import { defineConfig, devices } from "@playwright/test";
import { e2eServerEnv } from "./e2e/helpers/e2eServerEnv";

/** Port propi: ni 4450, ni 3179, ni 3177. */
const port = 3468;
const appUrl = `http://127.0.0.1:${port}`;

export default defineConfig({
  testDir: "./e2e",
  testMatch: "solo-servidor.spec.ts",
  timeout: 120_000,
  retries: 0,
  workers: 1,
  projects: [{ name: "chromium", use: { ...devices["Desktop Chrome"], browserName: "chromium" } }],
  use: {
    locale: "en-US",
    baseURL: appUrl,
  },
  globalTeardown: "./e2e/helpers/e2eGlobalTeardown.ts",
  webServer: {
    command: "npm run dev",
    env: { ...e2eServerEnv(), PORT: String(port), APP_URL: appUrl },
    url: `${appUrl}/api/health`,
    reuseExistingServer: false,
    timeout: 120_000,
  },
});
