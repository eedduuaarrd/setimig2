import { defineConfig } from "@playwright/test";
import { e2eServerEnv } from "./e2e/helpers/e2eServerEnv";

const port = Number(process.env.SETIMIG_E2E_PORT ?? process.env.PORT ?? 3300);
const appUrl = process.env.APP_URL ?? `http://127.0.0.1:${port}`;

/** Liquidació: resum traduït (en/es) i la mà visible sota el panell a 390 i a 1280. */
export default defineConfig({
  testDir: "./e2e",
  testMatch: "liquidacio-i18n-1280.spec.ts",
  timeout: 180_000,
  retries: 0,
  workers: 1,
  use: {
    browserName: "chromium",
    baseURL: appUrl,
    viewport: { width: 390, height: 844 },
    locale: "en-US",
    colorScheme: "dark",
    screenshot: "only-on-failure",
  },
  globalTeardown: "./e2e/helpers/e2eGlobalTeardown.ts",
  webServer: {
    command: `npm run build && cross-env NODE_ENV=production HOST=127.0.0.1 PORT=${port} APP_URL=${appUrl} PLAYER_TOKEN_SECRET=playwright-e2e-test-secret npm run start`,
    env: e2eServerEnv(),
    url: appUrl,
    reuseExistingServer: false,
    timeout: 180_000,
  },
});
