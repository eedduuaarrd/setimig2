import { defineConfig } from "@playwright/test";

const port = Number(process.env.PEEK_DEMO_PORT ?? 4317);
const baseURL = `http://127.0.0.1:${port}`;

export default defineConfig({
  testDir: "./e2e",
  testMatch: "peek-flip-demo.spec.ts",
  timeout: 60_000,
  retries: 0,
  workers: 1,
  use: {
    browserName: "chromium",
    baseURL,
    viewport: { width: 390, height: 844 },
    locale: "ca-ES",
    colorScheme: "dark",
    video: process.env.PW_VIDEO ? { mode: "on", size: { width: 390, height: 844 } } : "off",
  },
  webServer: {
    command: `npx vite --host 127.0.0.1 --port ${port} --strictPort`,
    url: `${baseURL}/e2e/peek-flip-demo.html`,
    reuseExistingServer: false,
    timeout: 120_000,
  },
});
