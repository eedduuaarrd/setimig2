# Setimig — UX / jugabilitat pass (45 punts)

Aquest pass afegeix una capa de poliment visual i tàctil a `src/index.css` sense alterar les regles de joc ni el protocol de xarxa.

## Canvis aplicats en aquesta versió
- Transicions de cartes més coherents i sense animació idle innecessària.
- Resposta tàctil més uniforme i estats disabled/busy sense salts visuals.
- Millor estabilitat tipogràfica per a noms i imports variables.
- Reaccions ràpides amb objectius tàctils d'almenys 44 px.
- Selecció de text habilitada en contingut de diàlegs, legal i regles, mantenint controls de joc no seleccionables.
- Diàlegs limitats a l'alçada visible i amb scroll intern.
- Ajustos per a mòbils estrets i orientació horitzontal baixa.
- Hover desactivat com a efecte persistent en dispositius tàctils.
- Respecte de `prefers-reduced-motion` per als nous efectes.
- Variables CSS de durada i easing per mantenir el moviment coherent.

## Estat dels 45 punts de la revisió
Els punts són una llista de verificació de qualitat, no 45 errors confirmats. El projecte ja disposava de molts elements: indicador de torn, prompt contextual, cronologia d'accions, pantalla de liquidació, progrés de partida, safe areas, adaptació de cartes, feedback hàptic/sonor i suport per a moviment reduït. Aquest pass els conserva i hi afegeix refinaments transversals.

## Validació pendent
Cal executar `npm ci`, `npm run check`, `npm test` i les proves E2E disponibles en un entorn amb dependències. Aquesta entrega no declara cap desplegament a producció.
