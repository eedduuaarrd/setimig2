# Tercera fase · Set i Mig

S'han mantingut els motors autoritatius, les apostes i els terminis de decisió.

1. Repartiment: es conserva la distribució adaptativa de ventall i les animacions originals.
2. Banca: es conserven les pauses de revelació i tensió existents; sense noves demores a servidor.
3. Temporitzador: barra de capçalera substituïda per compte enrere circular.
4. Estat rivals: exposat amb atribut semàntic i contrast del rival actiu.
5. Pot: títol explicatiu accessible, sense dobles recomptes.
6. Resultat: nova explicació breu basada en el resultat oficial (sense revelar punts propis).
7. Mòbil: millores CSS per pantalla estreta i fases amb protagonisme de la mà.
8. Cartes: botó per consultar la mà ampliada sense revelar cartes ocultes.
9. Última mà: resum consultable dels resultats oficials del servidor quan la taula està en espera (no és una reproducció animada de les cartes).
10. So: volum ambiental independent i atenuació temporal en moments de revelació/liquidació.
11. Modularització: components nous per a temporitzador, ampliador i resum, més CSS aïllat.

**Verificació**: cal compilar amb `npm ci && npm run check` i executar les proves E2E en un navegador compatible. No es pot assegurar funcionament de producció només amb la integritat del ZIP.

Les animacions realistes, el comportament de bots i les pauses de la banca continuen utilitzant les funcionalitats de la versió anterior. No es modifica la IA ni es crea un enregistrament complet de les cartes de mans passades.
