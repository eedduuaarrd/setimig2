# Millores de jugabilitat · 3 de novembre de 2026

## Canvis

- **Claredat del torn en mòbil:** indicador compacte just a sobre dels controls, amb qui juga, si et toca a tu i segons restants. No tapa els botons ni ocupa alçada addicional dins la mà.
- **Mòbils petits:** tipografia dels botons adaptable en pantalles de fins a 380 px. Indicador compacte també en horitzontal i suport al moviment reduït.
- **Apostes accessibles:** la barra d'apostes ara es pot controlar amb teclat (fletxes, inici/final, pàgina amunt/avall), amb semàntica i valors per a lectors de pantalla.
- **Ritme de partida:** avís de carta de 1750 a 1250 ms, avís de plantar-se de 2950 a 1850 ms. Liquidació de fitxes per rival de 900 a 650 ms, i comptador final de 800 a 600 ms. Els terminis de decisió dels jugadors (aposta i torn) no canvien.
- **Tests:** s'han actualitzat les comprovacions dels temps pactats al ritme del servidor.

## Abast

No s'han alterat les regles de Set i Mig, les probabilitats, l'economia de fitxes ni els contractes de xarxa. Les durades de revelació especial i l'oferta de banca s'han conservat per no comprometre la tensió i la llegibilitat.

## Verificació

Vegeu els resultats executats a l'entrega. Requereix `npm ci` per instal·lar les dependències abans de compilar o executar.
