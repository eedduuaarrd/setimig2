import "dotenv/config";
import express from "express";
import { createServer } from "http";
import path from "path";
import { Server } from "socket.io";
import { createServer as createViteServer } from "vite";
import { getBalance } from "./server/balances";
import { claimFreeChips, getFreeClaimStatus } from "./server/freeClaim";
import { getProfile, InvalidAvatarError, resolvedAvatarForProfile, upsertProfile } from "./server/profiles.ts";
import { getGameCountsForHealth, lobbyHeldStack, setupGameHandlers } from "./server/game";
import { buildHealthPayload } from "./server/healthMetrics.ts";
import { mountStaticDist } from "./server/staticAssets.ts";
import { apiRateLimit } from "./server/httpRateLimit.ts";
import { handleRenewPlayerSession, resolvePlayerFromRequest, sendPlayerResponse } from "./server/httpPlayerAuth.ts";
import { requireLoginMiddleware, registerSocketLoginGate } from "./server/requireLogin.ts";
import { createStripeClient } from "./server/payments";
import {
  handleDeleteFriend,
  handleGetFriendCode,
  handleGetFriends,
  handlePostFriends,
} from "./server/friends/friendsHttp.ts";
import {
  claimDailyMission,
  getAchievementsView,
  getMissionsView,
  getWeeklyLeaderboardView,
} from "./server/achievementsEngine.ts";
import { handleGetRanking } from "./server/chipRanking.ts";
import { ensureEngagementDirWithBackup } from "./server/achievementsStore.ts";
import { getPlayerHistory, getPlayerStats } from "./server/playerStats.ts";
import { getPublicCampaignPayload } from "./server/campaignProgress.ts";
import { installShutdownFlush } from "./server/writeCoalescing.ts";
import { handlePostEvent } from "./server/analyticsHttp.ts";
import { resolveListenHost } from "./server/listenHost.ts";
import { registerApiNotFound, registerManifestRedirect } from "./server/spaFallback.ts";
import { registerStaticLegalDocs } from "./server/staticLegalDocs.ts";
import { pruneAnalyticsOnStartup, rememberTestFlag, trackLater } from "./server/analytics.ts";
import { apiCorsMiddleware, socketIoOriginOptions } from "./server/allowedOrigins.ts";
import { registerHandoffRoutes } from "./server/originHandoff.ts";
import { recordDomainSeen } from "./server/domainMigration.ts";
import { notifySignupLater } from "./server/mail/signupNotice.ts";
import { sessionCookieMiddleware } from "./server/sessionCookie.ts";
import { registerAuthRoutes } from "./server/auth/authRoutes.ts";
import { registerGoogleAuthRoutes } from "./server/auth/googleAuth.ts";
import { registerPasskeyRoutes } from "./server/auth/passkeys.ts";
import { registerSoloHttpRoutes } from "./server/soloHttpRoutes.ts";

const PORT = Number(process.env.PORT) || 3000;
const HOST = resolveListenHost();
const APP_URL = process.env.APP_URL || `http://localhost:${PORT}`;
const stripe = createStripeClient();

// Async socket/HTTP handlers must never take the whole table server down.
process.on("unhandledRejection", (reason) => {
  console.error("[unhandledRejection]", reason instanceof Error ? reason.stack ?? reason.message : reason);
});

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  // Orígens permesos: sevenhalf.club, www.sevenhalf.club, setimig.supercbb.com (o ALLOWED_ORIGINS) + APP_URL.
  const io = new Server(httpServer, socketIoOriginOptions());
  // Sense compte: connect_error amb message === "auth_required". Vegeu docs/login-obligatori.md.
  registerSocketLoginGate(io);

  await setupGameHandlers(io);
  await ensureEngagementDirWithBackup();
  await pruneAnalyticsOnStartup().catch((err) => console.error("[analytics] prune failed:", err));
  // Escriptures agrupades (saldos, rànquing): es buiden en SIGTERM/SIGINT i en sortir.
  installShutdownFlush();

  app.disable("x-powered-by");
  app.use((req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "DENY");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=()");
    if (req.path.startsWith("/api/")) {
      res.setHeader("Cache-Control", "no-store, max-age=0");
    }
    next();
  });
  app.use(apiCorsMiddleware());
  app.use(apiRateLimit);
  app.use(express.json({ limit: "100kb" }));
  // Login obligatori: /api/* exigeix sessió, tret de /api/health, /api/auth/* i /api/handoff/exchange.
  app.use(requireLoginMiddleware);
  // Galeta de sessió HttpOnly per als HTML estàtics privats (vegeu server/sessionCookie.ts).
  app.use(sessionCookieMiddleware);
  // Traspàs de compte entre dominis (setimig.supercbb.com -> sevenhalf.club).
  registerHandoffRoutes(app);
  // Inici de sessió: correu (codi / enllaç màgic), Google i passkeys. Vegeu docs/auth-contracte.md.
  registerAuthRoutes(app);
  registerGoogleAuthRoutes(app);
  registerPasskeyRoutes(app);

  app.get("/api/health", (_req, res) => {
    res.json(buildHealthPayload({ stripe: !!stripe, games: getGameCountsForHealth() }));
  });

  app.post("/api/player-session", (req, res) => {
    // Renova un token vàlid o, si el client l'ha perdut, la galeta setimig_session no revocada.
    // No crea jugadors. Un Bearer vàlid guanya sobre la galeta (no es barregen comptes).
    void handleRenewPlayerSession(req, res);
  });

  app.get("/api/profile", async (req, res) => {
    const resolved = resolvePlayerFromRequest(req);
    if (!resolved) {
      return res.status(400).json({ error: "Identitat de jugador invalida." });
    }
    try {
      const profile = (await getProfile(resolved.playerId)) ?? {
        displayName: "Jugador",
        avatarDataUrl: null,
        updatedAt: Date.now(),
      };
      sendPlayerResponse(res, {
        displayName: profile.displayName,
        avatarDataUrl: profile.avatarDataUrl,
        avatar: resolvedAvatarForProfile(profile, resolved.playerId),
      });
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : "Error desconegut";
      console.error("[api]", req.path, message);
      return res.status(500).json({ error: "Error intern. Torna-ho a provar." });
    }
  });

  app.put("/api/profile", async (req, res) => {
    const resolved = resolvePlayerFromRequest(req);
    if (!resolved) {
      return res.status(400).json({ error: "Identitat de jugador invalida." });
    }
    try {
      const isNewProfile = !(await getProfile(resolved.playerId));
      const saved = await upsertProfile(resolved.playerId, {
        displayName: req.body?.displayName,
        avatarDataUrl: req.body?.avatarDataUrl,
        avatar: req.body?.avatar,
      });
      if (!saved) {
        return res.status(400).json({ error: "Perfil invalid." });
      }
      rememberTestFlag(resolved.playerId, saved.displayName);
      if (isNewProfile) {
        trackLater(resolved.playerId, "player_registered", { ageGateOk: req.body?.ageGateOk === true });
        // Avís de registre a l'administrador (asíncron i idempotent; no bloqueja la resposta).
        notifySignupLater({ playerId: resolved.playerId, displayName: saved.displayName, method: "anonim" });
      }
      sendPlayerResponse(res, {
        displayName: saved.displayName,
        avatarDataUrl: saved.avatarDataUrl,
        avatar: resolvedAvatarForProfile(saved, resolved.playerId),
      });
    } catch (error: unknown) {
      if (error instanceof InvalidAvatarError) {
        return res.status(400).json({ error: "Avatar invalid." });
      }
      const message = error instanceof Error ? error.message : "Error desconegut";
      console.error("[api]", req.path, message);
      return res.status(500).json({ error: "Error intern. Torna-ho a provar." });
    }
  });

  app.get("/api/balance", async (req, res) => {
    const resolved = resolvePlayerFromRequest(req);
    if (!resolved) {
      return res.status(400).json({ error: "Identitat de jugador invalida." });
    }
    try {
      // Mètrica de migració de domini (només compta setimig.supercbb.com i sevenhalf.club).
      recordDomainSeen(resolved.playerId, req.headers.host);
      const chips = await getBalance(resolved.playerId);
      const freeClaim = await getFreeClaimStatus(resolved.playerId);
      // `chips` és el gastable (la compra ja descomptada). `lobbyChips` hi suma les fitxes
      // que encara són a una taula on el jugador no està connectat, perquè el vestíbul no
      // mostri les 2.000 com a perdudes fins que la mà es tanqui. Vegeu docs/aposta-ma-abandonada.md.
      sendPlayerResponse(res, { chips, lobbyChips: chips + lobbyHeldStack(resolved.playerId), freeClaim });
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : "Error desconegut";
      console.error("[api]", req.path, message);
      return res.status(500).json({ error: "Error intern. Torna-ho a provar." });
    }
  });

  app.post("/api/events", (req, res) => void handlePostEvent(req, res));

  app.get("/api/friends", (req, res) => void handleGetFriends(req, res));
  app.post("/api/friends", (req, res) => void handlePostFriends(req, res));
  app.delete("/api/friends/:code", (req, res) => void handleDeleteFriend(req, res));
  app.get("/api/friends/code", (req, res) => void handleGetFriendCode(req, res));
  app.get("/api/stats", async (req, res) => {
    const resolved = resolvePlayerFromRequest(req);
    if (!resolved) {
      return res.status(400).json({ error: "Identitat de jugador invalida." });
    }
    try {
      const stats = await getPlayerStats(resolved.playerId);
      sendPlayerResponse(res, stats);
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : "Error desconegut";
      console.error("[api]", req.path, message);
      return res.status(500).json({ error: "Error intern. Torna-ho a provar." });
    }
  });

  app.get("/api/achievements", async (req, res) => {
    const resolved = resolvePlayerFromRequest(req);
    if (!resolved) {
      return res.status(400).json({ error: "Identitat de jugador invalida." });
    }
    try {
      const achievements = await getAchievementsView(resolved.playerId);
      sendPlayerResponse(res, { achievements });
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : "Error desconegut";
      console.error("[api]", req.path, message);
      return res.status(500).json({ error: "Error intern. Torna-ho a provar." });
    }
  });

  app.get("/api/missions", async (req, res) => {
    const resolved = resolvePlayerFromRequest(req);
    if (!resolved) {
      return res.status(400).json({ error: "Identitat de jugador invalida." });
    }
    try {
      const payload = await getMissionsView(resolved.playerId);
      sendPlayerResponse(res, payload);
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : "Error desconegut";
      console.error("[api]", req.path, message);
      return res.status(500).json({ error: "Error intern. Torna-ho a provar." });
    }
  });

  app.post("/api/missions/claim", async (req, res) => {
    const resolved = resolvePlayerFromRequest(req);
    if (!resolved) {
      return res.status(400).json({ error: "Identitat de jugador invalida." });
    }
    const missionId = typeof req.body?.missionId === "string" ? req.body.missionId.trim() : "";
    if (!missionId) {
      return res.status(400).json({ error: "missionId obligatori." });
    }
    try {
      const result = await claimDailyMission(resolved.playerId, missionId);
      if (result.ok === false) {
        const status = result.code === "NOT_FOUND" ? 404 : 409;
        return res.status(status).json({ error: result.code, code: result.code });
      }
      trackLater(resolved.playerId, "mission_claimed", { missionKey: missionId.replace(/^\d{4}-\d{2}-\d{2}-/, "") });
      sendPlayerResponse(res, result);
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : "Error desconegut";
      console.error("[api]", req.path, message);
      return res.status(500).json({ error: "Error intern. Torna-ho a provar." });
    }
  });

  // Rànquing per saldo. Auth: requireLogin (401). Límit: apiRateLimit (429 RATE_LIMIT), com la resta de /api.
  app.get("/api/ranking", (req, res) => void handleGetRanking(req, res));

  app.get("/api/leaderboard/weekly", async (req, res) => {
    try {
      // Identificació opcional: sense token/jugador el rànquing continua sent públic (me = null).
      const viewer = resolvePlayerFromRequest(req);
      const board = await getWeeklyLeaderboardView(req.query.limit, Date.now(), viewer?.playerId ?? null);
      res.json(board);
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : "Error desconegut";
      console.error("[api]", req.path, message);
      return res.status(500).json({ error: "Error intern. Torna-ho a provar." });
    }
  });

  app.get("/api/campaign", async (req, res) => {
    const resolved = resolvePlayerFromRequest(req);
    if (!resolved) {
      return res.status(400).json({ error: "Identitat de jugador invalida." });
    }
    try {
      const payload = await getPublicCampaignPayload(resolved.playerId);
      sendPlayerResponse(res, payload);
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : "Error desconegut";
      console.error("[api]", req.path, message);
      return res.status(500).json({ error: "Error intern. Torna-ho a provar." });
    }
  });

  app.get("/api/history", async (req, res) => {
    const resolved = resolvePlayerFromRequest(req);
    if (!resolved) {
      return res.status(400).json({ error: "Identitat de jugador invalida." });
    }
    try {
      const page = await getPlayerHistory(resolved.playerId, req.query.limit, req.query.before);
      sendPlayerResponse(res, page);
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : "Error desconegut";
      if (message === "Invalid before cursor") {
        return res.status(400).json({ error: message });
      }
      console.error("[api]", req.path, message);
      return res.status(500).json({ error: "Error intern. Torna-ho a provar." });
    }
  });

  registerSoloHttpRoutes(app);

  app.post("/api/claim-free-chips", async (req, res) => {
    const resolved = resolvePlayerFromRequest(req);
    if (!resolved) {
      return res.status(400).json({ error: "Identitat de jugador invalida." });
    }
    try {
      const result = await claimFreeChips(resolved.playerId);
      if (result.ok === false) {
        return res.status(429).json({
          error: "Encara no pots reclamar. Torna més tard.",
          code: result.code,
          chips: result.chips,
          freeClaim: result.freeClaim,
        });
      }
      trackLater(resolved.playerId, "daily_reward_claimed", { amount: result.credited });
      sendPlayerResponse(res, {
        chips: result.chips,
        credited: result.credited,
        freeClaim: result.freeClaim,
        lastClaimAt: result.lastClaimAt,
      });
    } catch (error: unknown) {
      const message = error instanceof Error ? error.message : "Error desconegut";
      console.error("[api]", req.path, message);
      return res.status(500).json({ error: "Error intern. Torna-ho a provar." });
    }
  });

  // /manifest.webmanifest (nom antic) -> /site.webmanifest (301).
  registerApiNotFound(app);
  registerManifestRedirect(app);

  if (process.env.NODE_ENV !== "production") {
    // Same documents as production, read from public/ so Vite's SPA fallback
    // does not answer /privacy and /terms with the home shell.
    registerStaticLegalDocs(app, path.join(process.cwd(), "public"));
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // /assets/* (amb hash) un any i immutable; index.html, sw.js i la resta sense memòria cau llarga.
    // Rutes de l'app -> index.html; fitxers amb extensió que no existeixen -> 404.
    mountStaticDist(app, path.join(process.cwd(), "dist"));
  }

  httpServer.listen(PORT, HOST, () => {
    console.log(`Set i Mig running on ${APP_URL} (escoltant a ${HOST}:${PORT})`);
  });
}

void startServer();
