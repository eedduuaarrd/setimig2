# Setimig V13 — interfície minimalista

Aquesta versió prioritza una interfície menys carregada i més clara sense canviar les regles de joc.

## Canvis
- Taula verda més plana, sense textura ni gradients intensos.
- Reducció d'ombres i efectes decoratius a la taula, cartes i controls.
- Botons principals amb text més directe: «Demanar carta», «Plantar-me» i «Plantar-se» segons el context.
- Acció de revelar simplificada a «Destapar carta»; es conserva l'explicació de què fa.
- Resum de sessió d'escriptori menys prominent per deixar el joc com a focus.
- Manteniment de l'estructura responsive, les zones segures del mòbil i el suport a moviment reduït.
- Es conserven els temes opcionals, el xat/reaccions i les funcions existents.

## Validació
- `src/GameView.tsx`: comprovació de sintaxi TSX amb TypeScript `transpileModule`, sense diagnòstics.
- No s'ha completat la compilació Vite ni les proves end-to-end perquè les dependències del projecte no estan instal·lades en aquest entorn.
- No s'ha publicat ni modificat directament el servidor de producció.

## Pendent per a una validació completa
- Executar `npm ci`, `npm run check` i les proves automatitzades.
- Provar la partida amb diversos navegadors/dispositius, especialment els casos de reconnexió i accions simultànies.
