import { defineConfig } from "@playwright/test";
import { catalanStorageState } from "./e2e/catalanLocale";

const port = Number(process.env.SETIMIG_E2E_PORT ?? process.env.PORT ?? 3177);
const appUrl = process.env.APP_URL ?? `http://127.0.0.1:${port}`;

export default defineConfig({
  testDir: "./e2e",
  testMatch: "casino-v2-tokens.spec.ts",
  timeout: 120_000,
  use: {
    locale: "ca-ES",
    storageState: catalanStorageState(),
    baseURL: appUrl,
    viewport: { width: 390, height: 844 },
  },
  webServer: {
    command: `npm run build && cross-env NODE_ENV=production PORT=${port} APP_URL=${appUrl} PLAYER_TOKEN_SECRET=playwright-e2e-test-secret npm run start`,
    url: appUrl,
    reuseExistingServer: false,
    timeout: 120_000,
  },
});
