# Setimig V11 — poliment d'experiència de joc

## Canvis aplicats
- Animació curta d'entrada per a les cartes que apareixen al centre, amb respecte per `prefers-reduced-motion`.
- Bloqueig temporal de les accions principals «Carta» i «Plantar-se» per evitar enviaments duplicats per doble toc o repeticions ràpides del teclat; el bloqueig es reinicia quan canvia el torn, la fase o la sala.
- Avís visible quan el navegador indica que no hi ha connexió a Internet, també en partides multijugador.
- Estats desactivats més clars per als botons mentre una acció està pendent.
- Millora del focus visible per a teclat i reducció global de transicions quan el dispositiu demana moviment reduït.
- Mantingut l'apilament vertical de les cartes centrals amb la carta més nova al davant.

## Funcions que ja existien i s'han mantingut
- Cronologia d'accions recents.
- Controls de so, vibració i moviment.
- Pantalla de resultat, compartir resultats i revanxa quan està disponible.
- Lògica de joc i redacció de cartes tapades del costat del servidor ja presents al projecte.

## Validació
- `src/GameView.tsx` passa la comprovació de sintaxi/transpilació TSX.
- La comprovació global `tsc --noEmit` no es pot completar en aquest entorn perquè les dependències del projecte no estan instal·lades (errors de mòduls absents com React i Playwright).
- No s'ha executat una prova visual real al navegador ni proves E2E en aquesta execució.
