# Setimig UX V20 — adaptació dels repositoris de cartes

## Revisió dels repositoris
- `Steellgold/blackjack`: útil com a referència de blackjack multijugador, repartiment, apostes i disseny responsive. No s'ha copiat l'arquitectura Next.js/Socket.IO perquè Setimig ja té el seu propi motor i sincronització.
- `FilipsMasolovs/react-blackjack`: referència de components de joc modulars i animacions de cartes. S'han adoptat patrons, no codi del repositori.
- `strangeworlder/react-ttrpg-cards`: té repartiment 3D amb física, patrons, flip, so i `prefers-reduced-motion`, però requereix Three.js, React Three Fiber i Rapier. No s'ha afegit perquè seria una dependència pesada i el seu model de cartes no correspon directament a la baralla espanyola de Setimig.
- `motiondivision/motion`: ja era una dependència del projecte. S'aprofita per animar els canvis de cara de les cartes i l'entrada de cartes noves als seients rivals.
- `joshwcomeau/use-sound`: no s'ha afegit; Setimig ja disposa de sons i vibració. Afegir un segon sistema podria duplicar efectes i preferències.
- `playpip/pip-web`: referència útil per una estètica controlada, lectura clara de la taula i separació entre motor i presentació. No s'ha copiat el seu motor de pòquer ni el seu sistema d'economia.
- `wmaillard/react-playing-cards`: referència per a mans, cartes superposades i disposicions en ventall. Es conserva el component `SpanishCard` i el layout propi de Setimig, en lloc d'importar cartes franceses o codi amb compatibilitat no verificada.
- `microsoft/playwright`: Setimig ja té infraestructura E2E; s'ha de fer servir per validar el comportament visual a mòbil/escriptori i el respecte per moviment reduït. No s'ha afirmat que les proves s'hagin executat en aquest entorn.

## Canvis implementats
- `SpanishCard.tsx`: animació breu de gir quan una carta passa de tapada a descoberta o a l'inrevés. Manté una única etiqueta accessible al component exterior i amaga els SVG interns de l'arbre accessible.
- `PlayerSeat.tsx`: entrada subtil i escalonada de les cartes als seients que no són el jugador local. La clau estable de cada carta evita tornar a animar les cartes existents quan només arriba una carta nova.
- Es respecta `useReducedMotion`; en mode de moviment reduït la transició és immediata.
- No s'afegeixen dependències, sons nous, textures pesades ni canvis al motor/regles del joc.

## Validació pendent
- Revisió estàtica i comprovació de sintaxi TypeScript dels fitxers modificats.
- La compilació completa, els tests unitaris/E2E i la comprovació visual real han de córrer en un entorn amb totes les dependències instal·lades. No desplegar sense aquests passos.
