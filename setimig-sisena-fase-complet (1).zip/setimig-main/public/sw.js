/* eslint-disable no-restricted-globals */
const CACHE_VERSION = "setimig-shell-v201";

/**
 * Domini antic (setimig.supercbb.com): SW de baixa. Buida les memòries cau, es desregistra sol i
 * no intercepta res, perquè el traspàs a sevenhalf.club i el 301 posterior no quedin amagats
 * darrere la shell desada. No recarrega cap pestanya: la partida oberta continua per xarxa.
 */
const RETIRED_HOSTNAMES = ["setimig.supercbb.com"];
const RETIRED = RETIRED_HOSTNAMES.includes(self.location.hostname);

/** Només al domini antic: la baixa no toca cap estat de la partida, així que no cal esperar entre mans. */
function retireOnInstall() {
  self.skipWaiting();
}

async function retireWorker() {
  try {
    const keys = await caches.keys();
    await Promise.all(keys.map((key) => caches.delete(key)));
  } catch {
    /* sense Cache Storage */
  }
  try {
    await self.registration.unregister();
  } catch {
    /* ja desregistrat */
  }
}

const SHELL = [
  "/",
  "/index.html",
  "/offline.html",
  "/robots.txt",
  "/site.webmanifest",
  // Logo «C · Fum daurat» (PNG rasteritzat). icon-1024 no hi va: només per a botigues i og.
  "/icon-192.png",
  "/icon-512.png",
  "/maskable-192.png",
  "/maskable-512.png",
  "/apple-touch-icon-180.png",
  "/favicon.ico",
  "/favicon-32.png",
  "/favicon-16.png",
  // Lobby: mateixa il·lustració amb fons transparent (sense el quadrat #0E0F0C).
  "/brand/logo-fum-192.png",
  "/brand/logo-fum-512.png",
  "/brand/logo-splash-v163.png",
  "/brand/logo-net-cartes-192.webp",
  "/brand/logo-net-cartes-512.webp",
  "/brand/intro/intro-7-oros.webp",
  "/brand/intro/intro-rei-copes.webp",
  "/brand/intro/intro-dors-3x.webp",
];

/**
 * Baralla E + revers L2b (nota-app-pwa.md): al precache només les il·lustracions 280, els pips, el paper i el
 * revers 2x (~380 KB), perquè la mà no surti mai buida fora de línia. Les 520 van amb memòria cau en temps
 * d'execució (cache-first), i l'app les precarrega en entrar a la taula. Tots els noms porten hash.
 */
// BARALLA:START (generat per scripts/baralla-assets.mjs; 27 fitxers, 375537 bytes)
const BARALLA_PRECACHE = [
  "/baralla/cares/1-bastos-280.63e3fe58.avif",
  "/baralla/cares/1-copes-280.f7062339.avif",
  "/baralla/cares/1-espases-280.62bd674b.avif",
  "/baralla/cares/1-oros-280.6dd25020.avif",
  "/baralla/cares/C-bastos-280.382bc34e.avif",
  "/baralla/cares/C-copes-280.b78b343b.avif",
  "/baralla/cares/C-espases-280.e342527b.avif",
  "/baralla/cares/C-oros-280.a1efc498.avif",
  "/baralla/cares/R-bastos-280.cde2093f.avif",
  "/baralla/cares/R-copes-280.d24464da.avif",
  "/baralla/cares/R-espases-280.4deda876.avif",
  "/baralla/cares/R-oros-280.266cd786.avif",
  "/baralla/cares/S-bastos-280.0aa25146.avif",
  "/baralla/cares/S-copes-280.3904e28a.avif",
  "/baralla/cares/S-espases-280.61a810ed.avif",
  "/baralla/cares/S-oros-280.4646f0ab.avif",
  "/baralla/cares/pip-bastos-280.dd9c1e1c.avif",
  "/baralla/cares/pip-bastos-520.a0e77ab9.avif",
  "/baralla/cares/pip-copes-280.3c30bece.avif",
  "/baralla/cares/pip-copes-520.08ce794c.avif",
  "/baralla/cares/pip-espases-280.c2434116.avif",
  "/baralla/cares/pip-espases-520.2d0d2fcf.avif",
  "/baralla/cares/pip-oros-280.7e478db3.avif",
  "/baralla/cares/pip-oros-520.ce85329b.avif",
  "/baralla/fons-280.241003f4.avif",
  "/baralla/fons-520.869b25aa.avif",
  "/baralla/dors-2x.7f2e8446.webp"
];
// BARALLA:END

function isBarallaAsset(url) {
  return url.pathname.startsWith("/baralla/");
}

function isApiOrSocket(url) {
  return url.pathname.startsWith("/api") || url.pathname.startsWith("/socket.io");
}

/** Mateixa regla que src/pwa/spaNavigation.ts: /t/CODI ha de servir l'app. */
function isSpaNavigationPath(pathname) {
  if (pathname.startsWith("/api") || pathname.startsWith("/socket.io")) return false;
  if (pathname === "/sw.js") return false;
  const last = pathname.split("/").pop() || "";
  if (last.includes(".")) return false;
  return true;
}

async function cachedSpaShell() {
  const cached = await caches.match("/index.html");
  if (cached) return cached;
  const offline = await caches.match("/offline.html");
  if (offline) return offline;
  return new Response("Seven Half Club", {
    status: 503,
    headers: { "Content-Type": "text/plain; charset=utf-8" },
  });
}

function assetUrlsFromHtml(html) {
  const urls = new Set();
  for (const match of html.matchAll(/(?:src|href)="(\/assets\/[^"?#]+)/g)) {
    urls.add(match[1]);
  }
  return [...urls];
}

async function precacheShellAndBundles() {
  const cache = await caches.open(CACHE_VERSION);
  await cache.addAll(SHELL).catch(() => {
    /* best-effort shell */
  });
  await Promise.allSettled(BARALLA_PRECACHE.map((asset) => cache.add(asset)));
  try {
    const res = await fetch("/index.html", { cache: "no-cache" });
    if (!res.ok) return;
    const html = await res.text();
    const assets = new Set(assetUrlsFromHtml(html));
    try {
      const manifestRes = await fetch("/precache-assets.json", { cache: "no-store" });
      if (manifestRes.ok) {
        const manifest = await manifestRes.json();
        if (Array.isArray(manifest.assets)) {
          for (const asset of manifest.assets) {
            if (typeof asset === "string" && /^\/assets\/[a-zA-Z0-9._/-]+$/.test(asset)) {
              assets.add(asset);
            }
          }
        }
      }
    } catch {
      /* Older deployments may not have a generated manifest. */
    }
    await Promise.allSettled([...assets].map((asset) => cache.add(asset)));
  } catch {
    /* offline install — shell only */
  }
}

self.addEventListener("message", (event) => {
  if (event.data?.type === "SKIP_WAITING") {
    self.skipWaiting();
  }
});

self.addEventListener("install", (event) => {
  if (RETIRED) {
    retireOnInstall();
    return;
  }
  // No activar una nova versió enmig d'una mà: el client ho autoritza entre mans.
  event.waitUntil(precacheShellAndBundles());
});

self.addEventListener("activate", (event) => {
  if (RETIRED) {
    event.waitUntil(retireWorker());
    return;
  }
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((key) => key !== CACHE_VERSION).map((key) => caches.delete(key))))
  );
  self.clients.claim();
});

self.addEventListener("fetch", (event) => {
  if (RETIRED) return;
  const url = new URL(event.request.url);
  if (url.origin !== self.location.origin) return;
  if (isApiOrSocket(url)) return;
  if (event.request.method !== "GET") return;

  if (event.request.mode === "navigate") {
    event.respondWith(
      fetch(event.request)
        .then(async (response) => {
          if (response.ok && response.type === "basic") {
            // Only the app shell may be stored as /index.html. /regles is its own document.
            if (url.pathname === "/" || url.pathname === "/index.html") {
              const clone = response.clone();
              void caches.open(CACHE_VERSION).then((cache) => cache.put("/index.html", clone));
            }
            return response;
          }
          if (!response.ok && isSpaNavigationPath(url.pathname)) {
            const shell = await cachedSpaShell();
            if (shell) return shell;
          }
          return response;
        })
        .catch(async () => cachedSpaShell())
    );
    return;
  }

  if (isBarallaAsset(url)) {
    // Noms amb hash: immutables, cache-first (les 520 entren aquí el primer cop que es demanen).
    event.respondWith(
      caches.match(event.request).then(
        (cached) =>
          cached ||
          fetch(event.request).then((response) => {
            if (response.ok && response.type === "basic") {
              const clone = response.clone();
              void caches.open(CACHE_VERSION).then((cache) => cache.put(event.request, clone));
            }
            return response;
          })
      )
    );
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cached) => {
      const network = fetch(event.request)
        .then((response) => {
          if (response.ok && response.type === "basic") {
            const clone = response.clone();
            void caches.open(CACHE_VERSION).then((cache) => cache.put(event.request, clone));
          }
          return response;
        })
        .catch(() => cached);
      return cached || network;
    })
  );
});
