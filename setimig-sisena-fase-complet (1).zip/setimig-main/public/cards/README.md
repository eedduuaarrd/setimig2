# Baralla v3 · Seven Half Club

Baralla espanyola de 40 cartes de disseny propi, més el dors, en SVG (estil v3: marfil #F5F2EB i tinta #0B0B0B, monocrom).

- **Fitxers:** `{pal}-{n}.svg`, amb pal = `oros`, `copes`, `espases` o `bastos`, i n = 1–7, 10 (sota), 11 (cavall) o 12 (rei). El dors és `back.svg`.
- **Manifest:** `manifest.json` conté `id`, `suit`, `rank`, `points` (les figures valen ½), `label` (en català) i `file` de cada carta.
- **Format:** `viewBox="0 0 250 350"` (5:7). Cada fitxer pesa menys de 4 KB. El text ja és a camins, així que no depèn de cap font.
- **Generació:** són fitxers generats; no s'editen a mà. Es fa amb `npx tsx scripts/gen-deck.ts` (escriu) o `npx tsx scripts/gen-deck.ts --check` (comprova que estan al dia).
  - Els glifs surten de `scripts/deck/glyphs.json`, que es regenera amb `scripts/deck/extract-glyphs.py` (fontTools).
- **Llicència:** el disseny és obra pròpia. Els contorns dels números i dels rètols són de Cormorant Garamond (SIL OFL-1.1).
- **UI:** encara no estan connectades a la UI. Ho farà App PWA.
