# Set i Mig

Aplicacio web del joc catala "Set i Mig" amb frontend React/Vite i servidor Express + Socket.IO.

**Revisió V6 — Edició Clàssica (25/10/2026):** redisseny minimalista, sobri i formal: identitat tipogràfica, lobby editorial, controls de joc continguts, dorsos de cartes discrets, diàlegs simplificats i nous recursos PWA/socials. Preserva les millores funcionals de V5 (ajuda contextual, fotos optimitzades, càrrega i PWA). Consulta `docs/EDICIO-CLASSICA-V6.md` i `DESPLEGAMENT-SUPERCBB.md` abans de publicar.

## Caracteristiques

- **IA al client**: partides contra bots al navegador (motor compartit a `shared/`).
- **Amics al servidor**: taules privades amb codi d'invitacio, xat i temps real.
- Regles completes: banca, 7½, Mort, jackpot; represa amb «Tornar a la partida» al lobby.
- Saldo de fitxes al servidor (JSON a `data/balances.json`), identificat per un `playerId` estable al navegador.
- Compra opcional de fitxes amb Stripe Checkout: les fitxes nomes s'acrediten despres de verificar la sessio (`/api/verify-checkout`).

## Requisits

- Node.js 20 o superior per a l'aplicació.
- Node.js 22.19 o superior per executar l'auditoria Lighthouse (`npm run test:lighthouse`), com al runner de CI.

## Configuracio

1. Instal·la dependencies:
   `npm ci`
2. Crea un `.env` a partir de `.env.example`.
3. Per pagaments, configura `STRIPE_SECRET_KEY` (sense clau, la botiga es veu pero el checkout retorna 503).

## Desplegament (produccio)

```bash
npm ci && npm run build && npm run start
```

- `PORT=4450`
- `APP_URL=https://setimig.supercbb.com` (redirects de Stripe i origen CORS de Socket.IO)

## Scripts

- `npm run dev`: servidor de desenvolupament amb frontend i backend.
- `npm run build`: build del client (Vite; inclou `public/`).
- `npm run lint`: comprovacio TypeScript.
- `npm run check`: lint + build.
- `npm run start`: execucio en mode produccio (`NODE_ENV=production`).

## Variables d'entorn

- `PORT`: port HTTP del servidor (per defecte 3000; produccio 4450).
- `APP_URL`: URL publica de l'app (redirects Stripe i CORS Socket.IO).
- `STRIPE_SECRET_KEY`: clau secreta Stripe per crear sessions i verificar pagaments.
- `BALANCE_DATA_DIR` (opcional): directori on es desa `balances.json` (per defecte `./data`).

## API de fitxes

- `GET /api/balance?playerId=...` — saldo actual.
- `POST /api/create-checkout-session` — inicia Stripe Checkout (requereix clau Stripe).
- `POST /api/verify-checkout` — body `{ session_id, playerId }`; comprova `payment_status` i acredita fitxes de forma idempotent.

Despres del pagament, Stripe redirigeix a `?session_id=cs_...`; el client crida la verificacio i mai confia en parametres `chips` a la URL.

## Estructura

- `src/`: interfície React i sessió IA local.
- `shared/`: motor de joc i IA (servidor + client).
- `server/`: Socket.IO per taules privades, saldos i represa IA servidor (legacy fins PAS 13 complet).
- `server.ts`: arrencada HTTP, Stripe i API.
- `public/`: logo, favicon i manifest.

## Notes

- Els pagaments son opcionals. Sense Stripe, la botiga continua visible pero el checkout retornara un error controlat.
- En sortir d'una sala o en desconnectar, el servidor persisteix les fitxes del jugador al magatzem central.
