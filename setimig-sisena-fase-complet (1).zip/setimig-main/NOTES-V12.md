# Setimig V12 — millores d'experiència

## Canvis d'aquesta versió
- Selector de tema de taula amb tres opcions: verd original, blau i fosc.
- Preferència de tema guardada localment a `localStorage` (`setimig_table_theme`). Si l'emmagatzematge no està disponible, continua funcionant el tema de la sessió.
- Selector de tema accessible des del menú d'eines tant en mòbil com en ordinador.
- Reaccions ràpides al xat: 😂 😮 👏 🍀 🔥 ❤️. Es transmeten com a missatges normals del joc, sense afegir un canal de xarxa separat.
- S'han mantingut les animacions de cartes, celebració del 7,5, estat de torn, xat, cronologia d'accions, reconexió gestionada per Socket.IO, revanxa i opcions d'accessibilitat ja presents al projecte.
- Temes amb estils alternatius discrets i focus visible per a les reaccions; es respecta `prefers-reduced-motion`.

## Validació
- Comprovació de sintaxi TSX amb el compilador TypeScript global: `src/GameView.tsx` i `src/components/TableToolsMenu.tsx` sense diagnòstics de sintaxi.
- Cal fer instal·lació de dependències, compilació completa i proves de navegador/multijugador abans de desplegar.

## Funcions que no s'han inventat ni simul·lat
- La reproducció completa d'una partida passada requereix que el servidor conservi una seqüència fiable d'esdeveniments; la cronologia actual no equival a una reproducció completa.
- No s'ha afegit mode espectador perquè cal validar explícitament les garanties de privacitat de les cartes ocultes al servidor.
- La protecció client contra dobles pulsacions no substitueix la validació i idempotència al servidor.
