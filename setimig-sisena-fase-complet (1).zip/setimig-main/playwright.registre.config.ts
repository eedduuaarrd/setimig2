import { defineConfig, devices } from "@playwright/test";
import { e2eServerEnv } from "./e2e/helpers/e2eServerEnv";

/** Registre nou contra el build de PRODUCCIÓ (npm run build abans): NODE_ENV=production, 1 worker. */
const port = Number(process.env.E2E_PORT || 3303);
export default defineConfig({
  testDir: "./e2e",
  testMatch: ["registre-nou.spec.ts"],
  timeout: 60_000,
  retries: 0,
  workers: 1,
  projects: [{ name: "chromium", use: { ...devices["Desktop Chrome"], browserName: "chromium" } }],
  use: { baseURL: `http://127.0.0.1:${port}` },
  webServer: {
    command: `cross-env PORT=${port} NODE_ENV=production tsx server.ts`,
    env: e2eServerEnv({ PORT: String(port), NODE_ENV: "production" }),
    url: `http://127.0.0.1:${port}/api/health`,
    reuseExistingServer: false,
    timeout: 120_000,
  },
});
