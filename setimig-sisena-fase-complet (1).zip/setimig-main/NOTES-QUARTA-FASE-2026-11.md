# Quarta fase — novetats i validació

Modificacions efectives:
- Apostes automàtiques diferenciades segons perfil i aposta pròpia anterior, limitades per fitxes i cobertura. No es consulta informació privada de rivals.
- Configuració persistent de controls mòbils centrats/esquerra/dreta; millora de la disposició dels indicadors i àrees tàctils.
- Configuració de qualitat gràfica automàtica/reduïda; extensió al bokeh existent i a l'ambientació CSS.
- Aspecte dels seients actius/plantats/passats/en espera; estil més coherent en la resolució de mans.
- Ajustaments de layout horitzontal de mòbil i compatibilitat amb moviment reduït.
- Proves unitàries del càlcul d'apostes dels bots.

Sistemes conservats de fases anteriors (no s'han duplicat): la distribució adaptativa de cartes, les piles i animacions de fitxes, els efectes de llum i ambientals, les diferents velocitats dels bots, el registre d'accions, els estadístics de sessió, la revisió de mans, la reconnexió i la sincronització de nova mà amb el servidor.

Limitacions: els controls esquerra/dreta ajusten alineació visual i punts d'origen, però encara no reorganitzen totes les files de botons. La memòria dels bots en aquesta fase es basa en l'aposta anterior i les fitxes pròpies, no en un historial complet de resultats. No s'ha creat cap vídeo/reproducció completa de mans. Els tests E2E requereixen les dependències de desenvolupament instal·lades i un navegador disponible.
