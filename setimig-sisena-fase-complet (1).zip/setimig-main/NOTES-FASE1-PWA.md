# Fase 1 — App PWA (cartes, taula, animacions, mòbil)

## Repos consultats (només idees o codi amb llicència permesa)

| Repo | URL | Llicència | Ús en Setimig |
|---|---|---|---|
| baterson/blackjack-svelte-5 | https://github.com/baterson/blackjack-svelte-5 | MIT | Patró FLIP de repartiment (`translate` + `rotateY`); atribució a `licenses/MIT-baterson-blackjack-svelte-5.txt` i `src/lib/cardDealMotion.ts` |
| stopnoanime/21-online | https://github.com/stopnoanime/21-online | MIT | Referència de layout de taula i rotació de seients (ja alineat amb `tableSeats`) |
| wmaillard/react-playing-cards | https://github.com/wmaillard/react-playing-cards | MIT | Ventall de cartes i superposició; `SpanishCard` + `seatHandFanLayout` propis |
| deck-of-cards/deck-of-cards | https://github.com/deck-of-cards/deck-of-cards | Codi MIT; gràfics LGPL | Només idees d'easing de repartiment; **cap gràfic copiat** |
| motiondivision/motion | https://github.com/motiondivision/motion | MIT | Flip i entrades (`SpanishCard`, `PlayerSeat`, `SettlementSheet`) |

No s'ha trobat cap repo de baralla espanyola amb SVG reutilitzable sota MIT/Apache/BSD/CC0; les ilustracions de `SpanishCard` són originals alineades amb `--sm-*`.

## Canvis principals

- Cartes SVG de la baralla espanyola (oros, copes, espases, bastos) i dors Midnight Gold.
- Tapet amb vora fusta/metall subtil, ombres de carta i pot coherents amb la guia.
- Animacions §7: repartir, flip, 7½ natural, passar-se, victòria (glow/partícules subtils), `prefers-reduced-motion`.
- Barra de risc verd → groc → vermell; botons d'acció amb estats `game-action-*`.
- Mòbil: swipe opcional per demanar carta (`setimig_swipe_hit`, menú de taula).
- Service worker `setimig-shell-v42`.
