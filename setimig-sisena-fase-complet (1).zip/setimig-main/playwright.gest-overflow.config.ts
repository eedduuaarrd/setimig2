import { defineConfig } from "@playwright/test";
import { catalanStorageState } from "./e2e/catalanLocale";
import { e2eServerEnv } from "./e2e/helpers/e2eServerEnv";

const port = Number(process.env.SETIMIG_E2E_PORT ?? process.env.PORT ?? 3304);
const appUrl = process.env.APP_URL ?? `http://127.0.0.1:${port}`;

export default defineConfig({
  testDir: "./e2e",
  testMatch: "gest-lliscar-overflow.spec.ts",
  timeout: 120_000,
  workers: 1,
  use: {
    baseURL: appUrl,
    viewport: { width: 390, height: 844 },
    locale: "ca-ES",
    storageState: catalanStorageState(),
  },
  webServer: {
    command: `npm run build && cross-env NODE_ENV=production PORT=${port} APP_URL=${appUrl} PLAYER_TOKEN_SECRET=playwright-e2e-test-secret npm run start`,
    env: e2eServerEnv(),
    url: appUrl,
    reuseExistingServer: true,
    timeout: 180_000,
  },
});
