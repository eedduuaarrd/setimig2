import { defineConfig, devices } from "@playwright/test";
import { catalanStorageState } from "./e2e/catalanLocale";
import { e2eServerEnv } from "./e2e/helpers/e2eServerEnv";

export default defineConfig({
  testDir: "./e2e",
  testMatch: "pas13-offline-reload.spec.ts",
  timeout: 180_000,
  retries: 0,
  projects: [{ name: "chromium", use: { ...devices["Pixel 5"], browserName: "chromium" } }],
  use: {
    locale: "ca-ES",
    storageState: catalanStorageState(),
    baseURL: "http://127.0.0.1:4173",
    viewport: { width: 390, height: 844 },
  },
  globalTeardown: "./e2e/helpers/e2eGlobalTeardown.ts",
  webServer: {
    command: "cross-env NODE_ENV=production PORT=4173 tsx server.ts",
    env: e2eServerEnv(),
    url: "http://127.0.0.1:4173",
    reuseExistingServer: false,
    timeout: 120_000,
  },
});
