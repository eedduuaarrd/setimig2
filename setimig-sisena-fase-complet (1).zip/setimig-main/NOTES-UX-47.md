# Setimig UX V17 — lectura de partida i feedback de torn

Aquesta iteració continua les millores V15–V16 sense alterar les regles del joc ni els esdeveniments enviats al servidor.

## Canvis
- La cronologia mostra el nombre d'accions i destaca visualment l'acció més recent.
- L'última acció es marca com a actualització accessible per a lectors de pantalla, sense anunciar tota la cronologia cada vegada.
- El resum de la mà anuncia el resultat personal amb `role=status` i `aria-live=polite`.
- El botó de continuació mostra un text explícit mentre la següent mà encara no es pot iniciar i associa el compte enrere automàtic quan n'hi ha.
- El panell de torn té una clau basada en sala, fase i jugador actiu perquè el canvi de torn reprodueixi la seva animació d'entrada.
- S'afegeix una animació curta i discreta a l'acció més recent, desactivada amb `prefers-reduced-motion`.

## Validació
- Cal executar `npm ci`, `npm run check` i `npm test` en un entorn amb les dependències disponibles abans de desplegar.
- No s'ha validat el flux complet en un navegador real ni s'ha desplegat a producció.
