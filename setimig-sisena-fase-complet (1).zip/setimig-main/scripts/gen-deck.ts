/**
 * Baralla espanyola pròpia (estil v3) · Seven Half Club.
 *
 * Genera 40 cares + el dors a public/cards/ i un manifest.json.
 * Determinista: mateixa entrada → mateixos bytes. Sense dependències.
 * El text (índexs i rètols) ja surt convertit a camins a partir de
 * scripts/deck/glyphs.json (Cormorant Garamond, SIL OFL-1.1), així les
 * cartes no depenen de cap font.
 *
 * Ús:  npx tsx scripts/gen-deck.ts            (escriu public/cards/)
 *      npx tsx scripts/gen-deck.ts --check    (només comprova que estan al dia)
 */
import { readFileSync, writeFileSync, mkdirSync, existsSync } from "node:fs";

type Cmd = [string, ...number[]];
type Glyph = { adv: number; d: Cmd[] };
type Glyphs = { unitsPerEm: number; weights: Record<string, Record<string, Glyph>> };

export type Suit = "oros" | "copes" | "espases" | "bastos";
export const SUITS: Suit[] = ["oros", "copes", "espases", "bastos"];
export const RANKS = [1, 2, 3, 4, 5, 6, 7, 10, 11, 12] as const;
const FIGURE: Record<number, string> = { 10: "SOTA", 11: "CAVALL", 12: "REI" };
const SUIT_NAME: Record<Suit, string> = { oros: "Oros", copes: "Copes", espases: "Espases", bastos: "Bastos" };
const RANK_NAME: Record<number, string> = { 1: "As", 10: "Sota", 11: "Cavall", 12: "Rei" };
/** «As d'Oros», «3 de Copes»… (amb apòstrof davant de vocal). */
function cardLabel(suit: Suit, rank: number): string {
  const s = SUIT_NAME[suit];
  return `${RANK_NAME[rank] ?? rank} ${/^[AEIOU]/.test(s) ? "d'" : "de "}${s}`;
}

const PAPER = "#F5F2EB";
const INK = "#0B0B0B";
const W = 250;
const H = 350;

const GLYPHS: Glyphs = JSON.parse(readFileSync(new URL("./deck/glyphs.json", import.meta.url), "utf8"));

// ---------- números ----------
/** Format curt: 1 decimal, sense zeros sobrers ni zero inicial. */
function n(v: number): string {
  let s = (Math.round(v * 10) / 10).toFixed(1);
  if (s.endsWith(".0")) s = s.slice(0, -2);
  if (s === "-0") s = "0";
  return s.replace(/^(-?)0\./, "$1.");
}
/** Uneix números estalviant separadors quan el signe ja separa. */
function nums(vs: number[]): string {
  let out = "";
  let prevHasDot = false;
  for (const v of vs) {
    const s = n(v);
    if (out === "" || s.startsWith("-") || (s.startsWith(".") && prevHasDot)) out += s;
    else out += " " + s;
    prevHasDot = s.includes(".");
  }
  return out;
}

// ---------- text a camins ----------
function textWidth(text: string, weight: string, size: number, spacing = 0): number {
  const g = GLYPHS.weights[weight];
  let w = 0;
  for (const ch of text) w += (g[ch].adv * size) / GLYPHS.unitsPerEm;
  return w + spacing * (text.length - 1);
}

/** Camí relatiu (quantitzat a 0,1) d'un text centrat a cx amb la línia base a y. */
function textPath(text: string, weight: string, size: number, cx: number, y: number, spacing = 0): string {
  const g = GLYPHS.weights[weight];
  const k = size / GLYPHS.unitsPerEm;
  let x = cx - textWidth(text, weight, size, spacing) / 2;
  const q = (v: number) => Math.round(v * 10) / 10;
  let d = "";
  let cur: [number, number] = [0, 0];
  let start: [number, number] = [0, 0];
  let first = true;
  for (const ch of text) {
    const gl = g[ch];
    for (const [op, ...a] of gl.d) {
      if (op === "Z") {
        d += "z";
        cur = start;
        continue;
      }
      const pts: number[] = [];
      for (let i = 0; i < a.length; i += 2) pts.push(q(x + a[i] * k), q(y + a[i + 1] * k));
      const rel: number[] = pts.map((v, i) => v - cur[i % 2]);
      const ex = pts[pts.length - 2];
      const ey = pts[pts.length - 1];
      if (op === "M") {
        d += (first ? "M" + nums(pts) : "m" + nums(rel));
        first = false;
        start = [ex, ey];
      } else if (op === "L") {
        if (rel[1] === 0) d += "h" + nums([rel[0]]);
        else if (rel[0] === 0) d += "v" + nums([rel[1]]);
        else d += "l" + nums(rel);
      } else {
        d += op.toLowerCase() + nums(rel);
      }
      cur = [ex, ey];
    }
    x += gl.adv * k + spacing;
  }
  return d;
}

// ---------- pals ----------
/** Pictograma del pal centrat a (0,0) sobre una graella de 24 unitats escalada a `size`. Traç 1,5. */
function suitGlyph(suit: Suit, size: number, sw = 1.5): string {
  const k = size / 24;
  const p = (...vs: number[]) => nums(vs.map((v) => v * k));
  const st = `fill="none" stroke="${INK}" stroke-width="${sw}"`;
  switch (suit) {
    case "oros":
      return (
        `<g ${st}><circle r="${n(11 * k)}"/><circle r="${n(8 * k)}" stroke-width="1"/>` +
        `<path d="M${p(0, -5.5, 4, 0, 0, 5.5, -4, 0)}z"/></g>` +
        `<circle r="${n(Math.max(1.2, 1.1 * k))}" fill="${INK}"/>`
      );
    case "copes":
      // calze de línies rectes: copa, nus, peu
      return `<path ${st} d="M${p(-9, -11, 9, -11, 4, -1, -4, -1)}zM${p(-9, -8)}H${n(9 * k)}M${p(0, -1)}V${n(7 * k)}M${p(-2.5, 3)}h${n(5 * k)}M${p(-6, 11, -3, 7, 3, 7, 6, 11)}z"/>`;
    case "espases":
      // fulla recta amb guarda
      return `<path ${st} d="M${p(0, -12, 2, -9, 2, 5, -2, 5, -2, -9)}zM${p(0, -8)}V${n(4 * k)}M${p(-7, 5)}H${n(7 * k)}M${p(0, 5)}V${n(9.5 * k)}"/><circle cy="${n(11 * k)}" r="${n(1.5 * k)}" ${st}/>`;
    case "bastos":
      // garrot amb dos nusos
      return `<path ${st} d="M${p(-1.2, 12, 1.2, 12, 3.5, -12, -3.5, -12)}zM${p(-2.7, -4)}l${p(-3.5, -3)}M${p(1.8, 4)}l${p(3.5, -3)}"/>`;
  }
}

/** Símbol petit de l'índex (14 unitats), sota el número. */
function indexSuit(suit: Suit): string {
  // oros i espases reprodueixen les mostres (cercle r7; fulla amb guarda)
  if (suit === "oros") return `<circle cx="22" cy="56" r="7" fill="none" stroke="${INK}" stroke-width="1.5"/>`;
  if (suit === "espases") return `<path d="M22 50v22M16 66h12" stroke="${INK}" stroke-width="1.5"/>`;
  return `<g transform="translate(22 59)">${suitGlyph(suit, 18, 1.2)}</g>`;
}

// ---------- pips ----------
const COL = [75, 125, 175];
const ROW = [80, 127.5, 175, 222.5, 270];
const PIPS: Record<number, [number, number][]> = {
  2: [[1, 0], [1, 4]],
  3: [[1, 0], [1, 2], [1, 4]],
  4: [[0, 0], [2, 0], [0, 4], [2, 4]],
  5: [[0, 0], [2, 0], [1, 2], [0, 4], [2, 4]],
  6: [[0, 0], [2, 0], [0, 2], [2, 2], [0, 4], [2, 4]],
  7: [[0, 0], [2, 0], [1, 1], [0, 2], [2, 2], [0, 4], [2, 4]],
};
const PIP_SIZE = 46;

function ace(suit: Suit): string {
  const rings = `<g fill="none" stroke="${INK}"><circle cx="125" cy="175" r="58" stroke-width="1.5"/><circle cx="125" cy="175" r="48" stroke-width="1"/></g>`;
  if (suit === "oros")
    return (
      rings +
      `<path d="M125 135 155 175 125 215 95 175Z" fill="none" stroke="${INK}" stroke-width="1.5"/><circle cx="125" cy="175" r="6" fill="${INK}"/>`
    );
  return rings + `<g transform="translate(125 175)">${suitGlyph(suit, 72)}</g>`;
}

function pips(suit: Suit, rank: number): string {
  let s = `<defs><g id="p">${suitGlyph(suit, PIP_SIZE)}</g></defs>`;
  for (const [c, r] of PIPS[rank]) s += `<use href="#p" x="${n(COL[c])}" y="${n(ROW[r])}"/>`;
  return s;
}

// ---------- figures ----------
/** Objecte del pal a la mà de la figura. */
function heldItem(suit: Suit): string {
  const st = `fill="none" stroke="${INK}" stroke-width="1.5"`;
  switch (suit) {
    case "espases":
      return `<path ${st} d="M175 95v150M165 230h20M175 245v15"/>`;
    case "bastos":
      return `<path ${st} d="M171 262h8l5-160h-18zM168.5 160l-7-5M180.5 200l7-5"/>`;
    case "copes":
      return `<g transform="translate(175 178)">${suitGlyph("copes", 44)}</g>`;
    case "oros":
      return `<g transform="translate(175 178)">${suitGlyph("oros", 40)}</g>`;
  }
}

function figure(suit: Suit, rank: number): string {
  const st = `fill="none" stroke="${INK}" stroke-width="1.5"`;
  let s = `<rect x="40" y="40" width="170" height="270" fill="none" stroke="${INK}" stroke-width="1"/>`;
  if (rank === 12) {
    // rei: corona, cap, cos (mostra 12-espases)
    s += `<g ${st}><path d="M95 110 105 85 115 100 125 80 135 100 145 85 155 110Z"/><circle cx="125" cy="140" r="22"/><path d="M90 250c0-50 15-78 35-78s35 28 35 78Z"/><path d="M110 200h30"/></g>`;
  } else if (rank === 10) {
    // sota: barret pla, cap, cos trapezoidal
    s += `<g ${st}><path d="M101 112h48M108 112l4-14h26l4 14"/><circle cx="125" cy="134" r="20"/><path d="M98 262 108 166h34l10 96Z"/><path d="M108 200h34M125 166v96"/></g>`;
  } else {
    // cavall: genet sobre un cavall geomètric que mira a l'esquerra
    s += `<g ${st}><path d="M113 82h24M118 82l2-10h10l2 10"/><circle cx="125" cy="98" r="14"/><path d="M112 162l4-50h18l4 50Z"/>` +
      `<path d="M84 162h88l-6 38H90ZM84 162 72 126l14-6 12 42M72 126 52 146l8 8 18-14M84 121l1-11 6 10M172 165l12 28M94 200l-6 60M106 200v60M148 200v60M160 200l6 60"/></g>`;
  }
  s += heldItem(suit);
  if (rank === 11) s = s.replace(/translate\(175 178\)/, "translate(178 128)").replace("M175 95v150M165 230h20M175 245v15", "M178 60v100M170 150h16M178 160v12").replace("M171 262h8l5-160h-18zM168.5 160l-7-5M180.5 200l7-5", "M176 176h4l3-112h-10zM174 100l-6-4M182 132l6-4");
  s += `<path d="${textPath(FIGURE[rank], "500", 14, 125, 292, 3)}" fill="${INK}"/>`;
  return s;
}

// ---------- carta ----------
function frame(fill: string, stroke: string, extra = ""): string {
  return `<rect x=".75" y=".75" width="248.5" height="348.5" rx="4" fill="${fill}" stroke="${stroke}"${extra} stroke-width="1.5"/>`;
}

function face(suit: Suit, rank: number): string {
  const label = cardLabel(suit, rank).replace("'", "&apos;");
  // índex: número + pal a dalt a l'esquerra; el mateix girat 180° a baix a la dreta
  const index = `<g id="i"><path d="${textPath(String(rank), "600", 30, 22, 40)}" fill="${INK}"/>${indexSuit(suit)}</g>`;
  const body = rank === 1 ? ace(suit) : rank >= 10 ? figure(suit, rank) : pips(suit, rank);
  return (
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img" aria-label="${label}">` +
    frame(PAPER, INK) +
    index +
    `<use href="#i" transform="rotate(180 125 175)"/>` +
    body +
    `</svg>\n`
  );
}

function back(): string {
  // mostra dors.svg (v3): negre, filet interior, cantonades art déco, rombes i ventall de dues cartes
  return (
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" role="img" aria-label="Dors de carta">` +
    frame(INK, PAPER, ` stroke-opacity=".65"`) +
    `<rect x="12" y="12" width="226" height="326" fill="none" stroke="${PAPER}" stroke-width="1"/>` +
    `<path d="M18 32V18h14M232 32V18h-14M18 318v14h14M232 318v14h-14" fill="none" stroke="${PAPER}" stroke-width="1.5"/>` +
    `<path d="M125 40 210 175 125 310 40 175ZM125 70 190 175 125 280 60 175Z" fill="none" stroke="${PAPER}" stroke-opacity=".35" stroke-width="1"/>` +
    `<g transform="translate(125 175)" fill="none" stroke="${PAPER}" stroke-width="1.5"><rect x="-22" y="-30" width="30" height="44" rx="2" transform="rotate(-10)"/><rect x="-8" y="-28" width="30" height="44" rx="2" fill="${INK}" transform="rotate(10)"/></g>` +
    `</svg>\n`
  );
}

export type ManifestCard = { id: string; suit: Suit; rank: number; points: number; label: string; file: string };

export function buildDeck(): Map<string, string> {
  const files = new Map<string, string>();
  const cards: ManifestCard[] = [];
  for (const suit of SUITS)
    for (const rank of RANKS) {
      const id = `${suit}-${rank}`;
      files.set(`${id}.svg`, face(suit, rank));
      cards.push({ id, suit, rank, points: rank >= 10 ? 0.5 : rank, label: cardLabel(suit, rank), file: `/cards/${id}.svg` });
    }
  files.set("back.svg", back());
  const manifest = {
    version: 3,
    viewBox: `0 0 ${W} ${H}`,
    aspect: "5:7",
    license: "Obra pròpia de Seven Half Club. Glifs: Cormorant Garamond (SIL OFL-1.1).",
    back: "/cards/back.svg",
    suits: SUITS,
    ranks: RANKS,
    cards,
  };
  files.set("manifest.json", JSON.stringify(manifest, null, 2) + "\n");
  return files;
}

const isMain = process.argv[1] && import.meta.url.endsWith(process.argv[1].replace(/\\/g, "/").split("/").pop() ?? "");
if (isMain) {
  const outArg = process.argv.indexOf("--out");
  const outDir = outArg > 0 ? process.argv[outArg + 1].replace(/\/?$/, "/") : new URL("../public/cards/", import.meta.url).pathname;
  const check = process.argv.includes("--check");
  const files = buildDeck();
  let stale = 0;
  let total = 0;
  if (!check) mkdirSync(outDir, { recursive: true });
  for (const [name, body] of files) {
    const path = outDir + name;
    const bytes = Buffer.byteLength(body);
    if (name.endsWith(".svg")) {
      total += bytes;
      if (bytes >= 4096) throw new Error(`${name} pesa ${bytes} B (límit 4 KB)`);
    }
    if (check) {
      if (!existsSync(path) || readFileSync(path, "utf8") !== body) {
        console.error(`desactualitzat: ${name}`);
        stale++;
      }
    } else writeFileSync(path, body);
  }
  if (total >= 120 * 1024) throw new Error(`la baralla pesa ${total} B (límit 120 KB)`);
  console.log(`${files.size - 1} SVG · ${(total / 1024).toFixed(1)} KB${check ? (stale ? ` · ${stale} desactualitzats` : " · al dia") : ` → ${outDir}`}`);
  if (stale) process.exit(1);
}
