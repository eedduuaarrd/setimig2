#!/usr/bin/env node
/**
 * Mesura el botó Apostar (bet-confirm) en diversos viewports.
 * Ús: APP_URL=http://127.0.0.1:3177 node scripts/measure-apostar.mjs
 */
import { chromium } from "@playwright/test";

const APP_URL = (process.env.APP_URL ?? "http://127.0.0.1:3177").replace(/\/$/, "");

const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844 },
  { tag: "375x667", width: 375, height: 667 },
  { tag: "360x740", width: 360, height: 740 },
];

async function passAgeGateToLobby(page, name) {
  const id = `meas-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
  await page.addInitScript(
    ({ playerId, playerName }) => {
      localStorage.setItem("setimig_player_id", playerId);
      localStorage.setItem("setimig_player_name", playerName);
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem(
        "setimig_age_gate",
        JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
      );
    },
    { playerId: id, playerName: name }
  );
  await page.goto(`${APP_URL}/`);
  const nameInput = page.getByTestId("age-gate-name");
  if (await nameInput.isVisible().catch(() => false)) {
    await nameInput.fill(name);
    await page.getByTestId("age-gate-accept").click();
  }
  await page.getByTestId("lobby-main").waitFor({ state: "visible", timeout: 60_000 });
}

async function openBetScreen(page) {
  await page.getByTestId("play-vs-ai-button").click();
  await page.getByTestId("ai-bot-picker").waitFor({ state: "visible" });
  await page.getByTestId("ai-bot-count-2").click();
  await page.getByRole("button", { name: "Començar" }).click();
  await page.getByTestId("bet-confirm").waitFor({ state: "visible", timeout: 60_000 });
}

function measureButton(box, vw, vh) {
  if (!box) return { ok: false, reason: "missing" };
  const bottom = box.y + box.height;
  const right = box.x + box.width;
  const visible = box.width > 0 && box.height > 0;
  const inViewport = box.y >= 0 && bottom <= vh && box.x >= 0 && right <= vw;
  return {
    ok: visible && inViewport,
    x: Math.round(box.x),
    y: Math.round(box.y),
    w: Math.round(box.width),
    h: Math.round(box.height),
    visible,
    inViewport,
  };
}

async function main() {
  const browser = await chromium.launch();
  const results = [];
  let allOk = true;

  for (const vp of VIEWPORTS) {
    const page = await browser.newPage({ viewport: { width: vp.width, height: vp.height } });
    try {
      await passAgeGateToLobby(page, `M${vp.tag}`);
      await openBetScreen(page);
      const box = await page.getByTestId("bet-confirm").boundingBox();
      const m = measureButton(box, vp.width, vp.height);
      results.push({ viewport: vp.tag, ...m });
      if (!m.ok) allOk = false;
      console.log(`APOSTAR ${vp.tag}: ${m.ok ? "OK" : "FAIL"} ${JSON.stringify(m)}`);
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      results.push({ viewport: vp.tag, ok: false, reason: message });
      allOk = false;
      console.log(`APOSTAR ${vp.tag}: FAIL ${JSON.stringify({ ok: false, reason: message })}`);
    } finally {
      await page.close();
    }
  }

  await browser.close();
  process.exit(allOk ? 0 : 1);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
