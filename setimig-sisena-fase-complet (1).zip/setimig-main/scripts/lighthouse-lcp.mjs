import * as chromeLauncher from "chrome-launcher";
import lighthouse from "lighthouse";

const url = process.env.LH_URL ?? "http://127.0.0.1:4173/";

const chrome = await chromeLauncher.launch({ chromeFlags: ["--headless", "--no-sandbox", "--disable-gpu"] });
try {
  const result = await lighthouse(
    url,
    {
      logLevel: "error",
      output: "json",
      port: chrome.port,
      formFactor: "mobile",
      screenEmulation: { mobile: true, width: 390, height: 844, deviceScaleFactor: 2, disabled: false },
      onlyCategories: ["performance"],
    },
    undefined
  );
  const perf = result.lhr.categories.performance?.score ?? 0;
  const lcp = result.lhr.audits["largest-contentful-paint"]?.numericValue ?? 0;
  console.log(JSON.stringify({ performance: perf, lcp_ms: Math.round(lcp) }, null, 2));
} finally {
  await chrome.kill();
}
