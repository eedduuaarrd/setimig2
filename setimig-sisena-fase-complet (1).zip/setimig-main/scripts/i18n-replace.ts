/**
 * Codemod de substitució de textos catalans per claus i18n (Set i Mig / Seven Half Club).
 *
 *   npx tsx scripts/i18n-replace.ts src/components/AgeGateOverlay.tsx          # dry-run (per defecte)
 *   npx tsx scripts/i18n-replace.ts --write src/components/AgeGateOverlay.tsx  # aplica canvis
 *   npx tsx scripts/i18n-replace.ts --write --literals src/lib/matchUi.ts      # també literals JS
 *
 * Què fa:
 *  - Text JSX exacte (>Juga ara<) -> >{t("lobby.playNow")}<
 *  - Atributs aria-label/title/placeholder/alt="..." -> aria-label={t("...")}
 *  - Amb --literals: "..." / '...' / `...` (sense ${}) -> t("...")  (revisa'ls: si són constants
 *    de mòdul s'avaluen un sol cop i no canviarien d'idioma; cal moure'ls dins d'una funció).
 *  - Afegeix `import { t } from ".../i18n/index.ts";` si cal.
 * Només substitueix textos sense placeholders ({x}) ni negretes (**); la resta la llista per fer-la a mà.
 * No toca className, estructura ni estils. Si un text té diverses claus, tria la primera i ho avisa.
 */
import { readFileSync, writeFileSync } from "node:fs";
import { dirname, relative, resolve } from "node:path";
import { ca } from "../src/i18n/locales/ca.ts";

const args = process.argv.slice(2);
const write = args.includes("--write");
const literals = args.includes("--literals");
const files = args.filter((a) => !a.startsWith("--") && !/\.test\.tsx?$/.test(a));
if (files.length === 0) {
  console.error("Ús: npx tsx scripts/i18n-replace.ts [--write] [--literals] <fitxers...>");
  process.exit(1);
}

const byText = new Map<string, string[]>();
(function walk(node: unknown, prefix: string) {
  for (const [k, v] of Object.entries(node as Record<string, unknown>)) {
    const key = prefix ? `${prefix}.${k}` : k;
    if (typeof v === "string") {
      if (!/\{\w+\}|\*\*/.test(v)) byText.set(v, [...(byText.get(v) ?? []), key]);
    } else if (v && typeof v === "object" && !("other" in v)) walk(v, key);
  }
})(ca, "");

const decode = (s: string) => s.replace(/&apos;|&#39;/g, "'").replace(/&quot;/g, '"').replace(/&amp;/g, "&").replace(/\s+/g, " ").trim();
const ambiguous = new Set<string>();
function keyFor(text: string): string | undefined {
  const keys = byText.get(decode(text));
  if (keys && keys.length > 1) ambiguous.add(`${decode(text)} -> ${keys.join(", ")}`);
  return keys ? [...keys].sort((a, b) => rank(a) - rank(b))[0] : undefined;
}
/** Preferència quan un text té diverses claus: marca visible > comuns > la resta (manifest/seo mai a JSX). */
function rank(key: string): number {
  if (key === "brand.name") return 0;
  if (key.startsWith("common.")) return 1;
  if (key.startsWith("manifest.") || key.startsWith("seo.")) return 9;
  return 5;
}

let total = 0;
for (const file of files) {
  const path = resolve(file);
  const original = readFileSync(path, "utf8");
  const changes: string[] = [];
  let src = original.replace(/(\s(?:aria-label|title|placeholder|alt))="([^"{}]+)"/g, (m, attr: string, text: string) => {
    const key = keyFor(text);
    if (!key) return m;
    changes.push(`attr  ${attr.trim()}="${text}" -> ${key}`);
    return `${attr}={t("${key}")}`;
  });
  src = src.replace(/>(\s*)([^<>{}]*?[\p{L}][^<>{}]*?)(\s*)</gu, (m, pre: string, text: string, post: string) => {
    const key = keyFor(text);
    if (!key) return m;
    changes.push(`jsx   ${decode(text)} -> ${key}`);
    return `>${pre}{t("${key}")}${post}<`;
  });
  if (literals) {
    src = src.replace(/(^|[^\w.])(["'`])((?:(?!\2)[^\\\n$]|\\.)+)\2/gm, (m, lead: string, _q: string, text: string, offset: number) => {
      const lineStart = src.lastIndexOf("\n", offset) + 1;
      const line = src.slice(lineStart, src.indexOf("\n", offset) === -1 ? undefined : src.indexOf("\n", offset));
      if (/^\s*(import|export\s+\*|\/\/|\*)/.test(line) || /from\s+["']/.test(line) || /className=|data-testid=/.test(line)) return m;
      // Comparacions amb textos del motor/servidor: no es tradueixen (són dades, no UI).
      if (/(===|!==|case|startsWith\(|includes\()\s*$/.test(src.slice(lineStart, offset + lead.length))) return m;
      const key = keyFor(text.replace(/\\'/g, "'"));
      if (!key) return m;
      changes.push(`lit   ${text} -> ${key}`);
      // Atribut JSX (label="...") -> label={t("...")}
      if (lead === "=" && /\w$/.test(src.slice(lineStart, offset))) return `={t("${key}")}`;
      return `${lead}t("${key}")`;
    });
  }
  if (changes.length && !/from\s+["'][./]*.*i18n\/index(\.ts)?["']/.test(src)) {
    let rel = relative(dirname(path), resolve("src/i18n/index.ts")).replace(/\\/g, "/");
    if (!rel.startsWith(".")) rel = `./${rel}`;
    const importLine = `import { t } from "${rel}";\n`;
    const lastImport = [...src.matchAll(/^import[^;]*;\s*$/gm)].pop();
    src = lastImport ? src.slice(0, lastImport.index! + lastImport[0].length) + "\n" + importLine.trimEnd() + src.slice(lastImport.index! + lastImport[0].length) : importLine + src;
  }
  const leftovers = [...src.matchAll(/>\s*([^<>{}]*[àèéíòóúç·][^<>{}]*)\s*</gu)].map((m) => decode(m[1]!)).filter(Boolean);
  total += changes.length;
  console.log(`\n# ${file}: ${changes.length} substitucions${write ? "" : " (dry-run)"}`);
  for (const c of changes) console.log(`  ${c}`);
  if (leftovers.length) console.log(`  ! textos JSX encara literals (revisar a mà): ${leftovers.slice(0, 10).join(" | ")}`);
  if (write && src !== original) writeFileSync(path, src);
}
if (ambiguous.size) console.log(`\nTextos amb diverses claus (s'ha triat la preferent):\n  ${[...ambiguous].join("\n  ")}`);
console.log(`\nTotal: ${total} substitucions${write ? " aplicades" : " proposades (usa --write per aplicar)"}.`);
