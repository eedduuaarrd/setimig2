import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import net from "node:net";
import os from "node:os";
import path from "node:path";
import { main } from "./purge-test-players.ts";

const ROOT = path.join(process.cwd(), "data", `purga-test-${Date.now()}`);
const A = "aaaaaaaa-test-0001";
const B = "bbbbbbbb-test-0002";
const KEEP = "cccccccc-real-0003";

function write(rel: string, data: unknown) {
  const file = path.join(ROOT, "data", rel);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function seed() {
  fs.rmSync(path.join(ROOT, "data"), { recursive: true, force: true });
  write("balances.json", { accounts: { [A]: { chips: 100 }, [B]: { chips: 200 }, [KEEP]: { chips: 300 } }, processedSessions: [] });
  for (const id of [A, B, KEEP]) {
    write(`profiles/${id}.json`, { displayName: id === KEEP ? "Real" : `Test ${id.slice(0, 1)}`, updatedAt: 1 });
    write(`player-stats/${id}.json`, { version: 1, aggregate: {}, hands: [], matches: [] });
  }
  write(`player-engagement/${A}.json`, { version: 1 });
  write(`campaign-progress/${B}.json`, { version: 1 });
  write("weekly-leaderboard/2026-W44.json", { version: 1, chipsWon: { [A]: 50, [KEEP]: 70 } });
  write("friends.json", {
    players: {
      [A]: { friendCode: "FAAAAAA", friendPlayerIds: [KEEP] },
      [KEEP]: { friendCode: "FKKKKKK", friendPlayerIds: [A, B] },
    },
    friendCodeIndex: { FAAAAAA: A, FKKKKKK: KEEP },
  });
  write("private-rooms.json", { rooms: { r1: { inviteCode: "ABC123", players: [{ playerId: B }] } }, inviteIndex: {} });
}

function snapshot(): Record<string, string> {
  const out: Record<string, string> = {};
  const walk = (dir: string) => {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const p = path.join(dir, e.name);
      if (e.isDirectory()) walk(p);
      else out[path.relative(ROOT, p)] = fs.readFileSync(p, "utf8");
    }
  };
  walk(path.join(ROOT, "data"));
  return out;
}

async function freePort(): Promise<number> {
  const srv = net.createServer();
  await new Promise<void>((r) => srv.listen(0, "127.0.0.1", () => r()));
  const port = (srv.address() as net.AddressInfo).port;
  await new Promise<void>((r) => srv.close(() => r()));
  return port;
}

async function run(args: string[]): Promise<{ code: number; out: string }> {
  const lines: string[] = [];
  const code = await main(
    [
      ...args,
      "--data-dir",
      path.join(ROOT, "data"),
      "--profiles-dir",
      path.join(ROOT, "data", "profiles"),
      "--friends-dir",
      path.join(ROOT, "data"),
      "--service",
      "none",
    ],
    (s) => lines.push(s)
  );
  return { code, out: lines.join("\n") };
}

/** Fora de /tmp: si el cwd és sota /tmp, una còpia a ROOT/backups es rebutja (codi 4). */
function backupDir(name: string): string {
  const dir = path.join(os.homedir(), "setimig-purga-test", path.basename(ROOT), name);
  fs.mkdirSync(path.dirname(dir), { recursive: true });
  return dir;
}

const readJ = (rel: string) => JSON.parse(fs.readFileSync(path.join(ROOT, "data", rel), "utf8"));

describe("scripts/purge-test-players", () => {
  before(() => fs.mkdirSync(ROOT, { recursive: true }));
  after(() => {
    fs.rmSync(ROOT, { recursive: true, force: true });
    fs.rmSync(path.join(os.homedir(), "setimig-purga-test", path.basename(ROOT)), { recursive: true, force: true });
  });

  it("per defecte només simula i llista tots els magatzems", async () => {
    seed();
    const before = snapshot();
    const { code, out } = await run([A, B, "--port", String(await freePort())]);
    assert.equal(code, 0);
    assert.deepEqual(snapshot(), before, "la simulació no toca res");
    for (const s of ["perfil", "estadístiques", "assoliments/missions", "campanya", "saldo", "rànquing 2026-W44", "amics", "ABC123", "SIMULACIÓ"]) {
      assert.ok(out.includes(s), `falta «${s}» a la sortida:\n${out}`);
    }
  });

  it("--apply fa còpia i esborra només els ids indicats", async () => {
    seed();
    const before = snapshot();
    const backup = backupDir("b1");
    fs.writeFileSync(path.join(ROOT, "ids.txt"), `${A}  # Test A\n\n${B}\n`);
    const { code, out } = await run(["--file", path.join(ROOT, "ids.txt"), "--apply", "--backup-dir", backup, "--port", String(await freePort())]);
    assert.equal(code, 0, out);
    const manifest = JSON.parse(fs.readFileSync(path.join(backup, "manifest.json"), "utf8"));
    assert.deepEqual(manifest.ids, [A, B]);
    for (const f of manifest.files) {
      assert.equal(fs.readFileSync(f.to, "utf8"), before[path.relative(ROOT, f.from)], `còpia fidel de ${f.from}`);
    }
    assert.deepEqual(Object.keys(readJ("balances.json").accounts), [KEEP]);
    assert.deepEqual(readJ("weekly-leaderboard/2026-W44.json").chipsWon, { [KEEP]: 70 });
    const friends = readJ("friends.json");
    assert.deepEqual(Object.keys(friends.players), [KEEP]);
    assert.deepEqual(friends.players[KEEP].friendPlayerIds, []);
    assert.deepEqual(friends.friendCodeIndex, { FKKKKKK: KEEP });
    for (const rel of [`profiles/${A}.json`, `profiles/${B}.json`, `player-stats/${A}.json`, `player-engagement/${A}.json`, `campaign-progress/${B}.json`]) {
      assert.equal(fs.existsSync(path.join(ROOT, "data", rel)), false, rel);
    }
    assert.ok(fs.existsSync(path.join(ROOT, "data", `profiles/${KEEP}.json`)));
    assert.ok(fs.existsSync(path.join(ROOT, "data", `player-stats/${KEEP}.json`)));
    assert.equal(snapshot()["data/private-rooms.json"], before["data/private-rooms.json"], "taules privades intactes");
  });

  it("--apply s'atura si el servidor sembla en marxa, llevat de --force", async () => {
    seed();
    const before = snapshot();
    const srv = net.createServer((s) => s.end());
    await new Promise<void>((r) => srv.listen(0, "127.0.0.1", () => r()));
    const port = String((srv.address() as net.AddressInfo).port);
    try {
      const blocked = await run([A, "--apply", "--backup-dir", backupDir("b2"), "--port", port]);
      assert.equal(blocked.code, 3);
      assert.deepEqual(snapshot(), before);
      assert.equal(fs.existsSync(backupDir("b2")), false);
      const forced = await run([A, "--apply", "--force", "--backup-dir", backupDir("b3"), "--port", port]);
      assert.equal(forced.code, 0, forced.out);
      assert.deepEqual(Object.keys(readJ("balances.json").accounts).sort(), [B, KEEP].sort());
    } finally {
      await new Promise<void>((r) => srv.close(() => r()));
    }
  });

  it("no accepta còpies a /tmp ni ids no vàlids", async () => {
    seed();
    const before = snapshot();
    const tmp = await run([A, "--apply", "--backup-dir", path.join(os.tmpdir(), "purga-x"), "--port", String(await freePort())]);
    assert.equal(tmp.code, 4);
    assert.deepEqual(snapshot(), before);
    const bad = await run(["../../etc/passwd"]);
    assert.equal(bad.code, 2);
    assert.deepEqual(snapshot(), before);
  });

  it("--find-name-prefix llista ids per nom sense tocar res", async () => {
    seed();
    const before = snapshot();
    const { code, out } = await run(["--find-name-prefix", "Test "]);
    assert.equal(code, 0);
    assert.ok(out.includes(A) && out.includes(B) && !out.includes(KEEP));
    assert.deepEqual(snapshot(), before);
  });
});
