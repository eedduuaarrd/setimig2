#!/usr/bin/env python3
"""v163 · logo de la splash + startup images d'iOS (Pillow, eina de màquina; no és dependència npm).

El fum de logo-fum-512.png tenia talls rectes a dalt i a baix (el núvol original estava retallat
pel llenç); v162 només esvaïa les vores del llenç, no el núvol. Aquí el halo daurat es genera de nou
a partir de la silueta de les cartes (logo-net-cartes-512.webp), difuminat, sobre un llenç de 768
amb una caiguda radial que arriba a alpha 0 molt abans de les vores en totes direccions.

Mida: les cartes ocupen min(45vw, 30vh) (= --logo-cards a CSS). Les cartes són 395/768 del llenç.
"""
import json, re, sys
from pathlib import Path
import numpy as np
from PIL import Image, ImageFilter

ROOT = Path(__file__).resolve().parent.parent
PUB = ROOT / "public"
C = 768
CARDS_FRAC = 395 / C  # amplada de les cartes dins el llenç

def logo():
    net = Image.open(PUB / "brand/logo-net-cartes-512.webp").convert("RGBA")
    a = net.split()[3]
    mask = Image.new("L", (C, C), 0); mask.paste(a, (128, 128))
    glow = mask.filter(ImageFilter.MaxFilter(9)).filter(ImageFilter.GaussianBlur(46))
    g = np.asarray(glow).astype(np.float32) / 255.0
    yy, xx = np.mgrid[0:C, 0:C].astype(np.float32)
    r = np.hypot(xx - C / 2, yy - C / 2) / (C / 2)
    fall = np.clip((0.92 - r) / 0.30, 0, 1); fall = fall * fall * (3 - 2 * fall)  # 0 a r≥0.92
    alpha = np.clip(g * 1.25, 0, 1) * fall * 0.78
    out = np.zeros((C, C, 4), np.float32)
    out[..., 0], out[..., 1], out[..., 2] = 176, 140, 78
    out[..., 3] = alpha * 255
    base = Image.fromarray(out.astype(np.uint8), "RGBA")
    base.alpha_composite(net, (128, 128))
    return base

def main():
    lg = logo()
    lg.save(PUB / "brand/logo-splash-v163.png", optimize=True)
    html = (ROOT / "index.html").read_text()
    sizes = sorted(set(re.findall(r"apple-splash-v163-(\d+)-(\d+)\.png", html)))
    out = PUB / "splash"
    for w, h in sizes:
        W, H = int(w), int(h)
        cards = min(0.45 * W, 0.30 * H)
        s = round(cards / CARDS_FRAC)
        im = Image.new("RGBA", (W, H), (14, 15, 12, 255))
        im.alpha_composite(lg.resize((s, s), Image.LANCZOS), ((W - s) // 2, (H - s) // 2))
        im.convert("RGB").save(out / f"apple-splash-v163-{W}-{H}.png", optimize=True)
    print(len(sizes), "startup images")

if __name__ == "__main__":
    main()
