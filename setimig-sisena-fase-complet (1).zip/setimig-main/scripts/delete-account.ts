/**
 * Esborrat oficial d'un compte per playerId (administració). Fa servir la MATEIXA funció que
 * l'endpoint POST /api/account/delete (server/accountDeletion.ts), que passa per les funcions de
 * persistència de cada magatzem: mai edita els JSON pel seu compte.
 *
 *   npx tsx scripts/delete-account.ts <playerId> [<playerId> ...]          # SIMULACIÓ (per defecte)
 *   npx tsx scripts/delete-account.ts <playerId> --apply                    # esborra de debò
 *   npx tsx scripts/delete-account.ts --find "<text>"                       # busca playerIds (només lectura)
 *
 * Opcions:
 *   --apply             Esborra. Abans copia tots els fitxers afectats amb sha256 (manifest.json) a
 *                       ~/setimig-backups/esborrat-compte-<data>/ i en verifica el sha256.
 *   --find TEXT         Busca (sense escriure res) per correu verificat a identities.json (exacte o
 *                       part, sense majúscules) i per nom de perfil (part). Mostra playerId, nom i
 *                       correu emmascarat.
 *   --data-dir DIR      Per defecte BALANCE_DATA_DIR o ./data
 *   --profiles-dir DIR  Per defecte PROFILE_DATA_DIR o <data-dir>/profiles
 *   --env-file FILE     Carrega l'env del servei (p. ex. ~/setimig/.env: BALANCE_DATA_DIR, sal de
 *                       l'analítica…) dins del procés ABANS de resoldre els directoris. No s'imprimeix mai.
 *   --backup-dir DIR    On va la còpia (mai a /tmp si les dades no hi són)
 *   --port N            Port del servidor per detectar si està en marxa (PORT o 4450; 0 = no comprovar)
 *   --service NOM       Servei systemd --user (setimig; «none» per no comprovar-ho)
 *
 * Amb el servidor en marxa NO fa --apply (les dades són a memòria i les tornaria a escriure):
 * atura'l abans (systemctl --user stop setimig) o fes servir l'endpoint des de la UI.
 */
import { createHash } from "node:crypto";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { serverLooksRunning } from "./purge-test-players.ts";

const PLAYER_ID_RE = /^[a-zA-Z0-9_-]{8,64}$/;

export type DeleteOptions = {
  ids: string[];
  apply: boolean;
  find: string | null;
  dataDir: string;
  profilesDir: string;
  envFile: string | null;
  backupDir: string | null;
  port: number;
  service: string | null;
};

export function parseArgs(argv: string[], env: NodeJS.ProcessEnv = process.env): DeleteOptions {
  const ids: string[] = [];
  let apply = false;
  let find: string | null = null;
  let dataDir: string | null = null;
  let profilesDir: string | null = null;
  let envFile: string | null = null;
  let backupDir: string | null = null;
  let port = Number(env.PORT) || 4450;
  let service: string | null = "setimig";
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]!;
    const next = () => {
      const v = argv[++i];
      if (v === undefined) throw new Error(`Falta el valor de ${a}`);
      return v;
    };
    if (a === "--apply") apply = true;
    else if (a === "--dry-run") apply = false;
    else if (a === "--find") find = next();
    else if (a === "--data-dir") dataDir = next();
    else if (a === "--profiles-dir") profilesDir = next();
    else if (a === "--env-file") envFile = next();
    else if (a === "--backup-dir") backupDir = next();
    else if (a === "--port") port = Number(next());
    else if (a === "--service") service = next();
    else if (a.startsWith("--")) throw new Error(`Opció desconeguda: ${a}`);
    else ids.push(a);
  }
  const bad = ids.filter((id) => !PLAYER_ID_RE.test(id));
  if (bad.length) throw new Error(`Ids no vàlids: ${bad.join(", ")}`);
  const resolvedData = path.resolve(dataDir ?? env.BALANCE_DATA_DIR ?? path.join(process.cwd(), "data"));
  return {
    ids: [...new Set(ids)],
    apply,
    find,
    dataDir: resolvedData,
    profilesDir: path.resolve(profilesDir ?? env.PROFILE_DATA_DIR ?? path.join(resolvedData, "profiles")),
    envFile: envFile ? path.resolve(envFile) : null,
    backupDir: backupDir ? path.resolve(backupDir) : null,
    port,
    service: service === "none" ? null : service,
  };
}

function sha256(file: string): string {
  return createHash("sha256").update(fs.readFileSync(file)).digest("hex");
}

function isUnder(p: string, root: string): boolean {
  return p === root || p.startsWith(root + path.sep);
}

/** Còpia de tots els fitxers afectats + manifest amb sha256; verifica cada còpia. */
export function backupFiles(files: string[], backupDir: string, ids: string[]): { dir: string; count: number } {
  fs.mkdirSync(backupDir, { recursive: true });
  const manifest: { ids: string[]; at: string; files: { from: string; to: string; sha256: string; bytes: number }[] } = {
    ids,
    at: new Date().toISOString(),
    files: [],
  };
  files.forEach((from, i) => {
    const to = path.join(backupDir, `${String(i).padStart(3, "0")}-${path.basename(path.dirname(from))}-${path.basename(from)}`);
    fs.copyFileSync(from, to);
    const h = sha256(from);
    if (sha256(to) !== h) throw new Error(`Còpia incorrecta (sha256): ${from}`);
    manifest.files.push({ from, to, sha256: h, bytes: fs.statSync(to).size });
  });
  fs.writeFileSync(path.join(backupDir, "manifest.json"), JSON.stringify(manifest, null, 2), "utf8");
  return { dir: backupDir, count: files.length };
}

function maskEmail(email: string): string {
  const [user = "", domain = ""] = email.split("@");
  return `${user.slice(0, 1)}***@${domain}`;
}

/** Només lectura: playerIds per correu verificat o nom de perfil. */
export function findAccounts(text: string, dataDir: string, profilesDir: string): { playerId: string; name: string | null; via: string }[] {
  const q = text.trim().toLowerCase();
  if (!q) return [];
  const out = new Map<string, { playerId: string; name: string | null; via: string }>();
  const nameOf = (id: string): string | null => {
    try {
      const n = JSON.parse(fs.readFileSync(path.join(profilesDir, `${id}.json`), "utf8"))?.displayName;
      return typeof n === "string" ? n : null;
    } catch {
      return null;
    }
  };
  try {
    const ids = JSON.parse(fs.readFileSync(path.join(dataDir, "identities.json"), "utf8"));
    for (const [email, pid] of Object.entries(ids?.emails ?? {})) {
      if (typeof pid === "string" && email.toLowerCase().includes(q)) {
        out.set(pid, { playerId: pid, name: nameOf(pid), via: `correu ${maskEmail(email)}` });
      }
    }
  } catch {
    /* sense identities.json */
  }
  if (fs.existsSync(profilesDir)) {
    for (const f of fs.readdirSync(profilesDir).filter((x) => x.endsWith(".json"))) {
      const id = f.slice(0, -5);
      const name = nameOf(id);
      if (name && name.toLowerCase().includes(q) && !out.has(id)) out.set(id, { playerId: id, name, via: "nom de perfil" });
    }
  }
  return [...out.values()].sort((a, b) => a.playerId.localeCompare(b.playerId));
}

export async function main(argv: string[], log: (s: string) => void = console.log): Promise<number> {
  // L'env del servei primer (pot definir BALANCE_DATA_DIR, la sal de l'analítica…); mai s'imprimeix.
  const envIdx = argv.indexOf("--env-file");
  if (envIdx >= 0 && argv[envIdx + 1]) {
    try {
      process.loadEnvFile(path.resolve(argv[envIdx + 1]!));
    } catch {
      log(`Error: no s'ha pogut llegir --env-file ${argv[envIdx + 1]}`);
      return 2;
    }
  }
  let opts: DeleteOptions;
  try {
    opts = parseArgs(argv);
  } catch (err) {
    log(`Error: ${(err as Error).message}`);
    return 2;
  }
  if (opts.find !== null) {
    const found = findAccounts(opts.find, opts.dataDir, opts.profilesDir);
    for (const f of found) log(`${f.playerId}\t${f.name ?? "(sense perfil)"}\t${f.via}`);
    log(`# ${found.length} comptes per «${opts.find}» (només lectura)`);
    return 0;
  }
  if (!opts.ids.length) {
    log("Cal almenys un playerId. Per defecte només simula; --apply per esborrar.");
    return 2;
  }
  // Les dades d'aquest script, no les de cap altre lloc (el servidor fa servir les mateixes variables).
  process.env.BALANCE_DATA_DIR = opts.dataDir;
  process.env.PROFILE_DATA_DIR = opts.profilesDir;
  if (!process.env.FRIENDS_DATA_DIR) process.env.FRIENDS_DATA_DIR = opts.dataDir;
  process.env.SETIMIG_WRITE_COALESCE_MS = "0";

  const { inspectAccount, deleteAccount } = await import("../server/accountDeletion.ts");
  const { flushAllPendingWrites } = await import("../server/writeCoalescing.ts");

  const invs = [];
  for (const id of opts.ids) {
    const inv = await inspectAccount(id);
    invs.push(inv);
    log(`Compte ${id}${inv.displayName ? ` («${inv.displayName}»)` : ""}${inv.alreadyDeleted ? " — JA ESBORRAT" : ""}`);
    for (const it of inv.items) log(`  esborrar: ${it}`);
    for (const it of inv.info) log(`  info: ${it}`);
    if (!inv.items.length) log("  (no hi ha dades)");
  }
  const running =
    opts.port > 0 ? await serverLooksRunning(opts.port, opts.service) : opts.service ? await serverLooksRunning(1, opts.service) : null;
  if (!opts.apply) {
    if (running) log(`AVÍS: sembla que el servidor està en marxa (${running}); per aplicar-ho cal aturar-lo.`);
    log("SIMULACIÓ: no s'ha esborrat res. Afegeix --apply per esborrar.");
    return 0;
  }
  if (running) {
    log(`ABORTAT: sembla que el servidor està en marxa (${running}). Atura'l (systemctl --user stop setimig) o fes servir l'endpoint. No s'ha escrit res.`);
    return 3;
  }
  const files = [...new Set(invs.flatMap((i) => i.files))];
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const backupDir = opts.backupDir ?? path.join(os.homedir(), "setimig-backups", `esborrat-compte-${stamp}`);
  const tmpRoots = [...new Set([path.resolve("/tmp"), path.resolve(os.tmpdir())])];
  if (tmpRoots.some((r) => isUnder(backupDir, r)) && !tmpRoots.some((r) => isUnder(opts.dataDir, r))) {
    log(`ABORTAT: la còpia no pot anar a /tmp (${backupDir}). No s'ha escrit res.`);
    return 4;
  }
  try {
    const b = backupFiles(files, backupDir, opts.ids);
    log(`Còpia (sha256 verificat) de ${b.count} fitxers a ${b.dir}`);
  } catch (err) {
    log(`ABORTAT: no s'ha pogut fer la còpia (${(err as Error).message}). No s'ha esborrat res.`);
    return 4;
  }
  for (const id of opts.ids) {
    const r = await deleteAccount(id);
    log(`Esborrat ${id}${r.newlyDeleted ? "" : " (ja ho estava; repassat)"}: ${JSON.stringify({ ...r, playerId: undefined })}`);
  }
  await flushAllPendingWrites();
  let leftovers = 0;
  for (const id of opts.ids) {
    const after = await inspectAccount(id);
    leftovers += after.items.length;
    if (after.items.length) log(`  QUEDA de ${id}: ${after.items.join("; ")}`);
  }
  log(leftovers ? "ATENCIÓ: han quedat dades (vegeu a dalt)." : "Fet: no queda cap dada dels comptes indicats.");
  return leftovers ? 5 : 0;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main(process.argv.slice(2)).then((code) => process.exit(code));
}
