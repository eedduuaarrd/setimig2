"""Genera les apple-touch-startup-image = fotograma 0 de la intro (#312): fons pla #0E0F0C, sense cartes ni aura.
Ús: python3 scripts/splash-fotograma0.py (llegeix les mides de public/splash/*.png)."""
import glob, re
from PIL import Image
for p in sorted(glob.glob("public/splash/apple-splash-v180-*.png")):
    w, h = map(int, re.search(r"-(\d+)-(\d+)\.png$", p).groups())
    Image.new("RGB", (w, h), (0x0E, 0x0F, 0x0C)).save(p, optimize=True)
    print(p, w, h)
