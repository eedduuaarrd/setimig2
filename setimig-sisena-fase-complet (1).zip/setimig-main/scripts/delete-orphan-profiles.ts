/**
 * Esborra perfils (i dades associades) sense compte verificat (correu / Google / passkey).
 * Fa servir la mateixa `deleteAccount` que scripts/delete-account.ts i el mateix criteri
 * que `playerHasAccount` / `accountPlayerIdsFromStore` (data/identities.json).
 *
 *   npx tsx scripts/delete-orphan-profiles.ts                         # SIMULACIÓ
 *   npx tsx scripts/delete-orphan-profiles.ts --apply                 # esborra de debò
 *   npx tsx scripts/delete-orphan-profiles.ts --apply --force         # ignora salvaguardes
 *
 * Opcions: --data-dir, --profiles-dir, --env-file, --backup-dir, --port, --service, --force
 * (mateix criteri que delete-account.ts). Amb --apply: còpia sha256 a
 * ~/setimig-backups/esborrat-perfils-sense-compte-<data>/, la verifica, i després esborra.
 * No executar --apply amb el servidor en marxa.
 *
 * Salvaguarda: si hi ha 0 comptes verificats, o si s'esborraria >90% dels candidats,
 * --apply avorta tret que es passi --force (el dry-run només avisa).
 */
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { accountPlayerIdsFromStore } from "../server/auth/identityStore.ts";
import { serverLooksRunning } from "./purge-test-players.ts";
import { backupFiles } from "./delete-account.ts";

export type OrphanOptions = {
  apply: boolean;
  force: boolean;
  dataDir: string;
  profilesDir: string;
  envFile: string | null;
  backupDir: string | null;
  port: number;
  service: string | null;
};

export function parseOrphanArgs(argv: string[], env: NodeJS.ProcessEnv = process.env): OrphanOptions {
  let apply = false;
  let force = false;
  let dataDir: string | null = null;
  let profilesDir: string | null = null;
  let envFile: string | null = null;
  let backupDir: string | null = null;
  let port = Number(env.PORT) || 4450;
  let service: string | null = "setimig";
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]!;
    const next = () => {
      const v = argv[++i];
      if (v === undefined) throw new Error(`Falta el valor de ${a}`);
      return v;
    };
    if (a === "--apply") apply = true;
    else if (a === "--dry-run") apply = false;
    else if (a === "--force") force = true;
    else if (a === "--data-dir") dataDir = next();
    else if (a === "--profiles-dir") profilesDir = next();
    else if (a === "--env-file") envFile = next();
    else if (a === "--backup-dir") backupDir = next();
    else if (a === "--port") port = Number(next());
    else if (a === "--service") service = next();
    else if (a.startsWith("--")) throw new Error(`Opció desconeguda: ${a}`);
    else throw new Error(`Argument inesperat: ${a} (no cal passar playerIds; es detecten sols)`);
  }
  const resolvedData = path.resolve(dataDir ?? env.BALANCE_DATA_DIR ?? path.join(process.cwd(), "data"));
  return {
    apply,
    force,
    dataDir: resolvedData,
    profilesDir: path.resolve(profilesDir ?? env.PROFILE_DATA_DIR ?? path.join(resolvedData, "profiles")),
    envFile: envFile ? path.resolve(envFile) : null,
    backupDir: backupDir ? path.resolve(backupDir) : null,
    port,
    service: service === "none" ? null : service,
  };
}

function readJson(file: string): any | null {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return null;
  }
}

function isRecord(v: unknown): v is Record<string, unknown> {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

/** playerIds amb almenys un correu, Google o passkey (criteri compartit amb requireLogin). */
export function accountPlayerIds(dataDir: string): Set<string> {
  const ids = readJson(path.join(dataDir, "identities.json"));
  return accountPlayerIdsFromStore(ids);
}

function listJsonStems(dir: string): string[] {
  if (!fs.existsSync(dir)) return [];
  return fs
    .readdirSync(dir)
    .filter((f) => f.endsWith(".json"))
    .map((f) => f.slice(0, -5))
    .sort();
}

/**
 * Candidats a orfe: perfils, comptes de saldo, stats, engagement, campanya
 * que no tinguin compte verificat.
 */
export function listOrphanPlayerIds(dataDir: string, profilesDir: string): string[] {
  const accounts = accountPlayerIds(dataDir);
  const candidates = new Set<string>();
  for (const id of listJsonStems(profilesDir)) candidates.add(id);
  const balances = readJson(path.join(dataDir, "balances.json"));
  if (isRecord(balances?.accounts)) {
    for (const id of Object.keys(balances.accounts)) candidates.add(id);
  }
  for (const sub of ["player-stats", "player-engagement", "campaign-progress"]) {
    for (const id of listJsonStems(path.join(dataDir, sub))) candidates.add(id);
  }
  return [...candidates].filter((id) => !accounts.has(id)).sort();
}

/** Quants candidats (perfils + saldos + stats…) hi ha abans de filtrar orfes. */
export function listCandidatePlayerIds(dataDir: string, profilesDir: string): string[] {
  const candidates = new Set<string>();
  for (const id of listJsonStems(profilesDir)) candidates.add(id);
  const balances = readJson(path.join(dataDir, "balances.json"));
  if (isRecord(balances?.accounts)) {
    for (const id of Object.keys(balances.accounts)) candidates.add(id);
  }
  for (const sub of ["player-stats", "player-engagement", "campaign-progress"]) {
    for (const id of listJsonStems(path.join(dataDir, sub))) candidates.add(id);
  }
  return [...candidates].sort();
}

export function orphanSafetyBlock(
  accounts: number,
  orphans: number,
  candidates: number,
): "zero_accounts" | "majority_orphans" | null {
  if (accounts === 0) return "zero_accounts";
  if (candidates > 0 && orphans / candidates > 0.9) return "majority_orphans";
  return null;
}

function isUnder(p: string, root: string): boolean {
  return p === root || p.startsWith(root + path.sep);
}

export async function main(argv: string[], log: (s: string) => void = console.log): Promise<number> {
  const envIdx = argv.indexOf("--env-file");
  if (envIdx >= 0 && argv[envIdx + 1]) {
    try {
      process.loadEnvFile(path.resolve(argv[envIdx + 1]!));
    } catch {
      log(`Error: no s'ha pogut llegir --env-file ${argv[envIdx + 1]}`);
      return 2;
    }
  }
  let opts: OrphanOptions;
  try {
    opts = parseOrphanArgs(argv);
  } catch (err) {
    log(`Error: ${(err as Error).message}`);
    return 2;
  }

  process.env.BALANCE_DATA_DIR = opts.dataDir;
  process.env.PROFILE_DATA_DIR = opts.profilesDir;
  if (!process.env.FRIENDS_DATA_DIR) process.env.FRIENDS_DATA_DIR = opts.dataDir;
  process.env.SETIMIG_WRITE_COALESCE_MS = "0";

  const candidates = listCandidatePlayerIds(opts.dataDir, opts.profilesDir);
  const orphans = listOrphanPlayerIds(opts.dataDir, opts.profilesDir);
  const accounts = accountPlayerIds(opts.dataDir);
  log(`Comptes verificats: ${accounts.size}`);
  log(`Candidats (perfils/saldos/stats…): ${candidates.length}`);
  log(`Perfils/dades sense compte (orfes): ${orphans.length}`);

  const block = orphanSafetyBlock(accounts.size, orphans.length, candidates.length);
  if (block === "zero_accounts") {
    log(
      "AVÍS: 0 comptes verificats a identities.json (emails/google/passkeys/players). " +
        "Si això és inesperat, NO apliquis: revisa el fitxer o restaura una còpia. " +
        "Amb --apply cal --force per continuar.",
    );
  } else if (block === "majority_orphans") {
    const pct = candidates.length ? Math.round((100 * orphans.length) / candidates.length) : 0;
    log(
      `AVÍS: s'esborraria el ${pct}% dels candidats (>90%). ` +
        "Amb --apply cal --force per continuar.",
    );
  }

  const { inspectAccount, deleteAccount } = await import("../server/accountDeletion.ts");
  const { flushAllPendingWrites } = await import("../server/writeCoalescing.ts");

  const invs = [];
  let withChips = 0;
  let withProgress = 0;
  for (const id of orphans) {
    const inv = await inspectAccount(id);
    invs.push(inv);
    const chipItem = inv.items.find((x) => x.startsWith("saldo:"));
    if (chipItem) withChips += 1;
    if (inv.items.some((x) => /estadístiques|assoliments|campanya/.test(x))) withProgress += 1;
    log(`Orfe ${id}${inv.displayName ? ` («${inv.displayName}»)` : ""}${inv.alreadyDeleted ? " — JA ESBORRAT" : ""}`);
    for (const it of inv.items) log(`  esborrar: ${it}`);
    for (const it of inv.info) log(`  info: ${it}`);
    if (!inv.items.length) log("  (no hi ha dades persistents més enllà de la detecció)");
  }
  log(`Resum orfes: ${orphans.length} total, ${withChips} amb fitxes, ${withProgress} amb historial/progrés`);

  const running =
    opts.port > 0 ? await serverLooksRunning(opts.port, opts.service) : opts.service ? await serverLooksRunning(1, opts.service) : null;

  if (!opts.apply) {
    if (running) log(`AVÍS: sembla que el servidor està en marxa (${running}); per aplicar-ho cal aturar-lo.`);
    log("SIMULACIÓ: no s'ha esborrat res. Afegeix --apply per esborrar (amb còpia sha256).");
    return 0;
  }
  if (!orphans.length) {
    log("Res a esborrar.");
    return 0;
  }
  if (block && !opts.force) {
    log(
      `ABORTAT: salvaguarda (${block}). Passa --force si n'estàs segur. No s'ha escrit res.`,
    );
    return 6;
  }
  if (running) {
    log(`ABORTAT: sembla que el servidor està en marxa (${running}). Atura'l abans. No s'ha escrit res.`);
    return 3;
  }
  const files = [...new Set(invs.flatMap((i) => i.files))];
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const backupDir =
    opts.backupDir ?? path.join(os.homedir(), "setimig-backups", `esborrat-perfils-sense-compte-${stamp}`);
  const tmpRoots = [...new Set([path.resolve("/tmp"), path.resolve(os.tmpdir())])];
  if (tmpRoots.some((r) => isUnder(backupDir, r)) && !tmpRoots.some((r) => isUnder(opts.dataDir, r))) {
    log(`ABORTAT: la còpia no pot anar a /tmp (${backupDir}). No s'ha escrit res.`);
    return 4;
  }
  try {
    const b = backupFiles(files, backupDir, orphans);
    log(`Còpia (sha256 verificat) de ${b.count} fitxers a ${b.dir}`);
  } catch (err) {
    log(`ABORTAT: no s'ha pogut fer la còpia (${(err as Error).message}). No s'ha esborrat res.`);
    return 4;
  }
  for (const id of orphans) {
    const r = await deleteAccount(id);
    log(`Esborrat ${id}${r.newlyDeleted ? "" : " (ja ho estava; repassat)"}`);
  }
  await flushAllPendingWrites();
  const left = listOrphanPlayerIds(opts.dataDir, opts.profilesDir);
  if (left.length) {
    log(`ATENCIÓ: encara queden ${left.length} orfes: ${left.slice(0, 10).join(", ")}${left.length > 10 ? "…" : ""}`);
    return 5;
  }
  log("Fet: no queda cap perfil/dada sense compte de la llista detectada.");
  return 0;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main(process.argv.slice(2)).then((code) => process.exit(code));
}
