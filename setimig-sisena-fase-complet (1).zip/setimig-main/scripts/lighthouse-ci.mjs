import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import * as chromeLauncher from "chrome-launcher";
import lighthouse from "lighthouse";

const PREVIEW_URL = process.env.LH_URL ?? "http://127.0.0.1:4173/";
const MIN_PERF = Number(process.env.LH_MIN_PERF ?? "0.9");
const MIN_A11Y = Number(process.env.LH_MIN_A11Y ?? "0.95");

function waitForUrl(url, timeoutMs = 60_000) {
  const start = Date.now();
  return new Promise((resolve, reject) => {
    const tick = async () => {
      try {
        const res = await fetch(url);
        if (res.ok) return resolve(undefined);
      } catch {
        /* retry */
      }
      if (Date.now() - start > timeoutMs) {
        reject(new Error(`Timeout waiting for ${url}`));
        return;
      }
      setTimeout(tick, 500);
    };
    tick();
  });
}

function runProdServer() {
  return spawn("npx", ["cross-env", "NODE_ENV=production", "PORT=4173", "tsx", "server.ts"], {
    stdio: "inherit",
    shell: true,
  });
}

async function runAudit(chrome, url) {
  return lighthouse(
    url,
    {
      logLevel: "error",
      output: "json",
      onlyCategories: ["performance", "accessibility"],
      port: chrome.port,
      formFactor: "mobile",
      screenEmulation: { mobile: true, width: 390, height: 844, deviceScaleFactor: 2, disabled: false },
      throttlingMethod: "simulate",
      throttling: {
        rttMs: 40,
        throughputKbps: 10240,
        cpuSlowdownMultiplier: 1,
        requestLatencyMs: 0,
        downloadThroughputKbps: 0,
        uploadThroughputKbps: 0,
      },
    },
    undefined
  );
}

async function main() {
  let preview = null;
  try {
    await waitForUrl(PREVIEW_URL);
  } catch {
    preview = runProdServer();
    await waitForUrl(PREVIEW_URL);
  }
  try {
    await fetch(PREVIEW_URL);
    const chrome = await chromeLauncher.launch({ chromeFlags: ["--headless", "--no-sandbox"] });
    try {
      await runAudit(chrome, PREVIEW_URL);
      const result = await runAudit(chrome, PREVIEW_URL);
      const perf = result.lhr.categories.performance?.score ?? 0;
      const a11y = result.lhr.categories.accessibility?.score ?? 0;
      console.log(JSON.stringify({ performance: perf, accessibility: a11y }, null, 2));
      assert.ok(perf >= MIN_PERF, `Performance ${perf} < ${MIN_PERF}`);
      assert.ok(a11y >= MIN_A11Y, `Accessibility ${a11y} < ${MIN_A11Y}`);
    } finally {
      await chrome.kill();
    }
  } finally {
    preview.kill("SIGTERM");
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
