/**
 * Restauració de saldos a partir d'una llista explícita (p. ex. scripts/restauracions/<rid>.json).
 *
 *   npx tsx scripts/restore-balances.ts [--list FITXER]                 # SIMULACIÓ (per defecte, no escriu res)
 *   npx tsx scripts/restore-balances.ts [--list FITXER] --apply         # aplica (servei aturat)
 *   npx tsx scripts/restore-balances.ts [--list FITXER] --rollback      # desfà una restauració aplicada
 *
 * Opcions:
 *   --list FITXER     Llista JSON { rid, entries: [{ playerId, expectedCurrent, increment, reason }] }
 *                     (per defecte scripts/restauracions/2026-10-27-saldos-v1.json)
 *   --data-dir DIR    Directori amb balances.json (per defecte BALANCE_DATA_DIR o ./data). Per provar
 *                     sobre una còpia.
 *   --backup-dir DIR  On es desa la còpia de balances.json abans d'escriure
 *                     (per defecte ~/setimig-backups/restore-<rid>-<data>; mai a /tmp si les dades no hi són)
 *   --port N          Port del servidor per detectar si està en marxa (PORT o 4450)
 *   --service NOM     Servei systemd --user (setimig; «none» per no comprovar-ho)
 *   --service-dir DIR Directori de treball del servei (per defecte el que digui systemd, o ~/setimig)
 *
 * Seguretat:
 * - --apply i --rollback es neguen si el servidor sembla en marxa i el directori de dades és el del
 *   servei: el servidor té balances.json en memòria i trepitjaria l'escriptura.
 * - Cada entrada és un increment sobre el saldo actual, només si el saldo actual és exactament
 *   `expectedCurrent` (si alguna entrada no quadra, no s'escriu res de res).
 * - Marca idempotent a processedSessions: `restore:<rid>:<playerId>` (desfer: `restore-rollback:…`).
 *   Una segona execució no fa res i ho diu.
 * - Abans d'escriure es desa una còpia de balances.json; després es comprova que la resta de
 *   comptes són idèntics.
 */
import fs from "node:fs";
import net from "node:net";
import os from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { fileURLToPath } from "node:url";

const PLAYER_ID_RE = /^[a-zA-Z0-9_-]{8,64}$/;
const RID_RE = /^[a-zA-Z0-9._-]{3,64}$/;
const SCRIPT_DIR = path.dirname(fileURLToPath(import.meta.url));
const DEFAULT_LIST = path.join(SCRIPT_DIR, "restauracions", "2026-10-27-saldos-v1.json");

export type Mode = "dry-run" | "apply" | "rollback";

export type RestoreEntry = { playerId: string; expectedCurrent: number; increment: number; reason: string };
export type RestoreList = { rid: string; entries: RestoreEntry[] };

export type RestoreOptions = {
  mode: Mode;
  listFile: string;
  dataDir: string;
  backupDir: string | null;
  port: number;
  service: string | null;
  serviceDir: string | null;
};

export function parseArgs(argv: string[], env: NodeJS.ProcessEnv = process.env): RestoreOptions {
  const opts: RestoreOptions = {
    mode: "dry-run",
    listFile: DEFAULT_LIST,
    dataDir: env.BALANCE_DATA_DIR || path.join(process.cwd(), "data"),
    backupDir: null,
    port: Number(env.PORT) || 4450,
    service: "setimig",
    serviceDir: null,
  };
  const modes = new Set<Mode>();
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]!;
    const next = () => {
      const v = argv[++i];
      if (v === undefined) throw new Error(`Falta el valor de ${a}`);
      return v;
    };
    if (a === "--apply") modes.add("apply");
    else if (a === "--rollback") modes.add("rollback");
    else if (a === "--dry-run") modes.add("dry-run");
    else if (a === "--list") opts.listFile = path.resolve(next());
    else if (a === "--data-dir") opts.dataDir = path.resolve(next());
    else if (a === "--backup-dir") opts.backupDir = path.resolve(next());
    else if (a === "--port") opts.port = Number(next());
    else if (a === "--service") {
      const v = next();
      opts.service = v === "none" ? null : v;
    } else if (a === "--service-dir") opts.serviceDir = path.resolve(next());
    else throw new Error(`Opció desconeguda: ${a}`);
  }
  if (modes.size > 1) throw new Error("Tria només un mode: --dry-run, --apply o --rollback");
  opts.mode = [...modes][0] ?? "dry-run";
  opts.dataDir = path.resolve(opts.dataDir);
  return opts;
}

export function loadList(file: string): RestoreList {
  const raw = JSON.parse(fs.readFileSync(file, "utf8")) as Partial<RestoreList>;
  if (!raw || typeof raw.rid !== "string" || !RID_RE.test(raw.rid)) throw new Error("Llista: `rid` no vàlid");
  if (!Array.isArray(raw.entries) || raw.entries.length === 0) throw new Error("Llista: cap entrada");
  const seen = new Set<string>();
  for (const e of raw.entries) {
    if (!e || typeof e.playerId !== "string" || !PLAYER_ID_RE.test(e.playerId)) throw new Error("Llista: playerId no vàlid");
    if (seen.has(e.playerId)) throw new Error(`Llista: playerId repetit (${maskId(e.playerId)})`);
    seen.add(e.playerId);
    if (!Number.isInteger(e.expectedCurrent) || e.expectedCurrent < 0) throw new Error("Llista: expectedCurrent no vàlid");
    if (!Number.isInteger(e.increment) || e.increment === 0) throw new Error("Llista: increment no vàlid");
    if (e.expectedCurrent + e.increment < 0) throw new Error("Llista: el saldo resultant seria negatiu");
    if (typeof e.reason !== "string" || !e.reason.trim()) throw new Error("Llista: falta `reason`");
  }
  return raw as RestoreList;
}

export function maskId(id: string): string {
  return `${id.slice(0, 8)}…`;
}

export function restoreMarker(rid: string, playerId: string): string {
  return `restore:${rid}:${playerId}`;
}

export function rollbackMarker(rid: string, playerId: string): string {
  return `restore-rollback:${rid}:${playerId}`;
}

const fmt = (n: number) => n.toLocaleString("ca-ES");

type Store = { accounts: Record<string, { chips: number; lastClaimAt?: number | null }>; processedSessions?: string[] };

function readStore(file: string): Store {
  const parsed = JSON.parse(fs.readFileSync(file, "utf8")) as Store;
  if (!parsed || typeof parsed !== "object" || !parsed.accounts) throw new Error(`Format de balances.json no vàlid: ${file}`);
  return parsed;
}

function chipsOf(store: Store, id: string): number {
  return store.accounts[id]?.chips ?? 24_500;
}

function accountSnapshot(store: Store, exclude: Set<string>): Map<string, string> {
  const out = new Map<string, string>();
  for (const [id, acc] of Object.entries(store.accounts)) if (!exclude.has(id)) out.set(id, JSON.stringify(acc, null, 2));
  return out;
}

function sha256(file: string): string {
  return createHash("sha256").update(fs.readFileSync(file)).digest("hex");
}

function isUnder(dir: string, root: string): boolean {
  const r = path.resolve(root);
  const d = path.resolve(dir);
  return d === r || d.startsWith(r + path.sep);
}

function realOrSelf(p: string): string {
  try {
    return fs.realpathSync(p);
  } catch {
    return path.resolve(p);
  }
}

/** Motiu pel qual el servidor sembla en marxa (port obert o servei actiu), o null. */
export async function serverLooksRunning(port: number, service: string | null): Promise<string | null> {
  if (port > 0) {
    const portOpen = await new Promise<boolean>((resolve) => {
      const sock = net.connect({ host: "127.0.0.1", port });
      const done = (v: boolean) => {
        sock.destroy();
        resolve(v);
      };
      sock.setTimeout(500, () => done(false));
      sock.once("connect", () => done(true));
      sock.once("error", () => done(false));
    });
    if (portOpen) return `hi ha alguna cosa escoltant al port ${port}`;
  }
  if (service) {
    const r = spawnSync("systemctl", ["--user", "is-active", service], { encoding: "utf8" });
    if (r.status === 0 && r.stdout.trim() === "active") return `el servei ${service} està actiu`;
  }
  return null;
}

function serviceWorkingDir(service: string | null): string | null {
  if (!service) return null;
  const r = spawnSync("systemctl", ["--user", "show", service, "-p", "WorkingDirectory", "--value"], { encoding: "utf8" });
  const v = r.status === 0 ? r.stdout.trim() : "";
  return v && v !== "/" ? v : null;
}

type Planned = {
  entry: RestoreEntry;
  marker: string;
  increment: number;
  expectedCurrent: number;
  current: number;
  action: "aplicar" | "ja-aplicat" | "no-quadra" | "sense-restauracio";
};

function planEntries(list: RestoreList, store: Store, mode: Mode): Planned[] {
  const done = new Set(store.processedSessions ?? []);
  return list.entries.map((entry) => {
    const rollback = mode === "rollback";
    const marker = rollback ? rollbackMarker(list.rid, entry.playerId) : restoreMarker(list.rid, entry.playerId);
    const increment = rollback ? -entry.increment : entry.increment;
    const expectedCurrent = rollback ? entry.expectedCurrent + entry.increment : entry.expectedCurrent;
    const current = chipsOf(store, entry.playerId);
    let action: Planned["action"];
    if (done.has(marker)) action = "ja-aplicat";
    else if (rollback && !done.has(restoreMarker(list.rid, entry.playerId))) action = "sense-restauracio";
    else if (current !== expectedCurrent) action = "no-quadra";
    else action = "aplicar";
    return { entry, marker, increment, expectedCurrent, current, action };
  });
}

function describe(p: Planned): string {
  const id = maskId(p.entry.playerId);
  const sign = p.increment > 0 ? "+" : "";
  const head = `  ${id}  actual ${fmt(p.current)} · esperat ${fmt(p.expectedCurrent)} · increment ${sign}${fmt(p.increment)} · objectiu ${fmt(p.expectedCurrent + p.increment)}`;
  const tail = {
    aplicar: "→ s'aplicaria",
    "ja-aplicat": "→ ja aplicat (marca present): no es farà res",
    "no-quadra": "→ NO QUADRA: el saldo actual no és l'esperat",
    "sense-restauracio": "→ no hi ha cap restauració aplicada per desfer",
  }[p.action];
  return `${head}\n      marca ${p.marker.replace(p.entry.playerId, id)} ${tail}`;
}

export async function main(argv: string[], log: (s: string) => void = console.log): Promise<number> {
  let opts: RestoreOptions;
  let list: RestoreList;
  try {
    opts = parseArgs(argv);
    list = loadList(opts.listFile);
  } catch (err) {
    log(`ERROR: ${err instanceof Error ? err.message : String(err)}`);
    return 1;
  }
  const file = path.join(opts.dataDir, "balances.json");
  if (!fs.existsSync(file)) {
    log(`ERROR: no existeix ${file}`);
    return 1;
  }
  const before = readStore(file);
  const planned = planEntries(list, before, opts.mode);
  log(`Restauració de saldos · rid ${list.rid} · mode ${opts.mode.toUpperCase()}`);
  log(`  dades: ${file} (sha256 ${sha256(file).slice(0, 16)}…, ${Object.keys(before.accounts).length} comptes)`);
  for (const p of planned) log(describe(p));

  const blocking = planned.filter((p) => p.action === "no-quadra" || p.action === "sense-restauracio");
  const pending = planned.filter((p) => p.action === "aplicar");

  if (opts.mode === "dry-run") {
    log(`SIMULACIÓ: no s'ha escrit res. ${pending.length} per aplicar, ${planned.length - pending.length - blocking.length} ja aplicades, ${blocking.length} bloquejades.`);
    return blocking.length ? 3 : 0;
  }
  if (blocking.length) {
    log(`ABORTAT: ${blocking.length} entrada(es) no quadren. No s'ha escrit res. Recalcula el pla.`);
    return 3;
  }
  if (pending.length === 0) {
    log("Res a fer: totes les entrades ja estaven aplicades (execució idempotent). No s'ha escrit res.");
    return 0;
  }

  // Servidor en marxa sobre aquestes mateixes dades → es nega.
  const running = await serverLooksRunning(opts.port, opts.service);
  const serviceDir = opts.serviceDir ?? serviceWorkingDir(opts.service) ?? path.join(os.homedir(), "setimig");
  const dataReal = realOrSelf(opts.dataDir);
  const sameAsService = isUnder(dataReal, realOrSelf(serviceDir)) || isUnder(dataReal, realOrSelf(path.join(process.cwd(), "data")));
  if (running && sameAsService) {
    log(`ABORTAT: ${running} i ${opts.dataDir} és el directori de dades del servei. Atura'l abans (systemctl --user stop ${opts.service ?? "setimig"}). No s'ha escrit res.`);
    return 4;
  }
  if (running) log(`Avís: ${running}, però les dades (${opts.dataDir}) no són les del servei (${serviceDir}): es continua.`);

  // Còpia abans d'escriure.
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const backupDir = opts.backupDir ?? path.join(os.homedir(), "setimig-backups", `restore-${list.rid}-${opts.mode}-${stamp}`);
  const tmpRoots = [path.resolve("/tmp"), path.resolve(os.tmpdir())];
  if (tmpRoots.some((r) => isUnder(backupDir, r)) && !tmpRoots.some((r) => isUnder(opts.dataDir, r))) {
    log(`ABORTAT: la còpia no pot anar a /tmp (${backupDir}). No s'ha escrit res.`);
    return 1;
  }
  fs.mkdirSync(backupDir, { recursive: true });
  const backupFile = path.join(backupDir, "balances.json");
  fs.copyFileSync(file, backupFile);
  if (sha256(backupFile) !== sha256(file)) {
    log("ABORTAT: la còpia no coincideix amb l'original. No s'ha escrit res.");
    return 1;
  }
  log(`  còpia: ${backupFile} (sha256 ${sha256(backupFile).slice(0, 16)}…)`);

  // Aplicació amb la transacció del mateix servidor (cua d'escriptures, tmp + rename, immediat).
  process.env.BALANCE_DATA_DIR = opts.dataDir;
  const balances = await import("../server/balances.ts");
  balances.resetBalanceStoreCacheForTests();
  const touched = new Set(planned.map((p) => p.entry.playerId));
  let failed = false;
  for (const p of pending) {
    const r = await balances.applyBalanceAdjustment({
      playerId: p.entry.playerId,
      increment: p.increment,
      expectedCurrent: p.expectedCurrent,
      marker: p.marker,
    });
    const id = maskId(p.entry.playerId);
    if (r.status === "applied") log(`  APLICAT ${id}: ${fmt(r.before)} → ${fmt(r.after)} (${r.increment > 0 ? "+" : ""}${fmt(r.increment)})`);
    else if (r.status === "already-applied") log(`  JA APLICAT ${id}: saldo ${fmt(r.current)} (no s'ha tocat)`);
    else {
      log(`  NO QUADRA ${id}: actual ${fmt(r.current)} ≠ esperat ${fmt(r.expectedCurrent)} (no s'ha tocat)`);
      failed = true;
    }
  }
  await balances.flushBalanceWrites();
  balances.resetBalanceStoreCacheForTests();

  // Comprovació posterior rellegint el disc.
  const after = readStore(file);
  const markers = new Set(after.processedSessions ?? []);
  const problems: string[] = [];
  for (const p of planned) {
    if (!markers.has(p.marker)) problems.push(`falta la marca de ${maskId(p.entry.playerId)}`);
    const want = p.expectedCurrent + p.increment;
    if (p.action === "aplicar" && chipsOf(after, p.entry.playerId) !== want) {
      problems.push(`${maskId(p.entry.playerId)}: ${fmt(chipsOf(after, p.entry.playerId))} ≠ ${fmt(want)}`);
    }
  }
  const othersBefore = accountSnapshot(before, touched);
  const othersAfter = accountSnapshot(after, touched);
  let changed = 0;
  for (const [id, json] of othersBefore) if (othersAfter.get(id) !== json) changed++;
  if (othersAfter.size !== othersBefore.size) problems.push(`nombre de comptes ${othersBefore.size + touched.size} → ${Object.keys(after.accounts).length}`);
  if (changed) problems.push(`${changed} altres comptes han canviat`);
  log(`  comprovació: ${othersBefore.size} altres comptes idèntics: ${changed === 0 && othersAfter.size === othersBefore.size ? "SÍ" : "NO"}; marques presents: ${planned.every((p) => markers.has(p.marker)) ? "SÍ" : "NO"}`);
  if (failed || problems.length) {
    log(`ERROR a la comprovació: ${problems.join("; ") || "alguna entrada no quadrava"}. Còpia per tornar enrere: ${backupFile}`);
    return 2;
  }
  log(`FET (${opts.mode}). Còpia: ${backupFile}`);
  return 0;
}

const isDirectRun = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isDirectRun) {
  main(process.argv.slice(2)).then(
    (code) => process.exit(code),
    (err) => {
      console.error(err);
      process.exit(1);
    }
  );
}
