/**
 * One-off Branch A mobile CSS/layout check at 390×844 (5 rivals).
 */
import { chromium } from "@playwright/test";

const BASE = process.env.BASE_URL ?? "http://127.0.0.1:3000";
const VIEWPORT = { width: 390, height: 844 };

async function enterLobby(page, name, playerId) {
  await page.addInitScript(
    ({ id, n }) => {
      localStorage.setItem("setimig_player_id", id);
      localStorage.setItem("setimig_player_name", n);
      localStorage.setItem(
        "setimig_age_gate",
        JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
      );
    },
    { id: playerId, n: name }
  );
  await page.goto(`${BASE}/`);
  const input = page.getByPlaceholder("El teu nom");
  if (await input.isVisible().catch(() => false)) {
    await input.fill(name);
    await page.getByRole("button", { name: "Entrar al lobby" }).click();
  }
  await page.getByTestId("lobby-main").waitFor({ state: "visible", timeout: 30_000 });
}

async function main() {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: VIEWPORT });
  await enterLobby(page, "BranchA", "branchamobile01");
  await page.getByTestId("play-vs-ai-button").click();
  await page.getByTestId("ai-bot-picker").waitFor({ state: "visible" });
  await page.getByTestId("ai-bot-count-6").click();
  await page.getByRole("button", { name: "Començar" }).click();
  await page.getByRole("button", { name: "Sortir de la partida" }).waitFor({ state: "visible", timeout: 45_000 });

  const betBtn = page.getByRole("button", { name: /^100$/ }).first();
  if (await betBtn.isVisible().catch(() => false)) await betBtn.click();

  const deadline = Date.now() + 120_000;
  while (Date.now() < deadline) {
    const playerCard = page.locator(".spanish-card-size-player").first();
    const opponentCard = page.locator(".spanish-card-size-opponent").first();
    if ((await playerCard.isVisible().catch(() => false)) && (await opponentCard.isVisible().catch(() => false))) {
      break;
    }
    const hit = page.getByRole("button", { name: "Carta" });
    if (await hit.isVisible().catch(() => false)) await hit.click();
    const stand = page.getByRole("button", { name: "Plantar-se" });
    if (await stand.isVisible().catch(() => false)) await stand.click();
    await page.waitForTimeout(600);
  }

  const metrics = await page.evaluate(() => {
    const root = document.querySelector(".game-table-root");
    const playerCard = document.querySelector(".spanish-card-size-player");
    const opponentCard = document.querySelector(".spanish-card-size-opponent");
    const pr = playerCard?.getBoundingClientRect();
    const or = opponentCard?.getBoundingClientRect();
    const cs = root ? getComputedStyle(root) : null;
    return {
      densityClass: root?.className ?? "",
      cssPlayerH: cs?.getPropertyValue("--card-player-h").trim(),
      cssPlayerW: cs?.getPropertyValue("--card-player-w").trim(),
      playerW: pr?.width ?? 0,
      playerH: pr?.height ?? 0,
      opponentW: or?.width ?? 0,
      opponentH: or?.height ?? 0,
    };
  });

  const playerRatio = metrics.playerW / metrics.playerH;
  const opponentRatio = metrics.opponentW / metrics.opponentH;

  const checks = [
    ["density-5 on table", metrics.densityClass.includes("game-table-density-5")],
    ["local card width >= 60", metrics.playerW >= 60],
    ["local card height >= 98", metrics.playerH >= 97],
    ["local aspect ~0.65", Math.abs(playerRatio - 0.65) < 0.04],
    ["rival card height >= 46", metrics.opponentH >= 45],
    ["rival aspect ~0.65", metrics.opponentW === 0 || Math.abs(opponentRatio - 0.65) < 0.04],
  ];

  console.log(JSON.stringify({ viewport: VIEWPORT, metrics, checks: Object.fromEntries(checks) }, null, 2));

  const failed = checks.filter(([, ok]) => !ok);
  await browser.close();
  if (failed.length) {
    console.error("FAILED:", failed.map(([n]) => n).join(", "));
    process.exit(1);
  }
  console.log("branch-a-mobile-check: OK");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
