#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib/setimig-env.sh
source "${SCRIPT_DIR}/lib/setimig-env.sh"

GITHUB_API_REPO="${GITHUB_API_REPO:-eedduuaarrd/setimig}"

usage() {
  cat <<'EOF'
Ús: merge-zip.sh <fitxer.zip> [--help]

Descomprime el ZIP, troba el commit base de main més proper, crea la branca
edu/zip-YYYYMMDD-HHMM amb merge a 3 bandes (sense esborrar fitxers de main
que no apareguin al ZIP), push i gate-pr sobre el commit resultant.
EOF
}

zip_root_dir() {
  local dir="$1"
  local count
  count="$(find "$dir" -mindepth 1 -maxdepth 1 ! -name '__MACOSX' | wc -l)"
  if [[ "$count" -eq 1 ]]; then
    find "$dir" -mindepth 1 -maxdepth 1 ! -name '__MACOSX' -print -quit
  else
    echo "$dir"
  fi
}

find_best_base_commit() {
  local repo="$1"
  local zip_root="$2"
  local best_commit=""
  local best_score=999999999

  git -C "$repo" fetch origin main --quiet || true
  local main_ref
  main_ref="$(git -C "$repo" rev-parse origin/main 2>/dev/null || git -C "$repo" rev-parse main)"

  local commit
  while IFS= read -r commit; do
    [[ -z "$commit" ]] && continue
    local tree_dir
    tree_dir="$(mktemp -d)"
    if ! git -C "$repo" archive "$commit" | tar -x -C "$tree_dir" 2>/dev/null; then
      rm -rf "$tree_dir"
      continue
    fi
    local stat_line
    stat_line="$(git diff --no-index --stat "$tree_dir" "$zip_root" 2>/dev/null | tail -1 || true)"
    rm -rf "$tree_dir"
    [[ -z "$stat_line" ]] && continue
    local score
    score="$(echo "$stat_line" | awk '{
      for(i=1;i<=NF;i++){
        if($i ~ /^[0-9]+$/ && $(i+1) ~ /^insertion/){ins=$i}
        if($i ~ /^[0-9]+$/ && $(i+1) ~ /^deletion/){del=$i}
      }
      print (ins+0)+(del+0)
    }')"
    score="${score:-999999999}"
    if [[ "$score" -lt "$best_score" ]]; then
      best_score="$score"
      best_commit="$commit"
    fi
  done < <(git -C "$repo" rev-list -n 200 "$main_ref")

  if [[ -z "$best_commit" ]]; then
    echo "No s'ha trobat cap commit base adequat." >&2
    return 1
  fi
  echo "$best_commit"
}

list_zip_files() {
  local zip_root="$1"
  (cd "$zip_root" && find . -type f ! -path './.git/*' | sed 's|^\./||' | sort -u)
}

three_way_apply() {
  local repo="$1"
  local base_commit="$2"
  local zip_root="$3"
  local conflicts=()

  while IFS= read -r relpath; do
    [[ -z "$relpath" ]] && continue
    local ours_path="${repo}/${relpath}"
    local theirs_path="${zip_root}/${relpath}"
    local base_path
    base_path="$(mktemp)"

    if git -C "$repo" cat-file -e "${base_commit}:${relpath}" 2>/dev/null; then
      git -C "$repo" show "${base_commit}:${relpath}" >"$base_path"
    else
      : >"$base_path"
    fi

    if [[ ! -f "$theirs_path" ]]; then
      rm -f "$base_path"
      continue
    fi

    mkdir -p "$(dirname "$ours_path")"

    if [[ ! -f "$ours_path" ]]; then
      cp "$theirs_path" "$ours_path"
      rm -f "$base_path"
      continue
    fi

    local merged
    merged="$(mktemp)"
    if git merge-file -p "$ours_path" "$base_path" "$theirs_path" >"$merged" 2>/dev/null; then
      mv "$merged" "$ours_path"
    else
      conflicts+=("$relpath")
      rm -f "$merged"
    fi
    rm -f "$base_path"
  done < <(list_zip_files "$zip_root")

  if ((${#conflicts[@]} > 0)); then
    echo "Conflictes de merge (atura):" >&2
    printf '  %s\n' "${conflicts[@]}" >&2
    return 1
  fi
  return 0
}

main() {
  if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
    usage
    exit 0
  fi
  if [[ $# -lt 1 ]]; then
    usage >&2
    exit 1
  fi
  local zip_file="$1"
  if [[ ! -f "$zip_file" ]]; then
    echo "No existe el fitxer: $zip_file" >&2
    exit 1
  fi

  setimig_export_path
  local repo="${SETIMIG_REPO}"
  local extract_dir
  extract_dir="$(mktemp -d /tmp/setimig-zip-XXXXXX)"
  unzip -q "$zip_file" -d "$extract_dir"
  local zip_root
  zip_root="$(zip_root_dir "$extract_dir")"

  echo "Cercant commit base (últims 200 commits de main)…"
  local base_commit
  base_commit="$(find_best_base_commit "$repo" "$zip_root")"
  echo "Base triada: ${base_commit}"

  local branch="edu/zip-$(date +%Y%m%d-%H%M)"
  git -C "$repo" fetch origin main --quiet || true
  git -C "$repo" checkout -B "$branch" origin/main 2>/dev/null || git -C "$repo" checkout -B "$branch" main

  three_way_apply "$repo" "$base_commit" "$zip_root"

  git -C "$repo" add -A
  if git -C "$repo" diff --cached --quiet; then
    echo "Cap canvi després del merge; no faig commit." >&2
    rm -rf "$extract_dir"
    exit 1
  fi

  git -C "$repo" commit -m "merge zip sobre main (base ${base_commit:0:8})"
  git -C "$repo" push -u origin "$branch"

  local head_sha
  head_sha="$(git -C "$repo" rev-parse HEAD)"
  rm -rf "$extract_dir"

  echo "Branca ${branch} (${head_sha}); executant gate-pr…"
  "${SCRIPT_DIR}/gate-pr.sh" "$head_sha"
}

main "$@"
