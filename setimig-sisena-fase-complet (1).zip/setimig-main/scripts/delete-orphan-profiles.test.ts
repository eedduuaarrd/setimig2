import { after, before, describe, it } from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import fs from "node:fs";
import net from "node:net";
import os from "node:os";
import path from "node:path";
import { accountPlayerIdsFromStore } from "../server/auth/identityStore.ts";
import {
  accountPlayerIds,
  listOrphanPlayerIds,
  main,
  orphanSafetyBlock,
  parseOrphanArgs,
} from "./delete-orphan-profiles.ts";

const ORPHAN = "orphan0000-0000-0000-0000-000000000001";
const ACCOUNT = "account00-0000-0000-0000-000000000002";
/** playerId hex com els de producció (loginWithIdentity / newPlayerId). */
const PROD_STYLE = "3288d5dd8af0123456789abc3288d5dd8af0123456789abc3288d5dd8af0abcd";
let dir: string;
let dataDir: string;
let backupDir: string;
let logs: string[];

const run = (args: string[]) => {
  logs = [];
  return main([...args, "--data-dir", dataDir, "--backup-dir", backupDir, "--service", "none", "--port", "0"], (s) =>
    logs.push(s),
  );
};
const sha = (f: string) => createHash("sha256").update(fs.readFileSync(f)).digest("hex");
function snapshot(): Record<string, string> {
  const out: Record<string, string> = {};
  const walk = (d: string) => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) walk(p);
      else out[path.relative(dataDir, p)] = sha(p);
    }
  };
  walk(dataDir);
  return out;
}
const write = (rel: string, data: unknown) => {
  fs.mkdirSync(path.dirname(path.join(dataDir, rel)), { recursive: true });
  fs.writeFileSync(path.join(dataDir, rel), JSON.stringify(data, null, 2), "utf8");
};

before(() => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), "setimig-orphan-"));
  dataDir = path.join(dir, "data");
  backupDir = path.join(dir, "backup");
  process.env.SETIMIG_ANALYTICS_SALT = "sal-orfes-0123456789abcdef";
  write("balances.json", {
    accounts: { [ORPHAN]: { chips: 1500 }, [ACCOUNT]: { chips: 9000 } },
    processedSessions: [],
  });
  write("identities.json", {
    version: 1,
    emails: { "amb@compte.cat": ACCOUNT },
    google: {},
    passkeys: {},
    players: { [ACCOUNT]: { createdVia: "email", emails: ["amb@compte.cat"] } },
    log: [],
  });
  write(`profiles/${ORPHAN}.json`, { displayName: "Orfe", avatarDataUrl: null, updatedAt: 1 });
  write(`profiles/${ACCOUNT}.json`, { displayName: "Amb compte", avatarDataUrl: null, updatedAt: 1 });
  write(`player-stats/${ORPHAN}.json`, { hands: 3 });
  write("friends.json", {
    players: {
      [ORPHAN]: { friendCode: "FORPH1", friendPlayerIds: [ACCOUNT] },
      [ACCOUNT]: { friendCode: "FACCT1", friendPlayerIds: [ORPHAN] },
    },
    friendCodeIndex: { FORPH1: ORPHAN, FACCT1: ACCOUNT },
  });
});

after(() => fs.rmSync(dir, { recursive: true, force: true }));

describe("scripts/delete-orphan-profiles.ts", () => {
  it("detecta només els sense compte", () => {
    assert.deepEqual(listOrphanPlayerIds(dataDir, path.join(dataDir, "profiles")), [ORPHAN]);
  });

  it("simulació per defecte: llista i no escriu res", async () => {
    const before1 = snapshot();
    assert.equal(await run([]), 0);
    const out = logs.join("\n");
    assert.match(out, /Perfils\/dades sense compte \(orfes\): 1/);
    assert.match(out, new RegExp(`Orfe ${ORPHAN}`));
    assert.match(out, /esborrar: saldo: 1500 fitxes/);
    assert.match(out, /SIMULACIÓ/);
    assert.ok(!out.includes(`Orfe ${ACCOUNT}`));
    assert.deepEqual(snapshot(), before1);
    assert.equal(fs.existsSync(backupDir), false);
  });

  it("--apply amb el servidor en marxa: es nega", async () => {
    const srv = net.createServer();
    await new Promise<void>((r) => srv.listen(0, "127.0.0.1", r));
    const port = (srv.address() as net.AddressInfo).port;
    const before1 = snapshot();
    logs = [];
    const code = await main(["--apply", "--data-dir", dataDir, "--backup-dir", backupDir, "--service", "none", "--port", String(port)], (s) =>
      logs.push(s),
    );
    srv.close();
    assert.equal(code, 3);
    assert.match(logs.join("\n"), /ABORTAT/);
    assert.deepEqual(snapshot(), before1);
  });

  it("--apply: còpia sha256, esborra l'orfe, conserva el compte", async () => {
    assert.equal(await run(["--apply"]), 0, logs.join("\n"));
    assert.match(logs.join("\n"), /Còpia \(sha256 verificat\)/);
    assert.match(logs.join("\n"), /Fet: no queda cap perfil/);
    const manifest = JSON.parse(fs.readFileSync(path.join(backupDir, "manifest.json"), "utf8"));
    assert.ok(manifest.files.length >= 1);
    for (const f of manifest.files) {
      assert.equal(sha(f.to), f.sha256);
    }
    const bal = JSON.parse(fs.readFileSync(path.join(dataDir, "balances.json"), "utf8"));
    assert.deepEqual(bal.accounts, { [ACCOUNT]: { chips: 9000 } });
    assert.equal(fs.existsSync(path.join(dataDir, `profiles/${ORPHAN}.json`)), false);
    assert.equal(fs.existsSync(path.join(dataDir, `profiles/${ACCOUNT}.json`)), true);
    assert.equal(fs.existsSync(path.join(dataDir, `player-stats/${ORPHAN}.json`)), false);
    const fr = JSON.parse(fs.readFileSync(path.join(dataDir, "friends.json"), "utf8"));
    assert.equal(fr.players[ORPHAN], undefined);
    assert.deepEqual(fr.players[ACCOUNT].friendPlayerIds, []);
    assert.deepEqual(listOrphanPlayerIds(dataDir, path.join(dataDir, "profiles")), []);
  });
});

describe("format real identities.json (correu + passkey)", () => {
  it("reconeix el mateix shape que desa identityStore a producció", () => {
    const store = {
      version: 1 as const,
      emails: { "test@agentmail.to": PROD_STYLE },
      google: {},
      passkeys: {
        "9UsM2hBuCredIdBase64urlExample0001": {
          playerId: PROD_STYLE,
          publicKey: "AAAA",
          counter: 2,
          transports: ["internal"],
          deviceType: "platform",
          backedUp: false,
          name: "iPhone",
          createdAt: 1_700_000_000_000,
          lastUsedAt: 1_700_000_100_000,
        },
      },
      players: {
        [PROD_STYLE]: {
          createdVia: "email" as const,
          createdAt: 1_700_000_000_000,
          emails: ["test@agentmail.to"],
          webauthnUserId: "opaque-webauthn-user",
        },
      },
      log: [
        { at: 1, type: "create" as const, kind: "email" as const, playerId: PROD_STYLE },
        { at: 2, type: "passkey_added" as const, kind: "passkey" as const, playerId: PROD_STYLE },
      ],
    };
    const ids = accountPlayerIdsFromStore(store);
    assert.equal(ids.size, 1);
    assert.ok(ids.has(PROD_STYLE));
    // només a players.emails (mapa emails buit) també compta — criteri playerHasAccount
    assert.ok(
      accountPlayerIdsFromStore({
        emails: {},
        google: {},
        passkeys: {},
        players: { [PROD_STYLE]: { emails: ["test@agentmail.to"] } },
      }).has(PROD_STYLE),
    );
    // només passkey
    assert.ok(
      accountPlayerIdsFromStore({
        emails: {},
        google: {},
        passkeys: { cred1: { playerId: PROD_STYLE } },
        players: { [PROD_STYLE]: { webauthnUserId: "x" } },
      }).has(PROD_STYLE),
    );
    // només googleSub a players
    assert.ok(
      accountPlayerIdsFromStore({
        emails: {},
        google: { "google-sub-1": PROD_STYLE },
        passkeys: {},
        players: { [PROD_STYLE]: { googleSub: "google-sub-1" } },
      }).has(PROD_STYLE),
    );
    // anònim a players sense correu/google/passkey → NO és compte
    assert.equal(
      accountPlayerIdsFromStore({
        emails: {},
        google: {},
        passkeys: {},
        players: { [ORPHAN]: { createdVia: "anonim" as const } },
      }).size,
      0,
    );
  });
});

describe("salvaguarda 0 comptes / >90% orfes", () => {
  it("orphanSafetyBlock detecta els dos casos", () => {
    assert.equal(orphanSafetyBlock(0, 10, 10), "zero_accounts");
    assert.equal(orphanSafetyBlock(1, 10, 10), "majority_orphans");
    assert.equal(orphanSafetyBlock(1, 9, 10), null);
    assert.equal(orphanSafetyBlock(5, 1, 10), null);
  });

  it("--apply amb identities buit avorta sense --force", async () => {
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "setimig-orphan-empty-"));
    const d = path.join(tmp, "data");
    const b = path.join(tmp, "backup");
    const writeRel = (rel: string, data: unknown) => {
      fs.mkdirSync(path.dirname(path.join(d, rel)), { recursive: true });
      fs.writeFileSync(path.join(d, rel), JSON.stringify(data, null, 2), "utf8");
    };
    writeRel("identities.json", {
      version: 1,
      emails: {},
      google: {},
      passkeys: {},
      players: {},
      log: [],
    });
    writeRel("balances.json", { accounts: { [ORPHAN]: { chips: 10 } }, processedSessions: [] });
    writeRel(`profiles/${ORPHAN}.json`, { displayName: "X", avatarDataUrl: null, updatedAt: 1 });
    assert.equal(accountPlayerIds(d).size, 0);
    const localLogs: string[] = [];
    const code = await main(["--apply", "--data-dir", d, "--backup-dir", b, "--service", "none", "--port", "0"], (s) =>
      localLogs.push(s),
    );
    assert.equal(code, 6, localLogs.join("\n"));
    assert.match(localLogs.join("\n"), /ABORTAT: salvaguarda \(zero_accounts\)/);
    assert.equal(fs.existsSync(path.join(d, `profiles/${ORPHAN}.json`)), true);
    assert.equal(fs.existsSync(b), false);
    // dry-run avisa però surt 0
    localLogs.length = 0;
    assert.equal(await main(["--data-dir", d, "--backup-dir", b, "--service", "none", "--port", "0"], (s) => localLogs.push(s)), 0);
    assert.match(localLogs.join("\n"), /0 comptes verificats/);
    fs.rmSync(tmp, { recursive: true, force: true });
  });

  it("parseOrphanArgs accepta --force", () => {
    const o = parseOrphanArgs(["--apply", "--force", "--service", "none", "--port", "0"]);
    assert.equal(o.apply, true);
    assert.equal(o.force, true);
  });
});
