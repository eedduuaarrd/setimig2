/**
 * Purga de jugadors de prova (p. ex. els «Test …» de QA) de tots els magatzems de dades.
 *
 *   npx tsx scripts/purge-test-players.ts <id> [<id> ...] [--file ids.txt]   # SIMULACIÓ (per defecte)
 *   npx tsx scripts/purge-test-players.ts --file ids.txt --apply              # esborra de debò
 *   npx tsx scripts/purge-test-players.ts --find-name-prefix "Test "          # llista ids per nom (només lectura)
 *
 * Opcions:
 *   --apply                 Esborra. Abans desa una còpia amb data de tots els fitxers afectats
 *                           a ~/setimig-backups/purga-jugadors-<data>/ (mai a /tmp).
 *   --force                 Continua encara que sembli que el servidor està en marxa.
 *   --data-dir DIR          Per defecte BALANCE_DATA_DIR o ./data
 *   --profiles-dir DIR      Per defecte PROFILE_DATA_DIR o <data-dir>/profiles
 *   --friends-dir DIR       Per defecte FRIENDS_DATA_DIR o <data-dir>
 *   --backup-dir DIR        Per defecte ~/setimig-backups/purga-jugadors-<data>
 *   --port N                Port del servidor per detectar si està en marxa (PORT o 4450)
 *   --service NOM           Servei systemd --user a comprovar (setimig; «none» per no comprovar-ho)
 *
 * El servidor desa les dades per lots i en memòria: si està en marxa, pot tornar a escriure
 * el que s'hagi esborrat. Atura'l abans (`systemctl --user stop setimig`) o fes servir --force.
 * Les taules privades (private-rooms.json) només s'informen: caduquen soles pel TTL.
 */
import fs from "node:fs";
import net from "node:net";
import os from "node:os";
import path from "node:path";
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const PLAYER_ID_RE = /^[a-zA-Z0-9_-]{8,64}$/;

export type PurgeOptions = {
  ids: string[];
  apply: boolean;
  force: boolean;
  dataDir: string;
  profilesDir: string;
  friendsDir: string;
  backupDir: string;
  port: number;
  service: string | null;
  findNamePrefix: string | null;
};

type JsonEdit = { file: string; label: string; describe: string[]; mutate: (data: any) => void };
type FileDelete = { file: string; label: string; describe: string };

export type PurgePlan = {
  ids: string[];
  deletes: FileDelete[];
  edits: JsonEdit[];
  reportOnly: string[];
};

function readJson(file: string): any | null {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return null;
  }
}

function isRecord(v: unknown): v is Record<string, any> {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

export function parseArgs(argv: string[], env: NodeJS.ProcessEnv = process.env): PurgeOptions {
  const ids: string[] = [];
  let apply = false;
  let force = false;
  let file: string | null = null;
  let dataDir: string | null = null;
  let profilesDir: string | null = null;
  let friendsDir: string | null = null;
  let backupDir: string | null = null;
  let port = Number(env.PORT) || 4450;
  let service: string | null = "setimig";
  let findNamePrefix: string | null = null;
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i]!;
    const next = () => {
      const v = argv[++i];
      if (v === undefined) throw new Error(`Falta el valor de ${a}`);
      return v;
    };
    if (a === "--apply") apply = true;
    else if (a === "--force") force = true;
    else if (a === "--file") file = next();
    else if (a === "--data-dir") dataDir = next();
    else if (a === "--profiles-dir") profilesDir = next();
    else if (a === "--friends-dir") friendsDir = next();
    else if (a === "--backup-dir") backupDir = next();
    else if (a === "--port") port = Number(next());
    else if (a === "--service") service = next();
    else if (a === "--find-name-prefix") findNamePrefix = next();
    else if (a.startsWith("--")) throw new Error(`Opció desconeguda: ${a}`);
    else ids.push(a);
  }
  if (file) {
    for (const line of fs.readFileSync(file, "utf8").split(/\r?\n/)) {
      const id = line.replace(/#.*/, "").trim();
      if (id) ids.push(id);
    }
  }
  const bad = ids.filter((id) => !PLAYER_ID_RE.test(id));
  if (bad.length) throw new Error(`Ids no vàlids: ${bad.join(", ")}`);
  const resolvedData = path.resolve(dataDir ?? env.BALANCE_DATA_DIR ?? path.join(process.cwd(), "data"));
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  return {
    ids: [...new Set(ids)],
    apply,
    force,
    dataDir: resolvedData,
    profilesDir: path.resolve(profilesDir ?? env.PROFILE_DATA_DIR ?? path.join(resolvedData, "profiles")),
    friendsDir: path.resolve(friendsDir ?? env.FRIENDS_DATA_DIR ?? resolvedData),
    backupDir: path.resolve(backupDir ?? path.join(os.homedir(), "setimig-backups", `purga-jugadors-${stamp}`)),
    port,
    service: service === "none" ? null : service,
    findNamePrefix,
  };
}

/** Ids de perfils amb el nom que comença per `prefix` (només lectura). */
export function findIdsByNamePrefix(profilesDir: string, prefix: string): { id: string; name: string }[] {
  if (!fs.existsSync(profilesDir)) return [];
  const out: { id: string; name: string }[] = [];
  for (const f of fs.readdirSync(profilesDir)) {
    if (!f.endsWith(".json")) continue;
    const name = readJson(path.join(profilesDir, f))?.displayName;
    if (typeof name === "string" && name.startsWith(prefix)) out.push({ id: f.slice(0, -5), name });
  }
  return out.sort((a, b) => a.name.localeCompare(b.name) || a.id.localeCompare(b.id));
}

export function buildPlan(opts: PurgeOptions): PurgePlan {
  const ids = new Set(opts.ids);
  const plan: PurgePlan = { ids: opts.ids, deletes: [], edits: [], reportOnly: [] };

  // Fitxers per jugador.
  const perPlayer: [string, string][] = [
    [opts.profilesDir, "perfil"],
    [path.join(opts.dataDir, "player-stats"), "estadístiques"],
    [path.join(opts.dataDir, "player-engagement"), "assoliments/missions"],
    [path.join(opts.dataDir, "campaign-progress"), "campanya"],
  ];
  for (const id of ids) {
    for (const [dir, label] of perPlayer) {
      const file = path.join(dir, `${id}.json`);
      if (!fs.existsSync(file)) continue;
      const name = label === "perfil" ? readJson(file)?.displayName : undefined;
      plan.deletes.push({ file, label, describe: `${id}${name ? ` («${name}»)` : ""}` });
    }
  }

  // balances.json
  const balancesFile = path.join(opts.dataDir, "balances.json");
  const balances = readJson(balancesFile);
  if (isRecord(balances?.accounts)) {
    const hit = [...ids].filter((id) => id in balances.accounts);
    if (hit.length) {
      plan.edits.push({
        file: balancesFile,
        label: "saldo",
        describe: hit.map((id) => `${id}: ${balances.accounts[id]?.chips} fitxes`),
        mutate: (d) => hit.forEach((id) => delete d.accounts[id]),
      });
    }
  }

  // Rànquing setmanal.
  const weeklyDir = path.join(opts.dataDir, "weekly-leaderboard");
  if (fs.existsSync(weeklyDir)) {
    for (const f of fs.readdirSync(weeklyDir).filter((x) => x.endsWith(".json")).sort()) {
      const file = path.join(weeklyDir, f);
      const data = readJson(file);
      if (!isRecord(data?.chipsWon)) continue;
      const hit = [...ids].filter((id) => id in data.chipsWon);
      if (!hit.length) continue;
      plan.edits.push({
        file,
        label: `rànquing ${f.replace(/\.json$/, "")}`,
        describe: hit.map((id) => `${id}: ${data.chipsWon[id]}`),
        mutate: (d) => hit.forEach((id) => delete d.chipsWon[id]),
      });
    }
  }

  // Agregat antic d'estadístiques.
  const legacyFile = path.join(opts.dataDir, "player-stats-aggregate.json");
  const legacy = readJson(legacyFile);
  if (isRecord(legacy?.players)) {
    const hit = [...ids].filter((id) => id in legacy.players);
    if (hit.length) {
      plan.edits.push({
        file: legacyFile,
        label: "agregat antic",
        describe: hit,
        mutate: (d) => hit.forEach((id) => delete d.players[id]),
      });
    }
  }

  // Amics: registre propi, codis i referències des d'altres jugadors.
  const friendsFile = path.join(opts.friendsDir, "friends.json");
  const friends = readJson(friendsFile);
  if (isRecord(friends?.players)) {
    const own = [...ids].filter((id) => id in friends.players);
    const codes = isRecord(friends.friendCodeIndex)
      ? Object.entries(friends.friendCodeIndex).filter(([, pid]) => ids.has(pid as string)).map(([c]) => c)
      : [];
    const refs = Object.entries(friends.players)
      .filter(([pid, rec]) => !ids.has(pid) && Array.isArray((rec as any)?.friendPlayerIds))
      .filter(([, rec]) => (rec as any).friendPlayerIds.some((f: string) => ids.has(f)))
      .map(([pid]) => pid);
    if (own.length || codes.length || refs.length) {
      plan.edits.push({
        file: friendsFile,
        label: "amics",
        describe: [
          ...own.map((id) => `${id}: registre i codi d'amic`),
          ...codes.map((c) => `codi ${c}`),
          ...refs.map((pid) => `${pid}: treure'l de la llista d'amics`),
        ],
        mutate: (d) => {
          own.forEach((id) => delete d.players[id]);
          if (isRecord(d.friendCodeIndex)) codes.forEach((c) => delete d.friendCodeIndex[c]);
          for (const pid of refs) {
            const rec = d.players[pid];
            rec.friendPlayerIds = rec.friendPlayerIds.filter((f: string) => !ids.has(f));
          }
        },
      });
    }
  }

  // Taules privades: només informar.
  const privFile = path.join(opts.dataDir, "private-rooms.json");
  const priv = readJson(privFile);
  if (isRecord(priv?.rooms)) {
    for (const [roomId, room] of Object.entries(priv.rooms)) {
      const seats = Array.isArray((room as any)?.players) ? (room as any).players : [];
      const hit = seats.filter((p: any) => ids.has(p?.playerId)).map((p: any) => p.playerId);
      if (hit.length) {
        plan.reportOnly.push(
          `taula privada ${(room as any).inviteCode ?? roomId}: ${hit.join(", ")} (no es toca; caduca pel TTL)`
        );
      }
    }
  }
  return plan;
}

export function formatPlan(plan: PurgePlan): string {
  const lines: string[] = [`Jugadors: ${plan.ids.length}`];
  for (const d of plan.deletes) lines.push(`  esborrar ${d.label}: ${d.file}  [${d.describe}]`);
  for (const e of plan.edits) {
    lines.push(`  editar ${e.label}: ${e.file}`);
    for (const x of e.describe) lines.push(`      - ${x}`);
  }
  for (const r of plan.reportOnly) lines.push(`  info: ${r}`);
  if (!plan.deletes.length && !plan.edits.length) lines.push("  (res a esborrar)");
  return lines.join("\n");
}

/** True si sembla que el servidor està en marxa (port obert o servei systemd actiu). */
export async function serverLooksRunning(port: number, service: string | null): Promise<string | null> {
  const portOpen = await new Promise<boolean>((resolve) => {
    const sock = net.connect({ host: "127.0.0.1", port });
    const done = (v: boolean) => {
      sock.destroy();
      resolve(v);
    };
    sock.setTimeout(500, () => done(false));
    sock.once("connect", () => done(true));
    sock.once("error", () => done(false));
  });
  if (portOpen) return `hi ha alguna cosa escoltant al port ${port}`;
  if (service) {
    const r = spawnSync("systemctl", ["--user", "is-active", service], { encoding: "utf8" });
    if (r.status === 0 && r.stdout.trim() === "active") return `el servei ${service} està actiu`;
  }
  return null;
}

function isUnderTmp(dir: string): boolean {
  const roots = new Set([path.resolve("/tmp"), path.resolve(os.tmpdir())]);
  return [...roots].some((r) => dir === r || dir.startsWith(r + path.sep));
}

function writeJsonAtomic(file: string, data: unknown): void {
  const tmp = `${file}.purga-tmp`;
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), "utf8");
  fs.renameSync(tmp, file);
}

/** Desa còpies de tots els fitxers afectats i en comprova la mida. Retorna el directori. */
export function backupAffected(plan: PurgePlan, opts: PurgeOptions): string {
  if (isUnderTmp(opts.backupDir)) throw new Error(`La còpia no pot anar a /tmp: ${opts.backupDir}`);
  fs.mkdirSync(opts.backupDir, { recursive: true });
  const files = [...new Set([...plan.deletes.map((d) => d.file), ...plan.edits.map((e) => e.file)])];
  const manifest: { ids: string[]; at: string; files: { from: string; to: string }[] } = {
    ids: plan.ids,
    at: new Date().toISOString(),
    files: [],
  };
  files.forEach((from, i) => {
    const to = path.join(opts.backupDir, `${String(i).padStart(3, "0")}-${path.basename(path.dirname(from))}-${path.basename(from)}`);
    fs.copyFileSync(from, to);
    if (fs.statSync(to).size !== fs.statSync(from).size) throw new Error(`Còpia incompleta: ${from}`);
    manifest.files.push({ from, to });
  });
  fs.writeFileSync(path.join(opts.backupDir, "manifest.json"), JSON.stringify(manifest, null, 2), "utf8");
  return opts.backupDir;
}

export function applyPlan(plan: PurgePlan): void {
  for (const e of plan.edits) {
    const data = JSON.parse(fs.readFileSync(e.file, "utf8"));
    e.mutate(data);
    writeJsonAtomic(e.file, data);
  }
  for (const d of plan.deletes) fs.rmSync(d.file, { force: true });
}

export async function main(argv: string[], log: (s: string) => void = console.log): Promise<number> {
  let opts: PurgeOptions;
  try {
    opts = parseArgs(argv);
  } catch (err) {
    log(`Error: ${(err as Error).message}`);
    return 2;
  }
  if (opts.findNamePrefix !== null) {
    const found = findIdsByNamePrefix(opts.profilesDir, opts.findNamePrefix);
    for (const f of found) log(`${f.id}\t${f.name}`);
    log(`# ${found.length} perfils amb el nom que comença per «${opts.findNamePrefix}» (només lectura)`);
    return 0;
  }
  if (!opts.ids.length) {
    log("Cal almenys un id (arguments o --file). Per defecte només simula; --apply per esborrar.");
    return 2;
  }
  const plan = buildPlan(opts);
  log(formatPlan(plan));
  const running = await serverLooksRunning(opts.port, opts.service);
  if (!opts.apply) {
    if (running) log(`AVÍS: sembla que el servidor està en marxa (${running}).`);
    log("SIMULACIÓ: no s'ha esborrat res. Afegeix --apply per esborrar.");
    return 0;
  }
  if (running && !opts.force) {
    log(`ATURAT: sembla que el servidor està en marxa (${running}). Atura'l o fes servir --force.`);
    return 3;
  }
  if (!plan.deletes.length && !plan.edits.length) {
    log("Res a esborrar.");
    return 0;
  }
  try {
    const dir = backupAffected(plan, opts);
    log(`Còpia desada a ${dir}`);
  } catch (err) {
    log(`ATURAT: no s'ha pogut fer la còpia (${(err as Error).message}). No s'ha esborrat res.`);
    return 4;
  }
  applyPlan(plan);
  log(`Fet: ${plan.deletes.length} fitxers esborrats, ${plan.edits.length} fitxers editats.`);
  return 0;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main(process.argv.slice(2)).then((code) => process.exit(code));
}
