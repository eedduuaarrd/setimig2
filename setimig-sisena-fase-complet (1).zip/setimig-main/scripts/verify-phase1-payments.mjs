/**
 * Phase 1 smoke checks: chip checkout routes gone; live Stripe keys rejected.
 * Run: node scripts/verify-phase1-payments.mjs
 */
import { spawn } from "node:child_process";
import { setTimeout as delay } from "node:timers/promises";

const PORT = 34567;
const base = `http://127.0.0.1:${PORT}`;

function runServer(env) {
  const child = spawn("npx", ["tsx", "server.ts"], {
    env: { ...process.env, ...env, PORT: String(PORT), NODE_ENV: "production" },
    stdio: ["ignore", "pipe", "pipe"],
  });
  return child;
}

async function waitForHealth(child, timeoutMs = 15_000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    try {
      const res = await fetch(`${base}/api/health`);
      if (res.ok) return;
    } catch {
      // not up yet
    }
    await delay(200);
  }
  const stderr = child.stderr ? await readStream(child.stderr) : "";
  throw new Error(`Server did not start:\n${stderr}`);
}

function readStream(stream) {
  return new Promise((resolve) => {
    let data = "";
    stream.on("data", (c) => (data += c));
    stream.on("end", () => resolve(data));
    setTimeout(() => resolve(data), 500);
  });
}

async function assertRouteGone(path) {
  const res = await fetch(`${base}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({}),
  });
  if (res.status !== 404) {
    const body = await res.text();
    throw new Error(`Expected 404 for ${path}, got ${res.status}: ${body}`);
  }
}

async function main() {
  const child = runServer({
    PAYMENTS_ENABLED: "false",
    STRIPE_SECRET_KEY: "",
  });
  try {
    await waitForHealth(child);
    await assertRouteGone("/api/create-checkout-session");
    await assertRouteGone("/api/verify-checkout");

    const health = await (await fetch(`${base}/api/health`)).json();
    if (health.stripe !== false) {
      throw new Error(`Expected stripe:false in health, got ${JSON.stringify(health)}`);
    }
  } finally {
    child.kill("SIGTERM");
  }

  const liveChild = runServer({
    PAYMENTS_ENABLED: "true",
    STRIPE_SECRET_KEY: "sk_live_fake_for_test",
  });
  try {
    await waitForHealth(liveChild);
    const health = await (await fetch(`${base}/api/health`)).json();
    if (health.stripe !== false) {
      throw new Error(`Live key guard failed: health=${JSON.stringify(health)}`);
    }
  } finally {
    liveChild.kill("SIGTERM");
  }

  console.log("verify-phase1-payments: OK");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
