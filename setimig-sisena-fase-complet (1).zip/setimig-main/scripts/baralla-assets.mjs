#!/usr/bin/env node
/**
 * Baralla E (Renaixement gravat) + revers L2b: copia el paquet final de Producte a l'app.
 *
 * Ús: node scripts/baralla-assets.mjs /workspace/setimig/cartes-final
 *
 * - public/baralla/…            recursos amb hash al nom (sha256, 8 caràcters)
 * - src/lib/barallaAssets.generated.ts  URL amb hash de cada recurs, les 40 cartes (cards.json) i el sprite
 *   (marc + índex, ids amb prefix «bx-» perquè no xoquin amb l'app), tots dos dins del bundle JS
 * - public/sw.js                 bloc BARALLA_PRECACHE
 */
import { createHash } from "node:crypto";
import { copyFileSync, mkdirSync, readFileSync, readdirSync, rmSync, statSync, writeFileSync } from "node:fs";
import { join, resolve } from "node:path";

const src = resolve(process.argv[2] ?? "/workspace/setimig/cartes-final");
const root = resolve(new URL("..", import.meta.url).pathname);
const outPublic = join(root, "public/baralla");

const hash8 = (file) => createHash("sha256").update(readFileSync(file)).digest("hex").slice(0, 8);
const declared = JSON.parse(readFileSync(join(src, "frame/hashes.json"), "utf8"));

rmSync(outPublic, { recursive: true, force: true });
mkdirSync(join(outPublic, "cares"), { recursive: true });

/** clau del paquet (p. ex. «cares/R-oros-280.avif») → URL servida */
const urls = {};
const sizes = {};
const mismatches = [];
function add(rel, destDir) {
  const file = join(src, rel);
  const h = hash8(file);
  if (declared[rel] && declared[rel] !== h) mismatches.push(`${rel}: hashes.json=${declared[rel]} real=${h}`);
  const name = rel.split("/").pop().replace(/\.(\w+)$/, `.${h}.$1`);
  copyFileSync(file, join(outPublic, destDir, name));
  urls[rel] = `/baralla/${destDir ? `${destDir}/` : ""}${name}`;
  sizes[rel] = statSync(file).size;
}

for (const f of readdirSync(join(src, "cares")).sort()) if (/\.(avif|webp)$/.test(f)) add(`cares/${f}`, "cares");
for (const f of ["fons-280.avif", "fons-280.webp", "fons-520.avif", "fons-520.webp"]) add(`frame/${f}`, "");
for (const f of ["dors-2x.webp", "dors-3x.webp"]) add(`dors/${f}`, "");

// Sprite: ids amb prefix perquè «marc», «placa», «foil»… no xoquin amb cap id de l'app.
let sprite = readFileSync(join(src, "frame/sprite.svg"), "utf8");
sprite = sprite
  .replace(/id="([^"]+)"/g, 'id="bx-$1"')
  .replace(/href="#([^"]+)"/g, 'href="#bx-$1"')
  .replace(/url\(#([^)]+)\)/g, "url(#bx-$1)");

const full = JSON.parse(readFileSync(join(src, "frame/cards.json"), "utf8"));
const slim = full.cards.map((c) => ({
  id: c.id,
  illus: c.illus,
  pips: c.pips ? { asset: c.pips.asset, items: c.pips.items.map(({ x, y, h }) => ({ x, y, h })) } : null,
}));

// Precache (nota-app-pwa.md): 280 de cada il·lustració, els 8 pips, els 2 fons i el revers 2x, en AVIF.
const precache = Object.keys(urls).filter(
  (k) =>
    (k.startsWith("cares/") && k.endsWith("-280.avif")) ||
    (k.startsWith("cares/pip-") && k.endsWith(".avif")) ||
    (k.startsWith("frame/fons-") && k.endsWith(".avif")) ||
    k === "dors/dors-2x.webp"
);
const precacheBytes = precache.reduce((s, k) => s + sizes[k], 0);

writeFileSync(
  join(root, "src/lib/barallaAssets.generated.ts"),
  `/* Generat per scripts/baralla-assets.mjs: no editar a mà. */\n` +
    `export const BARALLA_URLS: Readonly<Record<string, string>> = ${JSON.stringify(urls, null, 2)};\n\n` +
    `/** Recursos del precache del SW (${precache.length} fitxers, ${precacheBytes} bytes). */\n` +
    `export const BARALLA_PRECACHE: readonly string[] = ${JSON.stringify(precache.map((k) => urls[k]), null, 2)};\n\n` +
    `export type BarallaCard = { id: string; illus: string | null; pips: { asset: string; items: { x: number; y: number; h: number }[] } | null };\n` +
    `/** frame/cards.json: posicions en % de la carta. */\n` +
    `export const BARALLA_CARDS: readonly BarallaCard[] = ${JSON.stringify(slim)};\n\n` +
    `/** frame/sprite.svg (inline: els degradats no passen bé amb <use> extern). */\n` +
    `export const BARALLA_SPRITE = ${JSON.stringify(sprite)};\n`
);

const swPath = join(root, "public/sw.js");
const sw = readFileSync(swPath, "utf8");
const block =
  `// BARALLA:START (generat per scripts/baralla-assets.mjs; ${precache.length} fitxers, ${precacheBytes} bytes)\n` +
  `const BARALLA_PRECACHE = ${JSON.stringify(precache.map((k) => urls[k]), null, 2)};\n` +
  `// BARALLA:END`;
if (!/\/\/ BARALLA:START[\s\S]*?\/\/ BARALLA:END/.test(sw)) throw new Error("public/sw.js: falta el bloc BARALLA:START/END");
writeFileSync(swPath, sw.replace(/\/\/ BARALLA:START[\s\S]*?\/\/ BARALLA:END/, block));

console.log(JSON.stringify({ files: Object.keys(urls).length, precache: precache.length, precacheBytes, mismatches }, null, 1));
