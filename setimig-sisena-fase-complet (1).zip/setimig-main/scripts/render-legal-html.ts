/**
 * Prerender /privacy and /terms so crawlers get a real document, not the SPA shell.
 *
 *   /privacy      English, also hreflang x-default
 *   /privacy/ca   Catalan
 *   /privacy/es   Spanish
 *   /terms        English, also hreflang x-default
 *   /terms/ca     Catalan
 *   /terms/es     Spanish
 *
 * Vite copies public/ into dist/. server/staticLegalDocs.ts answers both the
 * slashless path and the trailing-slash path with 200 before the SPA fallback.
 *
 * Run: npx tsx scripts/render-legal-html.ts
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { LEGAL_DOC_PAGES, type LegalDocId, type LegalDocLang, type LegalDocPage } from "../shared/legalDocs.ts";
import { SITE_ORIGIN, absoluteUrl } from "../shared/seo.ts";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

const UI: Record<LegalDocLang, { languages: string; home: string; rules: string; footer: string }> = {
  en: {
    languages: "Languages",
    home: "Play",
    rules: "Rules",
    footer: "Seven Half Club · 18+ · no real money",
  },
  ca: {
    languages: "Idiomes",
    home: "Juga",
    rules: "Regles",
    footer: "Seven Half Club · 18+ · sense diners reals",
  },
  es: {
    languages: "Idiomas",
    home: "Jugar",
    rules: "Reglas",
    footer: "Seven Half Club · 18+ · sin dinero real",
  },
};

const LANG_LABEL: Record<LegalDocLang, string> = { en: "English", ca: "Català", es: "Español" };
const OG_LOCALE: Record<LegalDocLang, string> = { en: "en_US", ca: "ca_ES", es: "es_ES" };

function esc(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

function inline(source: string): string {
  const re = /(\*\*[^*]+\*\*|`[^`]+`|\[[^\]]+\]\([^)]+\))/g;
  let html = "";
  let last = 0;
  for (const match of source.matchAll(re)) {
    const index = match.index ?? 0;
    html += esc(source.slice(last, index));
    const token = match[0];
    if (token.startsWith("**")) html += `<strong>${esc(token.slice(2, -2))}</strong>`;
    else if (token.startsWith("`")) html += `<code>${esc(token.slice(1, -1))}</code>`;
    else {
      const link = /^\[([^\]]+)\]\(([^)]+)\)$/.exec(token);
      if (link) html += `<a href="${esc(link[2] ?? "")}">${esc(link[1] ?? "")}</a>`;
    }
    last = index + token.length;
  }
  html += esc(source.slice(last));
  return html;
}

function markdownToHtml(markdown: string): string {
  const blocks = markdown.trim().split(/\n{2,}/);
  return blocks
    .map((block) => {
      const lines = block.split("\n");
      const heading = /^(#{2,3})\s+(.+)$/.exec(lines[0] ?? "");
      if (heading && lines.length === 1) {
        const tag = heading[1] === "##" ? "h2" : "h3";
        return `<${tag}>${inline(heading[2] ?? "")}</${tag}>`;
      }
      if (lines.every((line) => line.startsWith("- "))) {
        return `<ul>${lines.map((line) => `<li>${inline(line.slice(2))}</li>`).join("")}</ul>`;
      }
      return `<p>${inline(lines.join(" "))}</p>`;
    })
    .join("\n");
}

function siblings(id: LegalDocId): LegalDocPage[] {
  return LEGAL_DOC_PAGES.filter((page) => page.id === id);
}

function render(page: LegalDocPage): string {
  const markdown = fs.readFileSync(path.join(root, "src/content/legal", `${page.id}.${page.lang}.md`), "utf8");
  const body = markdownToHtml(markdown);
  const ui = UI[page.lang];
  const canonical = absoluteUrl(page.path);
  const family = siblings(page.id);
  const hreflang = [
    ...family.map(
      (other) => `<link rel="alternate" hreflang="${other.lang}" href="${absoluteUrl(other.path)}" />`,
    ),
    `<link rel="alternate" hreflang="x-default" href="${absoluteUrl(family.find((other) => other.lang === "en")?.path ?? page.path)}" />`,
  ].join("\n    ");
  const languageNav = family
    .map((other) => {
      const current = other.path === page.path ? ' aria-current="page"' : "";
      return `<a href="${other.path}" hreflang="${other.lang}" lang="${other.lang}"${current}>${esc(LANG_LABEL[other.lang])}</a>`;
    })
    .join("\n");
  const otherId: LegalDocId = page.id === "privacy" ? "terms" : "privacy";
  const other = LEGAL_DOC_PAGES.find((item) => item.id === otherId && item.lang === page.lang);
  const jsonLd = JSON.stringify({
    "@context": "https://schema.org",
    "@type": "WebPage",
    name: page.title,
    description: page.description,
    url: canonical,
    inLanguage: page.lang,
    isPartOf: { "@type": "WebSite", name: "Seven Half Club", url: `${SITE_ORIGIN}/` },
  }).replace(/</g, "\\u003c");

  return `<!doctype html>
<html lang="${page.lang}">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="theme-color" content="#000000" />
    <meta name="robots" content="index, follow" />
    <title>${esc(page.title)}</title>
    <meta name="description" content="${esc(page.description)}" />
    <link rel="canonical" href="${canonical}" />
    ${hreflang}
    <meta property="og:type" content="website" />
    <meta property="og:locale" content="${OG_LOCALE[page.lang]}" />
    <meta property="og:title" content="${esc(page.title)}" />
    <meta property="og:description" content="${esc(page.description)}" />
    <meta property="og:url" content="${canonical}" />
    <meta property="og:image" content="${SITE_ORIGIN}/og-image.png" />
    <meta property="og:image:width" content="1200" />
    <meta property="og:image:height" content="630" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="${esc(page.title)}" />
    <meta name="twitter:description" content="${esc(page.description)}" />
    <meta name="twitter:image" content="${SITE_ORIGIN}/og-image.png" />
    <link rel="icon" href="/favicon-32.png" type="image/png" />
    <script type="application/ld+json">${jsonLd}</script>
    <style>
      :root { color-scheme: dark; }
      * { box-sizing: border-box; }
      html { background: #0b0b0b; }
      body {
        margin: 0;
        background: #0b0b0b;
        color: #f5f2eb;
        font: 17px/1.6 Georgia, "Noto Serif", serif;
      }
      a { color: #f5f2eb; }
      a:hover { color: #fff; }
      code { font: 0.92em/1.4 ui-monospace, monospace; }
      .wrap { width: min(42rem, calc(100% - 2rem)); margin: 0 auto; padding: 2rem 0 3rem; }
      header { border-bottom: 1px solid rgba(245, 242, 235, 0.28); padding-bottom: 1.25rem; }
      .brand { margin: 0; letter-spacing: 0.22em; text-transform: uppercase; font: 600 12px/1.4 system-ui, sans-serif; }
      h1 { margin: 0.4rem 0 0; font-size: 2.1rem; font-weight: 500; letter-spacing: -0.02em; }
      nav { display: flex; flex-wrap: wrap; gap: 0.75rem 1.25rem; margin: 1.25rem 0; font: 15px/1.4 system-ui, sans-serif; }
      nav a { text-underline-offset: 0.2em; }
      section, article > h2 { margin: 1.75rem 0 0.6rem; }
      h2 { margin: 1.75rem 0 0.6rem; font-size: 1.45rem; font-weight: 500; }
      p, li { margin: 0.45rem 0; }
      ul { padding-left: 1.2rem; }
      footer { margin-top: 2rem; padding-top: 1rem; border-top: 1px solid rgba(245, 242, 235, 0.28); font: 14px/1.5 system-ui, sans-serif; }
    </style>
  </head>
  <body>
    <div class="wrap">
      <header>
        <p class="brand">Seven Half Club</p>
        <h1>${esc(page.h1)}</h1>
      </header>
      <nav aria-label="${esc(ui.languages)}">
        ${languageNav}
      </nav>
      <nav aria-label="Seven Half Club">
        <a href="/">${esc(ui.home)}</a>
        <a href="/regles/">${esc(ui.rules)}</a>
        <a href="${other?.path ?? "/privacy"}">${esc(other?.h1 ?? "")}</a>
      </nav>
      <article>
        ${body}
      </article>
      <footer>
        <p>${esc(ui.footer)}</p>
        <p><a href="/">${esc(ui.home)}</a> · <a href="${other?.path ?? "/privacy"}">${esc(other?.h1 ?? "")}</a> · <a href="/regles/">${esc(ui.rules)}</a></p>
      </footer>
    </div>
  </body>
</html>
`;
}

for (const page of LEGAL_DOC_PAGES) {
  const file = path.join(root, "public", page.file);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, render(page));
}
