# Gate i desplegament des del VPS

Scripts bash per validar PRs, vigilar la cua i (opcionalment) desplegar des de `/home/ebernat/setimig`, sense `gh`.

## Token de GitHub

Crea un token **fine-grained** amb accés només al repositori `eedduuaarrd/setimig`:

| Permís | Accés |
|--------|--------|
| Contents | Read and write |
| Pull requests | Read and write |
| Metadata | Read (obligatori) |

Desa el token en una d'aquestes formes (mai el commitis al repo):

- Variable d'entorn `GITHUB_TOKEN`
- Fitxer `~/.config/setimig/github-token` (només el token, sense salts de línia extra)

Si no hi ha token, els scripts surten amb codi **2** i un missatge clar.

## Scripts

| Script | Descripció |
|--------|------------|
| `gate-pr.sh <num\|sha>` | Check, tests, e2e (3 specs), mesura APOSTAR; comentari al PR |
| `deploy-pr.sh <num> <sha>` | Gate + merge squash + `deploy.sh` + comprovacions producció |
| `pr-watch.sh` | PRs oberts amb SHA nou → `gate-pr` (registre en `~/.cache/setimig-gate/done.txt`) |
| `merge-zip.sh <zip>` | Integra un ZIP sobre `main` i executa el gate |
| `measure-apostar.mjs` | Mesura `bet-confirm` en 390×844, 375×667, 360×740 |

## Entorn

- Node: `/home/ebernat/.nvm/versions/node/v22.23.3/bin` (via `PATH`)
- Servei usuari: `systemctl --user setimig` (port **4450**, `/api/health`)
- Gate e2e: port **3177**, `node_modules` compartit des del repo principal (symlink)

## Cron (opcional)

El fitxer `crontab.txt` documenta una entrada cada 15 minuts (7–23h). **No s'instal·la automàticament**; copia-la manualment amb `crontab -e` si la vols activar.

## Ajuda

Tots els scripts accepten `--help`.
