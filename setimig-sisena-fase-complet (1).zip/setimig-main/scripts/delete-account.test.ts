import { after, before, describe, it } from "node:test";
import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import fs from "node:fs";
import net from "node:net";
import os from "node:os";
import path from "node:path";
import { main } from "./delete-account.ts";

/**
 * scripts/delete-account.ts: simulació per defecte (no escriu res), es nega amb el servidor en
 * marxa, còpia amb sha256 abans d'esborrar, només el compte indicat, idempotent, i --find.
 */
const A = "3288d5dd-prova-0000-0000-000000000001";
const B = "bbbbbbbb-altre-0000-0000-000000000002";
let dir: string;
let dataDir: string;
let backupDir: string;
let logs: string[];

const run = (args: string[]) => {
  logs = [];
  return main([...args, "--data-dir", dataDir, "--backup-dir", backupDir, "--service", "none", "--port", "0"], (s) => logs.push(s));
};
const sha = (f: string) => createHash("sha256").update(fs.readFileSync(f)).digest("hex");
function snapshot(): Record<string, string> {
  const out: Record<string, string> = {};
  const walk = (d: string) => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) walk(p);
      else out[path.relative(dataDir, p)] = sha(p);
    }
  };
  walk(dataDir);
  return out;
}
const write = (rel: string, data: unknown) => {
  fs.mkdirSync(path.dirname(path.join(dataDir, rel)), { recursive: true });
  fs.writeFileSync(path.join(dataDir, rel), JSON.stringify(data, null, 2), "utf8");
};

before(() => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), "setimig-delete-account-"));
  dataDir = path.join(dir, "data");
  backupDir = path.join(dir, "backup");
  process.env.SETIMIG_ANALYTICS_SALT = "sal-de-prova-0123456789abcdef";
  write("balances.json", { accounts: { [A]: { chips: 24_500 }, [B]: { chips: 777 } }, processedSessions: [] });
  write("identities.json", {
    version: 1,
    emails: { "grokcap-prod3@agentmail.to": A, "b@x.cat": B },
    google: {},
    passkeys: { k1: { playerId: A, publicKey: "x", counter: 0, name: "A", createdAt: 1 } },
    players: { [A]: { createdVia: "email" }, [B]: { createdVia: "email" } },
    log: [{ at: 1, type: "create", kind: "email", playerId: A }],
  });
  write(`profiles/${A}.json`, { displayName: "Provador QA", avatarDataUrl: null, updatedAt: 1 });
  write(`profiles/${B}.json`, { displayName: "Altre", avatarDataUrl: null, updatedAt: 1 });
  write("weekly-leaderboard/2026-W44.json", { version: 1, chipsWon: { [A]: 10, [B]: 20 } });
  write("friends.json", { players: { [A]: { friendCode: "FAAAA1", friendPlayerIds: [B] }, [B]: { friendCode: "FBBBB1", friendPlayerIds: [A] } }, friendCodeIndex: { FAAAA1: A, FBBBB1: B } });
});

after(() => fs.rmSync(dir, { recursive: true, force: true }));

describe("scripts/delete-account.ts", () => {
  it("--find per correu i per nom (només lectura)", async () => {
    const before1 = snapshot();
    assert.equal(await run(["--find", "grokcap-prod3"]), 0);
    assert.match(logs.join("\n"), new RegExp(`${A}\\tProvador QA\\tcorreu g\\*\\*\\*@agentmail\\.to`));
    assert.equal(await run(["--find", "altre"]), 0);
    assert.match(logs.join("\n"), new RegExp(`${B}\\tAltre\\tnom de perfil`));
    assert.deepEqual(snapshot(), before1);
  });

  it("simulació per defecte: llista i no escriu res", async () => {
    const before1 = snapshot();
    assert.equal(await run([A]), 0);
    const out = logs.join("\n");
    assert.match(out, /esborrar: saldo: 24500 fitxes/);
    assert.match(out, /esborrar: correus verificats: g\*\*\*@agentmail\.to/);
    assert.match(out, /esborrar: passkeys: 1/);
    assert.match(out, /SIMULACIÓ/);
    assert.deepEqual(snapshot(), before1);
    assert.equal(fs.existsSync(backupDir), false);
  });

  it("--apply amb el servidor en marxa: es nega i no escriu res", async () => {
    const srv = net.createServer();
    await new Promise<void>((r) => srv.listen(0, "127.0.0.1", r));
    const port = (srv.address() as net.AddressInfo).port;
    const before1 = snapshot();
    logs = [];
    const code = await main([A, "--apply", "--data-dir", dataDir, "--backup-dir", backupDir, "--service", "none", "--port", String(port)], (s) => logs.push(s));
    srv.close();
    assert.equal(code, 3);
    assert.match(logs.join("\n"), /ABORTAT/);
    assert.deepEqual(snapshot(), before1);
    assert.equal(fs.existsSync(backupDir), false);
  });

  it("--apply: còpia amb sha256, esborra només A, B intacte", async () => {
    const shaBefore: Record<string, string> = {};
    for (const f of ["balances.json", "identities.json", "friends.json", `profiles/${A}.json`]) shaBefore[f] = sha(path.join(dataDir, f));
    const profileB = sha(path.join(dataDir, `profiles/${B}.json`));
    assert.equal(await run([A, "--apply"]), 0, logs.join("\n"));
    assert.match(logs.join("\n"), /no queda cap dada/);
    const manifest = JSON.parse(fs.readFileSync(path.join(backupDir, "manifest.json"), "utf8"));
    for (const [rel, h] of Object.entries(shaBefore)) {
      const entry = manifest.files.find((x: any) => x.from === path.join(dataDir, rel));
      assert.ok(entry, `còpia de ${rel}`);
      assert.equal(entry.sha256, h);
      assert.equal(sha(entry.to), h);
    }
    const bal = JSON.parse(fs.readFileSync(path.join(dataDir, "balances.json"), "utf8"));
    assert.deepEqual(bal.accounts, { [B]: { chips: 777 } });
    const ids = JSON.parse(fs.readFileSync(path.join(dataDir, "identities.json"), "utf8"));
    assert.deepEqual(ids.emails, { "b@x.cat": B });
    assert.deepEqual(ids.passkeys, {});
    assert.deepEqual(Object.keys(ids.players), [B]);
    assert.equal(fs.existsSync(path.join(dataDir, `profiles/${A}.json`)), false);
    assert.equal(sha(path.join(dataDir, `profiles/${B}.json`)), profileB);
    const fr = JSON.parse(fs.readFileSync(path.join(dataDir, "friends.json"), "utf8"));
    assert.deepEqual(fr.players[B].friendPlayerIds, []);
    assert.deepEqual(fr.friendCodeIndex, { FBBBB1: B });
    const wk = JSON.parse(fs.readFileSync(path.join(dataDir, "weekly-leaderboard/2026-W44.json"), "utf8"));
    assert.deepEqual(wk.chipsWon, { [B]: 20 });
    assert.ok(fs.existsSync(path.join(dataDir, "deleted-accounts.json")));
  });

  it("idempotent: un segon --apply no canvia cap fitxer de dades", async () => {
    const before1 = snapshot();
    fs.rmSync(backupDir, { recursive: true, force: true });
    assert.equal(await run([A, "--apply"]), 0, logs.join("\n"));
    assert.match(logs.join("\n"), /JA ESBORRAT/);
    assert.deepEqual(snapshot(), before1);
  });
});
