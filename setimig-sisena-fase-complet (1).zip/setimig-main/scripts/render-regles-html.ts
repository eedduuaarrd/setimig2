/**
 * Prerender the static rules documents from the locale dictionaries.
 *
 * URL map (trailing slash; express.static 301s the bare path):
 *   /regles/     English, also hreflang x-default
 *   /regles/ca/  Catalan
 *   /regles/es/  Spanish
 *
 * Vite copies public/ into dist/; express.static serves these before the SPA
 * fallback, so server/ does not need a change.
 *
 * Run: npx tsx scripts/render-regles-html.ts
 */
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { COM_JUGAR_FAQ_IDS } from "../shared/comJugarFaq.ts";
import { BET_WINDOW_SEC, PLAY_WINDOW_SEC } from "../shared/turnTiming.ts";
import { SITE_ORIGIN, absoluteUrl } from "../shared/seo.ts";
import { ca, type Dict } from "../src/i18n/locales/ca.ts";
import { en } from "../src/i18n/locales/en.ts";
import { es } from "../src/i18n/locales/es.ts";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

const PAGES: { hreflang: string; path: string; file: string; dict: Dict }[] = [
  { hreflang: "en", path: "/regles/", file: "public/regles/index.html", dict: en },
  { hreflang: "ca", path: "/regles/ca/", file: "public/regles/ca/index.html", dict: ca },
  { hreflang: "es", path: "/regles/es/", file: "public/regles/es/index.html", dict: es },
];

function esc(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/** Existing copy uses **bold** markers. Render them; JSON-LD keeps the plain text. */
function rich(value: string): string {
  return value
    .split("**")
    .map((part, index) => (index % 2 === 1 ? `<strong>${esc(part)}</strong>` : esc(part)))
    .join("");
}

function fill(template: string, dict: Dict): string {
  return template
    .replaceAll("{game}", dict.brand.game)
    .replaceAll("{bet}", String(BET_WINDOW_SEC))
    .replaceAll("{play}", String(PLAY_WINDOW_SEC));
}

function faqItems(dict: Dict) {
  return COM_JUGAR_FAQ_IDS.map((id) => ({
    question: fill(dict.faq[id].q, dict),
    answer: fill(dict.faq[id].a, dict),
  }));
}

function jsonLd(data: unknown): string {
  return JSON.stringify(data).replace(/</g, "\\u003c");
}

function render(page: (typeof PAGES)[number]): string {
  const { dict } = page;
  const rules = dict.rules;
  const canonical = absoluteUrl(page.path);
  const questions = faqItems(dict);
  const guideHref = "/com-jugar";
  const guideLabel = fill(dict.guide.title, dict);
  const sections: { title: string; paragraphs: string[]; items: string[] }[] = [
    {
      title: rules.in30s,
      paragraphs: [],
      items: [
        rules.summary.deck,
        rules.summary.hidden,
        rules.summary.bankBust,
        rules.summary.bustLoses,
        fill(rules.summary.timers, dict),
      ],
    },
    { title: rules.objective.title, paragraphs: [rules.objective.body], items: [] },
    {
      title: rules.cards.title,
      paragraphs: [],
      items: [
        rules.cards.values,
        rules.cards.dealing,
        rules.cards.rotation,
        rules.cards.bankSevenHalf,
        rules.sheet.sevenHalfBank,
      ],
    },
    {
      title: rules.pay.title,
      paragraphs: [],
      items: [rules.pay.normal, rules.pay.natural, rules.pay.bankBust, rules.pay.bustLoses, rules.pay.coverage],
    },
    {
      title: rules.house.title,
      paragraphs: [rules.house.body],
      items: [
        rules.house.mort,
        rules.house.three,
        rules.house.four,
        rules.house.double,
        rules.house.split,
        rules.house.reveal,
      ],
    },
    { title: rules.private.title, paragraphs: [rules.private.body], items: [] },
  ];

  const sectionHtml = sections
    .map((section) => {
      const body = [
        ...section.paragraphs.map((paragraph) => `<p>${rich(paragraph)}</p>`),
        section.items.length
          ? `<ul>${section.items.map((item) => `<li>${rich(item)}</li>`).join("")}</ul>`
          : "",
      ].join("");
      return `<section><h2>${esc(section.title)}</h2>${body}</section>`;
    })
    .join("\n");

  const faqHtml = questions
    .map(
      (item) =>
        `<section><h3>${esc(item.question)}</h3><p>${rich(item.answer)}</p></section>`,
    )
    .join("\n");

  const languageNav = PAGES.map((other) => {
    const current = other.path === page.path ? ' aria-current="page"' : "";
    return `<a href="${other.path}" hreflang="${other.hreflang}"${current}>${esc(other.dict.seo.rules.title)}</a>`;
  }).join("\n");

  const hreflang = [
    ...PAGES.map(
      (other) =>
        `<link rel="alternate" hreflang="${other.hreflang}" href="${absoluteUrl(other.path)}" />`,
    ),
    `<link rel="alternate" hreflang="x-default" href="${absoluteUrl("/regles/")}" />`,
  ].join("\n    ");

  const gameLd = {
    "@context": "https://schema.org",
    "@type": "Game",
    name: "Seven Half Club",
    alternateName: ["7½", dict.brand.game],
    description: dict.seo.home.description,
    url: `${SITE_ORIGIN}/`,
    image: `${SITE_ORIGIN}/og-image.png`,
    inLanguage: page.hreflang,
    isAccessibleForFree: true,
    audience: { "@type": "PeopleAudience", requiredMinAge: 18 },
    playMode: ["SinglePlayer", "MultiPlayer"],
    gamePlatform: "Web browser",
  };

  const faqLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    inLanguage: page.hreflang,
    url: canonical,
    mainEntity: questions.map((item) => ({
      "@type": "Question",
      name: item.question,
      acceptedAnswer: { "@type": "Answer", text: item.answer },
    })),
  };

  return `<!doctype html>
<html lang="${page.hreflang}">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="theme-color" content="#000000" />
    <meta name="robots" content="index, follow" />
    <title>${esc(dict.seo.rules.title)}</title>
    <meta name="description" content="${esc(dict.seo.rules.description)}" />
    <link rel="canonical" href="${canonical}" />
    ${hreflang}
    <meta property="og:type" content="website" />
    <meta property="og:title" content="${esc(dict.seo.rules.title)}" />
    <meta property="og:description" content="${esc(dict.seo.rules.description)}" />
    <meta property="og:url" content="${canonical}" />
    <meta property="og:image" content="${SITE_ORIGIN}/og-image.png" />
    <meta property="og:image:width" content="1200" />
    <meta property="og:image:height" content="630" />
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:title" content="${esc(dict.seo.rules.title)}" />
    <meta name="twitter:description" content="${esc(dict.seo.rules.description)}" />
    <meta name="twitter:image" content="${SITE_ORIGIN}/og-image.png" />
    <link rel="icon" href="/favicon-32.png" type="image/png" />
    <script type="application/ld+json">${jsonLd(gameLd)}</script>
    <script type="application/ld+json">${jsonLd(faqLd)}</script>
    <style>
      :root { color-scheme: dark; }
      * { box-sizing: border-box; }
      html { background: #0b0b0b; }
      body {
        margin: 0;
        background: #0b0b0b;
        color: #f5f2eb;
        font: 17px/1.6 Georgia, "Noto Serif", serif;
      }
      a { color: #f5f2eb; }
      a:hover { color: #fff; }
      .wrap { width: min(42rem, calc(100% - 2rem)); margin: 0 auto; padding: 2rem 0 3rem; }
      header { border-bottom: 1px solid rgba(245, 242, 235, 0.28); padding-bottom: 1.25rem; }
      .brand { margin: 0; letter-spacing: 0.22em; text-transform: uppercase; font: 600 12px/1.4 system-ui, sans-serif; }
      h1 { margin: 0.4rem 0 0; font-size: 2.1rem; font-weight: 500; letter-spacing: -0.02em; }
      nav { display: flex; flex-wrap: wrap; gap: 0.75rem 1.25rem; margin: 1.25rem 0; font: 15px/1.4 system-ui, sans-serif; }
      nav a { text-underline-offset: 0.2em; }
      img.mark { display: block; width: 8.5rem; height: auto; margin: 1.25rem 0 0; }
      section { margin: 1.75rem 0; }
      h2 { margin: 0 0 0.6rem; font-size: 1.45rem; font-weight: 500; }
      h3 { margin: 0 0 0.35rem; font-size: 1.12rem; font-weight: 600; }
      p, li { margin: 0.45rem 0; }
      ul { padding-left: 1.2rem; }
      footer { margin-top: 2rem; padding-top: 1rem; border-top: 1px solid rgba(245, 242, 235, 0.28); font: 14px/1.5 system-ui, sans-serif; }
    </style>
  </head>
  <body>
    <div class="wrap">
      <header>
        <p class="brand">Seven Half Club</p>
        <h1>${esc(rules.title)}</h1>
        <img class="mark" src="/icon-512.png" width="512" height="512" alt="${esc(dict.seo.ogImageAlt)}" />
      </header>
      <nav aria-label="${esc(dict.brand.club)}">
        <a href="/">${esc(dict.brand.club)}</a>
        <a href="${guideHref}">${esc(guideLabel)}</a>
        ${languageNav}
      </nav>
      <p>${esc(rules.fullGuideAt)} <a href="${guideHref}">${esc(guideLabel)}</a>.</p>
      <article>
        ${sectionHtml}
        <section id="faq">
          <h2>${esc(dict.guide.toc.faq)}</h2>
          ${faqHtml}
        </section>
      </article>
      <footer>
        <p>${esc(dict.brand.adultsNoMoney)}</p>
        <p><a href="/">${esc(dict.lobby.playNow)}</a></p>
      </footer>
    </div>
  </body>
</html>
`;
}

for (const page of PAGES) {
  const file = path.join(root, page.file);
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, render(page));
  console.log(page.file);
}
