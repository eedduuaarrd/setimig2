import { defineConfig, devices } from "@playwright/test";

const appUrl = process.env.APP_URL ?? "http://127.0.0.1:3177";

export default defineConfig({
  testDir: "../e2e",
  testMatch: [
    "estetica-formal-layout.spec.ts",
    "fix-mobil-torn-central.spec.ts",
    "iphone-safearea-solo-start.spec.ts",
  ],
  timeout: 180_000,
  retries: 0,
  projects: [
    {
      name: "gate-chromium",
      use: {
        ...devices["Pixel 5"],
        browserName: "chromium",
        baseURL: appUrl,
        screenshot: "off",
        trace: "off",
      },
    },
  ],
  use: {
    baseURL: appUrl,
    screenshot: "off",
    trace: "off",
  },
});
