#!/usr/bin/env bash
# Camins i entorn per scripts al VPS.

SETIMIG_NODE_BIN_DIR="${SETIMIG_NODE_BIN_DIR:-/home/ebernat/.nvm/versions/node/v22.23.3/bin}"
SETIMIG_REPO="${SETIMIG_REPO:-${HOME}/setimig}"
SETIMIG_GATE_PORT="${SETIMIG_GATE_PORT:-3177}"
SETIMIG_PROD_PORT="${SETIMIG_PROD_PORT:-4450}"
SETIMIG_PROD_URL="${SETIMIG_PROD_URL:-https://setimig.supercbb.com}"

setimig_export_path() {
  export PATH="${SETIMIG_NODE_BIN_DIR}:${PATH}"
}

setimig_wait_health() {
  local base_url="$1"
  local attempts="${2:-60}"
  local i=0
  while (( i < attempts )); do
    if curl -fsS "${base_url%/}/api/health" >/dev/null 2>&1; then
      return 0
    fi
    sleep 1
    i=$((i + 1))
  done
  echo "Health check timeout: ${base_url}/api/health" >&2
  return 1
}

setimig_sw_cache_version() {
  local sw_url="$1"
  curl -fsS "$sw_url" | sed -n 's/^const CACHE_VERSION = "\([^"]*\)".*/\1/p' | head -1
}
