#!/usr/bin/env bash
# Funcions compartides per l'API REST de GitHub (sense gh).
# No imprimeix mai el token.

GITHUB_API_REPO="${GITHUB_API_REPO:-eedduuaarrd/setimig}"

github_token() {
  if [[ -n "${GITHUB_TOKEN:-}" ]]; then
    printf '%s' "$GITHUB_TOKEN"
    return 0
  fi
  local token_file="${HOME}/.config/setimig/github-token"
  if [[ -f "$token_file" ]]; then
    cat "$token_file"
    return 0
  fi
  echo "No s'ha trobat cap token de GitHub. Define GITHUB_TOKEN o crea ${token_file}." >&2
  exit 2
}

github_api() {
  local method="${1:-GET}"
  local path="$2"
  local data="${3:-}"
  local token
  token="$(github_token)"
  local url="https://api.github.com${path}"
  local -a curl_args=(
    -sS
    -X "$method"
    -H "Accept: application/vnd.github+json"
    -H "Authorization: Bearer ${token}"
    -H "X-GitHub-Api-Version: 2022-11-28"
  )
  if [[ -n "$data" ]]; then
    curl_args+=(-H "Content-Type: application/json" -d "$data")
  fi
  curl "${curl_args[@]}" "$url"
}

github_pr_head_sha() {
  local pr_num="$1"
  github_api GET "/repos/${GITHUB_API_REPO}/pulls/${pr_num}" | node -e '
    let s=""; process.stdin.on("data",d=>s+=d); process.stdin.on("end",()=>{
      const j=JSON.parse(s);
      if(j.message){ console.error(j.message); process.exit(1); }
      process.stdout.write(j.head.sha);
    });
  '
}

github_prs_for_sha() {
  local sha="$1"
  github_api GET "/repos/${GITHUB_API_REPO}/commits/${sha}/pulls"
}

github_list_open_prs() {
  github_api GET "/repos/${GITHUB_API_REPO}/pulls?state=open&per_page=100"
}

github_post_pr_comment() {
  local pr_num="$1"
  local body="$2"
  local payload
  payload="$(printf '%s' "$body" | node -e '
    const fs = require("fs");
    const b = fs.readFileSync(0, "utf8");
    process.stdout.write(JSON.stringify({ body: b }));
  ')"
  github_api POST "/repos/${GITHUB_API_REPO}/issues/${pr_num}/comments" "$payload" >/dev/null
}

github_squash_merge_pr() {
  local pr_num="$1"
  local sha="$2"
  local title
  title="$(github_api GET "/repos/${GITHUB_API_REPO}/pulls/${pr_num}" | node -e '
    let s=""; process.stdin.on("data",d=>s+=d); process.stdin.on("end",()=>{
      const j=JSON.parse(s);
      if(j.message){ console.error(j.message); process.exit(1); }
      process.stdout.write(j.title||"Merge PR #"+process.argv[1]);
    });
  ' "$pr_num")"
  local payload
  payload="$(node -e '
    const [sha, title] = process.argv.slice(1);
    process.stdout.write(JSON.stringify({
      merge_method: "squash",
      sha,
      commit_title: title,
    }));
  ' "$sha" "$title")"
  github_api PUT "/repos/${GITHUB_API_REPO}/pulls/${pr_num}/merge" "$payload"
}
