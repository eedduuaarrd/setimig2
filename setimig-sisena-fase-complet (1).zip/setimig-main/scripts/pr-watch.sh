#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib/setimig-env.sh
source "${SCRIPT_DIR}/lib/setimig-env.sh"
# shellcheck source=lib/github-api.sh
source "${SCRIPT_DIR}/lib/github-api.sh"

CACHE_DIR="${HOME}/.cache/setimig-gate"
DONE_FILE="${CACHE_DIR}/done.txt"
LOCK_FILE="${CACHE_DIR}/watch.lock"

usage() {
  cat <<'EOF'
Ús: pr-watch.sh [--help]

Consulta PRs oberts i executa gate-pr.sh una vegada per cada head SHA nou.
Registre: ~/.cache/setimig-gate/done.txt (lock amb flock).
No desplega.
EOF
}

main() {
  if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
    usage
    exit 0
  fi

  setimig_export_path
  mkdir -p "$CACHE_DIR"
  touch "$DONE_FILE"

  exec 9>"$LOCK_FILE"
  if ! flock -n 9; then
    echo "Un altre pr-watch està en curs; surto." >&2
    exit 0
  fi

  local prs_json
  prs_json="$(github_list_open_prs)"

  node -e '
    const prs = JSON.parse(process.argv[1]);
    if (!Array.isArray(prs)) {
      console.error(prs.message || "Resposta PR invàlida");
      process.exit(1);
    }
    for (const pr of prs) {
      process.stdout.write(`${pr.number}\t${pr.head.sha}\n`);
    }
  ' "$prs_json" | while IFS=$'\t' read -r num sha; do
    [[ -z "$num" || -z "$sha" ]] && continue
    if grep -qxF "$sha" "$DONE_FILE"; then
      echo "SHA ${sha:0:8} (PR #${num}) ja processat; ometo."
      continue
    fi
    echo "=== Gate PR #${num} (${sha:0:8}) ==="
    if "${SCRIPT_DIR}/gate-pr.sh" "$num"; then
      echo "$sha" >> "$DONE_FILE"
    else
      echo "Gate fallit per PR #${num}; no marco el SHA com fet." >&2
    fi
  done
}

main "$@"
