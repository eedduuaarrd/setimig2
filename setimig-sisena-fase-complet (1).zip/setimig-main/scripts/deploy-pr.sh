#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib/setimig-env.sh
source "${SCRIPT_DIR}/lib/setimig-env.sh"
# shellcheck source=lib/github-api.sh
source "${SCRIPT_DIR}/lib/github-api.sh"

usage() {
  cat <<'EOF'
Ús: deploy-pr.sh <num_pr> <sha_commit> [--help]

Executa gate-pr; si tot és OK, merge squash del PR (sha = head commit),
còpia de seguretat de data/, deploy.sh, health, SW i mesura APOSTAR en producció.

Si gate-pr o la verificació pre-merge fallen, no es fa merge.
EOF
}

main() {
  if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
    usage
    exit 0
  fi
  if [[ $# -lt 2 ]]; then
    usage >&2
    exit 1
  fi

  local pr_num="$1"
  local expected_sha="$2"
  if [[ ${#expected_sha} -lt 40 ]]; then
    expected_sha="$(git -C "${SETIMIG_REPO}" rev-parse "${expected_sha}^{commit}")"
  fi

  setimig_export_path

  local head_sha
  head_sha="$(github_pr_head_sha "$pr_num")"
  if [[ "$head_sha" != "$expected_sha" ]]; then
    echo "El SHA del PR (#${pr_num}) és ${head_sha}, no ${expected_sha}." >&2
    exit 1
  fi

  echo "=== Gate pre-merge ==="
  "${SCRIPT_DIR}/gate-pr.sh" "$pr_num"

  echo "=== Merge squash ==="
  local merge_resp
  merge_resp="$(github_squash_merge_pr "$pr_num" "$expected_sha")"
  if ! node -e '
    const j=JSON.parse(process.argv[1]);
    if(!j.merged){ console.error(j.message||JSON.stringify(j)); process.exit(1); }
  ' "$merge_resp"; then
    echo "Merge fallit." >&2
    exit 1
  fi

  # Còpia a disc (no a /tmp, que al VPS és RAM i es neteja).
  local backup_root="${SETIMIG_BACKUP_DIR:-$HOME/setimig-backups}"
  mkdir -p "$backup_root"
  local backup="${backup_root}/data-bak-$(date +%s)"
  echo "=== Còpia data/ → ${backup} ==="
  cp -a "${SETIMIG_REPO}/data" "$backup"

  echo "=== deploy.sh ==="
  (cd "${SETIMIG_REPO}" && ./deploy.sh)

  local prod_url="${SETIMIG_PROD_URL}"
  local local_health="http://127.0.0.1:${SETIMIG_PROD_PORT}"

  echo "=== Health local ${local_health} ==="
  setimig_wait_health "$local_health"

  echo "=== Versió SW en producció ==="
  local sw_ver
  sw_ver="$(setimig_sw_cache_version "${prod_url}/sw.js")"
  if [[ -z "$sw_ver" ]]; then
    echo "No s'ha pogut llegir CACHE_VERSION de ${prod_url}/sw.js" >&2
    exit 1
  fi
  echo "SW producció: ${sw_ver}"

  echo "=== Mesura APOSTAR producció ==="
  APP_URL="${prod_url}" node "${SCRIPT_DIR}/measure-apostar.mjs"

  echo "Desplegament completat (PR #${pr_num}, ${expected_sha})."
}

main "$@"
