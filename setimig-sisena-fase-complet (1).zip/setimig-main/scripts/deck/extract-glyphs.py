#!/usr/bin/env python3
"""Extreu els contorns de Cormorant Garamond (OFL-1.1) per a scripts/gen-deck.ts.

Ús: python3 scripts/deck/extract-glyphs.py CormorantGaramond.ttf > scripts/deck/glyphs.json
Requereix fontTools. Només cal tornar-lo a executar si canvia la font o els caràcters.
"""
import json, sys
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont
from fontTools.pens.recordingPen import RecordingPen

SETS = {"600": "0123456789", "500": "SOTACVLREI"}

def glyphs(path, wght, chars):
    font = instantiateVariableFont(TTFont(path), {"wght": int(wght)})
    cmap, gs, hmtx = font.getBestCmap(), font.getGlyphSet(), font["hmtx"]
    out = {}
    for ch in chars:
        name = cmap[ord(ch)]
        pen = RecordingPen()
        gs[name].draw(pen)
        cmds = []
        for op, pts in pen.value:
            if op == "moveTo":
                cmds.append(["M", *[c for p in pts for c in (p[0], -p[1])]])
            elif op == "lineTo":
                cmds.append(["L", *[c for p in pts for c in (p[0], -p[1])]])
            elif op == "qCurveTo":
                # descompon les corbes TrueType amb punts implícits
                pts = list(pts)
                if pts[-1] is None:
                    raise SystemExit("contorn sense punts on-curve")
                while len(pts) > 2:
                    a, b = pts[0], pts[1]
                    mid = ((a[0] + b[0]) / 2, (a[1] + b[1]) / 2)
                    cmds.append(["Q", a[0], -a[1], mid[0], -mid[1]])
                    pts = pts[1:]
                a, b = pts
                cmds.append(["Q", a[0], -a[1], b[0], -b[1]])
            elif op == "curveTo":
                cmds.append(["C", *[c for p in pts for c in (p[0], -p[1])]])
            elif op in ("closePath", "endPath"):
                cmds.append(["Z"])
        out[ch] = {"adv": hmtx[name][0], "d": cmds}
    return out

if __name__ == "__main__":
    src = sys.argv[1]
    data = {"font": "Cormorant Garamond (SIL OFL-1.1)", "unitsPerEm": 1000,
            "weights": {w: glyphs(src, w, c) for w, c in SETS.items()}}
    json.dump(data, sys.stdout, separators=(",", ":"))
    sys.stdout.write("\n")
