import { describe, it, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import net from "node:net";
import { main, loadList, restoreMarker, rollbackMarker } from "./restore-balances.ts";

/**
 * scripts/restore-balances.ts: simulació sense escriure, aplicació una sola vegada, idempotència,
 * guarda amb saldo diferent, la resta de comptes idèntics byte a byte, desfer i negar-se amb el
 * servidor en marxa sobre les mateixes dades.
 */

const TARGET = "8a9743b8-b862-4ca7-995b-8b2f4303a167";
const OTHER_A = "ba3ca7e1-4131-45f6-8c98-c058d88e643c";
const OTHER_B = "0aac95f1-29d6-4412-8be1-11056ec3b530";
const RID = "test-saldos-v1";

let dir: string;
let dataDir: string;
let backupDir: string;
let listFile: string;
let logs: string[];

function writeStore(store: unknown) {
  fs.writeFileSync(path.join(dataDir, "balances.json"), JSON.stringify(store, null, 2), "utf8");
}

function readText(): string {
  return fs.readFileSync(path.join(dataDir, "balances.json"), "utf8");
}

function readStore(): any {
  return JSON.parse(readText());
}

function baseStore(targetChips = 2_100) {
  return {
    accounts: {
      [OTHER_A]: { chips: 1_900, lastClaimAt: null },
      [TARGET]: { chips: targetChips, lastClaimAt: 1793045168663 },
      [OTHER_B]: { chips: 1_700, lastClaimAt: null },
    },
    processedSessions: ["cs_test_existing"],
    openSoloBuyIns: {},
  };
}

/** Bloc de text exacte d'un compte dins el fitxer (serialització de 2 espais del servidor). */
function accountBlock(text: string, id: string): string {
  const start = text.indexOf(`"${id}"`);
  assert.ok(start >= 0, `compte ${id} present`);
  const end = text.indexOf("}", start);
  return text.slice(start, end + 1);
}

function run(...args: string[]): Promise<number> {
  return main(
    ["--list", listFile, "--data-dir", dataDir, "--backup-dir", backupDir, "--service", "none", "--port", "0", ...args],
    (s) => logs.push(s)
  );
}

describe("scripts/restore-balances.ts", () => {
  beforeEach(() => {
    dir = fs.mkdtempSync(path.join(os.tmpdir(), "setimig-restore-"));
    dataDir = path.join(dir, "data");
    backupDir = path.join(dir, "backup");
    fs.mkdirSync(dataDir);
    listFile = path.join(dir, "list.json");
    fs.writeFileSync(
      listFile,
      JSON.stringify({
        rid: RID,
        entries: [{ playerId: TARGET, expectedCurrent: 2_100, increment: 44_650, reason: "prova" }],
      })
    );
    writeStore(baseStore());
    logs = [];
  });

  afterEach(() => {
    fs.rmSync(dir, { recursive: true, force: true });
  });

  it("la llista real del repositori és vàlida: 8a9743b8 +44.650 sobre 2.100", () => {
    const list = loadList(path.join(path.dirname(new URL(import.meta.url).pathname), "restauracions", "2026-10-27-saldos-v1.json"));
    assert.equal(list.entries.length, 1);
    assert.deepEqual(
      { playerId: list.entries[0]!.playerId, expectedCurrent: list.entries[0]!.expectedCurrent, increment: list.entries[0]!.increment },
      { playerId: TARGET, expectedCurrent: 2_100, increment: 44_650 }
    );
  });

  it("simulació (per defecte): no escriu res ni crea la còpia", async () => {
    const before = readText();
    const mtime = fs.statSync(path.join(dataDir, "balances.json")).mtimeMs;
    assert.equal(await run(), 0);
    assert.equal(readText(), before);
    assert.equal(fs.statSync(path.join(dataDir, "balances.json")).mtimeMs, mtime);
    assert.equal(fs.existsSync(backupDir), false);
    assert.ok(logs.some((l) => l.includes("SIMULACIÓ: no s'ha escrit res")));
    assert.ok(logs.some((l) => l.includes("objectiu 46.750") && l.includes("s'aplicaria")));
    assert.ok(!logs.join("\n").includes(TARGET), "l'id surt emmascarat");
  });

  it("--apply abona exactament una vegada, amb marca i còpia; la resta de comptes queden idèntics byte a byte", async () => {
    const beforeText = readText();
    assert.equal(await run("--apply"), 0);
    const after = readStore();
    assert.equal(after.accounts[TARGET].chips, 46_750);
    assert.equal(after.accounts[TARGET].lastClaimAt, 1793045168663, "es conserva lastClaimAt");
    assert.ok(after.processedSessions.includes(restoreMarker(RID, TARGET)));
    assert.ok(after.processedSessions.includes("cs_test_existing"));
    assert.deepEqual(after.openSoloBuyIns, {});
    const afterText = readText();
    for (const id of [OTHER_A, OTHER_B]) assert.equal(accountBlock(afterText, id), accountBlock(beforeText, id));
    assert.equal(fs.readFileSync(path.join(backupDir, "balances.json"), "utf8"), beforeText, "còpia idèntica a l'original");
    assert.ok(logs.some((l) => l.includes("APLICAT 8a9743b8…: 2.100 → 46.750 (+44.650)")));
    assert.ok(logs.some((l) => l.includes("2 altres comptes idèntics: SÍ")));
  });

  it("idempotent: una segona execució no fa res i ho diu (fitxer intacte)", async () => {
    assert.equal(await run("--apply"), 0);
    const once = readText();
    logs = [];
    assert.equal(await run("--apply"), 0);
    assert.equal(readText(), once);
    assert.equal(readStore().accounts[TARGET].chips, 46_750);
    assert.ok(logs.some((l) => l.includes("ja aplicat (marca present)")));
    assert.ok(logs.some((l) => l.includes("Res a fer")));
    logs = [];
    assert.equal(await run(), 0, "la simulació posterior també ho diu");
    assert.ok(logs.some((l) => l.includes("ja aplicat")));
  });

  it("guarda: si el saldo actual no és l'esperat, s'atura sense escriure res", async () => {
    writeStore(baseStore(2_350));
    const before = readText();
    assert.equal(await run("--apply"), 3);
    assert.equal(readText(), before);
    assert.equal(fs.existsSync(backupDir), false);
    assert.ok(logs.some((l) => l.includes("NO QUADRA")));
    assert.ok(logs.some((l) => l.includes("ABORTAT")));
    assert.equal(await run(), 3, "la simulació també avisa");
  });

  it("--rollback desfà amb increment negatiu i marca restore-rollback:, una sola vegada", async () => {
    logs = [];
    assert.equal(await run("--rollback"), 3, "sense restauració aplicada no hi ha res a desfer");
    assert.ok(logs.some((l) => l.includes("no hi ha cap restauració aplicada")));
    assert.equal(await run("--apply"), 0);
    logs = [];
    assert.equal(await run("--rollback"), 0);
    const after = readStore();
    assert.equal(after.accounts[TARGET].chips, 2_100);
    assert.ok(after.processedSessions.includes(rollbackMarker(RID, TARGET)));
    assert.ok(logs.some((l) => l.includes("APLICAT 8a9743b8…: 46.750 → 2.100 (-44.650)")));
    const once = readText();
    assert.equal(await run("--rollback"), 0);
    assert.equal(readText(), once, "desfer també és idempotent");
  });

  it("es nega a aplicar si el servidor sembla en marxa i les dades són les del servei", async () => {
    const srv = net.createServer();
    await new Promise<void>((resolve) => srv.listen(0, "127.0.0.1", () => resolve()));
    const port = (srv.address() as net.AddressInfo).port;
    try {
      const before = readText();
      const code = await main(
        ["--list", listFile, "--data-dir", dataDir, "--backup-dir", backupDir, "--service", "none", "--port", String(port), "--service-dir", dir, "--apply"],
        (s) => logs.push(s)
      );
      assert.equal(code, 4);
      assert.equal(readText(), before);
      assert.equal(fs.existsSync(backupDir), false);
      assert.ok(logs.some((l) => l.includes("ABORTAT") && l.includes(`port ${port}`)));
      // Amb el servidor en marxa però dades d'una còpia fora del servei: es permet (amb avís).
      logs = [];
      const other = fs.mkdtempSync(path.join(os.tmpdir(), "setimig-restore-svc-"));
      try {
        const ok = await main(
          ["--list", listFile, "--data-dir", dataDir, "--backup-dir", backupDir, "--service", "none", "--port", String(port), "--service-dir", other, "--apply"],
          (s) => logs.push(s)
        );
        assert.equal(ok, 0);
        assert.ok(logs.some((l) => l.startsWith("Avís:")));
      } finally {
        fs.rmSync(other, { recursive: true, force: true });
      }
    } finally {
      srv.close();
    }
  });
});
