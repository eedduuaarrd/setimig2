#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib/setimig-env.sh
source "${SCRIPT_DIR}/lib/setimig-env.sh"
# shellcheck source=lib/github-api.sh
source "${SCRIPT_DIR}/lib/github-api.sh"

usage() {
  cat <<'EOF'
Ús: gate-pr.sh <num_pr|sha_commit> [--help]

Executa el gate de qualitat per un PR o un SHA:
  check, tests (amb reintent condicionat), e2e Playwright, mesura APOSTAR.
Publica un comentari al PR si es coneix el número.

Variables: SETIMIG_REPO, SETIMIG_GATE_PORT, GITHUB_TOKEN.
EOF
}

PR_NUM=""
TARGET_SHA=""
INPUT_KIND=""

resolve_input() {
  local arg="$1"
  if [[ "$arg" =~ ^[0-9]+$ ]]; then
    PR_NUM="$arg"
    INPUT_KIND="pr"
    TARGET_SHA="$(github_pr_head_sha "$PR_NUM")"
  elif [[ "$arg" =~ ^[0-9a-fA-F]{7,40}$ ]]; then
    TARGET_SHA="$arg"
    if [[ ${#TARGET_SHA} -lt 40 ]]; then
      TARGET_SHA="$(git -C "${SETIMIG_REPO}" rev-parse "${TARGET_SHA}^{commit}")"
    fi
    INPUT_KIND="sha"
    local pulls_json
    pulls_json="$(github_prs_for_sha "$TARGET_SHA")"
    PR_NUM="$(node -e '
      const j=JSON.parse(process.argv[1]);
      if(!Array.isArray(j)||!j.length) process.exit(0);
      const open=j.find(p=>p.state==="open")||j[0];
      process.stdout.write(String(open.number));
    ' "$pulls_json" 2>/dev/null || true)"
  else
    echo "Entrada no vàlida: $arg (esperat número de PR o SHA)" >&2
    exit 1
  fi
}

WORKTREE=""
SERVER_PID=""
GATE_PORT="${SETIMIG_GATE_PORT}"
APP_URL="http://127.0.0.1:${GATE_PORT}"

declare -A STEP_STATUS=()
MEASURE_LINES=""

cleanup() {
  local ec=$?
  if [[ -n "$SERVER_PID" ]] && kill -0 "$SERVER_PID" 2>/dev/null; then
    kill "$SERVER_PID" 2>/dev/null || true
    wait "$SERVER_PID" 2>/dev/null || true
  fi
  if [[ -n "$WORKTREE" && -d "$WORKTREE" ]]; then
    git -C "${SETIMIG_REPO}" worktree remove -f "$WORKTREE" 2>/dev/null || rm -rf "$WORKTREE"
  fi
  if [[ $ec -ne 0 ]]; then
    exit "$ec"
  fi
}
trap cleanup EXIT INT TERM

run_check() {
  (cd "$WORKTREE" && npm run check)
}

test_only_flaky_private() {
  local log_file="$1"
  if ! grep -qE 'not ok |✖ ' "$log_file"; then
    return 1
  fi
  local files
  files="$(grep -oE '(server|shared|src)/[a-zA-Z0-9_./-]+\.test\.ts' "$log_file" | sort -u || true)"
  if [[ -z "$files" ]]; then
    return 1
  fi
  while IFS= read -r f; do
    [[ -z "$f" ]] && continue
    case "$f" in
      *privateRooms*|*playerToken*) ;;
      *) return 1 ;;
    esac
  done <<< "$files"
  return 0
}

run_unit_tests() {
  local log
  log="$(mktemp)"
  set +e
  (cd "$WORKTREE" && SETIMIG_TEST_FAST=1 npm test) 2>&1 | tee "$log"
  local code=${PIPESTATUS[0]}
  set -e
  if [[ $code -eq 0 ]]; then
    rm -f "$log"
    return 0
  fi
  if test_only_flaky_private "$log"; then
    echo "Reintent de npm test (només fallades privateRooms/playerToken)…" >&2
    set +e
    (cd "$WORKTREE" && SETIMIG_TEST_FAST=1 npm test) 2>&1 | tee "$log"
    code=${PIPESTATUS[0]}
    set -e
  fi
  rm -f "$log"
  return "$code"
}

start_gate_server() {
  (
    cd "$WORKTREE"
    export NODE_ENV=production
    export PORT="${GATE_PORT}"
    export APP_URL="${APP_URL}"
    export PLAYER_TOKEN_SECRET="${PLAYER_TOKEN_SECRET:-playwright-e2e-test-secret}"
    exec npm run start
  ) &
  SERVER_PID=$!
  setimig_wait_health "$APP_URL"
}

run_playwright() {
  (
    cd "$WORKTREE"
    export APP_URL="${APP_URL}"
    npx playwright test --config=scripts/playwright-gate.config.ts
  )
}

run_measure() {
  local out
  set +e
  out="$(cd "$WORKTREE" && APP_URL="${APP_URL}" node scripts/measure-apostar.mjs 2>&1)"
  local code=$?
  set -e
  MEASURE_LINES="$out"
  echo "$out"
  return "$code"
}

build_summary() {
  local overall="$1"
  {
    echo "## Gate Set i Mig"
    echo ""
    echo "SHA: \`${TARGET_SHA}\`${PR_NUM:+" · PR #${PR_NUM}"}"
    echo ""
    echo "| Pas | Estat |"
    echo "|-----|-------|"
    for step in check test e2e apostar; do
      echo "| ${step} | ${STEP_STATUS[$step]:-SKIP} |"
    done
    echo ""
    echo "**Resultat global:** ${overall}"
    if [[ -n "$MEASURE_LINES" ]]; then
      echo ""
      echo "### Mesures APOSTAR"
      echo '```'
      echo "$MEASURE_LINES"
      echo '```'
    fi
  }
}

post_summary() {
  local overall="$1"
  local body
  body="$(build_summary "$overall")"
  echo "$body"
  if [[ -n "$PR_NUM" ]]; then
    github_post_pr_comment "$PR_NUM" "$body" || echo "No s'ha pogut publicar el comentari al PR #${PR_NUM}" >&2
  fi
}

main() {
  if [[ "${1:-}" == "--help" || "${1:-}" == "-h" ]]; then
    usage
    exit 0
  fi
  if [[ $# -lt 1 ]]; then
    usage >&2
    exit 1
  fi

  setimig_export_path
  resolve_input "$1"

  if [[ -n "$PR_NUM" ]]; then
    WORKTREE="/tmp/sm-pr${PR_NUM}"
  else
    WORKTREE="/tmp/sm-pr-sha-${TARGET_SHA:0:8}"
  fi
  rm -rf "$WORKTREE"

  git -C "${SETIMIG_REPO}" fetch origin "${TARGET_SHA}" --depth=1 2>/dev/null || git -C "${SETIMIG_REPO}" fetch origin
  git -C "${SETIMIG_REPO}" worktree add -f "$WORKTREE" "$TARGET_SHA"
  ln -sfn "${SETIMIG_REPO}/node_modules" "${WORKTREE}/node_modules"

  local fail=0

  if run_check; then STEP_STATUS[check]=OK; else STEP_STATUS[check]=FAIL; fail=1; fi

  if [[ $fail -eq 0 ]]; then
    if run_unit_tests; then STEP_STATUS[test]=OK; else STEP_STATUS[test]=FAIL; fail=1; fi
  else
    STEP_STATUS[test]=SKIP
  fi

  if [[ $fail -eq 0 ]]; then
    start_gate_server
    if run_playwright; then STEP_STATUS[e2e]=OK; else STEP_STATUS[e2e]=FAIL; fail=1; fi
    if [[ $fail -eq 0 ]]; then
      if run_measure; then STEP_STATUS[apostar]=OK; else STEP_STATUS[apostar]=FAIL; fail=1; fi
    else
      STEP_STATUS[apostar]=SKIP
    fi
  else
    STEP_STATUS[e2e]=SKIP
    STEP_STATUS[apostar]=SKIP
  fi

  if [[ $fail -eq 0 ]]; then
    post_summary "OK"
    exit 0
  fi
  post_summary "FAIL"
  exit 1
}

main "$@"
