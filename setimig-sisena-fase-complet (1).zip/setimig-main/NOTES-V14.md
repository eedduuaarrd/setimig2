# Setimig V14 — millores de claredat i interacció

Partint de V13, aquesta versió incorpora millores addicionals al client:

- Indicador explícit a la mà central per diferenciar el torn propi del torn d'un altre jugador.
- Ajustos adaptatius a la pila central quan hi ha moltes cartes o poca alçada de pantalla.
- Les accions de demanar carta i plantar-se mostren «Enviant…» mentre estan pendents.
- Els botons de carta/plantar-se es desactiven si el navegador no té connexió (excepte en partida contra IA local/solitària segons l'estat existent).
- Estats desactivats i de càrrega més clars, zones tàctils consistents, focus visible i respecte a `prefers-reduced-motion`.
- Ajustos per a noms llargs i pantalles petites.

## Validació

No s'ha publicat cap canvi al lloc en producció. Cal executar `npm ci`, `npm run check`, `npm test` i les proves E2E de mòbil en un entorn amb dependències instal·lables abans de desplegar. Les millores que requereixen canvis en sincronització, reconexió del socket o gestió d'estats al servidor no s'han reescrit en aquesta versió: s'han mantingut els mecanismes ja presents al projecte per evitar alterar les regles de joc sense proves.
