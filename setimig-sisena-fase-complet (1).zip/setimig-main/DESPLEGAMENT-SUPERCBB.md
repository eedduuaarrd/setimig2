# Desplegament de Set i Mig a setimig.supercbb.com

El ZIP conté el **codi font complet**, no un `dist/` precompilat. Necessita un entorn Node.js amb accés a NPM i el mateix servidor Express / Socket.IO actual.

## Abans de substituir fitxers

1. Fes una **còpia de seguretat** del directori instal·lat i, especialment, de `data/` i del `.env` del servidor. El ZIP no inclou les dades reals dels jugadors, fitxes, sales ni claus.
2. Confirma que Node.js és versió 22.19 o superior per cobrir totes les eines, inclòs Lighthouse; la web requereix Node.js 20 o superior.
3. Desa el ZIP en una carpeta nova i copia l'arxiu `.env` de l'entorn anterior. **No introdueixis claus al codi ni al ZIP públic.**

## Construir i verificar

```bash
cd setimig
npm ci
npm run check
npm test
npm run test:e2e:pas17
```

Un cop les proves siguin correctes, publica el contingut del projecte amb el gestor de processos que ja utilitza el servidor (PM2, systemd o equivalent) i reinicia el servei. Exemple només si el teu sistema ja té l'aplicació configurada:

```bash
npm run build
npm run start
```

`npm run start` inicia el servidor en primer pla; en producció cal fer servir **el gestor de processos existent**. El port de producció documentat és `4450` i `APP_URL=https://setimig.supercbb.com`.

## Comprovacions després de publicar

- La web mostra l’**Edició Clàssica V6**: disseny verd fosc i marfil, marques tipogràfiques «7½», dos botons de joc i la guia desplegable.
- Una partida contra la IA arrenca i les apostes/cobraments són els correctes.
- A la taula, **Menú → Què puc fer ara?** explica el torn actual.
- Les sales amb amics, la invitació i el xat funcionen en dues sessions diferents.
- Canviar la foto a Perfil funciona amb imatges grans de mòbil.
- Es manté una partida durant un refresc de pàgina i entre mans.
- La PWA s'instal·la; quan actualitza, no força un refresc enmig d'una mà. El nou cache `setimig-shell-v38` actualitza també les icones.
- Sense connexió, una instal·lació ja carregada pot obrir els recursos del joc per jugar contra IA. Sense instal·lació/càrrega prèvia, es mostra la pantalla offline.

## Si falla alguna prova

Conserva en ús la versió anterior i revisa el `npm run check` / `npm test` abans de desplegar el nou codi. El projecte s'ha validat estàticament, però en l'entorn de preparació no hi havia accés al registre NPM per fer el build complet.

## Identitat visual V6

- El full de presentació principal és `src/elegant.css`, carregat després de `src/index.css`. Aquest ordre és intencionat.
- Fonts: **DM Sans** per a controls i textos; serif del sistema (Georgia) per a titulars i monograma.
- La majoria de colors són variables CSS; la disposició de la taula i el motor del joc no s'han modificat.
- Els recursos gràfics nous són a `public/icon-*.png`, `public/logo.svg`, `public/simbol.svg`, `public/favicon-32.png`, `public/apple-touch-icon-180.png` i `public/og-image.png`/`og-image.jpg`, amb el logo «Fum daurat» (els SVG porten el PNG/JPEG incrustat; no hi ha font vectorial).
- La interfície s'ha revisat sintàcticament, però **cal construir i executar les proves completes al servidor amb les dependències instal·lades** abans de posar-la en producció.
