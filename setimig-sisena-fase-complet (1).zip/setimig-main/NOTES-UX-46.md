# Setimig — UX / jugabilitat V16

## Canvis respecte de V15

- Afegit bloqueig temporal per a les accions especials `split_hands` i `double_bet`, tant a mòbil com a escriptori, per evitar enviaments duplicats per tocs ràpids.
- Les accions especials mostren un estat transitori (`Separant…` / `Doblant…`) i `aria-busy`; els controls incompatibles queden desactivats mentre s'envia l'acció.
- El bloqueig de les accions especials es neteja en canviar de torn/fase/sala i en desmuntar el component.
- Les accions normals (demanar carta / plantar-se) també respecten el bloqueig de les accions especials.
- Millorat el focus visible de teclat per a botons, controls de formulari i controls interactius de la taula.
- Afegits petits ajustos de llegibilitat numèrica, scroll horitzontal dels rivals i feedback d'interacció només amb ratolí.

## Validació

S'ha intentat executar `npm run check`, però la instal·lació de dependències (`npm ci`) no ha acabat dins del temps disponible i TypeScript informa que falten definicions de tipus de dependències (`TS2688`). Per tant, no es declara que la compilació ni les proves automatitzades hagin passat. Cal executar `npm ci`, `npm run check` i `npm test` en un entorn amb accés funcional al registre de paquets abans de desplegar.
