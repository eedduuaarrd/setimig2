# Set i Mig · segona fase d'experiència de partida

## Millores disponibles

1. **Cartes amb moviment físic**: es conserven el vol FLIP en arc, el gir 3D i l'aterratge, amb il·luminació del seient actiu reforçada.
2. **Revelació amb tensió**: es conserven les revelacions per etapes i les pauses selectives de la banca, ja implementades en el motor anterior.
3. **Fitxes amb moviment**: el sistema de fitxes i pagaments de `TableFx` continua integrat, sense duplicar moviments ni imports.
4. **Atenció a l'acció**: es reforça el focus de seient actiu; el sistema `TurnSpotlight` continua controlant el focus general.
5. **Finals diferenciats**: segueixen actius els estats win/lose/set i mig i les celebracions existents.
6. **Mode ràpid**: nou interruptor persistent al menú de la taula. Redueix les animacions de repartiment a una fosa breu i accelera transicions CSS seleccionades, sense tocar les regles ni els temps del servidor.
7. **Rivals amb personalitat visible**: els bots ja decideixen segons perfils prudent/normal/agosarat. A la fila de rivals v2 es mostra una insígnia amb el perfil real derivat del nom.
8. **Historial**: es manté l'historial existent, expandible en mòbil i escriptori, que no esborra mans dins d'una partida.
9. **Tutorial**: opció nova per repetir l'ajuda guiada des del menú de la taula durant una partida en solitari amb IA.
10. **Mòbil**: zona tàctil reforçada, accessibilitat al focus de teclat i millores per a pantalles molt estretes amb respecte de safe-area.

## Abast i límits

No s'han modificat les decisions autoritatives del servidor, les puntuacions, la banca ni les apostes.
El mode ràpid és **visual**, no modifica els rellotges ni escurça el temps disponible per a la decisió.
Les millores que ja existien s'han conservat i aprofitat, no s'han duplicat.
