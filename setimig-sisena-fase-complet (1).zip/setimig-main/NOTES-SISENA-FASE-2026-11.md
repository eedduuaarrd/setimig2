# Sisena fase — Qualitat i continuïtat

## Canvis implementats
- Estat d'aposta amb cinc situacions: seleccionada, enviada, confirmada pel servidor, fase tancada i sense connexió.
- Rellotge: recompte recalculat en recuperar el focus, les pàgines i la pestanya després de suspensió mòbil.
- Resum desplegable de la sessió, amb indicador del mode de pràctica i estadístiques del servidor (quan disponibles).
- Zones tàctils i marges de seguretat mòbils reforçats; gestos accidentals mitigats als controls principals.
- Invariants de dades públiques en mode desenvolupament: identificadors de jugadors, saldos, apostes i identificadors de cartes de cada mà; mai es registren dades de cartes ni saldo als missatges.
- Nou test unitari d'estats d'aposta i invariants, amb ordre `npm run test:fase6`.

## Sistemes ja existents i mantinguts
- Avanç automàtic de les mans i consulta dels resultats.
- Distribució de cartes, rellotge amb biaix de servidor, bots amb diferents perfils i ritme adaptatiu.
- Pràctica i estadístiques, animacions adaptades a mòbil, protecció de doble clic i reconnexió.
- Simulacions de mans, comprovacions del motor, tests Playwright i estils per a mòbil horitzontal.

## Limitacions i verificació
- Els invariants són diagnòstics en desenvolupament; no són una transacció atòmica ni substitueixen les validacions del servidor.
- La prova completa de navegador, la compilació de producció i la reconnexió real necessiten dependències i un entorn amb servidor funcionant. No s'han de declarar aprovades sense executar-les.
- La sincronització del temporitzador fa servir l'última marca de rellotge del servidor, no un servei continu de sincronització.

- Fitxers Playwright nous: `e2e/fase6.spec.ts` i `playwright.fase6.config.ts`. Ordre: `npm run test:e2e:fase6` (requereix dependències).
