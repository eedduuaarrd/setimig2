# Llicència dels sons (`public/sounds/`)

Els sons de `public/sounds/` provenen del paquet **Casino Audio (1.1)** de **Kenney** (Kenney Vleugels, https://www.kenney.nl).

- Font: https://kenney.nl/assets/casino-audio
- Fitxer descarregat: `kenney_casino-audio.zip` (SHA-256 `f36250766ac5bc378c13708ddf12a23a8e54a3251f8d482c7536e51b5dbafa18`), el 26-10-2026
- Llicència: **Creative Commons Zero (CC0 1.0)**, domini públic — http://creativecommons.org/publicdomain/zero/1.0/
  Text del `License.txt` del paquet: «You may use these assets in personal and commercial projects. Credit (Kenney or www.kenney.nl) would be nice but is not mandatory.»

## Conversió

Originals en OGG estèreo 44,1 kHz. Convertits amb ffmpeg a **mono, 44,1 kHz, 64 kbps**, sense metadades, en dos formats:
`.m4a` (AAC, per a iOS/Safari) i `.mp3` (alternativa universal). No s'ha retallat ni editat cap so.

```sh
ffmpeg -i ORIGINAL.ogg -ac 1 -ar 44100 -c:a libmp3lame -b:a 64k -map_metadata -1 NOM.mp3
ffmpeg -i ORIGINAL.ogg -ac 1 -ar 44100 -c:a aac -b:a 64k -map_metadata -1 -movflags +faststart NOM.m4a
```

## Correspondència original → fitxer nou

| Original (Kenney, `Audio/`) | Fitxers nous | Durada | Ús previst |
| --- | --- | --- | --- |
| `card-shuffle.ogg` | `shuffle.m4a`, `shuffle.mp3` | 3,06 s | Barrejar la baralla |
| `card-slide-1.ogg` | `deal.m4a`, `deal.mp3` | 0,60 s | Repartir una carta |
| `card-place-1.ogg` | `flip.m4a`, `flip.mp3` | 0,69 s | Destapar / girar una carta |
| `chip-lay-1.ogg` | `chip.m4a`, `chip.mp3` | 0,17 s | Posar una fitxa (aposta) |
| `chips-handle-5.ogg` | `chips-collect.m4a`, `chips-collect.mp3` | 0,83 s | Recollir / apilar fitxes (liquidació) |
| `chips-stack-3.ogg` | `win.m4a`, `win.mp3` | 0,37 s | Guanyar (fitxes que s'apilen) |
| `card-shove-1.ogg` | `lose.m4a`, `lose.mp3` | 0,77 s | Perdre (cartes retirades) |
| `chips-collide-4.ogg` | `click.m4a`, `click.mp3` | 0,22 s | Clic de botó |

El paquet no té sintonies de victòria o derrota ni clics d'interfície: `win`, `lose` i `click` són sons de fitxes i cartes triats com a equivalents.
