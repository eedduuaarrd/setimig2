import { defineConfig, devices } from "@playwright/test";
import { catalanStorageState } from "./e2e/catalanLocale";
import { e2eServerEnv } from "./e2e/helpers/e2eServerEnv";

// Playwright accepts either webServer.port or webServer.url, not both.
const port = Number(process.env.E2E_PORT || process.env.PORT || 4173);
const baseURL = `http://127.0.0.1:${port}`;

export default defineConfig({
  testDir: "./e2e",
  testMatch: ["pas16-table-layout.spec.ts", "pas15-smoke.spec.ts"],
  timeout: 240_000,
  retries: process.env.CI ? 1 : 0,
  projects: [{ name: "chromium", use: { ...devices["Pixel 5"], browserName: "chromium" } }],
  use: {
    locale: "ca-ES",
    storageState: catalanStorageState(),
    baseURL,
    viewport: { width: 390, height: 844 },
  },
  globalTeardown: "./e2e/helpers/e2eGlobalTeardown.ts",
  webServer: {
    command: `cross-env NODE_ENV=production PORT=${port} tsx server.ts`,
    env: e2eServerEnv({ PORT: String(port) }),
    url: baseURL,
    reuseExistingServer: false,
    timeout: 120_000,
  },
});
