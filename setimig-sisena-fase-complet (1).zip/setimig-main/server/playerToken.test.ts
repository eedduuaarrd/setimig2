import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { mkdtempSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import type { Request } from "express";
import { createPlayerSession, resolvePlayerFromRequest, sendPlayerResponse } from "./httpPlayerAuth.ts";
import { issuePlayerToken, resolvePlayerIdFromParts, verifyPlayerToken } from "./playerToken.ts";

process.env.BALANCE_DATA_DIR ??= mkdtempSync(path.join(os.tmpdir(), "setimig-ptok-"));

function request(
  body: unknown = {},
  headers: Record<string, string> = {},
  query: Record<string, unknown> = {},
): Request {
  return { body, headers, query } as Request;
}

describe("playerToken", () => {
  it("issues and verifies token", () => {
    const token = issuePlayerToken("abc123def456");
    assert.ok(token);
    const payload = verifyPlayerToken(token);
    assert.equal(payload?.playerId, "abc123def456");
  });

  it("rejects tampered token", () => {
    const token = issuePlayerToken("player0001");
    assert.ok(token);
    const separator = token.indexOf(".");
    const signature = token.slice(separator + 1);
    const changedFirstCharacter = signature[0] === "A" ? "B" : "A";
    const bad = `${token.slice(0, separator + 1)}${changedFirstCharacter}${signature.slice(1)}`;
    assert.equal(verifyPlayerToken(bad), null);
  });

  it("accepts legacy playerId when no token", () => {
    const resolved = resolvePlayerIdFromParts({ legacyPlayerId: "legacyplayer01" });
    assert.deepEqual(resolved, { playerId: "legacyplayer01", legacy: true });
  });

  it("prefers a verified token over a different legacy id on later HTTP requests", () => {
    const token = issuePlayerToken("realplayer01");
    assert.ok(token);
    const resolved = resolvePlayerFromRequest(
      request({}, { authorization: `Bearer ${token}` }, { playerId: "otherplayer1" }),
    );
    assert.deepEqual(resolved, { playerId: "realplayer01", legacy: false });
  });

  it("does not downgrade an explicit invalid token to a caller-supplied legacy ID", () => {
    const token = issuePlayerToken("realplayer01");
    assert.ok(token);
    const separator = token.indexOf(".");
    const signature = token.slice(separator + 1);
    const alteredFirstCharacter = signature[0] === "A" ? "B" : "A";
    const invalidToken = `${token.slice(0, separator + 1)}${alteredFirstCharacter}${signature.slice(1)}`;
    const resolved = resolvePlayerFromRequest(
      request({}, { authorization: `Bearer ${invalidToken}` }, { playerId: "legacyplayer01" }),
    );
    assert.equal(resolved, null);
  });

  it("keeps an existing tokenless balance ID on the legacy path without minting a token", async () => {
    const existingPlayerId = "legacyplayer01";
    const before = resolvePlayerFromRequest(request({}, {}, { playerId: existingPlayerId }));
    assert.deepEqual(before, { playerId: existingPlayerId, legacy: true });
    assert.equal(await createPlayerSession(request({ playerId: existingPlayerId })), null);
    const after = resolvePlayerFromRequest(request({}, {}, { playerId: existingPlayerId }));
    assert.deepEqual(after, before);
  });

  it("does not mint a player session for an unauthenticated legacy ID", async () => {
    assert.equal(await createPlayerSession(request({ playerId: "victimplayer01" })), null);
  });

  it("does not attach a signed token to a legacy-identity response", () => {
    let response: unknown;
    sendPlayerResponse({ json: (body) => (response = body) }, { chips: 100 });
    assert.deepEqual(response, { chips: 100 });
  });

  it("does not create an anonymous player session without a token", async () => {
    assert.equal(await createPlayerSession(request()), null);
  });

  it("renews a session only from a valid signed token", async () => {
    const token = issuePlayerToken("authorized01");
    assert.ok(token);
    const session = await createPlayerSession(request({}, { authorization: `Bearer ${token}` }));
    assert.ok(session);
    assert.equal(session.playerId, "authorized01");
    assert.equal(verifyPlayerToken(session.playerToken)?.playerId, "authorized01");
    assert.equal(verifyPlayerToken(token)?.playerId, "authorized01");
  });
});
