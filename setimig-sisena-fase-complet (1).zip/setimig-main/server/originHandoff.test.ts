import assert from "node:assert/strict";
import { after, before, beforeEach, describe, it } from "node:test";
import { mkdtempSync, rmSync, readFileSync } from "node:fs";
import { createServer, type Server as HttpServer } from "node:http";
import type { AddressInfo } from "node:net";
import os from "node:os";
import path from "node:path";
import express from "express";

const dataDir = mkdtempSync(path.join(os.tmpdir(), "setimig-handoff-"));
process.env.BALANCE_DATA_DIR = dataDir;

const {
  consumeHandoffToken,
  EXCHANGE_FAIL_LIMIT,
  HANDOFF_TTL_MS,
  MINT_LIMIT,
  mintHandoffToken,
  pendingHandoffCountForTests,
  registerHandoffRoutes,
  resetHandoffForTests,
} = await import("./originHandoff.ts");
const { issuePlayerToken, verifyPlayerToken } = await import("./playerToken.ts");
const { AUTH_REQUIRED, requireLoginMiddleware } = await import("./requireLogin.ts");
const { loginWithIdentity, resetIdentityStoreForTests } = await import("./auth/identityStore.ts");
const {
  flushDomainMigrationForTests,
  getMigrationStats,
  recordDomainSeen,
  resetDomainMigrationForTests,
} = await import("./domainMigration.ts");

const A = "a".repeat(48);
const B = "b".repeat(48);

function tamperPlayer(token: string, playerId: string): string {
  const [v, body, sig] = token.split(".");
  const payload = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
  payload.p = playerId;
  return [v, Buffer.from(JSON.stringify(payload)).toString("base64url"), sig].join(".");
}

describe("traspàs de compte entre dominis (lògica)", () => {
  beforeEach(() => resetHandoffForTests());

  it("un token vàlid es bescanvia pel mateix jugador", () => {
    const m = mintHandoffToken(A, { clientState: "{\"setimig_sound_volume\":\"0.4\"}" });
    assert.ok(m.ok);
    assert.ok(m.expiresAt - Date.now() <= HANDOFF_TTL_MS);
    const r = consumeHandoffToken(m.transferToken);
    assert.deepEqual(r, { ok: true, playerId: A, clientState: "{\"setimig_sound_volume\":\"0.4\"}" });
  });

  it("és d'un sol ús: el segon bescanvi (replay) falla", () => {
    const m = mintHandoffToken(A);
    assert.ok(m.ok);
    assert.equal(consumeHandoffToken(m.transferToken).ok, true);
    assert.deepEqual(consumeHandoffToken(m.transferToken), { ok: false, error: "USED_OR_UNKNOWN" });
    assert.equal(pendingHandoffCountForTests(), 0);
  });

  it("caduca als 5 minuts", () => {
    const t0 = Date.now();
    const m = mintHandoffToken(A, { now: t0 });
    assert.ok(m.ok);
    assert.equal(consumeHandoffToken(m.transferToken, { now: t0 + HANDOFF_TTL_MS - 1 }).ok, true);
    const m2 = mintHandoffToken(A, { now: t0 });
    assert.ok(m2.ok);
    assert.deepEqual(consumeHandoffToken(m2.transferToken, { now: t0 + HANDOFF_TTL_MS }), {
      ok: false,
      error: "EXPIRED",
    });
    // Tampoc es pot fer servir després, encara que el rellotge "torni enrere".
    assert.equal(consumeHandoffToken(m2.transferToken, { now: t0 }).ok, false);
  });

  it("una signatura incorrecta o un token mal format es rebutja", () => {
    const m = mintHandoffToken(A);
    assert.ok(m.ok);
    const [v, body, sig] = m.transferToken.split(".");
    const badSig = Buffer.from(sig, "base64url");
    badSig[0] ^= 0xff;
    assert.deepEqual(consumeHandoffToken([v, body, badSig.toString("base64url")].join(".")), {
      ok: false,
      error: "BAD_SIGNATURE",
    });
    for (const bad of ["", "h1.x", "nope", 42, null, `h2.${body}.${sig}`]) {
      assert.equal(consumeHandoffToken(bad).ok, false, String(bad));
    }
    // Un token de jugador normal no serveix com a token de traspàs (propòsit separat).
    assert.equal(consumeHandoffToken(`h1.${issuePlayerToken(A)}`).ok, false);
    // L'original continua sent vàlid: els intents fallits no el consumeixen.
    assert.equal(consumeHandoffToken(m.transferToken).ok, true);
  });

  it("no es pot canviar de jugador (cross-player)", () => {
    const m = mintHandoffToken(A);
    assert.ok(m.ok);
    assert.deepEqual(consumeHandoffToken(tamperPlayer(m.transferToken, B)), { ok: false, error: "BAD_SIGNATURE" });
    const mb = mintHandoffToken(B);
    assert.ok(mb.ok);
    const ra = consumeHandoffToken(m.transferToken);
    const rb = consumeHandoffToken(mb.transferToken);
    assert.ok(ra.ok && rb.ok);
    assert.equal(ra.playerId, A);
    assert.equal(rb.playerId, B);
  });

  it("límits: emissions per jugador i intents fallits per IP", () => {
    for (let i = 0; i < MINT_LIMIT; i++) assert.equal(mintHandoffToken(A).ok, true);
    assert.deepEqual(mintHandoffToken(A), { ok: false, error: "RATE_LIMIT" });
    assert.equal(mintHandoffToken(B).ok, true);

    const good = mintHandoffToken(B);
    assert.ok(good.ok);
    for (let i = 0; i < EXCHANGE_FAIL_LIMIT; i++) consumeHandoffToken("h1.x.y", { rateKey: "198.51.100.7" });
    assert.deepEqual(consumeHandoffToken(good.transferToken, { rateKey: "198.51.100.7" }), {
      ok: false,
      error: "RATE_LIMIT",
    });
    assert.equal(consumeHandoffToken(good.transferToken, { rateKey: "198.51.100.8" }).ok, true);
  });

  it("clientState massa gran es rebutja", () => {
    assert.deepEqual(mintHandoffToken(A, { clientState: "x".repeat(16 * 1024 + 1) }), {
      ok: false,
      error: "CLIENT_STATE_TOO_LARGE",
    });
  });
});

describe("traspàs de compte entre dominis (HTTP)", () => {
  let http: HttpServer;
  let base = "";

  before(async () => {
    resetDomainMigrationForTests();
    const app = express();
    app.use(express.json({ limit: "100kb" }));
    registerHandoffRoutes(app);
    http = createServer(app);
    await new Promise<void>((r) => http.listen(0, "127.0.0.1", () => r()));
    base = `http://127.0.0.1:${(http.address() as AddressInfo).port}`;
  });

  beforeEach(() => resetHandoffForTests());

  after(async () => {
    await new Promise<void>((r) => http.close(() => r()));
    await flushDomainMigrationForTests();
    resetDomainMigrationForTests();
    rmSync(dataDir, { recursive: true, force: true });
  });

  async function post(p: string, body: unknown, headers: Record<string, string> = {}) {
    const res = await fetch(base + p, {
      method: "POST",
      headers: { "content-type": "application/json", ...headers },
      body: JSON.stringify(body),
    });
    return { status: res.status, body: (await res.json()) as Record<string, unknown> };
  }

  it("domini antic emet, domini nou bescanvia: mateix playerId i token nou vàlid", async () => {
    const tokenA = issuePlayerToken(A)!;
    const minted = await post("/api/handoff/mint", {}, {
      authorization: `Bearer ${tokenA}`,
      origin: "https://setimig.supercbb.com",
    });
    assert.equal(minted.status, 200);
    const transferToken = minted.body.transferToken as string;
    assert.equal(minted.body.targetUrl, `https://sevenhalf.club/#handoff=${encodeURIComponent(transferToken)}`);

    const tokenB = issuePlayerToken(B)!;
    const ex = await post("/api/handoff/exchange", { transferToken }, {
      origin: "https://sevenhalf.club",
      authorization: `Bearer ${tokenB}`,
    });
    assert.equal(ex.status, 200);
    assert.equal(ex.body.playerId, A);
    assert.equal(verifyPlayerToken(ex.body.playerToken)?.playerId, A);
    assert.equal(ex.body.replacedPlayerId, B);

    const replay = await post("/api/handoff/exchange", { transferToken }, { origin: "https://sevenhalf.club" });
    assert.equal(replay.status, 410);

    await flushDomainMigrationForTests();
    const saved = JSON.parse(readFileSync(path.join(dataDir, "domain-migration.json"), "utf8"));
    assert.ok(saved.players[A].migratedAt > 0);
  });

  it("també serveix per a jugadors antics només amb playerId (legacy)", async () => {
    const minted = await post("/api/handoff/mint", { playerId: A });
    assert.equal(minted.status, 200);
    const ex = await post("/api/handoff/exchange", { transferToken: minted.body.transferToken });
    assert.equal(ex.body.playerId, A);
  });

  it("rebutja un token de jugador invàlid i un origen no permès", async () => {
    assert.equal((await post("/api/handoff/mint", {}, { authorization: "Bearer xxx.yyy" })).status, 400);
    const tokenA = issuePlayerToken(A)!;
    const bad = await post("/api/handoff/mint", {}, {
      authorization: `Bearer ${tokenA}`,
      origin: "https://evil.example",
    });
    assert.equal(bad.status, 403);
    const m = mintHandoffToken(A);
    assert.ok(m.ok);
    const badEx = await post("/api/handoff/exchange", { transferToken: m.transferToken }, { origin: "https://evil.example" });
    assert.equal(badEx.status, 403);
    // L'intent des d'un origen dolent no ha consumit el token.
    assert.equal(consumeHandoffToken(m.transferToken).ok, true);
  });

  it("mètrica: % de jugadors actius al domini antic que ja han migrat", async () => {
    resetDomainMigrationForTests();
    const now = Date.now();
    recordDomainSeen("c".repeat(48), "setimig.supercbb.com", now);
    recordDomainSeen("d".repeat(48), "setimig.supercbb.com", now);
    recordDomainSeen("d".repeat(48), "sevenhalf.club", now + 1);
    recordDomainSeen("e".repeat(48), "127.0.0.1:3190", now);
    const s = getMigrationStats(14, now + 2);
    assert.equal(s.activeOld, 2);
    assert.equal(s.activeOldMigrated, 1);
    assert.equal(s.migratedRatio, 0.5);
    assert.equal(s.activeNew, 1);
    const res = await fetch(`${base}/api/handoff/stats`);
    assert.equal(res.status, 200);
    const viaCf = await fetch(`${base}/api/handoff/stats`, { headers: { "cf-connecting-ip": "203.0.113.9" } });
    assert.equal(viaCf.status, 404);
  });
});

describe("traspàs amb login obligatori: bescanvi sense sessió al domini nou", () => {
  let http: HttpServer;
  let base = "";

  async function seedAccount(playerId: string, email: string): Promise<void> {
    const r = await loginWithIdentity({
      kind: "email",
      email,
      current: { playerId, legacy: false },
      allowCreate: false,
    });
    assert.ok(r.ok, email);
    assert.equal(r.playerId, playerId);
  }

  before(async () => {
    resetIdentityStoreForTests();
    await seedAccount(A, "handoff-a@test.cat");
    await seedAccount(B, "handoff-b@test.cat");
    const app = express();
    app.use(express.json({ limit: "100kb" }));
    app.use(requireLoginMiddleware);
    registerHandoffRoutes(app);
    http = createServer(app);
    await new Promise<void>((r) => http.listen(0, "127.0.0.1", () => r()));
    base = `http://127.0.0.1:${(http.address() as AddressInfo).port}`;
  });

  beforeEach(() => resetHandoffForTests());

  after(async () => {
    await new Promise<void>((r) => http.close(() => r()));
    resetIdentityStoreForTests();
    rmSync(dataDir, { recursive: true, force: true });
  });

  async function post(p: string, body: unknown, headers: Record<string, string> = {}) {
    const res = await fetch(base + p, {
      method: "POST",
      headers: { "content-type": "application/json", ...headers },
      body: JSON.stringify(body),
    });
    return { status: res.status, body: (await res.json()) as Record<string, unknown> };
  }

  it("mint sense sessió (playerId aliè) segueix en 401 i no emet cap codi", async () => {
    const minted = await post("/api/handoff/mint", { playerId: A }, { origin: "https://setimig.supercbb.com" });
    assert.equal(minted.status, 401);
    assert.deepEqual(minted.body, { error: AUTH_REQUIRED });
    assert.equal(pendingHandoffCountForTests(), 0);
    const stats = await fetch(`${base}/api/handoff/stats`);
    assert.equal(stats.status, 401);
  });

  it("el domini antic emet amb sessió i el domini nou bescanvia sense sessió", async () => {
    const tokenA = issuePlayerToken(A)!;
    const minted = await post("/api/handoff/mint", { clientState: "{\"setimig.locale\":\"ca\"}" }, {
      authorization: `Bearer ${tokenA}`,
      origin: "https://setimig.supercbb.com",
    });
    assert.equal(minted.status, 200);
    const transferToken = minted.body.transferToken as string;

    const ex = await post("/api/handoff/exchange", { transferToken }, { origin: "https://sevenhalf.club" });
    assert.equal(ex.status, 200);
    assert.equal(ex.body.playerId, A);
    assert.equal(verifyPlayerToken(String(ex.body.playerToken))?.playerId, A);
    assert.equal(ex.body.clientState, "{\"setimig.locale\":\"ca\"}");
    assert.equal(ex.body.replacedPlayerId, undefined);

    const replay = await post("/api/handoff/exchange", { transferToken }, { origin: "https://sevenhalf.club" });
    assert.equal(replay.status, 410);
    assert.equal(replay.body.code, "USED_OR_UNKNOWN");
  });

  it("el bescanvi obert segueix rebutjant origen, caducitat i límit per IP", async () => {
    const tokenA = issuePlayerToken(A)!;
    const minted = await post("/api/handoff/mint", {}, {
      authorization: `Bearer ${tokenA}`,
      origin: "https://setimig.supercbb.com",
    });
    assert.equal(minted.status, 200);
    const transferToken = minted.body.transferToken as string;

    const badOrigin = await post("/api/handoff/exchange", { transferToken }, { origin: "https://evil.example" });
    assert.equal(badOrigin.status, 403);
    assert.equal(badOrigin.body.code, "BAD_ORIGIN");
    assert.equal(pendingHandoffCountForTests(), 1);

    const expired = mintHandoffToken(B, { now: Date.now() - HANDOFF_TTL_MS - 1_000 });
    assert.ok(expired.ok);
    const gone = await post("/api/handoff/exchange", { transferToken: expired.transferToken }, {
      origin: "https://sevenhalf.club",
      "cf-connecting-ip": "203.0.113.40",
    });
    assert.equal(gone.status, 410);
    assert.equal(gone.body.code, "EXPIRED");

    for (let i = 0; i < EXCHANGE_FAIL_LIMIT; i++) {
      const fail = await post("/api/handoff/exchange", { transferToken: "h1.x.y" }, {
        origin: "https://sevenhalf.club",
        "cf-connecting-ip": "203.0.113.41",
      });
      assert.equal(fail.status, 400, `intent ${i}`);
    }
    const limited = await post("/api/handoff/exchange", { transferToken }, {
      origin: "https://sevenhalf.club",
      "cf-connecting-ip": "203.0.113.41",
    });
    assert.equal(limited.status, 429);
    assert.equal(limited.body.code, "RATE_LIMIT");
    assert.equal(pendingHandoffCountForTests(), 1);

    const ok = await post("/api/handoff/exchange", { transferToken }, {
      origin: "https://www.sevenhalf.club",
      "cf-connecting-ip": "203.0.113.42",
    });
    assert.equal(ok.status, 200);
    assert.equal(ok.body.playerId, A);
    assert.equal(pendingHandoffCountForTests(), 0);
  });
});
