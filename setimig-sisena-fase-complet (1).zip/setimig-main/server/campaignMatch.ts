import type { Room } from "../shared/gameEngine.ts";
import { ensureSoloBots } from "../shared/gameEngine.ts";
import { defaultHostMatchSettings } from "../shared/hostMatchSettings.ts";
import { getCampaignLevel, type CampaignLevelDef } from "../shared/campaignLevels.ts";
import { PHASE_B_START_CHIPS } from "../shared/matchPhaseB.ts";
import { recordCampaignAttempt } from "./campaignProgress.ts";

export function applyCampaignLevelToSoloRoom(room: Room, def: CampaignLevelDef): void {
  room.campaignLevel = def.level;
  room.campaignStartingChips = def.startingChips;
  room.botDifficulty = def.botDifficulty;
  room.hostMatchSettings = {
    ...defaultHostMatchSettings(),
    handsTotal: def.handsTotal,
    houseRulesEnabled: room.houseRulesEnabled === true,
  };
  ensureSoloBots(room, def.botCount);
}

export function campaignLevelForRoom(room: Room): number | null {
  const level = room.campaignLevel;
  if (level == null || !Number.isInteger(level)) return null;
  return getCampaignLevel(level) ? level : null;
}

export function evaluateCampaignLevelWon(room: Room, humanName: string): boolean {
  const match = room.matchResult;
  if (!match) return false;
  const row = match.ranking.find((r) => r.name === humanName);
  if (!row) return false;
  if (match.winnerName === humanName) return true;
  const start = room.phaseB?.startingChips ?? room.campaignStartingChips ?? PHASE_B_START_CHIPS;
  return row.chips > start;
}

export async function recordCampaignMatchIfNeeded(room: Room): Promise<void> {
  const level = campaignLevelForRoom(room);
  if (level == null || room.practiceMode) return;

  const human = room.players.find((p) => !p.isBot && p.playerId && !p.playerId.startsWith("bot-"));
  if (!human?.playerId) return;

  const won = evaluateCampaignLevelWon(room, human.name);
  const row = room.matchResult?.ranking.find((r) => r.name === human.name);
  const endingChips = row?.chips ?? human.chips;
  const startingChips = room.phaseB?.startingChips ?? room.campaignStartingChips ?? PHASE_B_START_CHIPS;

  await recordCampaignAttempt({
    playerId: human.playerId,
    level,
    roomId: room.id,
    won,
    endingChips,
    startingChips,
  });
}
