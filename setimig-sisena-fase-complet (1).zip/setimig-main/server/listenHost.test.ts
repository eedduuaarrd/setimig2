import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createServer } from "node:http";
import type { AddressInfo } from "node:net";
import { DEFAULT_LISTEN_HOST, resolveListenHost } from "./listenHost.ts";

describe("listen host (escolta local)", () => {
  it("per defecte escolta a 127.0.0.1", () => {
    assert.equal(DEFAULT_LISTEN_HOST, "127.0.0.1");
    assert.equal(resolveListenHost({}), "127.0.0.1");
    assert.equal(resolveListenHost({ HOST: "  " }), "127.0.0.1");
  });

  it("respecta SETIMIG_HOST i HOST (SETIMIG_HOST té prioritat)", () => {
    assert.equal(resolveListenHost({ HOST: "0.0.0.0" }), "0.0.0.0");
    assert.equal(resolveListenHost({ SETIMIG_HOST: "::1", HOST: "0.0.0.0" }), "::1");
  });

  it("un servidor amb el host per defecte queda lligat a 127.0.0.1", async () => {
    const http = createServer();
    await new Promise<void>((r) => http.listen(0, resolveListenHost({}), () => r()));
    const addr = http.address() as AddressInfo;
    assert.equal(addr.address, "127.0.0.1");
    await new Promise<void>((r) => http.close(() => r()));
  });
});
