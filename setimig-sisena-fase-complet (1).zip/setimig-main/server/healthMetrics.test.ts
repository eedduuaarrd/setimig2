import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import { buildHealthPayload, EMPTY_GAME_COUNTS, getAppVersion, resetAppVersionCacheForTests } from "./healthMetrics.ts";
import { getGameCountsForHealth, resetGameStateForTests } from "./game.ts";

describe("/api/health mètriques", () => {
  before(() => {
    process.env.SETIMIG_TEST_FAST = "1";
    resetAppVersionCacheForTests();
  });
  after(() => {
    delete process.env.SETIMIG_GIT_SHA;
    resetAppVersionCacheForTests();
  });

  it("manté ok/stripe i afegeix versió, partides, memòria i uptime", () => {
    const payload = buildHealthPayload({ stripe: false, games: { ...EMPTY_GAME_COUNTS, rooms: 3, activeGames: 2 } });
    assert.equal(payload.ok, true);
    assert.equal(payload.stripe, false);
    assert.equal(typeof payload.version.package, "string");
    assert.equal(payload.games.rooms, 3);
    assert.equal(payload.games.activeGames, 2);
    assert.ok(payload.memory.rssMb > 0);
    assert.ok(payload.memory.heapUsedMb > 0);
    assert.ok(payload.uptimeSec >= 0);
    assert.ok(!Number.isNaN(Date.parse(payload.startedAt)));
  });

  it("la versió pot venir de SETIMIG_GIT_SHA", () => {
    process.env.SETIMIG_GIT_SHA = "ABCDEF1234567890abcdef1234567890abcdef12";
    resetAppVersionCacheForTests();
    const v = getAppVersion();
    assert.equal(v.commit, "abcdef1234567890abcdef1234567890abcdef12");
    assert.equal(v.commitShort, "abcdef1");
  });

  it("els recomptes del joc són agregats i sense dades personals", () => {
    resetGameStateForTests();
    const counts = getGameCountsForHealth();
    assert.deepEqual(Object.keys(counts).sort(), Object.keys(EMPTY_GAME_COUNTS).sort());
    for (const v of Object.values(counts)) assert.equal(typeof v, "number");
    assert.equal(counts.rooms, 0);
    const json = JSON.stringify(buildHealthPayload({ stripe: true, games: counts }));
    assert.doesNotMatch(json, /playerId|displayName|seatToken|inviteCode/);
  });
});
