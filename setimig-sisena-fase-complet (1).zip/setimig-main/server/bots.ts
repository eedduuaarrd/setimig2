import {
  BANK_CHOICE_TIMEOUT_MS,
  BANKER_TIMEOUT_MS,
  BET_WINDOW_MS,
  BOT_ACTION_MAX_MS,
  BOT_ACTION_MIN_MS,
  PLAY_WINDOW_MS,
  defaultSettlementAutoMs,
  isTestFastPacing,
  soloSettlementAutoMs,
} from "../shared/pacing.ts";
import { botRng } from "../shared/ai/botProfile.ts";

export function botPaceMinMs(): number {
  return isTestFastPacing() ? 20 : BOT_ACTION_MIN_MS;
}

export function botPaceMaxMs(): number {
  return isTestFastPacing() ? 60 : BOT_ACTION_MAX_MS;
}

export function humanBetTimeoutMs(): number {
  return isTestFastPacing() ? 150 : BET_WINDOW_MS;
}

export function humanTurnTimeoutMs(): number {
  return isTestFastPacing() ? 180 : PLAY_WINDOW_MS;
}

export function bankerTimeoutMs(): number {
  return isTestFastPacing() ? 160 : BANKER_TIMEOUT_MS;
}

export function bankChoiceTimeoutMs(): number {
  return isTestFastPacing() ? 150 : BANK_CHOICE_TIMEOUT_MS;
}

export function soloSettlementMs(): number {
  return soloSettlementAutoMs();
}

export function defaultSettlementMs(): number {
  return defaultSettlementAutoMs();
}

/** @deprecated use humanTurnTimeoutMs() */
export const HUMAN_TURN_TIMEOUT_MS = PLAY_WINDOW_MS;

const BOT_NAMES = ["Laia", "Pau", "Núria", "Oriol", "Marta", "Jordi", "Clara", "Arnau"];
const ALT_BOT_NAMES = ["Quim", "Roser", "Biel", "Martí", "Aina", "Pol", "Arnau", "Gemma"];

let botNameCursor = 0;

export function nextBotName(): string {
  const name = BOT_NAMES[botNameCursor % BOT_NAMES.length];
  botNameCursor++;
  return name;
}

/** Bot display name that does not collide with human-chosen names at the table. */
export function pickBotNameAvoiding(avoid: ReadonlySet<string>): string {
  const pool = [...BOT_NAMES, ...ALT_BOT_NAMES];
  for (const candidate of pool) {
    if (!avoid.has(candidate.toLowerCase())) return candidate;
  }
  botNameCursor++;
  return `Rival ${botNameCursor}`;
}

export function botSocketId(roomId: string, slot: number): string {
  return `bot:${roomId}:${slot}`;
}

export function isBotId(id: string): boolean {
  return id.startsWith("bot:");
}

/**
 * Pausa entre accions d'un bot: aleatòria i acotada a [BOT_ACTION_MIN_MS, BOT_ACTION_MAX_MS]
 * (1,2–1,5 s; 20–60 ms en mode de tests ràpids). El RNG és injectable per als tests.
 */
export function randomBotPaceMs(rng: () => number = botRng): number {
  const min = botPaceMinMs();
  const max = botPaceMaxMs();
  const r = Math.min(Math.max(rng(), 0), 0.999_999);
  return min + Math.floor(r * (max - min + 1));
}

/** Starting chips for filler bots (not tied to balance store). */
export function botStartingChips(minBet: number): number {
  if (isTestFastPacing()) return minBet;
  return Math.max(minBet * 80, 8_000);
}

export type BotLikePlayer = {
  id: string;
  isBot?: boolean;
  name: string;
  chips: number;
};

export function markAsBot(player: BotLikePlayer, roomId: string, slot: number): void {
  player.isBot = true;
  player.id = botSocketId(roomId, slot);
  if (!player.name.includes("IA") && !player.name.includes("Bot")) {
    player.name = nextBotName();
  }
}
