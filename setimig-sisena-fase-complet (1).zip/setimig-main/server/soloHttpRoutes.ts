import type { Express, Request, Response } from "express";
import { getBalance } from "./balances.ts";
import { readTokenFromAuthHeader } from "./playerToken.ts";
import {
  actAuthoritativeSolo,
  closeAuthoritativeSolo,
  openAuthoritativeSolo,
  readAuthoritativeSoloView,
  resumeAuthoritativeSolo,
  soloClientJson,
  type AuthoritativeSoloError,
  type AuthoritativeSoloResult,
} from "./soloIsolatedSessions.ts";

const SOLO_ACTIONS = new Set([
  "hit",
  "stand",
  "place_bet",
  "double_bet",
  "mort_action",
  "swap_action",
  "card_peeked",
  "split_hands",
  "flip_card",
  "bank_keep_choice",
  "quick_rematch",
  "settlement_next",
]);

function accountPlayerId(req: Request): string | null {
  const id = (req as Request & { accountPlayerId?: string }).accountPlayerId;
  return typeof id === "string" && id.trim() ? id.trim() : null;
}

function bearerToken(req: Request): string | null {
  return readTokenFromAuthHeader(req.headers.authorization);
}

function sendResult(res: Response, result: AuthoritativeSoloResult): void {
  if (result.error && !result.view) {
    const status = result.error.code === "INSUFFICIENT_BALANCE" ? 409 : result.error.code === "BAD_TOKEN" ? 401 : 400;
    res.status(status).json(result.error);
    return;
  }
  res.json({
    view: result.view ? soloClientJson(result.view) : null,
    ...(result.error
      ? {
          error: result.error.message,
          code: result.error.code,
          ...(result.error.actionId ? { actionId: result.error.actionId } : {}),
        }
      : {}),
  });
}

/**
 * Client prim del mode solo. Cada resposta és la vista filtrada (`roomToView`);
 * el mazo i les cartes tapades no surten d'aquest mòdul.
 */
export function registerSoloHttpRoutes(app: Express): void {
  app.post("/api/solo/session", async (req, res) => {
    const playerId = accountPlayerId(req);
    const playerToken = bearerToken(req);
    if (!playerId || !playerToken) {
      res.status(401).json({ message: "Token de jugador invalid o caducat.", code: "BAD_TOKEN" });
      return;
    }
    const body = req.body && typeof req.body === "object" ? (req.body as Record<string, unknown>) : {};
    const playerName = typeof body.playerName === "string" ? body.playerName : "Jugador";
    try {
      if (body.resume === true) {
        const resumed = await resumeAuthoritativeSolo(
          playerId,
          playerName,
          playerToken,
          typeof body.soloResumeToken === "string" ? body.soloResumeToken : undefined,
        );
        if (!resumed) {
          res.status(404).json({ message: "No hi ha cap partida solo per reprendre.", code: "NO_SESSION" });
          return;
        }
        sendResult(res, resumed);
        return;
      }
      const opened = await openAuthoritativeSolo(playerId, playerName, playerToken, {
        botCount: typeof body.botCount === "number" ? body.botCount : undefined,
        botDifficulty: typeof body.botDifficulty === "string" ? body.botDifficulty : undefined,
        houseRulesEnabled: body.houseRulesEnabled === true,
        practiceMode: body.practiceMode === true,
        fastTournament: body.fastTournament === true,
        intent: "new",
      });
      sendResult(res, opened);
    } catch (err) {
      console.error("[api/solo/session]", err);
      res.status(500).json({ message: "Error intern. Torna-ho a provar.", code: "BAD" } satisfies AuthoritativeSoloError);
    }
  });

  app.get("/api/solo/view", (req, res) => {
    const playerId = accountPlayerId(req);
    if (!playerId) {
      res.status(401).json({ message: "Token de jugador invalid o caducat.", code: "BAD_TOKEN" });
      return;
    }
    const view = readAuthoritativeSoloView(playerId);
    if (!view) {
      res.status(404).json({ message: "No hi ha cap partida solo oberta.", code: "NO_SESSION" });
      return;
    }
    res.json({ view: soloClientJson(view) });
  });

  app.post("/api/solo/action", async (req, res) => {
    const playerId = accountPlayerId(req);
    const playerToken = bearerToken(req);
    if (!playerId || !playerToken) {
      res.status(401).json({ message: "Token de jugador invalid o caducat.", code: "BAD_TOKEN" });
      return;
    }
    const body = req.body && typeof req.body === "object" ? (req.body as Record<string, unknown>) : {};
    const action = typeof body.action === "string" ? body.action : "";
    if (!SOLO_ACTIONS.has(action)) {
      res.status(400).json({ message: "Acció no vàlida.", code: "BAD" });
      return;
    }
    const actionSeq = body.actionSeq;
    if (typeof actionSeq !== "number" || !Number.isInteger(actionSeq) || actionSeq < 1) {
      res.status(400).json({ message: "Seqüència d'acció invalida.", code: "BAD_ACTION_SEQ" });
      return;
    }
    try {
      const result = await actAuthoritativeSolo(playerId, action, body, { playerToken, actionSeq });
      if (result.error?.code === "BAD_TOKEN") {
        res.status(401).json(result.error);
        return;
      }
      sendResult(res, result);
    } catch (err) {
      console.error("[api/solo/action]", err);
      res.status(500).json({ message: "Error intern. Torna-ho a provar.", code: "BAD" });
    }
  });

  app.post("/api/solo/leave", async (req, res) => {
    const playerId = accountPlayerId(req);
    if (!playerId) {
      res.status(401).json({ message: "Token de jugador invalid o caducat.", code: "BAD_TOKEN" });
      return;
    }
    const body = req.body && typeof req.body === "object" ? (req.body as Record<string, unknown>) : {};
    const seatToken = typeof body.seatToken === "string" ? body.seatToken : undefined;
    try {
      const left = await closeAuthoritativeSolo(playerId, seatToken);
      const chips = await getBalance(playerId);
      res.json({ left, chips });
    } catch (err) {
      console.error("[api/solo/leave]", err);
      res.status(500).json({ message: "Error intern. Torna-ho a provar.", code: "BAD" });
    }
  });
}
