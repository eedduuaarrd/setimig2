import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import fs from "fs/promises";
import path from "path";
import {
  getProfile,
  upsertProfile,
  normalizeDisplayName,
  validateAvatarDataUrl,
  resolvedAvatarForProfile,
  InvalidAvatarError,
} from "./profiles.ts";

const TEST_DIR = path.join(process.cwd(), "data", "profiles-test-" + Date.now());

describe("profiles", () => {
  before(() => {
    process.env.PROFILE_DATA_DIR = TEST_DIR;
  });

  after(async () => {
    await fs.rm(TEST_DIR, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 });
    delete process.env.PROFILE_DATA_DIR;
  });

  it("normalizes display names", () => {
    assert.equal(normalizeDisplayName("  Ana  "), "Ana");
    assert.equal(normalizeDisplayName(""), "Jugador");
  });

  it("rejects an SVG avatar and malformed data URL", () => {
    assert.equal(validateAvatarDataUrl('data:image/svg+xml;base64,PHN2Zz48L3N2Zz4='), null);
    assert.equal(validateAvatarDataUrl('data:image/png;base64,not-valid<script>'), null);
    assert.equal(validateAvatarDataUrl('data:image/jpeg;base64,/9j/AA=='), 'data:image/jpeg;base64,/9j/AA==');
  });

  it("creates and reads profile", async () => {
    const saved = await upsertProfile("testplayerpas14aa", { displayName: "Pas14Start" });
    assert.ok(saved);
    assert.equal(saved?.displayName, "Pas14Start");
    const loaded = await getProfile("testplayerpas14aa");
    assert.equal(loaded?.displayName, "Pas14Start");
    assert.equal(loaded?.avatarDataUrl, null);
  });

  it("desa avatar vàlid i rebutja valors fora de llista", async () => {
    const playerId = "avatarvalid01";
    const saved = await upsertProfile(playerId, {
      avatar: { kind: "symbol", symbol: "star", color: "wine" },
    });
    assert.ok(saved);
    const resolved = resolvedAvatarForProfile(saved!, playerId);
    assert.equal(resolved.kind, "symbol");
    assert.equal(resolved.symbol, "star");
    await assert.rejects(
      () => upsertProfile(playerId, { avatar: { kind: "initials", initials: "TOOLONG", color: "emerald" } }),
      InvalidAvatarError
    );
  });

  it("perfils sense camp avatar mantenen compatibilitat", async () => {
    const playerId = "legacyavatar01";
    const profilePath = path.join(TEST_DIR, `${playerId}.json`);
    await fs.mkdir(TEST_DIR, { recursive: true });
    await fs.writeFile(
      profilePath,
      JSON.stringify({ displayName: "Legacy", avatarDataUrl: null, updatedAt: 1 }),
      "utf8"
    );
    const loaded = await getProfile(playerId);
    assert.ok(loaded);
    assert.equal(loaded?.avatar, undefined);
    const resolved = resolvedAvatarForProfile(loaded!, playerId);
    assert.equal(resolved.kind, "initials");
    assert.equal(resolved.initials, "LE");
  });

  it("preserves unreadable profile data instead of treating it as missing", async () => {
    const playerId = "corruptprofile01";
    const profilePath = path.join(TEST_DIR, `${playerId}.json`);
    const corruptData = "{\"displayName\": ";
    await fs.mkdir(TEST_DIR, { recursive: true });
    await fs.writeFile(profilePath, corruptData, "utf8");

    await assert.rejects(getProfile(playerId));
    await assert.rejects(upsertProfile(playerId, { displayName: "Replacement" }));
    assert.equal(await fs.readFile(profilePath, "utf8"), corruptData);
  });
});
