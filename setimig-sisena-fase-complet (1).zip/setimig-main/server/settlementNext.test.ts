import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket } from "socket.io-client";
import { setupGameHandlers } from "./game.ts";

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";

function connect(url: string): Promise<Socket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.on("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.on("connect_error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

function nextGameError(socket: Socket, ms = 3_000): Promise<{ code: string } | null> {
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      socket.off("game_error", onErr);
      resolve(null);
    }, ms);
    const onErr = (e: { code: string }) => {
      clearTimeout(timer);
      socket.off("game_error", onErr);
      resolve(e);
    };
    socket.on("game_error", onErr);
  });
}

describe("socket settlement_next", () => {
  it("l'accepta del jugador humà en liquidació i valida el remitent", async () => {
    process.env.SETIMIG_TEST_FAST = "1";
    const http = createServer();
    const io = new SocketIOServer(http, { cors: { origin: "*" } });
    await setupGameHandlers(io);
    await new Promise<void>((r) => http.listen(0, "127.0.0.1", () => r()));
    const url = `http://127.0.0.1:${(http.address() as { port: number }).port}`;
    const socket = await connect(url);
    const stranger = await connect(url);
    const errors: { code: string }[] = [];
    socket.on("game_error", (e: { code: string }) => errors.push(e));

    try {
      let roomId = "";
      let ackedInSettlement = false;
      await new Promise<void>((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("no settlement → next hand")), 60_000);
        const onRoom = (room: {
          phase: string;
          id: string;
          turnIndex?: number;
          players?: { id: string; isBanker?: boolean; bet?: number; pendingBankChoice?: unknown }[];
        }) => {
          roomId = room.id;
          const me = room.players?.find((p) => p.id === socket.id);
          if (room.phase === "settlement" && !ackedInSettlement) {
            ackedInSettlement = true;
            socket.emit("settlement_next", room.id);
          }
          if (ackedInSettlement && (room.phase === "betting" || room.phase === "waiting")) {
            clearTimeout(timer);
            socket.off("room_update", onRoom);
            resolve();
            return;
          }
          if (me?.pendingBankChoice) socket.emit("bank_keep_choice", { roomId: room.id, keep: false });
          if (room.phase === "betting" && me && !me.isBanker && me.bet === 0) {
            socket.emit("place_bet", { roomId: room.id, amount: 100 });
          }
          const nb = room.players?.filter((p) => !p.isBanker) ?? [];
          const turnId =
            room.phase === "playing"
              ? nb[room.turnIndex ?? 0]?.id
              : room.phase === "banker"
                ? room.players?.find((p) => p.isBanker)?.id
                : null;
          if (turnId === socket.id) socket.emit("stand", room.id);
        };
        socket.on("room_update", onRoom);
        socket.on("joined_room", onRoom);
        socket.emit("join_solo_room", { playerName: "NextTest", playerId: "settlementnext0001", botCount: 1 });
      });
      assert.equal(ackedInSettlement, true);
      assert.deepEqual(
        errors.filter((e) => e.code !== "BANK_MANDATORY"),
        [],
        "settlement_next no ha de donar error al jugador de la sala"
      );

      // Clic tardà fora de settlement: s'ignora sense error.
      const late = nextGameError(socket, 400);
      socket.emit("settlement_next", { roomId });
      assert.equal(await late, null);

      // Remitent que no és a la sala.
      const foreign = nextGameError(stranger);
      stranger.emit("settlement_next", roomId);
      assert.equal((await foreign)?.code, "NOT_IN_ROOM");

      // Payload invàlid.
      const bad = nextGameError(stranger);
      stranger.emit("settlement_next", 42);
      assert.equal((await bad)?.code, "BAD_PAYLOAD");
    } finally {
      socket.disconnect();
      stranger.disconnect();
      io.close();
      await new Promise<void>((r) => http.close(() => r()));
    }
  });
});
