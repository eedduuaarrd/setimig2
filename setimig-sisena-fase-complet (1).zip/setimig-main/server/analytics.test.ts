import { describe, it, before, after, beforeEach } from "node:test";
import assert from "node:assert/strict";
import fs from "fs/promises";
import os from "os";
import path from "path";
import {
  ANALYTICS_EVENT_NAMES,
  CLIENT_EVENTS,
  deleteAnalyticsForPlayer,
  eventFilePath,
  flushAnalytics,
  pruneAnalyticsOnStartup,
  pseudonymousId,
  resetAnalyticsForTests,
  sanitizeProps,
  track,
  trackGameFinished,
  trackGameStarted,
  noteHandForGame,
} from "./analytics.ts";
import { pruneDailyEventFiles, retentionLimits } from "./dataRetention.ts";
import { handlePostEvent } from "./analyticsHttp.ts";
import { issuePlayerToken } from "./playerToken.ts";
import { getProfile, touchLastSeen, upsertProfile, LAST_SEEN_RESOLUTION_MS } from "./profiles.ts";

let root = "";
const PLAYER = "a1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6";

async function readEvents(ts = Date.now()): Promise<Record<string, unknown>[]> {
  await flushAnalytics();
  try {
    const raw = await fs.readFile(eventFilePath(ts), "utf8");
    return raw.split("\n").filter(Boolean).map((l) => JSON.parse(l));
  } catch {
    return [];
  }
}

function mockRes() {
  const res = {
    statusCode: 200,
    body: undefined as unknown,
    status(code: number) {
      res.statusCode = code;
      return res;
    },
    json(body: unknown) {
      res.body = body;
      return res;
    },
    end() {
      return res;
    },
  };
  return res;
}

function req(body: Record<string, unknown>, playerId = PLAYER) {
  const token = issuePlayerToken(playerId);
  return {
    headers: { authorization: `Bearer ${token}`, "user-agent": "Mozilla/5.0 SecretUA", "x-forwarded-for": "203.0.113.7" },
    body,
    query: {},
    ip: "203.0.113.7",
  } as never;
}

describe("analítica first-party", () => {
  before(async () => {
    root = await fs.mkdtemp(path.join(os.tmpdir(), "setimig-analytics-"));
    process.env.ANALYTICS_DATA_DIR = path.join(root, "analytics");
    process.env.PROFILE_DATA_DIR = path.join(root, "profiles");
    process.env.SETIMIG_ANALYTICS_SALT = "test-salt-0123456789abcdef";
  });

  after(async () => {
    await fs.rm(root, { recursive: true, force: true });
    for (const k of ["ANALYTICS_DATA_DIR", "PROFILE_DATA_DIR", "SETIMIG_ANALYTICS_SALT", "SETIMIG_KEEP_ANALYTICS_DAYS"]) {
      delete process.env[k];
    }
  });

  beforeEach(async () => {
    resetAnalyticsForTests();
    await fs.rm(path.join(root, "analytics"), { recursive: true, force: true });
  });

  it("té el catàleg de 14 esdeveniments (17 noms) i el client només en pot enviar uns quants", () => {
    assert.equal(ANALYTICS_EVENT_NAMES.length, 17);
    for (const e of CLIENT_EVENTS) assert.ok(ANALYTICS_EVENT_NAMES.includes(e));
    assert.ok(!CLIENT_EVENTS.has("hand_completed"));
    assert.ok(!CLIENT_EVENTS.has("player_registered"));
  });

  it("valida els camps: descarta camps desconeguts i tipus incorrectes", () => {
    assert.equal(sanitizeProps("no_existeix", {}), null);
    assert.equal(sanitizeProps("hand_completed", [1]), null);
    const clean = sanitizeProps("hand_completed", {
      mode: "tournament",
      result: "win",
      chipDelta: 12.4,
      handIndex: "5",
      email: "a@b.cat",
      name: "Laia",
    });
    assert.deepEqual(clean, { mode: "tournament", result: "win", chipDelta: 12 });
    assert.deepEqual(sanitizeProps("game_started", { mode: "casino" }), {});
    assert.deepEqual(sanitizeProps("session_end", { durationSec: 999_999 }), { durationSec: 86_400 });
  });

  it("pid pseudònim: HMAC estable, no conté el playerId i canvia si es rota la sal", async () => {
    const a = await pseudonymousId(PLAYER);
    assert.match(a, /^[0-9a-f]{32}$/);
    assert.equal(a, await pseudonymousId(PLAYER));
    assert.ok(!a.includes(PLAYER.slice(0, 8)));
    process.env.SETIMIG_ANALYTICS_SALT = "una-altra-sal-0123456789";
    resetAnalyticsForTests();
    assert.notEqual(await pseudonymousId(PLAYER), a);
    process.env.SETIMIG_ANALYTICS_SALT = "test-salt-0123456789abcdef";
    resetAnalyticsForTests();
  });

  it("POST /api/events desa l'esdeveniment sense IP, user-agent, nom ni playerId", async () => {
    await upsertProfile(PLAYER, { displayName: "Laia" });
    const res = mockRes();
    await handlePostEvent(
      req({ event: "session_start", sid: "abcdef0123456789", appVersion: "sw-v76", platform: "pwa", props: { email: "x@y.z" } }),
      res as never,
    );
    assert.equal(res.statusCode, 204);
    const rows = await readEvents();
    assert.equal(rows.length, 1);
    const row = rows[0]!;
    assert.equal(row.event, "session_start");
    assert.equal(row.isTest, false);
    assert.equal(row.platform, "pwa");
    assert.equal(row.daysSinceRegister, 0);
    const raw = JSON.stringify(row);
    for (const leak of [PLAYER, "203.0.113.7", "SecretUA", "Laia", "x@y.z"]) {
      assert.ok(!raw.includes(leak), `no ha de contenir ${leak}`);
    }
    assert.deepEqual(
      Object.keys(row).sort(),
      ["appVersion", "daysSinceRegister", "event", "isTest", "pid", "platform", "sid", "ts"].sort(),
    );
  });

  it("POST /api/events rebutja esdeveniments de servidor, desconeguts o sense identitat", async () => {
    for (const event of ["hand_completed", "player_registered", "hack", ""]) {
      const res = mockRes();
      await handlePostEvent(req({ event }), res as never);
      assert.equal(res.statusCode, 400, event);
    }
    const res = mockRes();
    await handlePostEvent({ headers: {}, body: { event: "session_start" }, query: {} } as never, res as never);
    assert.equal(res.statusCode, 400);
    assert.equal((await readEvents()).length, 0);
  });

  it("isTest: per nom de prova al servidor o per marca del client (que no pot treure-la)", async () => {
    const testPlayer = "f0f1f2f3f4f5f6f7f8f9fafbfcfdfeff";
    await upsertProfile(testPlayer, { displayName: "Test Audit 3" });
    await track(testPlayer, "limit_set", { limitType: "time", value: 30 });
    await track(PLAYER, "exp_exposure", { expId: "onboarding5", variant: "b" }, { isTest: true });
    await track(testPlayer, "limit_hit", { limitType: "time", value: 30 }, { isTest: false });
    const rows = await readEvents();
    assert.deepEqual(rows.map((r) => r.isTest), [true, true, true]);
  });

  it("partides: game_started → game_finished i tournament_finished amb posició", async () => {
    await upsertProfile(PLAYER, { displayName: "Laia" });
    const room = {
      id: "solo-x",
      soloAi: true,
      fastTournament: true,
      minBet: 50,
      players: [
        { playerId: PLAYER, chips: 0, name: "Laia" },
        { playerId: "bot-1", isBot: true, chips: 3000 },
        { playerId: "bot-2", isBot: true, chips: 1000 },
      ],
    };
    trackGameStarted(room);
    trackGameStarted(room); // idempotent
    noteHandForGame(room.id, PLAYER);
    noteHandForGame(room.id, PLAYER);
    trackGameFinished(room, PLAYER, "complete");
    trackGameFinished(room, PLAYER, "leave"); // ja tancada: no duplica
    await new Promise((r) => setTimeout(r, 20));
    const rows = await readEvents();
    assert.deepEqual(rows.map((r) => r.event), ["game_started", "game_finished", "tournament_finished"]);
    assert.equal(rows[0]!.mode, "tournament");
    assert.equal(rows[0]!.bots, 2);
    assert.equal(rows[1]!.hands, 2);
    assert.equal(rows[1]!.endedBy, "complete");
    assert.equal(rows[2]!.position, 3);
    assert.equal(rows[2]!.entrants, 3);
  });

  it("poda: conserva només els dies de retenció (per defecte ~13 mesos) i mai el d'avui", async () => {
    assert.equal(retentionLimits().analyticsDays, 395);
    const dir = path.join(root, "analytics");
    await fs.mkdir(dir, { recursive: true });
    for (const d of ["2025-01-01", "2025-09-25", "2025-09-27", "2026-10-26"]) {
      await fs.writeFile(path.join(dir, `events-${d}.jsonl`), "{}\n");
    }
    await fs.writeFile(path.join(dir, ".salt"), "x".repeat(64));
    const removed = await pruneAnalyticsOnStartup(Date.parse("2026-10-26T12:00:00Z"));
    assert.deepEqual(removed.sort(), ["events-2025-01-01.jsonl", "events-2025-09-25.jsonl"]);
    process.env.SETIMIG_KEEP_ANALYTICS_DAYS = "1";
    const removed2 = await pruneDailyEventFiles(dir, retentionLimits().analyticsDays, "2026-10-26");
    assert.deepEqual(removed2, ["events-2025-09-27.jsonl"]);
    delete process.env.SETIMIG_KEEP_ANALYTICS_DAYS;
    assert.deepEqual((await fs.readdir(dir)).sort(), [".salt", "events-2026-10-26.jsonl"]);
  });

  it("esborrat per jugador (pid)", async () => {
    const other = "0123456789abcdef0123456789abcdef";
    await track(PLAYER, "limit_set", { limitType: "hands", value: 50 });
    await track(other, "limit_set", { limitType: "hands", value: 20 });
    assert.equal(await deleteAnalyticsForPlayer(PLAYER), 1);
    const rows = await readEvents();
    assert.equal(rows.length, 1);
    assert.equal(rows[0]!.pid, await pseudonymousId(other));
  });
});

describe("perfils: createdAt i lastSeen", () => {
  before(async () => {
    root = root || (await fs.mkdtemp(path.join(os.tmpdir(), "setimig-analytics-")));
    process.env.PROFILE_DATA_DIR = path.join(root, "profiles-2");
  });
  after(() => {
    delete process.env.PROFILE_DATA_DIR;
  });

  it("createdAt es fixa en crear i no es sobreescriu en actualitzar", async () => {
    const id = "c0ffee00c0ffee00c0ffee00c0ffee00";
    const first = await upsertProfile(id, { displayName: "Pere" });
    assert.ok(first?.createdAt);
    await new Promise((r) => setTimeout(r, 5));
    const second = await upsertProfile(id, { displayName: "Pere 2" });
    assert.equal(second?.createdAt, first!.createdAt);
    assert.ok(second!.updatedAt >= first!.updatedAt);
    assert.equal((await getProfile(id))?.createdAt, first!.createdAt);
  });

  it("perfils antics sense createdAt: no s'inventa", async () => {
    const id = "badc0ffee0badc0ffee0badc0ffee000";
    await fs.mkdir(process.env.PROFILE_DATA_DIR!, { recursive: true });
    await fs.writeFile(
      path.join(process.env.PROFILE_DATA_DIR!, `${id}.json`),
      JSON.stringify({ displayName: "Antic", avatarDataUrl: null, updatedAt: 1 }),
    );
    const saved = await upsertProfile(id, { displayName: "Antic" });
    assert.equal(saved?.createdAt, undefined);
    assert.ok(saved?.lastSeen);
  });

  it("touchLastSeen actualitza lastSeen amb resolució i no toca createdAt", async () => {
    const id = "deadbeefdeadbeefdeadbeefdeadbeef";
    assert.equal(await touchLastSeen(id), null);
    const created = await upsertProfile(id, { displayName: "Marta" });
    const t0 = created!.lastSeen!;
    const same = await touchLastSeen(id, t0 + 1000);
    assert.equal(same?.lastSeen, t0);
    const later = await touchLastSeen(id, t0 + LAST_SEEN_RESOLUTION_MS + 1);
    assert.equal(later?.lastSeen, t0 + LAST_SEEN_RESOLUTION_MS + 1);
    const reread = await getProfile(id);
    assert.equal(reread?.createdAt, created!.createdAt);
    assert.equal(reread?.updatedAt, created!.updatedAt);
    assert.equal(reread?.displayName, "Marta");
  });
});
