import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import fs from "fs/promises";
import path from "path";
import {
  getAchievementsView,
  getMissionsView,
  getWeeklyLeaderboardView,
  onHandRecordedForEngagement,
  onMatchRecordedForEngagement,
  WEEKLY_LEADERBOARD_MAX,
} from "./achievementsEngine.ts";
import { addWeeklyChipsWon, flushEngagementWritesForTests, resetEngagementCacheForTests } from "./achievementsStore.ts";
import { resetBalanceStoreCacheForTests, setBalance } from "./balances.ts";
import { madridWeekKey } from "./achievementsTime.ts";
import { getProfile, upsertProfile, resolvedAvatarForProfile, InvalidAvatarError } from "./profiles.ts";
import {
  AVATAR_COLOR_IDS,
  LEGACY_AVATAR_COLOR_MAP,
  normalizeStoredAvatar,
  parseAvatarPatch,
  toPlayerAvatarView,
  type PlayerAvatarConfig,
} from "../shared/playerAvatar.ts";

const ROOT = path.join(process.cwd(), "data", `f24-test-${Date.now()}`);
const PROFILES = path.join(ROOT, "profiles");
const AT = Date.UTC(2026, 6, 8, 12, 0, 0);
/** Setmana diferent de la d'AT perquè les mans dels altres tests no afectin el rànquing. */
const LB_AT = Date.UTC(2026, 7, 19, 12, 0, 0);
const boardFor = (limit: unknown, viewer: string | null) => getWeeklyLeaderboardView(limit, LB_AT, viewer);

function hand(playerId: string, over: Partial<Parameters<typeof onHandRecordedForEngagement>[0]> = {}) {
  return onHandRecordedForEngagement({
    playerId,
    result: "win",
    chipDelta: 0,
    passed: false,
    naturalSevenHalf: false,
    practice: false,
    at: AT,
    ...over,
  });
}

describe("F2.4 · forats de l'API", () => {
  before(() => {
    process.env.BALANCE_DATA_DIR = ROOT;
    process.env.PROFILE_DATA_DIR = PROFILES;
    process.env.SETIMIG_TEST_FAST = "1";
    resetEngagementCacheForTests();
    resetBalanceStoreCacheForTests();
  });

  after(async () => {
    await flushEngagementWritesForTests().catch(() => undefined);
    resetEngagementCacheForTests();
    await fs.rm(ROOT, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 }).catch(() => undefined);
    delete process.env.BALANCE_DATA_DIR;
    delete process.env.PROFILE_DATA_DIR;
  });

  describe("/api/achievements · progrés", () => {
    it("jugador nou: tots a 0 amb el target de cada assoliment", async () => {
      const list = await getAchievementsView("f24fresh01");
      assert.equal(list.length, 5);
      for (const a of list) {
        assert.deepEqual(Object.keys(a.progress).sort(), ["current", "target", "unlocked"]);
        assert.equal(a.progress.current, 0);
        assert.equal(a.progress.unlocked, false);
        assert.ok(a.progress.target >= 1);
      }
      assert.equal(list.find((a) => a.id === "ten_wins")?.progress.target, 10);
      assert.equal(list.find((a) => a.id === "no_bust_five")?.progress.target, 5);
    });

    it("el progrés segueix els comptadors i queda al target en desbloquejar", async () => {
      const id = "f24progress01";
      await setBalance(id, 1000);
      for (let i = 0; i < 3; i += 1) await hand(id);
      await hand(id, { result: "lose", passed: true });
      await onMatchRecordedForEngagement({ playerId: id, viewerOutcome: "win", practice: false, at: AT });
      const list = await getAchievementsView(id);
      const by = (k: string) => list.find((a) => a.id === k)!;
      assert.deepEqual(by("ten_wins").progress, { current: 3, target: 10, unlocked: false });
      assert.deepEqual(by("first_win").progress, { current: 1, target: 1, unlocked: true });
      assert.equal(by("first_win").unlocked, by("first_win").progress.unlocked);
      // La ratxa s'ha trencat amb la mà passada.
      assert.deepEqual(by("no_bust_five").progress, { current: 0, target: 5, unlocked: false });
      assert.deepEqual(by("first_match_win").progress, { current: 1, target: 1, unlocked: true });
      assert.deepEqual(by("natural_seven_half").progress, { current: 0, target: 1, unlocked: false });
    });

    it("un cop desbloquejat, el progrés no baixa encara que el comptador es reiniciï", async () => {
      const id = "f24streak01";
      await setBalance(id, 1000);
      for (let i = 0; i < 5; i += 1) await hand(id, { result: "lose" });
      await hand(id, { result: "lose", passed: true });
      const a = (await getAchievementsView(id)).find((x) => x.id === "no_bust_five")!;
      assert.deepEqual(a.progress, { current: 5, target: 5, unlocked: true });
    });
  });

  describe("claus i18n d'assoliments i missions", () => {
    it("assoliments: titleKey/descKey estables i el text català es manté", async () => {
      const list = await getAchievementsView("f24fresh01");
      const first = list.find((a) => a.id === "first_win")!;
      assert.equal(first.titleKey, "achievements.first_win.title");
      assert.equal(first.descKey, "achievements.first_win.desc");
      assert.equal(first.title, "Primera victòria");
      assert.ok(first.description.length > 0);
      for (const a of list) {
        assert.equal(a.titleKey, `achievements.${a.id}.title`);
        assert.equal(a.descKey, `achievements.${a.id}.desc`);
      }
    });

    it("missions: code + titleKey + params, amb els camps antics intactes", async () => {
      const view = await getMissionsView("f24fresh01", AT);
      assert.equal(view.missions.length, 3);
      for (const m of view.missions) {
        assert.equal(m.code, m.kind);
        assert.equal(m.titleKey, `missions.${m.kind}.title`);
        assert.deepEqual(m.params, { target: m.target });
        assert.ok(m.title.length > 0);
        assert.equal(typeof m.progress, "number");
      }
    });
  });

  describe("/api/leaderboard/weekly · noms i «me»", () => {
    const N = 55;
    const pid = (i: number) => `f24lb${String(i).padStart(3, "0")}`;

    before(async () => {
      resetEngagementCacheForTests();
      const week = madridWeekKey(LB_AT);
      for (let i = 0; i < N; i += 1) await addWeeklyChipsWon(week, pid(i), (N - i) * 10);
      await upsertProfile(pid(0), { displayName: "Reina d'Or" });
      await upsertProfile(pid(54), { displayName: "Darrer" });
    });

    it("limita a 50 i afegeix rank i displayName (públic)", async () => {
      const board = await boardFor(500, null);
      assert.equal(board.entries.length, WEEKLY_LEADERBOARD_MAX);
      assert.equal(board.weekKey, madridWeekKey(LB_AT));
      assert.equal(board.totalPlayers, N);
      assert.deepEqual(board.entries[0], { playerId: pid(0), chipsWon: 550, rank: 1, displayName: "Reina d'Or" });
      assert.equal(board.entries[1]!.displayName, "Jugador");
      board.entries.forEach((e, i) => assert.equal(e.rank, i + 1));
      for (const e of board.entries) {
        assert.deepEqual(Object.keys(e).sort(), ["chipsWon", "displayName", "playerId", "rank"]);
      }
      assert.equal(board.me, null);
    });

    it("«me» fora del top 50 dona la posició real", async () => {
      const board = await boardFor(50, pid(54));
      assert.deepEqual(board.me, { playerId: pid(54), chipsWon: 10, rank: 55, displayName: "Darrer", inTop: false });
      assert.equal(board.entries.some((e) => e.playerId === pid(54)), false);
    });

    it("«me» dins del top i jugador sense fitxes aquesta setmana", async () => {
      const top = await boardFor(10, pid(0));
      assert.equal(top.me?.rank, 1);
      assert.equal(top.me?.inTop, true);
      assert.equal(top.entries.length, 10);
      const none = await boardFor(10, "f24nobody01");
      assert.deepEqual(none.me, { playerId: "f24nobody01", chipsWon: 0, rank: null, displayName: "Jugador", inTop: false });
    });
  });

  describe("paleta d'avatars sense verds", () => {
    it("la paleta nova no té verds i cada color retirat té substitut a la paleta", () => {
      for (const green of ["emerald", "teal", "moss"]) {
        assert.equal((AVATAR_COLOR_IDS as readonly string[]).includes(green), false);
      }
      assert.deepEqual(LEGACY_AVATAR_COLOR_MAP, { emerald: "gold", teal: "onyx", moss: "ivory" });
      for (const v of Object.values(LEGACY_AVATAR_COLOR_MAP)) {
        assert.ok((AVATAR_COLOR_IDS as readonly string[]).includes(v));
      }
      assert.equal(AVATAR_COLOR_IDS.length, 8);
    });

    it("PUT (escriptura) només accepta la paleta nova", async () => {
      for (const color of ["emerald", "teal", "moss"]) {
        assert.equal(parseAvatarPatch({ kind: "symbol", symbol: "star", color }, "X"), null);
        await assert.rejects(
          () => upsertProfile("f24avatarput01", { avatar: { kind: "symbol", symbol: "star", color } }),
          InvalidAvatarError
        );
      }
      for (const color of ["gold", "onyx", "ivory", "wine"]) {
        const saved = await upsertProfile("f24avatarput01", { avatar: { kind: "initials", initials: "ab", color } });
        assert.equal(saved?.avatar?.color, color);
      }
    });

    it("perfils desats amb un verd es continuen llegint, amb el substitut", async () => {
      await fs.mkdir(PROFILES, { recursive: true });
      const cases: [string, string, PlayerAvatarConfig["kind"]][] = [
        ["f24legacy01", "emerald", "initials"],
        ["f24legacy02", "teal", "symbol"],
        ["f24legacy03", "moss", "initials"],
      ];
      for (const [id, color, kind] of cases) {
        const avatar = kind === "symbol" ? { kind, symbol: "heart", color } : { kind, initials: "QZ", color };
        await fs.writeFile(
          path.join(PROFILES, `${id}.json`),
          JSON.stringify({ displayName: "Antic", avatarDataUrl: null, avatar, updatedAt: 1 }),
          "utf8"
        );
        const loaded = await getProfile(id);
        assert.ok(loaded?.avatar, `${id} conserva l'avatar`);
        assert.equal(loaded!.avatar!.kind, kind);
        assert.equal(loaded!.avatar!.color, LEGACY_AVATAR_COLOR_MAP[color as keyof typeof LEGACY_AVATAR_COLOR_MAP]);
        assert.equal(resolvedAvatarForProfile(loaded!, id).color, loaded!.avatar!.color);
      }
      // Desar un altre camp reescriu el perfil ja amb el color nou, sense error.
      const saved = await upsertProfile("f24legacy01", { displayName: "Nou nom" });
      assert.equal(saved?.avatar?.color, "gold");
      assert.equal(saved?.avatar?.kind, "initials");
      if (saved?.avatar?.kind === "initials") assert.equal(saved.avatar.initials, "QZ");
    });

    it("lectura tolerant i vista de sala tradueixen colors retirats", () => {
      const cfg = normalizeStoredAvatar({ kind: "symbol", symbol: "seven", color: "moss" }, "X", "p1");
      assert.deepEqual(cfg, { kind: "symbol", symbol: "seven", color: "ivory" });
      const legacySeat = { kind: "initials", initials: "T", color: "teal" } as unknown as PlayerAvatarConfig;
      assert.equal(toPlayerAvatarView(legacySeat).color, "onyx");
    });
  });
});
