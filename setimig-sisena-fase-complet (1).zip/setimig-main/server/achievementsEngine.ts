import type { HandOutcome } from "../src/gameTypes.ts";
import { ACHIEVEMENT_BY_ID, ACHIEVEMENT_DEFS, achievementI18nKeys, type AchievementDef } from "./achievementsCatalog.ts";
import { madridDayKey, madridWeekKey } from "./achievementsTime.ts";
import { dailyMissionsForDay, missionI18n, type MissionKind } from "./missionsCatalog.ts";
import {
  addWeeklyChipsWon,
  readEngagement,
  type EngagementFile,
  withEngagement,
} from "./achievementsStore.ts";
import { DEFAULT_CHIPS, runBalanceTransaction } from "./balances.ts";
import { getProfile } from "./profiles.ts";
import { trackLater } from "./analytics.ts";

export type HandEngagementInput = {
  playerId: string;
  result: HandOutcome;
  chipDelta: number;
  passed: boolean;
  naturalSevenHalf: boolean;
  practice: boolean;
  at?: number;
};

function isWin(result: HandOutcome): boolean {
  return result === "win" || result === "jackpot";
}

function missionProgressForKind(
  file: EngagementFile,
  missionId: string,
  kind: MissionKind,
  hand: HandEngagementInput
): number {
  const row = file.missionProgress[missionId] ?? { progress: 0, claimedAt: null };
  let add = 0;
  switch (kind) {
    case "win_hands":
      if (isWin(hand.result)) add = 1;
      break;
    case "play_hands":
      add = 1;
      break;
    case "win_chips":
      if (hand.chipDelta > 0) add = hand.chipDelta;
      break;
    case "no_pass_hands":
      if (!hand.passed) add = 1;
      break;
    default:
      break;
  }
  row.progress += add;
  file.missionProgress[missionId] = row;
  return row.progress;
}

async function creditRewardOnce(
  file: EngagementFile,
  playerId: string,
  ledgerKey: string,
  chips: number
): Promise<number> {
  if (file.rewardLedger.includes(ledgerKey)) return 0;
  file.rewardLedger.push(ledgerKey);
  let credited = 0;
  await runBalanceTransaction(async (store) => {
    const entry = store.accounts[playerId];
    const current = entry?.chips ?? DEFAULT_CHIPS;
    const next = Math.min(999_999_999, current + chips);
    store.accounts[playerId] = { chips: next, lastClaimAt: entry?.lastClaimAt ?? null };
    credited = chips;
  });
  return credited;
}

function tryUnlockAchievements(file: EngagementFile, playerId: string, at: number): Promise<number> {
  const unlocks: { id: string; reward: number }[] = [];
  const c = file.counters;
  const maybe = (id: string, cond: boolean) => {
    if (!cond || file.achievementsUnlocked[id]) return;
    const def = ACHIEVEMENT_BY_ID.get(id);
    if (!def) return;
    file.achievementsUnlocked[id] = { at, rewarded: false };
    unlocks.push({ id, reward: def.rewardChips });
  };
  maybe("first_win", c.realWins >= 1);
  maybe("ten_wins", c.realWins >= 10);
  maybe("no_bust_five", c.noPassStreak >= 5);
  maybe("first_match_win", c.matchWins >= 1);

  return (async () => {
    let total = 0;
    for (const u of unlocks) {
      const ledgerKey = `achievement:${u.id}`;
      const credited = await creditRewardOnce(file, playerId, ledgerKey, u.reward);
      if (credited > 0) {
        const row = file.achievementsUnlocked[u.id];
        if (row) row.rewarded = true;
        total += credited;
      }
    }
    return total;
  })();
}

export async function onHandRecordedForEngagement(hand: HandEngagementInput): Promise<void> {
  if (hand.practice) return;
  const at = hand.at ?? Date.now();
  const dayKey = madridDayKey(at);
  const weekKey = madridWeekKey(at);
  const missions = dailyMissionsForDay(dayKey);

  await withEngagement(hand.playerId, async (file) => {
    file.counters.realHandsPlayed += 1;
    if (isWin(hand.result)) file.counters.realWins += 1;
    if (hand.passed) file.counters.noPassStreak = 0;
    else file.counters.noPassStreak += 1;
    if (hand.naturalSevenHalf && !file.achievementsUnlocked.natural_seven_half) {
      file.achievementsUnlocked.natural_seven_half = { at, rewarded: false };
      const def = ACHIEVEMENT_BY_ID.get("natural_seven_half");
      if (def) {
        const credited = await creditRewardOnce(
          file,
          hand.playerId,
          "achievement:natural_seven_half",
          def.rewardChips
        );
        if (credited > 0) file.achievementsUnlocked.natural_seven_half.rewarded = true;
      }
    }

    for (const m of missions) {
      const before = file.missionProgress[m.id]?.progress ?? 0;
      const after = missionProgressForKind(file, m.id, m.kind, hand);
      // Analítica: només quan la missió arriba a l'objectiu (no a cada mà).
      if (before < m.target && after >= m.target) {
        trackLater(hand.playerId, "mission_progress", { missionKey: `${m.kind}-${m.target}`, progress: m.target });
      }
    }

    await tryUnlockAchievements(file, hand.playerId, at);

    if (hand.chipDelta > 0) {
      await addWeeklyChipsWon(weekKey, hand.playerId, hand.chipDelta);
    }
  });
}

export type MatchEngagementInput = {
  playerId: string;
  viewerOutcome: "win" | "lose" | "eliminated" | null;
  practice: boolean;
  at?: number;
};

export async function onMatchRecordedForEngagement(match: MatchEngagementInput): Promise<void> {
  if (match.practice || match.viewerOutcome !== "win") return;
  const at = match.at ?? Date.now();
  await withEngagement(match.playerId, async (file) => {
    file.counters.matchWins += 1;
    await tryUnlockAchievements(file, match.playerId, at);
  });
}

export type AchievementProgress = { current: number; target: number; unlocked: boolean };

export type AchievementView = {
  id: string;
  /** Text català (fallback); el client pot traduir amb `titleKey` / `descKey`. */
  title: string;
  description: string;
  titleKey: string;
  descKey: string;
  rewardChips: number;
  unlocked: boolean;
  unlockedAt: number | null;
  rewarded: boolean;
  progress: AchievementProgress;
};

/** Valor brut del comptador associat a cada assoliment (sense limitar al target). */
function achievementCounterValue(def: AchievementDef, file: EngagementFile): number {
  const c = file.counters;
  switch (def.id) {
    case "first_win":
    case "ten_wins":
      return c.realWins;
    case "no_bust_five":
      return c.noPassStreak;
    case "first_match_win":
      return c.matchWins;
    default:
      // natural_seven_half i futurs assoliments binaris: no hi ha comptador acumulat.
      return 0;
  }
}

export function achievementProgress(def: AchievementDef, file: EngagementFile): AchievementProgress {
  const unlocked = !!file.achievementsUnlocked[def.id];
  const target = def.target;
  const current = unlocked ? target : Math.max(0, Math.min(target, achievementCounterValue(def, file)));
  return { current, target, unlocked };
}

export async function getAchievementsView(playerId: string): Promise<AchievementView[]> {
  const file = await readEngagement(playerId);
  return ACHIEVEMENT_DEFS.map((def) => {
    const row = file.achievementsUnlocked[def.id];
    return {
      id: def.id,
      title: def.title,
      description: def.description,
      ...achievementI18nKeys(def.id),
      rewardChips: def.rewardChips,
      unlocked: !!row,
      unlockedAt: row?.at ?? null,
      rewarded: row?.rewarded ?? false,
      progress: achievementProgress(def, file),
    };
  });
}

export type MissionView = {
  id: string;
  dayKey: string;
  /** Text català (fallback); el client pot traduir amb `titleKey` + `params`. */
  title: string;
  code: MissionKind;
  titleKey: string;
  params: { target: number };
  kind: MissionKind;
  target: number;
  progress: number;
  rewardChips: number;
  completed: boolean;
  claimed: boolean;
  claimedAt: number | null;
};

export async function getMissionsView(playerId: string, nowMs: number = Date.now()): Promise<{
  dayKey: string;
  missions: MissionView[];
}> {
  const dayKey = madridDayKey(nowMs);
  const templates = dailyMissionsForDay(dayKey);
  const file = await readEngagement(playerId);
  const missions: MissionView[] = templates.map((m) => {
    const row = file.missionProgress[m.id] ?? { progress: 0, claimedAt: null };
    const progress = Math.min(row.progress, m.target);
    return {
      id: m.id,
      dayKey: m.dayKey,
      title: m.title,
      ...missionI18n(m.kind, m.target),
      kind: m.kind,
      target: m.target,
      progress,
      rewardChips: m.rewardChips,
      completed: row.progress >= m.target,
      claimed: row.claimedAt != null,
      claimedAt: row.claimedAt,
    };
  });
  return { dayKey, missions };
}

export type ClaimMissionResult =
  | { ok: true; missionId: string; credited: number; chips: number }
  | { ok: false; code: "NOT_FOUND" | "INCOMPLETE" | "ALREADY_CLAIMED" };

export async function claimDailyMission(
  playerId: string,
  missionId: string,
  nowMs: number = Date.now()
): Promise<ClaimMissionResult> {
  const dayKey = madridDayKey(nowMs);
  const templates = dailyMissionsForDay(dayKey);
  const mission = templates.find((m) => m.id === missionId);
  if (!mission) return { ok: false, code: "NOT_FOUND" };

  return withEngagement(playerId, async (file) => {
    const row = file.missionProgress[missionId] ?? { progress: 0, claimedAt: null };
    if (row.claimedAt != null) return { ok: false, code: "ALREADY_CLAIMED" };
    if (row.progress < mission.target) return { ok: false, code: "INCOMPLETE" };

    const ledgerKey = `mission:${missionId}`;
    const credited = await creditRewardOnce(file, playerId, ledgerKey, mission.rewardChips);
    row.claimedAt = nowMs;
    file.missionProgress[missionId] = row;

    const entry = await runBalanceTransaction(async (store) => store.accounts[playerId]?.chips ?? DEFAULT_CHIPS);
    return { ok: true, missionId, credited, chips: entry };
  });
}

export const WEEKLY_LEADERBOARD_MAX = 50;

export type WeeklyLeaderboardEntry = {
  playerId: string;
  chipsWon: number;
  /** Posició 1-based dins del rànquing complet de la setmana. */
  rank: number;
  /** Nom públic del perfil (el mateix que es veu a taula); "Jugador" si no n'hi ha. */
  displayName: string;
};

export type WeeklyLeaderboardView = {
  weekKey: string;
  entries: WeeklyLeaderboardEntry[];
  /** Entrada de qui fa la petició, encara que quedi fora del top; null si no s'identifica. */
  me: (Omit<WeeklyLeaderboardEntry, "rank"> & { rank: number | null; inTop: boolean }) | null;
  totalPlayers: number;
};

async function publicDisplayName(playerId: string): Promise<string> {
  try {
    const profile = await getProfile(playerId);
    return profile?.displayName ?? "Jugador";
  } catch {
    return "Jugador";
  }
}

export async function getWeeklyLeaderboardView(
  limitRaw: unknown,
  nowMs: number = Date.now(),
  viewerPlayerId: string | null = null
): Promise<WeeklyLeaderboardView> {
  const limit = Math.min(WEEKLY_LEADERBOARD_MAX, Math.max(1, Math.floor(Number(limitRaw) || 10)));
  const weekKey = madridWeekKey(nowMs);
  const { getWeeklyLeaderboardRanked } = await import("./achievementsStore.ts");
  const ranked = await getWeeklyLeaderboardRanked(weekKey);
  const top = ranked.slice(0, limit);
  const entries = await Promise.all(
    top.map(async (row, i) => ({
      playerId: row.playerId,
      chipsWon: row.chipsWon,
      rank: i + 1,
      displayName: await publicDisplayName(row.playerId),
    }))
  );

  let me: WeeklyLeaderboardView["me"] = null;
  if (viewerPlayerId) {
    const idx = ranked.findIndex((row) => row.playerId === viewerPlayerId);
    const inTop = idx >= 0 && idx < limit;
    me = {
      playerId: viewerPlayerId,
      chipsWon: idx >= 0 ? ranked[idx]!.chipsWon : 0,
      rank: idx >= 0 ? idx + 1 : null,
      displayName: inTop ? entries[idx]!.displayName : await publicDisplayName(viewerPlayerId),
      inTop,
    };
  }
  return { weekKey, entries, me, totalPlayers: ranked.length };
}
