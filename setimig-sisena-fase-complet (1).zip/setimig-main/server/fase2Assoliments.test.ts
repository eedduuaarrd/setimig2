import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import fs from "fs/promises";
import path from "path";
import {
  claimDailyMission,
  getAchievementsView,
  getMissionsView,
  getWeeklyLeaderboardView,
  onHandRecordedForEngagement,
} from "./achievementsEngine.ts";
import { dailyMissionsForDay } from "./missionsCatalog.ts";
import { madridDayKey, madridWeekKey } from "./achievementsTime.ts";
import { resetEngagementCacheForTests, readEngagementForTests } from "./achievementsStore.ts";
import { getBalance, resetBalanceStoreCacheForTests, setBalance } from "./balances.ts";

const DATA_ROOT = path.join(process.cwd(), "data", `fase2-test-${Date.now()}`);
const PLAYER = "fase2player01";

describe("fase2 assoliments", () => {
  before(() => {
    process.env.BALANCE_DATA_DIR = DATA_ROOT;
    process.env.SETIMIG_TEST_FAST = "1";
    resetEngagementCacheForTests();
    resetBalanceStoreCacheForTests();
  });

  after(async () => {
    await fs.rm(DATA_ROOT, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 }).catch(() => undefined);
    delete process.env.BALANCE_DATA_DIR;
  });

  it("mode pràctica no compta per assoliments, missions ni rànquing", async () => {
    await setBalance(PLAYER, 1000);
    await onHandRecordedForEngagement({
      playerId: PLAYER,
      result: "win",
      chipDelta: 500,
      passed: false,
      naturalSevenHalf: true,
      practice: true,
      at: Date.UTC(2026, 5, 10, 12, 0, 0),
    });
    const achievements = await getAchievementsView(PLAYER);
    assert.equal(achievements.find((a) => a.id === "first_win")?.unlocked, false);
    const missions = await getMissionsView(PLAYER, Date.UTC(2026, 5, 10, 12, 0, 0));
    assert.equal(missions.missions.every((m) => m.progress === 0), true);
    const board = await getWeeklyLeaderboardView(10, Date.UTC(2026, 5, 10, 12, 0, 0));
    assert.equal(board.entries.length, 0);
    assert.equal(await getBalance(PLAYER), 1000);
  });

  it("primera victòria real desbloqueja i premia una sola vegada", async () => {
    resetEngagementCacheForTests();
    resetBalanceStoreCacheForTests();
    await setBalance(PLAYER, 2000);
    const at = Date.UTC(2026, 5, 11, 15, 0, 0);
    await onHandRecordedForEngagement({
      playerId: PLAYER,
      result: "win",
      chipDelta: 100,
      passed: false,
      naturalSevenHalf: false,
      practice: false,
      at,
    });
    await onHandRecordedForEngagement({
      playerId: PLAYER,
      result: "win",
      chipDelta: 100,
      passed: false,
      naturalSevenHalf: false,
      practice: false,
      at,
    });
    const achievements = await getAchievementsView(PLAYER);
    const first = achievements.find((a) => a.id === "first_win");
    assert.equal(first?.unlocked, true);
    assert.equal(first?.rewarded, true);
    const balance = await getBalance(PLAYER);
    assert.equal(balance, 2000 + 500);
    const file = await readEngagementForTests(PLAYER);
    assert.equal(file.rewardLedger.filter((k) => k === "achievement:first_win").length, 1);
  });

  it("reclamació de missió idempotent", async () => {
    resetEngagementCacheForTests();
    resetBalanceStoreCacheForTests();
    await setBalance(PLAYER, 3000);
    const at = Date.UTC(2026, 5, 12, 10, 0, 0);
    const dayKey = madridDayKey(at);
    const [mission] = dailyMissionsForDay(dayKey);
    assert.ok(mission);
    for (let i = 0; i < mission.target; i += 1) {
      await onHandRecordedForEngagement({
        playerId: PLAYER,
        result: mission.kind === "win_hands" ? "win" : "lose",
        chipDelta: mission.kind === "win_chips" ? 400 : 0,
        passed: false,
        naturalSevenHalf: false,
        practice: false,
        at,
      });
    }
    const claim1 = await claimDailyMission(PLAYER, mission.id, at);
    assert.equal(claim1.ok, true);
    if (claim1.ok) {
      assert.equal(claim1.credited, mission.rewardChips);
    }
    const claim2 = await claimDailyMission(PLAYER, mission.id, at);
    assert.equal(claim2.ok, false);
    if (!claim2.ok) assert.equal(claim2.code, "ALREADY_CLAIMED");
    const file = await readEngagementForTests(PLAYER);
    assert.equal(file.rewardLedger.filter((k) => k === `mission:${mission.id}`).length, 1);
  });

  it("missions determinístiques per dia Madrid i canvi de dia", () => {
    const d1 = Date.UTC(2026, 0, 5, 8, 0, 0);
    const d2 = Date.UTC(2026, 0, 6, 8, 0, 0);
    const m1 = dailyMissionsForDay(madridDayKey(d1));
    const m1b = dailyMissionsForDay(madridDayKey(d1));
    const m2 = dailyMissionsForDay(madridDayKey(d2));
    assert.deepEqual(m1.map((x) => x.id), m1b.map((x) => x.id));
    assert.notDeepEqual(m1.map((x) => x.id), m2.map((x) => x.id));
    assert.equal(m1.length, 3);
  });

  it("rànquing setmanal acumula fitxes i canvia de setmana", async () => {
    resetEngagementCacheForTests();
    resetBalanceStoreCacheForTests();
    const weeklyPlayer = "fase2weekly01";
    const w1At = Date.UTC(2026, 5, 9, 12, 0, 0);
    const w2At = Date.UTC(2026, 5, 16, 12, 0, 0);
    await onHandRecordedForEngagement({
      playerId: weeklyPlayer,
      result: "win",
      chipDelta: 250,
      passed: false,
      naturalSevenHalf: false,
      practice: false,
      at: w1At,
    });
    const board1 = await getWeeklyLeaderboardView(5, w1At);
    assert.equal(board1.weekKey, madridWeekKey(w1At));
    assert.equal(board1.entries.find((e) => e.playerId === weeklyPlayer)?.chipsWon, 250);

    await onHandRecordedForEngagement({
      playerId: weeklyPlayer,
      result: "win",
      chipDelta: 900,
      passed: false,
      naturalSevenHalf: false,
      practice: false,
      at: w2At,
    });
    const board2 = await getWeeklyLeaderboardView(5, w2At);
    assert.notEqual(board2.weekKey, board1.weekKey);
    assert.equal(board2.entries[0]?.chipsWon, 900);
    const oldWeek = await getWeeklyLeaderboardView(5, w1At);
    assert.equal(oldWeek.entries[0]?.chipsWon, 250);
  });
});
