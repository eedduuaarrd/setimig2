import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import fs from "fs/promises";
import path from "path";
import express from "express";
import { createServer } from "http";
import { roomToView, emptyRoomBase, type Player } from "../shared/gameEngine.ts";
import { upsertProfile } from "./profiles.ts";
import { assignPlayerAvatar } from "./playerProfileAvatar.ts";
import { getGameHostForTests } from "./game.ts";

const TEST_DIR = path.join(process.cwd(), "data", "profiles-f2b-" + Date.now());

describe("f2b avatar sala", () => {
  before(() => {
    process.env.PROFILE_DATA_DIR = TEST_DIR;
  });

  after(async () => {
    await fs.rm(TEST_DIR, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 });
    delete process.env.PROFILE_DATA_DIR;
  });

  it("RoomView.players inclou avatar sense trencar la vista", async () => {
    const playerId = "roomavatar01";
    await upsertProfile(playerId, {
      displayName: "Toni",
      avatar: { kind: "initials", initials: "T", color: "ivory" },
    });
    const room = emptyRoomBase("r-avatar", "Test", 10, 1000);
    const human: Player = {
      id: "sock-1",
      playerId,
      seatToken: "seat-1",
      name: "Toni",
      chips: 1000,
      bet: 0,
      isBanker: false,
      status: "waiting",
      handSlots: [],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    await assignPlayerAvatar(human);
    room.players.push(human);
    const view = roomToView(room, human.id, getGameHostForTests());
    assert.equal(view.players.length, 1);
    assert.equal(view.players[0].avatar?.label, "T");
    assert.equal(view.players[0].avatar?.color, "ivory");
  });
});

describe("f2b avatar API perfil", () => {
  let httpServer: ReturnType<typeof createServer>;
  let port = 0;

  before(async () => {
    process.env.PROFILE_DATA_DIR = TEST_DIR;
    const { upsertProfile, resolvedAvatarForProfile, InvalidAvatarError } = await import(
      "./profiles.ts"
    );
    const { resolvePlayerFromRequest, sendPlayerResponse } = await import("./httpPlayerAuth.ts");
    const app = express();
    app.use(express.json());
    app.put("/api/profile", async (req, res) => {
      const resolved = resolvePlayerFromRequest(req);
      if (!resolved) return res.status(400).json({ error: "bad" });
      try {
        const saved = await upsertProfile(resolved.playerId, { avatar: req.body?.avatar });
        if (!saved) return res.status(400).json({ error: "bad" });
        sendPlayerResponse(res, { avatar: resolvedAvatarForProfile(saved, resolved.playerId) });
      } catch (error) {
        if (error instanceof InvalidAvatarError) return res.status(400).json({ error: "Avatar invalid." });
        throw error;
      }
    });
    await new Promise<void>((resolve) => {
      httpServer = createServer(app).listen(0, () => {
        const addr = httpServer.address();
        port = typeof addr === "object" && addr ? addr.port : 0;
        resolve();
      });
    });
  });

  after(async () => {
    await new Promise<void>((resolve) => httpServer.close(() => resolve()));
    await fs.rm(TEST_DIR, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 }).catch(() => undefined);
    delete process.env.PROFILE_DATA_DIR;
  });

  it("PUT perfil retorna 400 per avatar invàlid", async () => {
    const response = await fetch(`http://127.0.0.1:${port}/api/profile`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ playerId: "apiavatar01", avatar: { kind: "symbol", symbol: "nope", color: "emerald" } }),
    });
    assert.equal(response.status, 400);
  });
});
