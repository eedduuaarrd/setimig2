import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  applyBankOfferDecision,
  botAcceptsBankOffer,
  buildPendingBankChoice,
  isSetIMigScore,
  pickBankOfferWinner,
  playerHasSetIMigHand,
} from "./bankRules.ts";

describe("bankRules", () => {
  it("detects set i mig (7½) scores", () => {
    assert.equal(isSetIMigScore(7.5, "stood"), true);
    assert.equal(isSetIMigScore(7.5, "playing"), true);
    assert.equal(isSetIMigScore(7.5, "busted"), false);
    assert.equal(isSetIMigScore(7, "stood"), false);
  });

  it("picks first non-banker in play order with set i mig", () => {
    const order = [{ id: "a" }, { id: "b" }, { id: "c" }];
    const has = (p: { id: string }) => p.id === "b" || p.id === "c";
    assert.equal(pickBankOfferWinner(order, has)?.id, "b");
  });

  it("playerHasSetIMigHand ignores empty bets", () => {
    assert.equal(
      playerHasSetIMigHand([{ bet: 0, score: 7.5, status: "stood" }]),
      false
    );
    assert.equal(
      playerHasSetIMigHand([{ bet: 100, score: 7.5, status: "stood" }]),
      true
    );
  });

  it("mandatory offer when player refused before", () => {
    assert.deepEqual(buildPendingBankChoice({ id: "x" }), { mandatory: false });
    assert.deepEqual(buildPendingBankChoice({ id: "x", refusedBankBefore: true }), {
      mandatory: true,
    });
  });

  it("applyBankOfferDecision transfers bank or records refusal", () => {
    const players = [
      { id: "bank", isBanker: true },
      { id: "p1", isBanker: false, refusedBankBefore: false },
    ];
    const declined = applyBankOfferDecision(players, "p1", false, false);
    assert.equal(declined.accept, false);
    assert.equal(declined.refused, true);
    assert.equal(players[0].isBanker, true);
    assert.equal(players[1].refusedBankBefore, true);

    const accepted = applyBankOfferDecision(players, "p1", true, false);
    assert.equal(accepted.accept, true);
    assert.equal(players[0].isBanker, false);
    assert.equal(players[1].isBanker, true);
  });

  it("mandatory offer forces bank even if client declines", () => {
    const players = [
      { id: "bank", isBanker: true },
      { id: "p1", isBanker: false, refusedBankBefore: true },
    ];
    const result = applyBankOfferDecision(players, "p1", false, true);
    assert.equal(result.accept, true);
    assert.equal(players[1].isBanker, true);
  });

  it("bot accepts bank when enough chips", () => {
    assert.equal(botAcceptsBankOffer(500, 100), true);
    assert.equal(botAcceptsBankOffer(50, 100), false);
  });
});
