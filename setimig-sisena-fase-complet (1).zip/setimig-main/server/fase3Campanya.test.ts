import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import fs from "fs/promises";
import path from "path";
import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import { io as ioClient } from "socket.io-client";
import {
  getCampaignProgress,
  getPublicCampaignPayload,
  isCampaignLevelUnlocked,
  readCampaignFileForTests,
  recordCampaignAttempt,
  resetCampaignProgressCacheForTests,
} from "./campaignProgress.ts";
import {
  applyCampaignLevelToSoloRoom,
  evaluateCampaignLevelWon,
  recordCampaignMatchIfNeeded,
} from "./campaignMatch.ts";
import { emptyRoomBase, type Room } from "../shared/gameEngine.ts";
import { getCampaignLevel } from "../shared/campaignLevels.ts";
import { resolvePlayerFromRequest } from "./httpPlayerAuth.ts";
import { resetBalanceStoreCacheForTests, setBalance } from "./balances.ts";
import { resetGameStateForTests, setupGameHandlers } from "./game.ts";

const DATA_ROOT = path.join(process.cwd(), "data", `fase3-test-${Date.now()}`);
const CAMPAIGN_PLAYER = "fase3camp01";

describe("fase3 campanya servidor", () => {
  before(() => {
    process.env.BALANCE_DATA_DIR = DATA_ROOT;
    process.env.SETIMIG_TEST_FAST = "1";
    resetCampaignProgressCacheForTests();
    resetBalanceStoreCacheForTests();
  });

  after(async () => {
    resetGameStateForTests();
    await fs.rm(DATA_ROOT, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 }).catch(() => undefined);
    delete process.env.BALANCE_DATA_DIR;
  });

  it("progrés additiu: intents acumulats i desbloqueig progressiu", async () => {
    resetCampaignProgressCacheForTests();
    const p0 = await getCampaignProgress(CAMPAIGN_PLAYER);
    assert.equal(p0.highestUnlocked, 1);
    assert.ok(isCampaignLevelUnlocked(p0, 1));
    assert.ok(!isCampaignLevelUnlocked(p0, 2));

    await recordCampaignAttempt({
      playerId: CAMPAIGN_PLAYER,
      level: 1,
      roomId: "solo-x",
      won: true,
      endingChips: 2_100,
      startingChips: 1_500,
    });
    await recordCampaignAttempt({
      playerId: CAMPAIGN_PLAYER,
      level: 1,
      roomId: "solo-y",
      won: false,
      endingChips: 900,
      startingChips: 1_500,
    });

    const file = await readCampaignFileForTests(CAMPAIGN_PLAYER);
    assert.equal(file.completions.length, 2);
    assert.equal(file.highestUnlocked, 2);

    const api = await getPublicCampaignPayload(CAMPAIGN_PLAYER);
    assert.equal(api.levels.length, 10);
    assert.deepEqual(api.progress.completedLevels, [1]);
    assert.equal(api.progress.highestUnlocked, 2);
  });

  it("evaluateCampaignLevelWon: guanyar partida o superar fitxes inicials", () => {
    const room = emptyRoomBase("solo-t", "Campanya", 100, 1000);
    room.soloAi = true;
    room.phaseB = { handsTotal: 5, handsCompleted: 5, chipPool: 6000, startingChips: 1_500 };
    room.matchResult = {
      winnerName: "Bot rival",
      ranking: [{ name: "Anna", chips: 1_400, isHuman: true }],
      viewerOutcome: "lose",
    };
    assert.equal(evaluateCampaignLevelWon(room, "Anna"), false);

    room.matchResult = {
      winnerName: "Anna",
      ranking: [{ name: "Anna", chips: 1_600, isHuman: true }],
      viewerOutcome: "win",
    };
    assert.equal(evaluateCampaignLevelWon(room, "Anna"), true);

    room.matchResult = {
      winnerName: "Bot",
      ranking: [
        { name: "Bot", chips: 3_000 },
        { name: "Anna", chips: 1_550, isHuman: true },
      ],
      viewerOutcome: "lose",
    };
    assert.equal(evaluateCampaignLevelWon(room, "Anna"), true);
  });

  it("applyCampaignLevelToSoloRoom configura bots i mans", () => {
    const room = emptyRoomBase("solo-c", "Campanya", 100, 1000);
    room.soloAi = true;
    const def = getCampaignLevel(3)!;
    applyCampaignLevelToSoloRoom(room, def);
    assert.equal(room.campaignLevel, 3);
    assert.equal(room.campaignStartingChips, def.startingChips);
    assert.equal(room.botDifficulty, def.botDifficulty);
    assert.equal(room.hostMatchSettings?.handsTotal, def.handsTotal);
    assert.equal(room.soloBotCount, def.botCount);
  });

  it("recordCampaignMatchIfNeeded registra en acabar partida de campanya", async () => {
    const matchPlayer = "fase3matchrec1";
    resetCampaignProgressCacheForTests();
    const room = emptyRoomBase("solo-r", "Campanya", 100, 1000);
    room.soloAi = true;
    room.campaignLevel = 1;
    room.campaignStartingChips = 1_500;
    room.phaseB = { handsTotal: 5, handsCompleted: 5, chipPool: 6000, startingChips: 1_500 };
    room.players = [
      {
        id: "h1",
        playerId: matchPlayer,
        seatToken: "s1",
        name: "Humà",
        chips: 1_800,
        bet: 0,
        isBanker: false,
        status: "waiting",
        handSlots: [],
        activeSlotIndex: 0,
        lastRoyal7Payout: 0,
        royal7AsBankerStreak: 0,
      },
    ];
    room.matchResult = {
      winnerName: "Humà",
      ranking: [{ name: "Humà", chips: 1_800, isHuman: true }],
      viewerOutcome: "win",
    };
    await recordCampaignMatchIfNeeded(room);
    const file = await readCampaignFileForTests(matchPlayer);
    assert.equal(file.completions.length, 1);
    assert.equal(file.completions[0]?.won, true);
    assert.equal(file.completions[0]?.level, 1);
  });

  it("join_solo_room rebutja nivell bloquejat i accepta nivell 1", async () => {
    resetGameStateForTests();
    resetCampaignProgressCacheForTests();
    await setBalance(CAMPAIGN_PLAYER, 5000);

    const app = express();
    app.use(express.json());
    app.get("/api/campaign", async (req, res) => {
      const resolved = resolvePlayerFromRequest(req);
      if (!resolved) return res.status(400).json({ error: "bad" });
      const payload = await getPublicCampaignPayload(resolved.playerId);
      res.json(payload);
    });

    const httpServer = createServer(app);
    const io = new Server(httpServer);
    setupGameHandlers(io);
    await new Promise<void>((resolve) => httpServer.listen(0, resolve));
    const port = (httpServer.address() as { port: number }).port;
    const socket = ioClient(`http://127.0.0.1:${port}`, { transports: ["websocket"] });
    await new Promise<void>((resolve) => socket.on("connect", () => resolve()));

    const locked = await new Promise<{ code?: string }>((resolve) => {
      socket.once("game_error", (err: { code?: string }) => resolve(err));
      socket.emit("join_solo_room", {
        playerName: "Prova",
        playerId: CAMPAIGN_PLAYER,
        botCount: 1,
        botDifficulty: "easy",
        campaignLevel: 5,
      });
    });
    assert.equal(locked.code, "CAMPAIGN_LOCKED");

    const joined = await new Promise<{ campaignLevel?: number }>((resolve, reject) => {
      const t = setTimeout(() => reject(new Error("timeout")), 8000);
      socket.once("joined_room", (view: { hostMatchSettings?: { handsTotal: number } }) => {
        clearTimeout(t);
        resolve({ campaignLevel: getCampaignLevel(1)?.handsTotal === view.hostMatchSettings?.handsTotal ? 1 : undefined });
      });
      socket.emit("join_solo_room", {
        playerName: "Prova",
        playerId: CAMPAIGN_PLAYER,
        botCount: 3,
        botDifficulty: "hard",
        campaignLevel: 1,
      });
    });
    assert.equal(joined.campaignLevel, 1);

    socket.disconnect();
    io.close();
    await new Promise<void>((resolve) => httpServer.close(() => resolve()));
  });

  it("GET /api/campaign retorna nivells i progrés", async () => {
    const apiPlayer = "fase3api0001";
    resetCampaignProgressCacheForTests();

    const app = express();
    app.get("/api/campaign", async (req, res) => {
      const resolved = resolvePlayerFromRequest(req);
      if (!resolved) return res.status(400).json({ error: "bad" });
      res.json(await getPublicCampaignPayload(resolved.playerId));
    });
    const httpServer = createServer(app);
    await new Promise<void>((resolve) => httpServer.listen(0, resolve));
    const port = (httpServer.address() as { port: number }).port;

    const res = await fetch(`http://127.0.0.1:${port}/api/campaign?playerId=${apiPlayer}`);
    assert.equal(res.status, 200);
    const body = (await res.json()) as { levels: unknown[]; progress: { highestUnlocked: number } };
    assert.equal(body.levels.length, 10);
    assert.equal(body.progress.highestUnlocked, 1);

    await new Promise<void>((resolve) => httpServer.close(() => resolve()));
  });
});
