import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { createServer, type Server as HttpServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket as ClientSocket } from "socket.io-client";
import { setupGameHandlers, resetGameStateForTests, getRoomSnapshotForTests } from "./game.ts";
import { flushAllPendingWrites } from "./writeCoalescing.ts";
import { getBalance, resetBalanceStoreCacheForTests, setBalance } from "./balances.ts";
import {
  flushSoloIsolatedSessionWritesForTests,
  loadSoloIsolatedSessionsOnBoot,
  markSoloIsolatedSessionActive,
  restorableSoloIsolatedSession,
  soloIsolatedRestoreWindowMs,
} from "./soloIsolatedSessions.ts";
import { removeTestDataDir } from "./testing/testDataDir.ts";
import type { RoomView } from "../src/gameTypes.ts";

/**
 * Provador (prod 3c308bd):
 * P1 · pràctica → reinici del servidor → el client reconnecta: la partida tornava amb termini
 *      d'aposta, Mort i torns amb temps, i «SALDO 2.000» (partida normal amb saldo real).
 * P2 · «Començar» amb un seient solo orfe → SOLO_RESUME_REQUIRED i cap room_update.
 */

type TestServer = { url: string; http: HttpServer; io: SocketIOServer };

async function startTestServer(): Promise<TestServer> {
  const http = createServer();
  const io = new SocketIOServer(http, { cors: { origin: "*" } });
  await setupGameHandlers(io);
  await new Promise<void>((resolve) => http.listen(0, "127.0.0.1", () => resolve()));
  const addr = http.address();
  const port = typeof addr === "object" && addr ? addr.port : 0;
  return { url: `http://127.0.0.1:${port}`, http, io };
}

/** Atura el servidor com un reinici: totes les sales en memòria es perden. */
async function stopTestServer(server: TestServer): Promise<void> {
  server.io.close();
  await new Promise<void>((resolve) => server.http.close(() => resolve()));
  await flushSoloIsolatedSessionWritesForTests();
  await flushAllPendingWrites();
  resetGameStateForTests();
}

function connect(url: string): Promise<ClientSocket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true, reconnection: false });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.on("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.on("connect_error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

function joinSolo(socket: ClientSocket, payload: Record<string, unknown>): Promise<RoomView> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("joined_room timeout")), 10_000);
    const onError = (err: { code?: string }) => {
      clearTimeout(timer);
      socket.off("joined_room", onJoined);
      reject(new Error(`game_error ${err.code}`));
    };
    const onJoined = (room: RoomView) => {
      clearTimeout(timer);
      socket.off("game_error", onError);
      resolve(room);
    };
    socket.once("joined_room", onJoined);
    socket.once("game_error", onError);
    socket.emit("join_solo_room", payload);
  });
}

function waitForPhase(socket: ClientSocket, phases: string[]): Promise<RoomView> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`phase ${phases.join("|")} timeout`)), 10_000);
    const onUpdate = (room: RoomView) => {
      if (!phases.includes(room.phase)) return;
      clearTimeout(timer);
      socket.off("room_update", onUpdate);
      resolve(room);
    };
    socket.on("room_update", onUpdate);
  });
}

function disconnectAndSettle(socket: ClientSocket): Promise<void> {
  socket.disconnect();
  return new Promise((r) => setTimeout(r, 150));
}

/** El que envia el client en reconnectar (`attemptSoloRejoinOnConnect`): sense mode. */
function plainRejoinPayload(playerId: string, soloResumeToken?: string): Record<string, unknown> {
  return {
    playerName: "Provador",
    playerId,
    soloResumeToken,
    botCount: 3,
    botDifficulty: "normal",
    houseRulesEnabled: false,
    practiceMode: false,
  };
}

describe("pràctica després d'un reinici i SOLO_RESUME_REQUIRED (Provador, prod 3c308bd)", () => {
  let dataDir = "";

  before(async () => {
    dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "setimig-practica-reinici-"));
    process.env.BALANCE_DATA_DIR = dataDir;
    process.env.SETIMIG_TEST_FAST = "1";
    delete process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD;
    resetBalanceStoreCacheForTests();
  });

  after(async () => {
    await removeTestDataDir(dataDir);
    delete process.env.BALANCE_DATA_DIR;
  });

  it("P1: una pràctica interrompuda per un reinici es refà en mode pràctica i no toca el saldo real", async () => {
    const playerId = "practicareinici0001";
    await setBalance(playerId, 25_000);
    await flushAllPendingWrites();

    let server = await startTestServer();
    let socket = await connect(server.url);
    const first = await joinSolo(socket, { ...plainRejoinPayload(playerId), practiceMode: true, botCount: 2 });
    assert.equal(first.practiceMode, true);
    assert.ok(first.soloResumeToken);
    await waitForPhase(socket, ["betting"]);

    // Reinici amb la pràctica en curs: el client perd la connexió i la sala desapareix.
    await disconnectAndSettle(socket);
    await stopTestServer(server);

    server = await startTestServer();
    socket = await connect(server.url);
    const resumed = await joinSolo(socket, plainRejoinPayload(playerId, first.soloResumeToken));
    assert.equal(resumed.practiceMode, true, "després del reinici ha de continuar sent pràctica");
    const room = getRoomSnapshotForTests(resumed.id);
    assert.ok(room);
    assert.equal(room.practiceMode, true);
    assert.equal(room.soloRealBalances?.has(playerId) ?? false, false, "no es llegeix el saldo real");
    assert.equal(room.players.filter((p) => p.isBot).length, 2, "conserva el nombre de bots");

    const betting = await waitForPhase(socket, ["betting"]);
    assert.equal(betting.practiceMode, true);
    assert.ok(!betting.bettingDeadlineAt, "la pràctica no té termini d'aposta");
    assert.ok(!betting.turnDeadlineAt, "la pràctica no té temporitzador de torn");

    // Sortir de la pràctica no escriu res al saldo real.
    socket.emit("leave_room", resumed.id);
    await new Promise((r) => setTimeout(r, 150));
    await flushAllPendingWrites();
    resetBalanceStoreCacheForTests();
    assert.equal(await getBalance(playerId), 25_000);

    // Després d'una sortida confirmada, una partida nova sense mode torna a ser normal.
    const normal = await joinSolo(socket, plainRejoinPayload(playerId));
    assert.equal(normal.practiceMode ?? false, false);

    socket.disconnect();
    await stopTestServer(server);
  });

  it("P1: desconnexió en plena pràctica sense reinici → reprendre continua en pràctica", async () => {
    const playerId = "practicareinici0002";
    const server = await startTestServer();
    let socket = await connect(server.url);
    const first = await joinSolo(socket, { ...plainRejoinPayload(playerId), practiceMode: true });
    await waitForPhase(socket, ["betting"]);
    await disconnectAndSettle(socket);

    socket = await connect(server.url);
    const resumed = await joinSolo(socket, plainRejoinPayload(playerId, first.soloResumeToken));
    assert.equal(resumed.practiceMode, true);
    socket.disconnect();
    await stopTestServer(server);
  });

  it("P1: `intent: \"new\"` (partida nova explícita) no refà la pràctica perduda", async () => {
    const playerId = "practicareinici0003";
    let server = await startTestServer();
    let socket = await connect(server.url);
    await joinSolo(socket, { ...plainRejoinPayload(playerId), practiceMode: true });
    await disconnectAndSettle(socket);
    await stopTestServer(server);

    server = await startTestServer();
    socket = await connect(server.url);
    const fresh = await joinSolo(socket, { ...plainRejoinPayload(playerId), intent: "new" });
    assert.equal(fresh.practiceMode ?? false, false);
    socket.disconnect();
    await stopTestServer(server);
  });

  it("P1: fora de la finestra de restauració, la marca de pràctica perduda caduca", async () => {
    const now = Date.now();
    markSoloIsolatedSessionActive("practicareinici0004", { mode: "practice", botCount: 3 }, now);
    await flushSoloIsolatedSessionWritesForTests();
    await loadSoloIsolatedSessionsOnBoot(now);
    assert.equal(restorableSoloIsolatedSession("practicareinici0004", now)?.mode, "practice");
    assert.equal(
      restorableSoloIsolatedSession("practicareinici0004", now + soloIsolatedRestoreWindowMs() + 1),
      null
    );
  });

  it("P2: «Començar» sense el token d'un seient orfe en plena partida → partida nova, no SOLO_RESUME_REQUIRED", async () => {
    const playerId = "practicareinici0005";
    const server = await startTestServer();
    let socket = await connect(server.url);
    const first = await joinSolo(socket, plainRejoinPayload(playerId));
    await waitForPhase(socket, ["betting"]);
    await disconnectAndSettle(socket);
    const orphan = getRoomSnapshotForTests(first.id)?.players.find((p) => p.playerId === playerId);
    assert.ok(orphan?.isBot, "el seient queda en mans d'una IA");

    socket = await connect(server.url);
    const fresh = await joinSolo(socket, plainRejoinPayload(playerId)); // sense soloResumeToken
    assert.ok(fresh.soloResumeToken);
    assert.notEqual(fresh.soloResumeToken, first.soloResumeToken);
    const room = getRoomSnapshotForTests(fresh.id)!;
    const humans = room.players.filter((p) => p.playerId === playerId);
    assert.equal(humans.length, 1);
    assert.ok(!humans[0]!.isBot);
    assert.equal(room.phaseB?.handsCompleted ?? 0, 0, "partida nova a la mà 1");
    await waitForPhase(socket, ["betting"]);
    socket.disconnect();
    await stopTestServer(server);
  });

  it("P2: doble «Començar» des del mateix socket → mai SOLO_RESUME_REQUIRED", async () => {
    const playerId = "practicareinici0006";
    const server = await startTestServer();
    const socket = await connect(server.url);
    const errors: string[] = [];
    const joins: RoomView[] = [];
    socket.on("game_error", (e: { code?: string }) => errors.push(e.code ?? "?"));
    socket.on("joined_room", (r: RoomView) => joins.push(r));
    socket.emit("join_solo_room", { ...plainRejoinPayload(playerId), practiceMode: true });
    socket.emit("join_solo_room", { ...plainRejoinPayload(playerId), practiceMode: true });
    await waitForPhase(socket, ["betting"]);
    await new Promise((r) => setTimeout(r, 200));
    assert.deepEqual(errors, []);
    assert.ok(joins.length >= 1);
    const room = getRoomSnapshotForTests(joins[0]!.id)!;
    assert.equal(room.players.filter((p) => p.playerId === playerId && !p.isBot).length, 1);
    socket.disconnect();
    await stopTestServer(server);
  });
});
