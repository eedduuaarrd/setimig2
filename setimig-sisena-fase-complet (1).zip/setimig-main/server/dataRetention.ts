import fs from "fs/promises";
import path from "path";

/**
 * Límits de retenció de data/: només s'esborren entrades velles; les dades vigents
 * (saldo, assoliments, progrés desbloquejat, rànquing de la setmana actual) es conserven sempre.
 */
function envInt(name: string, fallback: number, min = 1): number {
  const raw = process.env[name];
  if (raw === undefined || raw === "") return fallback;
  const n = Math.floor(Number(raw));
  return Number.isFinite(n) && n >= min ? n : fallback;
}

export function retentionLimits() {
  return {
    /** Còpies balances.json.bak-<data> que es conserven (les més recents). */
    balanceBackups: envInt("SETIMIG_KEEP_BALANCE_BACKUPS", 10),
    /** Setmanes de rànquing setmanal guardades a disc. */
    weeklyLeaderboardWeeks: envInt("SETIMIG_KEEP_LEADERBOARD_WEEKS", 12),
    /** Dies de progrés/reclamació de missions diàries guardats per jugador. */
    missionDays: envInt("SETIMIG_KEEP_MISSION_DAYS", 14),
    /** Intents de campanya guardats per jugador (més la primera victòria de cada nivell). */
    campaignAttempts: envInt("SETIMIG_KEEP_CAMPAIGN_ATTEMPTS", 200),
    /** Sessions de pagament ja processades (idempotència Stripe). */
    processedSessions: envInt("SETIMIG_KEEP_PROCESSED_SESSIONS", 20_000),
    /** Taules privades sense cap escriptura durant aquest temps es descarten en carregar. */
    privateRoomTtlMs: envInt("SETIMIG_PRIVATE_ROOM_TTL_DAYS", 30) * 86_400_000,
    /** Sales amb historial de xat en memòria. */
    chatRooms: envInt("SETIMIG_MAX_CHAT_ROOMS", 2_000),
    /** Dies de fitxers d'esdeveniments d'analítica (`data/analytics/events-<dia>.jsonl`); ~13 mesos. */
    analyticsDays: envInt("SETIMIG_KEEP_ANALYTICS_DAYS", 395),
  };
}

/** Esborra les còpies `<fitxer>.bak-<timestamp ISO>` més antigues i en deixa `keep`. */
export async function rotateTimestampedBackups(filePath: string, keep: number): Promise<string[]> {
  const dir = path.dirname(filePath);
  const prefix = `${path.basename(filePath)}.bak-`;
  let names: string[];
  try {
    names = await fs.readdir(dir);
  } catch {
    return [];
  }
  const backups = names.filter((n) => n.startsWith(prefix) && !n.endsWith(".tmp")).sort();
  const remove = backups.slice(0, Math.max(0, backups.length - Math.max(1, keep)));
  for (const name of remove) {
    await fs.rm(path.join(dir, name), { force: true });
  }
  return remove;
}

const WEEK_FILE_RE = /^\d{4}-W\d{2}\.json$/;

/** Deixa només les `keepWeeks` setmanes més recents (mai esborra `protectWeekKey`). */
export async function pruneWeeklyLeaderboardDir(
  dir: string,
  keepWeeks: number,
  protectWeekKey?: string
): Promise<string[]> {
  let names: string[];
  try {
    names = await fs.readdir(dir);
  } catch {
    return [];
  }
  const weeks = names.filter((n) => WEEK_FILE_RE.test(n)).sort();
  const keep = new Set(weeks.slice(-Math.max(1, keepWeeks)));
  if (protectWeekKey) keep.add(`${protectWeekKey}.json`);
  const remove = weeks.filter((n) => !keep.has(n));
  for (const name of remove) {
    await fs.rm(path.join(dir, name), { force: true });
  }
  return remove;
}

const DAY_PREFIX_RE = /^(\d{4}-\d{2}-\d{2})-/;

function shiftDayKey(dayKey: string, days: number): string {
  const ms = Date.parse(`${dayKey}T12:00:00Z`) + days * 86_400_000;
  return new Date(ms).toISOString().slice(0, 10);
}

type MissionCarrier = {
  missionProgress: Record<string, unknown>;
  rewardLedger: string[];
};

/**
 * Esborra el progrés i les entrades del registre de recompenses de missions diàries
 * de més de `keepDays` dies abans de la missió més recent del fitxer.
 * Les claus d'assoliments (`achievement:*`) no es toquen mai.
 */
export function pruneEngagementMissions(file: MissionCarrier, keepDays: number): boolean {
  let newest: string | null = null;
  for (const id of Object.keys(file.missionProgress)) {
    const m = DAY_PREFIX_RE.exec(id);
    if (m && (newest === null || m[1]! > newest)) newest = m[1]!;
  }
  if (newest === null) return false;
  const cutoff = shiftDayKey(newest, -Math.max(1, keepDays));
  let changed = false;
  for (const id of Object.keys(file.missionProgress)) {
    const m = DAY_PREFIX_RE.exec(id);
    if (m && m[1]! < cutoff) {
      delete file.missionProgress[id];
      changed = true;
    }
  }
  const ledger = file.rewardLedger.filter((key) => {
    if (!key.startsWith("mission:")) return true;
    const m = DAY_PREFIX_RE.exec(key.slice("mission:".length));
    return !m || m[1]! >= cutoff;
  });
  if (ledger.length !== file.rewardLedger.length) {
    file.rewardLedger = ledger;
    changed = true;
  }
  return changed;
}

/**
 * Limita els intents de campanya als `max` més recents, però conserva sempre
 * la primera victòria de cada nivell (perquè `completedLevels` no canviï).
 */
export function capCampaignAttempts<T extends { at: number; level: number; won: boolean }>(
  completions: T[],
  max: number
): T[] {
  if (completions.length <= max) return completions;
  const firstWin = new Map<number, T>();
  for (const row of completions) {
    if (row.won && !firstWin.has(row.level)) firstWin.set(row.level, row);
  }
  const tail = completions.slice(-Math.max(1, max));
  const inTail = new Set(tail);
  const extra = [...firstWin.values()].filter((row) => !inTail.has(row));
  return [...extra, ...tail].sort((a, b) => a.at - b.at);
}

/** Conserva les `max` sessions processades més recents. */
export function capProcessedSessions(list: string[], max: number): string[] {
  return list.length > max ? list.slice(list.length - max) : list;
}

export function isStaleSnapshot(persistedAt: unknown, now: number, ttlMs: number): boolean {
  return typeof persistedAt === "number" && Number.isFinite(persistedAt) && now - persistedAt > ttlMs;
}

const DAILY_JSONL_RE = /^events-(\d{4}-\d{2}-\d{2})\.jsonl$/;

/**
 * Esborra els fitxers diaris `events-<YYYY-MM-DD>.jsonl` de més de `keepDays` dies
 * respecte de `todayKey` (UTC). El fitxer d'avui no s'esborra mai.
 */
export async function pruneDailyEventFiles(dir: string, keepDays: number, todayKey: string): Promise<string[]> {
  let names: string[];
  try {
    names = await fs.readdir(dir);
  } catch {
    return [];
  }
  const cutoff = shiftDayKey(todayKey, -Math.max(1, keepDays));
  const remove = names.filter((n) => {
    const m = DAILY_JSONL_RE.exec(n);
    return !!m && m[1]! < cutoff;
  });
  for (const name of remove) {
    await fs.rm(path.join(dir, name), { force: true });
  }
  return remove;
}
