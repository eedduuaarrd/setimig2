import { describe, it, before, after, beforeEach } from "node:test";
import assert from "node:assert/strict";
import fs from "fs/promises";
import path from "path";
import { createServer, type Server as HttpServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket as ClientSocket } from "socket.io-client";
import {
  closeSoloBuyIn,
  flushBalanceWrites,
  getBalance,
  listOpenSoloBuyIns,
  refundOrphanSoloBuyIns,
  resetBalanceStoreCacheForTests,
  runBalanceTransaction,
  setBalance,
} from "./balances.ts";
import { onHandRecordedForEngagement } from "./achievementsEngine.ts";
import { flushEngagementWritesForTests, resetEngagementCacheForTests } from "./achievementsStore.ts";
import {
  getGameHostForTests,
  getRoomSnapshotForTests,
  requestedSoloMode,
  resetGameStateForTests,
  setupGameHandlers,
  soloModeOfRoom,
} from "./game.ts";
import { openSoloBuyInForRoom, recordSoloHandOnLedger, settleSoloBuyIn } from "./soloBuyIn.ts";
import { clearRoomTimers, emptyRoomBase, type Player, type Room } from "../shared/gameEngine.ts";
import { PHASE_B_START_CHIPS } from "../shared/matchPhaseB.ts";

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";

/**
 * Pagaments al saldo real durant una solo amb compra oberta (p. ex. «Primera victòria», +500):
 * el tancament de la compra abona només fitxes de taula verificades com a increment sobre el saldo
 * actual, i cada pagament compta exactament una vegada (sortida, doble tancament, reinici).
 * També: `join_solo_room` respecta el mode demanat explícitament (pràctica o `intent: "new"`).
 */

const DATA_ROOT = path.join(process.cwd(), "data", `solo-buyin-recompenses-test-${Date.now()}`);
const START = 24_500;
const FIRST_WIN_REWARD = 500;

type TestServer = { url: string; http: HttpServer; io: SocketIOServer };

async function startTestServer(): Promise<TestServer> {
  const http = createServer();
  const io = new SocketIOServer(http, { cors: { origin: "*" } });
  await setupGameHandlers(io);
  await new Promise<void>((resolve) => http.listen(0, "127.0.0.1", () => resolve()));
  const addr = http.address();
  const port = typeof addr === "object" && addr ? addr.port : 0;
  return { url: `http://127.0.0.1:${port}`, http, io };
}

async function stopTestServer(server: TestServer): Promise<void> {
  resetGameStateForTests();
  server.io.close();
  await new Promise<void>((resolve) => server.http.close(() => resolve()));
}

function connect(url: string): Promise<ClientSocket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.on("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.on("connect_error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

type JoinOutcome = { room?: { id: string }; error?: { code?: string } };

function joinSolo(socket: ClientSocket, playerId: string, extra: Record<string, unknown> = {}): Promise<JoinOutcome> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("join timeout")), 10_000);
    const done = (out: JoinOutcome) => {
      clearTimeout(timer);
      socket.off("joined_room");
      socket.off("game_error");
      resolve(out);
    };
    socket.once("joined_room", (room: { id: string }) => done({ room }));
    socket.once("game_error", (error: JoinOutcome["error"]) => done({ error }));
    socket.emit("join_solo_room", { playerName: "Recompensa", playerId, botCount: 3, ...extra });
  });
}

function leave(socket: ClientSocket, roomId: string): Promise<void> {
  return new Promise<void>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("leave timeout")), 5_000);
    socket.once("room_left", () => {
      clearTimeout(timer);
      resolve();
    });
    socket.emit("leave_room", roomId);
  });
}

async function waitFor(cond: () => boolean | Promise<boolean>, label: string, ms = 5_000): Promise<void> {
  const deadline = Date.now() + ms;
  while (!(await cond())) {
    if (Date.now() > deadline) throw new Error(`${label} timeout`);
    await new Promise((r) => setTimeout(r, 10));
  }
}

function seat(id: string, extra: Partial<Player> = {}): Player {
  return {
    id,
    playerId: id,
    seatToken: `${id}-t`,
    name: id,
    chips: PHASE_B_START_CHIPS,
    bet: 0,
    isBanker: false,
    status: "waiting",
    handSlots: [],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
    ...extra,
  };
}

function ledgerRoom(playerId: string): Room {
  const room = emptyRoomBase(`solo-${playerId}`, "Partida IA", 100, 1000);
  room.soloAi = true;
  room.autoFillBots = false;
  room.soloHumanPlayerId = playerId;
  room.players = [seat(playerId), seat("bot-a", { isBot: true, isBanker: true })];
  return room;
}

/** Mà liquidada al servidor: canvi de fitxes de taula i registre al llibre (com onHandSettled). */
function settleHand(room: Room, playerId: string, delta: number): void {
  const human = room.players.find((p) => p.playerId === playerId)!;
  const banker = room.players.find((p) => p.isBanker)!;
  human.chips += delta;
  banker.chips -= delta;
  room.phase = "settlement";
  room.lastRound = {
    title: "Liquidació",
    highlights: [],
    results: [
      { name: human.name, outcome: delta >= 0 ? "win" : "lose", chipDelta: delta, detail: "" },
      { name: banker.name, outcome: delta >= 0 ? "lose" : "win", chipDelta: -delta, detail: "" },
    ],
    at: Date.now(),
  };
  recordSoloHandOnLedger(room);
  room.phase = "waiting";
}

/** Camí real de l'assoliment: una mà guanyada (fora de pràctica) desbloqueja «Primera victòria». */
async function recordWinForAchievements(playerId: string, chipDelta: number): Promise<void> {
  await onHandRecordedForEngagement({
    playerId,
    result: "win",
    chipDelta,
    passed: false,
    naturalSevenHalf: false,
    practice: false,
  });
}

async function withCapturedErrors<T>(fn: () => Promise<T>): Promise<{ result: T; errors: string[] }> {
  const errors: string[] = [];
  const original = console.error;
  console.error = (...args: unknown[]) => {
    errors.push(args.map(String).join(" "));
  };
  try {
    return { result: await fn(), errors };
  } finally {
    console.error = original;
  }
}

describe("compra solo + pagaments al saldo durant la partida", () => {
  before(() => {
    process.env.BALANCE_DATA_DIR = DATA_ROOT;
    process.env.SETIMIG_TEST_FAST = "1";
    resetBalanceStoreCacheForTests();
    resetEngagementCacheForTests();
  });

  beforeEach(() => {
    resetGameStateForTests();
  });

  after(async () => {
    resetGameStateForTests();
    await flushEngagementWritesForTests().catch(() => undefined);
    await flushBalanceWrites().catch(() => undefined);
    resetBalanceStoreCacheForTests();
    resetEngagementCacheForTests();
    await fs.rm(DATA_ROOT, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 }).catch(() => undefined);
    delete process.env.BALANCE_DATA_DIR;
    delete process.env.SETIMIG_TEST_FAST;
  });

  it("(1) seure 24.500→22.500, mà guanyada + «Primera victòria» +500, sortir amb X verificades: 24.500 − 2.000 + X + 500", async () => {
    const playerId = "recompfirstwin1";
    await setBalance(playerId, START);
    const room = ledgerRoom(playerId);
    const opened = await openSoloBuyInForRoom(room, playerId, PHASE_B_START_CHIPS);
    assert.ok(opened.ok);
    assert.equal(await getBalance(playerId), START - PHASE_B_START_CHIPS);

    settleHand(room, playerId, 700);
    await recordWinForAchievements(playerId, 700);
    assert.equal(await getBalance(playerId), START - PHASE_B_START_CHIPS + FIRST_WIN_REWARD, "l'assoliment paga al saldo real");
    assert.equal(room.players[0]!.chips, PHASE_B_START_CHIPS + 700, "les fitxes de taula no canvien amb l'assoliment");
    settleHand(room, playerId, -200);
    await recordWinForAchievements(playerId, 100); // segona victòria: l'assoliment no torna a pagar

    const X = room.players[0]!.chips;
    assert.equal(X, 2_500);
    const { result, errors } = await withCapturedErrors(() => settleSoloBuyIn(room, undefined, "sortida"));
    assert.equal(result?.verified, true, "la verificació només mira fitxes de taula");
    assert.equal(result?.credit, X);
    assert.equal(errors.length, 0);
    assert.equal(await getBalance(playerId), START - PHASE_B_START_CHIPS + X + FIRST_WIN_REWARD);
    assert.equal(await getBalance(playerId), 25_500);
  });

  it("(2) servidor: sortir sense jugar amb un pagament durant la partida → 24.500 + pagament", async () => {
    const playerId = "recompnoplay001";
    await setBalance(playerId, START);
    const server = await startTestServer();
    const socket = await connect(server.url);
    try {
      const out = await joinSolo(socket, playerId);
      assert.ok(out.room, `s'ha pogut seure (${out.error?.code})`);
      const roomId = out.room!.id;
      assert.equal(await getBalance(playerId), START - PHASE_B_START_CHIPS);
      const room = getRoomSnapshotForTests(roomId)!;
      clearRoomTimers(getGameHostForTests(), room);
      const human = room.players.find((p) => p.playerId === playerId)!;
      assert.equal(human.bet, 0);
      // Pagament al saldo mentre la mesa és oberta (assoliment real).
      await recordWinForAchievements(playerId, 0);
      assert.equal(await getBalance(playerId), START - PHASE_B_START_CHIPS + FIRST_WIN_REWARD);
      await leave(socket, roomId);
      assert.equal(await getBalance(playerId), START + FIRST_WIN_REWARD);
      assert.ok(!Object.values(await listOpenSoloBuyIns()).some((e) => e.playerId === playerId));
      // Desconnectar després de sortir no torna a abonar res.
      socket.disconnect();
      await new Promise((r) => setTimeout(r, 150));
      assert.equal(await getBalance(playerId), START + FIRST_WIN_REWARD);
    } finally {
      socket.disconnect();
      await stopTestServer(server);
    }
  });

  it("(3) idempotent amb pagament entremig: dos tancaments + tancament directe no compten dues vegades", async () => {
    const playerId = "recompidempot01";
    await setBalance(playerId, START);
    const room = ledgerRoom(playerId);
    const opened = await openSoloBuyInForRoom(room, playerId, PHASE_B_START_CHIPS);
    assert.ok(opened.ok);
    settleHand(room, playerId, 300);
    await recordWinForAchievements(playerId, 300);
    await Promise.all([settleSoloBuyIn(room, undefined, "sortida"), settleSoloBuyIn(room, undefined, "destrucció")]);
    const expected = START - PHASE_B_START_CHIPS + 2_300 + FIRST_WIN_REWARD;
    assert.equal(await getBalance(playerId), expected);
    const again = await closeSoloBuyIn(opened.id, 99_999);
    assert.equal(again.closed, false);
    assert.equal(await refundOrphanSoloBuyIns(() => false), 0);
    await recordWinForAchievements(playerId, 10); // l'assoliment ja està pagat
    assert.equal(await getBalance(playerId), expected);
  });

  it("(4) refundOrphanSoloBuyIns en arrencar amb un pagament entremig no el perd", async () => {
    const playerId = "recomporphan001";
    await setBalance(playerId, START);
    const room = ledgerRoom(playerId);
    const opened = await openSoloBuyInForRoom(room, playerId, PHASE_B_START_CHIPS);
    assert.ok(opened.ok);
    settleHand(room, playerId, 400);
    await recordWinForAchievements(playerId, 400);
    // Reinici: la sala es perd (només viu en memòria) i el saldo es rellegeix del disc.
    await flushBalanceWrites();
    resetBalanceStoreCacheForTests();
    const originalWarn = console.warn;
    console.warn = () => undefined;
    try {
      assert.equal(await refundOrphanSoloBuyIns(() => false), 1);
      assert.equal(await refundOrphanSoloBuyIns(() => false), 0);
    } finally {
      console.warn = originalWarn;
    }
    assert.equal(await getBalance(playerId), START + FIRST_WIN_REWARD, "es retorna la compra i es conserva el pagament");
  });

  it("torneig ràpid: en sortir no es restaura cap còpia del saldo (els pagaments fets mentrestant es conserven)", async () => {
    const playerId = "recompfasttour1";
    await setBalance(playerId, START);
    const server = await startTestServer();
    const socket = await connect(server.url);
    try {
      const out = await joinSolo(socket, playerId, { fastTournament: { enabled: true }, intent: "new" });
      assert.ok(out.room, `s'ha pogut seure (${out.error?.code})`);
      const room = getRoomSnapshotForTests(out.room!.id)!;
      assert.equal(room.fastTournament, true);
      assert.equal(room.soloBuyIn, undefined);
      assert.equal(await getBalance(playerId), START);
      // Pagament al saldo fora de la taula (p. ex. una missió reclamada en una altra pestanya).
      await runBalanceTransaction((store) => {
        store.accounts[playerId] = { chips: (store.accounts[playerId]?.chips ?? 0) + 300, lastClaimAt: null };
      });
      await leave(socket, room.id);
      assert.equal(await getBalance(playerId), START + 300);
    } finally {
      socket.disconnect();
      await stopTestServer(server);
    }
  });
});

describe("join_solo_room respecta el mode demanat explícitament", () => {
  before(() => {
    process.env.BALANCE_DATA_DIR = DATA_ROOT;
    process.env.SETIMIG_TEST_FAST = "1";
    resetBalanceStoreCacheForTests();
  });

  beforeEach(() => {
    resetGameStateForTests();
  });

  after(async () => {
    resetGameStateForTests();
    await flushBalanceWrites().catch(() => undefined);
    resetBalanceStoreCacheForTests();
    await fs.rm(DATA_ROOT, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 }).catch(() => undefined);
    delete process.env.BALANCE_DATA_DIR;
    delete process.env.SETIMIG_TEST_FAST;
  });

  it("mode demanat: pràctica, torneig, campanya, `intent: \"new\"`; reconnexió sense mode → null", () => {
    assert.equal(requestedSoloMode({ practiceMode: true, intent: "new" }, null), "practice");
    assert.equal(requestedSoloMode({ fastTournament: { enabled: true } }, null), "fastTournament");
    assert.equal(requestedSoloMode({}, 3), "campaign:3");
    assert.equal(requestedSoloMode({ practiceMode: false, intent: "new" }, null), "normal");
    assert.equal(requestedSoloMode({ practiceMode: false }, null), null);
    assert.equal(soloModeOfRoom({ practiceMode: true }), "practice");
    assert.equal(soloModeOfRoom({ fastTournament: true }), "fastTournament");
    assert.equal(soloModeOfRoom({ campaignLevel: 2 }), "campaign:2");
    assert.equal(soloModeOfRoom({}), "normal");
  });

  it("solo normal en curs + «Començar» en pràctica → partida de pràctica nova (no es repren) i es tanca la compra", async () => {
    const playerId = "recompmodeprac1";
    await setBalance(playerId, START);
    const server = await startTestServer();
    const socket = await connect(server.url);
    try {
      const out = await joinSolo(socket, playerId, { intent: "new" });
      assert.ok(out.room);
      const roomId = out.room!.id;
      await waitFor(() => getRoomSnapshotForTests(roomId)?.phase !== "waiting", "inici de la mà");
      const before = getRoomSnapshotForTests(roomId)!;
      clearRoomTimers(getGameHostForTests(), before);
      const human = before.players.find((p) => p.playerId === playerId)!;
      human.chips += human.bet;
      human.bet = 0;
      assert.ok(before.soloBuyIn);

      const practice = await joinSolo(socket, playerId, { practiceMode: true, intent: "new" });
      assert.ok(practice.room, `pràctica (${practice.error?.code})`);
      const after = getRoomSnapshotForTests(roomId)!;
      assert.equal(after.practiceMode, true, "s'ha creat una partida de pràctica");
      assert.equal(after.soloBuyIn, undefined);
      assert.ok(!Object.values(await listOpenSoloBuyIns()).some((e) => e.playerId === playerId));
      assert.equal(await getBalance(playerId), START, "la compra verificada torna al saldo");
    } finally {
      socket.disconnect();
      await stopTestServer(server);
    }
  });

  it("`intent: \"new\"` amb una partida en curs (mans jugades) → partida nova; doble toc i reconnexió → es repren", async () => {
    const playerId = "recompmodenew01";
    await setBalance(playerId, START);
    const server = await startTestServer();
    const socket = await connect(server.url);
    try {
      const out = await joinSolo(socket, playerId, { intent: "new" });
      assert.ok(out.room);
      const roomId = out.room!.id;
      const firstBuyIn = getRoomSnapshotForTests(roomId)!.soloBuyIn!.id;
      await waitFor(() => getRoomSnapshotForTests(roomId)?.phase !== "waiting", "inici de la mà");

      // Doble toc a «Començar» (mateix socket, cap mà acabada): es repren la mateixa partida.
      const dup = await joinSolo(socket, playerId, { intent: "new" });
      assert.ok(dup.room);
      assert.equal(getRoomSnapshotForTests(roomId)!.soloBuyIn?.id, firstBuyIn);
      assert.equal(await getBalance(playerId), START - PHASE_B_START_CHIPS);

      const room = getRoomSnapshotForTests(roomId)!;
      clearRoomTimers(getGameHostForTests(), room);
      const human = room.players.find((p) => p.playerId === playerId)!;
      human.chips += human.bet;
      human.bet = 0;
      room.phaseB!.handsCompleted = 3;

      // Reconnexió automàtica (sense mode ni intent): es repren la partida en curs.
      const rejoin = await joinSolo(socket, playerId, { practiceMode: false });
      assert.ok(rejoin.room);
      assert.equal(getRoomSnapshotForTests(roomId)!.soloBuyIn?.id, firstBuyIn);
      assert.equal(getRoomSnapshotForTests(roomId)!.phaseB?.handsCompleted, 3);
      clearRoomTimers(getGameHostForTests(), getRoomSnapshotForTests(roomId)!);

      // «Començar» explícit: partida nova (compra anterior tancada, compra nova, mans a 0).
      const fresh = await joinSolo(socket, playerId, { practiceMode: false, intent: "new" });
      assert.ok(fresh.room);
      const after = getRoomSnapshotForTests(roomId)!;
      assert.ok(after.soloBuyIn);
      assert.notEqual(after.soloBuyIn!.id, firstBuyIn);
      assert.equal(after.phaseB?.handsCompleted, 0);
      assert.equal(after.practiceMode, false);
      const open = Object.values(await listOpenSoloBuyIns()).filter((e) => e.playerId === playerId);
      assert.equal(open.length, 1);
      assert.equal(await getBalance(playerId), START - PHASE_B_START_CHIPS);
    } finally {
      socket.disconnect();
      await stopTestServer(server);
    }
  });
});
