import fs from "fs/promises";
import path from "path";
import { isAccountDeleted } from "./deletedAccounts.ts";
import {
  CAMPAIGN_LEVEL_COUNT,
  CAMPAIGN_LEVELS,
  getCampaignLevel,
  type CampaignLevelDef,
} from "../shared/campaignLevels.ts";
import { capCampaignAttempts, retentionLimits } from "./dataRetention.ts";

const STORE_VERSION = 1;

function dataDir(): string {
  return process.env.BALANCE_DATA_DIR || path.join(process.cwd(), "data");
}

function campaignDir(): string {
  return path.join(dataDir(), "campaign-progress");
}

function playerPath(playerId: string): string {
  return path.join(campaignDir(), `${playerId}.json`);
}

export type CampaignAttemptRecord = {
  at: number;
  level: number;
  roomId: string;
  won: boolean;
  endingChips: number;
  startingChips: number;
};

type CampaignProgressFile = {
  version: number;
  highestUnlocked: number;
  completions: CampaignAttemptRecord[];
};

const cache = new Map<string, CampaignProgressFile>();
let writeChain: Promise<void> = Promise.resolve();

function emptyProgress(): CampaignProgressFile {
  return { version: STORE_VERSION, highestUnlocked: 1, completions: [] };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function normalizeProgress(raw: unknown): CampaignProgressFile {
  if (!isRecord(raw) || raw.version !== STORE_VERSION) return emptyProgress();
  const highestUnlocked = Math.min(
    CAMPAIGN_LEVEL_COUNT,
    Math.max(1, Math.floor(Number(raw.highestUnlocked) || 1))
  );
  const completions: CampaignAttemptRecord[] = [];
  if (Array.isArray(raw.completions)) {
    for (const row of raw.completions) {
      if (!isRecord(row)) continue;
      const level = Math.floor(Number(row.level));
      if (!getCampaignLevel(level)) continue;
      const at = Number(row.at);
      const roomId = typeof row.roomId === "string" ? row.roomId : "";
      const won = row.won === true;
      const endingChips = Math.max(0, Math.floor(Number(row.endingChips) || 0));
      const startingChips = Math.max(0, Math.floor(Number(row.startingChips) || 0));
      if (!Number.isFinite(at) || !roomId) continue;
      completions.push({ at, level, roomId, won, endingChips, startingChips });
    }
  }
  completions.sort((a, b) => a.at - b.at);
  return { version: STORE_VERSION, highestUnlocked, completions };
}

async function loadFile(playerId: string): Promise<CampaignProgressFile> {
  const cached = cache.get(playerId);
  if (cached) return cached;

  await fs.mkdir(campaignDir(), { recursive: true });
  const storePath = playerPath(playerId);
  let raw: string;
  try {
    raw = await fs.readFile(storePath, "utf8");
  } catch (error) {
    if (error instanceof Error && "code" in error && error.code === "ENOENT") {
      const fresh = emptyProgress();
      cache.set(playerId, fresh);
      return fresh;
    }
    throw error;
  }

  const parsed: unknown = JSON.parse(raw);
  const file = normalizeProgress(parsed);
  cache.set(playerId, file);
  return file;
}

async function persistFile(playerId: string, file: CampaignProgressFile): Promise<void> {
  if (isAccountDeleted(playerId)) return;
  cache.set(playerId, file);
  await fs.mkdir(campaignDir(), { recursive: true });
  const storePath = playerPath(playerId);
  const tmp = `${storePath}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(file, null, 2), "utf8");
  await fs.rename(tmp, storePath);
}

function enqueueWrite(task: () => Promise<void>): Promise<void> {
  writeChain = writeChain.then(task, task);
  return writeChain;
}

/** Esborrat de compte: progrés de la campanya (fitxer propi). */
export async function deleteCampaignProgress(playerId: string): Promise<boolean> {
  let removed = false;
  await enqueueWrite(async () => {
    cache.delete(playerId);
    try {
      await fs.rm(playerPath(playerId));
      removed = true;
    } catch (err) {
      if ((err as NodeJS.ErrnoException)?.code !== "ENOENT") throw err;
    }
  });
  return removed;
}

export function isCampaignLevelUnlocked(progress: CampaignProgressFile, level: number): boolean {
  if (!getCampaignLevel(level)) return false;
  return level <= progress.highestUnlocked;
}

export type PublicCampaignProgress = {
  highestUnlocked: number;
  completedLevels: number[];
  recentAttempts: CampaignAttemptRecord[];
};

export async function getCampaignProgress(playerId: string): Promise<CampaignProgressFile> {
  return loadFile(playerId);
}

export async function getPublicCampaignPayload(playerId: string): Promise<{
  levels: CampaignLevelDef[];
  progress: PublicCampaignProgress;
}> {
  const file = await loadFile(playerId);
  const completedSet = new Set<number>();
  for (const row of file.completions) {
    if (row.won) completedSet.add(row.level);
  }
  const completedLevels = [...completedSet].sort((a, b) => a - b);
  const recentAttempts = file.completions.slice(-20);
  return {
    levels: [...CAMPAIGN_LEVELS],
    progress: {
      highestUnlocked: file.highestUnlocked,
      completedLevels,
      recentAttempts,
    },
  };
}

export type RecordCampaignAttemptInput = {
  playerId: string;
  level: number;
  roomId: string;
  won: boolean;
  endingChips: number;
  startingChips: number;
  at?: number;
};

/** Afegeix un intent; només es descarten intents molt antics (es conserva la 1a victòria de cada nivell). */
export async function recordCampaignAttempt(input: RecordCampaignAttemptInput): Promise<void> {
  const levelDef = getCampaignLevel(input.level);
  if (!levelDef) return;

  const entry: CampaignAttemptRecord = {
    at: input.at ?? Date.now(),
    level: input.level,
    roomId: input.roomId,
    won: input.won,
    endingChips: Math.max(0, Math.floor(input.endingChips)),
    startingChips: Math.max(0, Math.floor(input.startingChips)),
  };

  await enqueueWrite(async () => {
    const file = await loadFile(input.playerId);
    file.completions = capCampaignAttempts([...file.completions, entry], retentionLimits().campaignAttempts);
    if (input.won) {
      const next = Math.min(CAMPAIGN_LEVEL_COUNT, input.level + 1);
      file.highestUnlocked = Math.max(file.highestUnlocked, next);
      file.highestUnlocked = Math.max(file.highestUnlocked, input.level);
    } else {
      file.highestUnlocked = Math.max(file.highestUnlocked, 1);
    }
    await persistFile(input.playerId, file);
  });
}

export function resetCampaignProgressCacheForTests(): void {
  cache.clear();
  writeChain = Promise.resolve();
}

export async function readCampaignFileForTests(playerId: string): Promise<CampaignProgressFile> {
  return loadFile(playerId);
}
