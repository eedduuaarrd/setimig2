import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { sanitizePlayerId } from "./balances.ts";
import { isAccountDeleted } from "./deletedAccounts.ts";
import { isSessionId, isSessionRevoked, isTokenRevoked, lineageSession } from "./revokedTokens.ts";

const DEFAULT_TTL_MS = 1000 * 60 * 60 * 24 * 365;

function secret(): string {
  const raw = process.env.PLAYER_TOKEN_SECRET?.trim();
  if (raw) return raw;
  if (process.env.NODE_ENV === "production") {
    throw new Error("PLAYER_TOKEN_SECRET is required in production");
  }
  return "dev-player-token-secret-change-me";
}

function b64url(data: Buffer | string): string {
  const buf = typeof data === "string" ? Buffer.from(data, "utf8") : data;
  return buf.toString("base64url");
}

function unb64url(s: string): Buffer {
  return Buffer.from(s, "base64url");
}

/**
 * HMAC amb el mateix secret que els tokens de jugador però amb un propòsit separat
 * (`purpose`), perquè una signatura d'un tipus de token no serveixi mai per a un altre.
 */
export function signWithPlayerSecret(purpose: string, body: string): Buffer {
  return createHmac("sha256", secret()).update(`${purpose}\n${body}`).digest();
}

export type PlayerTokenPayload = {
  playerId: string;
  exp: number;
  /** Id de sessió. Els tokens antics no en porten; continuen sent vàlids fins que es revoca el hash o la cadena. */
  sid?: string;
};

function newSessionId(): string {
  return randomBytes(16).toString("base64url");
}

export function issuePlayerToken(playerIdRaw: unknown, ttlMs?: number, sid?: string): string | null {
  const playerId = sanitizePlayerId(playerIdRaw);
  if (!playerId || isAccountDeleted(playerId)) return null;
  const ttl = ttlMs ?? DEFAULT_TTL_MS;
  const payload: PlayerTokenPayload = {
    playerId,
    exp: Date.now() + ttl,
    sid: sid && isSessionId(sid) ? sid : newSessionId(),
  };
  const body = b64url(JSON.stringify(payload));
  const sig = createHmac("sha256", secret()).update(body).digest();
  return `${body}.${b64url(sig)}`;
}

export function verifyPlayerToken(tokenRaw: unknown): PlayerTokenPayload | null {
  if (typeof tokenRaw !== "string" || !tokenRaw.includes(".")) return null;
  const [body, sigPart] = tokenRaw.split(".", 2);
  if (!body || !sigPart) return null;
  const expected = createHmac("sha256", secret()).update(body).digest();
  const actual = unb64url(sigPart);
  if (expected.length !== actual.length || !timingSafeEqual(expected, actual)) return null;
  try {
    const payload = JSON.parse(unb64url(body).toString("utf8")) as PlayerTokenPayload;
    if (!payload?.playerId || typeof payload.exp !== "number") return null;
    if (payload.exp < Date.now()) return null;
    const playerId = sanitizePlayerId(payload.playerId);
    if (!playerId || playerId !== payload.playerId) return null;
    // Compte esborrat: tots els tokens emesos abans deixen de valer.
    if (isAccountDeleted(playerId)) return null;
    // Logout: aquest token, o la sessió a què pertany (també si s'ha renovat), ja no val.
    if (isTokenRevoked(tokenRaw)) return null;
    const sid = typeof payload.sid === "string" && isSessionId(payload.sid) ? payload.sid : undefined;
    if (sid && isSessionRevoked(sid)) return null;
    const linked = lineageSession(tokenRaw);
    if (linked && isSessionRevoked(linked)) return null;
    return { playerId, exp: payload.exp, sid };
  } catch {
    return null;
  }
}

/** Use tokenless legacy IDs during migration, but never downgrade an explicit invalid token. */
export function resolvePlayerIdFromParts(parts: {
  token?: unknown;
  legacyPlayerId?: unknown;
}): { playerId: string; legacy: boolean } | null {
  const tokenProvided =
    parts.token !== undefined &&
    parts.token !== null &&
    !(typeof parts.token === "string" && parts.token.trim() === "");
  if (tokenProvided) {
    const verified = verifyPlayerToken(parts.token);
    return verified ? { playerId: verified.playerId, legacy: false } : null;
  }

  const legacy = sanitizePlayerId(parts.legacyPlayerId);
  if (legacy && !isAccountDeleted(legacy)) return { playerId: legacy, legacy: true };
  return null;
}

export function readTokenFromAuthHeader(header: unknown): string | null {
  if (typeof header !== "string" || !header.startsWith("Bearer ")) return null;
  const token = header.slice("Bearer ".length).trim();
  return token || null;
}
