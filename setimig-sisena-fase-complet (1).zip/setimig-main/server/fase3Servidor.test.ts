import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import fs from "fs/promises";
import path from "path";
import { createServer } from "http";
import { Server } from "socket.io";
import { io as ioClient } from "socket.io-client";
import { getBalance, resetBalanceStoreCacheForTests, setBalance } from "./balances.ts";
import {
  advanceRisingBlindsAfterHand,
  initialRisingBlindsState,
  buildRisingBlindLevels,
} from "../shared/risingBlinds.ts";
import { computeSoloMatchResult } from "../shared/matchRules.ts";
import {
  getGameHostForTests,
  getRoomSnapshotForTests,
  resetGameStateForTests,
  setupGameHandlers,
} from "./game.ts";
import { beginBettingPhase, emptyRoomBase, type Room } from "../shared/gameEngine.ts";
import { applyWagerConfigToRoom, buildRoomWagerConfig, tickRisingBlindsOnRoom } from "../shared/roomWagerConfig.ts";

const DATA_ROOT = path.join(process.cwd(), "data", `fase3-test-${Date.now()}`);

describe("fase3 servidor", () => {
  before(() => {
    process.env.BALANCE_DATA_DIR = DATA_ROOT;
    process.env.SETIMIG_TEST_FAST = "1";
    resetBalanceStoreCacheForTests();
  });

  after(async () => {
    resetGameStateForTests();
    await fs.rm(DATA_ROOT, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 }).catch(() => undefined);
    delete process.env.BALANCE_DATA_DIR;
  });

  it("crear taula privada amb perfil d'aposta aplica min/max", async () => {
    resetGameStateForTests();
    const httpServer = createServer();
    const io = new Server(httpServer);
    await setupGameHandlers(io);
    await new Promise<void>((resolve) => httpServer.listen(0, resolve));
    const port = (httpServer.address() as { port: number }).port;
    const socket = ioClient(`http://127.0.0.1:${port}`, { transports: ["websocket"] });
    await new Promise<void>((resolve) => socket.on("connect", () => resolve()));

    const view = await new Promise<{
      minBet: number;
      tableMaxBet?: number;
      betProfileId?: string;
      risingBlinds?: { enabled: boolean };
    }>(
      (resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("timeout")), 8000);
        socket.once("joined_room", (payload) => {
          clearTimeout(timer);
          resolve(payload);
        });
        socket.emit("create_private_table", {
          playerName: "Host",
          playerId: "fase3host01",
          betProfileId: "baix",
          risingBlinds: { enabled: true, handsPerLevel: 2 },
        });
      }
    );

    assert.equal(view.betProfileId, "baix");
    assert.equal(view.minBet, 50);
    assert.equal(view.tableMaxBet, 500);
    assert.equal(view.risingBlinds?.enabled, true);

    socket.disconnect();
    httpServer.close();
  });

  it("torneig ràpid no modifica el saldo real", async () => {
    const playerId = "fase3tourney1";
    resetBalanceStoreCacheForTests();
    await setBalance(playerId, 12_345);
    resetGameStateForTests();

    const httpServer = createServer();
    const io = new Server(httpServer);
    await setupGameHandlers(io);
    await new Promise<void>((resolve) => httpServer.listen(0, resolve));
    const port = (httpServer.address() as { port: number }).port;
    const socket = ioClient(`http://127.0.0.1:${port}`, { transports: ["websocket"] });
    await new Promise<void>((resolve) => socket.on("connect", () => resolve()));

    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("timeout join")), 8000);
      socket.once("joined_room", (payload: { fastTournament?: boolean; risingBlinds?: { enabled: boolean } }) => {
        clearTimeout(timer);
        assert.equal(payload.fastTournament, true);
        assert.equal(payload.risingBlinds?.enabled, true);
        resolve();
      });
      socket.emit("join_solo_room", {
        playerName: "Torneig",
        playerId,
        botCount: 1,
        botDifficulty: "easy",
        fastTournament: { enabled: true },
      });
    });

    socket.disconnect();
    await new Promise((r) => setTimeout(r, 200));
    assert.equal(await getBalance(playerId), 12_345);
    httpServer.close();
  });

  it("eliminació i guanyador segons minBet vigent", () => {
    const minBet = 200;
    const players = [
      { id: "h", name: "Humà", chips: 150, isBot: false },
      { id: "b", name: "Bot", chips: 5000, isBot: true },
    ];
    const match = computeSoloMatchResult(players, minBet, "h");
    assert.ok(match);
    assert.equal(match!.viewerOutcome, "eliminated");
    assert.equal(match!.winnerName, "Bot");
  });

  it("pujada de cegues al motor compartit", () => {
    const cfg = buildRoomWagerConfig({
      betProfileId: "mitja",
      risingBlinds: { enabled: true, handsPerLevel: 1 },
    });
    assert.ok(cfg);
    const room: Room = emptyRoomBase("r", "Test", cfg!.effectiveMinBet, 0);
    applyWagerConfigToRoom(room, cfg!);
    const startMin = room.minBet;
    tickRisingBlindsOnRoom(room);
    assert.ok(room.minBet >= startMin);
  });

  it("integració beginBettingPhase respecta minBet després de cegues", () => {
    const levels = buildRisingBlindLevels(100, 1000);
    let state = initialRisingBlindsState(levels);
    const opts = { enabled: true, handsPerLevel: 1 };
    for (let i = 0; i < 3; i++) {
      const r = advanceRisingBlindsAfterHand(state, opts);
      state = r.state;
    }
    const room = emptyRoomBase("r2", "T", state.levels[state.levelIndex]!, 0);
    room.risingBlinds = state;
    room.risingBlindsOptions = opts;
    room.minBet = state.levels[state.levelIndex]!;
    room.tableMaxBet = 1000;
    room.players = [
      {
        id: "b",
        playerId: "b",
        seatToken: "s",
        name: "Banca",
        chips: 10_000,
        bet: 0,
        isBanker: true,
        status: "waiting",
        handSlots: [],
        activeSlotIndex: 0,
        lastRoyal7Payout: 0,
        royal7AsBankerStreak: 0,
      },
      {
        id: "p",
        playerId: "p",
        seatToken: "s2",
        name: "Jugador",
        chips: 5000,
        bet: 0,
        isBanker: false,
        status: "waiting",
        handSlots: [],
        activeSlotIndex: 0,
        lastRoyal7Payout: 0,
        royal7AsBankerStreak: 0,
      },
    ];
    room.soloAi = true;
    room.phaseB = {
      handsTotal: 99,
      handsCompleted: 0,
      chipPool: 10_000,
      startingChips: 2000,
    };
    const host = getGameHostForTests();
    beginBettingPhase(host, room);
    assert.equal(room.phase, "betting");
    assert.ok(room.minBet >= 100);
  });
});
