import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createServer } from "http";
import { Server } from "socket.io";
import { io as ioClient } from "socket.io-client";
import { getGameHostForTests, getRoomSnapshotForTests, resetGameStateForTests, setupGameHandlers } from "./game.ts";
import {
  applyPhaseBRevenge,
  clearRoomTimers,
  clearSoloRoomState,
  emptyRoomBase,
  ensurePhaseBMatchInitialized,
  roomToView,
  type Player,
  type Room,
} from "../shared/gameEngine.ts";
import type { RoomView } from "../src/gameTypes.ts";

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";

function seat(id: string, extra: Partial<Player> = {}): Player {
  return {
    id,
    playerId: id,
    seatToken: id,
    name: id,
    chips: 2_000,
    bet: 0,
    isBanker: false,
    status: "waiting",
    handSlots: [],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
    ...extra,
  };
}

function oldGameRoom(opts: Partial<Room> = {}): Room {
  const room = emptyRoomBase("solo-x", "Solo", 100, 0);
  Object.assign(room, { soloAi: true, soloHumanPlayerId: "human1", ...opts });
  room.players = [seat("human1"), seat("bot-1", { isBot: true })];
  // Restes d'una partida anterior de 10 mans.
  room.sessionStats.set("human1", { handsPlayed: 10, netCf: -700, winStreak: 2, lastOutcome: "win", handsWon: 17, bestHandWin: 400 });
  return room;
}

describe("estadístiques de sessió per partida (P1-S1)", () => {
  it("una partida solo nova comença de zero (normal i pràctica)", () => {
    for (const practiceMode of [false, true]) {
      const room = oldGameRoom({ practiceMode });
      clearSoloRoomState(getGameHostForTests(), room);
      assert.equal(room.sessionStats.size, 0);

      const room2 = oldGameRoom({ practiceMode });
      ensurePhaseBMatchInitialized(room2);
      assert.equal(room2.sessionStats.size, 0, "una partida nova (phaseB nou) reinicia");
      const view = roomToView(room2, "human1", getGameHostForTests());
      assert.equal(view.sessionStats?.handsPlayed, 0);
      assert.equal(view.sessionStats?.netCf, 0);
      assert.equal(view.sessionStats?.handsWon, 0);
    }
  });

  it("la Revenja solo reinicia; en taula privada no es toca", () => {
    const solo = oldGameRoom({ matchEnded: true });
    applyPhaseBRevenge(solo);
    assert.equal(solo.sessionStats.size, 0);

    const priv = oldGameRoom({ soloAi: false, isPrivate: true, matchEnded: true });
    applyPhaseBRevenge(priv);
    assert.equal(priv.sessionStats.get("human1")?.handsPlayed, 10);
  });

  it("la vista mai dona més mans guanyades que jugades", () => {
    const room = oldGameRoom();
    room.phaseB = { handsTotal: 10, handsCompleted: 10, chipPool: 4_000, startingChips: 2_000 };
    const view = roomToView(room, "human1", getGameHostForTests());
    assert.equal(view.sessionStats?.handsPlayed, 10);
    assert.equal(view.sessionStats?.handsWon, 10);
  });

  it("per socket: mans jugades → partida nova i Revenja tornen a zero", async () => {
    process.env.SETIMIG_TEST_FAST = "1";
    resetGameStateForTests();
    const http = createServer();
    const io = new Server(http);
    await setupGameHandlers(io);
    await new Promise<void>((r) => http.listen(0, "127.0.0.1", () => r()));
    const port = (http.address() as { port: number }).port;
    const socket = ioClient(`http://127.0.0.1:${port}`, { transports: ["websocket"], forceNew: true });
    await new Promise<void>((r) => socket.on("connect", () => r()));
    const playerId = "statsreset000001";
    let resumeToken: string | undefined;
    const join = (practiceMode: boolean) =>
      new Promise<RoomView>((resolve, reject) => {
        const t = setTimeout(() => reject(new Error("join timeout")), 8000);
        socket.once("joined_room", (v: RoomView) => {
          clearTimeout(t);
          resumeToken = v.soloResumeToken ?? resumeToken;
          resolve(v);
        });
        socket.emit("join_solo_room", { playerName: "Stats", playerId, botCount: 1, practiceMode, soloResumeToken: resumeToken });
      });
    const playUntilHands = (roomId: string, n: number) =>
      new Promise<void>((resolve, reject) => {
        const deadline = Date.now() + 20_000;
        const tick = () => {
          const snap = getRoomSnapshotForTests(roomId);
          if ((snap?.sessionStats.get(playerId)?.handsPlayed ?? 0) >= n) return resolve();
          if (Date.now() > deadline) return reject(new Error(`no s'han jugat ${n} mans (fase ${snap?.phase})`));
          setTimeout(tick, 25);
        };
        tick();
      });
    const leave = async (roomId: string) => {
      socket.emit("leave_room", roomId);
      await new Promise((r) => setTimeout(r, 150));
    };
    const endMatch = async (roomId: string) => {
      const snap = getRoomSnapshotForTests(roomId)!;
      // Atura la mà en curs: cap temporitzador pendent no pot emetre més room_update antics.
      clearRoomTimers(getGameHostForTests(), snap);
      snap.phase = "waiting";
      snap.matchEnded = true;
      // Anada i tornada pel mateix socket: els room_update ja enviats arriben abans de l'ack.
      await new Promise<void>((r) => socket.emit("resume_status", { playerId }, () => r()));
      return snap;
    };
    try {
      const first = await join(false);
      await playUntilHands(first.id, 2);
      await leave(first.id);

      // Partida nova: comença de zero.
      const second = await join(false);
      assert.equal(second.sessionStats?.handsPlayed ?? 0, 0);
      assert.equal(second.sessionStats?.netCf ?? 0, 0);
      await playUntilHands(second.id, 1);
      await endMatch(second.id);

      // Revenja: també de zero.
      const afterRematch = new Promise<RoomView>((resolve) => {
        const onUpdate = (v: RoomView) => {
          socket.off("room_update", onUpdate);
          resolve(v);
        };
        socket.on("room_update", onUpdate);
      });
      socket.emit("quick_rematch", second.id);
      const v = await afterRematch;
      assert.equal(v.sessionStats?.handsPlayed ?? 0, 0);
      assert.equal(getRoomSnapshotForTests(second.id)!.sessionStats.get(playerId)?.handsPlayed ?? 0, 0);

      // Pràctica després d'una partida normal: no mostra l'acumulat anterior.
      await playUntilHands(second.id, 1);
      await leave(second.id);
      const practice = await join(true);
      assert.equal(practice.sessionStats?.handsPlayed ?? 0, 0);
      assert.equal(practice.sessionStats?.netCf ?? 0, 0);
      const s = getRoomSnapshotForTests(practice.id)!.sessionStats.get(playerId);
      assert.ok((s?.handsWon ?? 0) <= (s?.handsPlayed ?? 0));
    } finally {
      delete process.env.SETIMIG_TEST_FAST;
      socket.disconnect();
      io.close();
      await new Promise<void>((r) => http.close(() => r()));
    }
  });
});
