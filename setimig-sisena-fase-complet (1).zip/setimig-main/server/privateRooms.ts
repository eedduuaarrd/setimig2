/**
 * Codis d'invitació de taules privades (URL-safe). Els nous tenen 6–8 caràcters generats
 * amb Web Crypto (`crypto.getRandomValues`, sense biaix) (31^6 ≈ 8,9·10^8); s'accepten els antics de 4–5 per compatibilitat.
 */
const CODE_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789";
export const INVITE_CODE_LENGTH = 6;
export const INVITE_CODE_MIN_ACCEPTED = 4;
export const INVITE_CODE_MAX_ACCEPTED = 8;

/** Enter uniforme a [0, max) amb Web Crypto (Node 22 i navegador; aquest mòdul també entra al bundle client). */
function secureRandomInt(max: number): number {
  const limit = Math.floor(0x1_0000_0000 / max) * max;
  const buf = new Uint32Array(1);
  for (;;) {
    globalThis.crypto.getRandomValues(buf);
    if (buf[0]! < limit) return buf[0]! % max;
  }
}

export function generateInviteCode(length = INVITE_CODE_LENGTH): string {
  const n = Math.min(INVITE_CODE_MAX_ACCEPTED, Math.max(INVITE_CODE_LENGTH, Math.floor(length) || INVITE_CODE_LENGTH));
  let out = "";
  for (let i = 0; i < n; i++) {
    out += CODE_ALPHABET[secureRandomInt(CODE_ALPHABET.length)]!;
  }
  return out;
}

export function normalizeInviteCode(raw: unknown): string | null {
  if (typeof raw !== "string") return null;
  const code = raw.trim().toUpperCase().replace(/[^A-Z0-9]/g, "");
  if (code.length < INVITE_CODE_MIN_ACCEPTED || code.length > INVITE_CODE_MAX_ACCEPTED) return null;
  return code;
}

export function privateShareUrl(origin: string, code: string): string {
  const base = origin.replace(/\/$/, "");
  return `${base}/t/${encodeURIComponent(code)}`;
}

export { newSeatToken } from "../shared/seatToken.ts";
