import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createServer, type Server as HttpServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket as ClientSocket } from "socket.io-client";
import { setupGameHandlers } from "./game.ts";
import { canResumeSoloSeat, newSoloResumeToken } from "./soloResumeAuth.ts";
import type { RoomView } from "../src/gameTypes.ts";

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";

const PLAYER_ID = "pas9soloresumeplayer01";
const WAITING_PLAYER_ID = "pas9solowaitingplayer01";

describe("solo resume authorization", () => {
  it("allows ID-only resume only for a disconnected legacy seat", () => {
    assert.equal(canResumeSoloSeat(undefined, undefined), true);
    assert.equal(canResumeSoloSeat(undefined, undefined, false), true);
    assert.equal(canResumeSoloSeat(undefined, undefined, true), false);
  });

  it("requires the matching high-entropy secret for protected seats", () => {
    const token = newSoloResumeToken();
    assert.ok(token.length >= 40);
    assert.equal(canResumeSoloSeat(token, token), true);
    assert.equal(canResumeSoloSeat(token, undefined), false);
    assert.equal(canResumeSoloSeat(token, `${token}x`), false);
  });
});

async function startTestServer(): Promise<{ url: string; http: HttpServer; io: SocketIOServer }> {
  const http = createServer();
  const io = new SocketIOServer(http, { cors: { origin: "*" } });
  await setupGameHandlers(io);
  await new Promise<void>((resolve) => http.listen(0, "127.0.0.1", () => resolve()));
  const addr = http.address();
  const port = typeof addr === "object" && addr ? addr.port : 0;
  return { url: `http://127.0.0.1:${port}`, http, io };
}

function connect(url: string): Promise<ClientSocket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.on("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.on("connect_error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

describe("solo IA resume after reload", () => {
  it("rejoins mid-hand with same playerId and new socket id", async () => {
    const server = await startTestServer();
    const socket1 = await connect(server.url);
    let midHand: RoomView | null = null;

    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("join timeout")), 15_000);
      socket1.once("joined_room", (room: RoomView) => {
        clearTimeout(timer);
        if (room.phase !== "waiting") {
          midHand = room;
          resolve();
          return;
        }
        socket1.emit("place_bet", { roomId: room.id, amount: room.minBet ?? 100 });
      });
      socket1.on("room_update", (room: RoomView) => {
        const me = room.players?.find((p) => !p.isBot);
        if (!me) return;
        if (room.phase !== "waiting" && room.phase !== "settlement") {
          midHand = room;
          clearTimeout(timer);
          resolve();
        }
        if (room.phase === "betting" && me.status === "betting" && me.bet === 0) {
          socket1.emit("place_bet", { roomId: room.id, amount: room.minBet ?? 100 });
        }
      });
      socket1.emit("join_solo_room", {
        playerName: "ResumeTest",
        playerId: PLAYER_ID,
        botCount: 1,
      });
    });

    assert.ok(midHand);
    assert.notEqual(midHand!.phase, "waiting");
    assert.ok(midHand!.soloResumeToken);
    const chipsBefore = midHand!.players?.find((p) => !p.isBot)?.chips;
    socket1.disconnect();

    const socket2 = await connect(server.url);
    const resumed = await new Promise<RoomView>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("resume timeout")), 15_000);
      socket2.once("joined_room", (room: RoomView) => {
        clearTimeout(timer);
        resolve(room);
      });
      socket2.emit("join_solo_room", {
        playerName: "ResumeTest",
        playerId: PLAYER_ID,
        soloResumeToken: midHand!.soloResumeToken,
        botCount: 1,
      });
    });

    assert.equal(resumed.id, midHand!.id);
    assert.notEqual(resumed.phase, "waiting");
    const me = resumed.players?.find((p) => !p.isBot);
    assert.ok(me);
    assert.equal(me!.isBot, false);
    assert.equal(me!.id, socket2.id);
    if (typeof chipsBefore === "number") {
      assert.equal(me!.chips, chipsBefore);
    }

    socket2.disconnect();
    server.io.close();
    await new Promise<void>((resolve) => server.http.close(() => resolve()));
  });

  it("rejects ID-only takeover of a new solo seat while it is waiting", async () => {
    const server = await startTestServer();
    const owner = await connect(server.url);
    const room = await new Promise<RoomView>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("join timeout")), 10_000);
      owner.once("joined_room", (joined: RoomView) => {
        clearTimeout(timer);
        resolve(joined);
      });
      owner.emit("join_solo_room", {
        playerName: "WaitingOwner",
        playerId: WAITING_PLAYER_ID,
        botCount: 1,
      });
    });
    assert.equal(room.phase, "waiting");
    assert.ok(room.soloResumeToken);

    const attacker = await connect(server.url);
    const error = await new Promise<{ code?: string }>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("game_error timeout")), 10_000);
      attacker.once("game_error", (payload: { code?: string }) => {
        clearTimeout(timer);
        resolve(payload);
      });
      attacker.emit("join_solo_room", {
        playerName: "Attacker",
        playerId: WAITING_PLAYER_ID,
        botCount: 1,
      });
    });
    assert.equal(error.code, "SOLO_ACTIVE_ELSEWHERE");

    attacker.disconnect();
    owner.disconnect();
    server.io.close();
    await new Promise<void>((resolve) => server.http.close(() => resolve()));
  });
});
