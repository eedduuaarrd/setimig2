import fs from "fs/promises";
import path from "path";
import { isAccountDeleted } from "./deletedAccounts.ts";
import {
  pruneEngagementMissions,
  pruneWeeklyLeaderboardDir,
  retentionLimits,
  rotateTimestampedBackups,
} from "./dataRetention.ts";
import { coalesceDelayMs, registerFlusher, writeJsonAtomic, writeJsonAtomicSync } from "./writeCoalescing.ts";

const STORE_VERSION = 1;

function dataDir(): string {
  return process.env.BALANCE_DATA_DIR || path.join(process.cwd(), "data");
}

function engagementDir(): string {
  return path.join(dataDir(), "player-engagement");
}

function playerPath(playerId: string): string {
  return path.join(engagementDir(), `${playerId}.json`);
}

function weeklyDir(): string {
  return path.join(dataDir(), "weekly-leaderboard");
}

function weeklyPath(weekKey: string): string {
  return path.join(weeklyDir(), `${weekKey}.json`);
}

export type EngagementCounters = {
  realWins: number;
  realHandsPlayed: number;
  noPassStreak: number;
  matchWins: number;
};

export type EngagementFile = {
  version: number;
  counters: EngagementCounters;
  achievementsUnlocked: Record<string, { at: number; rewarded: boolean }>;
  missionProgress: Record<string, { progress: number; claimedAt: number | null }>;
  rewardLedger: string[];
};

let cache = new Map<string, EngagementFile>();
let writeChain: Promise<void> = Promise.resolve();

const weeklyCache = new Map<string, Record<string, number>>();
let weeklyWriteChain: Promise<void> = Promise.resolve();

function emptyEngagement(): EngagementFile {
  return {
    version: STORE_VERSION,
    counters: { realWins: 0, realHandsPlayed: 0, noPassStreak: 0, matchWins: 0 },
    achievementsUnlocked: {},
    missionProgress: {},
    rewardLedger: [],
  };
}

async function backupFileIfExists(filePath: string): Promise<void> {
  try {
    await fs.access(filePath);
  } catch {
    return;
  }
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  await fs.copyFile(filePath, `${filePath}.bak-${stamp}`);
}

export async function readEngagement(playerId: string): Promise<EngagementFile> {
  return loadEngagement(playerId);
}

async function loadEngagement(playerId: string): Promise<EngagementFile> {
  const cached = cache.get(playerId);
  if (cached) return cached;
  await fs.mkdir(engagementDir(), { recursive: true });
  const storePath = playerPath(playerId);
  let raw: string;
  try {
    raw = await fs.readFile(storePath, "utf8");
  } catch (error) {
    if (error instanceof Error && "code" in error && error.code === "ENOENT") {
      const fresh = emptyEngagement();
      cache.set(playerId, fresh);
      return fresh;
    }
    throw error;
  }
  const parsed: unknown = JSON.parse(raw);
  if (typeof parsed !== "object" || parsed === null || (parsed as EngagementFile).version !== STORE_VERSION) {
    throw new Error(`Invalid engagement store for ${playerId}`);
  }
  const file = parsed as EngagementFile;
  cache.set(playerId, file);
  return file;
}

async function persistEngagement(playerId: string, file: EngagementFile): Promise<void> {
  if (isAccountDeleted(playerId)) return;
  pruneEngagementMissions(file, retentionLimits().missionDays);
  cache.set(playerId, file);
  await fs.mkdir(engagementDir(), { recursive: true });
  const storePath = playerPath(playerId);
  const tmp = `${storePath}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(file, null, 2), "utf8");
  await fs.rename(tmp, storePath);
}

export function enqueueEngagementWrite(task: () => Promise<void>): Promise<void> {
  writeChain = writeChain.then(task, task);
  return writeChain;
}

export async function withEngagement<T>(
  playerId: string,
  fn: (file: EngagementFile) => Promise<T> | T
): Promise<T> {
  let result!: T;
  await enqueueEngagementWrite(async () => {
    const file = await loadEngagement(playerId);
    result = await fn(file);
    await persistEngagement(playerId, file);
  });
  return result;
}

export async function readEngagementForTests(playerId: string): Promise<EngagementFile> {
  return loadEngagement(playerId);
}

/** Test helper: wait for queued engagement/weekly writes before deleting a temp data dir. */
export async function flushEngagementWritesForTests(): Promise<void> {
  await writeChain.catch(() => undefined);
  await flushWeeklyWrites().catch(() => undefined);
}

export function resetEngagementCacheForTests(): void {
  try {
    flushWeeklyWritesSync();
  } catch {
    /* el directori de proves pot haver desaparegut */
  }
  dirtyWeeks.clear();
  cache.clear();
  weeklyCache.clear();
  writeChain = Promise.resolve();
  weeklyWriteChain = Promise.resolve();
}

type WeeklyFile = { version: number; chipsWon: Record<string, number> };

async function loadWeekly(weekKey: string): Promise<WeeklyFile> {
  const cached = weeklyCache.get(weekKey);
  if (cached) return { version: 1, chipsWon: cached };
  await fs.mkdir(weeklyDir(), { recursive: true });
  const p = weeklyPath(weekKey);
  try {
    const raw = await fs.readFile(p, "utf8");
    const parsed = JSON.parse(raw) as WeeklyFile;
    const chips = parsed.chipsWon ?? {};
    weeklyCache.set(weekKey, chips);
    return { version: 1, chipsWon: chips };
  } catch (error) {
    if (error instanceof Error && "code" in error && error.code === "ENOENT") {
      // Setmana nova: aprofitem per descartar setmanes antigues.
      await pruneWeeklyLeaderboardDir(weeklyDir(), retentionLimits().weeklyLeaderboardWeeks, weekKey).catch(
        () => undefined
      );
      return { version: 1, chipsWon: {} };
    }
    throw error;
  }
}

/** Setmanes pendents d'escriure (clau → ruta capturada) i temporitzador del buidat agrupat. */
const dirtyWeeks = new Map<string, string>();
let weeklyFlushTimer: ReturnType<typeof setTimeout> | null = null;

function clearWeeklyFlushTimer(): void {
  if (weeklyFlushTimer) {
    clearTimeout(weeklyFlushTimer);
    weeklyFlushTimer = null;
  }
}

/** S'ha de cridar dins de la cadena `weeklyWriteChain`. */
async function persistWeekly(weekKey: string, chipsWon: Record<string, number>): Promise<void> {
  weeklyCache.set(weekKey, chipsWon);
  const delay = coalesceDelayMs();
  if (delay === 0) {
    dirtyWeeks.delete(weekKey);
    await writeJsonAtomic(weeklyPath(weekKey), { version: 1, chipsWon });
    return;
  }
  if (!dirtyWeeks.has(weekKey)) dirtyWeeks.set(weekKey, weeklyPath(weekKey));
  if (!weeklyFlushTimer) {
    weeklyFlushTimer = setTimeout(() => {
      weeklyFlushTimer = null;
      void flushWeeklyWrites().catch((err) => console.error("[weekly] flush failed:", err));
    }, delay);
    weeklyFlushTimer.unref?.();
  }
}

/** Escriu ara les setmanes pendents (en ordre amb la resta d'escriptures del rànquing). */
export function flushWeeklyWrites(): Promise<void> {
  clearWeeklyFlushTimer();
  weeklyWriteChain = weeklyWriteChain
    .catch(() => undefined)
    .then(async () => {
      for (const [weekKey, target] of [...dirtyWeeks]) {
        const chipsWon = weeklyCache.get(weekKey);
        dirtyWeeks.delete(weekKey);
        if (!chipsWon) continue;
        try {
          await writeJsonAtomic(target, { version: 1, chipsWon });
        } catch (err) {
          if (!dirtyWeeks.has(weekKey)) dirtyWeeks.set(weekKey, target);
          throw err;
        }
      }
    });
  return weeklyWriteChain;
}

function flushWeeklyWritesSync(): void {
  clearWeeklyFlushTimer();
  for (const [weekKey, target] of [...dirtyWeeks]) {
    const chipsWon = weeklyCache.get(weekKey);
    dirtyWeeks.delete(weekKey);
    if (chipsWon) writeJsonAtomicSync(target, { version: 1, chipsWon });
  }
}

registerFlusher({ name: "weekly-leaderboard", flush: flushWeeklyWrites, flushSync: flushWeeklyWritesSync });

export async function addWeeklyChipsWon(
  weekKey: string,
  playerId: string,
  delta: number
): Promise<void> {
  if (delta <= 0 || isAccountDeleted(playerId)) return;
  // `.catch` first: one failed write must not poison the chain for the rest of the process.
  await (weeklyWriteChain = weeklyWriteChain.catch(() => undefined).then(async () => {
    const file = await loadWeekly(weekKey);
    const prev = file.chipsWon[playerId] ?? 0;
    file.chipsWon[playerId] = prev + Math.floor(delta);
    await persistWeekly(weekKey, file.chipsWon);
  }));
}

/** Rànquing complet de la setmana, ordenat (fitxes desc., empat per playerId per ser determinista). */
/** Esborrat de compte: assoliments, missions i recompenses (fitxer propi). */
export async function deleteEngagement(playerId: string): Promise<boolean> {
  let removed = false;
  await enqueueEngagementWrite(async () => {
    cache.delete(playerId);
    try {
      await fs.rm(playerPath(playerId));
      removed = true;
    } catch (err) {
      if ((err as NodeJS.ErrnoException)?.code !== "ENOENT") throw err;
    }
  });
  return removed;
}

/**
 * Esborrat de compte: treu el jugador de tots els rànquings setmanals (en memòria i a disc).
 * Les entrades dels altres jugadors no canvien. Retorna les setmanes afectades.
 */
export async function removeFromWeeklyLeaderboards(playerId: string): Promise<string[]> {
  const weeks: string[] = [];
  await (weeklyWriteChain = weeklyWriteChain.catch(() => undefined).then(async () => {
    let names: string[] = [];
    try {
      names = await fs.readdir(weeklyDir());
    } catch {
      names = [];
    }
    const keys = new Set([...weeklyCache.keys(), ...names.filter((n) => n.endsWith(".json")).map((n) => n.slice(0, -5))]);
    for (const weekKey of keys) {
      const file = await loadWeekly(weekKey);
      if (!(playerId in file.chipsWon)) continue;
      delete file.chipsWon[playerId];
      weeklyCache.set(weekKey, file.chipsWon);
      dirtyWeeks.delete(weekKey);
      await writeJsonAtomic(weeklyPath(weekKey), { version: 1, chipsWon: file.chipsWon });
      weeks.push(weekKey);
    }
  }));
  return weeks.sort();
}

export async function getWeeklyLeaderboardRanked(
  weekKey: string
): Promise<{ playerId: string; chipsWon: number }[]> {
  const file = await loadWeekly(weekKey);
  return Object.entries(file.chipsWon)
    .map(([playerId, chipsWon]) => ({ playerId, chipsWon }))
    .sort((a, b) => b.chipsWon - a.chipsWon || (a.playerId < b.playerId ? -1 : a.playerId > b.playerId ? 1 : 0));
}

export async function getWeeklyLeaderboard(
  weekKey: string,
  limit: number
): Promise<{ playerId: string; chipsWon: number }[]> {
  return (await getWeeklyLeaderboardRanked(weekKey)).slice(0, limit);
}

export async function ensureEngagementDirWithBackup(): Promise<void> {
  await fs.mkdir(engagementDir(), { recursive: true });
  await fs.mkdir(weeklyDir(), { recursive: true });
  const balances = path.join(dataDir(), "balances.json");
  await backupFileIfExists(balances);
  const limits = retentionLimits();
  await rotateTimestampedBackups(balances, limits.balanceBackups);
  await pruneWeeklyLeaderboardDir(weeklyDir(), limits.weeklyLeaderboardWeeks);
}
