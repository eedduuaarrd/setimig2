export type AchievementDef = {
  id: string;
  title: string;
  description: string;
  rewardChips: number;
  /** Valor que ha d'assolir el comptador per desbloquejar-lo (vegeu `achievementProgressCurrent`). */
  target: number;
};

/** Claus i18n estables perquè el client tradueixi; el text català es manté com a fallback. */
export function achievementI18nKeys(id: string): { titleKey: string; descKey: string } {
  return { titleKey: `achievements.${id}.title`, descKey: `achievements.${id}.desc` };
}

export const ACHIEVEMENT_DEFS: AchievementDef[] = [
  {
    id: "first_win",
    title: "Primera victòria",
    description: "Guanya la teva primera mà (fora de pràctica).",
    rewardChips: 500,
    target: 1,
  },
  {
    id: "natural_seven_half",
    title: "7½ natural",
    description: "Aconsegueix un 7 i mig natural en partida real.",
    rewardChips: 1_000,
    target: 1,
  },
  {
    id: "ten_wins",
    title: "Deu victòries",
    description: "Guanya 10 mans en partides reals.",
    rewardChips: 2_000,
    target: 10,
  },
  {
    id: "no_bust_five",
    title: "Mà ferma",
    description: "Completa 5 mans seguides sense passar-te (partida real).",
    rewardChips: 750,
    target: 5,
  },
  {
    id: "first_match_win",
    title: "Campió de taula",
    description: "Guanya una partida completa (fora de pràctica).",
    rewardChips: 1_500,
    target: 1,
  },
];

export const ACHIEVEMENT_BY_ID = new Map(ACHIEVEMENT_DEFS.map((a) => [a.id, a]));
