/**
 * Aposta en viu: durant la fase `betting`, cada aposta (humana o d'un bot) surt
 * en un `room_update` abans que es tanqui la fase. Les esperes van lligades a
 * l'esdeveniment, no a un son.
 */
import { describe, it, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";
import fs from "fs/promises";
import os from "os";
import path from "path";
import { createServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket } from "socket.io-client";
import {
  getGameHostForTests,
  getRoomSnapshotForTests,
  resetGameStateForTests,
  setHostTimersPausedForTests,
  setupGameHandlers,
} from "./game.ts";
import { issuePlayerToken } from "./playerToken.ts";
import { resetPrivateRoomStoreCacheForTests } from "./privateRoomStore.ts";
import {
  beginBettingPhase,
  clearRoomTimers,
  emptyRoomBase,
  fillPrivateBots,
  roomToView,
  type GameHost,
  type Player,
} from "../shared/gameEngine.ts";
import { removeTestDataDir } from "./testing/testDataDir.ts";

const HOST_ID = "apostaenvivhost001";
const GUEST_ID = "apostaenvivguest01";
const SOLO_ID = "apostaenvivsolo0001";

type BettingSeat = {
  id: string;
  bet?: number;
  chips?: number;
  isBanker?: boolean;
  isBot?: boolean;
  betting?: { status?: string; amount?: number } | null;
  handSlots?: { cards?: { card: { suit?: string; value?: number } | null; faceUp?: boolean }[] }[];
};

type BettingView = {
  phase?: string;
  pot?: number;
  deck?: unknown;
  players?: BettingSeat[];
};

function connect(url: string): Promise<Socket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.on("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.on("connect_error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

function waitJoined(socket: Socket): Promise<{ id: string; inviteCode?: string; minBet?: number }> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("join timeout")), 15_000);
    socket.once("joined_room", (room: { id: string; inviteCode?: string; minBet?: number }) => {
      clearTimeout(timer);
      resolve(room);
    });
  });
}

/** El proper `room_update` que compleix `pred`. El temps límit només falla el test. */
function whenRoomView(socket: Socket, pred: (view: BettingView) => boolean, label: string): Promise<BettingView> {
  return new Promise((resolve, reject) => {
    let lastPhase = "";
    const onUpdate = (view: BettingView) => {
      lastPhase = view.phase ?? "";
      if (!pred(view)) return;
      cleanup();
      resolve(view);
    };
    const onError = (err: { code?: string; message?: string }) => {
      cleanup();
      reject(new Error(`${label}: game_error ${err?.code ?? "?"} (${err?.message ?? ""})`));
    };
    const timer = setTimeout(() => {
      cleanup();
      reject(new Error(`${label} timeout (darrera fase ${lastPhase || "?"})`));
    }, 15_000);
    const cleanup = () => {
      clearTimeout(timer);
      socket.off("room_update", onUpdate);
      socket.off("game_error", onError);
    };
    socket.on("room_update", onUpdate);
    socket.on("game_error", onError);
  });
}

function liveBet(view: BettingView, bettorId: string, amount: number): boolean {
  if (view.phase !== "betting") return false;
  const bettor = view.players?.find((p) => p.id === bettorId);
  const pending = view.players?.some((p) => p.betting?.status === "pending");
  return bettor?.betting?.status === "placed" && bettor.betting.amount === amount && pending === true;
}

function assertNoFaceDownValues(view: BettingView) {
  assert.equal(view.deck, undefined);
  assert.equal(JSON.stringify(view).includes('"deck"'), false);
  for (const player of view.players ?? []) {
    assert.equal(player.handSlots?.length ?? 0, 0, "a la fase d'aposta encara no hi ha cartes");
    for (const slot of player.handSlots ?? []) {
      for (const card of slot.cards ?? []) {
        if (card.faceUp !== true) assert.equal(card.card, null);
      }
    }
  }
}

async function startServer(): Promise<{ url: string; http: ReturnType<typeof createServer>; io: SocketIOServer }> {
  const http = createServer();
  const io = new SocketIOServer(http, { cors: { origin: "*" } });
  await setupGameHandlers(io);
  await new Promise<void>((resolve) => http.listen(0, "127.0.0.1", () => resolve()));
  const port = (http.address() as { port: number }).port;
  return { url: `http://127.0.0.1:${port}`, http, io };
}

async function stopServer(io: SocketIOServer, http: ReturnType<typeof createServer>) {
  io.close();
  await new Promise<void>((resolve) => http.close(() => resolve()));
}

function seat(id: string, extra: Partial<Player> = {}): Player {
  return {
    id,
    playerId: id,
    seatToken: id,
    name: id,
    chips: 2_000,
    bet: 0,
    isBanker: false,
    status: "betting",
    handSlots: [],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
    ...extra,
  };
}

describe("aposta en viu", () => {
  let dataDir: string;

  beforeEach(async () => {
    dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "setimig-aposta-"));
    process.env.BALANCE_DATA_DIR = dataDir;
    process.env.SETIMIG_TEST_FAST = "1";
    resetGameStateForTests();
    resetPrivateRoomStoreCacheForTests();
  });

  afterEach(async () => {
    setHostTimersPausedForTests(false);
    delete process.env.SETIMIG_TEST_FAST;
    await removeTestDataDir(dataDir);
  });

  it("roomToView marca placed, pending i null sense ensenyar cartes tapades", () => {
    const host: GameHost = { emitRoomUpdate() {}, schedule: setTimeout, clearTimeout };
    const room = emptyRoomBase("aposta-vista", "Aposta", 100, 0);
    room.phase = "betting";
    const secret = { suit: "hearts" as const, value: 7, points: 7 };
    const banker = seat("banca", { isBanker: true, status: "betting", bet: 0 });
    const placed = seat("ja", {
      bet: 100,
      chips: 1_900,
      status: "playing",
      handSlots: [
        {
          id: "s",
          bet: 100,
          cards: [{ id: "c", card: secret, faceUp: false }],
          doubled: false,
          canDouble: false,
          mort: false,
          blindPair: false,
          blindUntilBankEnd: false,
          mortOffered: false,
          status: "playing",
        },
      ],
    });
    const pending = seat("falta", { bet: 0, status: "betting" });
    const exempt = seat("curt", { bet: 0, chips: 10, status: "betting" });
    room.players = [banker, placed, pending, exempt];

    const rival = roomToView(room, pending.id, host);
    const byId = new Map(rival.players.map((p) => [p.id, p]));
    assert.equal(byId.get("ja")?.betting?.status, "placed");
    assert.equal(byId.get("ja")?.betting?.amount, 100);
    assert.equal(byId.get("falta")?.betting?.status, "pending");
    assert.equal(byId.get("falta")?.betting?.amount, undefined);
    assert.equal(byId.get("banca")?.betting, null);
    assert.equal(byId.get("curt")?.betting, null);
    const hidden = byId.get("ja")?.handSlots[0]?.cards[0];
    assert.equal(hidden?.card, null);
    assert.equal(hidden?.faceUp, false);
    const wire = JSON.stringify(rival);
    assert.equal(wire.includes('"value":7'), false);
    assert.equal(wire.includes("hearts"), false);
    assert.equal(wire.includes('"deck"'), false);

    room.phase = "playing";
    const later = roomToView(room, pending.id, host);
    assert.ok(later.players.every((p) => p.betting === null));
    assert.equal(later.players.find((p) => p.id === "ja")?.bet, 100);
  });

  it("el client B veu l'aposta d'A amb la fase encara oberta i pending per a qui falta", async () => {
    const hostToken = issuePlayerToken(HOST_ID)!;
    const guestToken = issuePlayerToken(GUEST_ID)!;
    const { url, http, io } = await startServer();
    const host = await connect(url);
    const guest = await connect(url);
    setHostTimersPausedForTests(true);
    try {
      host.emit("create_private_table", {
        playerName: "Amfitrio",
        playerId: HOST_ID,
        playerToken: hostToken,
      });
      const created = await waitJoined(host);
      guest.emit("join_private_table", {
        inviteCode: created.inviteCode,
        playerName: "Convidat",
        playerId: GUEST_ID,
        playerToken: guestToken,
      });
      await waitJoined(guest);

      const seated = getRoomSnapshotForTests(created.id);
      assert.ok(seated);
      fillPrivateBots(seated, 3);
      assert.equal(seated.players.length, 3);

      const bankerReady = whenRoomView(
        host,
        (view) => view.players?.some((p) => p.isBanker) === true,
        "sorteig de banca",
      );
      host.emit("start_game", { roomId: created.id, playerToken: hostToken, actionSeq: 1 });
      await bankerReady;

      const drawn = getRoomSnapshotForTests(created.id);
      assert.ok(drawn);
      beginBettingPhase(getGameHostForTests(), drawn);
      clearRoomTimers(getGameHostForTests(), drawn);
      assert.equal(drawn.phase, "betting");

      const bettor = drawn.players.find((p) => !p.isBot && !p.isBanker);
      assert.ok(bettor, "hi ha un humà que ha d'apostar");
      const amount = drawn.minBet;
      const bettorSocket = bettor.id === host.id ? host : guest;
      const viewerSocket = bettorSocket === host ? guest : host;
      const token = bettorSocket === host ? hostToken : guestToken;
      const actionSeq = bettorSocket === host ? 2 : 1;

      const seenByViewer = whenRoomView(
        viewerSocket,
        (view) => liveBet(view, bettor.id, amount),
        "client B",
      );
      const seenByBettor = whenRoomView(
        bettorSocket,
        (view) => liveBet(view, bettor.id, amount),
        "client A",
      );
      bettorSocket.emit("place_bet", {
        roomId: created.id,
        amount,
        playerToken: token,
        actionSeq,
      });
      const [viewB, viewA] = await Promise.all([seenByViewer, seenByBettor]);

      for (const view of [viewB, viewA]) {
        assert.equal(view.phase, "betting");
        const placed = view.players?.find((p) => p.id === bettor.id);
        assert.equal(placed?.betting?.status, "placed");
        assert.equal(placed?.betting?.amount, amount);
        assert.equal(placed?.bet, amount);
        const pending = view.players?.filter((p) => p.betting?.status === "pending") ?? [];
        assert.ok(pending.length >= 1);
        for (const seat of pending) {
          assert.equal(seat.betting?.amount, undefined);
          assert.equal(seat.bet ?? 0, 0);
          assert.notEqual(seat.id, bettor.id);
        }
        const banker = view.players?.find((p) => p.isBanker);
        assert.equal(banker?.betting, null);
        assertNoFaceDownValues(view);
      }
    } finally {
      host.disconnect();
      guest.disconnect();
      setHostTimersPausedForTests(false);
      await stopServer(io, http);
    }
  });

  it("cada bot es publica amb la fase oberta i un altre bot encara pending", async () => {
    const { url, http, io } = await startServer();
    const socket = await connect(url);
    try {
      const live = whenRoomView(
        socket,
        (view) => {
          if (view.phase !== "betting") return false;
          const placed = view.players?.filter((p) => p.isBot && p.betting?.status === "placed") ?? [];
          const pending = view.players?.filter((p) => p.isBot && p.betting?.status === "pending") ?? [];
          return placed.length >= 1 && pending.length >= 1;
        },
        "aposta d'un bot",
      );
      socket.emit("join_solo_room", {
        playerName: "Solitari",
        playerId: SOLO_ID,
        botCount: 3,
        practiceMode: true,
        intent: "new",
      });
      const view = await live;
      assert.equal(view.phase, "betting");
      const placed = view.players?.filter((p) => p.isBot && p.betting?.status === "placed") ?? [];
      const pending = view.players?.filter((p) => p.isBot && p.betting?.status === "pending") ?? [];
      assert.ok(placed.length >= 1);
      assert.ok(pending.length >= 1);
      for (const bot of placed) {
        assert.equal(typeof bot.betting?.amount, "number");
        assert.ok((bot.betting?.amount ?? 0) > 0);
        assert.equal(bot.bet, bot.betting?.amount);
      }
      for (const bot of pending) {
        assert.equal(bot.betting?.amount, undefined);
        assert.equal(bot.bet ?? 0, 0);
      }
      const banker = view.players?.find((p) => p.isBanker);
      assert.equal(banker?.betting, null);
      assertNoFaceDownValues(view);
    } finally {
      socket.disconnect();
      await stopServer(io, http);
    }
  });
});
