import { describe, it, after } from "node:test";
import assert from "node:assert/strict";
import { createServer, type Server as HttpServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket as ClientSocket } from "socket.io-client";
import {
  setupGameHandlers,
  resetGameStateForTests,
  getGameHostForTests,
  getRoomSnapshotForTests,
  type ResumeStatus,
} from "./game.ts";
import { clearRoomTimers } from "../shared/gameEngine.ts";
import { DEFAULT_CHIPS } from "../shared/chips.ts";
import type { RoomView } from "../src/gameTypes.ts";

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";

/**
 * S1 · «Sortir» confirmat tanca la sessió de partida al servidor: després de `leave_room`,
 * `resume_status` ja no ofereix «Continuar la partida». Una desconnexió sense sortir
 * continua sent reprenible.
 */

type TestServer = { url: string; http: HttpServer; io: SocketIOServer };

async function startTestServer(): Promise<TestServer> {
  const http = createServer();
  const io = new SocketIOServer(http, { cors: { origin: "*" } });
  await setupGameHandlers(io);
  await new Promise<void>((resolve) => http.listen(0, "127.0.0.1", () => resolve()));
  const addr = http.address();
  const port = typeof addr === "object" && addr ? addr.port : 0;
  return { url: `http://127.0.0.1:${port}`, http, io };
}

async function stopTestServer(server: TestServer): Promise<void> {
  server.io.close();
  await new Promise<void>((resolve) => server.http.close(() => resolve()));
  resetGameStateForTests();
}

function connect(url: string): Promise<ClientSocket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.on("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.on("connect_error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

function queryResume(socket: ClientSocket, payload: Record<string, unknown>): Promise<ResumeStatus> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("resume_status timeout")), 10_000);
    socket.emit("resume_status", payload, (status: ResumeStatus) => {
      clearTimeout(timer);
      resolve(status);
    });
  });
}

function leaveRoom(
  socket: ClientSocket,
  roomId: string
): Promise<{ roomId: string; resumable: boolean; chips: number }> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("room_left timeout")), 10_000);
    socket.once("room_left", (payload: { roomId: string; resumable: boolean; chips: number }) => {
      clearTimeout(timer);
      resolve(payload);
    });
    socket.emit("leave_room", roomId);
  });
}

/** Atura els temporitzadors de la sala perquè la mà no avanci durant l'assert (sense canviar la lògica). */
function freezeRoom(roomId: string): void {
  const room = getRoomSnapshotForTests(roomId);
  assert.ok(room);
  clearRoomTimers(getGameHostForTests(), room!);
}

async function waitFor(cond: () => boolean, label: string): Promise<void> {
  const deadline = Date.now() + 5_000;
  while (!cond()) {
    if (Date.now() > deadline) throw new Error(`${label} timeout`);
    await new Promise((r) => setTimeout(r, 5));
  }
}

/** Entra en una partida solo i espera que la mà estigui en curs (fase diferent de «waiting»). */
function joinSoloMidHand(socket: ClientSocket, playerId: string, practiceMode: boolean): Promise<RoomView> {
  return new Promise((resolve, reject) => {
    let done = false;
    const timer = setTimeout(() => reject(new Error("mid-hand timeout")), 20_000);
    const finish = (room: RoomView) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      socket.off("room_update", onUpdate);
      resolve(room);
    };
    let joined: RoomView | null = null;
    const onUpdate = (room: RoomView) => {
      const me = room.players?.find((p) => !p.isBot);
      if (!me) return;
      if (room.phase !== "waiting" && room.phase !== "settlement" && joined) {
        finish({ ...room, soloResumeToken: joined.soloResumeToken });
        return;
      }
      if (room.phase === "betting" && me.status === "betting" && me.bet === 0) {
        socket.emit("place_bet", { roomId: room.id, amount: room.minBet ?? 100 });
      }
    };
    socket.once("joined_room", (room: RoomView) => {
      joined = room;
      if (room.phase !== "waiting" && room.phase !== "settlement") {
        finish(room);
        return;
      }
      socket.emit("place_bet", { roomId: room.id, amount: room.minBet ?? 100 });
    });
    socket.on("room_update", onUpdate);
    socket.emit("join_solo_room", { playerName: "SortirTest", playerId, botCount: 1, practiceMode });
  });
}

describe("S1 · Sortir tanca la sessió de partida", () => {
  after(() => resetGameStateForTests());

  for (const practiceMode of [false, true]) {
    const label = practiceMode ? "pràctica" : "normal";

    it(`solo ${label}: després de «Sortir» confirmat no hi ha partida per continuar`, async () => {
      const server = await startTestServer();
      const playerId = `s1sortir${practiceMode ? "prac" : "norm"}player01`;
      const socket = await connect(server.url);
      try {
        const room = await joinSoloMidHand(socket, playerId, practiceMode);
        assert.notEqual(room.phase, "waiting");
        freezeRoom(room.id);

        const before = await queryResume(socket, { playerId });
        assert.equal(before.solo, true, "a mitja partida hi ha sessió reprenible");
        assert.equal(before.soloPracticeMode, practiceMode);

        const left = await leaveRoom(socket, room.id);
        // `chips` és el saldo del vestíbul un cop tancada la sessió (#313). Aquí no queda
        // cap aposta retinguda: pràctica no toca el saldo, i la solo normal torna la compra sencera.
        assert.deepEqual(left, { roomId: room.id, resumable: false, chips: DEFAULT_CHIPS });

        const afterLeave = await queryResume(socket, { playerId });
        assert.equal(afterLeave.solo, false, "una sortida confirmada és definitiva");

        // Des d'una altra connexió (p. ex. recàrrega) tampoc no queda res per continuar.
        const other = await connect(server.url);
        try {
          const fromReload = await queryResume(other, { playerId });
          assert.equal(fromReload.solo, false);
        } finally {
          other.disconnect();
        }
      } finally {
        socket.disconnect();
        await stopTestServer(server);
      }
    });

    it(`solo ${label}: una desconnexió sense «Sortir» continua sent reprenible`, async () => {
      const server = await startTestServer();
      const playerId = `s1disc${practiceMode ? "prac" : "norm"}player01`;
      const socket1 = await connect(server.url);
      const room = await joinSoloMidHand(socket1, playerId, practiceMode);
      freezeRoom(room.id);
      socket1.disconnect();
      // El servidor processa la desconnexió: el seient passa a una IA amb el mateix playerId.
      await waitFor(
        () => getRoomSnapshotForTests(room.id)?.players.find((p) => p.playerId === playerId)?.isBot === true,
        "disconnect"
      );
      freezeRoom(room.id);

      const socket2 = await connect(server.url);
      try {
        const status = await queryResume(socket2, { playerId });
        assert.equal(status.solo, true);
        assert.equal(status.soloPracticeMode, practiceMode);

        const resumed = await new Promise<RoomView>((resolve, reject) => {
          const timer = setTimeout(() => reject(new Error("resume timeout")), 10_000);
          socket2.once("joined_room", (r: RoomView) => {
            clearTimeout(timer);
            resolve(r);
          });
          socket2.emit("join_solo_room", {
            playerName: "SortirTest",
            playerId,
            soloResumeToken: room.soloResumeToken,
            botCount: 1,
            practiceMode,
          });
        });
        assert.equal(resumed.id, room.id);
        assert.notEqual(resumed.phase, "waiting");
        assert.equal(resumed.practiceMode === true, practiceMode);
      } finally {
        socket2.disconnect();
        await stopTestServer(server);
      }
    });
  }

  it("taula privada: Sortir allibera el seient i una desconnexió el conserva", async () => {
    const server = await startTestServer();
    const hostId = "s1privhostplayer01";
    const host = await connect(server.url);
    try {
      const joined = await new Promise<RoomView>((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("create timeout")), 10_000);
        host.once("joined_room", (r: RoomView) => {
          clearTimeout(timer);
          resolve(r);
        });
        host.emit("create_private_table", { playerName: "Amfitrio", playerId: hostId });
      });
      assert.ok(joined.inviteCode);
      assert.ok(joined.viewerSeatToken);
      const seat = { playerId: hostId, inviteCode: joined.inviteCode, seatToken: joined.viewerSeatToken };

      const guestId = "s1privguestplayer01";
      const guest = await connect(server.url);
      const guestRoom = await new Promise<RoomView>((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("guest join timeout")), 10_000);
        guest.once("joined_room", (r: RoomView) => {
          clearTimeout(timer);
          resolve(r);
        });
        guest.emit("join_private_table", { inviteCode: joined.inviteCode, playerName: "Convidat", playerId: guestId });
      });
      const guestSeat = { playerId: guestId, inviteCode: joined.inviteCode, seatToken: guestRoom.viewerSeatToken };
      assert.equal((await queryResume(guest, guestSeat)).private, true);

      // Desconnexió accidental del convidat: el seient es conserva (gràcia).
      guest.disconnect();
      await waitFor(
        () =>
          getRoomSnapshotForTests(joined.id)?.players.find((p) => p.playerId === guestId)?.disconnectedAt !== undefined,
        "private disconnect"
      );
      assert.equal((await queryResume(host, guestSeat)).private, true);

      // Un token d'un altre jugador no confirma res.
      assert.equal((await queryResume(host, { ...guestSeat, playerId: hostId })).private, false);

      // Sortida confirmada de l'amfitrió fora de mà: seient alliberat.
      assert.equal((await queryResume(host, seat)).private, true);
      const left = await leaveRoom(host, joined.id);
      // Taula privada: les fitxes de taula no són el saldo real. El vestíbul rep el saldo, intacte.
      assert.deepEqual(left, { roomId: joined.id, resumable: false, chips: DEFAULT_CHIPS });
      assert.equal((await queryResume(host, seat)).private, false);
    } finally {
      host.disconnect();
      await stopTestServer(server);
    }
  });

  it("sense identitat vàlida no hi ha cap sessió", async () => {
    const server = await startTestServer();
    const socket = await connect(server.url);
    try {
      assert.deepEqual(await queryResume(socket, {}), { solo: false, soloPracticeMode: false, private: false });
      // També respon amb l'event, per a clients que no fan servir ack.
      const viaEvent = await new Promise<ResumeStatus>((resolve) => {
        socket.once("resume_status", resolve);
        socket.emit("resume_status", { playerId: "s1ningunplayer01" });
      });
      assert.equal(viaEvent.solo, false);
    } finally {
      socket.disconnect();
      await stopTestServer(server);
    }
  });
});
