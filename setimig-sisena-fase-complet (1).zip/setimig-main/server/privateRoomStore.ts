import fs from "fs/promises";
import path from "path";
import type { Room } from "../shared/gameEngine.ts";
import type { SessionStats } from "../src/gameTypes.ts";
import { isStaleSnapshot, retentionLimits } from "./dataRetention.ts";

function dataDir(): string {
  return process.env.BALANCE_DATA_DIR || path.join(process.cwd(), "data");
}

function storePath(): string {
  return path.join(dataDir(), "private-rooms.json");
}

type SerializedRoom = Omit<
  Room,
  | "sessionStats"
  | "roundStartChips"
  | "botTimer"
  | "humanTimer"
  | "settlementEndTimer"
  | "botWatchdogTimer"
  | "botTurnWatch"
  | "betsSettleTimer"
  | "actionHoldTimer"
  | "settlingInProgress"
> & {
  sessionStats: Record<string, SessionStats>;
  roundStartChips?: Record<string, number>;
  /** Darrera escriptura (ms); serveix per descartar taules abandonades. */
  persistedAt?: number;
};

interface PrivateRoomStoreFile {
  rooms: Record<string, SerializedRoom>;
  inviteIndex: Record<string, string>;
}

let cache: PrivateRoomStoreFile | null = null;
let writeChain: Promise<void> = Promise.resolve();

function emptyFile(): PrivateRoomStoreFile {
  return { rooms: {}, inviteIndex: {} };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

async function loadFile(): Promise<PrivateRoomStoreFile> {
  if (cache) return cache;

  let raw: string;
  try {
    raw = await fs.readFile(storePath(), "utf8");
  } catch (error) {
    if (error instanceof Error && "code" in error && error.code === "ENOENT") {
      cache = emptyFile();
      return cache;
    }
    throw error;
  }

  const parsed: unknown = JSON.parse(raw);
  if (!isRecord(parsed) || !isRecord(parsed.rooms) || !isRecord(parsed.inviteIndex)) {
    throw new Error("Invalid private room store format");
  }
  cache = {
    rooms: parsed.rooms as PrivateRoomStoreFile["rooms"],
    inviteIndex: parsed.inviteIndex as Record<string, string>,
  };
  return cache;
}

async function persistFile(file: PrivateRoomStoreFile): Promise<void> {
  cache = file;
  const p = storePath();
  await fs.mkdir(dataDir(), { recursive: true });
  const tmp = `${p}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(file, null, 2), "utf8");
  await fs.rename(tmp, p);
}

function enqueueWrite(task: () => Promise<void>): Promise<void> {
  writeChain = writeChain.then(task, task);
  return writeChain;
}

function offlineSocketId(seatToken: string): string {
  return `offline-${seatToken}`;
}

function serializeRoom(room: Room): SerializedRoom {
  const sessionStats: SerializedRoom["sessionStats"] = {};
  for (const [k, v] of room.sessionStats.entries()) {
    sessionStats[k] = v;
  }
  const roundStartChips: Record<string, number> | undefined = room.roundStartChips
    ? Object.fromEntries(room.roundStartChips.entries())
    : undefined;

  const {
    botTimer: _bt,
    humanTimer: _ht,
    settlementEndTimer: _st,
    botWatchdogTimer: _bw,
    botTurnWatch: _btw,
    betsSettleTimer: _bst,
    actionHoldTimer: _aht,
    settlingInProgress: _sip,
    sessionStats: _ss,
    roundStartChips: _rc,
    ...rest
  } = room;
  return {
    ...rest,
    players: room.players.map((p) => ({
      ...p,
      id: offlineSocketId(p.seatToken),
    })),
    sessionStats,
    roundStartChips,
    persistedAt: Date.now(),
  };
}

function deserializeRoom(stored: SerializedRoom): Room {
  const { persistedAt: _pa, ...raw } = stored;
  const sessionStats = new Map<string, SessionStats>(Object.entries(raw.sessionStats ?? {}));
  const roundStartChips = raw.roundStartChips
    ? new Map(Object.entries(raw.roundStartChips))
    : undefined;

  return {
    ...raw,
    botTimer: null,
    humanTimer: null,
    settlementEndTimer: null,
    botWatchdogTimer: null,
    botTurnWatch: null,
    betsSettleTimer: null,
    actionHoldTimer: null,
    sessionStats,
    roundStartChips,
    players: raw.players.map((p) => ({
      ...p,
      id: offlineSocketId(p.seatToken),
    })),
  };
}

/** Descarta taules sense escriptures des de fa més del TTL (i els seus codis d'invitació). */
async function pruneStalePrivateRooms(file: PrivateRoomStoreFile, now = Date.now()): Promise<string[]> {
  const ttl = retentionLimits().privateRoomTtlMs;
  const removed: string[] = [];
  for (const [roomId, room] of Object.entries(file.rooms)) {
    if (isStaleSnapshot(room.persistedAt, now, ttl)) {
      delete file.rooms[roomId];
      removed.push(roomId);
    }
  }
  if (removed.length === 0) return removed;
  const gone = new Set(removed);
  for (const [code, roomId] of Object.entries(file.inviteIndex)) {
    if (gone.has(roomId)) delete file.inviteIndex[code];
  }
  await enqueueWrite(() => persistFile(file));
  return removed;
}

export async function loadAllPrivateRooms(): Promise<{ rooms: Room[]; inviteIndex: Map<string, string> }> {
  const file = await loadFile();
  await pruneStalePrivateRooms(file);
  const rooms: Room[] = [];
  for (const serialized of Object.values(file.rooms)) {
    if (!serialized.isPrivate) continue;
    rooms.push(deserializeRoom(serialized));
  }
  return { rooms, inviteIndex: new Map(Object.entries(file.inviteIndex)) };
}

export async function persistPrivateRoomSnapshot(room: Room): Promise<void> {
  if (!room.isPrivate) return;
  await enqueueWrite(async () => {
    const file = await loadFile();
    file.rooms[room.id] = serializeRoom(room);
    if (room.inviteCode) {
      file.inviteIndex[room.inviteCode] = room.id;
    }
    await persistFile(file);
  });
}

export async function removePrivateRoomFromStore(roomId: string, inviteCode?: string): Promise<void> {
  await enqueueWrite(async () => {
    const file = await loadFile();
    delete file.rooms[roomId];
    if (inviteCode) delete file.inviteIndex[inviteCode];
    await persistFile(file);
  });
}

/** @internal Test helper: wait until queued room-store writes finish. */
export async function flushPrivateRoomStoreWritesForTests(): Promise<void> {
  let pending = writeChain;
  while (true) {
    await pending;
    if (pending === writeChain) return;
    pending = writeChain;
  }
}

export function resetPrivateRoomStoreCacheForTests(): void {
  cache = null;
}

export { offlineSocketId };
