import fs from "node:fs";
import path from "node:path";
import { analyticsDir, analyticsSaltKnown, deleteAnalyticsForPlayer, pseudonymousId } from "./analytics.ts";
import { deleteEngagement, removeFromWeeklyLeaderboards } from "./achievementsStore.ts";
import { deleteIdentitiesForPlayer, identityStorePath } from "./auth/identityStore.ts";
import { deleteBalanceAccount, sanitizePlayerId } from "./balances.ts";
import { deleteCampaignProgress } from "./campaignProgress.ts";
import { deletedAccountsPath, isAccountDeleted, markAccountDeleted } from "./deletedAccounts.ts";
import { deleteFriendsForPlayer } from "./friends/friendsStore.ts";
import { deletePlayerStats } from "./playerStats.ts";
import { deleteProfile } from "./profiles.ts";
import { forgetSoloIsolatedSession } from "./soloIsolatedSessions.ts";

/**
 * Esborrat de compte oficial. El fan servir l'endpoint POST /api/account/delete (servidor en
 * marxa) i scripts/delete-account.ts (servidor aturat): la MATEIXA funció `deleteAccount`, que
 * passa per les funcions de cada magatzem (amb les seves cues d'escriptura i memòria cau), mai
 * editant els JSON pel seu compte.
 *
 * Ordre: primer es marca el compte com a esborrat (data/deleted-accounts.json, només el hash),
 * de manera que tots els tokens i el playerId antic deixen de valer abans de tocar res més.
 * Idempotent: tornar-ho a executar no canvia res.
 *
 * S'esborra: perfil, saldo i compres d'entrada solo obertes, identitats (correus, Google, passkeys),
 * estadístiques i historial (són només del jugador), assoliments/missions, campanya, amics (i la
 * seva presència a les llistes dels altres), rànquings setmanals (només la seva entrada),
 * marca de partida solo i analítica (pseudònima). Les taules privades només s'informen: caduquen soles.
 */

function dataDir(): string {
  return process.env.BALANCE_DATA_DIR || path.join(process.cwd(), "data");
}
function profilesDir(): string {
  return process.env.PROFILE_DATA_DIR || path.join(process.cwd(), "data", "profiles");
}
function friendsFile(): string {
  return path.join(process.env.FRIENDS_DATA_DIR || process.env.BALANCE_DATA_DIR || path.join(process.cwd(), "data"), "friends.json");
}

function readJson(file: string): any | null {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch {
    return null;
  }
}
function isRecord(v: unknown): v is Record<string, any> {
  return v !== null && typeof v === "object" && !Array.isArray(v);
}

export function maskEmailForReport(email: string): string {
  const [user = "", domain = ""] = email.split("@");
  return `${user.slice(0, 1)}***@${domain}`;
}

export type AccountInventory = {
  playerId: string;
  alreadyDeleted: boolean;
  displayName: string | null;
  items: string[];
  /** Fitxers existents que l'esborrat pot modificar (per a la còpia de seguretat). */
  files: string[];
  info: string[];
};

/** Només lectura: què hi ha d'aquest compte i què s'esborraria. */
export async function inspectAccount(playerIdRaw: unknown): Promise<AccountInventory> {
  const playerId = sanitizePlayerId(playerIdRaw);
  if (!playerId) throw new Error("playerId no vàlid");
  const inv: AccountInventory = { playerId, alreadyDeleted: isAccountDeleted(playerId), displayName: null, items: [], files: [], info: [] };
  const touch = (file: string) => {
    if (fs.existsSync(file) && !inv.files.includes(file)) inv.files.push(file);
  };
  touch(deletedAccountsPath());

  const profileFile = path.join(profilesDir(), `${playerId}.json`);
  const profile = readJson(profileFile);
  if (profile) {
    inv.displayName = typeof profile.displayName === "string" ? profile.displayName : null;
    inv.items.push(`perfil («${inv.displayName ?? "?"}»)`);
    touch(profileFile);
  }

  const balancesFile = path.join(dataDir(), "balances.json");
  const balances = readJson(balancesFile);
  if (isRecord(balances?.accounts) && playerId in balances.accounts) {
    inv.items.push(`saldo: ${balances.accounts[playerId]?.chips} fitxes`);
    touch(balancesFile);
  }
  const open = Object.values(isRecord(balances?.openSoloBuyIns) ? balances.openSoloBuyIns : {}).filter(
    (e: any) => e?.playerId === playerId,
  ).length;
  if (open) {
    inv.items.push(`compres d'entrada solo obertes: ${open}`);
    touch(balancesFile);
  }

  const ids = readJson(identityStorePath());
  if (ids) {
    const emails = Object.entries(isRecord(ids.emails) ? ids.emails : {}).filter(([, p]) => p === playerId).map(([e]) => e);
    const google = Object.values(isRecord(ids.google) ? ids.google : {}).filter((p) => p === playerId).length;
    const passkeys = Object.values(isRecord(ids.passkeys) ? ids.passkeys : {}).filter((p: any) => p?.playerId === playerId).length;
    const player = isRecord(ids.players) && playerId in ids.players;
    const log = (Array.isArray(ids.log) ? ids.log : []).filter((e: any) => e?.playerId === playerId || e?.fromPlayerId === playerId).length;
    if (emails.length) inv.items.push(`correus verificats: ${emails.map(maskEmailForReport).join(", ")}`);
    if (google) inv.items.push(`Google: ${google}`);
    if (passkeys) inv.items.push(`passkeys: ${passkeys}`);
    if (player) inv.items.push("metadades d'identitat");
    if (log) inv.items.push(`entrades del registre d'inici de sessió: ${log}`);
    if (emails.length || google || passkeys || player || log) touch(identityStorePath());
  }

  for (const [dir, label] of [
    ["player-stats", "estadístiques i historial"],
    ["player-engagement", "assoliments/missions"],
    ["campaign-progress", "campanya"],
  ] as const) {
    const file = path.join(dataDir(), dir, `${playerId}.json`);
    if (fs.existsSync(file)) {
      inv.items.push(label);
      touch(file);
    }
  }
  const legacyFile = path.join(dataDir(), "player-stats-aggregate.json");
  const legacy = readJson(legacyFile);
  if (isRecord(legacy?.players) && playerId in legacy.players) {
    inv.items.push("agregat antic d'estadístiques");
    touch(legacyFile);
  }

  const weeklyDir = path.join(dataDir(), "weekly-leaderboard");
  if (fs.existsSync(weeklyDir)) {
    for (const f of fs.readdirSync(weeklyDir).filter((x) => x.endsWith(".json")).sort()) {
      const file = path.join(weeklyDir, f);
      const w = readJson(file);
      if (isRecord(w?.chipsWon) && playerId in w.chipsWon) {
        inv.items.push(`rànquing ${f.slice(0, -5)}: ${w.chipsWon[playerId]} (només la seva entrada)`);
        touch(file);
      }
    }
  }

  const friends = readJson(friendsFile());
  if (isRecord(friends?.players)) {
    const own = playerId in friends.players;
    const refs = Object.entries(friends.players).filter(
      ([pid, rec]: [string, any]) => pid !== playerId && Array.isArray(rec?.friendPlayerIds) && rec.friendPlayerIds.includes(playerId),
    ).length;
    if (own) inv.items.push("registre d'amics i codi d'amic");
    if (refs) inv.items.push(`present a la llista d'amics de ${refs} jugadors (se'l treu)`);
    if (own || refs) touch(friendsFile());
  }

  const soloFile = path.join(dataDir(), "solo-isolated-sessions.json");
  const solo = readJson(soloFile);
  if (isRecord(solo?.sessions) && playerId in solo.sessions) {
    inv.items.push("marca de partida solo");
    touch(soloFile);
  }

  const priv = readJson(path.join(dataDir(), "private-rooms.json"));
  if (isRecord(priv?.rooms)) {
    for (const [roomId, room] of Object.entries(priv.rooms) as [string, any][]) {
      const seats = Array.isArray(room?.players) ? room.players : [];
      if (seats.some((p: any) => p?.playerId === playerId)) {
        inv.info.push(`taula privada ${room?.inviteCode ?? roomId}: no es toca (caduca pel TTL)`);
      }
    }
  }

  if (analyticsSaltKnown()) {
    const pid = await pseudonymousId(playerId);
    const dir = analyticsDir();
    let lines = 0;
    for (const f of fs.existsSync(dir) ? fs.readdirSync(dir).filter((x) => x.endsWith(".jsonl")) : []) {
      const file = path.join(dir, f);
      const n = fs.readFileSync(file, "utf8").split("\n").filter((l) => l.includes(`"pid":"${pid}"`)).length;
      if (n) {
        lines += n;
        touch(file);
      }
    }
    if (lines) inv.items.push(`analítica (pseudònima): ${lines} esdeveniments`);
  } else {
    inv.info.push("analítica: sense sal coneguda (SETIMIG_ANALYTICS_SALT o .salt); no s'hi toca");
  }
  return inv;
}

export type AccountDeletionReport = {
  playerId: string;
  /** false si ja estava esborrat (idempotent). */
  newlyDeleted: boolean;
  balance: { chips: number | null; openSoloBuyIns: number };
  identities: { emails: number; google: number; passkeys: number; player: boolean; log: number };
  profile: boolean;
  stats: { file: boolean; legacy: boolean };
  engagement: boolean;
  campaign: boolean;
  weeklyLeaderboards: string[];
  friends: { own: boolean; codes: number; refs: number };
  soloSession: boolean;
  analyticsEvents: number | null;
};

/** Esborra el compte (vegeu la capçalera). Idempotent. */
export async function deleteAccount(playerIdRaw: unknown): Promise<AccountDeletionReport> {
  const playerId = sanitizePlayerId(playerIdRaw);
  if (!playerId) throw new Error("playerId no vàlid");
  // 1) Primer de tot: tokens i playerId antic deixen de valer.
  const newlyDeleted = await markAccountDeleted(playerId);
  // 2) Dades, cadascuna pel seu magatzem.
  const balance = await deleteBalanceAccount(playerId);
  const identities = await deleteIdentitiesForPlayer(playerId);
  const profile = await deleteProfile(playerId);
  const stats = await deletePlayerStats(playerId);
  const engagement = await deleteEngagement(playerId);
  const campaign = await deleteCampaignProgress(playerId);
  const weeklyLeaderboards = await removeFromWeeklyLeaderboards(playerId);
  const friends = await deleteFriendsForPlayer(playerId);
  const soloSession = await forgetSoloIsolatedSession(playerId);
  const analyticsEvents = analyticsSaltKnown() ? await deleteAnalyticsForPlayer(playerId) : null;
  return {
    playerId,
    newlyDeleted,
    balance,
    identities,
    profile,
    stats,
    engagement,
    campaign,
    weeklyLeaderboards,
    friends,
    soloSession,
    analyticsEvents,
  };
}
