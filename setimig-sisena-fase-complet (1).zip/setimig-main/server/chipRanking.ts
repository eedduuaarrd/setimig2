import fs from "fs/promises";
import path from "path";
import type { Request, Response } from "express";
import { listBalanceChips, getBalance } from "./balances.ts";
import { isBotId } from "./bots.ts";
import { isAccountDeleted } from "./deletedAccounts.ts";
import { sendAuthRequired } from "./requireLogin.ts";
import { getProfile, normalizeDisplayName } from "./profiles.ts";

/**
 * Rànquing públic per saldo de fitxes (GET /api/ranking).
 *
 * No reaprofita `getWeeklyLeaderboardView`: aquell rànquing és de fitxes guanyades
 * durant la setmana i inclou `playerId`. Aquí es reaprofita el patró (top + posició
 * de qui consulta, empat determinista). La resposta només porta nom visible, fitxes
 * i posició.
 *
 * Exclusions, només aquestes (filtre propi; no es fa servir `isTestIdentity`):
 * - Bot: `isBotId` (id que comença per `bot:`, server/bots.ts) o id que comença per
 *   `bot-` (el mateix tall que analytics.ts, handStatsRecorder.ts i campaignMatch.ts).
 * - Id de prova: `/(^|[-_])(test|e2e|audit|smoke)/i`. El nom visible no compta:
 *   ni «edu», ni «qa», ni cap altre prefix, ni `SETIMIG_ANALYTICS_TEST_NAME_RE`,
 *   ni `SETIMIG_ANALYTICS_ALL_TEST`. Això continua sent feina d'`isTestIdentity`
 *   per a la resta de l'app.
 * - Esborrat: `isAccountDeleted` (sha256 a data/deleted-accounts.json, server/deletedAccounts.ts).
 * - Ocult: `data/ranking-hidden.json` (el mateix directori que `balances.json`),
 *   `{"playerIds": ["<id>", ...]}`. Només es llegeix. Si el fitxer no existeix o el
 *   JSON no és vàlid, no s'amaga ningú i la petició no falla. Un id de la llista
 *   no surt al top ni té posició pròpia (`me.rank` null). No s'esborra el compte
 *   ni se'n toca el saldo. Vegeu docs/ranquing-ocult.md.
 *
 * Empats: més fitxes primer; a igualtat, `localeCompare` del nom en català; si el nom
 * també coincideix, playerId ascendent. La posició és 1-based i única (no es comparteix).
 * El playerId només serveix per ordenar: no surt a la resposta.
 */

/** Mateix patró d'id que la meitat d'id d'`isTestIdentity`, sense mirar el nom. */
const RANKING_TEST_ID_RE = /(^|[-_])(test|e2e|audit|smoke)/i;
export const CHIP_RANKING_LIMIT = 50;

export type ChipRankingEntry = {
  rank: number;
  displayName: string;
  chips: number;
};

export type ChipRankingMe = {
  rank: number | null;
  displayName: string;
  chips: number;
  inTop: boolean;
};

export type ChipRankingView = {
  entries: ChipRankingEntry[];
  me: ChipRankingMe;
  totalPlayers: number;
};

type Row = { playerId: string; displayName: string; chips: number };

export function isBotPlayerId(playerId: string): boolean {
  return isBotId(playerId) || playerId.startsWith("bot-");
}

/** Id de prova per al rànquing. No consulta el nom ni les variables d'analítica. */
export function isRankingTestPlayerId(playerId: string): boolean {
  return RANKING_TEST_ID_RE.test(playerId);
}

/** Directori de dades del rànquing: el de `balances.json` (`data/` si no hi ha `BALANCE_DATA_DIR`). */
export function rankingHiddenFilePath(): string {
  const dir = process.env.BALANCE_DATA_DIR || path.join(process.cwd(), "data");
  return path.join(dir, "ranking-hidden.json");
}

/**
 * Ids a amagar. Només lectura. Fitxer absent, il·legible o JSON invàlid → conjunt buit
 * (no s'amaga ningú i no es llança). No crea ni reescriu el fitxer.
 */
export async function loadHiddenRankingIds(): Promise<Set<string>> {
  let raw: string;
  try {
    raw = await fs.readFile(rankingHiddenFilePath(), "utf8");
  } catch {
    return new Set();
  }
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return new Set();
    const ids = (parsed as { playerIds?: unknown }).playerIds;
    if (!Array.isArray(ids)) return new Set();
    const hidden = new Set<string>();
    for (const id of ids) {
      if (typeof id !== "string") continue;
      const trimmed = id.trim();
      if (trimmed) hidden.add(trimmed);
    }
    return hidden;
  } catch {
    return new Set();
  }
}

/**
 * Cert si el compte no ha d'aparèixer al rànquing de fitxes.
 * Bot, id de prova, compte esborrat, o id llistat a `ranking-hidden.json`.
 * El nom visible no exclou ningú. Sense el conjunt d'ocults, aquests no compten
 * (el conjunt el carrega `getChipRankingView`).
 */
export function isExcludedFromChipRanking(playerId: string, hiddenIds?: ReadonlySet<string>): boolean {
  return (
    isBotPlayerId(playerId) ||
    isAccountDeleted(playerId) ||
    isRankingTestPlayerId(playerId) ||
    (hiddenIds?.has(playerId) ?? false)
  );
}

/** Ordre total: fitxes desc., nom (ca), playerId. Estable i determinista. */
export function compareChipRanking(a: Row, b: Row): number {
  if (b.chips !== a.chips) return b.chips - a.chips;
  const byName = a.displayName.localeCompare(b.displayName, "ca");
  if (byName !== 0) return byName;
  if (a.playerId < b.playerId) return -1;
  if (a.playerId > b.playerId) return 1;
  return 0;
}

async function visibleName(playerId: string): Promise<string> {
  try {
    const profile = await getProfile(playerId);
    return normalizeDisplayName(profile?.displayName);
  } catch {
    return "Jugador";
  }
}

async function mapPool<T, R>(items: T[], limit: number, fn: (item: T) => Promise<R>): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let cursor = 0;
  const workers = Math.min(limit, items.length);
  async function worker(): Promise<void> {
    for (;;) {
      const i = cursor++;
      if (i >= items.length) return;
      out[i] = await fn(items[i]!);
    }
  }
  if (workers === 0) return out;
  await Promise.all(Array.from({ length: workers }, () => worker()));
  return out;
}

function publicEntry(row: Row, rank: number): ChipRankingEntry {
  return { rank, displayName: row.displayName, chips: row.chips };
}

export async function getChipRankingView(viewerPlayerId: string): Promise<ChipRankingView> {
  const hiddenIds = await loadHiddenRankingIds();
  const listed = await listBalanceChips();
  const named = await mapPool(listed, 32, async (row) => {
    if (isExcludedFromChipRanking(row.playerId, hiddenIds)) return null;
    return { playerId: row.playerId, displayName: await visibleName(row.playerId), chips: row.chips };
  });

  const rows: Row[] = [];
  for (const row of named) if (row) rows.push(row);

  const viewerExcluded = isExcludedFromChipRanking(viewerPlayerId, hiddenIds);
  let viewer = rows.find((row) => row.playerId === viewerPlayerId) ?? null;
  if (!viewer && !viewerExcluded) {
    viewer = {
      playerId: viewerPlayerId,
      displayName: await visibleName(viewerPlayerId),
      chips: await getBalance(viewerPlayerId),
    };
    rows.push(viewer);
  }

  rows.sort(compareChipRanking);
  const ranked = rows.map((row, index) => ({ row, rank: index + 1 }));
  const top = ranked.slice(0, CHIP_RANKING_LIMIT);

  const viewerRanked = viewer ? ranked.find((item) => item.row.playerId === viewerPlayerId) ?? null : null;
  const inTop = viewerRanked != null && viewerRanked.rank <= CHIP_RANKING_LIMIT;
  const me: ChipRankingMe = viewerRanked
    ? {
        rank: viewerRanked.rank,
        displayName: viewerRanked.row.displayName,
        chips: viewerRanked.row.chips,
        inTop,
      }
    : {
        rank: null,
        displayName: await visibleName(viewerPlayerId),
        chips: await getBalance(viewerPlayerId),
        inTop: false,
      };

  return {
    entries: top.map((item) => publicEntry(item.row, item.rank)),
    me,
    totalPlayers: ranked.length,
  };
}

type AccountRequest = Request & { accountPlayerId?: string };

/** GET /api/ranking. El 401 el posa requireLogin; aquí es torna a comprovar la sessió. */
export async function handleGetRanking(req: Request, res: Response): Promise<void> {
  const playerId = (req as AccountRequest).accountPlayerId;
  if (!playerId) {
    sendAuthRequired(res);
    return;
  }
  try {
    res.json(await getChipRankingView(playerId));
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Error desconegut";
    console.error("[api]", req.path, message);
    res.status(500).json({ error: "Error intern. Torna-ho a provar." });
  }
}
