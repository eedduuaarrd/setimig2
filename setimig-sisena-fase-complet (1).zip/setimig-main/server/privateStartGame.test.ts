import { describe, it, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";
import fs from "fs/promises";
import os from "os";
import path from "path";
import { createServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket } from "socket.io-client";
import { resetGameStateForTests, setupGameHandlers } from "./game.ts";
import { issuePlayerToken } from "./playerToken.ts";
import {
  flushPrivateRoomStoreWritesForTests,
  resetPrivateRoomStoreCacheForTests,
} from "./privateRoomStore.ts";

const HOST_ID = "privstarthost000001";
const GUEST_ID = "privstartguest00001";

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";

function connect(url: string): Promise<Socket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.on("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.on("connect_error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

function waitJoined(socket: Socket): Promise<{
  id: string;
  inviteCode?: string;
  viewerSeatToken?: string;
  phase?: string;
  playerToken?: string;
  minBet?: number;
  tableMaxBet?: number;
  players?: { chips: number }[];
}> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("join timeout")), 15_000);
    socket.once("joined_room", (room) => {
      clearTimeout(timer);
      resolve(room);
    });
  });
}

async function startServer(): Promise<{
  url: string;
  http: ReturnType<typeof createServer>;
  io: SocketIOServer;
}> {
  const http = createServer();
  const io = new SocketIOServer(http, { cors: { origin: "*" } });
  await setupGameHandlers(io);
  await new Promise<void>((r) => http.listen(0, "127.0.0.1", () => r()));
  const port = (http.address() as { port: number }).port;
  return { url: `http://127.0.0.1:${port}`, http, io };
}

async function stopServer(io: SocketIOServer, http: ReturnType<typeof createServer>) {
  io.close();
  await new Promise<void>((r) => http.close(() => r()));
}

function waitRoomPlayerCount(socket: Socket, count: number, timeoutMs = 15_000): Promise<void> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`player count ${count} timeout`)), timeoutMs);
    const onUpdate = (room: { players?: unknown[] }) => {
      if (room.players?.length === count) {
        clearTimeout(timer);
        socket.off("room_update", onUpdate);
        resolve();
      }
    };
    socket.on("room_update", onUpdate);
  });
}

function waitPhase(socket: Socket, phase: string, timeoutMs = 45_000): Promise<void> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`phase ${phase} timeout`)), timeoutMs);
    const onUpdate = (room: { phase: string }) => {
      if (room.phase === phase) {
        clearTimeout(timer);
        socket.off("room_update", onUpdate);
        resolve();
      }
    };
    socket.on("room_update", onUpdate);
  });
}

describe("private table start_game (production payloads)", () => {
  let dataDir: string;

  beforeEach(async () => {
    dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "setimig-priv-start-"));
    process.env.BALANCE_DATA_DIR = dataDir;
    process.env.SETIMIG_TEST_FAST = "1";
    resetGameStateForTests();
    resetPrivateRoomStoreCacheForTests();
  });

  afterEach(async () => {
    delete process.env.SETIMIG_TEST_FAST;
    resetGameStateForTests();
    await flushPrivateRoomStoreWritesForTests();
    await fs.rm(dataDir, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 });
  });

  it("rejects malformed socket payloads and keeps the connection usable", async () => {
    const { url, http, io } = await startServer();
    const host = await connect(url);
    try {
      const events = [
        "create_private_table",
        "join_private_table",
        "fill_private_bots",
        "join_solo_room",
        "quick_rematch",
        "reset_session",
        "start_game",
        "place_bet",
        "double_bet",
        "mort_action",
        "split_hands",
        "flip_card",
        "hit",
        "stand",
        "bank_keep_choice",
        "send_message",
        "send_emote",
        "leave_room",
      ];

      for (const event of events) {
        const errorPromise = new Promise<{ code?: string }>((resolve, reject) => {
          const timeout = setTimeout(() => {
            host.off("game_error", onError);
            reject(new Error(`${event} did not reject its malformed payload`));
          }, 3_000);
          const onError = (error: { code?: string }) => {
            clearTimeout(timeout);
            resolve(error);
          };
          host.once("game_error", onError);
        });
        host.emit(event, null);
        const error = await errorPromise;
        assert.equal(error.code, "BAD_PAYLOAD", event);
      }

      const joinedPromise = waitJoined(host);
      host.emit("create_private_table", { playerName: "Host", playerId: HOST_ID });
      await joinedPromise;
    } finally {
      host.disconnect();
      await stopServer(io, http);
    }
  });

  it("rejects malformed chat fields without broadcasting and keeps the connection usable", async () => {
    const { url, http, io } = await startServer();
    const host = await connect(url);
    let guest: Socket | null = null;
    try {
      const hostJoined = waitJoined(host);
      host.emit("create_private_table", { playerName: "Host", playerId: HOST_ID });
      const hostRoom = await hostJoined;
      assert.ok(hostRoom.inviteCode);

      guest = await connect(url);
      const guestJoined = waitJoined(guest);
      guest.emit("join_private_table", {
        inviteCode: hostRoom.inviteCode,
        playerName: "Guest",
        playerId: GUEST_ID,
      });
      await guestJoined;

      const hostMessages: { sender?: string; text?: string }[] = [];
      const guestMessages: { sender?: string; text?: string }[] = [];
      host.on("new_message", (message) => hostMessages.push(message));
      guest.on("new_message", (message) => guestMessages.push(message));

      const malformedPayloads = [
        { roomId: hostRoom.id, message: 17 },
        { roomId: hostRoom.id, message: { text: "not a string" } },
        { roomId: hostRoom.id, message: ["not a string"] },
        { roomId: 17, message: "valid text" },
      ];

      for (const payload of malformedPayloads) {
        const errorPromise = new Promise<{ code?: string; message?: string }>((resolve, reject) => {
          const timeout = setTimeout(() => {
            host.off("game_error", onError);
            reject(new Error("malformed chat payload did not return BAD_PAYLOAD"));
          }, 3_000);
          const onError = (error: { code?: string; message?: string }) => {
            clearTimeout(timeout);
            resolve(error);
          };
          host.once("game_error", onError);
        });
        host.emit("send_message", payload);
        const error = await errorPromise;
        assert.equal(error.code, "BAD_PAYLOAD");
        assert.equal(error.message, "Sol·licitud invàlida.");
        assert.deepEqual(hostMessages, []);
        assert.deepEqual(guestMessages, []);
      }

      const validMessagePromise = new Promise<{ sender?: string; text?: string }>((resolve, reject) => {
        const timeout = setTimeout(() => {
          guest.off("new_message", onMessage);
          reject(new Error("valid chat message was not broadcast"));
        }, 3_000);
        const onMessage = (message: { sender?: string; text?: string }) => {
          clearTimeout(timeout);
          resolve(message);
        };
        guest!.once("new_message", onMessage);
      });
      const hostToken = issuePlayerToken(HOST_ID)!;
      host.emit("send_message", {
        roomId: hostRoom.id,
        message: "  Valid chat  ",
        playerToken: hostToken,
      });
      const validMessage = await validMessagePromise;
      assert.equal(validMessage.sender, "Host");
      assert.equal(validMessage.text, "Valid chat");
      assert.deepEqual(hostMessages, [validMessage]);
      assert.deepEqual(guestMessages, [validMessage]);
    } finally {
      guest?.disconnect();
      host.disconnect();
      await stopServer(io, http);
    }
  });

  it("keeps the default wager range for legacy private-table create payloads", async () => {
    const { url, http, io } = await startServer();
    const host = await connect(url);
    const joinedPromise = waitJoined(host);
    host.emit("create_private_table", { playerName: "Host", playerId: HOST_ID });
    const room = await joinedPromise;
    assert.equal(room.minBet, 100);
    assert.equal(room.tableMaxBet, 1_000);
    host.disconnect();
    await stopServer(io, http);
  });

  it("keeps guests within the seven seats funded for the configured maximum", async () => {
    const { url, http, io } = await startServer();
    const host = await connect(url);
    const joinedPromise = waitJoined(host);
    host.emit("create_private_table", {
      playerName: "Host",
      playerId: HOST_ID,
      minBet: 200,
      maxBet: 550,
    });
    const room = await joinedPromise;
    const fullPromise = waitRoomPlayerCount(host, 7);
    host.emit("fill_private_bots", room.id);
    await fullPromise;

    const guest = await connect(url);
    const errorPromise = new Promise<{ code?: string }>((resolve) => guest.once("game_error", resolve));
    guest.emit("join_private_table", {
      inviteCode: room.inviteCode,
      playerName: "Guest",
      playerId: GUEST_ID,
    });
    const error = await errorPromise;
    assert.equal(error.code, "ROOM_FULL");
    guest.disconnect();
    host.disconnect();
    await stopServer(io, http);
  });

  it("rejects reversed creator-selected wager limits", async () => {
    const { url, http, io } = await startServer();
    const host = await connect(url);
    const errorPromise = new Promise<{ code?: string }>((resolve) => host.once("game_error", resolve));
    host.emit("create_private_table", {
      playerName: "Host",
      playerId: HOST_ID,
      minBet: 600,
      maxBet: 500,
    });
    const error = await errorPromise;
    assert.equal(error.code, "BAD_BET_LIMITS");
    host.disconnect();
    await stopServer(io, http);
  });

  it("host starts with legacy string payload after guest joins by invite code", async () => {
    const { url, http, io } = await startServer();
    const host = await connect(url);
    host.emit("create_private_table", {
      playerName: "Host",
      playerId: HOST_ID,
      minBet: 200,
      maxBet: 550,
    });
    const hostRoom = await waitJoined(host);
    assert.ok(hostRoom.inviteCode);
    assert.equal(hostRoom.minBet, 200);
    assert.equal(hostRoom.tableMaxBet, 550);

    const guest = await connect(url);
    guest.emit("join_private_table", {
      inviteCode: hostRoom.inviteCode,
      playerName: "Guest",
      playerId: GUEST_ID,
    });
    const guestRoom = await waitJoined(guest);
    assert.equal(guestRoom.minBet, 200);
    assert.equal(guestRoom.tableMaxBet, 550);

    let gameError: { message?: string } | null = null;
    host.once("game_error", (err) => {
      gameError = err;
    });

    host.emit("start_game", hostRoom.id);

    await waitPhase(host, "betting");
    await waitPhase(guest, "betting");
    assert.equal(gameError, null);

    host.disconnect();
    guest.disconnect();
    await stopServer(io, http);
  });

  it("host reconnects before start and can still start without signed token on emit", async () => {
    const hostToken = issuePlayerToken(HOST_ID)!;
    const { url, http, io } = await startServer();
    const host = await connect(url);
    host.emit("create_private_table", {
      playerName: "Host",
      playerId: HOST_ID,
      playerToken: hostToken,
    });
    const hostRoom = await waitJoined(host);
    const hostSeat = hostRoom.viewerSeatToken!;
    assert.ok(hostRoom.inviteCode);

    const guest = await connect(url);
    guest.emit("join_private_table", {
      inviteCode: hostRoom.inviteCode,
      playerName: "Guest",
      playerId: GUEST_ID,
    });
    await waitJoined(guest);

    host.disconnect();
    await new Promise((r) => setTimeout(r, 200));

    const host2 = await connect(url);
    host2.emit("join_private_table", {
      inviteCode: hostRoom.inviteCode,
      playerName: "Host",
      playerId: HOST_ID,
      playerToken: hostToken,
      seatToken: hostSeat,
    });
    await waitJoined(host2);

    let gameError: { message?: string } | null = null;
    host2.once("game_error", (err) => {
      gameError = err;
    });
    host2.emit("start_game", hostRoom.id);

    await waitPhase(guest, "betting");
    assert.equal(gameError, null);

    host2.disconnect();
    guest.disconnect();
    await stopServer(io, http);
  });
});
