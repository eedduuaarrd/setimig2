import assert from "node:assert/strict";
import { createHmac } from "node:crypto";
import { after, before, describe, it } from "node:test";
import { existsSync, mkdtempSync, mkdirSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { createServer, type Server } from "node:http";
import os from "node:os";
import path from "node:path";
import express from "express";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient } from "socket.io-client";

const dataDir = mkdtempSync(path.join(os.tmpdir(), "setimig-logout-"));
process.env.BALANCE_DATA_DIR = dataDir;
process.env.PROFILE_DATA_DIR = path.join(dataDir, "profiles");
process.env.PLAYER_TOKEN_SECRET = "test-logout-revoca-secret";

const { loginWithIdentity } = await import("./auth/identityStore.ts");
const { issuePlayerToken, verifyPlayerToken } = await import("./playerToken.ts");
const { handleRenewPlayerSession } = await import("./httpPlayerAuth.ts");
const { registerAuthRoutes } = await import("./auth/authRoutes.ts");
const { requireLoginMiddleware, registerSocketLoginGate } = await import("./requireLogin.ts");
const { sessionCookieMiddleware, SESSION_COOKIE } = await import("./sessionCookie.ts");
const { mountStaticDist } = await import("./staticAssets.ts");
const { revokedTokensPath, resetRevokedTokensCacheForTests, hashToken } = await import("./revokedTokens.ts");

const A = "logoutacct0000000000000000000000000000001";
const B = "logoutacct0000000000000000000000000000002";

function connect(base: string, token: string): Promise<string> {
  return new Promise((resolve) => {
    const s = ioClient(base, { auth: { token }, transports: ["websocket"], reconnection: false });
    s.on("connect", () => { s.close(); resolve("ok"); });
    s.on("connect_error", (e) => { s.close(); resolve(e.message); });
  });
}

describe("logout revoca el token al servidor", () => {
  let server: Server;
  let io: SocketIOServer;
  let base = "";
  let tA = "", tA2 = "", tB = "";

  before(async () => {
    for (const [id, email] of [[A, "a@example.com"], [B, "b@example.com"]]) {
      const r = await loginWithIdentity({ kind: "email", email, current: { playerId: id, legacy: false }, allowCreate: false });
      assert.ok(r.ok);
    }
    tA = issuePlayerToken(A)!;
    tA2 = issuePlayerToken(A, 1000 * 60 * 60)!; // un altre dispositiu del mateix jugador
    tB = issuePlayerToken(B)!;
    const dist = mkdtempSync(path.join(os.tmpdir(), "setimig-logout-dist-"));
    mkdirSync(path.join(dist, "regles"), { recursive: true });
    writeFileSync(path.join(dist, "index.html"), "<!doctype html>");
    writeFileSync(path.join(dist, "regles/index.html"), "<!doctype html><title>Regles</title>");
    const app = express();
    app.use(express.json());
    app.use(sessionCookieMiddleware);
    app.use(requireLoginMiddleware);
    registerAuthRoutes(app);
    app.post("/api/player-session", (req, res) => {
      void handleRenewPlayerSession(req, res);
    });
    app.get("/api/balance", (_req, res) => res.json({ ok: true }));
    mountStaticDist(app, dist);
    server = createServer(app);
    io = new SocketIOServer(server);
    registerSocketLoginGate(io);
    await new Promise<void>((r) => server.listen(0, "127.0.0.1", () => r()));
    base = `http://127.0.0.1:${(server.address() as { port: number }).port}`;
  });
  after(async () => {
    io.close();
    await new Promise<void>((r) => server.close(() => r()));
    rmSync(dataDir, { recursive: true, force: true });
  });

  const bearer = (t: string) => ({ authorization: `Bearer ${t}` });
  const cookie = (t: string) => ({ cookie: `${SESSION_COOKIE}=${t}` });

  it("abans del logout tot funciona", async () => {
    assert.equal((await fetch(`${base}/api/balance`, { headers: bearer(tA) })).status, 200);
    for (const path of ["/api/auth/me", "/api/me"]) {
      const me = await fetch(`${base}${path}`, { headers: bearer(tA) });
      assert.equal(me.status, 200, path);
      assert.equal((await me.json()).playerId, A);
    }
    assert.equal((await fetch(`${base}/regles/`, { headers: cookie(tA), redirect: "manual" })).status, 200);
    assert.equal(await connect(base, tA), "ok");
  });

  it("socket viu es desconnecta en fer logout", async () => {
    const s = ioClient(base, { auth: { token: tA }, transports: ["websocket"], reconnection: false });
    await new Promise<void>((r) => s.on("connect", () => r()));
    const gone = new Promise<string>((r) => s.on("disconnect", (why) => r(why)));
    const res = await fetch(`${base}/api/auth/logout`, { method: "POST", headers: { ...bearer(tA), ...cookie(tA) } });
    assert.equal(res.status, 200);
    assert.match(res.headers.getSetCookie().join(";"), /Max-Age=0/);
    assert.equal(await gone, "io server disconnect");
    s.close();
  });

  it("després del logout: 401 a l'API i a /api/account/delete, connect_error i 302", async () => {
    const r1 = await fetch(`${base}/api/balance`, { headers: bearer(tA) });
    assert.equal(r1.status, 401);
    assert.equal((await r1.json()).error, "auth_required");
    for (const path of ["/api/auth/me", "/api/me"]) {
      const me = await fetch(`${base}${path}`, { headers: bearer(tA) });
      assert.equal(me.status, 401, path);
    }
    const r2 = await fetch(`${base}/api/account/delete`, {
      method: "POST",
      headers: { ...bearer(tA), "content-type": "application/json" },
      body: JSON.stringify({ confirm: "DELETE_MY_ACCOUNT" }),
    });
    assert.equal(r2.status, 401);
    assert.equal(await connect(base, tA), "auth_required");
    assert.equal((await fetch(`${base}/regles/`, { headers: cookie(tA), redirect: "manual" })).status, 302);
  });

  it("altres tokens (un altre dispositiu i un altre jugador) continuen valent", async () => {
    for (const t of [tA2, tB]) {
      assert.equal((await fetch(`${base}/api/balance`, { headers: bearer(t) })).status, 200);
      assert.equal((await fetch(`${base}/api/auth/me`, { headers: bearer(t) })).status, 200);
      assert.equal((await fetch(`${base}/api/me`, { headers: bearer(t) })).status, 200);
      assert.equal(await connect(base, t), "ok");
    }
  });

  it("la revocació sobreviu a una recàrrega del magatzem i només desa hashes", () => {
    const raw = readFileSync(revokedTokensPath(), "utf8");
    assert.ok(!raw.includes(tA) && !raw.includes(A));
    const parsed = JSON.parse(raw) as { version: number; tokens: Record<string, number> };
    assert.equal(parsed.version, 2);
    assert.ok(parsed.tokens);
    resetRevokedTokensCacheForTests();
    assert.equal(verifyPlayerToken(tA), null);
    assert.ok(verifyPlayerToken(tB));
    assert.ok(existsSync(revokedTokensPath()));
  });

  it("logout només amb Bearer revoca aquest token i no el de l'altre dispositiu", async () => {
    const t = issuePlayerToken(A)!;
    const res = await fetch(`${base}/api/auth/logout`, { method: "POST", headers: bearer(t) });
    assert.equal(res.status, 200);
    assert.equal((await fetch(`${base}/api/auth/me`, { headers: bearer(t) })).status, 401);
    assert.equal((await fetch(`${base}/api/auth/me`, { headers: bearer(tA2) })).status, 200);
    assert.equal(await connect(base, t), "auth_required");
    assert.equal(await connect(base, tA2), "ok");
  });

  it("logout només amb galeta revoca aquest token", async () => {
    const t = issuePlayerToken(A)!;
    const res = await fetch(`${base}/api/auth/logout`, { method: "POST", headers: cookie(t) });
    assert.equal(res.status, 200);
    assert.match(res.headers.getSetCookie().join(";"), /Max-Age=0/);
    assert.equal((await fetch(`${base}/api/auth/me`, { headers: bearer(t) })).status, 401);
    assert.equal((await fetch(`${base}/api/me`, { headers: bearer(t) })).status, 401);
    assert.equal(await connect(base, t), "auth_required");
    assert.equal((await fetch(`${base}/api/auth/me`, { headers: bearer(tB) })).status, 200);
  });

  it("logout sense token respon 200 i no revoca les altres sessions", async () => {
    const t = issuePlayerToken(A)!;
    const res = await fetch(`${base}/api/auth/logout`, { method: "POST" });
    assert.equal(res.status, 200);
    assert.equal((await res.json()).ok, true);
    assert.equal((await fetch(`${base}/api/auth/me`, { headers: bearer(t) })).status, 200);
    assert.equal(await connect(base, t), "ok");
  });

  it("renovar lliga el token vell: el logout del nou el revoca, l'altre dispositiu segueix", async () => {
    const old = issuePlayerToken(A)!;
    const renewed = await fetch(`${base}/api/player-session`, { method: "POST", headers: bearer(old) });
    assert.equal(renewed.status, 200);
    const body = (await renewed.json()) as { playerId: string; playerToken: string };
    assert.equal(body.playerId, A);
    assert.equal(verifyPlayerToken(body.playerToken)?.playerId, A);
    assert.equal((await fetch(`${base}/api/auth/me`, { headers: bearer(old) })).status, 200);
    const s = ioClient(base, { auth: { token: old }, transports: ["websocket"], reconnection: false });
    await new Promise<void>((r) => s.on("connect", () => r()));
    const gone = new Promise<string>((r) => s.on("disconnect", (why) => r(why)));
    const out = await fetch(`${base}/api/auth/logout`, { method: "POST", headers: bearer(body.playerToken) });
    assert.equal(out.status, 200);
    assert.equal(await gone, "io server disconnect");
    s.close();
    assert.equal((await fetch(`${base}/api/auth/me`, { headers: bearer(old) })).status, 401);
    assert.equal((await fetch(`${base}/api/auth/me`, { headers: bearer(body.playerToken) })).status, 401);
    assert.equal(await connect(base, old), "auth_required");
    assert.equal((await fetch(`${base}/api/auth/me`, { headers: bearer(tA2) })).status, 200);
  });

  it("un token sense sid, un cop renovat, mor amb el logout de la sessió", async () => {
    const exp = Date.now() + 60 * 60 * 1000;
    const body = Buffer.from(JSON.stringify({ playerId: A, exp }), "utf8").toString("base64url");
    const sig = createHmac("sha256", process.env.PLAYER_TOKEN_SECRET!).update(body).digest("base64url");
    const old = `${body}.${sig}`;
    assert.equal(verifyPlayerToken(old)?.playerId, A);
    const renewed = await fetch(`${base}/api/player-session`, { method: "POST", headers: bearer(old) });
    assert.equal(renewed.status, 200);
    const next = (await renewed.json()) as { playerToken: string };
    assert.equal((await fetch(`${base}/api/auth/me`, { headers: bearer(old) })).status, 200);
    const out = await fetch(`${base}/api/auth/logout`, { method: "POST", headers: cookie(next.playerToken) });
    assert.equal(out.status, 200);
    assert.equal((await fetch(`${base}/api/auth/me`, { headers: bearer(old) })).status, 401);
    assert.equal((await fetch(`${base}/api/auth/me`, { headers: bearer(next.playerToken) })).status, 401);
    assert.equal((await fetch(`${base}/api/player-session`, { method: "POST", headers: cookie(old) })).status, 401);
  });

  it("un fitxer de revocats de versió 1 es llegeix sense perdre els hashes", () => {
    const t = issuePlayerToken(B)!;
    writeFileSync(revokedTokensPath(), JSON.stringify({ version: 1, tokens: { [hashToken(t)]: Date.now() + 60_000 } }));
    resetRevokedTokensCacheForTests();
    assert.equal(verifyPlayerToken(t), null);
    assert.equal(verifyPlayerToken(tA2)?.playerId, A);
  });
});

describe("POST /api/player-session recupera la galeta", () => {
  let server: Server;
  let base = "";

  before(async () => {
    resetRevokedTokensCacheForTests();
    for (const [id, email] of [[A, "a@example.com"], [B, "b@example.com"]]) {
      const r = await loginWithIdentity({ kind: "email", email, current: { playerId: id, legacy: false }, allowCreate: false });
      assert.ok(r.ok);
    }
    const app = express();
    app.use(express.json());
    app.use(sessionCookieMiddleware);
    app.use(requireLoginMiddleware);
    registerAuthRoutes(app);
    app.post("/api/player-session", (req, res) => {
      void handleRenewPlayerSession(req, res);
    });
    app.get("/api/balance", (_req, res) => res.json({ ok: true }));
    server = createServer(app);
    await new Promise<void>((r) => server.listen(0, "127.0.0.1", () => r()));
    base = `http://127.0.0.1:${(server.address() as { port: number }).port}`;
  });
  after(async () => {
    await new Promise<void>((r) => server.close(() => r()));
  });

  const bearer = (t: string) => ({ authorization: `Bearer ${t}` });
  const cookie = (t: string) => ({ cookie: `${SESSION_COOKIE}=${t}` });

  it("galeta vàlida sense token renova el mateix compte", async () => {
    const t = issuePlayerToken(A)!;
    const res = await fetch(`${base}/api/player-session`, { method: "POST", headers: cookie(t) });
    assert.equal(res.status, 200);
    const body = (await res.json()) as { playerId: string; playerToken: string };
    assert.equal(body.playerId, A);
    assert.equal(verifyPlayerToken(body.playerToken)?.playerId, A);
    assert.match(res.headers.getSetCookie().join(";"), new RegExp(`${SESSION_COOKIE}=${body.playerToken}`));
    assert.equal((await fetch(`${base}/api/auth/me`, { headers: bearer(t) })).status, 200);
    assert.equal((await fetch(`${base}/api/balance`, { headers: cookie(t) })).status, 401);
  });

  it("galeta revocada pel logout no renova", async () => {
    const t = issuePlayerToken(A)!;
    const out = await fetch(`${base}/api/auth/logout`, { method: "POST", headers: cookie(t) });
    assert.equal(out.status, 200);
    const res = await fetch(`${base}/api/player-session`, { method: "POST", headers: cookie(t) });
    assert.equal(res.status, 401);
    assert.deepEqual(await res.json(), { error: "auth_required" });
    assert.equal(res.headers.getSetCookie().some((c) => c.startsWith(`${SESSION_COOKIE}=${t}`)), false);
  });

  it("sense galeta ni token segueix sent 401 i no crea compte", async () => {
    const res = await fetch(`${base}/api/player-session`, { method: "POST" });
    assert.equal(res.status, 401);
    assert.deepEqual(await res.json(), { error: "auth_required" });
    const orphan = issuePlayerToken("orfesessio0000000000000000000000000001");
    assert.ok(orphan);
    const no = await fetch(`${base}/api/player-session`, { method: "POST", headers: cookie(orphan) });
    assert.equal(no.status, 401);
  });

  it("un Bearer vàlid d'un altre compte guanya i no es fusiona amb la galeta", async () => {
    const cookieA = issuePlayerToken(A)!;
    const bearerB = issuePlayerToken(B)!;
    const res = await fetch(`${base}/api/player-session`, {
      method: "POST",
      headers: { ...cookie(cookieA), ...bearer(bearerB) },
    });
    assert.equal(res.status, 200);
    const body = (await res.json()) as { playerId: string; playerToken: string };
    assert.equal(body.playerId, B);
    assert.equal(verifyPlayerToken(body.playerToken)?.playerId, B);
    assert.notEqual(verifyPlayerToken(body.playerToken)?.playerId, A);
    assert.equal((await fetch(`${base}/api/auth/me`, { headers: bearer(cookieA) })).status, 200);
  });

  it("un Bearer revocat es dona per perdut i la galeta vàlida recupera la sessió", async () => {
    const live = issuePlayerToken(A)!;
    const dead = issuePlayerToken(B)!;
    assert.equal((await fetch(`${base}/api/auth/logout`, { method: "POST", headers: bearer(dead) })).status, 200);
    const res = await fetch(`${base}/api/player-session`, {
      method: "POST",
      headers: { ...cookie(live), ...bearer(dead) },
    });
    assert.equal(res.status, 200);
    assert.equal(((await res.json()) as { playerId: string }).playerId, A);
  });

  it("galeta d'un origen no permès no renova", async () => {
    const t = issuePlayerToken(A)!;
    const res = await fetch(`${base}/api/player-session`, {
      method: "POST",
      headers: { ...cookie(t), origin: "https://evil.example" },
    });
    assert.equal(res.status, 403);
    assert.equal((await res.json()).code, "BAD_ORIGIN");
    assert.equal((await fetch(`${base}/api/auth/me`, { headers: bearer(t) })).status, 200);
  });

  it("galeta caducada no renova", async () => {
    const exp = Date.now() - 1000;
    const body = Buffer.from(JSON.stringify({ playerId: A, exp }), "utf8").toString("base64url");
    const sig = createHmac("sha256", process.env.PLAYER_TOKEN_SECRET!).update(body).digest("base64url");
    const res = await fetch(`${base}/api/player-session`, { method: "POST", headers: cookie(`${body}.${sig}`) });
    assert.equal(res.status, 401);
  });
});
