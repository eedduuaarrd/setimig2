import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createServer, type Server as HttpServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket as ClientSocket } from "socket.io-client";
import {
  setupGameHandlers,
  resetGameStateForTests,
  getGameHostForTests,
  getRoomSnapshotForTests,
  type ResumeStatus,
} from "./game.ts";
import { clearRoomTimers } from "../shared/gameEngine.ts";
import type { RoomView } from "../src/gameTypes.ts";

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";

/**
 * P1 Provador (prod v93): eliminat en solo → «Tornar al lobby» → JUGAR → Començar portava a
 * «Última mà» (10/10) d'una partida vella amb 10.000 fitxes a la taula (2.000 de més).
 * `join_solo_room` amb la sala a «waiting» conservava el comptador de mans i les fitxes dels
 * bots de la partida anterior. Ara: partida nova a la mà 1 amb 8.000 fitxes, i una partida
 * acabada no és mai reprenible.
 */

type TestServer = { url: string; http: HttpServer; io: SocketIOServer };

async function startTestServer(): Promise<TestServer> {
  const http = createServer();
  const io = new SocketIOServer(http, { cors: { origin: "*" } });
  await setupGameHandlers(io);
  await new Promise<void>((resolve) => http.listen(0, "127.0.0.1", () => resolve()));
  const addr = http.address();
  const port = typeof addr === "object" && addr ? addr.port : 0;
  return { url: `http://127.0.0.1:${port}`, http, io };
}

async function stopTestServer(server: TestServer): Promise<void> {
  resetGameStateForTests();
  server.io.close();
  await new Promise<void>((resolve) => server.http.close(() => resolve()));
}

function connect(url: string): Promise<ClientSocket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.on("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.on("connect_error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

function joinSolo(socket: ClientSocket, payload: Record<string, unknown>): Promise<RoomView> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("joined_room timeout")), 10_000);
    socket.once("joined_room", (room: RoomView) => {
      clearTimeout(timer);
      resolve(room);
    });
    socket.once("game_error", (err: { code?: string }) => {
      clearTimeout(timer);
      reject(new Error(`game_error ${err.code}`));
    });
    socket.emit("join_solo_room", payload);
  });
}

function queryResume(socket: ClientSocket, playerId: string): Promise<ResumeStatus> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("resume_status timeout")), 10_000);
    socket.emit("resume_status", { playerId }, (status: ResumeStatus) => {
      clearTimeout(timer);
      resolve(status);
    });
  });
}

function viewTotal(room: RoomView): number {
  return (room.players ?? []).reduce((sum, p) => sum + (p.chips ?? 0), 0) + (room.pot ?? 0) + (room.jackpot ?? 0);
}

/** Juga una partida, la congela i la deixa en l'estat que es vol provar. */
async function staleSoloRoom(
  url: string,
  playerId: string,
  mutate: (room: NonNullable<ReturnType<typeof getRoomSnapshotForTests>>) => void
): Promise<{ first: ClientSocket; resumeToken: string | undefined }> {
  const first = await connect(url);
  const joined = await joinSolo(first, { playerName: "Test Priv 2", playerId, botCount: 3 });
  await new Promise((r) => setTimeout(r, 700));
  const room = getRoomSnapshotForTests(`solo-${playerId}`);
  assert.ok(room);
  clearRoomTimers(getGameHostForTests(), room!);
  const bots = room!.players.filter((p) => p.isBot);
  assert.equal(bots.length, 3);
  for (const p of room!.players) {
    p.bet = 0;
    p.handSlots = [];
    p.status = "waiting";
  }
  room!.pot = 0;
  room!.jackpot = 0;
  // Fitxes dels bots al final de la partida vella (8.000 en total amb el jugador a 0).
  bots[0]!.chips = 2_500;
  bots[1]!.chips = 4_700;
  bots[2]!.chips = 800;
  mutate(room!);
  return { first, resumeToken: joined.soloResumeToken };
}

function assertFreshMatch(view: RoomView): void {
  assert.equal(view.matchEnded, false);
  assert.equal(view.matchProgress?.handNumber, 1, "partida nova a la mà 1");
  assert.equal(viewTotal(view), 8_000, "8.000 fitxes a la taula");
  for (const p of view.players ?? []) assert.equal(p.chips, 2_000, `${p.name} comença amb 2.000`);
}

describe("solo: tornar a jugar després de quedar eliminat", () => {
  it("partida acabada (eliminat a la mà 4): no és reprenible i «Començar» en fa una de nova", async () => {
    const server = await startTestServer();
    const playerId = "soloelimrepresa0001";
    const { first, resumeToken } = await staleSoloRoom(server.url, playerId, (room) => {
      const human = room.players.find((p) => p.playerId === playerId)!;
      human.chips = 0;
      room.phase = "waiting";
      room.matchEnded = true;
      room.phaseB = { handsTotal: 10, handsCompleted: 4, chipPool: 8_000, startingChips: 2_000 };
    });
    try {
      const second = await connect(server.url);
      try {
        const status = await queryResume(second, playerId);
        assert.equal(status.solo, false, "una partida acabada no s'ofereix per continuar");
        const view = await joinSolo(second, {
          playerName: "Test Priv 2",
          playerId,
          botCount: 3,
          soloResumeToken: resumeToken,
        });
        assertFreshMatch(view);
        const room = getRoomSnapshotForTests(`solo-${playerId}`)!;
        assert.equal(room.players.filter((p) => p.playerId === playerId).length, 1);
        assert.equal(room.phaseB?.handsCompleted, 0);
        assert.equal(room.phaseB?.chipPool, 8_000);
      } finally {
        second.disconnect();
      }
    } finally {
      first.disconnect();
      await stopTestServer(server);
    }
  });

  it("sala de bots a «waiting» amb el comptador vell (10/10): «Començar» no hi entra", async () => {
    const server = await startTestServer();
    const playerId = "soloelimrepresa0002";
    const { first, resumeToken } = await staleSoloRoom(server.url, playerId, (room) => {
      room.players = room.players.filter((p) => p.playerId !== playerId);
      room.phase = "waiting";
      room.matchEnded = false;
      room.phaseB = { handsTotal: 10, handsCompleted: 10, chipPool: 8_000, startingChips: 2_000 };
    });
    try {
      const second = await connect(server.url);
      try {
        const view = await joinSolo(second, {
          playerName: "Test Priv 2",
          playerId,
          botCount: 3,
          soloResumeToken: resumeToken,
        });
        assertFreshMatch(view);
      } finally {
        second.disconnect();
      }
    } finally {
      first.disconnect();
      await stopTestServer(server);
    }
  });
});
