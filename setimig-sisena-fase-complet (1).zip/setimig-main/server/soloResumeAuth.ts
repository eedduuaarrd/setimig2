import { randomBytes, timingSafeEqual } from "node:crypto";

export function newSoloResumeToken(): string {
  return randomBytes(32).toString("base64url");
}

/** A missing stored token identifies a legacy seat that predates this auth protocol. */
export function canResumeSoloSeat(
  storedToken: string | undefined,
  suppliedToken: unknown,
  ownerSocketConnected = false,
): boolean {
  if (!storedToken) return !ownerSocketConnected;
  if (typeof suppliedToken !== "string" || !suppliedToken) return false;
  const expected = Buffer.from(storedToken);
  const actual = Buffer.from(suppliedToken);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}
