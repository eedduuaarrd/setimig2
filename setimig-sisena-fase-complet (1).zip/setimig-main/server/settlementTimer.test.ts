import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient } from "socket.io-client";
import { setupGameHandlers } from "./game.ts";

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";

/** Regression: emitRoom during settlement must not cancel settlementEndTimer (solo stuck after hand 1). */
describe("settlement timer", () => {
  it("solo AI advances to next betting after settlement", async () => {
    const http = createServer();
    const io = new SocketIOServer(http, { cors: { origin: "*" } });
    await setupGameHandlers(io);
    await new Promise<void>((r) => http.listen(0, "127.0.0.1", () => r()));
    const port = (http.address() as { port: number }).port;
    const url = `http://127.0.0.1:${port}`;

    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    await new Promise<void>((r) => socket.on("connect", () => r()));

    let sawSettlement = false;

    const done = new Promise<void>((resolve, reject) => {
      const timer = setTimeout(
        () => reject(new Error("never left settlement window")),
        120_000
      );

      const onRoom = (room: {
        phase: string;
        id: string;
        sessionStats?: { handsPlayed: number } | null;
        players?: { id: string; isBanker?: boolean; bet?: number; pendingBankChoice?: unknown }[];
      }) => {
        const me = room.players?.find((p) => p.id === socket.id);
        if (room.phase === "settlement") sawSettlement = true;
        if (sawSettlement && room.phase === "betting" && (room.sessionStats?.handsPlayed ?? 0) >= 1) {
          clearTimeout(timer);
          resolve();
          return;
        }
        if (me?.pendingBankChoice) {
          socket.emit("bank_keep_choice", { roomId: room.id, keep: false });
        }
        if (room.phase === "betting" && me && !me.isBanker && me.bet === 0) {
          socket.emit("place_bet", { roomId: room.id, amount: 100 });
        }
        const nb = room.players?.filter((p) => !p.isBanker) ?? [];
        const turnId =
          room.phase === "playing"
            ? nb[(room as { turnIndex?: number }).turnIndex ?? 0]?.id
            : room.phase === "banker"
              ? room.players?.find((p) => p.isBanker)?.id
              : null;
        if (turnId === socket.id && (room.phase === "playing" || room.phase === "banker")) {
          socket.emit("stand", room.id);
        }
      };

      socket.on("room_update", onRoom);
      socket.on("joined_room", onRoom);
      socket.emit("join_solo_room", {
        playerName: "SettleTest",
        playerId: "settlementtimer01",
        botCount: 1,
      });
    });

    try {
      await done;
      assert.equal(sawSettlement, true);
    } finally {
      socket.disconnect();
      io.close();
      await new Promise<void>((r) => http.close(() => r()));
    }
  });
});
