/**
 * Socket.io wiring for the shared game engine.
 */
import { allowSocketEvent, createSocketEventBucket } from "./socketRateLimit.ts";
import type { Server, Socket } from "socket.io";
import { getBalance, refundOrphanSoloBuyIns, sanitizePlayerId, setBalance } from "./balances";
import {
  applySoloBuyInChips,
  openSoloBuyInForRoom,
  recordSoloHandOnLedger,
  roomUsesSoloBuyIn,
  settleSoloBuyIn,
} from "./soloBuyIn.ts";
import {
  livePublicBuyInIds,
  recordPublicHandsOnLedger,
  roomUsesPublicBuyIn,
  seatPublicPlayerWithBuyIn,
  settlePublicBuyIn,
} from "./publicBuyIn.ts";
import { PHASE_B_START_CHIPS } from "../shared/matchPhaseB.ts";
import { parsePrivateDeckSeed } from "../shared/testSeededDeck.ts";
import { resolvePlayerIdFromParts } from "./playerToken.ts";
import { authorizePrivateAction, authorizeSoloClientAction, type PrivateActionMeta } from "./gameActionAuth.ts";
import {
  loadAllPrivateRooms,
  offlineSocketId,
  persistPrivateRoomSnapshot,
  removePrivateRoomFromStore,
  resetPrivateRoomStoreCacheForTests,
} from "./privateRoomStore.ts";
import { markAsBot } from "./bots.ts";
import { SOLO_START_DELAY_MS } from "../shared/pacing.ts";
import {
  generateInviteCode,
  newSeatToken,
  normalizeInviteCode,
} from "./privateRooms.ts";
import type { RoomView } from "../src/gameTypes.ts";
import type { SettlementEventPayload } from "../shared/settlementSummary.ts";
import { cardAsSeen, type CardDealtEvent, type RoomViewExtended } from "../shared/dealEvents.ts";
import { resolveSeatDisplayName } from "./seatName.ts";
import { assignPlayerAvatar } from "./playerProfileAvatar.ts";
import {
  applyRevealCard,
  applyDouble,
  classifyDoubleReject,
  applyHit,
  applyMort,
  applySwap,
  applyCardPeeked,
  applyPlaceBet,
  betRangeError,
  applySplit,
  applyStand,
  applyPhaseBRevenge,
  applyHostMatchSettings,
  ensurePhaseBMatchInitialized,
  beginGameStart,
  canStartGame,
  clearRoomTimers,
  clearSoloRoomState,
  freshSessionStats,
  resetSessionStats,
  createBotPlayer,
  currentPlayer,
  currentSlot,
  emptyRoomBase,
  ensureFillBots,
  ensureSoloBots,
  fillPrivateBots,
  humanPlayers,
  isPrivateHost,
  nextBotSlot,
  privateTableChips,
  resolvePendingBankChoice,
  acknowledgeSettlement,
  publishRoom,
  removePlayerFromHand,
  resumePacingTimers,
  roomToView,
  type GameHost,
  type Player,
  type Room,
} from "../shared/gameEngine.ts";
import { ENGINE_MESSAGES } from "../shared/gameMessages.ts";
import { DEFAULT_BOT_DIFFICULTY, isBotDifficulty } from "../shared/ai/botDifficulty.ts";
import {
  DEFAULT_PRIVATE_MAX_BET,
  DEFAULT_PRIVATE_MIN_BET,
  MAX_PRIVATE_TABLE_PLAYERS,
} from "../shared/tableBetLimits.ts";
import { createActionReceiptStore, isActionReceiptId } from "./actionReceiptStore.ts";
import { actionReceiptIdFromPayload, buildGameActionAck } from "./gameActionAck.ts";
import { canResumeSoloSeat, newSoloResumeToken } from "./soloResumeAuth.ts";
import { resolveInviteCodeForHost } from "./friends/friendsHttp.ts";
import {
  emitChatHistoryToSocket,
  forgetRoomChatWhenDestroyed,
  handlePrivateSendEmote,
  handlePrivateSendMessage,
  resetSocialChatForTests,
} from "./social/privateTableChat.ts";
import { recordHandStatsFromSettlement, recordMatchEndForHumans } from "./handStatsRecorder.ts";
import { applyCampaignLevelToSoloRoom, recordCampaignMatchIfNeeded } from "./campaignMatch.ts";
import { getCampaignLevel, parseCampaignLevelInput } from "../shared/campaignLevels.ts";
import { getCampaignProgress, isCampaignLevelUnlocked } from "./campaignProgress.ts";
import { defaultHostMatchSettings } from "../shared/hostMatchSettings.ts";
import { normalizeFastTournamentOptions, roomUsesIsolatedPlayChips } from "../shared/fastTournament.ts";
import {
  clearSoloIsolatedSession,
  loadSoloIsolatedSessionsOnBoot,
  markSoloIsolatedSessionActive,
  markSoloIsolatedSessionLost,
  registerAuthoritativeSoloRuntime,
  resetSoloIsolatedSessionsForTests,
  restorableSoloIsolatedSession,
  touchSoloIsolatedSession,
} from "./soloIsolatedSessions.ts";
import { applyWagerConfigToRoom, buildRoomWagerConfig } from "../shared/roomWagerConfig.ts";

import { EMPTY_GAME_COUNTS, type GameCounts } from "./healthMetrics.ts";
import { trustedClientIp } from "./clientIp.ts";
import { trackGameFinished, trackGameStarted, trackPrivateRoom } from "./analytics.ts";
import { randomBase36 } from "../shared/seatToken.ts";
import { isJoinBlocked, recordJoinFailure } from "./joinAttemptLimit.ts";
import { defaultPublicOrigin, publicOriginFor } from "./allowedOrigins.ts";
const rooms: Map<string, Room> = new Map();
const inviteCodeToRoomId = new Map<string, string>();

/**
 * Enllaços d'invitació: es fan amb el domini des del qual juga cada jugador (si és a la llista
 * d'orígens permesos); si no se sap, APP_URL o setimig.supercbb.com.
 */
const PRIVATE_TABLE_ORIGIN = defaultPublicOrigin();
const socketPublicOrigins = new Map<string, string>();

export function privateTableOriginForSocket(socketId?: string): string {
  return (socketId && socketPublicOrigins.get(socketId)) || PRIVATE_TABLE_ORIGIN;
}

function testScheduleMs(ms: number): number {
  if (process.env.SETIMIG_TEST_FAST === "1") return Math.max(1, Math.min(ms, 48));
  return ms;
}

/**
 * Amb SETIMIG_TEST_FAST tots els temporitzadors del motor duren com a màxim 48 ms.
 * Un test que necessita un torn quiet (p. ex. rebutjar una acció fora de torn) pot
 * pausar-los: si no, el termini d'aposta o un bot avancen la mà abans de la comprovació.
 */
let hostTimersPausedForTests = false;

export function setHostTimersPausedForTests(paused: boolean): void {
  hostTimersPausedForTests = paused;
  if (paused) clearPendingHostTimersForTests();
}

function clearPendingHostTimersForTests(): void {
  for (const handle of pendingHostTimers) clearTimeout(handle);
  pendingHostTimers.clear();
}

/**
 * Temporitzadors pendents del motor. Només serveix perquè `resetGameStateForTests` els pugui
 * cancel·lar tots: abans, els d'un test continuaven jugant (i escrivint a disc) quan el test
 * següent ja havia esborrat o canviat el directori de dades (ENOENT/ENOTEMPTY intermitents).
 * No canvia cap comportament: cada temporitzador surt del conjunt quan s'executa o es cancel·la.
 */
const pendingHostTimers = new Set<ReturnType<typeof setTimeout>>();

const gameHost: GameHost = {
  schedule: (fn, ms) => {
    if (hostTimersPausedForTests) {
      const idle = setTimeout(() => {}, 0);
      clearTimeout(idle);
      return idle;
    }
    const handle: ReturnType<typeof setTimeout> = setTimeout(() => {
      pendingHostTimers.delete(handle);
      try {
        const result: unknown = fn();
        if (result != null && typeof (result as { then?: unknown }).then === "function") {
          void Promise.resolve(result).catch((err) => {
            console.error("[gameHost.schedule] async callback failed:", err);
          });
        }
      } catch (err) {
        console.error("[gameHost.schedule] callback failed:", err);
      }
    }, testScheduleMs(ms));
    pendingHostTimers.add(handle);
    return handle;
  },
  clearTimeout: (id) => {
    if (id) {
      pendingHostTimers.delete(id);
      clearTimeout(id);
    }
  },
  // Sense `persistHumanBalance`: les fitxes de taula mai s'escriuen com a saldo real després de cada
  // mà (abans les taules públiques ho feien i trepitjaven els pagaments fets mentrestant). El saldo
  // real de les taules públiques va per compra d'entrada + abonament verificat (publicBuyIn.ts).
  getPrivateTableOrigin: (viewerId) => privateTableOriginForSocket(viewerId),
  onHandSettled(room) {
    // Llibre de la compra solo: síncron i abans de res (les fitxes encara són les de la liquidació).
    recordSoloHandOnLedger(room);
    recordPublicHandsOnLedger(room);
    // Stats are best-effort: a failed write must never crash the table server.
    return recordHandStatsFromSettlement(room, room.lastRound?.results).catch((err) => {
      console.error("[stats] hand record failed:", err);
    });
  },
  async onMatchFinished(room) {
    // Final de partida solo: s'abona el resultat verificat (el llibre surt de la sala ara mateix).
    const settling = settleSoloBuyIn(room, undefined, "final de partida").catch((err) => {
      console.error("[saldo] tancament de la compra solo fallit:", err);
    });
    try {
      await recordMatchEndForHumans(room);
      await recordCampaignMatchIfNeeded(room);
    } catch (err) {
      console.error("[stats] match record failed:", err);
    }
    await settling;
  },
  emitRoomUpdate() {
    /* server uses publishRoom */
  },
  publishRoom(room) {
    return emitRoom(room);
  },
};

/**
 * Saldo real en sortir d'una sala no privada. El mode pràctica fa servir fitxes de pràctica
 * i no llegeix ni escriu mai balances.json (ni tan sols per «restaurar» una còpia antiga,
 * que podria trepitjar un canvi fet mentrestant, p. ex. fitxes gratis en una altra pestanya).
 */
async function persistRealBalanceOnLeave(
  room: Room,
  leaving: Player,
  opts: { seatContinues?: boolean } = {}
): Promise<void> {
  if (room.practiceMode) return;
  if (roomUsesIsolatedPlayChips(room)) {
    // Torneig ràpid: fitxes aïllades, el saldo real no s'ha tocat. Abans s'hi tornava a escriure
    // una còpia del saldo presa en seure, que esborrava qualsevol pagament fet mentrestant
    // (recompenses de missions, fitxes gratis, compres). Ara no s'escriu res.
    room.soloRealBalances?.delete(leaving.playerId);
    return;
  }
  if (roomUsesSoloBuyIn(room)) {
    // Solo amb saldo real: mai s'escriuen les fitxes de taula com a saldo. Es tanca la compra
    // (resultat verificat o només la compra) com a increment atòmic sobre el saldo ACTUAL: els
    // pagaments al saldo durant la partida (assoliments, missions, fitxes gratis) s'hi conserven. Si el seient continua amb la IA (desconnexió a
    // mitja mà), es tanca en acabar la partida o en començar-ne una altra.
    if (!opts.seatContinues) await settleSoloBuyIn(room, leaving, "sortida");
    return;
  }
  // Taula pública: abonament verificat de la compra d'entrada com a increment sobre el saldo actual.
  // Mai `setBalance(fitxes de taula)`: esborrava assoliments, missions o compres fets mentrestant.
  if (roomUsesPublicBuyIn(room)) await settlePublicBuyIn(room, leaving, "sortida");
}

/** Només amb saldo 0 (amb saldo parcial es seu amb el que hi ha). */
function insufficientBalanceError(required: number, balance: number) {
  return {
    message:
      `No tens fitxes per seure a la partida contra la IA (saldo ${balance.toLocaleString("ca-ES")}). ` +
      `Pots recollir fitxes gratis o jugar en mode pràctica.`,
    code: "INSUFFICIENT_BALANCE",
    required,
    balance,
  };
}

/** Mode d'una partida solo: "normal", "practice", "fastTournament" o "campaign:<nivell>". */
export function soloModeOfRoom(room: Pick<Room, "practiceMode" | "fastTournament" | "campaignLevel">): string {
  if (room.practiceMode) return "practice";
  if (room.fastTournament) return "fastTournament";
  if (room.campaignLevel != null) return `campaign:${room.campaignLevel}`;
  return "normal";
}

/**
 * Mode que demana `join_solo_room`, o null si no en demana cap (reconnexió automàtica: el client
 * envia `practiceMode: false` sense `intent`). `intent: "new"` sense cap altre mode és una solo normal.
 */
export function requestedSoloMode(payload: Record<string, unknown>, campaignLevel: number | null): string | null {
  if (payload.practiceMode === true) return "practice";
  if (normalizeFastTournamentOptions(payload.fastTournament)?.enabled === true) return "fastTournament";
  if (campaignLevel != null) return `campaign:${campaignLevel}`;
  if (payload.intent === "new") return "normal";
  return null;
}

const soloJoinLocks = new Map<string, Promise<void>>();

/** Serialitza les peticions `join_solo_room` d'una mateixa sala solo. */
async function withSoloJoinLock(rid: string, fn: () => Promise<void>): Promise<void> {
  const previous = soloJoinLocks.get(rid) ?? Promise.resolve();
  const run = previous.then(fn, fn);
  const tail = run.catch((err) => {
    console.error("[join_solo_room] failed:", err);
  });
  soloJoinLocks.set(rid, tail);
  try {
    await run;
  } finally {
    if (soloJoinLocks.get(rid) === tail) soloJoinLocks.delete(rid);
  }
}

function soloRoomId(playerId: string): string {
  return `solo-${playerId}`;
}

function canEditHostMatchSettings(room: Room): boolean {
  if (room.phase !== "waiting") return false;
  if (room.matchEnded) return true;
  if (!room.phaseB) return true;
  return room.phaseB.handsCompleted === 0;
}

function isSocketRecord(payload: unknown): payload is Record<string, unknown> {
  return typeof payload === "object" && payload !== null && !Array.isArray(payload);
}

function applyOptionalRoomWagerConfig(
  room: Room,
  payload: Record<string, unknown>
): string | null {
  const hasProfile = payload.betProfileId !== undefined && payload.betProfileId !== null;
  const hasRising = payload.risingBlinds !== undefined && payload.risingBlinds !== null;
  const hasFast =
    payload.fastTournament !== undefined && payload.fastTournament !== null;
  if (!hasProfile && !hasRising && !hasFast) return null;
  const config = buildRoomWagerConfig({
    betProfileId: payload.betProfileId,
    minBet: payload.minBet,
    maxBet: payload.maxBet,
    risingBlinds: payload.risingBlinds,
    fastTournament: payload.fastTournament,
  });
  if (!config) {
    return "Opcions de taula (límits, cegues o torneig) no vàlides.";
  }
  applyWagerConfigToRoom(room, config);
  return null;
}

function emitBadSocketPayload(socket: Socket): void {
  socket.emit("game_error", { message: "Sol·licitud invàlida.", code: "BAD_PAYLOAD" });
}

function roomByInviteCode(code: string): Room | undefined {
  const roomId = inviteCodeToRoomId.get(code);
  return roomId ? rooms.get(roomId) : undefined;
}

function registerInviteCode(code: string, roomId: string) {
  inviteCodeToRoomId.set(code, roomId);
}

function unregisterInviteCode(room: Room) {
  if (room.inviteCode) inviteCodeToRoomId.delete(room.inviteCode);
}

async function destroyPrivateRoomIfEmpty(room: Room) {
  if (!room.isPrivate) return;
  const humans = room.players.filter((p) => !p.isBot);
  if (humans.length > 0) return;
  const code = room.inviteCode;
  unregisterInviteCode(room);
  forgetRoomChatWhenDestroyed(room.id);
  clearRoomTimers(gameHost, room);
  rooms.delete(room.id);
  forgetRoomEmitState(room.id);
  await removePrivateRoomFromStore(room.id, code);
}

const graceTimers = new Map<string, ReturnType<typeof setTimeout>>();
const actionReceipts = createActionReceiptStore();

function privateDisconnectGraceMs(): number {
  if (process.env.SETIMIG_TEST_FAST === "1") return 400;
  const raw = process.env.PRIVATE_DISCONNECT_GRACE_MS;
  if (raw) {
    const n = Number(raw);
    if (Number.isFinite(n) && n > 0) return n;
  }
  return 120_000;
}

function clearGraceTimer(seatToken: string) {
  const t = graceTimers.get(seatToken);
  if (t) {
    clearTimeout(t);
    graceTimers.delete(seatToken);
  }
}

async function evictPrivatePlayerAfterGrace(roomId: string, seatToken: string) {
  const room = rooms.get(roomId);
  if (!room?.isPrivate) return;
  const idx = room.players.findIndex((p) => p.seatToken === seatToken && !p.isBot);
  if (idx === -1) return;
  const leaving = room.players[idx]!;
  if (!leaving.graceUntil || leaving.graceUntil > Date.now()) return;
  if (leaving.id !== offlineSocketId(seatToken)) return;
  room.players.splice(idx, 1);
  await destroyPrivateRoomIfEmpty(room);
  await commitRoom(room);
}

function schedulePrivateDisconnectGrace(room: Room, player: Player) {
  clearGraceTimer(player.seatToken);
  const ms = privateDisconnectGraceMs();
  player.disconnectedAt = Date.now();
  player.graceUntil = player.disconnectedAt + ms;
  player.id = offlineSocketId(player.seatToken);
  const timer = setTimeout(() => {
    graceTimers.delete(player.seatToken);
    void evictPrivatePlayerAfterGrace(room.id, player.seatToken);
  }, ms);
  graceTimers.set(player.seatToken, timer);
}

async function commitRoom(room: Room) {
  if (room.isPrivate) {
    if (rooms.get(room.id) !== room) return;
    await persistPrivateRoomSnapshot(room);
  }
  await publishRoom(gameHost, room);
}

type CardActionResult = { ok: true } | { ok: false; message: string; code: string };

/**
 * Hit i stand: mateix ack que l'aposta (`game_action_ack`), en acceptar l'acció.
 * Si queda a la cua de l'avís, l'ack surt ara, no quan el temporitzador l'aplica.
 * Un error segueix sent `game_error` i no hi ha ack.
 */
async function onPlayerCardAction(socket: Socket, action: "hit" | "stand", payload: unknown): Promise<void> {
  if (typeof payload !== "string" && !isSocketRecord(payload)) {
    emitBadSocketPayload(socket);
    return;
  }
  const body = typeof payload === "string" ? null : payload;
  const roomId = typeof payload === "string" ? payload : body.roomId;
  if (typeof roomId !== "string") return;
  const meta: PrivateActionMeta = body ? { playerToken: body.playerToken, actionSeq: body.actionSeq } : {};
  const receiptId = body ? actionReceiptIdFromPayload(body) : undefined;
  const room = rooms.get(roomId);
  if (!room) return;
  const player = room.players.find((p) => p.id === socket.id);
  const apply = async (): Promise<CardActionResult> => {
    const authErr = authorizePrivateAction(room, player, meta, {
      allowedPhases: ["playing", "banker"],
      requireTurn: true,
    });
    if (authErr) return { ok: false, message: authErr.message, code: authErr.code };
    const err = action === "hit" ? applyHit(gameHost, room, socket.id) : applyStand(gameHost, room, socket.id);
    if (err) {
      await commitRoom(room);
      return { ok: false, message: err, code: "BAD_TURN" };
    }
    await commitRoom(room);
    return { ok: true };
  };
  const result = await actionReceipts.run(`${room.id}:${player?.seatToken ?? socket.id}`, receiptId, apply);
  if (result.ok === false) {
    socket.emit("game_error", { message: result.message, code: result.code, actionId: receiptId });
    return;
  }
  if (receiptId) {
    socket.emit("game_action_ack", buildGameActionAck({ action, actionId: receiptId, roomId: room.id }));
  }
}

function allocateInviteCode(): string {
  for (let attempt = 0; attempt < 40; attempt++) {
    const code = generateInviteCode(attempt < 20 ? 6 : 7);
    if (!inviteCodeToRoomId.has(code)) return code;
  }
  return generateInviteCode(8);
}

/**
 * Emissions en curs per sala. Totes les publicacions demanades mentre una emissió espera
 * `fetchSockets` s'ajunten en aquesta mateixa emissió: les vistes es construeixen quan acaba
 * l'espera, així que surt l'estat més recent una sola vegada (abans, una mà liquidada sortia
 * 2–3 vegades seguides: `settleGame` + l'acció que l'havia provocat + `commitRoom`).
 */
const emitsInFlight = new Map<string, Promise<void>>();

/** Liquidació ja lliurada a cada socket (`settlement` surt una sola vegada per socket i mà). */
const settlementDelivered = new Map<string, { settlementId: string; sockets: Set<string> }>();

/** Darrera carta (`handSeq`, `dealSeq`) enviada a cada socket com a `card_dealt`. */
const dealsDelivered = new Map<string, Map<string, { handSeq: number; dealSeq: number }>>();

function forgetRoomEmitState(roomId: string) {
  emitsInFlight.delete(roomId);
  settlementDelivered.delete(roomId);
  dealsDelivered.delete(roomId);
}

/**
 * Un socket que entra (o torna) a la sala no rep les cartes ja repartides com a `card_dealt`
 * (ja les té al `room_update` / `joined_room`); només les noves.
 */
function markDealsDelivered(room: Room, socketId: string) {
  let bySocket = dealsDelivered.get(room.id);
  if (!bySocket) {
    bySocket = new Map();
    dealsDelivered.set(room.id, bySocket);
  }
  bySocket.set(socketId, { handSeq: room.dealHandSeq ?? 0, dealSeq: room.dealSeq ?? 0 });
}

/** Envia, en ordre, les cartes noves per a aquest socket (carta només si la pot veure). */
function emitPendingDeals(
  room: Room,
  socket: { id: string; emit: (ev: string, payload: CardDealtEvent) => unknown },
  view: RoomViewExtended
) {
  const log = room.dealLog;
  const handSeq = room.dealHandSeq;
  if (!log?.length || !handSeq) return;
  let bySocket = dealsDelivered.get(room.id);
  if (!bySocket) {
    bySocket = new Map();
    dealsDelivered.set(room.id, bySocket);
  }
  const cursor = bySocket.get(socket.id);
  const fromSeq = cursor && cursor.handSeq === handSeq ? cursor.dealSeq : 0;
  for (const rec of log) {
    if (rec.dealSeq <= fromSeq) continue;
    const seatId = room.players.find((p) => p.playerId === rec.playerId)?.id ?? "";
    const seen = cardAsSeen(view, seatId, rec.slotIndex, rec.cardId);
    socket.emit("card_dealt", {
      roomId: room.id,
      handSeq: rec.handSeq,
      dealSeq: rec.dealSeq,
      kind: rec.kind,
      seatId,
      isBanker: rec.isBanker,
      slotIndex: rec.slotIndex,
      cardIndex: rec.cardIndex,
      cardId: rec.cardId,
      faceUp: seen.faceUp,
      card: seen.card,
      initialIndex: rec.initialIndex,
      delayMs: rec.delayMs,
      at: rec.at,
      animUntil: room.dealAnimUntil ?? rec.at,
    });
  }
  bySocket.set(socket.id, { handSeq, dealSeq: log[log.length - 1]!.dealSeq });
}

function emitRoom(room: Room): Promise<void> {
  if (!rooms.has(room.id)) return Promise.resolve();
  const io = ioRef;
  if (!io) return Promise.resolve();
  const pending = emitsInFlight.get(room.id);
  if (pending) return pending;
  const run = (async () => {
    try {
      const sockets = await io.in(room.id).fetchSockets();
      // A partir d'aquí les vistes es fan amb l'estat actual; una publicació nova en farà una altra.
      if (emitsInFlight.get(room.id) === run) emitsInFlight.delete(room.id);
      if (!rooms.has(room.id)) return;
      for (const s of sockets) {
        const view = roomViewForSocket(room, s.id);
        emitPendingDeals(room, s, view);
        const settlement = view.settlement;
        if (settlement) {
          let delivered = settlementDelivered.get(room.id);
          if (!delivered || delivered.settlementId !== settlement.settlementId) {
            delivered = { settlementId: settlement.settlementId, sockets: new Set() };
            settlementDelivered.set(room.id, delivered);
          }
          if (!delivered.sockets.has(s.id)) {
            delivered.sockets.add(s.id);
            const payload: SettlementEventPayload = { ...settlement, room: view };
            s.emit("settlement", payload);
          }
        }
        s.emit("room_update", view);
      }
    } finally {
      if (emitsInFlight.get(room.id) === run) emitsInFlight.delete(room.id);
    }
  })();
  emitsInFlight.set(room.id, run);
  return run;
}

let ioRef: Server | null = null;

function emitJoinedPrivateRoom(socket: Socket, room: Room) {
  socket.emit("joined_room", roomViewForSocket(room, socket.id));
  if (room.isPrivate) emitChatHistoryToSocket(socket, room.id);
}

function roomViewForSocket(room: Room, socketId: string): RoomViewExtended {
  return roomToView(room, socketId, gameHost);
}

/** Nom del seient: el del perfil, no el suggeriment aleatori que pugui enviar el client. */
async function assignRoomPlayerName(
  room: { players: Player[] },
  playerId: string,
  requested: string | undefined,
  fallback: string,
  excludePlayerId?: string
): Promise<string> {
  const peers = room.players
    .filter((p) => p.playerId !== excludePlayerId)
    .map((p) => p.name);
  return resolveSeatDisplayName(playerId, requested, peers, fallback);
}

function stablePlayerId(clientPlayerId: unknown, playerToken?: unknown, fallbackSeed?: string): string | null {
  const resolved = resolvePlayerIdFromParts({ token: playerToken, legacyPlayerId: clientPlayerId });
  if (resolved) return resolved.playerId;

  const tokenProvided =
    playerToken !== undefined &&
    playerToken !== null &&
    !(typeof playerToken === "string" && playerToken.trim() === "");
  if (tokenProvided) return null;

  const legacy = sanitizePlayerId(clientPlayerId);
  if (legacy) return legacy;
  return `priv-human-${(fallbackSeed ?? newSeatToken()).slice(0, 24)}`;
}

/**
 * S1: identitat per a consultes de només lectura (`resume_status`). A diferència de
 * `stablePlayerId`, no s'inventa mai un id de recanvi: sense identitat vàlida no hi ha sessió.
 */
function lookupPlayerId(clientPlayerId: unknown, playerToken?: unknown): string | null {
  const resolved = resolvePlayerIdFromParts({ token: playerToken, legacyPlayerId: clientPlayerId });
  if (resolved) return resolved.playerId;
  const tokenProvided =
    playerToken !== undefined &&
    playerToken !== null &&
    !(typeof playerToken === "string" && playerToken.trim() === "");
  if (tokenProvided) return null;
  return sanitizePlayerId(clientPlayerId) || null;
}

export type ResumeStatus = {
  /** Hi ha una partida solo (normal, pràctica o torneig) en curs que `join_solo_room` reprendria. */
  solo: boolean;
  /** Mode pràctica de la partida solo reprenible (només té sentit si `solo`). */
  soloPracticeMode: boolean;
  /** El seient privat (`inviteCode` + `seatToken`) encara existeix i es pot reprendre. */
  private: boolean;
};

/**
 * S1 · Font de veritat per a «Continuar la partida». Una sortida confirmada (`leave_room`)
 * treu el jugador de la sala solo, així que aquí torna `solo: false`; una simple desconnexió
 * deixa el seient en mans d'una IA amb el mateix playerId i continua sent reprenible.
 */
export function resumeStatusFor(
  playerId: string | null,
  inviteCode?: unknown,
  seatToken?: unknown
): ResumeStatus {
  const status: ResumeStatus = { solo: false, soloPracticeMode: false, private: false };
  if (playerId) {
    const solo = rooms.get(soloRoomId(playerId));
    if (
      solo &&
      solo.soloAi &&
      solo.phase !== "waiting" &&
      !solo.matchEnded &&
      solo.players.some((p) => p.playerId === playerId)
    ) {
      status.solo = true;
      status.soloPracticeMode = solo.practiceMode === true;
    }
  }
  const code = typeof inviteCode === "string" ? inviteCode.trim().toUpperCase() : "";
  const token = typeof seatToken === "string" ? seatToken.trim() : "";
  if (playerId && code && token) {
    const room = roomByInviteCode(code);
    if (room?.isPrivate) {
      status.private = room.players.some(
        (p) => !p.isBot && p.seatToken === token && p.playerId === playerId
      );
    }
  }
  return status;
}

export async function setupGameHandlers(io: Server) {
  ioRef = io;
  if (process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD !== "1") {
    const loaded = await loadAllPrivateRooms();
    for (const [code, roomId] of loaded.inviteIndex) {
      inviteCodeToRoomId.set(code, roomId);
    }
    for (const room of loaded.rooms) {
      rooms.set(room.id, room);
      resumePacingTimers(gameHost, room);
    }
  }
  // Les sales solo viuen només a memòria: després d'un reinici, la pràctica o el torneig ràpid
  // que hi hagués en curs es refà en el mateix mode quan el client reconnecta.
  await loadSoloIsolatedSessionsOnBoot();
  // Compres solo obertes d'abans d'un reinici: les sales solo només viuen en memòria, així que
  // es retorna la compra sencera (mai es perd per un reinici a mitja partida).
  try {
    const liveIds = new Set([
      ...[...rooms.values()].map((r) => r.soloBuyIn?.id).filter(Boolean),
      ...livePublicBuyInIds(rooms.values()),
    ]);
    await refundOrphanSoloBuyIns((id) => liveIds.has(id));
  } catch (err) {
    console.error("[saldo] retorn de compres solo obertes fallit:", err);
  }

  io.on("connection", (socket: Socket) => {
    const publicOrigin = publicOriginFor(socket.handshake.headers.origin);
    if (publicOrigin) {
      socketPublicOrigins.set(socket.id, publicOrigin);
      socket.once("disconnect", () => socketPublicOrigins.delete(socket.id));
    }
    const floodBucket = createSocketEventBucket();
    socket.use((_packet, next) => {
      if (allowSocketEvent(floodBucket)) return next();
      if (!floodBucket.warned) {
        floodBucket.warned = true;
        socket.emit("game_error", { message: "Massa accions seguides. Espera un moment.", code: "RATE_LIMIT" });
      }
    });
    socket.on(
      "create_private_table",
      async (payload: unknown) => {
        if (!isSocketRecord(payload)) {
          emitBadSocketPayload(socket);
          return;
        }
        const { playerName, playerId: clientPlayerId, playerToken, houseRulesEnabled, minBet, maxBet } =
          payload as {
            playerName?: string;
            playerId?: string;
            playerToken?: string;
            houseRulesEnabled?: boolean;
            minBet?: number;
            maxBet?: number;
          };
        const wagerConfig = buildRoomWagerConfig({
          betProfileId: payload.betProfileId,
          minBet: minBet ?? DEFAULT_PRIVATE_MIN_BET,
          maxBet: maxBet ?? DEFAULT_PRIVATE_MAX_BET,
          risingBlinds: payload.risingBlinds,
        });
        if (!wagerConfig) {
          socket.emit("game_error", {
            message: "Defineix una aposta mínima i màxima vàlides (entre 1 i 1.000.000 fitxes).",
            code: "BAD_BET_LIMITS",
          });
          return;
        }
        const limits = wagerConfig.limits;
      const seatToken = newSeatToken();
      const stableId = stablePlayerId(clientPlayerId, playerToken, seatToken);
      if (!stableId) {
        socket.emit("game_error", { message: "Token de jugador invalid o caducat.", code: "BAD_TOKEN" });
        return;
      }
      const code = await resolveInviteCodeForHost(
        stableId,
        () => allocateInviteCode(),
        (c) => inviteCodeToRoomId.has(c),
      );
      const roomId = `priv-${Date.now().toString(36)}-${randomBase36(7)}`;
      const room = emptyRoomBase(roomId, `Taula ${code}`, wagerConfig.effectiveMinBet, 1000);
      applyWagerConfigToRoom(room, wagerConfig);
      room.isPrivate = true;
      room.inviteCode = code;
      room.hostSeatToken = seatToken;
      room.autoFillBots = false;
      room.soloAi = false;
      room.houseRulesEnabled = houseRulesEnabled === true;
      const deckSeed = parsePrivateDeckSeed((payload as { deckSeed?: unknown }).deckSeed);
      if (deckSeed !== null) room.testDeckSeed = deckSeed;
      room.hostMatchSettings = {
        ...defaultHostMatchSettings(),
        houseRulesEnabled: houseRulesEnabled === true,
      };
      const player: Player = {
        id: socket.id,
        playerId: stableId,
        seatToken,
        name: await assignRoomPlayerName(room, stableId, playerName, "Amfitrió"),
        chips: privateTableChips(room),
        bet: 0,
        isBanker: false,
        status: "waiting",
        handSlots: [],
        activeSlotIndex: 0,
        lastRoyal7Payout: 0,
        royal7AsBankerStreak: 0,
      };
      await assignPlayerAvatar(player);
      room.players.push(player);
      rooms.set(roomId, room);
      registerInviteCode(code, roomId);
      socket.join(roomId);
      markDealsDelivered(room, socket.id);
      await commitRoom(room);
      emitJoinedPrivateRoom(socket, room);
      trackPrivateRoom("private_room_created", room, player, false);
    },
    );

    socket.on(
      "join_private_table",
      async (payload: unknown) => {
        if (!isSocketRecord(payload)) {
          emitBadSocketPayload(socket);
          return;
        }
        const { inviteCode, playerName, seatToken, playerId: clientPlayerId, playerToken } = payload as {
          inviteCode?: string;
          playerName?: string;
          seatToken?: string;
          playerId?: string;
          playerToken?: string;
        };
        const ipKey = trustedClientIp(socket.handshake.address, socket.handshake.headers);
        if (isJoinBlocked(ipKey)) {
          socket.emit("game_error", {
            message: "Massa intents amb codis incorrectes. Torna-ho a provar d'aquí a uns minuts.",
            code: "RATE_LIMIT",
          });
          return;
        }
        const code = normalizeInviteCode(inviteCode ?? "");
        if (!code) {
          recordJoinFailure(ipKey);
          socket.emit("game_error", { message: "Codi de taula invalid.", code: "BAD_CODE" });
          return;
        }
        const room = roomByInviteCode(code);
        if (!room || !room.isPrivate) {
          recordJoinFailure(ipKey);
          socket.emit("game_error", { message: "Taula no trobada.", code: "ROOM_NOT_FOUND" });
          return;
        }

        const trimmedToken = typeof seatToken === "string" ? seatToken.trim() : "";
        if (trimmedToken) {
          const resume = room.players.find((p) => p.seatToken === trimmedToken && !p.isBot);
          if (resume) {
            const identity = resolvePlayerIdFromParts({
              token: playerToken,
              legacyPlayerId: clientPlayerId,
            });
            if (!identity || identity.playerId !== resume.playerId) {
              socket.emit("game_error", {
                message: "Token de jugador invalid per reprendre aquest seient.",
                code: "BAD_TOKEN",
              });
              return;
            }
            clearGraceTimer(resume.seatToken);
            resume.disconnectedAt = undefined;
            resume.graceUntil = undefined;
            resume.id = socket.id;
            resume.isBot = false;
            resume.name = await assignRoomPlayerName(
              room,
              resume.playerId,
              playerName,
              resume.name || "Jugador",
              resume.playerId
            );
            await assignPlayerAvatar(resume);
            socket.join(room.id);
            markDealsDelivered(room, socket.id);
            await commitRoom(room);
            emitJoinedPrivateRoom(socket, room);
            return;
          }
        }

        if (room.phase !== "waiting") {
          socket.emit("game_error", {
            message: "Partida en curs. Torna amb el mateix enllaç per reprendre el teu seient.",
            code: "GAME_IN_PROGRESS",
          });
          return;
        }
        if (room.players.length >= MAX_PRIVATE_TABLE_PLAYERS) {
          socket.emit("game_error", { message: "Sala plena.", code: "ROOM_FULL" });
          return;
        }

        const newToken = newSeatToken();
        const stableId = stablePlayerId(clientPlayerId, playerToken, newToken);
        if (!stableId) {
          socket.emit("game_error", { message: "Token de jugador invalid o caducat.", code: "BAD_TOKEN" });
          return;
        }
        const player: Player = {
          id: socket.id,
          playerId: stableId,
          seatToken: newToken,
          name: await assignRoomPlayerName(room, stableId, playerName, "Convidat"),
          chips: privateTableChips(room),
          bet: 0,
          isBanker: false,
          status: "waiting",
          handSlots: [],
          activeSlotIndex: 0,
          lastRoyal7Payout: 0,
          royal7AsBankerStreak: 0,
        };
        await assignPlayerAvatar(player);
        room.players.push(player);
        socket.join(room.id);
        markDealsDelivered(room, socket.id);
        await commitRoom(room);
        emitJoinedPrivateRoom(socket, room);
        trackPrivateRoom("private_room_joined", room, player, true);
      }
    );

    socket.on(
      "update_match_settings",
      async (payload: unknown) => {
        if (!isSocketRecord(payload)) {
          emitBadSocketPayload(socket);
          return;
        }
        const { roomId, settings, playerToken, actionSeq } = payload as {
          roomId?: string;
          settings?: unknown;
          playerToken?: string;
          actionSeq?: number;
        };
        if (typeof roomId !== "string") {
          emitBadSocketPayload(socket);
          return;
        }
        const room = rooms.get(roomId);
        const actor = room?.players.find((p) => p.id === socket.id);
        const hostOk =
          room &&
          actor &&
          (room.soloAi ? actor.playerId === room.soloHumanPlayerId : isPrivateHost(room, actor));
        if (!room || !hostOk) {
          socket.emit("game_error", { message: "Només l'amfitrió pot canviar els ajustos.", code: "NOT_HOST" });
          return;
        }
        if (room.isPrivate) {
          const authErr = authorizePrivateAction(room, actor, { playerToken, actionSeq }, { allowedPhases: ["waiting"] });
          if (authErr) {
            socket.emit("game_error", authErr);
            return;
          }
        }
        if (!canEditHostMatchSettings(room)) {
          socket.emit("game_error", {
            message: "Els ajustos només es poden canviar entre partides.",
            code: "MATCH_IN_PROGRESS",
          });
          return;
        }
        const err = applyHostMatchSettings(room, settings);
        if (err) {
          socket.emit("game_error", { message: err, code: "BAD_SETTINGS" });
          return;
        }
        await commitRoom(room);
      },
    );

    socket.on(
      "fill_private_bots",
      async (payload: string | { roomId: string; playerToken?: string; actionSeq?: number }) => {
        if (typeof payload !== "string" && !isSocketRecord(payload)) {
          emitBadSocketPayload(socket);
          return;
        }
        const roomId = typeof payload === "string" ? payload : payload.roomId;
        const meta: PrivateActionMeta =
          typeof payload === "string" ? {} : { playerToken: payload.playerToken, actionSeq: payload.actionSeq };
        const room = rooms.get(roomId);
        const host = room?.players.find((p) => p.id === socket.id);
        if (!room || !room.isPrivate || !isPrivateHost(room, host)) {
          socket.emit("game_error", { message: "Només l'amfitrió pot omplir bots.", code: "NOT_HOST" });
          return;
        }
        const authErr = authorizePrivateAction(room, host, meta, { allowedPhases: ["waiting"] });
        if (authErr) {
          socket.emit("game_error", authErr);
          return;
        }
        fillPrivateBots(room);
        await commitRoom(room);
      },
    );

    socket.on("join_solo_room", (payload: unknown) => {
      void joinSoloRoomActor(
        {
          id: socket.id,
          join: (roomId: string) => {
            void socket.join(roomId);
          },
          emit: (event: string, body?: unknown) => {
            socket.emit(event, body);
          },
        },
        payload,
      );
    });


    socket.on("quick_rematch", async (roomId: string) => {
      if (typeof roomId !== "string") {
        emitBadSocketPayload(socket);
        return;
      }
      const room = rooms.get(roomId);
      const modeOk = room?.soloAi || room?.isPrivate;
      const isMember = room?.players.some((player) => player.id === socket.id);
      if (!room || !modeOk || !isMember || room.phase !== "waiting" || !room.matchEnded) {
        socket.emit("game_error", { message: "No es pot repetir ara.", code: "BAD" });
        return;
      }
      if (!canStartGame(room)) {
        socket.emit("game_error", { message: "Calen mes jugadors.", code: "NEED_PLAYERS" });
        return;
      }
      if (roomUsesSoloBuyIn(room)) {
        const human = room.players.find((p) => p.id === socket.id)!;
        // La partida acabada ja s'ha tancat en acabar; per si de cas, es tanca ara (idempotent).
        await settleSoloBuyIn(room, human, "revenja");
        const amount = room.phaseB?.startingChips ?? privateTableChips(room);
        const opened = await openSoloBuyInForRoom(room, human.playerId, amount);
        if (!opened.ok) {
          socket.emit("game_error", insufficientBalanceError(opened.required, opened.balance));
          return;
        }
        if (room.phase !== "waiting" || !room.matchEnded) {
          // Algú ha començat una altra partida mentre es descomptava: es retorna la compra.
          await settleSoloBuyIn(room, undefined, "revenja cancel·lada");
          return;
        }
      }
      applyPhaseBRevenge(room);
      if (room.soloAi) {
        room.soloBotPresets = undefined;
        ensureSoloBots(room, room.soloBotCount ?? 1);
        ensurePhaseBMatchInitialized(room);
        applySoloBuyInChips(room);
      }
      trackGameStarted(room);
      beginGameStart(gameHost, room);
      await commitRoom(room);
    });

    /** «Següent» al full de liquidació. Payload: roomId (string) o { roomId, playerToken?, actionSeq? }. */
    socket.on("settlement_next", async (payload: unknown) => {
      if (typeof payload !== "string" && !isSocketRecord(payload)) {
        emitBadSocketPayload(socket);
        return;
      }
      const body = typeof payload === "string" ? { roomId: payload } : (payload as Record<string, unknown>);
      if (typeof body.roomId !== "string") {
        emitBadSocketPayload(socket);
        return;
      }
      const room = rooms.get(body.roomId);
      const player = room?.players.find((p) => p.id === socket.id);
      if (!room || !player || player.isBot) {
        socket.emit("game_error", { message: "Jugador no trobat a la taula.", code: "NOT_IN_ROOM" });
        return;
      }
      // Clic tardà (la mà ja ha avançat): s'ignora sense error.
      if (room.phase !== "settlement" || player.settlementAck) return;
      const authErr = authorizePrivateAction(
        room,
        player,
        { playerToken: body.playerToken, actionSeq: body.actionSeq },
        { allowedPhases: ["settlement"] }
      );
      if (authErr) {
        socket.emit("game_error", authErr);
        return;
      }
      const err = acknowledgeSettlement(gameHost, room, player);
      if (err) {
        socket.emit("game_error", { message: err, code: "NOT_IN_ROOM" });
        return;
      }
      await commitRoom(room);
    });

    socket.on("reset_session", async (roomId: string) => {
      if (typeof roomId !== "string") {
        emitBadSocketPayload(socket);
        return;
      }
      const room = rooms.get(roomId);
      const player = room?.players.find((p) => p.id === socket.id);
      if (!room || !room.soloAi || !player || player.isBot) {
        socket.emit("game_error", { message: "No es pot reiniciar la sessió ara.", code: "BAD" });
        return;
      }
      room.sessionStats.set(player.playerId, freshSessionStats());
      await commitRoom(room);
    });

    socket.on(
      "start_game",
      async (payload: string | { roomId: string; playerToken?: string; actionSeq?: number }) => {
        if (typeof payload !== "string" && !isSocketRecord(payload)) {
          emitBadSocketPayload(socket);
          return;
        }
        const roomId = typeof payload === "string" ? payload : payload.roomId;
        const meta: PrivateActionMeta =
          typeof payload === "string" ? {} : { playerToken: payload.playerToken, actionSeq: payload.actionSeq };
        const room = rooms.get(roomId);
        const actor = room?.players.find((p) => p.id === socket.id);
        if (room?.isPrivate && !isPrivateHost(room, actor)) {
          socket.emit("game_error", { message: "Només l'amfitrió pot iniciar la partida.", code: "NOT_HOST" });
          return;
        }
        if (room?.isPrivate) {
          const authErr = authorizePrivateAction(room, actor, meta, { allowedPhases: ["waiting"] });
          if (authErr) {
            socket.emit("game_error", authErr);
            return;
          }
        }
        if (!room || room.phase !== "waiting" || !canStartGame(room)) {
          socket.emit("game_error", { message: "Calen almenys 2 jugadors.", code: "NEED_PLAYERS" });
          return;
        }
        trackGameStarted(room);
        beginGameStart(gameHost, room);
        await commitRoom(room);
      },
    );

    socket.on(
      "place_bet",
      async (payload: unknown) => {
        if (!isSocketRecord(payload)) {
          emitBadSocketPayload(socket);
          return;
        }
        const { roomId, amount, playerToken, actionSeq } = payload as {
          roomId: string;
          amount: number;
          playerToken?: string;
          actionSeq?: number;
        };
        const receiptId = actionReceiptIdFromPayload(payload);
        const room = rooms.get(roomId);
        const player = room?.players.find((p) => p.id === socket.id);
        if (!room || !player) {
          socket.emit("game_error", { message: "No es pot apostar ara.", code: "BAD_PHASE", actionId: receiptId });
          return;
        }
        const applyBet = async (): Promise<
          | { ok: true; amount: number }
          | { ok: false; message: string; code: string }
        > => {
          const authErr = authorizePrivateAction(room, player, { playerToken, actionSeq }, {
            allowedPhases: ["betting", "waiting"],
          });
          if (authErr) return { ok: false, ...authErr };
          const rangeErr = betRangeError(room, player, amount);
          if (rangeErr) return { ok: false, message: rangeErr, code: "BET_RANGE" };
          const err = applyPlaceBet(room, player, amount, gameHost);
          if (err) return { ok: false, message: err, code: "BAD_PHASE" };
          await commitRoom(room);
          return { ok: true, amount: player.bet };
        };
        const result = await actionReceipts.run(`${room.id}:${player.seatToken}`, receiptId, applyBet);
        if (result.ok === false) {
          socket.emit("game_error", { message: result.message, code: result.code, actionId: receiptId });
          return;
        }
        if (receiptId) {
          socket.emit(
            "game_action_ack",
            buildGameActionAck({
              action: "place_bet",
              actionId: receiptId,
              roomId: room.id,
              amount: result.amount,
            }),
          );
        }
      },

    );

    socket.on(
      "double_bet",
      async (
        payload:
          | string
          | {
              roomId?: unknown;
              playerToken?: unknown;
              actionSeq?: unknown;
              actionId?: unknown;
              requestId?: unknown;
            },
      ) => {
        if (typeof payload !== "string" && !isSocketRecord(payload)) {
          emitBadSocketPayload(socket);
          return;
        }
        const body = typeof payload === "string" ? null : payload;
        const roomId = typeof payload === "string" ? payload : body.roomId;
        if (typeof roomId !== "string") {
          emitBadSocketPayload(socket);
          return;
        }
        const meta: PrivateActionMeta = body
          ? { playerToken: body.playerToken, actionSeq: body.actionSeq }
          : {};
        const receiptId = body ? actionReceiptIdFromPayload(body) : undefined;
        const room = rooms.get(roomId);
        const player = room?.players.find((p) => p.id === socket.id);
        if (!room || !player) {
          socket.emit("game_error", doubleGameError(ENGINE_MESSAGES.cannotDoubleNow, "NOT_IN_ROOM", receiptId));
          return;
        }
        const authErr = authorizePrivateAction(room, player, meta, {
          allowedPhases: ["playing"],
          requireTurn: true,
        });
        if (authErr) {
          socket.emit("game_error", doubleGameError(authErr.message, authErr.code, receiptId));
          return;
        }
        const err = applyDouble(gameHost, room, player.id);
        if (err) {
          const code = classifyDoubleReject(room, player.id)?.code ?? "CANNOT_DOUBLE";
          socket.emit("game_error", doubleGameError(err, code, receiptId));
        }
        await commitRoom(room);
      },
    );

    socket.on(
      "mort_action",
      async (payload: unknown) => {
        if (!isSocketRecord(payload)) {
          emitBadSocketPayload(socket);
          return;
        }
        const { roomId, accept, playerToken, actionSeq } = payload as {
          roomId: string;
          accept: boolean;
          playerToken?: string;
          actionSeq?: number;
        };
        const room = rooms.get(roomId);
        const player = room?.players.find((p) => p.id === socket.id);
        if (!room || !player) {
          socket.emit("game_error", { message: "Acció no vàlida.", code: "BAD" });
          return;
        }
        const authErr = authorizePrivateAction(room, player, { playerToken, actionSeq }, {
          allowedPhases: ["playing", "betting"],
        });
        if (authErr) {
          socket.emit("game_error", authErr);
          return;
        }
        const err = applyMort(gameHost, room, player.id, accept);
        if (err) socket.emit("game_error", { message: err, code: "BAD" });
        await commitRoom(room);
      },
    );

    // Normes de la casa: primera carta 3 o 4 → «Jugar» (swap: false) o «Canviar» (swap: true).
    socket.on(
      "swap_action",
      async (payload: unknown) => {
        if (!isSocketRecord(payload)) {
          emitBadSocketPayload(socket);
          return;
        }
        const { roomId, swap, playerToken, actionSeq } = payload as {
          roomId: string;
          swap: unknown;
          playerToken?: string;
          actionSeq?: number;
        };
        const room = rooms.get(roomId);
        const player = room?.players.find((p) => p.id === socket.id);
        if (!room || !player || typeof swap !== "boolean") {
          socket.emit("game_error", { message: "Acció no vàlida.", code: "BAD" });
          return;
        }
        const authErr = authorizePrivateAction(room, player, { playerToken, actionSeq }, {
          allowedPhases: ["playing"],
          requireTurn: true,
        });
        if (authErr) {
          socket.emit("game_error", authErr);
          return;
        }
        const err = applySwap(gameHost, room, player.id, swap);
        if (err) socket.emit("game_error", { message: err, code: "BAD" });
        await commitRoom(room);
      },
    );

    // El propietari ha mirat la carta de l'oferta: el termini passa a ser turnMs des d'ara.
    socket.on(
      "card_peeked",
      async (payload: unknown) => {
        if (!isSocketRecord(payload)) {
          emitBadSocketPayload(socket);
          return;
        }
        const { roomId, cardId, playerToken, actionSeq } = payload as {
          roomId?: string;
          cardId?: unknown;
          playerToken?: string;
          actionSeq?: number;
        };
        if (typeof roomId !== "string" || typeof cardId !== "string" || !cardId) {
          emitBadSocketPayload(socket);
          return;
        }
        const room = rooms.get(roomId);
        const player = room?.players.find((p) => p.id === socket.id);
        if (!room || !player) return;
        const authErr = authorizePrivateAction(room, player, { playerToken, actionSeq }, {
          allowedPhases: ["playing"],
          requireTurn: true,
        });
        if (authErr) {
          socket.emit("game_error", authErr);
          return;
        }
        if (!applyCardPeeked(room, player.id, cardId)) return;
        await commitRoom(room);
      },
    );

    socket.on(
      "split_hands",
      async (payload: string | { roomId: string; playerToken?: string; actionSeq?: number }) => {
        if (typeof payload !== "string" && !isSocketRecord(payload)) {
          emitBadSocketPayload(socket);
          return;
        }
        const roomId = typeof payload === "string" ? payload : payload.roomId;
        const meta: PrivateActionMeta =
          typeof payload === "string" ? {} : { playerToken: payload.playerToken, actionSeq: payload.actionSeq };
        const room = rooms.get(roomId);
        const player = room?.players.find((p) => p.id === socket.id);
        if (!room || !player) return;
        const authErr = authorizePrivateAction(room, player, meta, {
          allowedPhases: ["playing"],
          requireTurn: true,
        });
        if (authErr) {
          socket.emit("game_error", authErr);
          return;
        }
        const err = applySplit(room, player.id);
        if (err) socket.emit("game_error", { message: err, code: "BAD" });
        await commitRoom(room);
      },
    );

    socket.on(
      "flip_card",
      async (payload: unknown) => {
        if (!isSocketRecord(payload)) {
          emitBadSocketPayload(socket);
          return;
        }
        const { roomId, cardId, playerToken, actionSeq } = payload as {
          roomId: string;
          cardId: string;
          playerToken?: string;
          actionSeq?: number;
        };
        const room = rooms.get(roomId);
      const player = room?.players.find((p) => p.id === socket.id);
      if (!room || !player) return;
      const authErr = authorizePrivateAction(room, player, { playerToken, actionSeq }, {
        allowedPhases: ["playing"],
        requireTurn: true,
      });
      if (authErr) {
        socket.emit("game_error", authErr);
        return;
      }
      if (room.phase !== "playing" || currentPlayer(room) !== player) return;
      const slot = currentSlot(room);
      if (!slot || !slot.cards.some((c) => c.id === cardId)) return;
      const revealErr = applyRevealCard(room, player.id, cardId);
      if (revealErr) {
        socket.emit("game_error", { message: revealErr, code: "BAD" });
        return;
      }
      await commitRoom(room);
    },
    );

    socket.on("hit", (payload: unknown) => void onPlayerCardAction(socket, "hit", payload));
    socket.on("stand", (payload: unknown) => void onPlayerCardAction(socket, "stand", payload));

    socket.on(
      "bank_keep_choice",
      async (payload: unknown) => {
        if (!isSocketRecord(payload)) {
          emitBadSocketPayload(socket);
          return;
        }
        const { roomId, keep, playerToken, actionSeq } = payload as {
          roomId: string;
          keep: boolean;
          playerToken?: string;
          actionSeq?: number;
        };
        const room = rooms.get(roomId);
      const player = room?.players.find((p) => p.id === socket.id);
      if (!room || !player || !player.pendingBankChoice) return;
      const authErr = authorizePrivateAction(room, player, { playerToken, actionSeq }, {
        allowedPhases: ["waiting", "betting", "playing", "settlement"],
      });
      if (authErr) {
        socket.emit("game_error", authErr);
        return;
      }
      if (player.pendingBankChoice.mandatory && !keep) {
        socket.emit("game_error", {
          message: "Ara la banca és obligatòria.",
          code: "BANK_MANDATORY",
        });
      }
      resolvePendingBankChoice(room, player, keep, gameHost);
      await commitRoom(room);
    },
    );

    socket.on("send_message", (payload: unknown) => {
      handlePrivateSendMessage(io, socket, payload, (roomId) => rooms.get(roomId), () =>
        emitBadSocketPayload(socket),
      );
    });

    socket.on("send_emote", (payload: unknown) => {
      handlePrivateSendEmote(io, socket, payload, (roomId) => rooms.get(roomId), () =>
        emitBadSocketPayload(socket),
      );
    });

    /**
     * S1 · «Continuar la partida»: el client pregunta al servidor si encara hi ha sessió.
     * Payload: { playerId?, playerToken?, inviteCode?, seatToken? }. Respon amb l'event
     * `resume_status` i, si n'hi ha, amb el callback d'ack de socket.io.
     */
    socket.on("resume_status", (payload: unknown, ack?: unknown) => {
      const body = isSocketRecord(payload) ? payload : {};
      const status = resumeStatusFor(
        lookupPlayerId(body.playerId, body.playerToken),
        body.inviteCode,
        body.seatToken
      );
      socket.emit("resume_status", status);
      if (typeof ack === "function") (ack as (s: ResumeStatus) => void)(status);
    });

    socket.on("leave_room", async (roomId: string) => {
      if (typeof roomId !== "string") {
        emitBadSocketPayload(socket);
        return;
      }
      const authId = typeof socket.data?.playerId === "string" ? socket.data.playerId : "";
      let room = rooms.get(roomId);
      if (!room && authId) {
        const solo = rooms.get(soloRoomId(authId));
        if (solo) room = solo;
      }
      const lobbyChipsFor = async (playerId: string) => (await getBalance(playerId)) + lobbyHeldStack(playerId);
      if (!room) {
        socket.emit("room_left", {
          roomId,
          resumable: false,
          ...(authId ? { chips: await lobbyChipsFor(authId) } : {}),
        });
        return;
      }
      let idx = room.players.findIndex((p) => p.id === socket.id);
      if (idx === -1 && authId) idx = room.players.findIndex((p) => p.playerId === authId);
      if (idx === -1) {
        socket.emit("room_left", {
          roomId: room.id,
          resumable: false,
          ...(authId ? { chips: await lobbyChipsFor(authId) } : {}),
        });
        return;
      }
      const leaving = room.players[idx];
      // Les taules privades juguen amb fitxes de taula (privateTableChips), no amb el saldo real:
      // en sortir no es toca balances.json, igual que abans. La gràcia és només per a desconnexions.
      if (!room.isPrivate) {
        await persistRealBalanceOnLeave(room, leaving);
      }
      trackGameFinished(room, leaving.playerId, "leave");
      const wasBanker = leaving.isBanker;
      const wasHost = isPrivateHost(room, leaving);
      if (room.isPrivate) clearGraceTimer(leaving.seatToken);
      const othersHuman = room.players.some((p) => p !== leaving && !p.isBot);
      if (room.isPrivate && othersHuman) {
        // Sortida confirmada (fins i tot a mitja mà): el seient s'allibera a l'instant i la mà
        // continua de manera consistent (torn, banca i aposta) per a la resta de la taula.
        removePlayerFromHand(gameHost, room, leaving.id);
      } else {
        room.players.splice(idx, 1);
      }
      socket.leave(room.id);
      if (room.isPrivate && wasHost) {
        const nextHost = room.players.find((p) => !p.isBot);
        room.hostSeatToken = nextHost?.seatToken;
      }
      if (room.soloAi) {
        // Sortida confirmada: no hi ha cap partida de pràctica/torneig per refer.
        if (!leaving.isBot) clearSoloIsolatedSession(leaving.playerId);
        clearSoloRoomState(gameHost, room);
      } else if (room.isPrivate) {
        await destroyPrivateRoomIfEmpty(room);
      } else if (room.players.length === 0) {
        room.phase = "waiting";
        room.pot = 0;
        room.deck = [];
        room.lastRound = null;
      } else if (wasBanker) {
        room.players[0].isBanker = true;
        room.phase = "waiting";
        room.pot = 0;
        room.deck = [];
      }
      await commitRoom(room);
      // Sortida confirmada: la sessió queda tancada al servidor (S1). El saldo ja és el de després
      // de tancar la compra (a mitja mà, sense l'aposta del pot).
      socket.emit("room_left", { roomId: room.id, resumable: false, chips: await getBalance(leaving.playerId) });
    });

    socket.on("disconnect", async () => {
      for (const room of rooms.values()) {
        const idx = room.players.findIndex((p) => p.id === socket.id);
        if (idx === -1) continue;
        const leaving = room.players[idx];
        const midGame = room.phase !== "waiting" && room.phase !== "settlement";
        if (room.isPrivate && !leaving.isBot) {
          schedulePrivateDisconnectGrace(room, leaving);
          await commitRoom(room);
          continue;
        }
        if (!leaving.isBot) trackGameFinished(room, leaving.playerId, "disconnect");
        if (room.soloAi && !leaving.isBot && (room.practiceMode || room.fastTournament)) {
          markSoloIsolatedSessionLost(leaving.playerId);
        }
        if (midGame && !leaving.isBot && !room.isPrivate) {
          await persistRealBalanceOnLeave(room, leaving, { seatContinues: room.soloAi === true });
          const prevName = leaving.name;
          markAsBot(leaving, room.id, nextBotSlot(room));
          leaving.name = `${prevName.replace(/\s*IA\s*$/i, "").slice(0, 18)} IA`;
          await commitRoom(room);
          continue;
        }
        if (!room.isPrivate) {
          await persistRealBalanceOnLeave(room, leaving);
        }
        const wasBanker = leaving.isBanker;
        room.players.splice(idx, 1);
        if (room.players.length === 0) {
          room.phase = "waiting";
          room.pot = 0;
          room.deck = [];
        } else if (wasBanker && room.phase === "waiting") {
          room.players[0].isBanker = true;
          room.phase = "waiting";
        } else if (wasBanker && midGame) {
          const replacement = room.players.find((p) => p.isBot) ?? room.players[0];
          room.players.forEach((p) => {
            p.isBanker = p.id === replacement.id;
          });
        }
        if (room.isPrivate) {
          await destroyPrivateRoomIfEmpty(room);
        }
        if (room.soloAi && humanPlayers(room).length === 0) {
          clearSoloRoomState(gameHost, room);
        }
        ensureFillBots(room);
        await commitRoom(room);
      }
    });
  });
}

export type SoloRoomActor = {
  id: string;
  join: (roomId: string) => void;
  emit: (event: string, payload?: unknown) => void;
};

/** Entrada solo (socket o client HTTP). Només s'emet roomToView, mai la sala sencera. */
export async function joinSoloRoomActor(actor: SoloRoomActor, payload: unknown): Promise<void> {
  if (!isSocketRecord(payload)) {
    actor.emit("game_error", { message: "Sol·licitud invàlida.", code: "BAD_PAYLOAD" });
    return;
  }
  const { playerName, playerId, playerToken, soloResumeToken, botCount, botDifficulty, practiceMode, campaignLevel: campaignLevelRaw } = payload as {
    playerName?: string;
    playerId?: string;
    playerToken?: string;
    soloResumeToken?: string;
    botCount?: number;
    botDifficulty?: string;
    houseRulesEnabled?: boolean;
    practiceMode?: boolean;
    betProfileId?: string;
    risingBlinds?: unknown;
    fastTournament?: unknown;
    campaignLevel?: unknown;
    /** "new": partida nova explícita; no es refà cap pràctica/torneig perdut. */
    intent?: unknown;
  };
  const stableId = stablePlayerId(playerId, playerToken);
  if (!stableId) {
    actor.emit("game_error", {
      message: playerToken ? "Token de jugador invalid o caducat." : "Identitat de jugador invalida.",
      code: playerToken ? "BAD_TOKEN" : "PLAYER_ID",
    });
    return;
  }
  const rid = soloRoomId(stableId);
  // Una sola petició `join_solo_room` alhora per jugador: abans, dos «Començar» seguits (o
  // «Començar» + la reconnexió automàtica) s'encavalcaven als `await` i el segon veia un
  // seient nou amb un token que el client encara no tenia → SOLO_RESUME_REQUIRED.
  await withSoloJoinLock(rid, async () => {
  let room = rooms.get(rid);
  if (!room) {
    room = emptyRoomBase(rid, "Partida IA", 100, 1000);
    room.soloAi = true;
    room.autoFillBots = false;
    rooms.set(rid, room);
  }

  let resumePlayer = room.players.find((p) => p.playerId === stableId);
  if (resumePlayer) {
    // El mateix socket que ja té el seient (doble toc a «Començar», o una segona petició
    // abans de rebre el token al `joined_room`): és el propietari, no cal el token.
    const sameSocket = resumePlayer.id === actor.id;
    const ownerConnectedElsewhere =
      !sameSocket && ioRef?.sockets.sockets.has(resumePlayer.id) === true;
    const tokenOk =
      sameSocket || canResumeSoloSeat(resumePlayer.soloResumeToken, soloResumeToken, ownerConnectedElsewhere);
    if (!tokenOk) {
      if (ownerConnectedElsewhere) {
        // La partida és oberta en un altre dispositiu o pestanya connectada: no es pren el
        // seient, però el client rep una resposta clara (abans: SOLO_RESUME_REQUIRED i silenci).
        actor.emit("game_error", {
          message: "Ja tens aquesta partida oberta en un altre dispositiu o pestanya.",
          code: "SOLO_ACTIVE_ELSEWHERE",
        });
        return;
      }
      // Seient orfe (el seu socket ja no hi és) i el client no té el token per reprendre'l:
      // abans es responia SOLO_RESUME_REQUIRED i el client es quedava sense cap room_update.
      // Ara «Començar» fa el que diu: es descarta el seient orfe i comença una partida nova.
      // La compra solo oberta d'aquell seient (si n'hi ha) es tanca just abans de buidar la
      // sala (`settleSoloBuyIn` … "partida nova"): abonament verificat o retorn de la compra,
      // una sola vegada.
      resumePlayer = undefined;
    } else {
      // Upgrade a legacy seat after its first successful ID-only resume.
      resumePlayer.soloResumeToken ??= newSoloResumeToken();
    }
  }
  const wantsCampaign =
    campaignLevelRaw !== undefined && campaignLevelRaw !== null && campaignLevelRaw !== "";
  const parsedCampaignLevel = wantsCampaign ? parseCampaignLevelInput(campaignLevelRaw) : null;
  if (wantsCampaign && parsedCampaignLevel == null) {
    actor.emit("game_error", {
      message: "Nivell de campanya no vàlid.",
      code: "CAMPAIGN_INVALID",
    });
    return;
  }
  if (parsedCampaignLevel != null && practiceMode === true) {
    actor.emit("game_error", {
      message: "La campanya no està disponible en mode pràctica.",
      code: "CAMPAIGN_PRACTICE",
    });
    return;
  }
  if (
    parsedCampaignLevel != null &&
    normalizeFastTournamentOptions((payload as Record<string, unknown>).fastTournament)?.enabled === true
  ) {
    actor.emit("game_error", {
      message: "La campanya no està disponible en torneig ràpid.",
      code: "CAMPAIGN_TOURNAMENT",
    });
    return;
  }
  if (parsedCampaignLevel != null) {
    const progress = await getCampaignProgress(stableId);
    if (!isCampaignLevelUnlocked(progress, parsedCampaignLevel)) {
      actor.emit("game_error", {
        message: "Aquest nivell de campanya encara no està desbloquejat.",
        code: "CAMPAIGN_LOCKED",
      });
      return;
    }
  }

  // Mode demanat explícitament (pràctica, torneig, campanya o `intent: "new"`): si no és el
  // de la partida en curs, no es repren (abans «Començar» en pràctica podia tornar a la solo
  // normal en curs amb el compte enrere). Excepció: el mateix socket amb el mateix mode i cap
  // mà acabada (doble toc a «Començar»), que continua reprenent la partida acabada de crear.
  const requestedMode = requestedSoloMode(payload as Record<string, unknown>, parsedCampaignLevel);
  const modeMismatch = requestedMode !== null && requestedMode !== soloModeOfRoom(room);
  const sameSocketFreshGame =
    resumePlayer?.id === actor.id && !modeMismatch && (room.phaseB?.handsCompleted ?? 0) === 0;
  const explicitNewGame =
    modeMismatch || ((payload as Record<string, unknown>).intent === "new" && !sameSocketFreshGame);

  // Només es repren una partida en curs: mai una partida acabada (eliminat o última mà jugada).
  if (resumePlayer && room.phase !== "waiting" && !room.matchEnded && !explicitNewGame) {
    resumePlayer.id = actor.id;
    resumePlayer.isBot = false;
    resumePlayer.name = await assignRoomPlayerName(
      room,
      resumePlayer.playerId,
      playerName,
      resumePlayer.name || "Jugador",
      resumePlayer.playerId
    );
    void assignPlayerAvatar(resumePlayer);
    room.soloAi = true;
    room.soloHumanPlayerId = stableId;
    if (room.practiceMode || room.fastTournament) touchSoloIsolatedSession(stableId);
    actor.join(rid);
    markDealsDelivered(room, actor.id);
    await commitRoom(room);
    actor.emit("joined_room", roomViewForSocket(room, actor.id));
    return;
  }

  // El client, en reconnectar (p. ex. després d'un reinici del servidor), torna a enviar
  // `join_solo_room` sense el mode de la partida. Si el jugador acaba de perdre una partida
  // de pràctica o de torneig ràpid, se'n refà una de nova del mateix mode: mai una partida
  // normal amb temporitzadors i saldo real. `intent: "new"` (o un mode explícit) ho evita.
  const explicitMode =
    practiceMode === true ||
    normalizeFastTournamentOptions((payload as Record<string, unknown>).fastTournament)?.enabled === true ||
    parsedCampaignLevel != null ||
    (payload as Record<string, unknown>).intent === "new";
  const restored = explicitMode ? null : restorableSoloIsolatedSession(stableId);
  const effectivePayload: Record<string, unknown> = { ...(payload as Record<string, unknown>) };
  if (restored) {
    if (restored.mode === "fastTournament") {
      effectivePayload.fastTournament = { enabled: true };
      effectivePayload.practiceMode = false;
    } else {
      effectivePayload.practiceMode = true;
      delete effectivePayload.fastTournament;
    }
    if (restored.betProfileId !== undefined) effectivePayload.betProfileId = restored.betProfileId;
    if (restored.botCount !== undefined) effectivePayload.botCount = restored.botCount;
    if (restored.botDifficulty !== undefined) effectivePayload.botDifficulty = restored.botDifficulty;
    effectivePayload.houseRulesEnabled = restored.houseRulesEnabled === true;
    console.info(`[solo] partida ${restored.mode} perduda refeta en el mateix mode (${rid})`);
  }
  const effPracticeMode = effectivePayload.practiceMode === true;
  const effHouseRules = effectivePayload.houseRulesEnabled === true;
  const effBotCount = typeof effectivePayload.botCount === "number" ? effectivePayload.botCount : botCount;
  const effBotDifficulty =
    typeof effectivePayload.botDifficulty === "string" ? effectivePayload.botDifficulty : botDifficulty;

  // Partida nova: sempre des d'una sala neta, també si la sala era a «waiting» (final de
  // partida o entre dues mans). Abans, a «waiting» es conservaven el comptador de mans
  // (`phaseB`) i les fitxes dels bots de la partida anterior: «Començar» podia portar a la
  // mà 10/10 d'una partida vella amb 2.000 fitxes de més a la taula.
  // La partida anterior (p. ex. la que jugava la IA pel jugador desconnectat) es tanca abans.
  await settleSoloBuyIn(room, undefined, "partida nova");
  clearSoloRoomState(gameHost, room);

  room.players = room.players.filter((p) => p.isBot);
  room.soloAi = true;
  room.autoFillBots = false;
  room.soloHumanPlayerId = stableId;
  // Partida solo nova (normal, pràctica o torneig): estadístiques de sessió des de zero.
  resetSessionStats(room);
  const fastOpts = normalizeFastTournamentOptions(effectivePayload.fastTournament);
  const fastTournamentRequested = fastOpts?.enabled === true;
  room.practiceMode = effPracticeMode && !fastTournamentRequested;
  room.fastTournament = fastTournamentRequested;
  const wagerPayload: Record<string, unknown> = { ...effectivePayload };
  if (fastTournamentRequested && wagerPayload.betProfileId === undefined) {
    wagerPayload.betProfileId = "mitja";
    wagerPayload.fastTournament = { enabled: true };
  }
  const wagerErr = applyOptionalRoomWagerConfig(room, wagerPayload);
  if (wagerErr) {
    actor.emit("game_error", { message: wagerErr, code: "BAD_WAGER_CONFIG" });
    return;
  }
  room.houseRulesEnabled = effHouseRules;
  room.hostMatchSettings = {
    ...defaultHostMatchSettings(),
    houseRulesEnabled: effHouseRules,
  };
  if (parsedCampaignLevel != null) {
    const campaignDef = getCampaignLevel(parsedCampaignLevel)!;
    applyCampaignLevelToSoloRoom(room, campaignDef);
  } else {
    const level = effBotDifficulty ?? "";
    room.botDifficulty = isBotDifficulty(level) ? level : DEFAULT_BOT_DIFFICULTY;
  }
  // Cap còpia del saldo real en seure (ni en pràctica, ni en torneig, ni en solo normal): en
  // sortir mai es restaura una còpia antiga que trepitjaria els pagaments fets mentrestant.
  room.soloRealBalances?.delete(stableId);
  if (roomUsesSoloBuyIn(room)) {
    // Compra d'entrada: es descompta del saldo real ara (atòmic, mai negatiu).
    const opened = await openSoloBuyInForRoom(room, stableId, privateTableChips(room));
    if (!opened.ok) {
      actor.emit("game_error", insufficientBalanceError(opened.required, opened.balance));
      return;
    }
  }
  const player: Player = {
    id: actor.id,
    playerId: stableId,
    seatToken: newSeatToken(),
    soloResumeToken: newSoloResumeToken(),
    name: await assignRoomPlayerName(room, stableId, playerName, "Jugador"),
    chips: privateTableChips(room),
    bet: 0,
    isBanker: false,
    status: "waiting",
    handSlots: [],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
  };
  await assignPlayerAvatar(player);
  room.players.unshift(player);
  if (parsedCampaignLevel == null) {
    ensureSoloBots(room, effBotCount ?? 3);
  }
  if (room.practiceMode || room.fastTournament) {
    markSoloIsolatedSessionActive(stableId, {
      mode: room.practiceMode ? "practice" : "fastTournament",
      botCount: typeof effBotCount === "number" ? effBotCount : undefined,
      botDifficulty: room.botDifficulty,
      houseRulesEnabled: effHouseRules,
      betProfileId: typeof wagerPayload.betProfileId === "string" ? wagerPayload.betProfileId : undefined,
    });
  } else {
    clearSoloIsolatedSession(stableId);
  }
  // Fitxes i comptador de mans de partida nova ara mateix (abans d'esperar res): la vista
  // inicial ja suma el total correcte i cap temporitzador antic no pot reaprofitar l'estat.
  room.phaseB = undefined;
  room.matchEnded = false;
  room.matchResult = null;
  ensurePhaseBMatchInitialized(room);
  // Compra parcial (saldo < compra completa): el jugador seu amb les fitxes que ha pagat.
  applySoloBuyInChips(room);
  for (const seat of room.players) {
    if (seat.isBot && !seat.avatar) await assignPlayerAvatar(seat);
  }
  actor.join(rid);
  markDealsDelivered(room, actor.id);
  await commitRoom(room);
  actor.emit("joined_room", roomViewForSocket(room, actor.id));
  if (canStartGame(room)) {
    trackGameStarted(room, { restart: true });
    const startingRoom = room;
    gameHost.schedule(() => {
      if (startingRoom.phase === "waiting" && !startingRoom.matchEnded) beginGameStart(gameHost, startingRoom);
    }, SOLO_START_DELAY_MS);
  }
  });
}

export type SoloActionError = {
  message: string;
  code: string;
  required?: number;
  balance?: number;
  actionId?: string;
};

export type SoloActionResult = {
  view: RoomViewExtended | null;
  error: SoloActionError | null;
};

/** `game_error` d'un doblar rebutjat. `actionId` només si el client n'ha enviat un de vàlid. */
function doubleGameError(message: string, code: string, actionId: string | undefined) {
  return actionId ? { message, code, actionId } : { message, code };
}

function soloActionError(action: string, body: Record<string, unknown>, error: SoloActionError): SoloActionError {
  if (action !== "double_bet") return error;
  const actionId = actionReceiptIdFromPayload(body);
  return actionId ? { ...error, actionId } : error;
}

function soloSeat(playerId: string): { room: Room; player: Player } | null {
  const room = rooms.get(soloRoomId(playerId));
  if (!room?.soloAi) return null;
  const player = room.players.find((p) => !p.isBot && p.playerId === playerId);
  if (!player) return null;
  return { room, player };
}

/** Vista que pot sortir cap al client: roomToView, sense mazo ni cartes tapades amb valor. */
export function authoritativeSoloView(playerId: string): RoomViewExtended | null {
  const found = soloSeat(playerId);
  if (!found) return null;
  return roomToView(found.room, found.player.id, gameHost);
}

function soloActionPhaseOpts(
  action: string,
): { requireTurn?: boolean; allowedPhases?: Room["phase"][] } | null {
  switch (action) {
    case "hit":
    case "stand":
      return { allowedPhases: ["playing", "banker"], requireTurn: true };
    case "double_bet":
    case "split_hands":
    case "swap_action":
    case "flip_card":
    case "card_peeked":
      return { allowedPhases: ["playing"], requireTurn: true };
    case "mort_action":
      return { allowedPhases: ["playing", "betting"] };
    case "place_bet":
      return { allowedPhases: ["betting", "waiting"] };
    case "settlement_next":
      return { allowedPhases: ["settlement"] };
    case "bank_keep_choice":
      return { allowedPhases: ["waiting", "betting", "playing", "settlement"] };
    case "quick_rematch":
      return { allowedPhases: ["waiting"] };
    default:
      return null;
  }
}

/** Seient solo, també si la IA l'ha agafat després d'una desconnexió (cal poder tancar la compra). */
function soloSeatForLeave(playerId: string): { room: Room; player: Player } | null {
  const room = rooms.get(soloRoomId(playerId));
  if (!room?.soloAi) return null;
  const player = room.players.find((p) => p.playerId === playerId);
  if (!player) return null;
  return { room, player };
}

export async function leaveAuthoritativeSolo(playerId: string, seatToken?: string): Promise<boolean> {
  const found = soloSeatForLeave(playerId);
  if (!found) return false;
  // El jugador ja està autenticat. Un token de seient que no coincideix (vista antiga, seient
  // passat a la IA) no ha de deixar les 2.000 retingudes.
  void seatToken;
  await persistRealBalanceOnLeave(found.room, found.player);
  clearSoloIsolatedSession(playerId);
  clearSoloRoomState(gameHost, found.room);
  await commitRoom(found.room);
  return true;
}

/** Accions del client prim. La resposta és sempre la vista filtrada, mai la sala. */
export async function applyAuthoritativeSoloAction(
  playerId: string,
  action: string,
  body: Record<string, unknown>,
  meta: { playerToken: string; actionSeq: number },
): Promise<SoloActionResult> {
  const found = soloSeat(playerId);
  if (!found) {
    return { view: null, error: { message: "Jugador no trobat a la taula.", code: "NOT_IN_ROOM" } };
  }
  const { room, player } = found;
  const opts = soloActionPhaseOpts(action);
  if (!opts) {
    return {
      view: roomToView(room, player.id, gameHost),
      error: { message: "Acció no vàlida.", code: "BAD" },
    };
  }
  const fail = (error: SoloActionError): SoloActionResult => ({
    view: roomToView(room, player.id, gameHost),
    error,
  });

  if (action === "place_bet") {
    const amount = body.amount;
    const receiptId = isActionReceiptId(body.actionId) ? body.actionId : undefined;
    const result = await actionReceipts.run(`${room.id}:${player.seatToken}`, receiptId, async () => {
      const authErr = authorizeSoloClientAction(room, player, meta, opts);
      if (authErr) return { ok: false as const, ...authErr };
      if (typeof amount !== "number" || !Number.isFinite(amount)) {
        return { ok: false as const, message: "Aposta no vàlida.", code: "BAD" };
      }
      const rangeErr = betRangeError(room, player, amount);
      if (rangeErr) return { ok: false as const, message: rangeErr, code: "BET_RANGE" };
      const err = applyPlaceBet(room, player, amount, gameHost);
      if (err) return { ok: false as const, message: err, code: "BAD_PHASE" };
      await commitRoom(room);
      return { ok: true as const };
    });
    if (result.ok === false) return fail(result);
    return { view: roomToView(room, player.id, gameHost), error: null };
  }

  if (action === "settlement_next" && (room.phase !== "settlement" || player.settlementAck)) {
    return { view: roomToView(room, player.id, gameHost), error: null };
  }
  if (action === "bank_keep_choice" && !player.pendingBankChoice) {
    return { view: roomToView(room, player.id, gameHost), error: null };
  }

  const authErr = authorizeSoloClientAction(room, player, meta, opts);
  if (authErr) return fail(soloActionError(action, body, authErr));

  if (action === "hit") {
    const err = applyHit(gameHost, room, player.id);
    if (err) return fail({ message: err, code: "BAD_TURN" });
  } else if (action === "stand") {
    const err = applyStand(gameHost, room, player.id);
    if (err) return fail({ message: err, code: "BAD_TURN" });
  } else if (action === "double_bet") {
    const err = applyDouble(gameHost, room, player.id);
    if (err) {
      const code = classifyDoubleReject(room, player.id)?.code ?? "CANNOT_DOUBLE";
      return fail(soloActionError(action, body, { message: err, code }));
    }
  } else if (action === "split_hands") {
    const err = applySplit(room, player.id);
    if (err) return fail({ message: err, code: "BAD" });
  } else if (action === "mort_action") {
    const err = applyMort(gameHost, room, player.id, body.accept === true);
    if (err) return fail({ message: err, code: "BAD" });
  } else if (action === "swap_action") {
    if (typeof body.swap !== "boolean") return fail({ message: "Acció no vàlida.", code: "BAD" });
    const err = applySwap(gameHost, room, player.id, body.swap);
    if (err) return fail({ message: err, code: "BAD" });
  } else if (action === "card_peeked") {
    if (typeof body.cardId !== "string" || !body.cardId) return fail({ message: "Acció no vàlida.", code: "BAD" });
    if (!applyCardPeeked(room, player.id, body.cardId)) {
      return { view: roomToView(room, player.id, gameHost), error: null };
    }
  } else if (action === "flip_card") {
    if (typeof body.cardId !== "string" || !body.cardId) return fail({ message: "Acció no vàlida.", code: "BAD" });
    if (room.phase !== "playing" || currentPlayer(room) !== player) {
      return { view: roomToView(room, player.id, gameHost), error: null };
    }
    const revealErr = applyRevealCard(room, player.id, body.cardId);
    if (revealErr) return fail({ message: revealErr, code: "BAD" });
  } else if (action === "bank_keep_choice") {
    const keep = body.keep === true;
    if (player.pendingBankChoice?.mandatory && !keep) {
      return fail({ message: "Ara la banca és obligatòria.", code: "BANK_MANDATORY" });
    }
    resolvePendingBankChoice(room, player, keep, gameHost);
  } else if (action === "settlement_next") {
    const err = acknowledgeSettlement(gameHost, room, player);
    if (err) return fail({ message: err, code: "NOT_IN_ROOM" });
  } else if (action === "quick_rematch") {
    if (room.phase !== "waiting" || !room.matchEnded) {
      return fail({ message: "No es pot repetir ara.", code: "BAD" });
    }
    if (!canStartGame(room)) return fail({ message: "Calen mes jugadors.", code: "NEED_PLAYERS" });
    if (roomUsesSoloBuyIn(room)) {
      await settleSoloBuyIn(room, player, "revenja");
      const amount = room.phaseB?.startingChips ?? privateTableChips(room);
      const opened = await openSoloBuyInForRoom(room, player.playerId, amount);
      if (!opened.ok) return fail(insufficientBalanceError(opened.required, opened.balance));
      if (room.phase !== "waiting" || !room.matchEnded) {
        await settleSoloBuyIn(room, undefined, "revenja cancel·lada");
        return { view: roomToView(room, player.id, gameHost), error: null };
      }
    }
    applyPhaseBRevenge(room);
    room.soloBotPresets = undefined;
    ensureSoloBots(room, room.soloBotCount ?? 1);
    ensurePhaseBMatchInitialized(room);
    applySoloBuyInChips(room);
    trackGameStarted(room);
    beginGameStart(gameHost, room);
  }

  await commitRoom(room);
  return { view: roomToView(room, player.id, gameHost), error: null };
}

export { roomToView, type Room, type Player };

/** Test helpers */
export function resetGameStateForTests() {
  hostTimersPausedForTests = false;
  for (const room of rooms.values()) clearRoomTimers(gameHost, room);
  for (const t of pendingHostTimers) clearTimeout(t);
  pendingHostTimers.clear();
  rooms.clear();
  emitsInFlight.clear();
  settlementDelivered.clear();
  dealsDelivered.clear();
  inviteCodeToRoomId.clear();
  actionReceipts.clear();
  for (const t of graceTimers.values()) clearTimeout(t);
  graceTimers.clear();
  resetPrivateRoomStoreCacheForTests();
  resetSocialChatForTests();
  resetSoloIsolatedSessionsForTests();
}

export async function reloadPrivateRoomsFromDisk() {
  const loaded = await loadAllPrivateRooms();
  for (const [code, roomId] of loaded.inviteIndex) {
    inviteCodeToRoomId.set(code, roomId);
  }
  for (const room of loaded.rooms) {
    rooms.set(room.id, room);
    resumePacingTimers(gameHost, room);
  }
}

/**
 * Test helper: seu el socket `socketId` a una taula pública (la crea si cal) amb compra d'entrada.
 * Avui no hi ha cap esdeveniment de client per seure a una taula pública.
 */
export async function seatPublicPlayerForTests(
  roomId: string,
  socketId: string,
  playerId: string,
  name: string,
  buyIn = PHASE_B_START_CHIPS
): Promise<Room> {
  let room = rooms.get(roomId);
  if (!room) {
    room = emptyRoomBase(roomId, "Taula pública", 100, 1000);
    room.soloAi = false;
    room.isPrivate = false;
    room.autoFillBots = false;
    rooms.set(roomId, room);
  }
  const player: Player = {
    id: socketId,
    playerId,
    seatToken: newSeatToken(),
    name,
    chips: 0,
    bet: 0,
    isBanker: room.players.length === 0,
    status: "waiting",
    handSlots: [],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
  };
  const opened = await seatPublicPlayerWithBuyIn(room, player, buyIn);
  if (!opened.ok) throw new Error("saldo 0");
  room.players.push(player);
  ioRef?.sockets.sockets.get(socketId)?.join(roomId);
  return room;
}

export function getGameHostForTests(): GameHost {
  return gameHost;
}

export function getRoomSnapshotForTests(roomId: string): Room | undefined {
  return rooms.get(roomId);
}

/**
 * Fitxes de taula que el vestíbul ha de sumar al saldo gastable.
 * Només si la compra segueix oberta i el jugador no és a la taula (desconnectat o client HTTP
 * que ja no té el seient connectat). Amb el socket a la sala, el vestíbul mostra el gastable.
 */
export function lobbyHeldStack(playerId: string): number {
  if (!playerId) return 0;
  let extra = 0;
  for (const room of rooms.values()) {
    const open = room.soloBuyIn?.playerId === playerId || room.realBuyIns?.[playerId] != null;
    if (!open) continue;
    const seat = room.players.find((p) => p.playerId === playerId);
    if (!seat) continue;
    const atTable = !seat.isBot && ioRef?.sockets.sockets.has(seat.id) === true;
    if (atTable) continue;
    extra += Math.max(0, Math.floor(seat.chips)) + Math.max(0, Math.floor(seat.bet));
  }
  return extra;
}

/** Recomptes agregats per a /api/health (sense ids ni noms). */
export function getGameCountsForHealth(): GameCounts {
  const counts: GameCounts = { ...EMPTY_GAME_COUNTS };
  for (const room of rooms.values()) {
    counts.rooms += 1;
    if (room.phase !== "waiting") counts.activeGames += 1;
    if (room.isPrivate) counts.privateRooms += 1;
    if (room.soloAi) counts.soloRooms += 1;
    for (const p of room.players) {
      if (p.isBot) {
        counts.bots += 1;
      } else {
        counts.humanPlayers += 1;
        if (!p.id.startsWith("offline-")) counts.connectedHumans += 1;
      }
    }
  }
  counts.sockets = ioRef?.engine?.clientsCount ?? 0;
  return counts;
}

registerAuthoritativeSoloRuntime({
  join: joinSoloRoomActor,
  action: applyAuthoritativeSoloAction,
  view: authoritativeSoloView,
  leave: leaveAuthoritativeSolo,
});
