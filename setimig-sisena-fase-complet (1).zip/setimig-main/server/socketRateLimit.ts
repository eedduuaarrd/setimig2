/**
 * Per-socket flood guard for all client→server events (game actions, joins, chat…).
 * Generous enough for real play (a human acts ~1×/s), but drops scripted floods
 * before they reach the game engine. Chat keeps its own stricter per-player limit.
 */
export const SOCKET_EVENT_WINDOW_MS = 10_000;
export const SOCKET_EVENT_MAX = 60;

function defaultMax(): number {
  // Unit/integration tests replay whole hands in milliseconds on one socket.
  return process.env.SETIMIG_TEST_FAST === "1" ? 5_000 : SOCKET_EVENT_MAX;
}

export interface SocketEventBucket {
  windowStart: number;
  count: number;
  warned: boolean;
}

export function createSocketEventBucket(now = Date.now()): SocketEventBucket {
  return { windowStart: now, count: 0, warned: false };
}

/** Returns true when the event may proceed. Fixed window, O(1) per event. */
export function allowSocketEvent(
  bucket: SocketEventBucket,
  now = Date.now(),
  max = defaultMax(),
  windowMs = SOCKET_EVENT_WINDOW_MS,
): boolean {
  if (now - bucket.windowStart >= windowMs) {
    bucket.windowStart = now;
    bucket.count = 0;
    bucket.warned = false;
  }
  bucket.count += 1;
  return bucket.count <= max;
}
