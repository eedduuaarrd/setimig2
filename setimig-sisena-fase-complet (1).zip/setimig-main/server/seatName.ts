import { uniqueDisplayNameInRoom } from "../shared/playerNames.ts";
import { getProfile, normalizeDisplayName } from "./profiles.ts";

/**
 * Nom del seient humà.
 *
 * La font és el perfil (`data/profiles/<id>.json` → `displayName`). El nom que envia el
 * client (sovint el suggeriment aleatori de la porta, p. ex. «Núria») només es fa servir
 * si el perfil encara no en té cap de triat. «Jugador» és el buit del servidor, no un nom.
 */
export async function resolveSeatDisplayName(
  playerId: string,
  requested: string | undefined,
  existingNames: string[],
  fallback: string
): Promise<string> {
  let fromProfile = "";
  try {
    const profile = await getProfile(playerId);
    const stored = profile ? normalizeDisplayName(profile.displayName) : "";
    if (stored && stored !== "Jugador") fromProfile = stored;
  } catch {
    fromProfile = "";
  }
  const fromClient = typeof requested === "string" ? requested.trim().slice(0, 24) : "";
  const chosen = fromProfile || (fromClient && fromClient !== "Jugador" ? fromClient : "");
  return uniqueDisplayNameInRoom(existingNames, chosen, fallback);
}
