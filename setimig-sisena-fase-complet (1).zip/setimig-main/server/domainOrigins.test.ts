import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { createServer, type Server as HttpServer } from "node:http";
import type { AddressInfo } from "node:net";
import express from "express";
import { Server } from "socket.io";
import { io as ioClient } from "socket.io-client";
import {
  apiCorsMiddleware,
  configuredAllowedOrigins,
  defaultPublicOrigin,
  domainKindForHost,
  isAllowedOrigin,
  publicOriginFor,
  socketIoOriginOptions,
} from "./allowedOrigins.ts";
import { privateShareUrl } from "./privateRooms.ts";

const PROD = { NODE_ENV: "production", APP_URL: "https://setimig.supercbb.com" };

describe("llista d'orígens permesos (sevenhalf.club)", () => {
  it("per defecte inclou els dos dominis nous i l'antic", () => {
    const list = configuredAllowedOrigins(PROD);
    for (const o of ["https://sevenhalf.club", "https://www.sevenhalf.club", "https://setimig.supercbb.com"]) {
      assert.ok(list.includes(o), o);
      assert.equal(isAllowedOrigin(o, "irrellevant", PROD), true, o);
    }
  });

  it("rebutja orígens desconeguts, http al domini bo i subdominis falsos", () => {
    for (const o of [
      "https://evil.example",
      "http://sevenhalf.club",
      "https://sevenhalf.club.evil.example",
      "https://evilsevenhalf.club",
      "null",
      "not a url",
    ]) {
      assert.equal(isAllowedOrigin(o, "127.0.0.1:4450", PROD), false, o);
    }
  });

  it("sense Origin (no navegador) i mateix origen es permeten", () => {
    assert.equal(isAllowedOrigin(undefined, "x", PROD), true);
    assert.equal(isAllowedOrigin("http://127.0.0.1:3190", "127.0.0.1:3190", PROD), true);
    assert.equal(isAllowedOrigin("http://127.0.0.1:3190", "127.0.0.1:3191", PROD), false);
  });

  it("localhost només fora de producció", () => {
    assert.equal(isAllowedOrigin("http://localhost:5173", "localhost:3000", { NODE_ENV: "development" }), true);
    assert.equal(isAllowedOrigin("http://localhost:5173", "localhost:3000", PROD), false);
  });

  it("ALLOWED_ORIGINS substitueix la llista, però APP_URL sempre hi és", () => {
    const env = { ...PROD, ALLOWED_ORIGINS: "https://sevenhalf.club, https://beta.sevenhalf.club/" };
    assert.deepEqual(configuredAllowedOrigins(env), [
      "https://sevenhalf.club",
      "https://beta.sevenhalf.club",
      "https://setimig.supercbb.com",
    ]);
    assert.equal(isAllowedOrigin("https://www.sevenhalf.club", "x", env), false);
  });

  it("enllaços d'invitació amb el domini del jugador, o APP_URL per defecte", () => {
    assert.equal(publicOriginFor("https://www.sevenhalf.club", PROD), "https://www.sevenhalf.club");
    assert.equal(publicOriginFor("https://evil.example", PROD), null);
    assert.equal(publicOriginFor("http://localhost:3000", { NODE_ENV: "development" }), null);
    assert.equal(defaultPublicOrigin(PROD), "https://setimig.supercbb.com");
    assert.equal(defaultPublicOrigin({}), "https://setimig.supercbb.com");
    assert.equal(
      privateShareUrl(publicOriginFor("https://sevenhalf.club", PROD) ?? "", "AB12C"),
      "https://sevenhalf.club/t/AB12C",
    );
  });

  it("classifica els hosts per a la mètrica", () => {
    assert.equal(domainKindForHost("setimig.supercbb.com"), "old");
    assert.equal(domainKindForHost("sevenhalf.club"), "new");
    assert.equal(domainKindForHost("www.sevenhalf.club:443"), "new");
    assert.equal(domainKindForHost("127.0.0.1:4450"), "other");
  });
});

describe("socket.io i CORS de /api amb la llista d'orígens", () => {
  let http: HttpServer;
  let io: Server;
  let base = "";

  before(async () => {
    const app = express();
    app.use(apiCorsMiddleware(PROD));
    app.get("/api/ping", (_req, res) => res.json({ ok: true }));
    http = createServer(app);
    io = new Server(http, socketIoOriginOptions(PROD));
    await new Promise<void>((r) => http.listen(0, "127.0.0.1", () => r()));
    base = `http://127.0.0.1:${(http.address() as AddressInfo).port}`;
  });

  after(async () => {
    io.close();
    await new Promise<void>((r) => http.close(() => r()));
  });

  function connectWithOrigin(origin?: string): Promise<"connected" | "rejected"> {
    return new Promise((resolve) => {
      const s = ioClient(base, {
        transports: ["polling"],
        reconnection: false,
        timeout: 3000,
        extraHeaders: origin ? { origin } : {},
      });
      s.on("connect", () => {
        s.close();
        resolve("connected");
      });
      s.on("connect_error", () => {
        s.close();
        resolve("rejected");
      });
    });
  }

  it("accepta sevenhalf.club, www i setimig.supercbb.com", async () => {
    for (const o of ["https://sevenhalf.club", "https://www.sevenhalf.club", "https://setimig.supercbb.com"]) {
      assert.equal(await connectWithOrigin(o), "connected", o);
    }
  });

  it("accepta clients sense Origin (tests, scripts)", async () => {
    assert.equal(await connectWithOrigin(), "connected");
  });

  it("rebutja un origen no permès", async () => {
    assert.equal(await connectWithOrigin("https://evil.example"), "rejected");
  });

  it("CORS de /api: capçaleres només per a orígens permesos; preflight desconegut -> 403", async () => {
    const ok = await fetch(`${base}/api/ping`, { headers: { origin: "https://sevenhalf.club" } });
    assert.equal(ok.headers.get("access-control-allow-origin"), "https://sevenhalf.club");
    assert.equal(ok.headers.get("vary"), "Origin");

    const bad = await fetch(`${base}/api/ping`, { headers: { origin: "https://evil.example" } });
    assert.equal(bad.headers.get("access-control-allow-origin"), null);

    const pre = await fetch(`${base}/api/ping`, {
      method: "OPTIONS",
      headers: { origin: "https://www.sevenhalf.club", "access-control-request-method": "POST" },
    });
    assert.equal(pre.status, 204);
    assert.equal(pre.headers.get("access-control-allow-origin"), "https://www.sevenhalf.club");

    const preBad = await fetch(`${base}/api/ping`, {
      method: "OPTIONS",
      headers: { origin: "https://evil.example", "access-control-request-method": "POST" },
    });
    assert.equal(preBad.status, 403);
  });
});
