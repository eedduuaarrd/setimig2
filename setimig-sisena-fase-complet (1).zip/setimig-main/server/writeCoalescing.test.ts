import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import { spawn } from "node:child_process";
import fs from "fs/promises";
import os from "os";
import path from "path";
import { pathToFileURL } from "url";
import {
  creditCheckoutSession,
  flushBalanceWrites,
  resetBalanceStoreCacheForTests,
  setBalance,
} from "./balances.ts";
import { addWeeklyChipsWon, flushWeeklyWrites, resetEngagementCacheForTests } from "./achievementsStore.ts";
import { getWriteCounts, resetWriteCounts } from "./writeCoalescing.ts";

const DATA_ROOT = path.join(os.tmpdir(), `setimig-coalesce-${process.pid}`);

async function readJson(p: string): Promise<any> {
  return JSON.parse(await fs.readFile(p, "utf8"));
}

describe("escriptures agrupades", () => {
  before(async () => {
    process.env.BALANCE_DATA_DIR = DATA_ROOT;
    process.env.SETIMIG_WRITE_COALESCE_MS = "300";
    await fs.mkdir(DATA_ROOT, { recursive: true });
    resetBalanceStoreCacheForTests();
    resetEngagementCacheForTests();
  });

  after(async () => {
    await flushBalanceWrites().catch(() => undefined);
    await flushWeeklyWrites().catch(() => undefined);
    resetBalanceStoreCacheForTests();
    resetEngagementCacheForTests();
    delete process.env.SETIMIG_WRITE_COALESCE_MS;
    delete process.env.BALANCE_DATA_DIR;
    await fs.rm(DATA_ROOT, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 });
  });

  it("balances.json: 50 canvis seguits → poques escriptures, i res es perd", async () => {
    resetWriteCounts();
    for (let i = 1; i <= 50; i++) await setBalance("coalesceplayer01", 1000 + i);
    assert.ok((getWriteCounts()["balances.json"] ?? 0) <= 1, JSON.stringify(getWriteCounts()));
    await new Promise((r) => setTimeout(r, 600));
    const onDisk = await readJson(path.join(DATA_ROOT, "balances.json"));
    assert.equal(onDisk.accounts.coalesceplayer01.chips, 1050);
    assert.ok((getWriteCounts()["balances.json"] ?? 0) <= 2);
    await assert.rejects(fs.access(path.join(DATA_ROOT, "balances.json.tmp")));
  });

  it("flushBalanceWrites escriu immediatament els canvis pendents", async () => {
    await setBalance("coalesceplayer02", 777);
    await flushBalanceWrites();
    const onDisk = await readJson(path.join(DATA_ROOT, "balances.json"));
    assert.equal(onDisk.accounts.coalesceplayer02.chips, 777);
  });

  it("els pagaments (Stripe) s'escriuen a l'acte, sense esperar l'agrupació", async () => {
    await setBalance("coalesceplayer03", 100);
    await creditCheckoutSession("cs_coalesce_1", "coalesceplayer03", 500);
    const onDisk = await readJson(path.join(DATA_ROOT, "balances.json"));
    assert.equal(onDisk.accounts.coalesceplayer03.chips, 600);
    assert.ok(onDisk.processedSessions.includes("cs_coalesce_1"));
  });

  it("rànquing setmanal: agrupa i després escriu la suma correcta", async () => {
    resetWriteCounts();
    for (let i = 0; i < 20; i++) await addWeeklyChipsWon("2026-W44", "coalesceplayer01", 10);
    assert.ok((getWriteCounts()["weekly-leaderboard"] ?? 0) <= 1);
    await flushWeeklyWrites();
    const onDisk = await readJson(path.join(DATA_ROOT, "weekly-leaderboard", "2026-W44.json"));
    assert.equal(onDisk.chipsWon.coalesceplayer01, 200);
  });

  for (const mode of ["SIGTERM", "SIGINT", "exit"] as const) {
    it(`apagada (${mode}): es guarden els canvis pendents`, async () => {
      const dir = path.join(DATA_ROOT, `shutdown-${mode}`);
      await fs.mkdir(dir, { recursive: true });
      const here = path.dirname(new URL(import.meta.url).pathname);
      const script = path.join(dir, "child.mts");
      await fs.writeFile(
        script,
        `
import { setBalance } from ${JSON.stringify(pathToFileURL(path.join(here, "balances.ts")).href)};
import { addWeeklyChipsWon } from ${JSON.stringify(pathToFileURL(path.join(here, "achievementsStore.ts")).href)};
import { installShutdownFlush } from ${JSON.stringify(pathToFileURL(path.join(here, "writeCoalescing.ts")).href)};
installShutdownFlush();
await setBalance("shutdownplayer01", 4242);
await addWeeklyChipsWon("2026-W44", "shutdownplayer01", 99);
if (${JSON.stringify(mode)} === "exit") process.exit(0);
console.log("ready");
setInterval(() => {}, 1000);
`
      );
      const child = spawn(process.execPath, ["--import", "tsx", script], {
        cwd: process.cwd(),
        env: { ...process.env, BALANCE_DATA_DIR: dir, SETIMIG_WRITE_COALESCE_MS: "10000" },
        stdio: ["ignore", "pipe", "pipe"],
      });
      let stderr = "";
      child.stderr.on("data", (d) => (stderr += d));
      if (mode !== "exit") {
        await new Promise<void>((resolve, reject) => {
          const t = setTimeout(() => reject(new Error(`no ready: ${stderr}`)), 20_000);
          child.stdout.on("data", (d) => {
            if (String(d).includes("ready")) {
              clearTimeout(t);
              resolve();
            }
          });
        });
        // Encara no s'ha escrit res (agrupació de 10 s).
        await assert.rejects(fs.access(path.join(dir, "balances.json")));
        child.kill(mode);
      }
      const code = await new Promise<number | null>((resolve) => child.on("exit", (c) => resolve(c)));
      assert.equal(code, 0, stderr);
      const bal = await readJson(path.join(dir, "balances.json"));
      assert.equal(bal.accounts.shutdownplayer01.chips, 4242);
      const weekly = await readJson(path.join(dir, "weekly-leaderboard", "2026-W44.json"));
      assert.equal(weekly.chipsWon.shutdownplayer01, 99);
    });
  }
});
