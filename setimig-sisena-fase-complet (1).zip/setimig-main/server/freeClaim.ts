import {
  DEFAULT_CHIPS,
  getAccountEntry,
  runBalanceTransaction,
  type BalanceAccount,
} from "./balances";

export const FREE_CLAIM_CHIPS = 10_000;
export const FREE_CLAIM_INTERVAL_MS = 4 * 60 * 60 * 1000;

export type FreeClaimStatus = {
  claimable: boolean;
  nextClaimAt: number | null;
  secondsUntilClaim: number;
  amount: number;
};

export function freeClaimStatusForAccount(
  entry: BalanceAccount | undefined,
  nowMs: number = Date.now()
): FreeClaimStatus {
  const lastClaimAt = entry?.lastClaimAt ?? null;
  if (lastClaimAt == null || !Number.isFinite(lastClaimAt)) {
    return { claimable: true, nextClaimAt: null, secondsUntilClaim: 0, amount: FREE_CLAIM_CHIPS };
  }
  const nextClaimAt = lastClaimAt + FREE_CLAIM_INTERVAL_MS;
  if (nowMs >= nextClaimAt) {
    return { claimable: true, nextClaimAt, secondsUntilClaim: 0, amount: FREE_CLAIM_CHIPS };
  }
  const secondsUntilClaim = Math.ceil((nextClaimAt - nowMs) / 1000);
  return { claimable: false, nextClaimAt, secondsUntilClaim, amount: FREE_CLAIM_CHIPS };
}

export type ClaimFreeChipsResult =
  | {
      ok: true;
      chips: number;
      credited: number;
      freeClaim: FreeClaimStatus;
      lastClaimAt: number;
    }
  | {
      ok: false;
      code: "TOO_SOON";
      chips: number;
      freeClaim: FreeClaimStatus;
    };

export async function getFreeClaimStatus(playerId: string, nowMs: number = Date.now()): Promise<FreeClaimStatus> {
  const entry = await getAccountEntry(playerId);
  return freeClaimStatusForAccount(entry, nowMs);
}

export async function claimFreeChips(playerId: string, nowMs: number = Date.now()): Promise<ClaimFreeChipsResult> {
  return runBalanceTransaction(async (store) => {
    const entry = store.accounts[playerId];
    const chips = entry?.chips ?? DEFAULT_CHIPS;
    const status = freeClaimStatusForAccount(entry, nowMs);
    if (!status.claimable) {
      return { ok: false as const, code: "TOO_SOON" as const, chips, freeClaim: status };
    }
    const nextChips = Math.min(999_999_999, chips + FREE_CLAIM_CHIPS);
    const lastClaimAt = nowMs;
    store.accounts[playerId] = { chips: nextChips, lastClaimAt };
    const freeClaim = freeClaimStatusForAccount(store.accounts[playerId], nowMs);
    return { ok: true as const, chips: nextChips, credited: FREE_CLAIM_CHIPS, freeClaim, lastClaimAt };
  });
}
