import { isActionReceiptId } from "./actionReceiptStore.ts";

/**
 * Confirmació d'una acció acceptada. L'aposta, el hit i el stand comparteixen
 * l'event `game_action_ack` i aquest sobre.
 *
 * `amount` només el porta l'aposta (fitxes acceptades). Hit i stand no en tenen.
 * `actionId` hi és si la petició portava un id vàlid (`actionId` o, si no, `requestId`).
 */
export type GameActionAck = {
  action: string;
  actionId?: string;
  roomId: string;
  amount?: number;
};

/** Id de rebut: `actionId` si és vàlid; si no, `requestId`. */
export function actionReceiptIdFromPayload(payload: {
  actionId?: unknown;
  requestId?: unknown;
}): string | undefined {
  if (isActionReceiptId(payload.actionId)) return payload.actionId;
  if (isActionReceiptId(payload.requestId)) return payload.requestId;
  return undefined;
}

/** Mateix ordre de camps que l'ack de l'aposta. Omet els que no apliquen. */
export function buildGameActionAck(fields: {
  action: string;
  roomId: string;
  actionId?: string;
  amount?: number;
}): GameActionAck {
  const actionId = fields.actionId;
  const amount =
    typeof fields.amount === "number" && Number.isFinite(fields.amount) ? fields.amount : undefined;
  if (actionId && amount !== undefined) {
    return { action: fields.action, actionId, roomId: fields.roomId, amount };
  }
  if (actionId) {
    return { action: fields.action, actionId, roomId: fields.roomId };
  }
  return { action: fields.action, roomId: fields.roomId };
}
