#!/usr/bin/env node
/**
 * Executa els fitxers de test un per un, cadascun en el seu propi procés:
 *   node --import tsx --test-force-exit --test-reporter=tap <fitxer>
 *
 * - TMPDIR apunta a /tmp/setimig-test-run-XXXX, de manera que tots els mkdtemp dels tests
 *   (setimig-priv-*, setimig-bal-*, …) hi queden a dins, i s'esborra sencer en acabar,
 *   també si els tests fallen o si s'interromp amb Ctrl+C / SIGTERM.
 * - Abans es feia servir `node --test --test-force-exit` amb tots els fitxers: cada fitxer anava
 *   a un procés fill que enviava els resultats al pare per una canonada, i el `process.exit` del
 *   force-exit tallava aquesta sortida quan els tests acabaven ràpid. Es perdien resultats en
 *   silenci (p. ex. shared/gameEngine.test.ts donava entre 19 i 36 tests segons l'execució).
 *   Executant cada fitxer directament (sense `--test`), el reporter escriu al stdout del mateix
 *   procés i no es perd res. L'aïllament per fitxer i l'ordre seqüencial són els mateixos.
 * - Al final mostra un resum agregat (`# tests`, `# pass`, `# fail`…) i surt amb 1 si algun
 *   fitxer falla o no arriba a informar del seu resum.
 *
 * Ús: node server/testRunner.mjs <fitxers de test…>
 */
import { spawn } from "node:child_process";
import { existsSync, mkdtempSync, rmSync } from "node:fs";
import os from "node:os";
import path from "node:path";

const root = mkdtempSync(path.join(os.tmpdir(), "setimig-test-run-"));
let cleaned = false;
function cleanup() {
  if (cleaned) return;
  cleaned = true;
  try {
    rmSync(root, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 });
  } catch (err) {
    console.error(`[testRunner] no s'ha pogut esborrar ${root}:`, err);
  }
}

const files = process.argv.slice(2);
const env = { ...process.env, TMPDIR: root, TMP: root, TEMP: root, SETIMIG_TEST_TMP_ROOT: root };
const totals = { tests: 0, suites: 0, pass: 0, fail: 0, cancelled: 0, skipped: 0, todo: 0 };
const failedFiles = [];
let current = null;
let interrupted = false;

for (const sig of ["SIGINT", "SIGTERM"]) {
  process.on(sig, () => {
    interrupted = true;
    current?.kill(sig);
  });
}
process.on("exit", cleanup);

function runFile(file) {
  return new Promise((resolve) => {
    const child = spawn(
      process.execPath,
      ["--import", "tsx", "--test-force-exit", "--test-reporter=tap", file],
      { env, stdio: ["ignore", "pipe", "inherit"] }
    );
    current = child;
    let buf = "";
    const summary = {};
    child.stdout.on("data", (chunk) => {
      process.stdout.write(chunk);
      buf += chunk.toString("utf8");
      let nl;
      while ((nl = buf.indexOf("\n")) !== -1) {
        const line = buf.slice(0, nl);
        buf = buf.slice(nl + 1);
        const m = /^# (tests|suites|pass|fail|cancelled|skipped|todo) (\d+)$/.exec(line);
        if (m) summary[m[1]] = Number(m[2]);
      }
    });
    child.on("error", (err) => {
      console.error(`[testRunner] ${file}:`, err);
      resolve({ code: 1, summary });
    });
    child.on("close", (code, signal) => {
      current = null;
      resolve({ code: code ?? (signal ? 1 : 0), summary });
    });
  });
}

const started = Date.now();
for (const file of files) {
  if (interrupted) break;
  if (!existsSync(file)) {
    console.error(`[testRunner] no existeix: ${file}`);
    failedFiles.push(`${file} (no existeix)`);
    continue;
  }
  console.log(`# fitxer: ${file}`);
  const { code, summary } = await runFile(file);
  for (const k of Object.keys(totals)) totals[k] += summary[k] ?? 0;
  if (code !== 0 || summary.tests === undefined || (summary.fail ?? 0) > 0) {
    failedFiles.push(summary.tests === undefined ? `${file} (sense resum)` : file);
  }
}

console.log(`# ===== resum: ${files.length} fitxers =====`);
for (const [k, v] of Object.entries(totals)) console.log(`# ${k} ${v}`);
console.log(`# duration_ms ${Date.now() - started}`);
if (failedFiles.length) console.log(`# fitxers amb errors: ${failedFiles.join(", ")}`);
cleanup();
process.exit(failedFiles.length || interrupted ? 1 : 0);
