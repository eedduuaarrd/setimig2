import { createHash } from "node:crypto";
import { madridDayKey } from "./achievementsTime.ts";

export type MissionKind = "win_hands" | "play_hands" | "win_chips" | "no_pass_hands";

export type MissionTemplate = {
  kind: MissionKind;
  target: number;
  title: string;
  rewardChips: number;
};

const POOL: MissionTemplate[] = [
  { kind: "win_hands", target: 2, title: "Guanya 2 mans avui", rewardChips: 400 },
  { kind: "win_hands", target: 3, title: "Guanya 3 mans avui", rewardChips: 600 },
  { kind: "play_hands", target: 4, title: "Juga 4 mans avui", rewardChips: 350 },
  { kind: "play_hands", target: 6, title: "Juga 6 mans avui", rewardChips: 500 },
  { kind: "win_chips", target: 300, title: "Guanya 300 fitxes netes avui", rewardChips: 450 },
  { kind: "win_chips", target: 800, title: "Guanya 800 fitxes netes avui", rewardChips: 900 },
  { kind: "no_pass_hands", target: 3, title: "3 mans sense passar-te avui", rewardChips: 550 },
];

/** Clau i18n estable d'una missió; el client la interpola amb `params` (p. ex. `{ target }`). */
export function missionI18n(kind: MissionKind, target: number): {
  code: MissionKind;
  titleKey: string;
  params: { target: number };
} {
  return { code: kind, titleKey: `missions.${kind}.title`, params: { target } };
}

export type DailyMission = MissionTemplate & { id: string; dayKey: string };

function seededIndex(seed: string, max: number): number {
  const hex = createHash("sha256").update(seed).digest("hex").slice(0, 8);
  const n = Number.parseInt(hex, 16);
  return n % max;
}

export function dailyMissionsForDay(dayKey: string = madridDayKey()): DailyMission[] {
  const used = new Set<number>();
  const missions: DailyMission[] = [];
  let attempt = 0;
  while (missions.length < 3 && attempt < 40) {
    const idx = seededIndex(`${dayKey}:${attempt}`, POOL.length);
    attempt += 1;
    if (used.has(idx)) continue;
    used.add(idx);
    const t = POOL[idx]!;
    missions.push({
      ...t,
      id: `${dayKey}-${t.kind}-${t.target}`,
      dayKey,
    });
  }
  return missions;
}
