/**
 * Prova de càrrega: N taules solo simultànies (1 client humà automàtic + bots) contra
 * un servidor socket.io en procés, amb dades en un directori temporal.
 *
 * Ús (no forma part de `npm test`):
 *   npm run test:carrega                       # 50 taules, 60 s, timers ràpids
 *   CARREGA_TAULES=50 CARREGA_SEGONS=120 CARREGA_REAL=1 npm run test:carrega
 *   node --cpu-prof --cpu-prof-dir=$HOME/prof --import tsx server/cargaTaules.ts
 * Dades temporals a ~/setimig-backups/carrega (o CARREGA_DATA_DIR); s'esborren en acabar.
 */
import { createServer } from "http";
import fs from "fs/promises";
import os from "os";
import path from "path";
import { monitorEventLoopDelay } from "perf_hooks";
import { pathToFileURL } from "url";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket as ClientSocket } from "socket.io-client";

export type LoadTestOptions = {
  tables: number;
  botsPerTable: number;
  durationMs: number;
  /** true = timers reals de producció; false = SETIMIG_TEST_FAST (estrès màxim). */
  realTimers: boolean;
};

export type LoadTestReport = {
  options: LoadTestOptions;
  tablesJoined: number;
  handsSettled: number;
  handsPerSec: number;
  roomUpdates: number;
  roomUpdatesPerSec: number;
  gameErrors: number;
  gameErrorCodes: Record<string, number>;
  actionLatencyMs: { count: number; p50: number; p95: number; p99: number; max: number };
  eventLoopDelayMs: { p50: number; p99: number; max: number };
  cpuPercent: number;
  memoryMb: { rssStart: number; rssEnd: number; heapUsedStart: number; heapUsedEnd: number; rssPeak: number };
  dataDirKb: number;
  /** Escriptures a disc durant la prova (balances.json, weekly-leaderboard, …). */
  fileWrites: Record<string, number>;
  writeCoalesceMs: number;
};

function percentile(sorted: number[], p: number): number {
  if (sorted.length === 0) return 0;
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.ceil((p / 100) * sorted.length) - 1));
  return Math.round(sorted[idx]! * 10) / 10;
}

const mb = (b: number) => Math.round((b / 1_048_576) * 10) / 10;

async function dirSizeKb(dir: string): Promise<number> {
  let total = 0;
  const walk = async (d: string) => {
    for (const ent of await fs.readdir(d, { withFileTypes: true }).catch(() => [])) {
      const p = path.join(d, ent.name);
      if (ent.isDirectory()) await walk(p);
      else total += (await fs.stat(p).catch(() => ({ size: 0 }))).size;
    }
  };
  await walk(dir);
  return Math.round(total / 1024);
}

type ViewLike = {
  id: string;
  phase: string;
  turnIndex?: number;
  turnPlayerId?: string | null;
  matchEnded?: boolean;
  players?: { id: string; isBanker?: boolean; isBot?: boolean; bet?: number; pendingBankChoice?: unknown }[];
};

export async function runLoadTest(opts: LoadTestOptions): Promise<LoadTestReport> {
  // Dades de la prova a disc (mai a /tmp, que al VPS és RAM): ~/setimig-backups/carrega/…
  const baseDir = process.env.CARREGA_DATA_DIR || path.join(os.homedir(), "setimig-backups", "carrega");
  await fs.mkdir(baseDir, { recursive: true });
  const dataDir = await fs.mkdtemp(path.join(baseDir, "run-"));
  process.env.BALANCE_DATA_DIR = dataDir;
  process.env.PROFILE_DATA_DIR = path.join(dataDir, "profiles");
  process.env.FRIENDS_DATA_DIR = dataDir;
  process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";
  // Com a producció: escriptures agrupades (SETIMIG_WRITE_COALESCE_MS=0 → escriptura a cada canvi).
  if (process.env.SETIMIG_WRITE_COALESCE_MS === undefined) process.env.SETIMIG_WRITE_COALESCE_MS = "1500";
  if (opts.realTimers) delete process.env.SETIMIG_TEST_FAST;
  else process.env.SETIMIG_TEST_FAST = "1";

  try {
    return await runLoadTestIn(dataDir, opts);
  } finally {
    // També si la prova falla: no deixar dades temporals.
    await fs.rm(dataDir, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 }).catch(() => undefined);
  }
}

async function runLoadTestIn(dataDir: string, opts: LoadTestOptions): Promise<LoadTestReport> {
  const { setupGameHandlers, resetGameStateForTests } = await import("./game.ts");
  const { flushPlayerStatsWritesForTests } = await import("./playerStats.ts");
  const { flushEngagementWritesForTests } = await import("./achievementsStore.ts");
  const { runBalanceTransaction } = await import("./balances.ts");
  const { flushAllPendingWrites, getWriteCounts, resetWriteCounts } = await import("./writeCoalescing.ts");
  resetWriteCounts();

  const http = createServer();
  const io = new SocketIOServer(http, { cors: { origin: "*" } });
  await setupGameHandlers(io);
  await new Promise<void>((r) => http.listen(0, "127.0.0.1", () => r()));
  const addr = http.address();
  const url = `http://127.0.0.1:${typeof addr === "object" && addr ? addr.port : 0}`;

  const LOOP_RES_MS = 10;
  const loop = monitorEventLoopDelay({ resolution: LOOP_RES_MS });
  /** L'histograma inclou la resolució del temporitzador: la restem per obtenir el retard real. */
  const loopMs = (ns: number) => Math.max(0, Math.round((ns / 1e6 - LOOP_RES_MS) * 10) / 10);
  const latencies: number[] = [];
  let roomUpdates = 0;
  let handsSettled = 0;
  let gameErrors = 0;
  const gameErrorCodes: Record<string, number> = {};
  let tablesJoined = 0;
  let rssPeak = 0;
  const memStart = process.memoryUsage();
  const sockets: ClientSocket[] = [];

  const connectOne = (i: number) =>
    new Promise<void>((resolve, reject) => {
      const socket = ioClient(url, { transports: ["websocket"], forceNew: true, reconnection: false });
      sockets.push(socket);
      const timer = setTimeout(() => reject(new Error(`taula ${i}: join timeout`)), 20_000);
      let pendingSince: number | null = null;
      let lastPhase = "";
      /** Evita repetir la mateixa acció per a cada room_update del mateix torn. */
      let lastActKey = "";
      let myHands = 0;
      let joined = false;
      const act = (event: string, payload: unknown, key: string) => {
        if (key === lastActKey) return;
        lastActKey = key;
        if (pendingSince === null) pendingSince = performance.now();
        socket.emit(event, payload);
      };
      const onRoom = (room: ViewLike) => {
        roomUpdates++;
        if (pendingSince !== null) {
          latencies.push(performance.now() - pendingSince);
          pendingSince = null;
        }
        if (!joined) {
          joined = true;
          tablesJoined++;
          clearTimeout(timer);
          resolve();
        }
        if (room.phase === "settlement" && lastPhase !== "settlement") {
          handsSettled++;
          myHands++;
        }
        lastPhase = room.phase;
        const me = room.players?.find((p) => p.id === socket.id);
        if (!me) return;
        if (room.phase === "waiting" && room.matchEnded) {
          act("quick_rematch", room.id, `rematch:${myHands}`);
          return;
        }
        if (me.pendingBankChoice) act("bank_keep_choice", { roomId: room.id, keep: false }, `bank:${myHands}`);
        if (room.phase === "betting" && !me.isBanker && (me.bet ?? 0) === 0) {
          act("place_bet", { roomId: room.id, amount: 100 }, `bet:${myHands}`);
        }
        const nb = room.players?.filter((p) => !p.isBanker) ?? [];
        const turnId =
          room.turnPlayerId ??
          (room.phase === "playing"
            ? nb[room.turnIndex ?? 0]?.id
            : room.phase === "banker"
              ? room.players?.find((p) => p.isBanker)?.id
              : null);
        if (turnId === socket.id && (room.phase === "playing" || room.phase === "banker")) {
          act("stand", room.id, `stand:${room.phase}:${myHands}`);
        }
      };
      socket.on("room_update", onRoom);
      socket.on("joined_room", onRoom);
      socket.on("game_error", (err: { code?: string }) => {
        gameErrors++;
        const code = err?.code ?? "?";
        gameErrorCodes[code] = (gameErrorCodes[code] ?? 0) + 1;
        pendingSince = null;
      });
      socket.on("connect", () => {
        socket.emit("join_solo_room", {
          playerName: `Carrega${i}`,
          playerId: `carregaplayer${String(i).padStart(4, "0")}`,
          botCount: opts.botsPerTable,
        });
      });
      socket.on("connect_error", (err) => {
        clearTimeout(timer);
        reject(err);
      });
    });

  const cpuStart = process.cpuUsage();
  const t0 = performance.now();
  loop.enable();
  const memTimer = setInterval(() => {
    rssPeak = Math.max(rssPeak, process.memoryUsage().rss);
  }, 250);
  try {
    await Promise.all(Array.from({ length: opts.tables }, (_, i) => connectOne(i)));
    await new Promise((r) => setTimeout(r, opts.durationMs));
  } finally {
    loop.disable();
    clearInterval(memTimer);
  }
  const elapsedS = (performance.now() - t0) / 1000;
  const cpu = process.cpuUsage(cpuStart);
  const memEnd = process.memoryUsage();

  for (const s of sockets) s.disconnect();
  io.close();
  await new Promise<void>((r) => http.close(() => r()));
  resetGameStateForTests();
  await new Promise((r) => setTimeout(r, 300));
  await runBalanceTransaction(() => undefined);
  const fileWritesDuringRun = getWriteCounts();
  await flushAllPendingWrites();
  await flushPlayerStatsWritesForTests();
  await flushEngagementWritesForTests();
  const dataDirKb = await dirSizeKb(dataDir);
  await fs.rm(dataDir, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 }).catch(() => undefined);

  latencies.sort((a, b) => a - b);
  return {
    options: opts,
    tablesJoined,
    handsSettled,
    handsPerSec: Math.round((handsSettled / elapsedS) * 10) / 10,
    roomUpdates,
    roomUpdatesPerSec: Math.round(roomUpdates / elapsedS),
    gameErrors,
    gameErrorCodes,
    actionLatencyMs: {
      count: latencies.length,
      p50: percentile(latencies, 50),
      p95: percentile(latencies, 95),
      p99: percentile(latencies, 99),
      max: percentile(latencies, 100),
    },
    eventLoopDelayMs: {
      p50: loopMs(loop.percentile(50)),
      p99: loopMs(loop.percentile(99)),
      max: loopMs(loop.max),
    },
    cpuPercent: Math.round(((cpu.user + cpu.system) / 1000 / (elapsedS * 1000)) * 1000) / 10,
    memoryMb: {
      rssStart: mb(memStart.rss),
      rssEnd: mb(memEnd.rss),
      heapUsedStart: mb(memStart.heapUsed),
      heapUsedEnd: mb(memEnd.heapUsed),
      rssPeak: mb(Math.max(rssPeak, memEnd.rss)),
    },
    dataDirKb,
    fileWrites: fileWritesDuringRun,
    writeCoalesceMs: Number(process.env.SETIMIG_WRITE_COALESCE_MS),
  };
}

function envNum(name: string, fallback: number): number {
  const n = Number(process.env[name]);
  return Number.isFinite(n) && n > 0 ? n : fallback;
}

if (import.meta.url === pathToFileURL(process.argv[1] ?? "").href) {
  process.on("unhandledRejection", (reason) => {
    console.error("[unhandledRejection]", reason instanceof Error ? reason.message : reason);
  });
  const report = await runLoadTest({
    tables: envNum("CARREGA_TAULES", 50),
    botsPerTable: envNum("CARREGA_BOTS", 3),
    durationMs: envNum("CARREGA_SEGONS", 60) * 1000,
    realTimers: process.env.CARREGA_REAL === "1",
  });
  console.log(JSON.stringify(report, null, 2));
  process.exit(0);
}
