/** Correccions de l'auditoria del 26/10/2026 (P1-1, P1-3, P2-1, P2-2). */
import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import fs from "fs/promises";
import path from "path";
import { createServer, type Server as HttpServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket as ClientSocket } from "socket.io-client";
import type { Card } from "../src/gameTypes.ts";
import {
  applyDouble,
  applyHit,
  applySplit,
  applyStand,
  betRangeError,
  BLIND_PAIR_LOCKED,
  emptyRoomBase,
  type GameHost,
  type HandSlot,
  type Player,
  type Room,
} from "../shared/gameEngine.ts";
import { trustedClientIp } from "./clientIp.ts";
import { clientKey } from "./httpRateLimit.ts";
import {
  isJoinBlocked,
  JOIN_BLOCK_MS,
  JOIN_MAX_FAILS,
  recordJoinFailure,
  resetJoinAttemptLimitForTests,
} from "./joinAttemptLimit.ts";

process.env.SETIMIG_TEST_FAST = "1";

const noopHost: GameHost = {
  emitRoomUpdate() {},
  schedule: (fn, ms) => setTimeout(fn, ms),
  clearTimeout() {},
};

function card(value: number): Card {
  return { suit: "hearts", value, points: value >= 10 ? 0.5 : value } as unknown as Card;
}

function slot(cards: Card[], extra: Partial<HandSlot> = {}): HandSlot {
  return {
    id: `s-${Math.random()}`,
    bet: 100,
    cards: cards.map((c, i) => ({ id: `c${i}-${Math.random()}`, card: c, faceUp: false })),
    status: "playing",
    mort: false,
    blindPair: false,
    doubled: false,
    canDouble: false,
    blindUntilBankEnd: false,
    mortOffered: false,
    ...extra,
  } as HandSlot;
}

function player(id: string, overrides: Partial<Player> = {}): Player {
  return {
    id,
    playerId: id,
    seatToken: id,
    name: id,
    chips: 5_000,
    bet: 0,
    isBanker: false,
    status: "betting",
    handSlots: [],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
    ...overrides,
  } as Player;
}

function blindPairRoom(): { room: Room; p1: Player } {
  const room = emptyRoomBase("aud-3", "Aud3", 100, 0);
  room.houseRulesEnabled = true;
  const banker = player("bank", { isBanker: true, chips: 50_000, status: "playing", handSlots: [slot([card(5)])] });
  const p1 = player("p1", {
    bet: 100,
    status: "playing",
    handSlots: [slot([card(10), card(11)], { blindPair: true, blindUntilBankEnd: true })],
  });
  room.players = [banker, p1];
  room.phase = "playing";
  room.turnPlayerIndex = 0;
  room.deck = [card(1), card(2), card(4), card(5), card(6)];
  return { room, p1 };
}

describe("auditoria P1-1: mà del 3 (dues cegues)", () => {
  it("rebutja Carta, Doblar i Split; només deixa plantar-se", () => {
    const { room, p1 } = blindPairRoom();
    assert.equal(applyHit(noopHost, room, "p1"), BLIND_PAIR_LOCKED);
    assert.equal(applySplit(room, "p1"), BLIND_PAIR_LOCKED);
    assert.equal(applyDouble(noopHost, room, "p1"), BLIND_PAIR_LOCKED);
    assert.equal(p1.handSlots.length, 1);
    assert.equal(p1.handSlots[0]!.cards.length, 2);
    assert.equal(p1.chips, 5_000);
    assert.equal(applyStand(noopHost, room, "p1"), null);
  });
});

describe("auditoria P2-2: imports d'aposta fora de rang", () => {
  function bettingRoom() {
    const room = emptyRoomBase("aud-bet", "AudBet", 100, 0);
    const banker = player("bank", { isBanker: true, chips: 1_000_000 });
    const p1 = player("p1", { chips: 5_000 });
    room.players = [banker, p1];
    room.phase = "betting";
    return { room, p1 };
  }

  it("rebutja per sota del mínim i per sobre del màxim; accepta dins del rang", () => {
    const { room, p1 } = bettingRoom();
    assert.match(betRangeError(room, p1, 1) ?? "", /mínima/);
    assert.match(betRangeError(room, p1, 99) ?? "", /mínima/);
    assert.match(betRangeError(room, p1, 999_999) ?? "", /màxima/);
    assert.match(betRangeError(room, p1, "abc") ?? "", /no vàlida/);
    assert.equal(betRangeError(room, p1, 100), null);
    assert.equal(betRangeError(room, p1, 250), null);
  });
});

describe("auditoria P2-1: IP de confiança", () => {
  it("cf-connecting-ip només es creu si la connexió ve de loopback (Caddy)", () => {
    for (const lo of ["127.0.0.1", "::1", "::ffff:127.0.0.1"]) {
      assert.equal(trustedClientIp(lo, { "cf-connecting-ip": "203.0.113.7" }), "203.0.113.7");
      assert.equal(trustedClientIp(lo, {}), null);
    }
    assert.equal(trustedClientIp("198.51.100.9", { "cf-connecting-ip": "203.0.113.7" }), "198.51.100.9");
    assert.equal(trustedClientIp("198.51.100.9", {}), "198.51.100.9");
  });

  it("el limitador HTTP fa servir la mateixa regla", () => {
    const req = (remoteAddress: string, headers: Record<string, string>) =>
      ({ socket: { remoteAddress }, headers }) as unknown as Parameters<typeof clientKey>[0];
    assert.equal(clientKey(req("127.0.0.1", { "cf-connecting-ip": "203.0.113.7" })), "203.0.113.7");
    assert.equal(clientKey(req("198.51.100.9", { "cf-connecting-ip": "1.2.3.4" })), "198.51.100.9");
    assert.equal(clientKey(req("::1", {})), null);
  });
});

describe("auditoria P1-3: límit d'intents per IP en entrar per codi", () => {
  it("bloqueja després de N errors i no depèn del socket", () => {
    resetJoinAttemptLimitForTests();
    const t0 = 1_000_000;
    for (let i = 0; i < JOIN_MAX_FAILS - 1; i++) assert.equal(recordJoinFailure("ip-a", t0 + i), false);
    assert.equal(isJoinBlocked("ip-a", t0 + 20), false);
    assert.equal(recordJoinFailure("ip-a", t0 + 30), true);
    assert.equal(isJoinBlocked("ip-a", t0 + 40), true);
    assert.equal(isJoinBlocked("ip-b", t0 + 40), false);
    assert.equal(isJoinBlocked("ip-a", t0 + 30 + JOIN_BLOCK_MS + 1), false);
    assert.equal(isJoinBlocked(null, t0), false);
  });

  describe("via socket (reconnectant)", () => {
    const DATA_ROOT = path.join(process.cwd(), "data", `aud-join-${Date.now()}`);
    let http: HttpServer;
    let io: SocketIOServer;
    let url = "";

    before(async () => {
      process.env.BALANCE_DATA_DIR = DATA_ROOT;
      process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";
      resetJoinAttemptLimitForTests();
      const { setupGameHandlers } = await import("./game.ts");
      http = createServer();
      io = new SocketIOServer(http, { cors: { origin: "*" } });
      await setupGameHandlers(io);
      await new Promise<void>((r) => http.listen(0, "127.0.0.1", () => r()));
      const addr = http.address();
      url = `http://127.0.0.1:${typeof addr === "object" && addr ? addr.port : 0}`;
    });

    after(async () => {
      io.close();
      await new Promise<void>((r) => http.close(() => r()));
      resetJoinAttemptLimitForTests();
      await fs.rm(DATA_ROOT, { recursive: true, force: true }).catch(() => undefined);
      delete process.env.BALANCE_DATA_DIR;
    });

    async function tryJoin(code: string): Promise<string> {
      const socket: ClientSocket = ioClient(url, {
        transports: ["websocket"],
        forceNew: true,
        reconnection: false,
        extraHeaders: { "cf-connecting-ip": "203.0.113.50" },
      });
      try {
        return await new Promise<string>((resolve, reject) => {
          const timer = setTimeout(() => reject(new Error("timeout")), 5_000);
          socket.on("game_error", (e: { code?: string }) => {
            clearTimeout(timer);
            resolve(e.code ?? "?");
          });
          socket.on("connect", () => socket.emit("join_private_table", { inviteCode: code, playerName: "Aud" }));
        });
      } finally {
        socket.disconnect();
      }
    }

    it("un socket nou per intent no reinicia el comptador", async () => {
      for (let i = 0; i < JOIN_MAX_FAILS; i++) {
        assert.equal(await tryJoin(`ZZZZZ${i % 10}`), "ROOM_NOT_FOUND");
      }
      assert.equal(await tryJoin("ZZZZZZ"), "RATE_LIMIT");
    });
  });
});
