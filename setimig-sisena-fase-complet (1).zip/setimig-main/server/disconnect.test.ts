import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket } from "socket.io-client";
import { setupGameHandlers } from "./game.ts";
import { issuePlayerToken } from "./playerToken.ts";

const HOST_ID = "privdiscohost00001";
const GUEST_ID = "privdiscoguest001";

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";

function connect(url: string): Promise<Socket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.on("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.on("connect_error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

describe("disconnect mid-game", () => {
  it("private table keeps game running when a guest drops", async () => {
    process.env.SETIMIG_TEST_FAST = "1";
    const http = createServer();
    const io = new SocketIOServer(http, { cors: { origin: "*" } });
    await setupGameHandlers(io);
    await new Promise<void>((r) => http.listen(0, "127.0.0.1", () => r()));
    const port = (http.address() as { port: number }).port;
    const url = `http://127.0.0.1:${port}`;

    const host = await connect(url);
    const guest = await connect(url);

    const hostRoom = await new Promise<{ id: string; inviteCode?: string }>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("create timeout")), 15_000);
      host.once("joined_room", (room) => {
        clearTimeout(timer);
        resolve(room);
      });
      const hostToken = issuePlayerToken(HOST_ID)!;
      host.emit("create_private_table", {
        playerName: "Host",
        playerId: HOST_ID,
        playerToken: hostToken,
      });
    });

    const code = hostRoom.inviteCode;
    assert.ok(code);

    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("guest join timeout")), 15_000);
      guest.once("joined_room", () => {
        clearTimeout(timer);
        resolve();
      });
      guest.emit("join_private_table", {
        inviteCode: code,
        playerName: "Guest",
        playerId: GUEST_ID,
        playerToken: issuePlayerToken(GUEST_ID),
      });
    });

    const hostToken = issuePlayerToken(HOST_ID)!;
    host.emit("fill_private_bots", { roomId: hostRoom.id, playerToken: hostToken, actionSeq: 1 });
    host.emit("start_game", { roomId: hostRoom.id, playerToken: hostToken, actionSeq: 2 });

    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("game never started")), 45_000);
      guest.on("room_update", (room: { phase: string }) => {
        if (room.phase === "betting" || room.phase === "playing") {
          clearTimeout(timer);
          resolve();
        }
      });
    });

    guest.disconnect();

    await new Promise((r) => setTimeout(r, 300));

    const stillRunning = await new Promise<boolean>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("host saw no update")), 10_000);
      host.on("room_update", (room: { phase: string; players: { name: string; isBot?: boolean }[] }) => {
        if (room.phase === "waiting") return;
        clearTimeout(timer);
        resolve(room.players.length >= 2);
      });
    });

    try {
      assert.equal(stillRunning, true);
    } finally {
      delete process.env.SETIMIG_TEST_FAST;
      host.disconnect();
      io.close();
      await new Promise<void>((r) => http.close(() => r()));
    }
  });
});
