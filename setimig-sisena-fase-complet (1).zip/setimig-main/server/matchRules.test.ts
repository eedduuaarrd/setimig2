import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { computeSoloMatchResult } from "./matchRules.ts";

describe("computeSoloMatchResult", () => {
  it("returns null while human and at least one bot can bet", () => {
    const result = computeSoloMatchResult(
      [
        { id: "h1", name: "Human", chips: 500, isBot: false },
        { id: "b1", name: "Bot A", chips: 8000, isBot: true },
      ],
      100,
      "h1"
    );
    assert.equal(result, null);
  });

  it("eliminates human with insufficient chips", () => {
    const result = computeSoloMatchResult(
      [
        { id: "h1", name: "Human", chips: 50, isBot: false },
        { id: "b1", name: "Bot A", chips: 9000, isBot: true },
      ],
      100,
      "h1"
    );
    assert.ok(result);
    assert.equal(result.viewerOutcome, "eliminated");
    assert.equal(result.winnerName, "Bot A");
    assert.equal(result.ranking[0].eliminated, false);
    assert.equal(result.ranking.find((e) => e.name === "Human")?.eliminated, true);
  });

  it("human wins when all bots are broke", () => {
    const result = computeSoloMatchResult(
      [
        { id: "h1", name: "Human", chips: 1200, isBot: false },
        { id: "b1", name: "Bot A", chips: 80, isBot: true },
        { id: "b2", name: "Bot B", chips: 0, isBot: true },
      ],
      100,
      "h1"
    );
    assert.ok(result);
    assert.equal(result.winnerName, "Human");
    assert.equal(result.viewerOutcome, "win");
  });
});
