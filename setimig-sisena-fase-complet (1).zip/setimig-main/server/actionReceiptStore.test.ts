import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createActionReceiptStore } from "./actionReceiptStore.ts";

describe("game action receipt store", () => {
  it("runs concurrent retries once and returns the original result", async () => {
    const store = createActionReceiptStore();
    let applications = 0;
    const operation = async () => {
      applications += 1;
      await Promise.resolve();
      return { ok: true, bet: 250 };
    };

    const [first, retry] = await Promise.all([
      store.run("room:seat", "request-1", operation),
      store.run("room:seat", "request-1", operation),
    ]);

    assert.equal(applications, 1);
    assert.deepEqual(retry, first);
  });

  it("keeps room and seat actions isolated and expires receipts", async () => {
    let now = 10;
    const store = createActionReceiptStore({ ttlMs: 50, now: () => now });
    let applications = 0;
    const apply = () => ++applications;

    assert.equal(await store.run("room-a:seat", "same-id", apply), 1);
    assert.equal(await store.run("room-a:other-seat", "same-id", apply), 2);
    assert.equal(await store.run("room-a:seat", "other-id", apply), 3);
    now += 50;
    assert.equal(await store.run("room-a:seat", "same-id", apply), 4);
    assert.equal(applications, 4);
  });

  it("prunes expired receipts from insertion order despite a backwards clock adjustment", async () => {
    let now = 10;
    const store = createActionReceiptStore({ ttlMs: 50, now: () => now });
    let applications = 0;
    const apply = () => ++applications;

    assert.equal(await store.run("room", "older", apply), 1);
    now = 20;
    assert.equal(await store.run("room", "newer", apply), 2);
    now = 0;
    assert.equal(await store.run("room", "latest", apply), 3);

    now = 60;
    assert.equal(await store.run("room", "newer", apply), 2);
    assert.equal(await store.run("room", "latest", apply), 3);
    assert.equal(await store.run("room", "older", apply), 4);
    assert.equal(applications, 4);
  });

  it("does not cache missing or malformed action IDs", async () => {
    const store = createActionReceiptStore();
    let applications = 0;
    const apply = () => ++applications;

    await store.run("room:seat", undefined, apply);
    await store.run("room:seat", " ", apply);
    await store.run("room:seat", "x".repeat(129), apply);

    assert.equal(applications, 3);
  });
});
