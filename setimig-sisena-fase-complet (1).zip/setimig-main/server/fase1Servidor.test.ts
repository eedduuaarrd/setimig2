import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import fs from "fs/promises";
import path from "path";
import { createServer } from "http";
import { Server } from "socket.io";
import { io as ioClient } from "socket.io-client";
import express from "express";
import type { Request } from "express";
import {
  getPlayerHistory,
  getPlayerStats,
  recordResolvedHand,
  resetPlayerStatsCacheForTests,
  readPlayerStatsFileForTests,
} from "./playerStats.ts";
import { resolvePlayerFromRequest } from "./httpPlayerAuth.ts";
import { getBalance, resetBalanceStoreCacheForTests, setBalance } from "./balances.ts";
import { beginBettingPhase, emptyRoomBase, type Room } from "../shared/gameEngine.ts";
import { defaultHostMatchSettings } from "../shared/hostMatchSettings.ts";
import {
  getGameHostForTests,
  getRoomSnapshotForTests,
  resetGameStateForTests,
  setupGameHandlers,
} from "./game.ts";

const DATA_ROOT = path.join(process.cwd(), "data", `fase1-test-${Date.now()}`);
const STATS_DIR = path.join(DATA_ROOT, "player-stats");
const BALANCES_PATH = path.join(DATA_ROOT, "balances.json");

const TEST_PLAYER = "fase1player01";

describe("fase1 servidor", () => {
  before(() => {
    process.env.BALANCE_DATA_DIR = DATA_ROOT;
    process.env.SETIMIG_TEST_FAST = "1";
    resetPlayerStatsCacheForTests();
    resetBalanceStoreCacheForTests();
  });

  after(async () => {
    resetGameStateForTests();
    await fs.rm(DATA_ROOT, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 }).catch(() => undefined);
    delete process.env.BALANCE_DATA_DIR;
  });

  it("migració additiva: dades de saldo intactes i legacy stats importades", async () => {
    await fs.mkdir(DATA_ROOT, { recursive: true });
    const balancePayload = JSON.stringify(
      { accounts: { [TEST_PLAYER]: { chips: 4242, lastClaimAt: null } }, processedSessions: [] },
      null,
      2
    );
    await fs.writeFile(BALANCES_PATH, balancePayload, "utf8");
    const legacyPath = path.join(DATA_ROOT, "player-stats-aggregate.json");
    await fs.writeFile(
      legacyPath,
      JSON.stringify({ players: { [TEST_PLAYER]: { handsPlayed: 4, handsWon: 2 } } }),
      "utf8"
    );

    resetBalanceStoreCacheForTests();
    resetPlayerStatsCacheForTests();
    const chips = await getBalance(TEST_PLAYER);
    assert.equal(chips, 4242);
    assert.equal(await fs.readFile(BALANCES_PATH, "utf8"), balancePayload);

    const stats = await getPlayerStats(TEST_PLAYER);
    assert.equal(stats.handsPlayed, 4);
    assert.equal(stats.winRatePercent, 50);
  });

  it("estadístiques exclouen mans de pràctica", async () => {
    resetPlayerStatsCacheForTests();
    await recordResolvedHand({
      playerId: TEST_PLAYER,
      roomId: "r1",
      roomLabel: "Real",
      finalPoints: 7,
      passed: false,
      naturalSevenHalf: false,
      bet: 100,
      result: "win",
      chipDelta: 100,
      wasBanker: false,
      practice: false,
    });
    await recordResolvedHand({
      playerId: TEST_PLAYER,
      roomId: "r2",
      roomLabel: "Pràctica",
      finalPoints: 8,
      passed: true,
      naturalSevenHalf: true,
      bet: 0,
      result: "win",
      chipDelta: 0,
      wasBanker: false,
      practice: true,
    });
    const stats = await getPlayerStats(TEST_PLAYER);
    assert.equal(stats.handsPlayed, 5);
    assert.equal(stats.passCount, 0);
    const file = await readPlayerStatsFileForTests(TEST_PLAYER);
    assert.equal(file.hands.length, 2);
    assert.equal(file.hands.filter((h) => h.practice).length, 1);
  });

  it("mode pràctica: sense temporitzador humà en fase d'apostes", () => {
    const host = getGameHostForTests();
    const room: Room = emptyRoomBase("practice-room", "Pràctica", 100, 1000);
    room.practiceMode = true;
    room.soloAi = true;
    room.players.push({
      id: "h1",
      playerId: TEST_PLAYER,
      seatToken: "seat-h1",
      name: "Humà",
      chips: 2000,
      bet: 0,
      isBanker: false,
      status: "waiting",
      handSlots: [],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    });
    room.players.push({
      id: "b1",
      playerId: "bot-x",
      seatToken: "bot-x",
      name: "Bot",
      chips: 2000,
      bet: 0,
      isBanker: true,
      isBot: true,
      status: "waiting",
      handSlots: [],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    });
    beginBettingPhase(host, room);
    assert.equal(room.turnDeadlineAt, null);
    assert.equal(room.bettingDeadlineAt, null);
  });

  it("ajustos rebutjats durant partida en curs", async () => {
    resetGameStateForTests();
    const httpServer = createServer();
    const io = new Server(httpServer);
    await setupGameHandlers(io);
    await new Promise<void>((resolve) => httpServer.listen(0, resolve));
    const port = (httpServer.address() as { port: number }).port;
    const socket = ioClient(`http://127.0.0.1:${port}`, { transports: ["websocket"] });
    await new Promise<void>((resolve) => socket.on("connect", () => resolve()));

    const roomId = await new Promise<string>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("timeout join")), 8000);
      socket.once("joined_room", (payload: { id: string }) => {
        clearTimeout(timer);
        resolve(payload.id);
      });
      socket.emit("join_solo_room", {
        playerName: "Test",
        playerId: TEST_PLAYER,
        botCount: 1,
        botDifficulty: "easy",
      });
    });

    await new Promise<void>((resolve, reject) => {
      const deadline = Date.now() + 6000;
      const tick = () => {
        const snap = getRoomSnapshotForTests(roomId);
        if (snap && snap.phase !== "waiting") {
          resolve();
          return;
        }
        if (Date.now() > deadline) {
          reject(new Error("La partida no ha arrencat a temps"));
          return;
        }
        setTimeout(tick, 40);
      };
      tick();
    });

    let sawError = false;
    socket.once("game_error", (err: { code?: string }) => {
      if (err.code === "MATCH_IN_PROGRESS") sawError = true;
    });
    socket.emit("update_match_settings", {
      roomId,
      settings: { ...defaultHostMatchSettings(), handsTotal: 12 },
    });
    await new Promise((r) => setTimeout(r, 250));
    assert.equal(sawError, true);

    socket.disconnect();
    httpServer.close();
  });

  it("saldo no canvia en sortir de partida de pràctica", async () => {
    const practicePlayer = "fase1practice1";
    resetBalanceStoreCacheForTests();
    await setBalance(practicePlayer, 9000);
    assert.equal(await getBalance(practicePlayer), 9000);
    resetGameStateForTests();
    const httpServer = createServer();
    const io = new Server(httpServer);
    await setupGameHandlers(io);
    await new Promise<void>((resolve) => httpServer.listen(0, resolve));
    const port = (httpServer.address() as { port: number }).port;
    const socket = ioClient(`http://127.0.0.1:${port}`, { transports: ["websocket"] });
    await new Promise<void>((resolve) => socket.on("connect", () => resolve()));

    const roomId = await new Promise<string>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("timeout join")), 8000);
      socket.once("joined_room", (payload: { id: string }) => {
        clearTimeout(timer);
        resolve(payload.id);
      });
      socket.emit("join_solo_room", {
        playerName: "Test",
        playerId: practicePlayer,
        botCount: 1,
        botDifficulty: "easy",
        practiceMode: true,
      });
    });

    await new Promise<void>((resolve, reject) => {
      const deadline = Date.now() + 6000;
      const tick = () => {
        const snap = getRoomSnapshotForTests(roomId);
        if (snap && snap.phase !== "waiting" && snap.phase !== "settlement") {
          assert.equal(snap.practiceMode, true);
          assert.equal(snap.soloRealBalances?.has(practicePlayer) ?? false, false);
          resolve();
          return;
        }
        if (Date.now() > deadline) {
          reject(new Error("Partida de pràctica no en curs"));
          return;
        }
        setTimeout(tick, 40);
      };
      tick();
    });

    socket.disconnect();
    await new Promise((r) => setTimeout(r, 300));

    httpServer.close();
    const after = await getBalance(practicePlayer);
    assert.equal(after, 9000);
  });

  it("GET /api/history sense before retorna la primera pàgina", async () => {
    const playerId = "history-first-page";
    resetPlayerStatsCacheForTests();
    await recordResolvedHand({
      playerId,
      roomId: "r-h1",
      roomLabel: "Taula",
      finalPoints: 7,
      passed: false,
      naturalSevenHalf: false,
      bet: 50,
      result: "win",
      chipDelta: 50,
      wasBanker: false,
      practice: false,
      at: 1000,
    });

    const app = express();
    app.get("/api/history", async (req, res) => {
      const resolved = resolvePlayerFromRequest(req as Request);
      if (!resolved) {
        return res.status(400).json({ error: "Identitat de jugador invalida." });
      }
      try {
        const page = await getPlayerHistory(resolved.playerId, req.query.limit, req.query.before);
        res.json(page);
      } catch (error: unknown) {
        const message = error instanceof Error ? error.message : "Error desconegut";
        if (message === "Invalid before cursor") {
          return res.status(400).json({ error: message });
        }
        return res.status(500).json({ error: message });
      }
    });
    const httpServer = createServer(app);
    await new Promise<void>((resolve) => httpServer.listen(0, resolve));
    const port = (httpServer.address() as { port: number }).port;
    const url = `http://127.0.0.1:${port}/api/history?playerId=${playerId}`;
    const response = await fetch(url);
    httpServer.close();
    assert.equal(response.status, 200);
    const body = (await response.json()) as { hands: { id: string }[] };
    assert.equal(body.hands.length, 1);
  });

  it("getPlayerHistory pagina amb before vàlid", async () => {
    const playerId = "history-pagination";
    resetPlayerStatsCacheForTests();
    await recordResolvedHand({
      playerId,
      roomId: "r-old",
      roomLabel: "Antiga",
      finalPoints: 5,
      passed: false,
      naturalSevenHalf: false,
      bet: 10,
      result: "lose",
      chipDelta: -10,
      wasBanker: false,
      practice: false,
      at: 100,
    });
    await recordResolvedHand({
      playerId,
      roomId: "r-new",
      roomLabel: "Nova",
      finalPoints: 7,
      passed: false,
      naturalSevenHalf: false,
      bet: 20,
      result: "win",
      chipDelta: 20,
      wasBanker: false,
      practice: false,
      at: 200,
    });

    const first = await getPlayerHistory(playerId, 1, undefined);
    assert.equal(first.hands.length, 1);
    assert.equal(first.hands[0]?.at, 200);
    assert.equal(first.nextBefore, 200);

    const second = await getPlayerHistory(playerId, 1, first.nextBefore);
    assert.equal(second.hands.length, 1);
    assert.equal(second.hands[0]?.at, 100);
    assert.equal(second.nextBefore, null);
  });

  it("GET /api/history amb before invàlid retorna 400", async () => {
    const playerId = "history-bad-before";
    const app = express();
    app.get("/api/history", async (req, res) => {
      const resolved = resolvePlayerFromRequest(req as Request);
      if (!resolved) {
        return res.status(400).json({ error: "Identitat de jugador invalida." });
      }
      try {
        const page = await getPlayerHistory(resolved.playerId, req.query.limit, req.query.before);
        res.json(page);
      } catch (error: unknown) {
        const message = error instanceof Error ? error.message : "Error desconegut";
        if (message === "Invalid before cursor") {
          return res.status(400).json({ error: message });
        }
        return res.status(500).json({ error: message });
      }
    });
    const httpServer = createServer(app);
    await new Promise<void>((resolve) => httpServer.listen(0, resolve));
    const port = (httpServer.address() as { port: number }).port;
    const url = `http://127.0.0.1:${port}/api/history?playerId=${playerId}&before=not-a-number`;
    const response = await fetch(url);
    httpServer.close();
    assert.equal(response.status, 400);
    const body = (await response.json()) as { error: string };
    assert.equal(body.error, "Invalid before cursor");
  });
});
