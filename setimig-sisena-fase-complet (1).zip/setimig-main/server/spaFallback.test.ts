import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from "node:fs";
import { createServer, type Server } from "node:http";
import os from "node:os";
import path from "node:path";
import express from "express";
import { hasFileExtension, registerManifestRedirect } from "./spaFallback.ts";
import { mountStaticDist } from "./staticAssets.ts";
import { privadesaRedirectTarget } from "./staticLegalDocs.ts";

/** Mateix muntatge que server.ts en producció. */
describe("fallback SPA de dist/ i redirecció del manifest", () => {
  let dist = "";
  let server: Server;
  let base = "";

  before(async () => {
    dist = mkdtempSync(path.join(os.tmpdir(), "setimig-spa-"));
    mkdirSync(path.join(dist, "assets"));
    writeFileSync(path.join(dist, "assets", "index-EQjPcBJ4.js"), "console.log(1);");
    writeFileSync(path.join(dist, "index.html"), "<!doctype html><title>Set i Mig</title>");
    writeFileSync(path.join(dist, "sw.js"), "self.addEventListener(\"fetch\", () => {});");
    writeFileSync(path.join(dist, "site.webmanifest"), "{\"name\":\"Set i Mig\"}");
    const app = express();
    app.get("/api/health", (_req, res) => res.json({ ok: true }));
    registerManifestRedirect(app);
    mountStaticDist(app, dist);
    server = createServer(app);
    await new Promise<void>((r) => server.listen(0, "127.0.0.1", () => r()));
    base = `http://127.0.0.1:${(server.address() as { port: number }).port}`;
  });

  after(async () => {
    await new Promise<void>((r) => server.close(() => r()));
    rmSync(dist, { recursive: true, force: true });
  });

  const get = (p: string) => fetch(base + p, { redirect: "manual" });

  it("un fitxer amb extensió que no existeix retorna 404 (no index.html)", async () => {
    for (const p of ["/foo.js", "/manifest.json", "/assets/missing.css", "/assets/index-VELL0000.js"]) {
      const res = await get(p);
      assert.equal(res.status, 404, p);
      assert.doesNotMatch(await res.text(), /Set i Mig/, p);
    }
  });

  it("les rutes de l app (sense extensió) reben index.html amb 200", async () => {
    for (const p of ["/", "/t/ABC123", "/partida/abc", "/perfil/"]) {
      const res = await get(p);
      assert.equal(res.status, 200, p);
      assert.match(res.headers.get("content-type") ?? "", /text\/html/, p);
      assert.match(await res.text(), /Set i Mig/, p);
    }
  });

  it("/regles/en, /regles/en/ i /regles/en/index.html fan 301 a /regles/", async () => {
    mkdirSync(path.join(dist, "regles"), { recursive: true });
    writeFileSync(path.join(dist, "regles", "index.html"), "<!doctype html><title>Rules</title>");
    for (const p of ["/regles/en", "/regles/en/", "/regles/en/index.html"]) {
      const res = await get(p);
      assert.equal(res.status, 301, p);
      assert.equal(res.headers.get("location"), "/regles/", p);
    }
    // Sense sessió, /regles/ és privat (login obligatori): vegeu staticHtmlLogin.test.ts.
    const canonical = await get("/regles/");
    assert.equal(canonical.status, 302);
    assert.equal(canonical.headers.get("location"), "/login?next=%2Fregles%2F");
  });

  it("/privacy i /terms responen el seu HTML i, si falta, 404 (mai la shell)", async () => {
    for (const p of ["/privacy", "/privacy/", "/terms", "/terms/", "/privacy/ca", "/terms/es/"]) {
      const missing = await get(p);
      assert.equal(missing.status, 404, p);
      assert.equal(await missing.text(), "Not found");
    }
    mkdirSync(path.join(dist, "privacy"), { recursive: true });
    writeFileSync(
      path.join(dist, "privacy", "index.html"),
      "<!doctype html><title>Privacy Policy · Seven Half Club</title><h1>Privacy Policy</h1>",
    );
    mkdirSync(path.join(dist, "terms", "es"), { recursive: true });
    writeFileSync(
      path.join(dist, "terms", "es", "index.html"),
      "<!doctype html><html lang=\"es\"><title>Condiciones del servicio · Seven Half Club</title></html>",
    );
    for (const p of ["/privacy", "/privacy/"]) {
      const res = await get(p);
      assert.equal(res.status, 200, p);
      assert.match(res.headers.get("content-type") ?? "", /text\/html/, p);
      const body = await res.text();
      assert.match(body, /<title>Privacy Policy · Seven Half Club<\/title>/);
      assert.doesNotMatch(body, /<title>Set i Mig<\/title>/);
    }
    for (const p of ["/terms/es", "/terms/es/"]) {
      const res = await get(p);
      assert.equal(res.status, 200, p);
      assert.match(await res.text(), /Condiciones del servicio/);
    }
  });

  it("/privadesa fa 301 a /privacy i conserva l'idioma si n'hi ha", async () => {
    assert.equal(privadesaRedirectTarget("/privadesa"), "/privacy");
    assert.equal(privadesaRedirectTarget("/privadesa/"), "/privacy");
    assert.equal(privadesaRedirectTarget("/privadesa/ca"), "/privacy/ca");
    assert.equal(privadesaRedirectTarget("/privadesa/ca/"), "/privacy/ca");
    assert.equal(privadesaRedirectTarget("/privadesa/es/"), "/privacy/es");
    assert.equal(privadesaRedirectTarget("/ca/privadesa"), "/privacy/ca");
    assert.equal(privadesaRedirectTarget("/es/privadesa/"), "/privacy/es");
    assert.equal(privadesaRedirectTarget("/en/privadesa"), "/privacy");
    assert.equal(privadesaRedirectTarget("/privacy"), null);

    const cases: [string, string][] = [
      ["/privadesa", "/privacy"],
      ["/privadesa/", "/privacy"],
      ["/privadesa/ca", "/privacy/ca"],
      ["/privadesa/ca/", "/privacy/ca"],
      ["/ca/privadesa", "/privacy/ca"],
      ["/es/privadesa/", "/privacy/es"],
      ["/privadesa?lang=ca", "/privacy?lang=ca"],
    ];
    for (const [from, to] of cases) {
      const res = await get(from);
      assert.equal(res.status, 301, from);
      assert.equal(res.headers.get("location"), to, from);
      assert.doesNotMatch(await res.text(), /Set i Mig/, from);
    }
  });

  it("/manifest.webmanifest fa 301 a /site.webmanifest", async () => {
    const res = await get("/manifest.webmanifest");
    assert.equal(res.status, 301);
    assert.equal(res.headers.get("location"), "/site.webmanifest");
  });

  it("/site.webmanifest continua amb 200 i content-type de manifest", async () => {
    const res = await get("/site.webmanifest");
    assert.equal(res.status, 200);
    assert.match(res.headers.get("content-type") ?? "", /^application\/manifest\+json/);
    assert.equal(JSON.parse(await res.text()).name, "Set i Mig");
  });

  it("els fitxers existents i les capçaleres d index.html i sw.js no canvien", async () => {
    const asset = await get("/assets/index-EQjPcBJ4.js");
    assert.equal(asset.status, 200);
    assert.match(asset.headers.get("content-type") ?? "", /javascript/);
    for (const p of ["/index.html", "/sw.js"]) {
      const res = await get(p);
      assert.equal(res.status, 200, p);
      assert.equal(res.headers.get("cache-control"), "public, max-age=0", p);
    }
    const sw = await get("/sw.js");
    assert.match(sw.headers.get("content-type") ?? "", /javascript/);
  });

  it("les rutes API no es toquen", async () => {
    const res = await get("/api/health");
    assert.equal(res.status, 200);
    assert.deepEqual(await res.json(), { ok: true });
  });

  it("hasFileExtension només mira l últim segment", () => {
    assert.equal(hasFileExtension("/foo.js"), true);
    assert.equal(hasFileExtension("/assets/a-1.css"), true);
    assert.equal(hasFileExtension("/"), false);
    assert.equal(hasFileExtension("/t/ABC123"), false);
    assert.equal(hasFileExtension("/v1.2/partida"), false);
    assert.equal(hasFileExtension("/.well-known/x"), false);
  });
});
