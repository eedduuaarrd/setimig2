import type { HandResultLine } from "../src/gameTypes.ts";
import type { Room } from "../shared/gameEngine.ts";
import { roomUsesIsolatedPlayChips } from "../shared/fastTournament.ts";
import { bankerFact, factsFromSlots, type ProfileHandFact, type ProfileHandResult, type SlotCountInput } from "../shared/profileHandCount.ts";
import { scoreCards } from "../shared/scoring.ts";
import { onHandRecordedForEngagement, onMatchRecordedForEngagement } from "./achievementsEngine.ts";
import { recordMatchSummary, recordResolvedHand } from "./playerStats.ts";
import { noteHandForGame, roomMode, trackGameFinished, trackLater } from "./analytics.ts";

function roomLabel(room: Room): string {
  if (room.isPrivate && room.inviteCode) return `Taula ${room.inviteCode}`;
  if (room.soloAi) {
    if (room.fastTournament) return "Torneig ràpid IA";
    return room.practiceMode ? "Pràctica IA" : "Partida IA";
  }
  return room.name || room.id;
}

/**
 * Mans que entren al perfil. El text «banca passada» NO és una passada del jugador
 * (abans `detailFlags` ho comptava així i un «Passat» real no sumava).
 * Un split és una mà per slot (fins a 3); una mà doblada és una sola mà.
 */
function factsForResult(room: Room, line: HandResultLine): ProfileHandFact[] {
  const player = room.players.find((p) => p.id === line.params?.seatId) ?? room.players.find((p) => p.name === line.name);
  if (!player) return [];
  if (player.isBanker) {
    const slot = player.handSlots[0];
    const points = line.handPoints ?? (slot ? scoreCards(slot.cards) : 0);
    if (slot?.cards.length || points > 0) {
      return [bankerFact({ points, cardCount: slot?.cards.length ?? 0, chipDelta: line.chipDelta, autoStood: slot?.autoStood })];
    }
    // La banca també pot guanyar una mà resumida només amb el resultat (sense cartes al slot).
    return [factFromResultLine(line)];
  }
  const slots: SlotCountInput[] = player.handSlots
    .map((slot, handIndex) => ({ slot, handIndex }))
    .filter(({ slot }) => slot.bet > 0)
    .map(({ slot, handIndex }) => ({
      points: scoreCards(slot.cards),
      cardCount: slot.cards.length,
      mort: slot.mort,
      doubled: slot.doubled,
      autoStood: slot.autoStood,
      handIndex,
    }));
  const hands =
    line.code === "hands" && line.params && "hands" in line.params
      ? line.params.hands.map((h) => ({ code: h.code, hand: h.params.hand }))
      : [];
  if (slots.length) return factsFromSlots(slots, hands);
  // Liquidació sense slots (només nom, resultat i delta): una mà, amb el resultat que ja porta.
  // Si no, una victòria no arribava a l'assoliment «Primera victòria».
  return [factFromResultLine(line)];
}

function factFromResultLine(line: HandResultLine): ProfileHandFact {
  const bust = line.outcome === "bust";
  const win = line.outcome === "win" || line.outcome === "jackpot";
  const result: ProfileHandResult = bust ? "bust" : line.outcome;
  return {
    points: line.handPoints ?? 0,
    bust,
    autoStood: false,
    winAgainstBank: win,
    naturalSevenHalf: false,
    doubled: false,
    result,
  };
}

let handStatWrites: Promise<void> = Promise.resolve();

/** Espera les estadístiques i recompenses ja engegades (els tests llegeixen el saldo just després). */
export function flushHandStatWritesForTests(): Promise<void> {
  return handStatWrites.catch(() => undefined);
}

export function recordHandStatsFromSettlement(room: Room, results: HandResultLine[] | undefined): Promise<void> {
  const run = recordHandStatsFromSettlementNow(room, results);
  handStatWrites = handStatWrites.then(() => run, () => run);
  return run;
}

async function recordHandStatsFromSettlementNow(room: Room, results: HandResultLine[] | undefined): Promise<void> {
  if (!results?.length) return;
  const at = room.lastRound?.at ?? Date.now();
  const label = roomLabel(room);
  const practice = roomUsesIsolatedPlayChips(room);

  for (const line of results) {
    const player = room.players.find((p) => p.id === line.params?.seatId) ?? room.players.find((p) => p.name === line.name);
    if (!player || player.isBot || !player.playerId || player.playerId.startsWith("bot-")) continue;
    const facts = factsForResult(room, line);
    if (!facts.length) continue;
    const mode = roomMode(room);
    for (const fact of facts) {
      const handIndex = await recordResolvedHand({
        playerId: player.playerId,
        roomId: room.id,
        roomLabel: label,
        finalPoints: fact.points,
        passed: fact.bust,
        naturalSevenHalf: fact.naturalSevenHalf,
        bet: player.bet,
        result: fact.result,
        chipDelta: line.chipDelta,
        wasBanker: player.isBanker,
        practice,
        mode,
        at,
      });
      noteHandForGame(room.id, player.playerId);
      trackLater(player.playerId, "hand_completed", {
        mode,
        result: fact.result === "jackpot" ? "win" : fact.result,
        chipDelta: line.chipDelta,
        wasBanker: player.isBanker,
        handIndex,
      });
      await onHandRecordedForEngagement({
        playerId: player.playerId,
        result: fact.result,
        chipDelta: line.chipDelta,
        passed: fact.bust,
        naturalSevenHalf: fact.naturalSevenHalf,
        practice,
        at,
      });
    }
    if (!practice && player.chips <= 0) trackLater(player.playerId, "chips_depleted", { mode });
  }
  if (room.fastTournament) await recordFastTournamentEndIfOver(room);
}

/**
 * Torneig ràpid: no té final de partida de la fase B. Es dona per acabat quan el jugador
 * es queda sense fitxes de torneig o és l'únic que en té; es desa a l'historial
 * (mode `tournament`) i s'emeten `game_finished` + `tournament_finished`.
 */
async function recordFastTournamentEndIfOver(room: Room): Promise<void> {
  for (const player of room.players) {
    if (player.isBot || !player.playerId || player.playerId.startsWith("bot-")) continue;
    const othersAlive = room.players.some((p) => p !== player && p.chips > 0);
    if (player.chips > 0 && othersAlive) continue;
    await recordMatchSummary({
      playerId: player.playerId,
      roomId: room.id,
      roomLabel: roomLabel(room),
      handsPlayed: room.phaseB?.handsCompleted ?? 0,
      viewerOutcome: player.chips > 0 ? "win" : "eliminated",
      practice: true,
      mode: "tournament",
    });
    trackGameFinished(room, player.playerId, "complete");
  }
}

function viewerOutcomeForPlayer(
  room: Room,
  playerName: string
): "win" | "lose" | "eliminated" | null {
  const match = room.matchResult;
  if (!match) return null;
  const row = match.ranking.find((r) => r.name === playerName);
  if (!row) return null;
  if (row.eliminated) return "eliminated";
  if (match.winnerName === playerName) return "win";
  return "lose";
}

export async function recordMatchEndForHumans(room: Room): Promise<void> {
  const label = roomLabel(room);
  const practice = roomUsesIsolatedPlayChips(room);
  const handsPlayed = room.phaseB?.handsCompleted ?? 0;
  for (const player of room.players) {
    if (player.isBot || !player.playerId || player.playerId.startsWith("bot-")) continue;
    const viewerOutcome = viewerOutcomeForPlayer(room, player.name);
    await recordMatchSummary({
      playerId: player.playerId,
      roomId: room.id,
      roomLabel: label,
      handsPlayed,
      viewerOutcome,
      practice,
      mode: roomMode(room),
    });
    trackGameFinished(room, player.playerId, "complete");
    await onMatchRecordedForEngagement({
      playerId: player.playerId,
      viewerOutcome,
      practice,
    });
  }
}
