import fs from "fs/promises";
import path from "path";
import type { RoomViewExtended } from "../shared/dealEvents.ts";

/**
 * Partides solo amb fitxes aïllades (pràctica i torneig ràpid) que s'han de poder refer si el
 * jugador perd la sala: reinici del servidor (les sales solo només viuen a memòria) o
 * desconnexió que treu el seient. El client, en reconnectar, torna a enviar `join_solo_room`
 * sense `practiceMode`/`fastTournament`; sense aquesta marca el servidor obria una partida
 * NORMAL (temporitzadors, «SALDO», i en sortir les fitxes de taula s'escrivien com a saldo real).
 *
 * Només es desa el mode i la configuració per refer una partida nova d'aquell mode; mai fitxes
 * ni saldos. Fitxer: `<BALANCE_DATA_DIR|data>/solo-isolated-sessions.json`.
 */
export type SoloIsolatedMode = "practice" | "fastTournament";

export type SoloIsolatedSession = {
  mode: SoloIsolatedMode;
  botCount?: number;
  botDifficulty?: string;
  houseRulesEnabled?: boolean;
  betProfileId?: string;
  updatedAt: number;
  /** Moment en què el jugador va perdre la sala (reinici o desconnexió). Sense valor: sala viva. */
  lostAt?: number;
};

/** Temps màxim des que es perd la sala fins que una reconnexió encara la refà en el mateix mode. */
export function soloIsolatedRestoreWindowMs(): number {
  const raw = Number(process.env.SOLO_ISOLATED_RESTORE_WINDOW_MS);
  return Number.isFinite(raw) && raw > 0 ? raw : 10 * 60_000;
}

/** Marques més velles que això es descarten en arrencar (partides abandonades). */
const MAX_AGE_MS = 12 * 60 * 60_000;

function dataDir(): string {
  return process.env.BALANCE_DATA_DIR || path.join(process.cwd(), "data");
}

/** Els tests que no carreguen sales persistides tampoc fan servir aquest fitxer (sense rastre entre fitxers). */
function diskEnabled(): boolean {
  return process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD !== "1";
}

function storePath(): string {
  return path.join(dataDir(), "solo-isolated-sessions.json");
}

let sessions = new Map<string, SoloIsolatedSession>();
let writeChain: Promise<void> = Promise.resolve();

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function parseEntry(value: unknown): SoloIsolatedSession | null {
  if (!isRecord(value)) return null;
  if (value.mode !== "practice" && value.mode !== "fastTournament") return null;
  if (typeof value.updatedAt !== "number" || !Number.isFinite(value.updatedAt)) return null;
  return {
    mode: value.mode,
    botCount: typeof value.botCount === "number" ? value.botCount : undefined,
    botDifficulty: typeof value.botDifficulty === "string" ? value.botDifficulty : undefined,
    houseRulesEnabled: value.houseRulesEnabled === true,
    betProfileId: typeof value.betProfileId === "string" ? value.betProfileId : undefined,
    updatedAt: value.updatedAt,
    lostAt: typeof value.lostAt === "number" ? value.lostAt : undefined,
  };
}

function schedulePersist(): Promise<void> {
  if (!diskEnabled()) return writeChain;
  const snapshot = Object.fromEntries(sessions.entries());
  const task = async () => {
    try {
      const p = storePath();
      await fs.mkdir(dataDir(), { recursive: true });
      const tmp = `${p}.tmp`;
      await fs.writeFile(tmp, JSON.stringify({ sessions: snapshot }, null, 2), "utf8");
      await fs.rename(tmp, p);
    } catch (err) {
      console.error("[soloIsolatedSessions] write failed:", err);
    }
  };
  writeChain = writeChain.then(task, task);
  return writeChain;
}

/**
 * En arrencar: totes les sales solo s'han perdut (només eren a memòria), així que cada marca
 * viva passa a «perduda ara». Les massa velles es descarten.
 */
export async function loadSoloIsolatedSessionsOnBoot(now = Date.now()): Promise<void> {
  sessions = new Map();
  if (!diskEnabled()) return;
  let raw: string;
  try {
    raw = await fs.readFile(storePath(), "utf8");
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code !== "ENOENT") {
      console.error("[soloIsolatedSessions] read failed:", err);
    }
    return;
  }
  try {
    const parsed: unknown = JSON.parse(raw);
    const entries = isRecord(parsed) && isRecord(parsed.sessions) ? parsed.sessions : {};
    for (const [playerId, value] of Object.entries(entries)) {
      const entry = parseEntry(value);
      if (!entry || now - entry.updatedAt > MAX_AGE_MS) continue;
      sessions.set(playerId, { ...entry, lostAt: entry.lostAt ?? now });
    }
  } catch (err) {
    console.error("[soloIsolatedSessions] invalid file, ignored:", err);
    return;
  }
  await schedulePersist();
}

/** Partida aïllada nova o represa: sala viva. */
export function markSoloIsolatedSessionActive(
  playerId: string,
  session: Omit<SoloIsolatedSession, "updatedAt" | "lostAt">,
  now = Date.now()
): void {
  sessions.set(playerId, { ...session, updatedAt: now });
  void schedulePersist();
}

/** El jugador ha reprès el seient (la sala segueix viva): la marca deixa d'estar perduda. */
export function touchSoloIsolatedSession(playerId: string, now = Date.now()): void {
  const entry = sessions.get(playerId);
  if (!entry || entry.lostAt === undefined) return;
  sessions.set(playerId, { ...entry, lostAt: undefined, updatedAt: now });
  void schedulePersist();
}

/** Desconnexió: si no torna dins la finestra, la propera partida ja no es refà en aquest mode. */
export function markSoloIsolatedSessionLost(playerId: string, now = Date.now()): void {
  const entry = sessions.get(playerId);
  if (!entry) return;
  sessions.set(playerId, { ...entry, lostAt: now, updatedAt: now });
  void schedulePersist();
}

/** Sortida confirmada o partida normal nova: no hi ha res a refer. */
export function clearSoloIsolatedSession(playerId: string): void {
  if (!sessions.delete(playerId)) return;
  void schedulePersist();
}

/**
 * Esborrat de compte: treu la marca del jugador de la memòria i del fitxer, sense tocar les dels
 * altres (des d'un script, la memòria és buida: per això s'edita el fitxer i no s'hi bolca la memòria).
 */
export async function forgetSoloIsolatedSession(playerId: string): Promise<boolean> {
  const inMemory = sessions.delete(playerId);
  let onDisk = false;
  if (!diskEnabled()) return inMemory;
  const task = async () => {
    let raw: string;
    try {
      raw = await fs.readFile(storePath(), "utf8");
    } catch {
      return;
    }
    const parsed: unknown = JSON.parse(raw);
    if (!isRecord(parsed) || !isRecord(parsed.sessions) || !(playerId in parsed.sessions)) return;
    delete parsed.sessions[playerId];
    const tmp = `${storePath()}.tmp`;
    await fs.writeFile(tmp, JSON.stringify(parsed, null, 2), "utf8");
    await fs.rename(tmp, storePath());
    onDisk = true;
  };
  writeChain = writeChain.then(task, task);
  await writeChain;
  return inMemory || onDisk;
}

/** Marca perduda dins la finestra de restauració, o `null`. */
export function restorableSoloIsolatedSession(
  playerId: string,
  now = Date.now()
): SoloIsolatedSession | null {
  const entry = sessions.get(playerId);
  if (!entry || entry.lostAt === undefined) return null;
  if (now - entry.lostAt > soloIsolatedRestoreWindowMs()) {
    clearSoloIsolatedSession(playerId);
    return null;
  }
  return entry;
}

export async function flushSoloIsolatedSessionWritesForTests(): Promise<void> {
  await writeChain;
}

export function resetSoloIsolatedSessionsForTests(): void {
  sessions = new Map();
}

/**
 * Partida solo autoritativa. L'estat (mazo, cartes tapades) viu al motor del servidor;
 * cap resposta cap al client passa per aquí sense `roomToView`. El registre el fa `game.ts`
 * en carregar-se (evita un cicle d'imports).
 */
export type AuthoritativeSoloActor = {
  id: string;
  join: (roomId: string) => void;
  emit: (event: string, payload?: unknown) => void;
};

export type AuthoritativeSoloError = {
  message: string;
  code: string;
  required?: number;
  balance?: number;
  actionId?: string;
};

export type AuthoritativeSoloResult = {
  view: RoomViewExtended | null;
  error: AuthoritativeSoloError | null;
};

type AuthoritativeSoloRuntime = {
  join: (actor: AuthoritativeSoloActor, payload: unknown) => Promise<void>;
  action: (
    playerId: string,
    action: string,
    body: Record<string, unknown>,
    meta: { playerToken: string; actionSeq: number },
  ) => Promise<AuthoritativeSoloResult>;
  view: (playerId: string) => RoomViewExtended | null;
  leave: (playerId: string, seatToken?: string) => Promise<boolean>;
};

let runtime: AuthoritativeSoloRuntime | null = null;

export function registerAuthoritativeSoloRuntime(next: AuthoritativeSoloRuntime): void {
  runtime = next;
}

export function httpSoloActorId(playerId: string): string {
  return `http:${playerId}`;
}

function requireRuntime(): AuthoritativeSoloRuntime {
  if (!runtime) {
    throw new Error("El motor solo del servidor no està registrat.");
  }
  return runtime;
}

/** JSON que pot viatjar al navegador. El mazo no forma part de la vista; si hi aparegués, es treu. */
export function soloClientJson(view: RoomViewExtended): Record<string, unknown> {
  const json = JSON.parse(JSON.stringify(view)) as Record<string, unknown>;
  delete json.deck;
  return json;
}

export type AuthoritativeSoloOpenOptions = {
  botCount?: number;
  botDifficulty?: string;
  houseRulesEnabled?: boolean;
  practiceMode?: boolean;
  fastTournament?: boolean;
  soloResumeToken?: string;
  /** Partida nova explícita. La represa no l'envia: així es refà la pràctica perduda. */
  intent?: "new";
};

async function emitSoloJoin(
  playerId: string,
  playerName: string,
  playerToken: string,
  options: AuthoritativeSoloOpenOptions,
): Promise<AuthoritativeSoloResult> {
  const rt = requireRuntime();
  let result: AuthoritativeSoloResult = { view: null, error: null };
  const actor: AuthoritativeSoloActor = {
    id: httpSoloActorId(playerId),
    join() {},
    emit(event, payload) {
      if (event === "joined_room" && payload && typeof payload === "object") {
        result = { view: payload as RoomViewExtended, error: null };
      } else if (event === "game_error" && payload && typeof payload === "object") {
        const body = payload as AuthoritativeSoloError;
        result = {
          view: result.view,
          error: {
            message: typeof body.message === "string" ? body.message : "Error",
            code: typeof body.code === "string" ? body.code : "BAD",
            required: typeof body.required === "number" ? body.required : undefined,
            balance: typeof body.balance === "number" ? body.balance : undefined,
          },
        };
      }
    },
  };
  await rt.join(actor, {
    playerName,
    playerId,
    playerToken,
    soloResumeToken: options.soloResumeToken,
    botCount: options.botCount,
    botDifficulty: options.botDifficulty,
    houseRulesEnabled: options.houseRulesEnabled === true,
    practiceMode: options.practiceMode === true,
    fastTournament: options.fastTournament ? { enabled: true } : undefined,
    ...(options.intent ? { intent: options.intent } : {}),
  });
  if (!result.view && !result.error) {
    const view = rt.view(playerId);
    result = view
      ? { view, error: null }
      : { view: null, error: { message: "No s'ha pogut obrir la partida.", code: "BAD" } };
  }
  return result;
}

/** Partida nova (o represa del mateix seient HTTP). `intent: "new"` no refà una pràctica perduda. */
export function openAuthoritativeSolo(
  playerId: string,
  playerName: string,
  playerToken: string,
  options: AuthoritativeSoloOpenOptions,
): Promise<AuthoritativeSoloResult> {
  return emitSoloJoin(playerId, playerName, playerToken, options);
}

/**
 * Reconnexió: si la sala encara és a memòria se'n torna la vista, sense tornar a obrir compra.
 * Si el servidor s'ha reiniciat, es refà la pràctica o el torneig ràpid dins la finestra.
 * Sense sala ni marca, no crea una solo normal (això cobraria compra).
 */
export async function resumeAuthoritativeSolo(
  playerId: string,
  playerName: string,
  playerToken: string,
  soloResumeToken?: string,
): Promise<AuthoritativeSoloResult | null> {
  const rt = requireRuntime();
  const existing = rt.view(playerId);
  if (existing) return { view: existing, error: null };
  if (!restorableSoloIsolatedSession(playerId)) return null;
  return emitSoloJoin(playerId, playerName, playerToken, { soloResumeToken });
}

export function readAuthoritativeSoloView(playerId: string): RoomViewExtended | null {
  return requireRuntime().view(playerId);
}

export function actAuthoritativeSolo(
  playerId: string,
  action: string,
  body: Record<string, unknown>,
  meta: { playerToken: string; actionSeq: number },
): Promise<AuthoritativeSoloResult> {
  return requireRuntime().action(playerId, action, body, meta);
}

export function closeAuthoritativeSolo(playerId: string, seatToken?: string): Promise<boolean> {
  return requireRuntime().leave(playerId, seatToken);
}
