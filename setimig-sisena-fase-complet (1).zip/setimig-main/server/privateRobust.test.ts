import { describe, it, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";
import fs from "fs/promises";
import os from "os";
import path from "path";
import { createServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket } from "socket.io-client";
import {
  getGameHostForTests,
  getRoomSnapshotForTests,
  resetGameStateForTests,
  setHostTimersPausedForTests,
  setupGameHandlers,
} from "./game.ts";
import { issuePlayerToken } from "./playerToken.ts";
import { removePrivateRoomFromStore, resetPrivateRoomStoreCacheForTests } from "./privateRoomStore.ts";
import {
  beginBettingPhase,
  clearRoomTimers,
  currentPlayer,
  fillPrivateBots,
  type Room,
} from "../shared/gameEngine.ts";
import { resetTestDeckSeedWarningsForTests } from "../shared/shuffle.ts";
import { removeTestDataDir } from "./testing/testDataDir.ts";

const HOST_ID = "privrobusthost00001";
const GUEST_ID = "privrobustguest001";

function connect(url: string): Promise<Socket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.on("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.on("connect_error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

function waitJoined(socket: Socket): Promise<{
  id: string;
  inviteCode?: string;
  viewerSeatToken?: string;
  phase?: string;
  minBet?: number;
  players?: { bet?: number; chips?: number; handSlots?: unknown[] }[];
}> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("join timeout")), 15_000);
    socket.once("joined_room", (room) => {
      clearTimeout(timer);
      resolve(room);
    });
  });
}

/**
 * Espera que l'estat del servidor compleixi `pred`. Escolta els dos sockets abans de
 * comprovar la foto, així no depèn de quin `room_update` arribi primer ni d'una espera fixa.
 * `onMatch` corre al mateix torn que la coincidència (abans de cedir el control).
 */
function whenRoom(
  roomId: string,
  sockets: Socket[],
  pred: (room: Room) => boolean,
  onMatch?: (room: Room) => void,
): Promise<Room> {
  return new Promise((resolve) => {
    let settled = false;
    const tryFinish = () => {
      if (settled) return;
      const room = getRoomSnapshotForTests(roomId);
      if (!room || !pred(room)) return;
      settled = true;
      for (const socket of sockets) socket.off("room_update", tryFinish);
      onMatch?.(room);
      resolve(room);
    };
    for (const socket of sockets) socket.on("room_update", tryFinish);
    tryFinish();
  });
}

/** El proper `game_error` d'aquest socket. S'ha de registrar abans de l'`emit`. */
function expectGameError(socket: Socket, code: string): Promise<{ code?: string; message?: string }> {
  return new Promise((resolve, reject) => {
    socket.once("game_error", (err: { code?: string; message?: string }) => {
      if (err?.code === code) resolve(err);
      else reject(new Error(`esperava ${code} i ha arribat ${err?.code ?? "?"} (${err?.message ?? ""})`));
    });
  });
}

/**
 * Llavor 4 amb amfitrió, convidat i un bot (en aquest ordre de seient): el bot guanya el
 * sorteig (figura de cors) i el primer torn és sempre l'amfitrió. El convidat és qui pica fora de torn.
 */
const WRONG_TURN_DECK_SEED = "4";

function useWrongTurnDeck(): () => void {
  const prev = {
    seed: process.env.SETIMIG_TEST_DECK_SEED,
    shuffle: process.env.SETIMIG_TEST_SHUFFLE_SEED,
    host: process.env.SETIMIG_HOST,
    env: process.env.NODE_ENV,
  };
  process.env.SETIMIG_TEST_DECK_SEED = WRONG_TURN_DECK_SEED;
  delete process.env.SETIMIG_TEST_SHUFFLE_SEED;
  process.env.SETIMIG_HOST = "127.0.0.1";
  if (process.env.NODE_ENV === "production") process.env.NODE_ENV = "test";
  resetTestDeckSeedWarningsForTests();
  return () => {
    if (prev.seed === undefined) delete process.env.SETIMIG_TEST_DECK_SEED;
    else process.env.SETIMIG_TEST_DECK_SEED = prev.seed;
    if (prev.shuffle === undefined) delete process.env.SETIMIG_TEST_SHUFFLE_SEED;
    else process.env.SETIMIG_TEST_SHUFFLE_SEED = prev.shuffle;
    if (prev.host === undefined) delete process.env.SETIMIG_HOST;
    else process.env.SETIMIG_HOST = prev.host;
    if (prev.env === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = prev.env;
    resetTestDeckSeedWarningsForTests();
  };
}

async function startServer(): Promise<{
  url: string;
  http: ReturnType<typeof createServer>;
  io: SocketIOServer;
}> {
  const http = createServer();
  const io = new SocketIOServer(http, { cors: { origin: "*" } });
  await setupGameHandlers(io);
  await new Promise<void>((r) => http.listen(0, "127.0.0.1", () => r()));
  const port = (http.address() as { port: number }).port;
  return { url: `http://127.0.0.1:${port}`, http, io };
}

async function stopServer(io: SocketIOServer, http: ReturnType<typeof createServer>) {
  io.close();
  await new Promise<void>((r) => http.close(() => r()));
}

describe("private tables robust", () => {
  let dataDir: string;

  beforeEach(async () => {
    dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "setimig-priv-"));
    process.env.BALANCE_DATA_DIR = dataDir;
    process.env.SETIMIG_TEST_FAST = "1";
    resetGameStateForTests();
    resetPrivateRoomStoreCacheForTests();
  });

  afterEach(async () => {
    delete process.env.SETIMIG_TEST_FAST;
    // Atura els temporitzadors del joc i buida totes les escriptures abans d'esborrar (abans: ENOTEMPTY).
    await removeTestDataDir(dataDir);
  });

  it("rejoin mid-hand preserves seat, bet, and chips", async () => {
    const hostToken = issuePlayerToken(HOST_ID)!;
    const guestToken = issuePlayerToken(GUEST_ID)!;
    const { url, http, io } = await startServer();

    const host = await connect(url);
    host.emit("create_private_table", {
      playerName: "Host",
      playerId: HOST_ID,
      playerToken: hostToken,
    });
    const hostRoom = await waitJoined(host);

    const guest = await connect(url);
    guest.emit("join_private_table", {
      inviteCode: hostRoom.inviteCode,
      playerName: "Guest",
      playerId: GUEST_ID,
      playerToken: guestToken,
    });
    const guestRoom = await waitJoined(guest);
    const guestSeat = guestRoom.viewerSeatToken!;
    let actionSeq = 1;

    host.emit("fill_private_bots", {
      roomId: hostRoom.id,
      playerToken: hostToken,
      actionSeq: actionSeq++,
    });
    await new Promise((r) => setTimeout(r, 120));
    host.emit("start_game", {
      roomId: hostRoom.id,
      playerToken: hostToken,
      actionSeq: actionSeq++,
    });

    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("game never started")), 45_000);
      guest.on("room_update", (room: { phase: string }) => {
        if (room.phase === "betting") {
          clearTimeout(timer);
          resolve();
        }
      });
    });

    guest.emit("place_bet", {
      roomId: hostRoom.id,
      amount: hostRoom.minBet ?? 100,
      playerToken: guestToken,
      actionSeq: 1,
    });

    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("bet not applied")), 15_000);
      guest.on("room_update", (room: { players?: { bet?: number }[] }) => {
        const me = room.players?.find((p) => p.bet && p.bet > 0);
        if (me) {
          clearTimeout(timer);
          resolve();
        }
      });
    });

    const beforeSnap = getRoomSnapshotForTests(hostRoom.id);
    const guestBefore = beforeSnap!.players.find((p) => p.seatToken === guestSeat)!;
    const chipsBefore = guestBefore.chips;
    const betBefore = guestBefore.bet;

    guest.disconnect();
    await new Promise((r) => setTimeout(r, 200));

    const guest2 = await connect(url);
    guest2.emit("join_private_table", {
      inviteCode: hostRoom.inviteCode,
      playerName: "Guest",
      seatToken: guestSeat,
      playerId: GUEST_ID,
      playerToken: guestToken,
    });
    const resumed = await waitJoined(guest2);
    const me = resumed.players?.find((p) => p.bet === betBefore);
    assert.equal(resumed.viewerSeatToken, guestSeat);
    assert.equal(me?.chips, chipsBefore);
    assert.equal(me?.bet, betBefore);

    host.disconnect();
    guest2.disconnect();
    await stopServer(io, http);
  });

  it("reloads private room state after simulated server restart", async () => {
    const hostToken = issuePlayerToken(HOST_ID)!;
    const guestToken = issuePlayerToken(GUEST_ID)!;
    let { url, http, io } = await startServer();

    const host = await connect(url);
    host.emit("create_private_table", {
      playerName: "Host",
      playerId: HOST_ID,
      playerToken: hostToken,
    });
    const hostRoom = await waitJoined(host);

    const guest = await connect(url);
    guest.emit("join_private_table", {
      inviteCode: hostRoom.inviteCode,
      playerName: "Guest",
      playerId: GUEST_ID,
      playerToken: guestToken,
    });
    const guestRoom = await waitJoined(guest);
    const guestSeat = guestRoom.viewerSeatToken!;
    let seq = 1;

    host.emit("fill_private_bots", { roomId: hostRoom.id, playerToken: hostToken, actionSeq: seq++ });
    await new Promise((r) => setTimeout(r, 120));
    host.emit("start_game", { roomId: hostRoom.id, playerToken: hostToken, actionSeq: seq++ });

    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("betting timeout")), 45_000);
      guest.on("room_update", (room: { phase: string }) => {
        if (room.phase === "betting") {
          clearTimeout(timer);
          resolve();
        }
      });
    });

    guest.emit("place_bet", {
      roomId: hostRoom.id,
      amount: 100,
      playerToken: guestToken,
      actionSeq: 1,
    });
    await new Promise((r) => setTimeout(r, 400));

    const snap = getRoomSnapshotForTests(hostRoom.id)!;
    const guestPlayer = snap.players.find((p) => p.seatToken === guestSeat)!;
    const savedBet = guestPlayer.bet;
    const savedChips = guestPlayer.chips;
    const invite = hostRoom.inviteCode!;

    host.disconnect();
    guest.disconnect();
    await stopServer(io, http);

    resetGameStateForTests();
    resetPrivateRoomStoreCacheForTests();
    ({ url, http, io } = await startServer());

    const guest2 = await connect(url);
    guest2.emit("join_private_table", {
      inviteCode: invite,
      playerName: "Guest",
      seatToken: guestSeat,
      playerId: GUEST_ID,
      playerToken: guestToken,
    });
    const resumed = await waitJoined(guest2);
    const me = resumed.players?.find((p) => p.bet === savedBet);
    assert.equal(me?.chips, savedChips);
    assert.equal(me?.bet, savedBet);
    assert.notEqual(resumed.phase, "waiting");

    guest2.disconnect();
    await stopServer(io, http);
  });

  it("does not restore a private room after its final player leaves", async () => {
    const hostToken = issuePlayerToken(HOST_ID)!;
    const { url, http, io } = await startServer();

    const host = await connect(url);
    host.emit("create_private_table", {
      playerName: "Host",
      playerId: HOST_ID,
      playerToken: hostToken,
    });
    const room = await waitJoined(host);
    const inviteCode = room.inviteCode!;

    const left = new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("room_left timeout")), 5_000);
      host.once("room_left", () => {
        clearTimeout(timer);
        resolve();
      });
    });
    host.emit("leave_room", room.id);
    await left;

    const storePath = path.join(dataDir, "private-rooms.json");
    const store = JSON.parse(await fs.readFile(storePath, "utf8")) as {
      rooms: Record<string, unknown>;
      inviteIndex: Record<string, string>;
    };
    assert.equal(store.rooms[room.id], undefined);
    assert.equal(store.inviteIndex[inviteCode], undefined);

    host.disconnect();
    await stopServer(io, http);
    resetGameStateForTests();

    const restarted = await startServer();
    const guest = await connect(restarted.url);
    const errorPromise = new Promise<{ code?: string }>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("missing room-not-found error")), 5_000);
      guest.once("game_error", (error) => {
        clearTimeout(timer);
        resolve(error);
      });
    });
    guest.emit("join_private_table", {
      inviteCode,
      playerName: "Guest",
      playerId: GUEST_ID,
      playerToken: issuePlayerToken(GUEST_ID)!,
    });
    const error = await errorPromise;
    assert.equal(error.code, "ROOM_NOT_FOUND");

    guest.disconnect();
    await stopServer(restarted.io, restarted.http);
  });

  it("does not overwrite a malformed private-room store on the next write", async () => {
    const file = path.join(dataDir, "private-rooms.json");
    for (const contents of ["{", JSON.stringify({ rooms: [], inviteIndex: {} })]) {
      await fs.writeFile(file, contents, "utf8");
      resetPrivateRoomStoreCacheForTests();

      await assert.rejects(removePrivateRoomFromStore("missing-room"));
      assert.equal(await fs.readFile(file, "utf8"), contents);
    }
  });

  it("rejects invalid private actions (token, replay, wrong turn)", { timeout: 20_000 }, async () => {
    const restoreDeck = useWrongTurnDeck();
    const hostToken = issuePlayerToken(HOST_ID)!;
    const guestToken = issuePlayerToken(GUEST_ID)!;
    const { url, http, io } = await startServer();
    const host = await connect(url);
    const guest = await connect(url);
    // El motor de test tapa qualsevol temporitzador a 48 ms. Sense pausa, el termini
    // d'aposta i els bots mouen el torn abans que arribi el `room_update`.
    setHostTimersPausedForTests(true);
    try {
      host.emit("create_private_table", {
        playerName: "Host",
        playerId: HOST_ID,
        playerToken: hostToken,
      });
      const hostRoom = await waitJoined(host);

      guest.emit("join_private_table", {
        inviteCode: hostRoom.inviteCode,
        playerName: "Guest",
        playerId: GUEST_ID,
        playerToken: guestToken,
      });
      await waitJoined(guest);

      const seated = getRoomSnapshotForTests(hostRoom.id);
      assert.ok(seated);
      fillPrivateBots(seated, 3);
      assert.equal(seated.players.length, 3);
      assert.equal(seated.players[2]?.isBot, true);

      const bankerReady = whenRoom(hostRoom.id, [host, guest], (room) => room.players.some((p) => p.isBanker));
      host.emit("start_game", { roomId: hostRoom.id, playerToken: hostToken, actionSeq: 1 });
      const drawn = await bankerReady;
      assert.equal(drawn.players.find((p) => p.isBot)?.isBanker, true, "llavor 4: la banca és el bot");
      beginBettingPhase(getGameHostForTests(), drawn);
      clearRoomTimers(getGameHostForTests(), drawn);
      assert.equal(drawn.phase, "betting");
      const betting = drawn;

      const badToken = expectGameError(guest, "BAD_TOKEN");
      guest.emit("place_bet", {
        roomId: hostRoom.id,
        amount: betting.minBet,
        playerToken: issuePlayerToken("otherplayer00001"),
        actionSeq: 1,
      });
      assert.equal((await badToken).code, "BAD_TOKEN");

      const guestBet = whenRoom(
        hostRoom.id,
        [host, guest],
        (room) => {
          const player = room.players.find((p) => p.playerId === GUEST_ID);
          return !!player && player.bet === betting.minBet && player.lastActionSeq === 1;
        },
      );
      guest.emit("place_bet", {
        roomId: hostRoom.id,
        amount: betting.minBet,
        playerToken: guestToken,
        actionSeq: 1,
      });
      await guestBet;

      const replay = expectGameError(guest, "REPLAY");
      guest.emit("place_bet", {
        roomId: hostRoom.id,
        amount: betting.minBet,
        playerToken: guestToken,
        actionSeq: 1,
      });
      assert.equal((await replay).code, "REPLAY");

      const playingReady = whenRoom(hostRoom.id, [host, guest], (room) => room.phase === "playing", (room) => {
        clearRoomTimers(getGameHostForTests(), room);
      });
      host.emit("place_bet", {
        roomId: hostRoom.id,
        amount: betting.minBet,
        playerToken: hostToken,
        actionSeq: 2,
      });
      const playing = await playingReady;

      const guestPlayer = playing.players.find((player) => player.playerId === GUEST_ID);
      const banker = playing.players.find((player) => player.isBanker);
      assert.ok(guestPlayer);
      assert.equal(banker?.isBot, true, "llavor 4: la banca és el bot");
      assert.equal(currentPlayer(playing)?.playerId, HOST_ID, "el torn és de l'amfitrió");
      assert.notEqual(currentPlayer(playing)?.playerId, GUEST_ID);
      assert.equal(guestPlayer.lastActionSeq, 1);

      const turnErr = expectGameError(guest, "BAD_TURN");
      guest.emit("hit", {
        roomId: hostRoom.id,
        playerToken: guestToken,
        actionSeq: (guestPlayer.lastActionSeq ?? 0) + 1,
      });
      assert.equal((await turnErr).code, "BAD_TURN");
      assert.equal(getRoomSnapshotForTests(hostRoom.id)?.phase, "playing");
      assert.equal(currentPlayer(getRoomSnapshotForTests(hostRoom.id)!)?.playerId, HOST_ID);
    } finally {
      host.disconnect();
      guest.disconnect();
      await stopServer(io, http);
      setHostTimersPausedForTests(false);
      restoreDeck();
    }
  });
});
