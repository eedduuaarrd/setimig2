import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { createServer, type Server } from "node:http";
import os from "node:os";
import path from "node:path";
import express from "express";
import { registerApiNotFound, registerManifestRedirect } from "./spaFallback.ts";
import { mountStaticDist } from "./staticAssets.ts";

describe("/api/* desconegudes retornen JSON, no index.html", () => {
  let dist = "";
  let server: Server;
  let base = "";
  before(async () => {
    dist = mkdtempSync(path.join(os.tmpdir(), "setimig-api404-"));
    writeFileSync(path.join(dist, "index.html"), "<!doctype html><title>Set i Mig</title>");
    const app = express();
    app.use(express.json());
    app.post("/api/player-session", (_req, res) => res.json({ ok: true }));
    app.post("/api/auth/email/start", (_req, res) => res.json({ ok: true }));
    app.get("/api/auth/providers", (_req, res) => res.json({ ok: true }));
    registerApiNotFound(app);
    registerManifestRedirect(app);
    mountStaticDist(app, dist);
    server = createServer(app);
    await new Promise<void>((r) => server.listen(0, "127.0.0.1", () => r()));
    base = `http://127.0.0.1:${(server.address() as { port: number }).port}`;
  });
  after(async () => {
    await new Promise<void>((r) => server.close(() => r()));
    rmSync(dist, { recursive: true, force: true });
  });

  it("/api/no-existeix → 404 JSON", async () => {
    for (const [m, p] of [["GET", "/api/no-existeix"], ["POST", "/api/no-existeix"], ["GET", "/api"]]) {
      const res = await fetch(base + p, { method: m });
      assert.equal(res.status, 404, `${m} ${p}`);
      assert.match(res.headers.get("content-type") ?? "", /application\/json/);
      assert.deepEqual(await res.json(), { error: "NOT_FOUND" });
    }
  });

  it("GET /api/player-session → 405 JSON amb Allow: POST", async () => {
    const res = await fetch(base + "/api/player-session");
    assert.equal(res.status, 405);
    assert.equal(res.headers.get("allow"), "POST");
    assert.deepEqual(await res.json(), { error: "METHOD_NOT_ALLOWED" });
    const r2 = await fetch(base + "/api/auth/providers", { method: "POST" });
    assert.equal(r2.status, 405);
    assert.equal(r2.headers.get("allow"), "GET, HEAD");
  });

  it("les rutes existents i d auth continuen funcionant", async () => {
    const a = await fetch(base + "/api/player-session", { method: "POST", headers: { "content-type": "application/json" }, body: "{}" });
    assert.equal(a.status, 200);
    const b = await fetch(base + "/api/auth/email/start", { method: "POST", headers: { "content-type": "application/json" }, body: "{}" });
    assert.equal(b.status, 200);
    assert.equal((await fetch(base + "/api/auth/providers")).status, 200);
  });

  it("les rutes de la SPA (no /api) encara reben index.html", async () => {
    for (const p of ["/login/correu", "/", "/apilat", "/socketio"]) {
      const res = await fetch(base + p);
      assert.equal(res.status, 200, p);
      assert.match(await res.text(), /Set i Mig/, p);
    }
  });
});
