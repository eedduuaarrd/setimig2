import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient } from "socket.io-client";
import { getGameHostForTests, getRoomSnapshotForTests, setupGameHandlers } from "./game.ts";
import { clearRoomTimers, publishRoom, runBotAction } from "../shared/gameEngine.ts";
import { applyBankerToPlayer } from "../shared/bankRotation.ts";
import { setBotRngForTests } from "../shared/ai/botProfile.ts";
import type { Card } from "../src/gameTypes.ts";

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";

function figure(suit: Card["suit"] = "clubs"): Card {
  return { suit, value: 10, points: 0.5 };
}

describe("bot split in live solo room", () => {
  it("bot split advances play (no stuck loop)", async () => {
    process.env.SETIMIG_TEST_FAST = "1";
    const http = createServer();
    const io = new SocketIOServer(http, { cors: { origin: "*" } });
    await setupGameHandlers(io);
    await new Promise<void>((r) => http.listen(0, "127.0.0.1", () => r()));
    const port = (http.address() as { port: number }).port;
    const url = `http://127.0.0.1:${port}`;

    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    await new Promise<void>((r) => socket.on("connect", () => r()));

    let roomId = "";

    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("join timeout")), 15_000);
      socket.once("joined_room", (room: { id: string }) => {
        clearTimeout(timer);
        roomId = room.id;
        resolve();
      });
      socket.emit("join_solo_room", {
        playerName: "SplitFlow",
        playerId: "botsplitflow0001",
        botCount: 1,
      });
    });

    // El servidor arrenca la mà sol després de `joined_room` (amb una espera pel mig). Abans el test
    // preparava la sala de seguida i competia amb aquest arrencada: si el servidor arribava primer,
    // el bot ja era la banca (primera mà solo), el torn calculat era el de l'humà i el bot no feia
    // res («handSlots.length 1»). Ara s'espera que la mà hagi arrencat, s'aturen els seus
    // temporitzadors i es prepara la sala de manera determinista: humà de banca, torn del bot.
    const host = getGameHostForTests();
    const deadline = Date.now() + 15_000;
    let snap = getRoomSnapshotForTests(roomId);
    while (!(snap && snap.phase === "betting" && snap.players.some((p) => p.isBanker))) {
      assert.ok(Date.now() < deadline, `la mà no ha arrencat (fase ${snap?.phase})`);
      await new Promise((r) => setTimeout(r, 5));
      snap = getRoomSnapshotForTests(roomId);
    }
    clearRoomTimers(host, snap);
    assert.ok(snap);
    snap!.houseRulesEnabled = true;
    const bot = snap!.players.find((p) => p.isBot);
    const human = snap!.players.find((p) => !p.isBot);
    assert.ok(bot && human);
    applyBankerToPlayer(snap!.players, human!.id);
    human!.chips = 5_000;
    human!.bet = 0;
    human!.handSlots = [];
    snap!.phase = "playing";
    snap!.turnPlayerIndex = 0; // l'únic que no fa de banca és el bot
    bot!.chips = 500;
    bot!.bet = 100;
    bot!.status = "playing";
    bot!.activeSlotIndex = 0;
    bot!.handSlots = [
      {
        id: "rigged",
        bet: 100,
        cards: [
          { id: "a", card: figure("hearts"), faceUp: true },
          { id: "b", card: figure("diamonds"), faceUp: true },
        ],
        doubled: false,
        canDouble: false,
        mort: false,
        blindPair: false,
        blindUntilBankEnd: false,
        mortOffered: false,
        status: "playing",
      },
    ];
    // Des dels perfils de bot (#182) la separació és probabilística; el test vol el camí amb separació.
    setBotRngForTests(() => 0);
    try {
      runBotAction(host, snap!, bot!);
    } finally {
      setBotRngForTests(null);
    }
    assert.equal(bot!.handSlots.length, 2);

    let phaseAdvanced = false;
    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("stuck after split")), 20_000);
      socket.on("room_update", (room: { phase: string }) => {
        if (room.phase === "banker" || room.phase === "settlement" || room.phase === "betting") {
          phaseAdvanced = true;
          clearTimeout(timer);
          resolve();
        }
      });
      void publishRoom(host, snap!);
    });

    try {
      assert.equal(phaseAdvanced, true);
    } finally {
      delete process.env.SETIMIG_TEST_FAST;
      socket.disconnect();
      io.close();
      await new Promise<void>((r) => http.close(() => r()));
    }
  });
});
