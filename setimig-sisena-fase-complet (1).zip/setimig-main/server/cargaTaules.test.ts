import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { runLoadTest } from "./cargaTaules.ts";

/** Versió curta de la prova de càrrega (la llarga: `npm run test:carrega`). */
describe("prova de càrrega (curta)", () => {
  it("5 taules de bots simultànies juguen mans sense errors", async () => {
    const report = await runLoadTest({ tables: 5, botsPerTable: 3, durationMs: 3_000, realTimers: false });
    assert.equal(report.tablesJoined, 5);
    assert.ok(report.handsSettled >= 5, `mans resoltes: ${report.handsSettled}`);
    assert.equal(report.gameErrors, 0, JSON.stringify(report.gameErrorCodes));
    assert.ok(report.actionLatencyMs.p95 < 250, `latència p95 ${report.actionLatencyMs.p95} ms`);
  });
});
