import { describe, it, after } from "node:test";
import assert from "node:assert/strict";
import { createServer, type Server as HttpServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket as ClientSocket } from "socket.io-client";
import {
  setupGameHandlers,
  resetGameStateForTests,
  getGameHostForTests,
  getRoomSnapshotForTests,
  type ResumeStatus,
} from "./game.ts";
import { clearRoomTimers, nonBankersInPlayOrder, publishRoom, type Room } from "../shared/gameEngine.ts";
import { DEFAULT_CHIPS } from "../shared/chips.ts";
import type { RoomView } from "../src/gameTypes.ts";
import { getBalance, flushBalanceWrites } from "./balances.ts";
import { flushHandStatWritesForTests } from "./handStatsRecorder.ts";

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";
// Ritme ràpid de test: aquest fitxer no aposta mai i espera que la finestra d'apostes
// (HUMAN_BET_TIMEOUT_MS, 18 s reals) es tanqui sola fins a «playing», però les esperes són de 15 s.
// Abans només passava dins de `npm test` (SETIMIG_TEST_FAST=1 a l'entorn); executat sol fallava
// a les 3 proves amb «playing timeout (fase betting)». El motor el llegeix en temps d'execució.
process.env.SETIMIG_TEST_FAST = "1";

/**
 * S1 (seguiment) · «Sortir» confirmat en una taula privada allibera el seient a l'instant,
 * també a mitja mà; una desconnexió el conserva durant la gràcia.
 */

type TestServer = { url: string; http: HttpServer; io: SocketIOServer };

async function startTestServer(): Promise<TestServer> {
  const http = createServer();
  const io = new SocketIOServer(http, { cors: { origin: "*" } });
  await setupGameHandlers(io);
  await new Promise<void>((resolve) => http.listen(0, "127.0.0.1", () => resolve()));
  const addr = http.address();
  const port = typeof addr === "object" && addr ? addr.port : 0;
  return { url: `http://127.0.0.1:${port}`, http, io };
}

async function stopTestServer(server: TestServer): Promise<void> {
  server.io.close();
  await new Promise<void>((resolve) => server.http.close(() => resolve()));
  resetGameStateForTests();
}

function connect(url: string): Promise<ClientSocket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.on("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.on("connect_error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

function once<T>(socket: ClientSocket, event: string): Promise<T> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`${event} timeout`)), 10_000);
    socket.once(event, (payload: T) => {
      clearTimeout(timer);
      resolve(payload);
    });
  });
}

function waitRoom(socket: ClientSocket, predicate: (room: RoomView) => boolean, label: string): Promise<RoomView> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      socket.off("room_update", onUpdate);
      reject(new Error(`${label} timeout`));
    }, 15_000);
    const onUpdate = (room: RoomView) => {
      if (!predicate(room)) return;
      clearTimeout(timer);
      socket.off("room_update", onUpdate);
      resolve(room);
    };
    socket.on("room_update", onUpdate);
  });
}

function queryResume(socket: ClientSocket, payload: Record<string, unknown>): Promise<ResumeStatus> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("resume_status timeout")), 10_000);
    socket.emit("resume_status", payload, (status: ResumeStatus) => {
      clearTimeout(timer);
      resolve(status);
    });
  });
}

/** Espera (al mateix procés) que la sala arribi a la fase i l'atura: cap temporitzador no l'avança. */
async function freezeAt(roomId: string, pred: (room: Room) => boolean, label: string): Promise<Room> {
  const deadline = Date.now() + 15_000;
  for (;;) {
    const room = getRoomSnapshotForTests(roomId);
    if (room && pred(room)) {
      clearRoomTimers(getGameHostForTests(), room);
      return room;
    }
    if (Date.now() > deadline) throw new Error(`${label} timeout (fase ${room?.phase})`);
    await new Promise((r) => setImmediate(r));
  }
}

function tableTotal(room: Room): number {
  return room.players.reduce((sum, p) => sum + p.chips, 0) + room.pot + room.jackpot;
}

type Table = {
  roomId: string;
  inviteCode: string;
  sockets: Map<string, ClientSocket>; // playerId → socket
  seatTokens: Map<string, string>;
};

/** Amfitrió + 2 convidats humans + bots; la partida comença. */
async function openTable(server: TestServer, prefix: string): Promise<Table> {
  const sockets = new Map<string, ClientSocket>();
  const seatTokens = new Map<string, string>();
  const hostId = `${prefix}host0001`;
  const host = await connect(server.url);
  const created = once<RoomView>(host, "joined_room");
  host.emit("create_private_table", { playerName: "Amfitrio", playerId: hostId });
  const room = await created;
  sockets.set(hostId, host);
  seatTokens.set(hostId, room.viewerSeatToken!);
  for (const n of [1, 2]) {
    const id = `${prefix}guest000${n}`;
    const s = await connect(server.url);
    const joined = once<RoomView>(s, "joined_room");
    s.emit("join_private_table", { inviteCode: room.inviteCode, playerName: `Convidat${n}`, playerId: id });
    const view = await joined;
    sockets.set(id, s);
    seatTokens.set(id, view.viewerSeatToken!);
  }
  host.emit("fill_private_bots", room.id);
  await waitRoom(host, (r) => r.players.length > 3, "bots");
  host.emit("start_game", room.id);
  return { roomId: room.id, inviteCode: room.inviteCode!, sockets, seatTokens };
}

function closeTable(table: Table) {
  for (const s of table.sockets.values()) s.disconnect();
}

function socketIdOf(room: Room, playerId: string): string | undefined {
  return room.players.find((p) => p.playerId === playerId)?.id;
}

/**
 * Saldo de vestíbul ja tancat. Les mans anteriors poden haver abonat un assoliment
 * (partida real, fora de pràctica) en paral·lel; es espera aquest abonament i es
 * paren els temporitzadors perquè no n'arribi un altre entre la lectura i la sortida.
 * Les fitxes de taula no entren en aquest saldo.
 */
async function settledLobbyChips(room: Room, playerId: string): Promise<number> {
  clearRoomTimers(getGameHostForTests(), room);
  await flushHandStatWritesForTests();
  await flushBalanceWrites();
  const chips = await getBalance(playerId);
  assert.ok(chips >= DEFAULT_CHIPS);
  return chips;
}

describe("S1 · Sortir d'una taula privada allibera el seient a l'instant", () => {
  after(() => resetGameStateForTests());

  it("jugador a mitja mà en el seu torn: seient fora, torn al següent, fitxes consistents", async () => {
    const server = await startTestServer();
    const table = await openTable(server, "s1pplay");
    try {
      // Mà en curs i torn d'un humà que no fa de banca.
      const room = await freezeAt(
        table.roomId,
        (r) => {
          if (r.phase !== "playing") return false;
          const order = r.players.filter((p) => !p.isBanker);
          return r.players.some((p) => !p.isBanker && !p.isBot && table.sockets.has(p.playerId)) && order.length > 0;
        },
        "playing"
      );
      const order = nonBankersInPlayOrder(room);
      const cur = order[room.turnPlayerIndex]!;
      const leaver = !cur.isBot && !cur.isBanker ? cur : order.find((p) => !p.isBot)!;
      const leaverPid = leaver.playerId;
      const leaverSocket = table.sockets.get(leaverPid)!;
      const watcherPid = [...table.sockets.keys()].find((id) => id !== leaverPid)!;
      const watcher = table.sockets.get(watcherPid)!;
      const seatsBefore = room.players.length;
      const totalBefore = tableTotal(room);
      const leaverChips = leaver.chips;
      const stake = leaver.handSlots.reduce((s, h) => s + h.bet, 0);
      const banker = room.players.find((p) => p.isBanker)!;
      const bankerChipsBefore = banker.chips;
      const wasTheirTurn = cur === leaver;
      const nextExpected = wasTheirTurn ? order[room.turnPlayerIndex + 1]?.playerId : cur.playerId;

      const seen = waitRoom(watcher, (r) => r.players.length === seatsBefore - 1, "seat gone");
      const lobby = await settledLobbyChips(room, leaverPid);
      const left = once<{ roomId: string; resumable: boolean; chips: number }>(leaverSocket, "room_left");
      leaverSocket.emit("leave_room", table.roomId);
      // `chips` és el del vestíbul, ja tancat: no inclou l'aposta de la taula.
      assert.deepEqual(await left, { roomId: table.roomId, resumable: false, chips: lobby });
      const after = getRoomSnapshotForTests(table.roomId)!;
      clearRoomTimers(getGameHostForTests(), after);

      assert.equal(after.players.some((p) => p.playerId === leaverPid), false, "seient alliberat");
      assert.equal(tableTotal(after) + leaverChips, totalBefore, "cap fitxa no es crea ni es perd");
      assert.equal(after.players.find((p) => p.isBanker)!.chips, bankerChipsBefore + stake, "l'aposta va a la banca");
      if (after.phase === "playing") {
        assert.equal(nonBankersInPlayOrder(after)[after.turnPlayerIndex]?.playerId, nextExpected);
      } else {
        assert.equal(nextExpected, undefined);
        assert.ok(["banker", "settlement"].includes(after.phase));
      }
      const view = await seen;
      assert.equal(view.players.some((p) => p.id === leaverSocket.id), false);

      const status = await queryResume(watcher, {
        playerId: leaverPid,
        inviteCode: table.inviteCode,
        seatToken: table.seatTokens.get(leaverPid),
      });
      assert.equal(status.private, false);

      // La mà no queda encallada: arriba a la liquidació o a una mà nova.
      const live = getRoomSnapshotForTests(table.roomId)!;
      await publishRoom(getGameHostForTests(), live);
      await freezeAt(table.roomId, (r) => r.phase === "settlement" || r.phase === "waiting" || r.phase === "betting", "hand end");
    } finally {
      closeTable(table);
      await stopTestServer(server);
    }
  });

  it("banca humana a mitja mà: mà anul·lada, apostes retornades, nova banca i mà següent", async () => {
    const server = await startTestServer();
    const table = await openTable(server, "s1pbank");
    try {
      // Preparació: a l'inici de les apostes (cap aposta encara) la banca passa a l'amfitrió humà.
      const hostPid = [...table.sockets.keys()][0]!;
      const betting = await freezeAt(
        table.roomId,
        (r) => r.phase === "betting" && r.players.every((p) => p.bet === 0),
        "betting"
      );
      for (const p of betting.players) p.isBanker = p.playerId === hostPid;
      await publishRoom(getGameHostForTests(), betting);
      const room = await freezeAt(table.roomId, (r) => r.phase === "playing", "human banker playing");
      assert.equal(room.players.find((p) => p.isBanker)?.playerId, hostPid);
      const banker = room.players.find((p) => p.isBanker)!;
      const bankerSocket = table.sockets.get(banker.playerId)!;
      const watcherPid = [...table.sockets.keys()].find((id) => id !== banker.playerId)!;
      const watcher = table.sockets.get(watcherPid)!;
      const totalBefore = tableTotal(room);
      const bankerChips = banker.chips;
      const expected = new Map(
        room.players.filter((p) => !p.isBanker).map((p) => [p.playerId, p.chips + p.handSlots.reduce((s, h) => s + h.bet, 0)])
      );

      const lobby = await settledLobbyChips(room, banker.playerId);
      const left = once<{ roomId: string; resumable: boolean; chips: number }>(bankerSocket, "room_left");
      bankerSocket.emit("leave_room", table.roomId);
      assert.deepEqual(await left, { roomId: table.roomId, resumable: false, chips: lobby });
      const after = getRoomSnapshotForTests(table.roomId)!;

      assert.equal(after.players.some((p) => p.playerId === banker.playerId), false);
      assert.equal(after.phase, "waiting");
      assert.equal(after.pot, 0);
      // Nova banca al següent en ordre de seient que pugui cobrir la taula; si ningú no pot, la sorteja la mà següent.
      assert.ok(after.players.filter((p) => p.isBanker).length <= 1);
      for (const p of after.players) assert.equal(p.chips, expected.get(p.playerId), `${p.name} recupera l'aposta`);
      assert.equal(tableTotal(after) + bankerChips, totalBefore);

      // Comença la mà següent sense la banca que ha sortit.
      await freezeAt(table.roomId, (r) => r.phase === "betting" || r.phase === "playing", "next hand");
      const status = await queryResume(watcher, {
        playerId: banker.playerId,
        inviteCode: table.inviteCode,
        seatToken: table.seatTokens.get(banker.playerId),
      });
      assert.equal(status.private, false);
    } finally {
      closeTable(table);
      await stopTestServer(server);
    }
  });

  it("desconnexió a mitja mà: el seient es conserva i es pot reprendre", async () => {
    const server = await startTestServer();
    const table = await openTable(server, "s1pdisc");
    try {
      const room = await freezeAt(table.roomId, (r) => r.phase === "playing", "playing");
      const pid = [...table.sockets.keys()].find((id) => socketIdOf(room, id))!;
      const seatsBefore = room.players.length;
      table.sockets.get(pid)!.disconnect();
      table.sockets.delete(pid);
      await freezeAt(
        table.roomId,
        (r) => r.players.find((p) => p.playerId === pid)?.disconnectedAt !== undefined,
        "grace"
      );
      const after = getRoomSnapshotForTests(table.roomId)!;
      assert.equal(after.players.length, seatsBefore, "el seient es manté");

      const back = await connect(server.url);
      table.sockets.set(pid, back);
      const status = await queryResume(back, {
        playerId: pid,
        inviteCode: table.inviteCode,
        seatToken: table.seatTokens.get(pid),
      });
      assert.equal(status.private, true);
      const joined = once<RoomView>(back, "joined_room");
      back.emit("join_private_table", {
        inviteCode: table.inviteCode,
        playerName: "Torna",
        playerId: pid,
        seatToken: table.seatTokens.get(pid),
      });
      const view = await joined;
      assert.equal(view.viewerSeatToken, table.seatTokens.get(pid));
      assert.ok(view.players.some((p) => p.id === back.id));
    } finally {
      closeTable(table);
      await stopTestServer(server);
    }
  });
});
