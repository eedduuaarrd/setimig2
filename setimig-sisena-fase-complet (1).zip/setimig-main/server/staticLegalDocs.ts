import type { Express, NextFunction, Request, Response } from "express";
import path from "path";
import { LEGAL_DOC_PAGES } from "../shared/legalDocs.ts";

const PRIVACY_LOCALES = new Set(["ca", "es"]);

/**
 * Old Catalan slug /privadesa → the public privacy document.
 * A locale suffix (/privadesa/ca) or prefix (/ca/privadesa) is kept by sending
 * that language's page (/privacy/ca). English and the bare path go to /privacy.
 * The query string is preserved.
 */
export function privadesaRedirectTarget(pathname: string): string | null {
  const pathOnly = pathname.length > 1 && pathname.endsWith("/") ? pathname.slice(0, -1) : pathname;
  if (pathOnly === "/privadesa") return "/privacy";

  const suffix = /^\/privadesa\/([a-z]{2})$/.exec(pathOnly);
  const prefix = /^\/([a-z]{2})\/privadesa$/.exec(pathOnly);
  const locale = suffix?.[1] ?? prefix?.[1];
  if (!locale) return null;
  if (locale === "en") return "/privacy";
  if (PRIVACY_LOCALES.has(locale)) return `/privacy/${locale}`;
  return "/privacy";
}

export function redirectLegacyPrivadesa(req: Request, res: Response, next: NextFunction): void {
  if (req.method !== "GET" && req.method !== "HEAD") {
    next();
    return;
  }
  const target = privadesaRedirectTarget(req.path);
  if (!target) {
    next();
    return;
  }
  const query = req.url.includes("?") ? req.url.slice(req.url.indexOf("?")) : "";
  res.redirect(301, `${target}${query}`);
}

/**
 * /privacy and /terms are their own HTML documents (public/<file>), not the SPA.
 *
 * Registered before express.static and the SPA fallback. Both the slashless
 * path and the trailing-slash path return 200 with that file. A missing file
 * is a plain 404, never index.html: Google OAuth must not receive the home page.
 *
 * There is no Caddyfile in this repo. Production Caddy reverse-proxies to this
 * process, so this handler is the route that keeps /privacy off the home shell.
 * The service worker is network-first for navigations and only stores / and
 * /index.html as the app shell, so a 200 from here is not rewritten to home.
 */
export function registerStaticLegalDocs(app: Express, rootDir: string): void {
  app.use(redirectLegacyPrivadesa);
  for (const page of LEGAL_DOC_PAGES) {
    const filePath = path.resolve(rootDir, page.file);
    const send = (_req: Request, res: Response) => {
      res.setHeader("Cache-Control", "public, max-age=0");
      res.type("html");
      res.sendFile(filePath, (err) => {
        if (err && !res.headersSent) {
          res.status(404).type("text/plain").send("Not found");
        }
      });
    };
    app.get(page.path, send);
    app.get(`${page.path}/`, send);
  }
}
