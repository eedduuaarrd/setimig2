import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { generateInviteCode, normalizeInviteCode, privateShareUrl } from "./privateRooms.ts";

describe("private invite codes", () => {
  it("generates ≥6 character codes from safe alphabet with crypto (not Math.random)", () => {
    const originalRandom = Math.random;
    try {
      Math.random = () => 0;
      const seen = new Set<string>();
      for (let i = 0; i < 200; i += 1) {
        const code = generateInviteCode();
        assert.match(code, /^[A-Z2-9]{6}$/);
        assert.ok(!/[OIL01]/.test(code), `invite code should not contain ambiguous characters: ${code}`);
        seen.add(code);
      }
      assert.ok(seen.size > 190, "codes must not depend on Math.random");
      assert.equal(generateInviteCode(4).length, 6, "mai menys de 6");
      assert.equal(generateInviteCode(20).length, 8);
    } finally {
      Math.random = originalRandom;
    }
  });

  it("normalizes user input", () => {
    assert.equal(normalizeInviteCode(" ab12 "), "AB12");
    assert.equal(normalizeInviteCode("abc"), null);
    assert.equal(normalizeInviteCode("ABCDE1"), "ABCDE1");
    assert.equal(normalizeInviteCode("ABCDEFGH9"), null);
  });

  it("share url is /t/CODE", () => {
    assert.equal(privateShareUrl("https://setimig.supercbb.com/", "AB12C"), "https://setimig.supercbb.com/t/AB12C");
  });
});
