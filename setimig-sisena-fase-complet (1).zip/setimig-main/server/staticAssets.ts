import express, { type Express, type NextFunction, type Request, type Response } from "express";
import path from "path";
import { spaFallbackHandler } from "./spaFallback.ts";
import { staticHtmlLoginGate } from "./staticHtmlLogin.ts";
import { registerStaticLegalDocs } from "./staticLegalDocs.ts";

/**
 * Capçaleres de memòria cau dels fitxers de `dist/` en producció.
 *
 * - `/assets/*`: Vite hi posa el hash del contingut al nom (`index-EQjPcBJ4.js`), de manera que
 *   un nom concret no canvia mai de contingut: es pot guardar un any i marcar `immutable`.
 * - La resta (`index.html`, `sw.js`, `site.webmanifest`, icones…) no porta hash i ha de
 *   continuar revalidant-se a cada càrrega: es deixa el valor per defecte d'`express.static`
 *   (`public, max-age=0`). Així una versió nova del client i del service worker es veu de seguida.
 *
 * Abans tot sortia amb `public, max-age=0` i Cloudflare (Browser Cache TTL per defecte de 4 h)
 * el reescrivia a `max-age=14400` per als fitxers estàtics. Cloudflare respecta un `max-age`
 * de l'origen més llarg que el seu TTL, de manera que aquest valor arriba al navegador.
 */
export const IMMUTABLE_ASSET_CACHE_CONTROL = "public, max-age=31536000, immutable";

export function isHashedAssetPath(distPath: string, filePath: string): boolean {
  const rel = path.relative(path.join(distPath, "assets"), filePath);
  return rel !== "" && !rel.startsWith("..") && !path.isAbsolute(rel);
}

/**
 * Les regles en anglès eren a `/regles/en/`. El document és `/regles/`
 * (`express.static` serveix `dist/regles/index.html`). Sense aquesta
 * redirecció, `/regles/en` i `/regles/en/` cauen al fallback SPA (200) i
 * `/regles/en/index.html` és un fitxer inexistent.
 */
const LEGACY_ENGLISH_RULES_PATHS = new Set(["/regles/en", "/regles/en/", "/regles/en/index.html"]);
export const ENGLISH_RULES_PATH = "/regles/";

export function legacyEnglishRulesRedirect(req: Request, res: Response, next: NextFunction): void {
  if ((req.method === "GET" || req.method === "HEAD") && LEGACY_ENGLISH_RULES_PATHS.has(req.path)) {
    res.redirect(301, ENGLISH_RULES_PATH);
    return;
  }
  next();
}

/**
 * Serveix `dist/` (fitxers estàtics + SPA) amb la política de memòria cau de dalt.
 *
 * Fallback (`spaFallbackHandler`): les rutes de l'app reben `index.html`; un fitxer amb
 * extensió que no existeix (p. ex. un `/assets/*` vell) retorna 404 i mai queda `immutable`.
 * La redirecció 301 de `/manifest.webmanifest` (`registerManifestRedirect`) s'ha de registrar
 * abans de cridar aquesta funció (server.ts ho fa). La de `/regles/en` es registra aquí,
 * abans d'`express.static` i del fallback: és l'únic muntatge que serveix `/regles/`.
 */
export function mountStaticDist(app: Express, distPath: string): void {
  // /privacy and /terms: 200 with their own HTML, before static and the SPA shell.
  registerStaticLegalDocs(app, distPath);
  app.use(legacyEnglishRulesRedirect);
  // Login obligatori: HTML estàtic no públic sense sessió → /login?next=.
  app.use(staticHtmlLoginGate(distPath));
  app.use(
    express.static(distPath, {
      setHeaders(res: Response, filePath: string) {
        if (isHashedAssetPath(distPath, filePath)) {
          res.setHeader("Cache-Control", IMMUTABLE_ASSET_CACHE_CONTROL);
        }
      },
    })
  );
  app.get("*", spaFallbackHandler(distPath));
}
