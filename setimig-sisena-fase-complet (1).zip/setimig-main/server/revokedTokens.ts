import { createHash } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { writeJsonAtomic } from "./writeCoalescing.ts";

/**
 * Revocació de logout (data/revoked-tokens.json).
 *
 * - `tokens`: sha256 del token → caducitat (ms). El token en clar no es desa.
 * - `sessions`: id de sessió revocat → caducitat. Mata el token presentat i els que
 *   s'han renovat a partir d'ell (`POST /api/player-session`), no els altres dispositius.
 * - `lineage`: sha256 d'un token anterior → id de sessió (per als tokens d'abans del camp `sid`).
 * - `sessionExp`: id de sessió → caducitat màxima de la cadena (per no esborrar la revocació
 *   abans que mori el token més nou).
 *
 * El fitxer antic `{ version: 1, tokens }` es llegeix tal qual. En desar es passa a la
 * versió 2 sense perdre `tokens` (migració additiva). Les entrades caducades es poden en
 * desar. Lectura síncrona: `verifyPlayerToken` és síncrona.
 * Fitxer malmès: error (mai tornar a acceptar un token revocat per un fitxer il·legible).
 */
const HASH_RE = /^[a-f0-9]{64}$/;
const SID_RE = /^[A-Za-z0-9_-]{16,128}$/;

type FileV2 = {
  version: 2;
  tokens: Record<string, number>;
  sessions: Record<string, number>;
  lineage: Record<string, string>;
  sessionExp: Record<string, number>;
};

type Mem = {
  tokens: Map<string, number>;
  sessions: Map<string, number>;
  lineage: Map<string, string>;
  sessionExp: Map<string, number>;
};

let cache: { file: string; mem: Mem } | null = null;
let chain: Promise<unknown> = Promise.resolve();

function dataDir(): string {
  return process.env.BALANCE_DATA_DIR || path.join(process.cwd(), "data");
}

export function revokedTokensPath(): string {
  return path.join(dataDir(), "revoked-tokens.json");
}

export function hashToken(token: string): string {
  return createHash("sha256").update(`setimig-revoked-token:${token}`).digest("hex");
}

export function isSessionId(sid: string): boolean {
  return SID_RE.test(sid);
}

function emptyMem(): Mem {
  return { tokens: new Map(), sessions: new Map(), lineage: new Map(), sessionExp: new Map() };
}

function readExpMap(raw: unknown, keyRe: RegExp): Map<string, number> {
  const out = new Map<string, number>();
  if (!raw || typeof raw !== "object") return out;
  for (const [k, v] of Object.entries(raw as Record<string, unknown>)) {
    if (!keyRe.test(k)) continue;
    const n = typeof v === "number" ? v : Number(v);
    if (Number.isFinite(n)) out.set(k, n);
  }
  return out;
}

function load(): Mem {
  const file = revokedTokensPath();
  if (cache && cache.file === file) return cache.mem;
  const mem = emptyMem();
  let raw: string | null = null;
  try {
    raw = fs.readFileSync(file, "utf8");
  } catch (err) {
    if ((err as NodeJS.ErrnoException)?.code !== "ENOENT") throw err;
  }
  if (raw !== null) {
    const parsed = JSON.parse(raw) as Partial<FileV2> & { tokens?: unknown; sessions?: unknown; lineage?: unknown; sessionExp?: unknown };
    mem.tokens = readExpMap(parsed.tokens, HASH_RE);
    mem.sessions = readExpMap(parsed.sessions, SID_RE);
    mem.sessionExp = readExpMap(parsed.sessionExp, SID_RE);
    if (parsed.lineage && typeof parsed.lineage === "object") {
      for (const [h, sid] of Object.entries(parsed.lineage as Record<string, unknown>)) {
        if (HASH_RE.test(h) && typeof sid === "string" && isSessionId(sid)) mem.lineage.set(h, sid);
      }
    }
  }
  cache = { file, mem };
  return mem;
}

function prune(mem: Mem, now: number): void {
  for (const [k, e] of mem.tokens) if (e < now) mem.tokens.delete(k);
  for (const [k, e] of mem.sessions) if (e < now) mem.sessions.delete(k);
  for (const [sid, e] of [...mem.sessionExp]) {
    if (e >= now) continue;
    mem.sessionExp.delete(sid);
    for (const [h, s] of [...mem.lineage]) if (s === sid) mem.lineage.delete(h);
  }
}

async function persist(mem: Mem): Promise<void> {
  const out: FileV2 = {
    version: 2,
    tokens: Object.fromEntries(mem.tokens),
    sessions: Object.fromEntries(mem.sessions),
    lineage: Object.fromEntries(mem.lineage),
    sessionExp: Object.fromEntries(mem.sessionExp),
  };
  await fs.promises.mkdir(dataDir(), { recursive: true });
  await writeJsonAtomic(revokedTokensPath(), out);
}

function mutate(run: (mem: Mem, now: number) => void, now = Date.now()): Promise<void> {
  const next = chain.then(async () => {
    const mem = load();
    run(mem, now);
    prune(mem, now);
    await persist(mem);
  }, async () => {
    const mem = load();
    run(mem, now);
    prune(mem, now);
    await persist(mem);
  });
  chain = next.catch(() => undefined);
  return next;
}

export function isTokenRevoked(token: string): boolean {
  return load().tokens.has(hashToken(token));
}

export function isSessionRevoked(sid: string): boolean {
  return isSessionId(sid) && load().sessions.has(sid);
}

/** Sessió a què es va lligar aquest token en renovar-lo (si no porta `sid` al payload). */
export function lineageSession(token: string): string | null {
  return load().lineage.get(hashToken(token)) ?? null;
}

export function lineageSessionByHash(hash: string): string | null {
  return load().lineage.get(hash) ?? null;
}

/**
 * Lliga un token ja emès a una sessió i allarga la caducitat de la cadena fins a `exp`.
 * Cal desar-ho abans de lliurar el token renovat: si no, el logout no podria matar el token vell.
 */
export function linkTokenToSession(token: string, sid: string, exp: number): Promise<void> {
  return mutate((mem) => {
    if (!isSessionId(sid)) return;
    mem.lineage.set(hashToken(token), sid);
    mem.sessionExp.set(sid, Math.max(mem.sessionExp.get(sid) ?? 0, exp));
  });
}

/**
 * Revoca el token presentat i, si en té, la sessió sencera (renovacions incloses).
 * No toca les altres sessions del mateix jugador. Idempotent. Desa abans de tornar.
 */
export function revokePresentedToken(token: string, exp: number, sid?: string, now = Date.now()): Promise<void> {
  return mutate((mem) => {
    const h = hashToken(token);
    mem.tokens.set(h, exp);
    const ids = new Set<string>();
    if (sid && isSessionId(sid)) ids.add(sid);
    const linked = mem.lineage.get(h);
    if (linked) ids.add(linked);
    for (const id of ids) {
      const until = Math.max(exp, mem.sessionExp.get(id) ?? 0);
      mem.sessions.set(id, until);
      mem.sessionExp.set(id, until);
    }
  }, now);
}

/** Per als tests: oblida la memòria cau (simula un reinici; es torna a llegir el fitxer). */
export function resetRevokedTokensCacheForTests(): void {
  cache = null;
  chain = Promise.resolve();
}
