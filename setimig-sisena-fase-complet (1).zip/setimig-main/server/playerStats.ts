import fs from "fs/promises";
import path from "path";
import { isAccountDeleted } from "./deletedAccounts.ts";
import type { HandOutcome } from "../src/gameTypes.ts";
import type { GameMode } from "./analytics.ts";
import { averagePointsFromTenths, pointsToTenths } from "../shared/profileHandCount.ts";

const STORE_VERSION = 1;
const MAX_HAND_RECORDS = 600;
const MAX_MATCH_RECORDS = 120;

function dataDir(): string {
  return process.env.BALANCE_DATA_DIR || path.join(process.cwd(), "data");
}

function statsDir(): string {
  return path.join(dataDir(), "player-stats");
}

function legacyAggregatePath(): string {
  return path.join(dataDir(), "player-stats-aggregate.json");
}

function playerStorePath(playerId: string): string {
  return path.join(statsDir(), `${playerId}.json`);
}

export type HandHistoryRecord = {
  id: string;
  at: number;
  roomId: string;
  roomLabel: string;
  finalPoints: number;
  passed: boolean;
  naturalSevenHalf: boolean;
  bet: number;
  result: HandOutcome;
  chipDelta: number;
  wasBanker: boolean;
  practice: boolean;
  /** Mode de joc (pràctica i torneig ràpid comparteixen `practice: true`). */
  mode?: GameMode;
};

export type MatchSummaryRecord = {
  id: string;
  at: number;
  roomId: string;
  roomLabel: string;
  handsPlayed: number;
  viewerOutcome: "win" | "lose" | "eliminated" | null;
  practice: boolean;
  mode?: GameMode;
};

type PlayerStatsFile = {
  version: number;
  aggregate: {
    handsPlayed: number;
    handsWon: number;
    pointsSum: number;
    /** Suma de punts × 10 (6,5 → 65). Opcional: els fitxers antics només tenen `pointsSum` sencer. */
    pointsSumTenths?: number;
    passCount: number;
    /** Mans totals de la vida del jugador (tots els modes); per a `handIndex` d'analítica. */
    allHands?: number;
  };
  hands: HandHistoryRecord[];
  matches: MatchSummaryRecord[];
};

let migrationDone = false;
const cache = new Map<string, PlayerStatsFile>();
let writeChain: Promise<void> = Promise.resolve();

function emptyFile(): PlayerStatsFile {
  return {
    version: STORE_VERSION,
    aggregate: { handsPlayed: 0, handsWon: 0, pointsSum: 0, passCount: 0 },
    hands: [],
    matches: [],
  };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function trimRotated<T>(items: T[], max: number): T[] {
  if (items.length <= max) return items;
  return items.slice(items.length - max);
}

async function backupFileIfExists(filePath: string): Promise<void> {
  try {
    await fs.access(filePath);
  } catch {
    return;
  }
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  const backup = `${filePath}.bak-${stamp}`;
  await fs.copyFile(filePath, backup);
}

async function runMigrationOnce(): Promise<void> {
  if (migrationDone) return;
  migrationDone = true;
  await fs.mkdir(statsDir(), { recursive: true });
  const legacy = legacyAggregatePath();
  try {
    await fs.access(legacy);
  } catch {
    return;
  }
  await backupFileIfExists(legacy);
  let raw: string;
  try {
    raw = await fs.readFile(legacy, "utf8");
  } catch {
    return;
  }
  try {
    const parsed: unknown = JSON.parse(raw);
    if (!isRecord(parsed) || !isRecord(parsed.players)) return;
    for (const [playerId, entry] of Object.entries(parsed.players)) {
      if (!isRecord(entry)) continue;
      const target = path.join(statsDir(), `${playerId}.json`);
      try {
        await fs.access(target);
        continue;
      } catch {
        /* new file */
      }
      const file = emptyFile();
      const handsPlayed = Number(entry.handsPlayed);
      const handsWon = Number(entry.handsWon);
      if (Number.isFinite(handsPlayed)) file.aggregate.handsPlayed = Math.max(0, Math.floor(handsPlayed));
      if (Number.isFinite(handsWon)) file.aggregate.handsWon = Math.max(0, Math.floor(handsWon));
      await persistPlayerFile(playerId, file);
    }
  } catch {
    /* leave legacy file intact */
  }
}

async function loadPlayerFile(playerId: string): Promise<PlayerStatsFile> {
  await runMigrationOnce();
  const cached = cache.get(playerId);
  if (cached) return cached;

  const storePath = playerStorePath(playerId);
  let raw: string;
  try {
    raw = await fs.readFile(storePath, "utf8");
  } catch (error) {
    if (error instanceof Error && "code" in error && error.code === "ENOENT") {
      const fresh = emptyFile();
      cache.set(playerId, fresh);
      return fresh;
    }
    throw error;
  }

  const parsed: unknown = JSON.parse(raw);
  if (!isRecord(parsed) || parsed.version !== STORE_VERSION || !isRecord(parsed.aggregate)) {
    throw new Error(`Invalid player stats format for ${playerId}`);
  }
  const file: PlayerStatsFile = {
    version: STORE_VERSION,
    aggregate: {
      handsPlayed: Math.max(0, Math.floor(Number(parsed.aggregate.handsPlayed) || 0)),
      handsWon: Math.max(0, Math.floor(Number(parsed.aggregate.handsWon) || 0)),
      pointsSum: Math.max(0, Math.floor(Number(parsed.aggregate.pointsSum) || 0)),
      ...(Number.isFinite(Number(parsed.aggregate.pointsSumTenths)) && parsed.aggregate.pointsSumTenths !== undefined
        ? { pointsSumTenths: Math.max(0, Math.round(Number(parsed.aggregate.pointsSumTenths))) }
        : {}),
      passCount: Math.max(0, Math.floor(Number(parsed.aggregate.passCount) || 0)),
      ...(Number.isFinite(Number(parsed.aggregate.allHands)) && parsed.aggregate.allHands !== undefined
        ? { allHands: Math.max(0, Math.floor(Number(parsed.aggregate.allHands))) }
        : {}),
    },
    hands: Array.isArray(parsed.hands) ? (parsed.hands as HandHistoryRecord[]) : [],
    matches: Array.isArray(parsed.matches) ? (parsed.matches as MatchSummaryRecord[]) : [],
  };
  cache.set(playerId, file);
  return file;
}

async function persistPlayerFile(playerId: string, file: PlayerStatsFile): Promise<void> {
  if (isAccountDeleted(playerId)) return;
  cache.set(playerId, file);
  await fs.mkdir(statsDir(), { recursive: true });
  const storePath = playerStorePath(playerId);
  const tmp = `${storePath}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(file, null, 2), "utf8");
  await fs.rename(tmp, storePath);
}

function enqueueWrite(task: () => Promise<void>): Promise<void> {
  writeChain = writeChain.then(task, task);
  return writeChain;
}

/**
 * Esborrat de compte: historial de mans i partides (fitxer propi) i entrada a l'agregat antic.
 * L'historial només és del jugador (no hi ha ids d'altres jugadors), així que s'esborra sencer.
 */
export async function deletePlayerStats(playerId: string): Promise<{ file: boolean; legacy: boolean }> {
  const out = { file: false, legacy: false };
  await enqueueWrite(async () => {
    cache.delete(playerId);
    try {
      await fs.rm(playerStorePath(playerId));
      out.file = true;
    } catch (err) {
      if ((err as NodeJS.ErrnoException)?.code !== "ENOENT") throw err;
    }
    // Si quedés a l'agregat antic, la migració el tornaria a crear en reiniciar.
    const legacy = legacyAggregatePath();
    let raw: string | null = null;
    try {
      raw = await fs.readFile(legacy, "utf8");
    } catch {
      raw = null;
    }
    if (raw !== null) {
      const parsed: unknown = JSON.parse(raw);
      if (isRecord(parsed) && isRecord(parsed.players) && playerId in parsed.players) {
        delete parsed.players[playerId];
        const tmp = `${legacy}.tmp`;
        await fs.writeFile(tmp, JSON.stringify(parsed, null, 2), "utf8");
        await fs.rename(tmp, legacy);
        out.legacy = true;
      }
    }
  });
  return out;
}

export type RecordHandInput = {
  playerId: string;
  roomId: string;
  roomLabel: string;
  finalPoints: number;
  passed: boolean;
  naturalSevenHalf: boolean;
  bet: number;
  result: HandOutcome;
  chipDelta: number;
  wasBanker: boolean;
  practice: boolean;
  mode?: GameMode;
  at?: number;
};

/** Desa la mà i retorna el nombre total de mans del jugador (tots els modes), 1-based. */
export async function recordResolvedHand(input: RecordHandInput): Promise<number> {
  const at = input.at ?? Date.now();
  const entry: HandHistoryRecord = {
    id: `${at}-${Math.random().toString(36).slice(2, 9)}`,
    at,
    roomId: input.roomId,
    roomLabel: input.roomLabel,
    finalPoints: input.finalPoints,
    passed: input.passed,
    naturalSevenHalf: input.naturalSevenHalf,
    bet: input.bet,
    result: input.result,
    chipDelta: input.chipDelta,
    wasBanker: input.wasBanker,
    practice: input.practice,
    ...(input.mode ? { mode: input.mode } : {}),
  };

  let handIndex = 0;
  await enqueueWrite(async () => {
    const file = await loadPlayerFile(input.playerId);
    // Fitxers antics: s'estima a partir de l'historial (limitat) i del recompte real.
    const previous = file.aggregate.allHands ?? Math.max(file.hands.length, file.aggregate.handsPlayed);
    file.aggregate.allHands = previous + 1;
    handIndex = file.aggregate.allHands;
    file.hands = trimRotated([...file.hands, entry], MAX_HAND_RECORDS);
    if (!input.practice) {
      file.aggregate.handsPlayed += 1;
      const addTenths = pointsToTenths(input.finalPoints);
      if (file.aggregate.pointsSumTenths == null) file.aggregate.pointsSumTenths = file.aggregate.pointsSum * 10;
      file.aggregate.pointsSumTenths += addTenths;
      file.aggregate.pointsSum += Math.max(0, Math.floor(input.finalPoints));
      if (input.passed) file.aggregate.passCount += 1;
      if (input.result === "win" || input.result === "jackpot") file.aggregate.handsWon += 1;
    }
    await persistPlayerFile(input.playerId, file);
  });
  return handIndex;
}

export type RecordMatchInput = {
  playerId: string;
  roomId: string;
  roomLabel: string;
  handsPlayed: number;
  viewerOutcome: "win" | "lose" | "eliminated" | null;
  practice: boolean;
  mode?: GameMode;
  at?: number;
};

export async function recordMatchSummary(input: RecordMatchInput): Promise<void> {
  const at = input.at ?? Date.now();
  const entry: MatchSummaryRecord = {
    id: `${at}-m-${Math.random().toString(36).slice(2, 8)}`,
    at,
    roomId: input.roomId,
    roomLabel: input.roomLabel,
    handsPlayed: Math.max(0, Math.floor(input.handsPlayed)),
    viewerOutcome: input.viewerOutcome,
    practice: input.practice,
    ...(input.mode ? { mode: input.mode } : {}),
  };

  await enqueueWrite(async () => {
    const file = await loadPlayerFile(input.playerId);
    file.matches = trimRotated([...file.matches, entry], MAX_MATCH_RECORDS);
    await persistPlayerFile(input.playerId, file);
  });
}

export type PublicPlayerStats = {
  handsPlayed: number;
  winRatePercent: number;
  averagePoints: number;
  passCount: number;
};

export async function getPlayerStats(playerId: string): Promise<PublicPlayerStats> {
  const file = await loadPlayerFile(playerId);
  const handsPlayed = file.aggregate.handsPlayed;
  const winRatePercent =
    handsPlayed > 0 ? Math.round((file.aggregate.handsWon / handsPlayed) * 100) : 0;
  const tenths = file.aggregate.pointsSumTenths ?? file.aggregate.pointsSum * 10;
  const averagePoints = averagePointsFromTenths(tenths, handsPlayed);
  return {
    handsPlayed,
    winRatePercent,
    averagePoints,
    passCount: file.aggregate.passCount,
  };
}

export type HistoryPage = {
  hands: HandHistoryRecord[];
  matches: MatchSummaryRecord[];
  nextBefore: number | null;
};

export async function getPlayerHistory(
  playerId: string,
  limitRaw: unknown,
  beforeRaw: unknown
): Promise<HistoryPage> {
  const limit = Math.min(50, Math.max(1, Math.floor(Number(limitRaw) || 20)));
  const absentBefore =
    beforeRaw === undefined || beforeRaw === null || beforeRaw === "";
  const before = absentBefore ? Number.POSITIVE_INFINITY : Number(beforeRaw);
  if (!absentBefore && !Number.isFinite(before)) {
    throw new Error("Invalid before cursor");
  }

  const file = await loadPlayerFile(playerId);
  const merged = [
    ...file.hands.map((h) => ({ kind: "hand" as const, at: h.at, hand: h })),
    ...file.matches.map((m) => ({ kind: "match" as const, at: m.at, match: m })),
  ]
    .filter((row) => row.at < before)
    .sort((a, b) => b.at - a.at);

  const slice = merged.slice(0, limit);
  const hands: HandHistoryRecord[] = [];
  const matches: MatchSummaryRecord[] = [];
  for (const row of slice) {
    if (row.kind === "hand") hands.push(row.hand);
    else matches.push(row.match);
  }
  const oldest = slice.length > 0 ? slice[slice.length - 1]!.at : null;
  const hasMore = oldest != null && merged.length > limit;
  return {
    hands,
    matches,
    nextBefore: hasMore ? oldest : null,
  };
}

/** Test helper: wait for queued stats writes before deleting a temp data dir. */
export async function flushPlayerStatsWritesForTests(): Promise<void> {
  await writeChain.catch(() => undefined);
}

/** Test helper */
export function resetPlayerStatsCacheForTests(): void {
  cache.clear();
  migrationDone = false;
  writeChain = Promise.resolve();
}

export async function readPlayerStatsFileForTests(playerId: string): Promise<PlayerStatsFile> {
  return loadPlayerFile(playerId);
}
