import { describe, it, before, after, beforeEach } from "node:test";
import assert from "node:assert/strict";
import fs from "fs/promises";
import path from "path";
import { createServer, type Server as HttpServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket as ClientSocket } from "socket.io-client";
import {
  flushBalanceWrites,
  getBalance,
  listOpenSoloBuyIns,
  resetBalanceStoreCacheForTests,
  runBalanceTransaction,
  setBalance,
} from "./balances.ts";
import { onHandRecordedForEngagement } from "./achievementsEngine.ts";
import { flushEngagementWritesForTests, resetEngagementCacheForTests } from "./achievementsStore.ts";
import {
  getGameHostForTests,
  getRoomSnapshotForTests,
  resetGameStateForTests,
  seatPublicPlayerForTests,
  setupGameHandlers,
} from "./game.ts";
import { roomUsesPublicBuyIn, settlePublicBuyIn } from "./publicBuyIn.ts";
import type { Room } from "../shared/gameEngine.ts";
import type { RoomView } from "../src/gameTypes.ts";
import { PHASE_B_START_CHIPS } from "../shared/matchPhaseB.ts";

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";

/**
 * Taules públiques multijugador: el saldo real mai es fixa a les fitxes de taula (ni després de
 * cada mà ni en sortir). Compra d'entrada en seure + abonament verificat en sortir, com a
 * increment atòmic sobre el saldo actual, idempotent i sense perdre pagaments fets mentrestant.
 * Les taules privades no canvien (les seves fitxes no són saldo real).
 */

const DATA_ROOT = path.join(process.cwd(), "data", `publiques-increments-test-${Date.now()}`);
const START = 24_500;
const BUY_IN = PHASE_B_START_CHIPS;
const FIRST_WIN_REWARD = 500;

type TestServer = { url: string; http: HttpServer; io: SocketIOServer };

async function startTestServer(): Promise<TestServer> {
  const http = createServer();
  const io = new SocketIOServer(http, { cors: { origin: "*" } });
  await setupGameHandlers(io);
  await new Promise<void>((resolve) => http.listen(0, "127.0.0.1", () => resolve()));
  const addr = http.address();
  const port = typeof addr === "object" && addr ? addr.port : 0;
  return { url: `http://127.0.0.1:${port}`, http, io };
}

async function stopTestServer(server: TestServer, opts: { keepRooms?: boolean } = {}): Promise<void> {
  if (!opts.keepRooms) resetGameStateForTests();
  server.io.close();
  await new Promise<void>((resolve) => server.http.close(() => resolve()));
}

function connect(url: string): Promise<ClientSocket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.on("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.on("connect_error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

function once<T>(socket: ClientSocket, event: string, ms = 5_000): Promise<T> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`${event} timeout`)), ms);
    socket.once(event, (data: T) => {
      clearTimeout(timer);
      resolve(data);
    });
  });
}

async function leave(socket: ClientSocket, roomId: string): Promise<void> {
  const left = once(socket, "room_left");
  socket.emit("leave_room", roomId);
  await left;
}

async function waitFor(cond: () => boolean | Promise<boolean>, label: string, ms = 5_000): Promise<void> {
  const deadline = Date.now() + ms;
  while (!(await cond())) {
    if (Date.now() > deadline) throw new Error(`${label} timeout`);
    await new Promise((r) => setTimeout(r, 10));
  }
}

/** Dos humans a una taula pública (A i B), amb compra d'entrada cadascun. */
async function publicTable(server: TestServer, roomId: string, ids: [string, string]) {
  const a = await connect(server.url);
  const b = await connect(server.url);
  await seatPublicPlayerForTests(roomId, a.id!, ids[0], "Ana");
  const room = await seatPublicPlayerForTests(roomId, b.id!, ids[1], "Biel");
  return { a, b, room };
}

/**
 * Mà liquidada amb el ganxo real del servidor (`onHandSettled`: llibre de compres, estadístiques i
 * assoliments). `delta` és el resultat de `who`; l'altre jugador hi posa la contrapartida.
 */
async function settleHand(room: Room, who: string, delta: number): Promise<void> {
  const human = room.players.find((p) => p.playerId === who)!;
  const other = room.players.find((p) => p !== human);
  human.chips += delta;
  if (other) other.chips -= delta;
  room.phase = "settlement";
  room.lastRound = {
    title: "Liquidació",
    highlights: [],
    results: [
      { name: human.name, outcome: delta > 0 ? "win" : delta < 0 ? "lose" : "push", chipDelta: delta, detail: "" },
      { name: other?.name ?? "Banca", outcome: delta > 0 ? "lose" : delta < 0 ? "win" : "push", chipDelta: -delta, detail: "" },
    ],
    at: Date.now(),
  } as Room["lastRound"];
  await getGameHostForTests().onHandSettled?.(room);
  room.phase = "waiting";
}

/** «Primera victòria» ja cobrada abans de la prova (per mesurar només les fitxes de taula). */
async function preUnlockFirstWin(playerId: string): Promise<void> {
  await onHandRecordedForEngagement({
    playerId,
    result: "win",
    chipDelta: 1,
    passed: false,
    naturalSevenHalf: false,
    practice: false,
  });
}

async function openBuyInsOf(playerId: string) {
  return Object.values(await listOpenSoloBuyIns()).filter((e) => e.playerId === playerId);
}

function setup() {
  before(() => {
    process.env.BALANCE_DATA_DIR = DATA_ROOT;
    process.env.SETIMIG_TEST_FAST = "1";
    resetBalanceStoreCacheForTests();
    resetEngagementCacheForTests();
  });
  beforeEach(() => {
    resetGameStateForTests();
  });
  after(async () => {
    resetGameStateForTests();
    await flushEngagementWritesForTests().catch(() => undefined);
    await flushBalanceWrites().catch(() => undefined);
    resetBalanceStoreCacheForTests();
    resetEngagementCacheForTests();
    await fs.rm(DATA_ROOT, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 }).catch(() => undefined);
    delete process.env.BALANCE_DATA_DIR;
    delete process.env.SETIMIG_TEST_FAST;
  });
}

describe("taules públiques: saldo real per increments (compra + abonament verificat)", () => {
  setup();

  it("el servidor ja no escriu mai les fitxes de taula com a saldo després de cada mà", () => {
    assert.equal(getGameHostForTests().persistHumanBalance, undefined);
    assert.equal(roomUsesPublicBuyIn({ soloAi: false, isPrivate: false }), true);
    assert.equal(roomUsesPublicBuyIn({ soloAi: false, isPrivate: true }), false);
    assert.equal(roomUsesPublicBuyIn({ soloAi: true, isPrivate: false }), false);
    assert.equal(roomUsesPublicBuyIn({ soloAi: false, isPrivate: false, practiceMode: true }), false);
  });

  it("(1) mà pública guanyada +X → saldo +X exactament una vegada (sortir i després desconnectar)", async () => {
    const [ana, biel] = ["pubwinana00001", "pubwinbiel0001"];
    await preUnlockFirstWin(ana);
    await preUnlockFirstWin(biel);
    await setBalance(ana, START);
    await setBalance(biel, START);
    const server = await startTestServer();
    const { a, b, room } = await publicTable(server, "pub-win", [ana, biel]);
    try {
      assert.equal(await getBalance(ana), START - BUY_IN, "en seure es descompta la compra");
      assert.equal(room.players.find((p) => p.playerId === ana)!.chips, BUY_IN);
      await settleHand(room, ana, 700);
      assert.equal(await getBalance(ana), START - BUY_IN, "després de la mà el saldo no es toca");
      assert.equal(await getBalance(biel), START - BUY_IN);
      await leave(a, room.id);
      assert.equal(await getBalance(ana), START + 700);
      a.disconnect();
      await new Promise((r) => setTimeout(r, 150));
      assert.equal(await getBalance(ana), START + 700, "desconnectar després de sortir no torna a abonar");
      await leave(b, room.id);
      assert.equal(await getBalance(biel), START - 700);
      assert.equal((await openBuyInsOf(ana)).length + (await openBuyInsOf(biel)).length, 0);
    } finally {
      a.disconnect();
      b.disconnect();
      await stopTestServer(server);
    }
  });

  it("(2) «Primera victòria» +500 durant la taula sobreviu a cada mà i a la sortida", async () => {
    const [ana, biel] = ["pubachana00001", "pubachbiel0001"];
    await preUnlockFirstWin(biel);
    await setBalance(ana, START);
    await setBalance(biel, START);
    const server = await startTestServer();
    const { a, b, room } = await publicTable(server, "pub-ach", [ana, biel]);
    try {
      // La primera mà guanyada passa pel ganxo real: estadístiques → assoliment → +500 al saldo.
      await settleHand(room, ana, 300);
      await waitFor(async () => (await getBalance(ana)) === START - BUY_IN + FIRST_WIN_REWARD, "assoliment pagat");
      for (const delta of [-100, 250, -50]) {
        await settleHand(room, ana, delta);
        assert.equal(await getBalance(ana), START - BUY_IN + FIRST_WIN_REWARD, "cap mà trepitja el pagament");
      }
      await leave(a, room.id);
      assert.equal(await getBalance(ana), START + 400 + FIRST_WIN_REWARD);
      // Biel pot haver cobrat altres assoliments durant la taula (p. ex. 5 mans sense passar-se):
      // també es conserven. En sortir només s'hi suma el resultat verificat de la taula.
      const bielBeforeLeave = await getBalance(biel);
      await leave(b, room.id);
      assert.equal(await getBalance(biel), bielBeforeLeave + BUY_IN - 400);
    } finally {
      a.disconnect();
      b.disconnect();
      await stopTestServer(server);
    }
  });

  it("(3) pagament des d'una altra pestanya durant la taula es conserva (sortida per desconnexió)", async () => {
    const [ana, biel] = ["pubtabana00001", "pubtabbiel0001"];
    await preUnlockFirstWin(ana);
    await preUnlockFirstWin(biel);
    await setBalance(ana, START);
    await setBalance(biel, START);
    const server = await startTestServer();
    const { a, b, room } = await publicTable(server, "pub-tab", [ana, biel]);
    try {
      await settleHand(room, ana, -600);
      // Una altra pestanya: fitxes gratis / missió / compra directament al saldo.
      await runBalanceTransaction((store) => {
        store.accounts[ana] = { chips: store.accounts[ana]!.chips + 1_000, lastClaimAt: null };
      });
      await settleHand(room, ana, 200);
      assert.equal(await getBalance(ana), START - BUY_IN + 1_000);
      a.disconnect();
      await waitFor(async () => (await openBuyInsOf(ana)).length === 0, "tancament per desconnexió");
      assert.equal(await getBalance(ana), START - 400 + 1_000);
      await leave(b, room.id);
      assert.equal(await getBalance(biel), START + 400);
    } finally {
      a.disconnect();
      b.disconnect();
      await stopTestServer(server);
    }
  });

  it("(4) sortir/desconnectar dues vegades (i tancaments simultanis) no compten dues vegades", async () => {
    const [ana, biel] = ["pubdblana00001", "pubdblbiel0001"];
    await preUnlockFirstWin(ana);
    await preUnlockFirstWin(biel);
    await setBalance(ana, START);
    await setBalance(biel, START);
    const server = await startTestServer();
    const { a, b, room } = await publicTable(server, "pub-dbl", [ana, biel]);
    try {
      await settleHand(room, ana, 500);
      const seatA = room.players.find((p) => p.playerId === ana)!;
      // Dos tancaments alhora (p. ex. Sortir + desconnexió que es creuen).
      await Promise.all([settlePublicBuyIn(room, seatA, "sortida"), settlePublicBuyIn(room, seatA, "desconnexió")]);
      assert.equal(await getBalance(ana), START + 500);
      // I després els camins reals: Sortir, tornar a Sortir i desconnectar.
      await leave(a, room.id);
      a.emit("leave_room", room.id);
      a.disconnect();
      await new Promise((r) => setTimeout(r, 150));
      assert.equal(await getBalance(ana), START + 500);

      // Desconnexió a mitja mà: el seient passa a la IA, s'abona una vegada (l'aposta en joc es
      // perd, com a les solo) i les mans que juga la IA després ja no toquen el saldo.
      const seatB = room.players.find((p) => p.playerId === biel)!;
      room.phase = "playing";
      seatB.chips -= 300;
      seatB.bet = 300;
      b.disconnect();
      await waitFor(async () => (await openBuyInsOf(biel)).length === 0, "tancament a mitja mà");
      const afterDisc = await getBalance(biel);
      assert.equal(afterDisc, START - 500 - 300);
      const botSeat = room.players.find((p) => p.isBot)!;
      assert.ok(botSeat, "el seient continua amb la IA");
      botSeat.bet = 0;
      botSeat.chips += 300;
      room.phase = "waiting";
      await settleHand(room, botSeat.playerId, 900);
      assert.equal(await getBalance(biel), afterDisc);
    } finally {
      a.disconnect();
      b.disconnect();
      await stopTestServer(server);
    }
  });

  it("(5) reinici amb un jugador assegut: es retorna la compra una vegada; cap fitxa es crea ni es perd del saldo", async () => {
    const [ana, biel] = ["pubrstana00001", "pubrstbiel0001"];
    await preUnlockFirstWin(ana);
    await preUnlockFirstWin(biel);
    await setBalance(ana, START);
    await setBalance(biel, START);
    const server = await startTestServer();
    const { a, b, room } = await publicTable(server, "pub-rst", [ana, biel]);
    await settleHand(room, ana, 800);
    await runBalanceTransaction((store) => {
      store.accounts[ana] = { chips: store.accounts[ana]!.chips + 250, lastClaimAt: null };
    });

    // Un arrencada amb la sala encara viva (p. ex. un segon servidor de proves) no la retorna.
    const live = await startTestServer();
    assert.equal((await openBuyInsOf(ana)).length, 1, "la compra d'una sala viva no es retorna");
    await stopTestServer(live, { keepRooms: true });

    // Caiguda: la sala (només a memòria) desapareix i el saldo es rellegeix del disc.
    a.disconnect();
    b.disconnect();
    await flushBalanceWrites();
    await stopTestServer(server);
    resetBalanceStoreCacheForTests();
    const warn = console.warn;
    console.warn = () => undefined;
    try {
      const rebooted = await startTestServer();
      await stopTestServer(rebooted);
      const again = await startTestServer();
      await stopTestServer(again);
    } finally {
      console.warn = warn;
    }
    assert.equal(await getBalance(ana), START + 250, "compra retornada + pagament conservat");
    assert.equal(await getBalance(biel), START);
    assert.equal((await openBuyInsOf(ana)).length + (await openBuyInsOf(biel)).length, 0);
  });
});

describe("taules privades: comportament sense canvis (les fitxes no són saldo real)", () => {
  setup();

  it("(6) seure, jugar una mà, sortir i desconnectar a una privada no toquen el saldo real", async () => {
    const hostId = "pubprivhost001";
    const guestId = "pubprivguest01";
    // Els assoliments ja cobrats: aquí només es mira que les fitxes de taula no toquin el saldo.
    await preUnlockFirstWin(hostId);
    await preUnlockFirstWin(guestId);
    await setBalance(hostId, START);
    await setBalance(guestId, START);
    const server = await startTestServer();
    const host = await connect(server.url);
    const guest = await connect(server.url);
    try {
      const created = once<RoomView>(host, "joined_room");
      host.emit("create_private_table", { playerName: "Amfitrio", playerId: hostId });
      const view = await created;
      const joined = once<RoomView>(guest, "joined_room");
      guest.emit("join_private_table", { inviteCode: view.inviteCode, playerName: "Convidat", playerId: guestId });
      await joined;
      const room = getRoomSnapshotForTests(view.id)!;
      assert.equal(room.isPrivate, true);
      assert.equal(roomUsesPublicBuyIn(room), false);
      assert.equal(room.realBuyIns, undefined);
      assert.equal(await getBalance(hostId), START, "seure a una privada no descompta res");
      await settleHand(room, hostId, 400);
      assert.equal(await getBalance(hostId), START);
      assert.equal(await getBalance(guestId), START);
      await leave(guest, room.id);
      guest.disconnect();
      host.disconnect();
      await new Promise((r) => setTimeout(r, 150));
      assert.equal(await getBalance(hostId), START);
      assert.equal(await getBalance(guestId), START);
      assert.equal((await openBuyInsOf(hostId)).length + (await openBuyInsOf(guestId)).length, 0);
    } finally {
      host.disconnect();
      guest.disconnect();
      await stopTestServer(server);
    }
  });
});
