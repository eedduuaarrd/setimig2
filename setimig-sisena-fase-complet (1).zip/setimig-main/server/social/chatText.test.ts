import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { filterProfanity, maxChatLength, prepareChatMessage, sanitizeChatPlainText } from "./chatText.ts";

describe("chatText", () => {
  it("sanitizes plain text and strips markup", () => {
    assert.equal(sanitizeChatPlainText("  hola   <b>món</b>  "), "hola món");
    assert.equal(sanitizeChatPlainText("a\u0007b"), "ab");
  });

  it("filters profanity in three languages", () => {
    assert.match(filterProfanity("això és una merda"), /\*\*\*/);
    assert.match(filterProfanity("what the fuck"), /\*\*\*/);
    assert.match(filterProfanity("això és collons"), /\*\*\*/);
  });

  it("enforces max length", () => {
    assert.equal(maxChatLength(), 200);
    const long = "a".repeat(201);
    const result = prepareChatMessage(long);
    assert.equal(result.ok, false);
    if (!result.ok) assert.equal(result.code, "CHAT_TOO_LONG");
  });
});
