const MAX_CHAT_LENGTH = 200;

const PROFANITY = [
  "puta",
  "puto",
  "cabron",
  "cabrón",
  "gilipollas",
  "mierda",
  "joder",
  "coño",
  "cono",
  "hostia",
  "fuck",
  "fucking",
  "shit",
  "bitch",
  "asshole",
  "damn",
  "merda",
  "collons",
  "imbecil",
  "imbècil",
  "idiota",
];

const profanityPattern = new RegExp(
  `\\b(${PROFANITY.map((w) => w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|")})\\b`,
  "gi",
);

export function maxChatLength(): number {
  return MAX_CHAT_LENGTH;
}

/** Plain text: strip tags/control chars and collapse whitespace. */
export function sanitizeChatPlainText(raw: string): string {
  const noTags = raw.replace(/<[^>]*>/g, "");
  const cleaned = noTags
    .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, "")
    .replace(/\s+/g, " ")
    .trim();
  return cleaned;
}

export function filterProfanity(text: string): string {
  return text.replace(profanityPattern, "***");
}

export function prepareChatMessage(raw: unknown): { ok: true; text: string } | { ok: false; code: string } {
  if (typeof raw !== "string") {
    return { ok: false, code: "BAD_PAYLOAD" };
  }
  const sanitized = sanitizeChatPlainText(raw);
  if (!sanitized) {
    return { ok: false, code: "CHAT_EMPTY" };
  }
  if (sanitized.length > MAX_CHAT_LENGTH) {
    return { ok: false, code: "CHAT_TOO_LONG" };
  }
  return { ok: true, text: filterProfanity(sanitized) };
}
