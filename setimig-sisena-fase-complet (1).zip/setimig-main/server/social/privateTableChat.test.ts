import { describe, it, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";
import fs from "fs/promises";
import os from "os";
import path from "path";
import { createServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket } from "socket.io-client";
import { resetGameStateForTests, setupGameHandlers } from "../game.ts";
import { issuePlayerToken } from "../playerToken.ts";
import {
  flushPrivateRoomStoreWritesForTests,
  resetPrivateRoomStoreCacheForTests,
} from "../privateRoomStore.ts";
import { resetSocialChatForTests } from "./privateTableChat.ts";
import { resetChatRateLimitsForTests } from "./chatRateLimit.ts";

const HOST_ID = "privchathost000001";
const GUEST_ID = "privchatguest00001";

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";
process.env.SETIMIG_TEST_FAST = "1";

function connect(url: string): Promise<Socket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.on("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.on("connect_error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

function waitJoined(socket: Socket): Promise<{ id: string; inviteCode?: string }> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("join timeout")), 15_000);
    socket.once("joined_room", (room) => {
      clearTimeout(timer);
      resolve(room);
    });
  });
}

async function startServer() {
  resetGameStateForTests();
  resetSocialChatForTests();
  resetChatRateLimitsForTests();
  const http = createServer();
  const io = new SocketIOServer(http, { cors: { origin: "*" } });
  await setupGameHandlers(io);
  await new Promise<void>((resolve) => http.listen(0, resolve));
  const port = (http.address() as { port: number }).port;
  return { url: `http://127.0.0.1:${port}`, http, io };
}

async function stopServer(io: SocketIOServer, http: ReturnType<typeof createServer>) {
  io.close();
  await new Promise<void>((resolve) => http.close(() => resolve()));
  await flushPrivateRoomStoreWritesForTests();
  resetPrivateRoomStoreCacheForTests();
}

describe("private table chat", () => {
  let dataDir = "";

  beforeEach(async () => {
    dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "setimig-chat-"));
    process.env.BALANCE_DATA_DIR = dataDir;
    process.env.FRIENDS_DATA_DIR = dataDir;
  });

  afterEach(async () => {
    delete process.env.BALANCE_DATA_DIR;
    delete process.env.FRIENDS_DATA_DIR;
    if (dataDir) await fs.rm(dataDir, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 });
  });

  it("rejects invalid or foreign tokens and only broadcasts to room members", async () => {
    const hostToken = issuePlayerToken(HOST_ID)!;
    const guestToken = issuePlayerToken(GUEST_ID)!;
    const { url, http, io } = await startServer();
    const host = await connect(url);
    let guest: Socket | null = null;
    let outsider: Socket | null = null;
    try {
      const hostJoined = waitJoined(host);
      host.emit("create_private_table", { playerName: "Host", playerId: HOST_ID, playerToken: hostToken });
      const hostRoom = await hostJoined;

      guest = await connect(url);
      const guestJoined = waitJoined(guest);
      guest.emit("join_private_table", {
        inviteCode: hostRoom.inviteCode,
        playerName: "Guest",
        playerId: GUEST_ID,
        playerToken: guestToken,
      });
      await guestJoined;

      outsider = await connect(url);
      const outsiderMsgs: unknown[] = [];
      outsider.on("new_message", (m) => outsiderMsgs.push(m));

      const badTokenErr = await new Promise<{ code?: string }>((resolve, reject) => {
        const t = setTimeout(() => reject(new Error("timeout")), 3000);
        host.once("game_error", (e) => {
          clearTimeout(t);
          resolve(e);
        });
        host.emit("send_message", { roomId: hostRoom.id, message: "hola", playerToken: "fals.token" });
      });
      assert.equal(badTokenErr.code, "BAD_TOKEN");

      const otherTokenErr = await new Promise<{ code?: string }>((resolve, reject) => {
        const t = setTimeout(() => reject(new Error("timeout")), 3000);
        host.once("game_error", (e) => {
          clearTimeout(t);
          resolve(e);
        });
        host.emit("send_message", { roomId: hostRoom.id, message: "hola", playerToken: guestToken });
      });
      assert.equal(otherTokenErr.code, "BAD_TOKEN");

      const guestMsgs: { text?: string }[] = [];
      guest.on("new_message", (m) => guestMsgs.push(m));
      host.emit("send_message", {
        roomId: hostRoom.id,
        message: "hola sala",
        playerToken: hostToken,
      });
      // Abans: espera fixa de 80 ms, que fallava amb la màquina carregada.
      for (let waited = 0; guestMsgs.length < 1 && waited < 3000; waited += 20) {
        await new Promise((r) => setTimeout(r, 20));
      }
      await new Promise((r) => setTimeout(r, 80));
      assert.equal(guestMsgs.length, 1);
      assert.equal(outsiderMsgs.length, 0);

      host.emit("send_message", {
        roomId: hostRoom.id,
        message: "merda filtrada",
        playerToken: hostToken,
      });
      for (let waited = 0; !guestMsgs.some((m) => m.text?.includes("***")) && waited < 3000; waited += 20) {
        await new Promise((r) => setTimeout(r, 20));
      }
      assert.ok(guestMsgs.some((m) => m.text?.includes("***")));

      host.emit("send_message", {
        roomId: hostRoom.id,
        message: "x".repeat(201),
        playerToken: hostToken,
      });
      const tooLong = await new Promise<{ code?: string }>((resolve, reject) => {
        const t = setTimeout(() => reject(new Error("timeout")), 3000);
        host.once("game_error", (e) => {
          clearTimeout(t);
          resolve(e);
        });
      });
      assert.equal(tooLong.code, "CHAT_TOO_LONG");
    } finally {
      guest?.disconnect();
      outsider?.disconnect();
      host.disconnect();
      await stopServer(io, http);
    }
  });

  it("accepts chat from a legacy seat without playerToken (perfil sense setimig_player_token)", async () => {
    const { url, http, io } = await startServer();
    const host = await connect(url);
    let guest: Socket | null = null;
    try {
      const hostJoined = waitJoined(host);
      // Com el client real: create/join només envien playerId (cap token).
      host.emit("create_private_table", { playerName: "Host", playerId: HOST_ID });
      const hostRoom = await hostJoined;
      guest = await connect(url);
      const guestJoined = waitJoined(guest);
      guest.emit("join_private_table", { inviteCode: hostRoom.inviteCode, playerName: "Guest", playerId: GUEST_ID });
      await guestJoined;

      const errors: { code?: string }[] = [];
      host.on("game_error", (e) => errors.push(e));
      const guestMsgs: { text?: string; sender?: string }[] = [];
      guest.on("new_message", (m) => guestMsgs.push(m));
      host.emit("send_message", { roomId: hostRoom.id, message: "Bona mà" });
      host.emit("send_message", { roomId: hostRoom.id, message: "buit", playerToken: "" });
      for (let waited = 0; guestMsgs.length < 2 && waited < 3000; waited += 20) {
        await new Promise((r) => setTimeout(r, 20));
      }
      assert.deepEqual(errors, []);
      assert.equal(guestMsgs.length, 2);
      assert.equal(guestMsgs[0].text, "Bona mà");
      assert.equal(guestMsgs[0].sender, "Host");
    } finally {
      guest?.disconnect();
      host.disconnect();
      await stopServer(io, http);
    }
  });

  it("rate limits chat and emotes per player", async () => {
    const hostToken = issuePlayerToken(HOST_ID)!;
    const { url, http, io } = await startServer();
    const host = await connect(url);
    try {
      const hostJoined = waitJoined(host);
      host.emit("create_private_table", { playerName: "Host", playerId: HOST_ID, playerToken: hostToken });
      const room = await hostJoined;

      let received = 0;
      host.on("new_message", () => {
        received += 1;
      });
      host.on("room_emote", () => {
        received += 1;
      });

      for (let i = 0; i < 5; i++) {
        host.emit("send_message", {
          roomId: room.id,
          message: `msg ${i}`,
          playerToken: hostToken,
        });
      }
      await new Promise((r) => setTimeout(r, 120));
      assert.equal(received, 5);

      const rateErr = await new Promise<{ code?: string }>((resolve, reject) => {
        const t = setTimeout(() => reject(new Error("timeout")), 3000);
        host.once("game_error", (e) => {
          clearTimeout(t);
          resolve(e);
        });
        host.emit("send_message", {
          roomId: room.id,
          message: "sisè",
          playerToken: hostToken,
        });
      });
      assert.equal(rateErr.code, "CHAT_RATE_LIMIT");
    } finally {
      host.disconnect();
      await stopServer(io, http);
    }
  });
});
