const WINDOW_MS = 10_000;
const MAX_EVENTS = 5;

const buckets = new Map<string, number[]>();

function windowMs(): number {
  if (process.env.SETIMIG_TEST_FAST === "1") return 200;
  return WINDOW_MS;
}

export function resetChatRateLimitsForTests(): void {
  buckets.clear();
}

export function checkAndRecordChatRate(playerId: string): boolean {
  const now = Date.now();
  const win = windowMs();
  const prev = buckets.get(playerId) ?? [];
  const recent = prev.filter((t) => now - t < win);
  if (recent.length >= MAX_EVENTS) {
    buckets.set(playerId, recent);
    return false;
  }
  recent.push(now);
  buckets.set(playerId, recent);
  return true;
}
