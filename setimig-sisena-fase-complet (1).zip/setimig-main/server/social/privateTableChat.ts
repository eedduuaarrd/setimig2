import type { Server, Socket } from "socket.io";
import type { Room } from "../../shared/gameEngine.ts";
import type { Player } from "../../shared/gameEngine.ts";
import { isMissingPlayerToken, verifyPrivatePlayerToken, type GameActionError } from "../gameActionAuth.ts";
import { prepareChatMessage } from "./chatText.ts";
import { checkAndRecordChatRate, resetChatRateLimitsForTests } from "./chatRateLimit.ts";
import {
  appendRoomChatEntry,
  clearRoomChatHistory,
  getRoomChatHistory,
  resetRoomChatHistoryForTests,
  type RoomChatEntry,
} from "./roomChatHistory.ts";
import { isAllowedEmote } from "./emotes.ts";

function isSocketRecord(payload: unknown): payload is Record<string, unknown> {
  return typeof payload === "object" && payload !== null && !Array.isArray(payload);
}

function formatTimeLabel(): string {
  return new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function memberAuth(
  room: Room | undefined,
  player: Player | undefined,
  playerToken: unknown,
): GameActionError | null {
  if (!room?.isPrivate) {
    return { message: "El xat només està disponible a taules privades.", code: "CHAT_PRIVATE_ONLY" };
  }
  if (!player || player.isBot) {
    return { message: "Jugador no trobat a la taula.", code: "NOT_IN_ROOM" };
  }
  // El socket ja està lligat al seient (create/join_private_table). Igual que les accions de joc
  // (normalizePrivateActionMeta), un missatge sense token s'accepta per a aquest seient: els perfils
  // amb id llegat no tenen `setimig_player_token` i abans rebien BAD_TOKEN al xat. Un token explícit
  // invàlid, caducat o d'un altre jugador continua rebutjat.
  if (isMissingPlayerToken(playerToken)) return null;
  return verifyPrivatePlayerToken(player, playerToken);
}

function emitChatError(socket: Socket, err: GameActionError): void {
  socket.emit("game_error", err);
}

export function resetSocialChatForTests(): void {
  resetChatRateLimitsForTests();
  resetRoomChatHistoryForTests();
}

export function emitChatHistoryToSocket(socket: Socket, roomId: string): void {
  const entries = getRoomChatHistory(roomId);
  if (entries.length === 0) return;
  socket.emit("chat_history", { roomId, entries });
}

export function handlePrivateSendMessage(
  io: Server,
  socket: Socket,
  payload: unknown,
  resolveRoom: (roomId: string) => Room | undefined,
  onBadPayload: () => void,
): void {
  if (!isSocketRecord(payload)) {
    onBadPayload();
    return;
  }
  const { roomId, message, playerToken } = payload;
  if (typeof roomId !== "string" || typeof message !== "string") {
    onBadPayload();
    return;
  }
  const room = resolveRoom(roomId);
  const player = room?.players.find((p) => p.id === socket.id);
  const authErr = memberAuth(room, player, playerToken);
  if (authErr) {
    if (authErr.code !== "NOT_IN_ROOM") emitChatError(socket, authErr);
    return;
  }
  const prepared = prepareChatMessage(message);
  if (prepared.ok === false) {
    if (prepared.code === "BAD_PAYLOAD") onBadPayload();
    else if (prepared.code === "CHAT_TOO_LONG") {
      emitChatError(socket, { message: "Missatge massa llarg.", code: "CHAT_TOO_LONG" });
    }
    return;
  }
  if (!checkAndRecordChatRate(player!.playerId)) {
    emitChatError(socket, {
      message: "Massa missatges. Espera uns segons.",
      code: "CHAT_RATE_LIMIT",
    });
    return;
  }
  const entry: RoomChatEntry = {
    kind: "message",
    sender: player!.name,
    text: prepared.text,
    timestamp: formatTimeLabel(),
  };
  appendRoomChatEntry(roomId, entry);
  io.to(roomId).emit("new_message", {
    sender: entry.sender,
    text: entry.text,
    timestamp: entry.timestamp,
  });
}

export function handlePrivateSendEmote(
  io: Server,
  socket: Socket,
  payload: unknown,
  resolveRoom: (roomId: string) => Room | undefined,
  onBadPayload: () => void,
): void {
  if (!isSocketRecord(payload)) {
    onBadPayload();
    return;
  }
  const { roomId, emoteId, playerToken } = payload;
  if (typeof roomId !== "string" || emoteId === undefined) {
    onBadPayload();
    return;
  }
  if (!isAllowedEmote(emoteId)) {
    onBadPayload();
    return;
  }
  const room = resolveRoom(roomId);
  const player = room?.players.find((p) => p.id === socket.id);
  const authErr = memberAuth(room, player, playerToken);
  if (authErr) {
    if (authErr.code !== "NOT_IN_ROOM") emitChatError(socket, authErr);
    return;
  }
  if (!checkAndRecordChatRate(player!.playerId)) {
    emitChatError(socket, {
      message: "Massa reaccions. Espera uns segons.",
      code: "CHAT_RATE_LIMIT",
    });
    return;
  }
  const entry: RoomChatEntry = {
    kind: "emote",
    sender: player!.name,
    emoteId,
    timestamp: formatTimeLabel(),
  };
  appendRoomChatEntry(roomId, entry);
  io.to(roomId).emit("room_emote", {
    sender: entry.sender,
    emoteId: entry.emoteId,
    timestamp: entry.timestamp,
  });
}

export function forgetRoomChatWhenDestroyed(roomId: string): void {
  clearRoomChatHistory(roomId);
}
