const ALLOWED_EMOTES = new Set([
  "thumbs_up",
  "wave",
  "clap",
  "laugh",
  "think",
  "fire",
  "heart",
  "sad",
]);

export function isAllowedEmote(id: unknown): id is string {
  return typeof id === "string" && ALLOWED_EMOTES.has(id);
}

export function listAllowedEmotes(): string[] {
  return [...ALLOWED_EMOTES];
}
