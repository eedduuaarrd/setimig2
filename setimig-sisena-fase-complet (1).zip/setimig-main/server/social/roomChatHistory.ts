export type RoomChatEntry = {
  kind: "message" | "emote";
  sender: string;
  text?: string;
  emoteId?: string;
  timestamp: string;
};

import { retentionLimits } from "../dataRetention.ts";

const MAX_HISTORY = 40;
const history = new Map<string, RoomChatEntry[]>();

export function resetRoomChatHistoryForTests(): void {
  history.clear();
}

export function appendRoomChatEntry(roomId: string, entry: RoomChatEntry): void {
  let list = history.get(roomId);
  if (!list) {
    list = [];
    const maxRooms = retentionLimits().chatRooms;
    while (history.size >= maxRooms) {
      const oldest = history.keys().next().value;
      if (oldest === undefined) break;
      history.delete(oldest);
    }
  }
  list.push(entry);
  if (list.length > MAX_HISTORY) {
    list.splice(0, list.length - MAX_HISTORY);
  }
  history.set(roomId, list);
}

export function getRoomChatHistory(roomId: string, limit = 30): RoomChatEntry[] {
  const list = history.get(roomId) ?? [];
  return list.slice(-limit);
}

export function clearRoomChatHistory(roomId: string): void {
  history.delete(roomId);
}
