import { createHash } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { writeJsonAtomic } from "./writeCoalescing.ts";

/**
 * Comptes esborrats (data/deleted-accounts.json): només el sha256 del playerId i la data.
 *
 * Els tokens de jugador són HMAC sense estat i duren un any; perquè un compte esborrat deixi de
 * funcionar, `verifyPlayerToken`, `issuePlayerToken` i el camí antic sense token consulten aquesta
 * llista. Es desa el hash (no el playerId) per no conservar l'identificador del compte esborrat.
 * Lectura síncrona i en memòria (la verificació de tokens és síncrona).
 */
type File = { version: 1; players: Record<string, number> };

let cache: { file: string; hashes: Map<string, number> } | null = null;
let chain: Promise<unknown> = Promise.resolve();
/** playerIds esborrats en aquest procés (en clar només a memòria): el saldo els treu en desar. */
const deletedHere = new Set<string>();

export function accountsDeletedInThisProcess(): string[] {
  return [...deletedHere];
}

function dataDir(): string {
  return process.env.BALANCE_DATA_DIR || path.join(process.cwd(), "data");
}

export function deletedAccountsPath(): string {
  return path.join(dataDir(), "deleted-accounts.json");
}

export function hashPlayerId(playerId: string): string {
  return createHash("sha256").update(`setimig-deleted-account:${playerId}`).digest("hex");
}

function load(): Map<string, number> {
  const file = deletedAccountsPath();
  if (cache && cache.file === file) return cache.hashes;
  const hashes = new Map<string, number>();
  let raw: string | null = null;
  try {
    raw = fs.readFileSync(file, "utf8");
  } catch (err) {
    if ((err as NodeJS.ErrnoException)?.code !== "ENOENT") throw err;
  }
  if (raw !== null) {
    // Fitxer malmès: error. Mai s'ha de tornar a acceptar un compte esborrat per un fitxer il·legible.
    const parsed = JSON.parse(raw) as Partial<File>;
    for (const [h, at] of Object.entries(parsed.players ?? {})) {
      if (/^[a-f0-9]{64}$/.test(h)) hashes.set(h, Number(at) || 0);
    }
  }
  cache = { file, hashes };
  return hashes;
}

export function isAccountDeleted(playerId: string): boolean {
  return load().has(hashPlayerId(playerId));
}

/** Marca el compte com a esborrat (idempotent) i ho desa abans de tornar. */
export function markAccountDeleted(playerId: string, now = Date.now()): Promise<boolean> {
  const run = async () => {
    const hashes = load();
    deletedHere.add(playerId);
    const h = hashPlayerId(playerId);
    if (hashes.has(h)) return false;
    hashes.set(h, now);
    const out: File = { version: 1, players: Object.fromEntries(hashes) };
    await fs.promises.mkdir(dataDir(), { recursive: true });
    await writeJsonAtomic(deletedAccountsPath(), out);
    return true;
  };
  const next = chain.then(run, run);
  chain = next.catch(() => undefined);
  return next;
}

export function resetDeletedAccountsForTests(): void {
  cache = null;
  chain = Promise.resolve();
  deletedHere.clear();
}
