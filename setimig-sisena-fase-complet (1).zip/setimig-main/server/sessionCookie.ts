import type { NextFunction, Request, Response } from "express";
import { verifyPlayerToken } from "./playerToken.ts";

/**
 * Galeta de sessió perquè la navegació directa (sense JS ni capçalera Bearer) pugui obrir els
 * HTML estàtics privats de dist/ (`/regles/`…). Conté el mateix token HMAC que el client desa a
 * localStorage. HttpOnly + Secure + SameSite=Lax + Path=/. Max-Age = caducitat del token.
 *
 * La llegeix la porta d'HTML estàtic (staticHtmlLogin.ts) i, per recuperar la sessió,
 * POST /api/player-session quan no hi ha Bearer vàlid. La resta de /api i el socket no
 * la llegeixen (SameSite=Lax; a la renovació per galeta també es comprova l'origen).
 * Mai es registra el valor del token.
 */
export const SESSION_COOKIE = "setimig_session";

export function sessionCookieHeader(token: string, maxAgeS: number): string {
  return `${SESSION_COOKIE}=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${Math.max(0, Math.floor(maxAgeS))}`;
}

export function clearSessionCookieHeader(): string {
  return `${SESSION_COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0`;
}

export function readSessionCookie(req: Pick<Request, "headers">): string | null {
  const header = req.headers.cookie;
  if (typeof header !== "string") return null;
  for (const part of header.split(";")) {
    const i = part.indexOf("=");
    if (i < 0 || part.slice(0, i).trim() !== SESSION_COOKIE) continue;
    const v = part.slice(i + 1).trim();
    return /^[A-Za-z0-9_.-]{1,2048}$/.test(v) ? v : null;
  }
  return null;
}

function appendSetCookie(res: Response, value: string): void {
  const prev = res.getHeader("Set-Cookie");
  const list = prev === undefined ? [] : Array.isArray(prev) ? prev.map(String) : [String(prev)];
  res.setHeader("Set-Cookie", [...list, value]);
}

export function setSessionCookie(res: Response, token: string): boolean {
  const v = verifyPlayerToken(token);
  if (!v) return false;
  appendSetCookie(res, sessionCookieHeader(token, (v.exp - Date.now()) / 1000));
  return true;
}

export function clearSessionCookie(res: Response): void {
  appendSetCookie(res, clearSessionCookieHeader());
}

/**
 * Qualsevol resposta JSON d /api que lliuri un `playerToken` vàlid (login per correu, Google,
 * passkey, renovació de sessió POST /api/player-session, traspàs de domini, refresc de token
 * a les accions de joc) també posa la galeta. Així cap camí d inici de sessió se n escapa.
 */
export function sessionCookieMiddleware(req: Request, res: Response, next: NextFunction): void {
  if (!req.path.startsWith("/api/")) return next();
  const json = res.json.bind(res);
  res.json = ((body: unknown) => {
    const tok = (body as { playerToken?: unknown } | null)?.playerToken;
    if (typeof tok === "string" && !res.headersSent && res.statusCode < 400) setSessionCookie(res, tok);
    return json(body);
  }) as Response["json"];
  next();
}
