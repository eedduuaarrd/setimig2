import { describe, it, before, after, beforeEach } from "node:test";
import assert from "node:assert/strict";
import fs from "fs/promises";
import path from "path";
import { createServer, type Server as HttpServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket as ClientSocket } from "socket.io-client";
import {
  closeSoloBuyIn,
  flushBalanceWrites,
  getBalance,
  listOpenSoloBuyIns,
  resetBalanceStoreCacheForTests,
  setBalance,
} from "./balances.ts";
import {
  getGameHostForTests,
  getRoomSnapshotForTests,
  leaveAuthoritativeSolo,
  lobbyHeldStack,
  resetGameStateForTests,
  setupGameHandlers,
} from "./game.ts";
import {
  openSoloBuyInForRoom,
  recordSoloHandOnLedger,
  settleSoloBuyIn,
  soloBuyInPayout,
} from "./soloBuyIn.ts";
import {
  beginGameStart,
  clearRoomTimers,
  emptyRoomBase,
  type GameHost,
  type Player,
  type Room,
} from "../shared/gameEngine.ts";
import { PHASE_B_START_CHIPS } from "../shared/matchPhaseB.ts";
import { createManualClockHost } from "../shared/testing/manualClockHost.ts";

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";

/**
 * Saldo real de les partides solo: compra d'entrada en seure, abonament només verificat en
 * sortir (si no quadra, només la compra), idempotent, i retorn de la compra després d'un reinici.
 */

const DATA_ROOT = path.join(process.cwd(), "data", `solo-buyin-test-${Date.now()}`);

type TestServer = { url: string; http: HttpServer; io: SocketIOServer };

async function startTestServer(): Promise<TestServer> {
  const http = createServer();
  const io = new SocketIOServer(http, { cors: { origin: "*" } });
  await setupGameHandlers(io);
  await new Promise<void>((resolve) => http.listen(0, "127.0.0.1", () => resolve()));
  const addr = http.address();
  const port = typeof addr === "object" && addr ? addr.port : 0;
  return { url: `http://127.0.0.1:${port}`, http, io };
}

async function stopTestServer(server: TestServer): Promise<void> {
  resetGameStateForTests();
  server.io.close();
  await new Promise<void>((resolve) => server.http.close(() => resolve()));
}

function connect(url: string): Promise<ClientSocket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.on("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.on("connect_error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

type JoinOutcome = { room?: { id: string }; error?: { code?: string; required?: number; balance?: number } };

function joinSolo(socket: ClientSocket, playerId: string): Promise<JoinOutcome> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("join timeout")), 10_000);
    const done = (out: JoinOutcome) => {
      clearTimeout(timer);
      socket.off("joined_room");
      socket.off("game_error");
      resolve(out);
    };
    socket.once("joined_room", (room: { id: string }) => done({ room }));
    socket.once("game_error", (error: JoinOutcome["error"]) => done({ error }));
    socket.emit("join_solo_room", { playerName: "Compra", playerId, botCount: 3 });
  });
}

async function waitFor(cond: () => boolean | Promise<boolean>, label: string, ms = 5_000): Promise<void> {
  const deadline = Date.now() + ms;
  while (!(await cond())) {
    if (Date.now() > deadline) throw new Error(`${label} timeout`);
    await new Promise((r) => setTimeout(r, 10));
  }
}

function seat(id: string, extra: Partial<Player> = {}): Player {
  return {
    id,
    playerId: id,
    seatToken: `${id}-t`,
    name: id,
    chips: PHASE_B_START_CHIPS,
    bet: 0,
    isBanker: false,
    status: "waiting",
    handSlots: [],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
    ...extra,
  };
}

function ledgerRoom(playerId: string): Room {
  const room = emptyRoomBase(`solo-${playerId}`, "Partida IA", 100, 1000);
  room.soloAi = true;
  room.autoFillBots = false;
  room.soloHumanPlayerId = playerId;
  room.players = [seat(playerId), seat("bot-a", { isBot: true, isBanker: true })];
  return room;
}

/** Simula una mà liquidada al servidor: canvi de fitxes i registre al llibre (com onHandSettled). */
function settleHand(room: Room, playerId: string, delta: number): void {
  const human = room.players.find((p) => p.playerId === playerId)!;
  const banker = room.players.find((p) => p.isBanker)!;
  human.chips += delta;
  banker.chips -= delta;
  room.phase = "settlement";
  room.lastRound = {
    title: "Liquidació",
    highlights: [],
    results: [
      { name: human.name, outcome: delta >= 0 ? "win" : "lose", chipDelta: delta, detail: "" },
      { name: banker.name, outcome: delta >= 0 ? "lose" : "win", chipDelta: -delta, detail: "" },
    ],
    at: Date.now(),
  };
  recordSoloHandOnLedger(room);
  room.phase = "waiting";
}

async function withCapturedErrors<T>(fn: () => Promise<T>): Promise<{ result: T; errors: string[] }> {
  const errors: string[] = [];
  const original = console.error;
  console.error = (...args: unknown[]) => {
    errors.push(args.map(String).join(" "));
  };
  try {
    return { result: await fn(), errors };
  } finally {
    console.error = original;
  }
}

describe("solo amb saldo real: compra d'entrada i abonament verificat", () => {
  before(() => {
    process.env.BALANCE_DATA_DIR = DATA_ROOT;
    process.env.SETIMIG_TEST_FAST = "1";
    resetBalanceStoreCacheForTests();
  });

  beforeEach(() => {
    resetGameStateForTests();
  });

  after(async () => {
    resetGameStateForTests();
    await flushBalanceWrites().catch(() => undefined);
    resetBalanceStoreCacheForTests();
    await fs.rm(DATA_ROOT, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 }).catch(() => undefined);
    delete process.env.BALANCE_DATA_DIR;
    delete process.env.SETIMIG_TEST_FAST;
  });

  it("en seure es descompta la compra del saldo real i queda oberta", async () => {
    const playerId = "buyindeduct0001";
    await setBalance(playerId, 5_000);
    const server = await startTestServer();
    const socket = await connect(server.url);
    try {
      const out = await joinSolo(socket, playerId);
      assert.ok(out.room, `s'ha pogut seure (${out.error?.code})`);
      assert.equal(await getBalance(playerId), 5_000 - PHASE_B_START_CHIPS);
      const open = Object.values(await listOpenSoloBuyIns()).filter((e) => e.playerId === playerId);
      assert.equal(open.length, 1);
      assert.equal(open[0]!.amount, PHASE_B_START_CHIPS);
      const room = getRoomSnapshotForTests(out.room!.id)!;
      assert.equal(room.players.find((p) => p.playerId === playerId)?.chips, PHASE_B_START_CHIPS);
    } finally {
      socket.disconnect();
      await stopTestServer(server);
    }
  });

  it("saldo 0: no seu, no descompta res (INSUFFICIENT_BALANCE amb required i balance)", async () => {
    const playerId = "buyinzerobal001";
    await setBalance(playerId, 0);
    const server = await startTestServer();
    const socket = await connect(server.url);
    try {
      const out = await joinSolo(socket, playerId);
      assert.equal(out.error?.code, "INSUFFICIENT_BALANCE");
      assert.equal(out.error?.required, PHASE_B_START_CHIPS);
      assert.equal(out.error?.balance, 0);
      assert.equal(await getBalance(playerId), 0);
      assert.ok(!Object.values(await listOpenSoloBuyIns()).some((e) => e.playerId === playerId));
      assert.equal(getRoomSnapshotForTests(`solo-${playerId}`)?.players.some((p) => p.playerId === playerId) ?? false, false);
    } finally {
      socket.disconnect();
      await stopTestServer(server);
    }
  });

  it("saldo parcial (1–1.999): compra = tot el saldo i seu amb aquestes fitxes", async () => {
    for (const balance of [1, 650, 1_999]) {
      const playerId = `buyinpartial${String(balance).padStart(4, "0")}`;
      await setBalance(playerId, balance);
      const server = await startTestServer();
      const socket = await connect(server.url);
      try {
        const out = await joinSolo(socket, playerId);
        assert.ok(out.room, `saldo ${balance}: s'ha pogut seure (${out.error?.code})`);
        assert.equal(await getBalance(playerId), 0, `saldo ${balance}: es descompta tot`);
        const open = Object.values(await listOpenSoloBuyIns()).filter((e) => e.playerId === playerId);
        assert.equal(open.length, 1);
        assert.equal(open[0]!.amount, balance);
        const room = getRoomSnapshotForTests(out.room!.id)!;
        assert.equal(room.soloBuyIn?.amount, balance);
        const human = room.players.find((p) => p.playerId === playerId)!;
        assert.equal(human.chips + human.bet, balance, `saldo ${balance}: seu amb ${balance} fitxes`);
        const bots = room.players.filter((p) => p.playerId !== playerId);
        assert.equal(room.phaseB?.chipPool, balance + bots.length * PHASE_B_START_CHIPS);
        // Sortir amb la partida congelada: s'abona el resultat verificat de la compra parcial.
        await waitFor(() => room.phase !== "waiting", "inici de la mà");
        clearRoomTimers(getGameHostForTests(), room);
        const payout = soloBuyInPayout(room, room.soloBuyIn!, human);
        assert.equal(payout.verified, true);
        await new Promise<void>((resolve) => {
          socket.once("room_left", () => resolve());
          socket.emit("leave_room", room.id);
        });
        assert.equal(await getBalance(playerId), payout.credit);
        assert.ok(payout.credit <= balance);
      } finally {
        socket.disconnect();
        await stopTestServer(server);
      }
    }
  });

  it("revenja amb saldo parcial: compra = saldo restant i seu amb aquestes fitxes", async () => {
    const playerId = "buyinrevpartial";
    await setBalance(playerId, 2_300);
    const server = await startTestServer();
    const socket = await connect(server.url);
    try {
      const out = await joinSolo(socket, playerId);
      assert.ok(out.room);
      assert.equal(await getBalance(playerId), 300);
      const roomId = out.room!.id;
      await waitFor(() => getRoomSnapshotForTests(roomId)?.phase !== "waiting", "inici de la mà");
      const room = getRoomSnapshotForTests(roomId)!;
      clearRoomTimers(getGameHostForTests(), room);
      // Final de partida amb 700 fitxes, coherent amb les mans registrades (−1.300).
      const human = room.players.find((p) => p.playerId === playerId)!;
      const bot = room.players.find((p) => p.playerId !== playerId)!;
      for (const p of room.players) {
        p.bet = 0;
        p.handSlots = [];
        p.status = "waiting";
      }
      room.pot = 0;
      human.chips = 700;
      bot.chips += 1_300;
      room.soloBuyIn!.handsNet = -1_300;
      room.soloBuyIn!.hands = 3;
      room.phase = "waiting";
      room.matchEnded = true;
      await new Promise<void>((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("revenja timeout")), 5_000);
        const tick = () => {
          const r = getRoomSnapshotForTests(roomId);
          if (r && !r.matchEnded && r.soloBuyIn) {
            clearTimeout(timer);
            resolve();
            return;
          }
          setTimeout(tick, 10);
        };
        socket.emit("quick_rematch", roomId);
        tick();
      });
      // 300 + 700 (abonament verificat) = 1.000 → compra parcial de 1.000.
      assert.equal(await getBalance(playerId), 0);
      const after = getRoomSnapshotForTests(roomId)!;
      assert.equal(after.soloBuyIn?.amount, 1_000);
      const seatAfter = after.players.find((p) => p.playerId === playerId)!;
      assert.equal(seatAfter.chips + seatAfter.bet, 1_000);
      const open = Object.values(await listOpenSoloBuyIns()).filter((e) => e.playerId === playerId);
      assert.equal(open.length, 1);
      assert.equal(open[0]!.amount, 1_000);
    } finally {
      socket.disconnect();
      await stopTestServer(server);
    }
  });

  it("en sortir s'abona el resultat verificat (compra + mans)", async () => {
    const playerId = "buyinverify0001";
    await setBalance(playerId, 10_000);
    const room = ledgerRoom(playerId);
    const opened = await openSoloBuyInForRoom(room, playerId, PHASE_B_START_CHIPS);
    assert.ok(opened.ok);
    assert.equal(await getBalance(playerId), 8_000);
    settleHand(room, playerId, 300);
    settleHand(room, playerId, -100);
    settleHand(room, playerId, 450);
    const { result, errors } = await withCapturedErrors(() => settleSoloBuyIn(room, undefined, "test"));
    assert.equal(result?.verified, true);
    assert.equal(result?.credit, 2_650);
    assert.equal(errors.length, 0);
    assert.equal(await getBalance(playerId), 8_000 + 2_650);
  });

  it("a mitja mà l'aposta compta per verificar però es perd (com abans)", async () => {
    const playerId = "buyinmidhand001";
    await setBalance(playerId, 10_000);
    const room = ledgerRoom(playerId);
    await openSoloBuyInForRoom(room, playerId, PHASE_B_START_CHIPS);
    settleHand(room, playerId, 200);
    const human = room.players[0]!;
    human.chips -= 300;
    human.bet = 300;
    room.phase = "playing";
    const payout = soloBuyInPayout(room, room.soloBuyIn!, human);
    assert.deepEqual(payout, { verified: true, credit: 1_900, expected: 2_200, actual: 2_200 });
  });

  it("35.250, compra 2.000, pèrdues 100+100+100+500, surt amb 1.200 → lobby 34.450", async () => {
    const playerId = "buyinvideo35250";
    const start = 35_250;
    await setBalance(playerId, start);
    const room = ledgerRoom(playerId);
    await openSoloBuyInForRoom(room, playerId, PHASE_B_START_CHIPS);
    assert.equal(await getBalance(playerId), start - PHASE_B_START_CHIPS);
    for (const delta of [-100, -100, -100, -500]) settleHand(room, playerId, delta);
    const human = room.players.find((p) => p.playerId === playerId)!;
    assert.equal(human.chips, 1_200);
    const { result, errors } = await withCapturedErrors(() => settleSoloBuyIn(room, human, "sortida"));
    assert.equal(result?.verified, true);
    assert.equal(result?.credit, 1_200);
    assert.notEqual(result?.credit, PHASE_B_START_CHIPS + 1_200);
    assert.equal(errors.length, 0);
    // 35.250 − 2.000 + 1.200. Ni 36.150 (compra + romanent, o un saldo antic) ni 35.250 (pèrdues tornades).
    assert.equal(await getBalance(playerId), 34_450);
  });

  it("dos «Pau»: el llibre agafa el delta del seient, no el de la banca homònima", async () => {
    const playerId = "buyinsamename01";
    await setBalance(playerId, 35_250);
    const room = ledgerRoom(playerId);
    await openSoloBuyInForRoom(room, playerId, PHASE_B_START_CHIPS);
    const human = room.players.find((p) => p.playerId === playerId)!;
    const banker = room.players.find((p) => p.isBanker)!;
    human.name = "Pau";
    banker.name = "Pau";
    human.chips = 1_200;
    banker.chips += 800;
    room.phase = "settlement";
    room.handSeq = 4;
    room.lastRound = {
      title: "Liquidació",
      highlights: [],
      results: [
        {
          name: "Pau",
          outcome: "win",
          chipDelta: 800,
          detail: "",
          params: { player: "Pau", seatId: banker.id, chipDelta: 800, score: null },
        },
        {
          name: "Pau",
          outcome: "lose",
          chipDelta: -800,
          detail: "",
          code: "hands",
          params: { player: "Pau", seatId: human.id, chipDelta: -800, hands: [] },
        },
      ],
      at: Date.now(),
    };
    recordSoloHandOnLedger(room);
    recordSoloHandOnLedger(room);
    assert.equal(room.soloBuyIn!.handsNet, -800, "la mateixa mà no es suma dues vegades");
    const { result } = await withCapturedErrors(() => settleSoloBuyIn(room, human, "sortida"));
    assert.equal(result?.credit, 1_200);
    assert.equal(await getBalance(playerId), 34_450);
  });

  it("si el llibre no veu les pèrdues, s'abona el romanent i no la compra sencera", async () => {
    const playerId = "buyinmissedloss";
    await setBalance(playerId, 35_250);
    const room = ledgerRoom(playerId);
    await openSoloBuyInForRoom(room, playerId, PHASE_B_START_CHIPS);
    const human = room.players[0]!;
    human.chips = 1_200;
    room.phase = "settlement";
    const { result, errors } = await withCapturedErrors(() => settleSoloBuyIn(room, human, "sortida"));
    assert.equal(result?.verified, false);
    assert.equal(result?.expected, PHASE_B_START_CHIPS);
    assert.equal(result?.credit, 1_200);
    assert.equal(errors.length, 1);
    assert.match(errors[0]!, /fitxes de taula \(1200\)/);
    assert.equal(await getBalance(playerId), 34_450);
  });

  it("si no quadra, es retorna només la compra i es registra l'error", async () => {
    const playerId = "buyinmismatch01";
    await setBalance(playerId, 10_000);
    const room = ledgerRoom(playerId);
    await openSoloBuyInForRoom(room, playerId, PHASE_B_START_CHIPS);
    settleHand(room, playerId, 500);
    // Fitxes que apareixen fora de cap mà liquidada (p. ex. un seient refet amb fitxes noves).
    room.players[0]!.chips += 2_000;
    const { result, errors } = await withCapturedErrors(() => settleSoloBuyIn(room, undefined, "test"));
    assert.equal(result?.verified, false);
    assert.equal(result?.credit, PHASE_B_START_CHIPS);
    assert.equal(await getBalance(playerId), 10_000, "només es recupera la compra");
    assert.equal(errors.length, 1);
    assert.match(errors[0]!, /sala solo-buyinmismatch01/);
    assert.match(errors[0]!, /jugador buyinmismatch01/);
    assert.match(errors[0]!, /esperat 2500, real 4500/);
  });

  it("idempotent: dos tancaments (p. ex. Sortir + destruir) abonen una sola vegada", async () => {
    const playerId = "buyinidempot001";
    await setBalance(playerId, 10_000);
    const room = ledgerRoom(playerId);
    const opened = await openSoloBuyInForRoom(room, playerId, PHASE_B_START_CHIPS);
    assert.ok(opened.ok);
    settleHand(room, playerId, 700);
    await Promise.all([settleSoloBuyIn(room, undefined, "sortida"), settleSoloBuyIn(room, undefined, "destrucció")]);
    assert.equal(await getBalance(playerId), 8_000 + 2_700);
    const again = await closeSoloBuyIn(opened.id, 99_999);
    assert.equal(again.closed, false);
    assert.equal(await getBalance(playerId), 8_000 + 2_700);
  });

  it("servidor: Sortir i després desconnectar abonen una sola vegada", async () => {
    const playerId = "buyinleavedisc1";
    await setBalance(playerId, 6_000);
    const server = await startTestServer();
    const socket = await connect(server.url);
    try {
      const out = await joinSolo(socket, playerId);
      assert.ok(out.room);
      assert.equal(await getBalance(playerId), 4_000);
      const room = getRoomSnapshotForTests(out.room!.id)!;
      // Sortida abans de començar cap mà: el resultat verificat és la compra sencera.
      await new Promise<void>((resolve) => {
        socket.once("room_left", () => resolve());
        socket.emit("leave_room", room.id);
      });
      socket.disconnect();
      await new Promise((r) => setTimeout(r, 200));
      assert.equal(await getBalance(playerId), 6_000);
      assert.ok(!Object.values(await listOpenSoloBuyIns()).some((e) => e.playerId === playerId));
    } finally {
      socket.disconnect();
      await stopTestServer(server);
    }
  });

  it("seient orfe descartat per «Començar» sense token: la seva compra es tanca una sola vegada", async () => {
    const playerId = "buyinorphanseat";
    await setBalance(playerId, 5_000);
    const server = await startTestServer();
    const first = await connect(server.url);
    let second: ClientSocket | null = null;
    try {
      const out = await joinSolo(first, playerId);
      assert.ok(out.room);
      const roomId = out.room!.id;
      assert.equal(await getBalance(playerId), 3_000);
      await waitFor(() => getRoomSnapshotForTests(roomId)?.phase !== "waiting", "inici de la mà");
      first.disconnect();
      await waitFor(
        () => getRoomSnapshotForTests(roomId)?.players.some((p) => p.playerId === playerId && p.isBot) ?? false,
        "seient en mans de la IA"
      );
      const room = getRoomSnapshotForTests(roomId)!;
      clearRoomTimers(getGameHostForTests(), room);
      const oldLedger = { ...room.soloBuyIn! };
      const orphan = room.players.find((p) => p.playerId === playerId)!;
      const expected = soloBuyInPayout(room, room.soloBuyIn!, orphan);
      assert.equal(expected.verified, true);
      second = await connect(server.url);
      // Sense soloResumeToken: el seient orfe es descarta i comença una partida nova.
      const again = await joinSolo(second, playerId);
      assert.ok(again.room, `partida nova (${again.error?.code})`);
      const open = await listOpenSoloBuyIns();
      assert.equal(open[oldLedger.id], undefined, "la compra del seient orfe s'ha tancat");
      const mine = Object.values(open).filter((e) => e.playerId === playerId);
      assert.equal(mine.length, 1, "només hi ha la compra de la partida nova");
      assert.equal(mine[0]!.amount, PHASE_B_START_CHIPS);
      assert.equal(await getBalance(playerId), 3_000 + expected.credit - PHASE_B_START_CHIPS);
      const reclose = await closeSoloBuyIn(oldLedger.id, 99_999);
      assert.equal(reclose.closed, false, "mai es tanca dues vegades");
    } finally {
      first.disconnect();
      second?.disconnect();
      await stopTestServer(server);
    }
  });

  it("reinici amb una compra oberta: en arrencar es retorna la compra", async () => {
    const playerId = "buyinrestart001";
    await setBalance(playerId, 7_000);
    const server = await startTestServer();
    const socket = await connect(server.url);
    try {
      const out = await joinSolo(socket, playerId);
      assert.ok(out.room);
      assert.equal(await getBalance(playerId), 5_000);
      // Partida en marxa: la desconnexió deixa el seient a la IA i la compra continua oberta.
      await waitFor(() => getRoomSnapshotForTests(out.room!.id)?.phase !== "waiting", "inici de la mà");
      socket.disconnect();
      await new Promise((r) => setTimeout(r, 100));
    } finally {
      socket.disconnect();
      await stopTestServer(server);
    }
    // «Reinici»: la sala en memòria s'ha perdut i el store es torna a llegir del disc.
    resetBalanceStoreCacheForTests();
    assert.ok(Object.values(await listOpenSoloBuyIns()).some((e) => e.playerId === playerId), "la compra és al disc");
    const restarted = await startTestServer();
    try {
      await waitFor(async () => (await getBalance(playerId)) === 7_000, "retorn de la compra");
      assert.ok(!Object.values(await listOpenSoloBuyIns()).some((e) => e.playerId === playerId));
    } finally {
      await stopTestServer(restarted);
    }
    // Un segon arrencada no torna a abonar res.
    const again = await startTestServer();
    try {
      await new Promise((r) => setTimeout(r, 100));
      assert.equal(await getBalance(playerId), 7_000);
    } finally {
      await stopTestServer(again);
    }
  });

  it("sortir a mitja mà torna el seient sense l'aposta i un segon tancament no duplica", async () => {
    const playerId = "buyinmidleave01";
    const start = 10_000;
    await setBalance(playerId, start);
    const server = await startTestServer();
    const socket = await connect(server.url);
    try {
      const out = await joinSolo(socket, playerId);
      assert.ok(out.room);
      const roomId = out.room!.id;
      await waitFor(() => getRoomSnapshotForTests(roomId)?.phase === "betting", "apostes", 20_000);
      socket.emit("place_bet", { roomId, amount: 100 });
      await waitFor(() => {
        const room = getRoomSnapshotForTests(roomId);
        const human = room?.players.find((p) => p.playerId === playerId);
        return room?.phase === "playing" && (human?.bet ?? 0) > 0;
      }, "mà en joc", 20_000);
      const mid = getRoomSnapshotForTests(roomId)!;
      const human = mid.players.find((p) => p.playerId === playerId)!;
      const bet = human.bet;
      assert.equal(human.chips + human.bet, PHASE_B_START_CHIPS);
      assert.equal(await getBalance(playerId), start - PHASE_B_START_CHIPS);
      await new Promise<void>((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("room_left timeout")), 10_000);
        socket.once("room_left", (payload: { chips?: number }) => {
          clearTimeout(timer);
          assert.equal(payload.chips, start - bet);
          resolve();
        });
        socket.emit("leave_room", roomId);
      });
      assert.equal(await getBalance(playerId), start - bet, "el vestíbul no es queda les 2.000");
      assert.equal(lobbyHeldStack(playerId), 0);
      assert.ok(!Object.values(await listOpenSoloBuyIns()).some((e) => e.playerId === playerId));
      assert.equal(await leaveAuthoritativeSolo(playerId), false);
      assert.equal(await getBalance(playerId), start - bet, "liquidar després no torna l'aposta una altra vegada");
    } finally {
      socket.disconnect();
      await stopTestServer(server);
    }
  });

  it("desconnectar a mitja mà: el vestíbul suma les fitxes de taula; sortir després no duplica", async () => {
    const playerId = "buyinmiddisc001";
    const start = 10_000;
    await setBalance(playerId, start);
    const server = await startTestServer();
    const socket = await connect(server.url);
    try {
      const out = await joinSolo(socket, playerId);
      assert.ok(out.room);
      const roomId = out.room!.id;
      await waitFor(() => getRoomSnapshotForTests(roomId)?.phase === "betting", "apostes", 20_000);
      socket.emit("place_bet", { roomId, amount: 100 });
      await waitFor(() => {
        const room = getRoomSnapshotForTests(roomId);
        const human = room?.players.find((p) => p.playerId === playerId);
        return (human?.bet ?? 0) > 0;
      }, "aposta feta", 20_000);
      const before = getRoomSnapshotForTests(roomId)!;
      const seated = before.players.find((p) => p.playerId === playerId)!;
      const bet = seated.bet;
      const tableStack = seated.chips + seated.bet;
      socket.disconnect();
      await waitFor(
        () => getRoomSnapshotForTests(roomId)?.players.some((p) => p.playerId === playerId && p.isBot) ?? false,
        "seient en mans de la IA",
        10_000
      );
      clearRoomTimers(getGameHostForTests(), getRoomSnapshotForTests(roomId)!);
      const held = lobbyHeldStack(playerId);
      assert.equal(held, tableStack);
      assert.equal((await getBalance(playerId)) + held, start, "el vestíbul no baixa les 2.000 mentre la compra és oberta");
      assert.equal(await leaveAuthoritativeSolo(playerId), true);
      assert.equal(await getBalance(playerId), start - bet);
      assert.equal(lobbyHeldStack(playerId), 0);
      assert.equal(await leaveAuthoritativeSolo(playerId), false);
      assert.equal(await getBalance(playerId), start - bet);
    } finally {
      socket.disconnect();
      await stopTestServer(server);
    }
  });

  it("partides senceres jugades pel motor: el resultat sempre quadra (cap abonament injust)", async () => {
    for (let game = 0; game < 12; game++) {
      const playerId = `buyinfullgame${String(game).padStart(2, "0")}`;
      await setBalance(playerId, 10_000);
      const clock = createManualClockHost({ capMs: 50, syncDateNow: true });
      const host: GameHost = { ...clock.host, onHandSettled: (r) => recordSoloHandOnLedger(r) };
      const room = emptyRoomBase(`solo-${playerId}`, "Partida IA", 100, 1000);
      room.soloAi = true;
      room.autoFillBots = false;
      room.soloBotCount = 3;
      room.soloHumanPlayerId = playerId;
      // El seient del jugador el juga la IA (com després d'una desconnexió): partida sencera sola.
      room.players = [
        seat(playerId, { isBot: true, id: "bot-solo-human" }),
        seat("bot-a", { isBot: true }),
        seat("bot-b", { isBot: true }),
        seat("bot-c", { isBot: true }),
      ];
      const opened = await openSoloBuyInForRoom(room, playerId, PHASE_B_START_CHIPS);
      assert.ok(opened.ok);
      try {
        beginGameStart(host, room);
        clock.runUntil(() => !!room.matchEnded, 3_000_000);
      } finally {
        clock.restoreDateNow();
      }
      assert.equal(room.matchEnded, true, `partida ${game} acabada`);
      const ledger = room.soloBuyIn!;
      const human = room.players.find((p) => p.playerId === playerId);
      const payout = soloBuyInPayout(room, ledger, human);
      assert.equal(payout.verified, true, `partida ${game}: esperat ${payout.expected}, real ${payout.actual}`);
      assert.ok(ledger.hands > 0);
    }
  });
});
