/**
 * IP del client per a límits (HTTP i sockets).
 * Només es confia en `CF-Connecting-IP` quan la connexió arriba per loopback
 * (Cloudflare → Caddy → Node a 127.0.0.1). Si la connexió ve d'una altra adreça,
 * la capçalera s'ignora i s'usa l'adreça del socket (no es pot falsificar).
 */
export function isLoopbackAddress(addr: string | undefined | null): boolean {
  return addr === "127.0.0.1" || addr === "::1" || addr === "::ffff:127.0.0.1";
}

type HeaderBag = Record<string, string | string[] | undefined>;

function headerValue(headers: HeaderBag, name: string): string | null {
  const raw = headers[name];
  const v = Array.isArray(raw) ? raw[0] : raw;
  return typeof v === "string" && v.trim() ? v.trim().slice(0, 64) : null;
}

/**
 * Retorna la clau d'IP del client, o `null` per a crides locals directes
 * (loopback sense capçalera de Cloudflare: health checks i gates locals).
 */
export function trustedClientIp(remoteAddress: string | undefined | null, headers: HeaderBag): string | null {
  const remote = remoteAddress ?? "";
  if (isLoopbackAddress(remote)) return headerValue(headers, "cf-connecting-ip");
  return remote ? remote.slice(0, 64) : null;
}
