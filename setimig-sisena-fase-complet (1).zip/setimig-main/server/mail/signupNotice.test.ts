import assert from "node:assert/strict";
import { beforeEach, describe, it } from "node:test";
import { mkdtempSync, mkdirSync, readFileSync, writeFileSync, rmSync } from "node:fs";
import os from "node:os";
import path from "node:path";

const dataDir = mkdtempSync(path.join(os.tmpdir(), "setimig-signup-"));
const profDir = path.join(dataDir, "profiles");
process.env.BALANCE_DATA_DIR = dataDir;
process.env.PROFILE_DATA_DIR = profDir;
delete process.env.ADMIN_SIGNUP_EMAIL;

const { setMailTransportForTests } = await import("./mailer.ts");
const {
  adminSignupEmail,
  buildSignupNotice,
  countAccounts,
  formatMadrid,
  maskEmail,
  notifySignup,
  notifySignupLater,
  registerAccountIdSource,
  resetSignupNoticesForTests,
  signupNoticeEntryForTests,
} = await import("./signupNotice.ts");

type Sent = { to: string; subject: string; text: string; kind: string };
let sent: Sent[] = [];

function resetAll(): void {
  rmSync(dataDir, { recursive: true, force: true });
  mkdirSync(profDir, { recursive: true });
  resetSignupNoticesForTests();
  sent = [];
  setMailTransportForTests(async (msg) => {
    sent.push(msg);
    return { ok: true, provider: "cloudflare", delivered: true };
  });
}

const P1 = "p".repeat(40);
const P2 = "q".repeat(40);

describe("avís de registre", () => {
  beforeEach(() => {
    delete process.env.ADMIN_SIGNUP_EMAIL;
    resetAll();
  });

  it("destinatari per defecte edubernat6@gmail.com; configurable i desactivable", () => {
    assert.equal(adminSignupEmail({}), "edubernat6@gmail.com");
    assert.equal(adminSignupEmail({ ADMIN_SIGNUP_EMAIL: "x@y.cat" }), "x@y.cat");
    assert.equal(adminSignupEmail({ ADMIN_SIGNUP_EMAIL: "off" }), null);
  });

  it("envia nom, via, hora de Madrid i total de comptes", async () => {
    writeFileSync(path.join(profDir, `${P1}.json`), "{}");
    writeFileSync(path.join(profDir, `${P2}.json`), "{}");
    const at = Date.UTC(2026, 9, 27, 13, 31, 0); // 14:31 a Madrid (CET)
    assert.equal(await notifySignup({ playerId: P1, displayName: "Marta", method: "anonim", at }), "sent");
    assert.equal(sent.length, 1);
    const m = sent[0]!;
    assert.equal(m.to, "edubernat6@gmail.com");
    assert.equal(m.kind, "signup_notice");
    assert.match(m.subject, /Marta/);
    assert.match(m.text, /Nom \/ àlies: Marta/);
    assert.match(m.text, /Via de registre: anònim/);
    assert.match(m.text, /27\/10\/2026 14:31:00/);
    assert.match(m.text, /Total de comptes: 2/);
    assert.doesNotMatch(m.subject, /\[prova\]/);
  });

  it("és idempotent per compte (també amb crides simultànies)", async () => {
    const r = await Promise.all([
      notifySignup({ playerId: P1, displayName: "Marta", method: "email", email: "marta@exemple.cat" }),
      notifySignup({ playerId: P1, displayName: "Marta", method: "anonim" }),
    ]);
    assert.deepEqual(r.sort(), ["duplicate", "sent"]);
    assert.equal(await notifySignup({ playerId: P1, method: "google" }), "duplicate");
    assert.equal(sent.length, 1);
    // Persistit: un procés nou tampoc no el torna a enviar.
    resetSignupNoticesForTests();
    assert.equal(await notifySignup({ playerId: P1, method: "anonim" }), "duplicate");
    const stored = JSON.parse(readFileSync(path.join(dataDir, "signup-notices.json"), "utf8"));
    assert.equal(stored.notified[P1].status, "sent");
  });

  it("el correu del jugador surt emmascarat", async () => {
    await notifySignup({ playerId: P1, displayName: "", method: "email", email: "marta.puig@exemple.cat" });
    assert.match(sent[0]!.text, /Correu: m\*\*\*g@exemple\.cat/);
    assert.doesNotMatch(sent[0]!.text, /marta\.puig/);
    assert.match(sent[0]!.text, /encara sense àlies/);
  });

  it("marca [prova] els comptes de prova", async () => {
    await notifySignup({ playerId: P1, displayName: "Test Reg C", method: "anonim" });
    assert.match(sent[0]!.subject, /^\[prova\]/);
  });

  it("error d'enviament: es registra, no llança i no es reintenta", async () => {
    setMailTransportForTests(async () => ({ ok: false, provider: "cloudflare", error: "HTTP_500" }));
    const origErr = console.error;
    const lines: string[] = [];
    console.error = (...a: unknown[]) => void lines.push(a.join(" "));
    try {
      assert.equal(await notifySignup({ playerId: P1, method: "anonim" }), "failed");
    } finally {
      console.error = origErr;
    }
    assert.match(lines.join("\n"), /signup-notice.*HTTP_500/);
    assert.equal((await signupNoticeEntryForTests(P1))?.status, "failed");
    assert.equal(await notifySignup({ playerId: P1, method: "anonim" }), "duplicate");
  });

  it("desactivat amb ADMIN_SIGNUP_EMAIL=off", async () => {
    process.env.ADMIN_SIGNUP_EMAIL = "off";
    assert.equal(await notifySignup({ playerId: P1, method: "anonim" }), "disabled");
    assert.equal(sent.length, 0);
  });

  it("notifySignupLater no bloqueja (retorna abans d'enviar)", async () => {
    let release!: () => void;
    const gate = new Promise<void>((r) => (release = r));
    setMailTransportForTests(async (msg) => {
      await gate;
      sent.push(msg);
      return { ok: true, provider: "cloudflare", delivered: true };
    });
    const t0 = Date.now();
    notifySignupLater({ playerId: P2, method: "anonim" });
    assert.ok(Date.now() - t0 < 50);
    assert.equal(sent.length, 0);
    release();
    for (let i = 0; i < 50 && sent.length === 0; i++) await new Promise((r) => setTimeout(r, 10));
    assert.equal(sent.length, 1);
  });

  it("countAccounts uneix perfils, avisats i fonts externes", async () => {
    writeFileSync(path.join(profDir, `${P1}.json`), "{}");
    registerAccountIdSource(() => [P1, P2, "r".repeat(40)]);
    assert.equal(await countAccounts(), 3);
  });

  it("helpers de format", () => {
    assert.equal(maskEmail("ab@x.cat"), "a***@x.cat");
    assert.equal(maskEmail("marta@x.cat"), "m***a@x.cat");
    assert.equal(maskEmail("a@x.cat"), "a***@x.cat");
    assert.match(formatMadrid(Date.UTC(2026, 6, 1, 10, 0, 0)), /01\/07\/2026 12:00:00/);
    const n = buildSignupNotice({ displayName: "X", method: "google", at: 0, total: 5, test: false, playerIdShort: "abcd1234" });
    assert.match(n.text, /Via de registre: Google/);
    assert.match(n.text, /Total de comptes: 5/);
    assert.equal("html" in n, false, "l'avís és només text pla (sense píxel ni enllaços reescrits)");
  });
});
