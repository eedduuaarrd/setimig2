/**
 * Crida transaccional de Brevo (POST /v3/smtp/email) per al codi d'accés.
 * No envia res si no hi ha clau. Els tests hi passen un fetch simulat.
 *
 * Seguiment: l'API no té un interruptor que tregui el píxel i la reescriptura d'enllaços
 * a tots els comptes. El que sí que accepta la crida:
 * - `to[].contactPixelTrackingConsent: false` (anonimitza obertures i clics si el compte
 *   té activat el consentiment per contacte; si no, Brevo ignora el camp).
 * - capçaleres `X-Mailin-Track`, `X-Mailin-Track-Clicks` i `X-Mailin-Track-Opens` a 0.
 *   Al relé SMTP (prova del 27/10/2026) aquestes capçaleres no aturaven el seguiment.
 * Apagar-ho del tot és un ajust del tauler (Transactional → Settings → Tracking), no de l'API.
 * Detall: docs/correu-codi-acces.md.
 */

export const BREVO_TRANSACTIONAL_URL = "https://api.brevo.com/v3/smtp/email";

export const BREVO_TRACKING_OFF_HEADERS: Record<string, string> = {
  "X-Mailin-Track": "0",
  "X-Mailin-Track-Clicks": "0",
  "X-Mailin-Track-Opens": "0",
};

export type BrevoLoginCode = {
  to: string;
  subject: string;
  text: string;
  html: string;
  from: { email: string; name: string };
};

export function brevoLoginCodeBody(msg: BrevoLoginCode): Record<string, unknown> {
  return {
    sender: { email: msg.from.email, name: msg.from.name },
    to: [{ email: msg.to, contactPixelTrackingConsent: false }],
    subject: msg.subject,
    htmlContent: msg.html,
    textContent: msg.text,
    headers: BREVO_TRACKING_OFF_HEADERS,
  };
}

export type BrevoSendResult = { ok: true; messageId: string | null } | { ok: false; error: string };

export async function sendBrevoLoginCode(
  msg: BrevoLoginCode,
  opts: { apiKey: string; fetchImpl?: typeof fetch }
): Promise<BrevoSendResult> {
  const fetchImpl = opts.fetchImpl ?? fetch;
  const key = opts.apiKey.trim();
  if (!key) return { ok: false, error: "NO_API_KEY" };
  let res: Response;
  try {
    res = await fetchImpl(BREVO_TRANSACTIONAL_URL, {
      method: "POST",
      headers: {
        "api-key": key,
        "Content-Type": "application/json",
        accept: "application/json",
      },
      body: JSON.stringify(brevoLoginCodeBody(msg)),
    });
  } catch (err) {
    const name = err instanceof Error ? err.name : "Error";
    return { ok: false, error: `NETWORK_${name}` };
  }
  let body: { messageId?: unknown } | null = null;
  try {
    body = (await res.json()) as { messageId?: unknown };
  } catch {
    body = null;
  }
  if (!res.ok) return { ok: false, error: `HTTP_${res.status}` };
  const messageId = typeof body?.messageId === "string" ? body.messageId : null;
  return { ok: true, messageId };
}
