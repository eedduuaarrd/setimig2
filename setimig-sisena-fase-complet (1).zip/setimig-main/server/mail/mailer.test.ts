import assert from "node:assert/strict";
import { afterEach, describe, it } from "node:test";
import {
  isValidEmailAddress,
  mailCanDeliver,
  mailFrom,
  mailStatus,
  sendMail,
  setMailFetchForTests,
  setMailTransportForTests,
} from "./mailer.ts";

const CF_ENV = {
  MAIL_PROVIDER: "cloudflare",
  CF_EMAIL_ACCOUNT_ID: "acc123",
  CF_EMAIL_API_TOKEN: "tok-secret-xyz",
};

function captureLogs(): { lines: string[]; restore: () => void } {
  const lines: string[] = [];
  const orig = { log: console.log, warn: console.warn, error: console.error };
  for (const k of ["log", "warn", "error"] as const) console[k] = (...a: unknown[]) => void lines.push(a.join(" "));
  return { lines, restore: () => Object.assign(console, orig) };
}

describe("mailer: configuració", () => {
  afterEach(() => {
    setMailFetchForTests(null);
    setMailTransportForTests(null);
  });

  it("per defecte és mode log (no envia)", () => {
    assert.deepEqual(mailStatus({}), { requested: "log", effective: "log" });
    assert.equal(mailCanDeliver({}), false);
  });

  it("cloudflare sense compte o token cau a log", () => {
    const s = mailStatus({ MAIL_PROVIDER: "cloudflare", CF_EMAIL_ACCOUNT_ID: "a" });
    assert.equal(s.effective, "log");
    assert.match(s.reason ?? "", /CF_EMAIL/);
    assert.equal(mailStatus(CF_ENV).effective, "cloudflare");
  });

  it("remitent per defecte noreply@sevenhalf.club / Seven Half Club", () => {
    assert.deepEqual(mailFrom({}), { address: "noreply@sevenhalf.club", name: "Seven Half Club" });
  });

  it("mai des de Gmail: remitent o SMTP de Google cauen a log", () => {
    assert.equal(mailStatus({ ...CF_ENV, MAIL_FROM: "edu@gmail.com" }).effective, "log");
    assert.equal(mailStatus({ MAIL_PROVIDER: "smtp", SMTP_HOST: "smtp.gmail.com" }).effective, "log");
    assert.equal(mailStatus({ MAIL_PROVIDER: "smtp", SMTP_HOST: "smtp.mx.cloudflare.net" }).effective, "smtp");
  });

  it("valida adreces", () => {
    assert.equal(isValidEmailAddress("a@b.cat"), true);
    assert.equal(isValidEmailAddress("no-arrova"), false);
    assert.equal(isValidEmailAddress("a@b"), false);
    assert.equal(isValidEmailAddress("a b@c.com"), false);
  });
});

describe("mailer: enviament", () => {
  afterEach(() => {
    setMailFetchForTests(null);
    setMailTransportForTests(null);
  });

  it("mode log: no crida la xarxa i el log no conté adreça ni assumpte", async () => {
    let called = false;
    setMailFetchForTests((async () => {
      called = true;
      return new Response("{}");
    }) as typeof fetch);
    const cap = captureLogs();
    try {
      const r = await sendMail({ to: "persona@exemple.cat", subject: "Codi secret 123456", text: "x", kind: "login_code" }, {});
      assert.deepEqual(r, { ok: true, provider: "log", delivered: false });
    } finally {
      cap.restore();
    }
    assert.equal(called, false);
    const all = cap.lines.join("\n");
    assert.match(all, /mode=log kind=login_code/);
    assert.doesNotMatch(all, /persona|exemple|123456|Codi/);
  });

  it("cloudflare: POST a l'API REST amb Bearer i cos correcte", async () => {
    let seen: { url: string; init: RequestInit } | null = null;
    setMailFetchForTests((async (url: string, init: RequestInit) => {
      seen = { url, init };
      return new Response(JSON.stringify({ success: true, errors: [], result: { delivered: ["a@b.cat"], permanent_bounces: [], queued: [] } }), { status: 200 });
    }) as unknown as typeof fetch);
    const cap = captureLogs();
    let r;
    try {
      r = await sendMail({ to: "a@b.cat", subject: "S", text: "T", html: "<p>T</p>", kind: "signup_notice" }, CF_ENV);
    } finally {
      cap.restore();
    }
    assert.deepEqual(r, { ok: true, provider: "cloudflare", delivered: true });
    assert.ok(seen);
    const s = seen as { url: string; init: RequestInit };
    assert.equal(s.url, "https://api.cloudflare.com/client/v4/accounts/acc123/email/sending/send");
    assert.equal((s.init.headers as Record<string, string>).Authorization, "Bearer tok-secret-xyz");
    const body = JSON.parse(String(s.init.body));
    assert.deepEqual(body.to, ["a@b.cat"]);
    assert.deepEqual(body.from, { address: "noreply@sevenhalf.club", name: "Seven Half Club" });
    assert.equal(body.subject, "S");
    assert.equal(body.html, "<p>T</p>");
    assert.doesNotMatch(cap.lines.join("\n"), /tok-secret|a@b\.cat/);
  });

  it("cloudflare: error de l'API retorna ok:false sense filtrar el token", async () => {
    setMailFetchForTests((async () =>
      new Response(JSON.stringify({ success: false, errors: [{ code: 10102, message: "email.sending.error.authentication.forbidden" }] }), { status: 403 })) as unknown as typeof fetch);
    const cap = captureLogs();
    let r;
    try {
      r = await sendMail({ to: "a@b.cat", subject: "S", text: "T", kind: "x" }, CF_ENV);
    } finally {
      cap.restore();
    }
    assert.equal(r.ok, false);
    assert.match((r as { error: string }).error, /HTTP_403_10102/);
    assert.doesNotMatch(cap.lines.join("\n"), /tok-secret/);
  });

  it("cloudflare: rebot permanent i error de xarxa són fallades", async () => {
    setMailFetchForTests((async () =>
      new Response(JSON.stringify({ success: true, result: { delivered: [], permanent_bounces: ["a@b.cat"] } }))) as unknown as typeof fetch);
    const cap = captureLogs();
    try {
      assert.deepEqual(await sendMail({ to: "a@b.cat", subject: "S", text: "T", kind: "x" }, CF_ENV), {
        ok: false,
        provider: "cloudflare",
        error: "PERMANENT_BOUNCE",
      });
      setMailFetchForTests((async () => {
        throw new TypeError("fetch failed");
      }) as typeof fetch);
      const r = await sendMail({ to: "a@b.cat", subject: "S", text: "T", kind: "x" }, CF_ENV);
      assert.equal(r.ok, false);
    } finally {
      cap.restore();
    }
  });

  it("destinatari invàlid no s'envia", async () => {
    const cap = captureLogs();
    try {
      const r = await sendMail({ to: "dolent", subject: "S", text: "T", kind: "x" }, CF_ENV);
      assert.equal(r.ok, false);
    } finally {
      cap.restore();
    }
  });
});
