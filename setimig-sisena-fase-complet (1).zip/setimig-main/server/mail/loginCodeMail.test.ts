import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { loginCodeHasTrackingUrl, renderLoginCodeMail } from "./loginCodeTemplate.ts";
import { BREVO_TRANSACTIONAL_URL, brevoLoginCodeBody, sendBrevoLoginCode } from "./brevoClient.ts";
import { buildLoginMail, MAIL_LOCALES } from "../auth/emailLogin.ts";

const COPY = {
  ca: /El teu codi per entrar a Seven Half Club/,
  en: /Your Seven Half Club sign-in code/,
  es: /Tu código para entrar en Seven Half Club/,
  it: /Il tuo codice per accedere a Seven Half Club/,
  "pt-BR": /Seu código para entrar no Seven Half Club/,
} as const;

describe("plantilla del codi d'accés", () => {
  it("porta el codi, l'idioma, la marca i cap URL de seguiment", () => {
    for (const locale of MAIL_LOCALES) {
      const mail = buildLoginMail("482913", locale, null);
      assert.match(mail.subject, /482913/);
      assert.match(mail.text, /482913/);
      assert.match(mail.html, /482913/);
      assert.match(mail.html, new RegExp(`lang="${locale}"`));
      assert.match(mail.html, /#0b0b0b/i);
      assert.match(mail.html, /#f5f2eb/i);
      assert.match(mail.html, /#d4af6a/i);
      assert.match(mail.html, /Cormorant Garamond/);
      assert.match(mail.html, /DM Sans/);
      assert.match(mail.html, /Seven Half Club/);
      assert.match(mail.text, COPY[locale]);
      assert.match(mail.html, COPY[locale]);
      assert.equal(loginCodeHasTrackingUrl(mail.html), false, locale);
      assert.equal(loginCodeHasTrackingUrl(mail.text), false, locale);
      assert.doesNotMatch(mail.html, /<img\b/i);
      assert.doesNotMatch(mail.html, /<a\b/i);
    }
  });

  it("el text pla i l'HTML diuen el mateix codi i no barregen idiomes", () => {
    const ca = renderLoginCodeMail({
      locale: "ca",
      code: "111222",
      subject: "111222 és el teu codi de Seven Half Club",
      intro: "El teu codi per entrar a Seven Half Club: 111222",
      pageLine: "Escriu-lo a la pantalla d'inici de sessió:",
      loginUrl: "https://sevenhalf.club/login/correu",
      expiry: "Caduca d'aquí a 10 minuts i només es pot fer servir un cop.",
      ignore: "Si no l'has demanat tu, ignora aquest correu.",
    });
    assert.match(ca.text, /111222/);
    assert.doesNotMatch(ca.text, /sign-in code|código|codice|código do/i);
    assert.doesNotMatch(ca.html, /sign-in code/);
  });
});

describe("crida Brevo simulada", () => {
  it("envia HTML i text, el codi a l'assumpte, i desactiva el seguiment; no truca a la xarxa real", async () => {
    const mail = buildLoginMail("909090", "en", null);
    let called = 0;
    let seenUrl = "";
    let seenKey = "";
    let seenBody: Record<string, unknown> | null = null;
    const fetchImpl: typeof fetch = async (input, init) => {
      called += 1;
      seenUrl = String(input);
      seenKey = new Headers(init?.headers).get("api-key") ?? "";
      seenBody = JSON.parse(String(init?.body)) as Record<string, unknown>;
      return new Response(JSON.stringify({ messageId: "<id@brevo>" }), { status: 201 });
    };
    const result = await sendBrevoLoginCode(
      {
        to: "persona@exemple.cat",
        subject: mail.subject,
        text: mail.text,
        html: mail.html,
        from: { email: "noreply@sevenhalf.club", name: "Seven Half Club" },
      },
      { apiKey: "xkeysib-test-only", fetchImpl }
    );
    assert.deepEqual(result, { ok: true, messageId: "<id@brevo>" });
    assert.equal(called, 1);
    assert.equal(seenUrl, BREVO_TRANSACTIONAL_URL);
    assert.equal(seenKey, "xkeysib-test-only");
    const body = brevoLoginCodeBody({
      to: "persona@exemple.cat",
      subject: mail.subject,
      text: mail.text,
      html: mail.html,
      from: { email: "noreply@sevenhalf.club", name: "Seven Half Club" },
    });
    assert.deepEqual(seenBody, body);
    assert.deepEqual((seenBody!.to as { contactPixelTrackingConsent: boolean }[])[0], {
      email: "persona@exemple.cat",
      contactPixelTrackingConsent: false,
    });
    const headers = seenBody!.headers as Record<string, string>;
    assert.equal(headers["X-Mailin-Track"], "0");
    assert.equal(headers["X-Mailin-Track-Clicks"], "0");
    assert.equal(headers["X-Mailin-Track-Opens"], "0");
    assert.match(String(seenBody!.subject), /909090/);
    assert.match(String(seenBody!.htmlContent), /909090/);
    assert.match(String(seenBody!.textContent), /909090/);
    assert.equal(loginCodeHasTrackingUrl(String(seenBody!.htmlContent)), false);
    assert.doesNotMatch(JSON.stringify(seenBody), /xkeysib-test-only/);
  });
});
