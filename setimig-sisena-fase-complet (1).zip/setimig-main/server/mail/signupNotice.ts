import fs from "fs/promises";
import path from "path";
import { isTestIdentity } from "../analytics.ts";
import { sanitizePlayerId } from "../balances.ts";
import { writeJsonAtomic } from "../writeCoalescing.ts";
import { isValidEmailAddress, sendMail, type MailResult } from "./mailer.ts";

/**
 * Avís de registre a l'administrador: cada compte nou envia UN correu (idempotent per playerId)
 * a ADMIN_SIGNUP_EMAIL (per defecte edubernat6@gmail.com) pel canal propi de l'app (mailer.ts).
 *
 * - Asíncron: `notifySignupLater` no bloqueja mai el registre; els errors només es registren.
 * - Idempotència: data/signup-notices.json (escriptura atòmica) guarda els playerId ja avisats.
 *   Es marca ABANS d'enviar (com a molt un correu per compte, encara que el procés caigui).
 * - ADMIN_SIGNUP_EMAIL=off desactiva l'avís.
 */
export const DEFAULT_ADMIN_SIGNUP_EMAIL = "edubernat6@gmail.com";

export type SignupMethod = "anonim" | "email" | "google" | "passkey";

export const SIGNUP_METHOD_LABEL: Record<SignupMethod, string> = {
  anonim: "anònim (perfil amb verificació 18+)",
  email: "correu (codi o enllaç màgic)",
  google: "Google",
  passkey: "passkey (Face ID / Touch ID)",
};

export type SignupNoticeInput = {
  playerId: string;
  displayName?: string | null;
  method: SignupMethod;
  /** Correu verificat (només se n'envia una versió emmascarada). */
  email?: string | null;
  at?: number;
};

type NoticeEntry = { at: number; method: SignupMethod; status: "pending" | "sent" | "log" | "failed" };
type NoticeStore = { notified: Record<string, NoticeEntry> };

function dataDir(): string {
  return process.env.BALANCE_DATA_DIR || path.join(process.cwd(), "data");
}

function storePath(): string {
  return path.join(dataDir(), "signup-notices.json");
}

function profileDir(): string {
  return process.env.PROFILE_DATA_DIR || path.join(process.cwd(), "data", "profiles");
}

let cache: NoticeStore | null = null;
let chain: Promise<unknown> = Promise.resolve();
/** Altres fonts de comptes (p. ex. identitats creades per login abans de tenir perfil). */
const extraAccountSources: Array<() => Promise<Iterable<string>> | Iterable<string>> = [];

export function registerAccountIdSource(src: () => Promise<Iterable<string>> | Iterable<string>): void {
  extraAccountSources.push(src);
}

async function load(): Promise<NoticeStore> {
  if (cache) return cache;
  try {
    const parsed = JSON.parse(await fs.readFile(storePath(), "utf8")) as Partial<NoticeStore>;
    cache = { notified: parsed && typeof parsed.notified === "object" && parsed.notified ? parsed.notified : {} };
  } catch (err) {
    if ((err as NodeJS.ErrnoException)?.code !== "ENOENT") {
      // Fitxer malmès: no se sobreescriu (es conserva per revisar-lo) i no s'envia res.
      throw new Error("signup-notices.json illegible");
    }
    cache = { notified: {} };
  }
  return cache;
}

function serial<T>(fn: () => Promise<T>): Promise<T> {
  const next = chain.then(fn, fn);
  chain = next.catch(() => undefined);
  return next;
}

/** Nombre total de comptes: perfils desats ∪ comptes avisats ∪ altres fonts registrades. */
export async function countAccounts(): Promise<number> {
  const ids = new Set<string>();
  try {
    for (const f of await fs.readdir(profileDir())) {
      if (f.endsWith(".json") && !f.endsWith(".tmp")) ids.add(f.slice(0, -5));
    }
  } catch {
    /* sense perfils */
  }
  const store = await load().catch(() => ({ notified: {} }) as NoticeStore);
  for (const id of Object.keys(store.notified)) ids.add(id);
  for (const src of extraAccountSources) {
    try {
      for (const id of await src()) ids.add(id);
    } catch {
      /* font opcional */
    }
  }
  return ids.size;
}

export function maskEmail(email: string): string {
  const [local, domain] = email.trim().toLowerCase().split("@");
  if (!local || !domain) return "(invàlid)";
  const shown = local.length <= 2 ? local[0] : `${local[0]}${local[local.length - 1]}`;
  return `${shown[0]}***${shown.length > 1 ? shown[1] : ""}@${domain}`;
}

export function formatMadrid(ms: number): string {
  const parts = new Intl.DateTimeFormat("ca-ES", {
    timeZone: "Europe/Madrid",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
    timeZoneName: "short",
  }).formatToParts(new Date(ms));
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? "";
  return `${get("day")}/${get("month")}/${get("year")} ${get("hour")}:${get("minute")}:${get("second")} (${get("timeZoneName")}, Europe/Madrid)`;
}

export function adminSignupEmail(env: NodeJS.ProcessEnv | Record<string, string | undefined> = process.env): string | null {
  const raw = (env.ADMIN_SIGNUP_EMAIL ?? "").trim();
  if (/^(off|none|no|0|false)$/i.test(raw)) return null;
  const addr = raw || DEFAULT_ADMIN_SIGNUP_EMAIL;
  return isValidEmailAddress(addr) ? addr : null;
}

export function buildSignupNotice(input: {
  displayName: string;
  method: SignupMethod;
  at: number;
  total: number;
  maskedEmail?: string | null;
  test: boolean;
  playerIdShort: string;
}): { subject: string; text: string } {
  const name = input.displayName.trim() || "(encara sense àlies)";
  const when = formatMadrid(input.at);
  const subject = `${input.test ? "[prova] " : ""}Nou compte a Seven Half Club: ${name.slice(0, 40)} (${input.total} comptes)`;
  const lines = [
    `Nom / àlies: ${name}`,
    `Via de registre: ${SIGNUP_METHOD_LABEL[input.method]}`,
    ...(input.maskedEmail ? [`Correu: ${input.maskedEmail}`] : []),
    `Hora: ${when}`,
    `Total de comptes: ${input.total}`,
    `Id del compte: ${input.playerIdShort}…`,
    ...(input.test ? ["Marcat com a compte de prova pel nom o l'id."] : []),
  ];
  const text = `${lines.join("\n")}\n\n— Seven Half Club (avís automàtic, no responguis)`;
  // Només text pla: sense part HTML, el proveïdor (Brevo) no hi pot afegir píxel ni reescriure enllaços.
  return { subject, text };
}

export type NotifyOutcome = "sent" | "log" | "failed" | "duplicate" | "disabled" | "invalid";

/** Envia (com a molt una vegada per compte) l'avís de registre. No llança mai. */
export async function notifySignup(input: SignupNoticeInput): Promise<NotifyOutcome> {
  const playerId = sanitizePlayerId(input.playerId);
  if (!playerId) return "invalid";
  const to = adminSignupEmail();
  if (!to) return "disabled";
  const at = input.at ?? Date.now();
  try {
    const claimed = await serial(async () => {
      const store = await load();
      if (store.notified[playerId]) return false;
      store.notified[playerId] = { at, method: input.method, status: "pending" };
      await writeJsonAtomic(storePath(), store);
      return true;
    });
    if (!claimed) return "duplicate";

    const total = await countAccounts();
    const displayName = (input.displayName ?? "").toString().slice(0, 60);
    const msg = buildSignupNotice({
      displayName,
      method: input.method,
      at,
      total,
      maskedEmail: input.email && isValidEmailAddress(input.email) ? maskEmail(input.email) : null,
      test: isTestIdentity(playerId, displayName),
      playerIdShort: playerId.slice(0, 8),
    });
    let result: MailResult;
    try {
      result = await sendMail({ to, kind: "signup_notice", ...msg });
    } catch {
      result = { ok: false, provider: "log", error: "THROW" };
    }
    const status: NoticeEntry["status"] = "error" in result ? "failed" : result.delivered ? "sent" : "log";
    await serial(async () => {
      const store = await load();
      const prev = store.notified[playerId];
      if (prev) prev.status = status;
      await writeJsonAtomic(storePath(), store);
    });
    if ("error" in result) console.error(`[signup-notice] player=${playerId.slice(0, 8)} error=${result.error}`);
    return status;
  } catch (err) {
    console.error(`[signup-notice] player=${playerId.slice(0, 8)} error=${err instanceof Error ? err.message : "?"}`);
    return "failed";
  }
}

/** Dispara l'avís sense esperar-lo (el registre no s'espera mai al correu). */
export function notifySignupLater(input: SignupNoticeInput): void {
  setImmediate(() => {
    void notifySignup(input);
  });
}

export function resetSignupNoticesForTests(): void {
  cache = null;
  chain = Promise.resolve();
  extraAccountSources.length = 0;
}

export async function signupNoticeEntryForTests(playerId: string): Promise<NoticeEntry | undefined> {
  return (await load()).notified[playerId];
}
