/**
 * Canal de correu propi de l'app (remitent noreply@sevenhalf.club).
 *
 * Proveïdors (MAIL_PROVIDER):
 * - `cloudflare`: Cloudflare Email Sending, API REST des del VPS
 *   (POST https://api.cloudflare.com/client/v4/accounts/{CF_EMAIL_ACCOUNT_ID}/email/sending/send,
 *   capçalera Authorization: Bearer CF_EMAIL_API_TOKEN, permís «Email Sending: Edit»).
 * - `smtp`: SMTP genèric (SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS). Port 465 = TLS implícit.
 * - `log` (per defecte, o si falta configuració): no envia res; només deixa una línia de log
 *   sense dades personals (ni adreces, ni assumpte, ni contingut).
 *
 * Mai s'envia des de cap Gmail: si el remitent o el servidor SMTP són de Google, es refusa.
 * Els secrets només es llegeixen de l'entorn i no s'escriuen mai al log.
 */

export type MailProvider = "cloudflare" | "smtp" | "log";

export type MailMessage = {
  to: string;
  subject: string;
  text: string;
  html?: string;
  /** Capçaleres extra (p. ex. desactivar el seguiment de Brevo al relé SMTP). */
  headers?: Record<string, string>;
  /** Tipus de correu per al log (p. ex. "signup_notice", "login_code"). Sense dades personals. */
  kind: string;
};

export type MailResult =
  | { ok: true; provider: MailProvider; delivered: boolean }
  | { ok: false; provider: MailProvider; error: string };

export type MailTransport = (msg: MailMessage, from: { address: string; name: string }) => Promise<MailResult>;

type Env = NodeJS.ProcessEnv | Record<string, string | undefined>;

export const DEFAULT_MAIL_FROM = "noreply@sevenhalf.club";
export const DEFAULT_MAIL_FROM_NAME = "Seven Half Club";
const CF_API_BASE = "https://api.cloudflare.com/client/v4";
const SEND_TIMEOUT_MS = 10_000;
const EMAIL_RE = /^[^\s@<>()",;:]{1,64}@[a-z0-9.-]{1,190}\.[a-z]{2,24}$/i;

let testTransport: MailTransport | null = null;
let fetchImpl: typeof fetch = (input, init) => fetch(input, init);

/** Només per a tests: substitueix l'enviament real (o null per restaurar-lo). */
export function setMailTransportForTests(t: MailTransport | null): void {
  testTransport = t;
}

export function hasMailTestTransport(): boolean {
  return testTransport !== null;
}

/** Només per a tests: substitueix el fetch del proveïdor Cloudflare. */
export function setMailFetchForTests(f: typeof fetch | null): void {
  fetchImpl = f ?? ((input, init) => fetch(input, init));
}

export function isValidEmailAddress(raw: unknown): raw is string {
  return typeof raw === "string" && raw.length <= 254 && EMAIL_RE.test(raw.trim());
}

function str(env: Env, key: string): string {
  return (env[key] ?? "").trim();
}

const GOOGLE_MAIL_DOMAIN_RE = /@(gmail\.com|googlemail\.com)$/i;
const GOOGLE_SMTP_RE = /(^|\.)(gmail\.com|googlemail\.com|google\.com)$/i;

export function mailFrom(env: Env = process.env): { address: string; name: string } {
  const address = str(env, "MAIL_FROM") || DEFAULT_MAIL_FROM;
  const name = str(env, "MAIL_FROM_NAME") || DEFAULT_MAIL_FROM_NAME;
  return { address, name };
}

export type MailStatus = {
  /** Proveïdor demanat a MAIL_PROVIDER. */
  requested: MailProvider;
  /** Proveïdor que s'usarà de veritat (log si falta configuració o està prohibida). */
  effective: MailProvider;
  /** Motiu pel qual s'ha caigut a log (sense secrets). */
  reason?: string;
};

export function mailStatus(env: Env = process.env): MailStatus {
  const raw = str(env, "MAIL_PROVIDER").toLowerCase();
  const requested: MailProvider = raw === "cloudflare" || raw === "smtp" ? raw : "log";
  if (requested === "log") return { requested, effective: "log" };
  const from = mailFrom(env);
  if (!isValidEmailAddress(from.address)) return { requested, effective: "log", reason: "MAIL_FROM invàlid" };
  if (GOOGLE_MAIL_DOMAIN_RE.test(from.address)) {
    return { requested, effective: "log", reason: "remitent de Gmail prohibit" };
  }
  if (requested === "cloudflare") {
    if (!str(env, "CF_EMAIL_ACCOUNT_ID") || !str(env, "CF_EMAIL_API_TOKEN")) {
      return { requested, effective: "log", reason: "falten CF_EMAIL_ACCOUNT_ID o CF_EMAIL_API_TOKEN" };
    }
    return { requested, effective: "cloudflare" };
  }
  const host = str(env, "SMTP_HOST").toLowerCase();
  if (!host) return { requested, effective: "log", reason: "falta SMTP_HOST" };
  if (GOOGLE_SMTP_RE.test(host)) return { requested, effective: "log", reason: "SMTP de Google prohibit" };
  return { requested, effective: "smtp" };
}

/** El canal pot enviar correus de veritat (no és el mode log). */
export function mailCanDeliver(env: Env = process.env): boolean {
  return mailStatus(env).effective !== "log";
}

async function sendViaCloudflare(msg: MailMessage, from: { address: string; name: string }, env: Env): Promise<MailResult> {
  const accountId = encodeURIComponent(str(env, "CF_EMAIL_ACCOUNT_ID"));
  const url = `${CF_API_BASE}/accounts/${accountId}/email/sending/send`;
  let res: Response;
  try {
    res = await fetchImpl(url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${str(env, "CF_EMAIL_API_TOKEN")}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        to: [msg.to],
        from: { address: from.address, name: from.name },
        subject: msg.subject,
        text: msg.text,
        ...(msg.html ? { html: msg.html } : {}),
      }),
      signal: AbortSignal.timeout(SEND_TIMEOUT_MS),
    });
  } catch (err) {
    const name = err instanceof Error ? err.name : "Error";
    return { ok: false, provider: "cloudflare", error: `NETWORK_${name}` };
  }
  let body: {
    success?: boolean;
    errors?: { code?: number; message?: string }[];
    result?: { permanent_bounces?: string[]; suppressed_recipients?: string[] } | null;
  } | null = null;
  try {
    body = (await res.json()) as typeof body;
  } catch {
    body = null;
  }
  if (!res.ok || !body?.success) {
    const first = body?.errors?.[0];
    const code = first?.code ?? res.status;
    const message = typeof first?.message === "string" ? first.message.slice(0, 80) : "";
    return { ok: false, provider: "cloudflare", error: `HTTP_${res.status}_${code}${message ? `_${message}` : ""}` };
  }
  if ((body.result?.permanent_bounces?.length ?? 0) > 0) {
    return { ok: false, provider: "cloudflare", error: "PERMANENT_BOUNCE" };
  }
  if ((body.result?.suppressed_recipients?.length ?? 0) > 0) {
    return { ok: false, provider: "cloudflare", error: "SUPPRESSED" };
  }
  return { ok: true, provider: "cloudflare", delivered: true };
}

async function sendViaSmtp(msg: MailMessage, from: { address: string; name: string }, env: Env): Promise<MailResult> {
  const port = Number(str(env, "SMTP_PORT")) || 465;
  try {
    const nodemailer = (await import("nodemailer")).default;
    const user = str(env, "SMTP_USER");
    const transporter = nodemailer.createTransport({
      host: str(env, "SMTP_HOST"),
      port,
      secure: port === 465,
      requireTLS: port !== 465,
      ...(user ? { auth: { user, pass: str(env, "SMTP_PASS") } } : {}),
      connectionTimeout: SEND_TIMEOUT_MS,
      socketTimeout: SEND_TIMEOUT_MS,
    });
    await transporter.sendMail({
      from: { name: from.name, address: from.address },
      to: msg.to,
      subject: msg.subject,
      text: msg.text,
      ...(msg.html ? { html: msg.html } : {}),
      ...(msg.headers ? { headers: msg.headers } : {}),
    });
    return { ok: true, provider: "smtp", delivered: true };
  } catch (err) {
    const code = (err as { code?: unknown; responseCode?: unknown })?.responseCode ?? (err as { code?: unknown })?.code;
    return { ok: false, provider: "smtp", error: `SMTP_${typeof code === "string" || typeof code === "number" ? code : "ERROR"}` };
  }
}

/**
 * Envia un correu pel canal configurat. Mai llança: retorna el resultat i escriu una línia de log
 * sense dades personals.
 */
export async function sendMail(msg: MailMessage, env: Env = process.env): Promise<MailResult> {
  const kind = String(msg.kind || "mail").replace(/[^a-z0-9_-]/gi, "").slice(0, 40) || "mail";
  if (!isValidEmailAddress(msg.to)) {
    console.warn(`[mail] kind=${kind} destinatari invàlid; no s'envia`);
    return { ok: false, provider: mailStatus(env).effective, error: "BAD_RECIPIENT" };
  }
  const from = mailFrom(env);
  if (testTransport) return testTransport({ ...msg, to: msg.to.trim() }, from);

  const status = mailStatus(env);
  if (status.effective === "log") {
    console.log(
      `[mail] mode=log kind=${kind} (no s'envia${status.reason ? `; ${status.reason}` : ""})`,
    );
    return { ok: true, provider: "log", delivered: false };
  }
  const result =
    status.effective === "cloudflare"
      ? await sendViaCloudflare({ ...msg, to: msg.to.trim() }, from, env)
      : await sendViaSmtp({ ...msg, to: msg.to.trim() }, from, env);
  if ("error" in result) console.error(`[mail] provider=${result.provider} kind=${kind} error=${result.error}`);
  else console.log(`[mail] provider=${result.provider} kind=${kind} enviat`);
  return result;
}

export function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]!);
}
