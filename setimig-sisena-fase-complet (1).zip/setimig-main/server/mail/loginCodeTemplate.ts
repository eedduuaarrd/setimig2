/**
 * Correu del codi d'accés amb la marca del login (Seven Half Club).
 * Fons #0b0b0b, paper #f5f2eb, or #d4af6a (el daurat de /login).
 * Tipografia: Cormorant Garamond (titulars) i DM Sans (cos), com l'app.
 * Sense imatges remotes ni enllaços de seguiment: el proveïdor no hi ha de trobar un píxel
 * ni un href per reescriure. L'adreça de la pantalla de login va en text pla.
 */

export type LoginCodeCopy = {
  locale: string;
  code: string;
  subject: string;
  intro: string;
  pageLine: string;
  loginUrl: string;
  expiry: string;
  ignore: string;
  magicLine?: string | null;
  magicUrl?: string | null;
};

const TRACKING_URL = /sendibt|sendinblue|brevo\.com|\/track\/|open\.gif|pixel/i;

export function loginCodeHasTrackingUrl(value: string): boolean {
  return TRACKING_URL.test(value);
}

function esc(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

export function renderLoginCodeMail(copy: LoginCodeCopy): { subject: string; text: string; html: string } {
  const lines = [copy.intro, "", copy.pageLine, copy.loginUrl];
  if (copy.magicLine && copy.magicUrl) lines.push("", copy.magicLine, copy.magicUrl);
  lines.push("", copy.expiry, copy.ignore);
  const text = lines.join("\n") + "\n";

  const lang = esc(copy.locale);
  const magic =
    copy.magicLine && copy.magicUrl
      ? `<p style="margin:16px 0 0;font-size:14px;line-height:20px;">${esc(copy.magicLine)}<br>${esc(copy.magicUrl)}</p>`
      : "";
  const html = `<!DOCTYPE html>
<html lang="${lang}">
<head><meta charset="utf-8"><title>${esc(copy.subject)}</title></head>
<body style="margin:0;padding:0;background:#0b0b0b;">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#0b0b0b;padding:32px 16px;">
    <tr><td align="center">
      <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:420px;background:#f5f2eb;border-radius:16px;">
        <tr><td style="padding:28px 28px 8px;font-family:'Cormorant Garamond',Georgia,'Times New Roman',serif;font-size:22px;line-height:28px;color:#d4af6a;text-align:center;">Seven Half Club</td></tr>
        <tr><td style="padding:8px 28px 0;font-family:'DM Sans',system-ui,sans-serif;font-size:15px;line-height:22px;color:#0b0b0b;text-align:center;">${esc(copy.intro)}</td></tr>
        <tr><td style="padding:20px 28px 8px;font-family:'Cormorant Garamond',Georgia,'Times New Roman',serif;font-size:40px;line-height:44px;letter-spacing:0.28em;font-weight:600;color:#0b0b0b;text-align:center;">${esc(copy.code)}</td></tr>
        <tr><td style="padding:8px 28px 28px;font-family:'DM Sans',system-ui,sans-serif;font-size:14px;line-height:20px;color:#0b0b0b;text-align:center;">
          <p style="margin:0;">${esc(copy.pageLine)}</p>
          <p style="margin:8px 0 0;">${esc(copy.loginUrl)}</p>
          ${magic}
          <p style="margin:16px 0 0;color:#3a3a3a;">${esc(copy.expiry)}</p>
          <p style="margin:8px 0 0;color:#3a3a3a;">${esc(copy.ignore)}</p>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>
`;
  return { subject: copy.subject, text, html };
}
