import fs from "node:fs";
import path from "node:path";
import { domainKindForHost } from "./allowedOrigins.ts";
import { registerFlusher, writeJsonAtomic, writeJsonAtomicSync } from "./writeCoalescing.ts";

/**
 * Mètrica de migració setimig.supercbb.com -> sevenhalf.club.
 *
 * Per a cada jugador només es desa quan s'ha vist per última vegada a cada domini i quan ha fet
 * el traspàs (cap IP, nom ni user-agent). Fitxer: `<dades>/domain-migration.json`.
 * Les peticions des d'altres hosts (localhost, tests, gates) no compten.
 */
export type MigrationEntry = { oldSeenAt?: number; newSeenAt?: number; migratedAt?: number };
type Store = { players: Record<string, MigrationEntry> };

const DAY_MS = 24 * 60 * 60 * 1000;
const SEEN_RESOLUTION_MS = 60 * 60 * 1000;
let store: Store | null = null;
let loadedFrom = "";
let dirty = false;
let timer: ReturnType<typeof setTimeout> | null = null;

function filePath(): string {
  const dir = process.env.BALANCE_DATA_DIR || path.join(process.cwd(), "data");
  return path.join(dir, "domain-migration.json");
}

function load(): Store {
  const fp = filePath();
  if (store && loadedFrom === fp) return store;
  loadedFrom = fp;
  try {
    const parsed = JSON.parse(fs.readFileSync(fp, "utf8")) as Store;
    store = parsed && typeof parsed.players === "object" && parsed.players ? parsed : { players: {} };
  } catch {
    store = { players: {} };
  }
  return store;
}

function schedule(): void {
  dirty = true;
  if (timer) return;
  timer = setTimeout(() => {
    timer = null;
    void flush().catch((err) => console.error("[domain-migration] write failed:", err));
  }, 2_000);
  timer.unref?.();
}

async function flush(): Promise<void> {
  if (timer) {
    clearTimeout(timer);
    timer = null;
  }
  if (!dirty || !store) return;
  dirty = false;
  await writeJsonAtomic(loadedFrom, store);
}

registerFlusher({
  name: "domain-migration",
  flush,
  flushSync: () => {
    if (!dirty || !store) return;
    dirty = false;
    writeJsonAtomicSync(loadedFrom, store);
  },
});

/** Anota que el jugador ha fet servir l'app des d'aquest Host (només dominis antic i nou). */
export function recordDomainSeen(playerId: string, host: unknown, now = Date.now()): void {
  const kind = domainKindForHost(host);
  if (kind === "other") return;
  const s = load();
  const e = (s.players[playerId] ??= {});
  const key = kind === "old" ? "oldSeenAt" : "newSeenAt";
  // Com a molt una escriptura per jugador i domini cada hora.
  const prev = e[key];
  if (prev && now - prev < SEEN_RESOLUTION_MS) return;
  e[key] = now;
  schedule();
}

export function recordDomainMigrated(playerId: string, now = Date.now()): void {
  const s = load();
  const e = (s.players[playerId] ??= {});
  e.migratedAt = now;
  schedule();
}

export type MigrationStats = {
  windowDays: number;
  /** Jugadors vistos al domini antic dins la finestra. */
  activeOld: number;
  /** D'aquests, quants han fet el traspàs o s'han vist després al domini nou. */
  activeOldMigrated: number;
  activeOldPending: number;
  /** activeOldMigrated / activeOld (1 si no n'hi ha cap). */
  migratedRatio: number;
  activeNew: number;
  totalMigrated: number;
};

export function getMigrationStats(windowDays = 14, now = Date.now()): MigrationStats {
  const s = load();
  const since = now - windowDays * DAY_MS;
  let activeOld = 0;
  let activeOldMigrated = 0;
  let activeNew = 0;
  let totalMigrated = 0;
  for (const e of Object.values(s.players)) {
    const migrated =
      !!e.migratedAt || (!!e.newSeenAt && !!e.oldSeenAt && e.newSeenAt >= e.oldSeenAt);
    if (e.migratedAt) totalMigrated += 1;
    if (e.newSeenAt && e.newSeenAt >= since) activeNew += 1;
    if (e.oldSeenAt && e.oldSeenAt >= since) {
      activeOld += 1;
      if (migrated) activeOldMigrated += 1;
    }
  }
  return {
    windowDays,
    activeOld,
    activeOldMigrated,
    activeOldPending: activeOld - activeOldMigrated,
    migratedRatio: activeOld === 0 ? 1 : activeOldMigrated / activeOld,
    activeNew,
    totalMigrated,
  };
}

export function resetDomainMigrationForTests(): void {
  if (timer) clearTimeout(timer);
  timer = null;
  dirty = false;
  store = null;
  loadedFrom = "";
}

export async function flushDomainMigrationForTests(): Promise<void> {
  await flush();
}
