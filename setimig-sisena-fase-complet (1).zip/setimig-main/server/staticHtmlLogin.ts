import { existsSync, statSync } from "node:fs";
import path from "node:path";
import type { NextFunction, Request, RequestHandler, Response } from "express";
import { resolveAccountSession } from "./requireLogin.ts";
import { readSessionCookie } from "./sessionCookie.ts";

/**
 * Login obligatori també per als HTML estàtics de `dist/` (p. ex. `dist/regles/index.html`),
 * que `express.static` serveix sense passar per l app.
 *
 * Sessió: capçalera Bearer o galeta HttpOnly `setimig_session` (mateixa validació).
 * Sense sessió de compte, qualsevol HTML estàtic (fitxer `*.html` o índex de directori) que no
 * sigui públic redirigeix (302) a `/login?next=<ruta original>`.
 * Públics: l shell SPA (`/`, `/index.html`, que ja fa la seva porta al client), `offline.html`
 * (fallback del service worker), `/privacy`, `/terms`, `/login` (i `/login/correu`) i el 404.
 * Assets (js, css, imatges, fonts, `sw.js`, manifest, icones) no són HTML: no es toquen.
 */
const PUBLIC_PREFIXES = ["/privacy", "/terms", "/login", "/404"];
const PUBLIC_EXACT = new Set(["/", "/index.html", "/offline.html"]);

export function isPublicHtmlPath(p: string): boolean {
  if (PUBLIC_EXACT.has(p)) return true;
  return PUBLIC_PREFIXES.some((pre) => p === pre || p.startsWith(pre + "/") || p.startsWith(pre + "."));
}

/** Fitxer HTML de dist/ que serviria express.static per a aquesta ruta, o null. */
export function staticHtmlFileFor(distPath: string, reqPath: string): string | null {
  let decoded: string;
  try {
    decoded = decodeURIComponent(reqPath);
  } catch {
    return null;
  }
  const abs = path.join(distPath, path.posix.normalize(decoded));
  const rel = path.relative(distPath, abs);
  if (rel.startsWith("..") || path.isAbsolute(rel)) return null;
  if (path.extname(abs).toLowerCase() === ".html" || path.extname(abs).toLowerCase() === ".htm") {
    return existsSync(abs) ? abs : null;
  }
  try {
    if (statSync(abs).isDirectory()) {
      const idx = path.join(abs, "index.html");
      return existsSync(idx) ? idx : null;
    }
  } catch {
    /* no existeix */
  }
  return null;
}

export function staticHtmlLoginGate(distPath: string): RequestHandler {
  return (req: Request, res: Response, next: NextFunction) => {
    if (req.method !== "GET" && req.method !== "HEAD") return next();
    if (isPublicHtmlPath(req.path)) return next();
    if (!staticHtmlFileFor(distPath, req.path)) return next();
    const cookieTok = readSessionCookie(req);
    const sessionReq = req.headers.authorization || !cookieTok
      ? req
      : { headers: { authorization: `Bearer ${cookieTok}` }, body: undefined, query: {} };
    void resolveAccountSession(sessionReq as Request)
      .then((session) => {
        if (session) return next();
        res.setHeader("Cache-Control", "no-store");
        res.redirect(302, "/login?next=" + encodeURIComponent(req.originalUrl || req.path));
      })
      .catch((err) => next(err));
  };
}
