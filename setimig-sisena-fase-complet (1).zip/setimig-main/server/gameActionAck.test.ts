import { describe, it, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { createServer } from "node:http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket } from "socket.io-client";
import {
  getGameHostForTests,
  getRoomSnapshotForTests,
  resetGameStateForTests,
  setHostTimersPausedForTests,
  setupGameHandlers,
} from "./game.ts";
import { issuePlayerToken } from "./playerToken.ts";
import { resetPrivateRoomStoreCacheForTests } from "./privateRoomStore.ts";
import { beginBettingPhase, clearRoomTimers, currentPlayer, fillPrivateBots, type Player, type Room } from "../shared/gameEngine.ts";
import { resetTestDeckSeedWarningsForTests } from "../shared/shuffle.ts";
import { removeTestDataDir } from "./testing/testDataDir.ts";
import { actionReceiptIdFromPayload, buildGameActionAck, type GameActionAck } from "./gameActionAck.ts";

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";

const HOST_ID = "ackhitstandhost001";
const GUEST_ID = "ackhitstandguest01";
const SOLO_ID = "ackhitstandsolo0001";

describe("sobre de game_action_ack", () => {
  it("hit i stand comparteixen els camps de l'aposta, sense amount", () => {
    const bet = buildGameActionAck({ action: "place_bet", actionId: "id-1", roomId: "sala", amount: 100 });
    const hit = buildGameActionAck({ action: "hit", actionId: "id-1", roomId: "sala" });
    const stand = buildGameActionAck({ action: "stand", actionId: "id-1", roomId: "sala" });
    assert.deepEqual(bet, { action: "place_bet", actionId: "id-1", roomId: "sala", amount: 100 });
    assert.deepEqual(hit, { action: "hit", actionId: "id-1", roomId: "sala" });
    assert.deepEqual(stand, { action: "stand", actionId: "id-1", roomId: "sala" });
    assert.deepEqual(
      Object.keys(hit).sort(),
      Object.keys(bet).filter((key) => key !== "amount").sort(),
    );
    assert.deepEqual(Object.keys(stand).sort(), Object.keys(hit).sort());
    assert.deepEqual(buildGameActionAck({ action: "hit", roomId: "sala" }), { action: "hit", roomId: "sala" });
    assert.equal("amount" in hit, false);
  });

  it("l'id és actionId o, si no n'hi ha, requestId", () => {
    assert.equal(actionReceiptIdFromPayload({ actionId: "act", requestId: "req" }), "act");
    assert.equal(actionReceiptIdFromPayload({ requestId: "req-1" }), "req-1");
    assert.equal(actionReceiptIdFromPayload({ actionId: "  " }), undefined);
    assert.equal(actionReceiptIdFromPayload({ actionId: "x".repeat(129) }), undefined);
    assert.equal(actionReceiptIdFromPayload({}), undefined);
  });
});

function connect(url: string): Promise<Socket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.on("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.on("connect_error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

function waitJoined(socket: Socket): Promise<{ id: string; inviteCode?: string }> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("join timeout")), 15_000);
    socket.once("joined_room", (room: { id: string; inviteCode?: string }) => {
      clearTimeout(timer);
      resolve(room);
    });
  });
}

function whenRoom(roomId: string, sockets: Socket[], pred: (room: Room) => boolean): Promise<Room> {
  return new Promise((resolve) => {
    let settled = false;
    const tryFinish = () => {
      if (settled) return;
      const room = getRoomSnapshotForTests(roomId);
      if (!room || !pred(room)) return;
      settled = true;
      for (const socket of sockets) socket.off("room_update", tryFinish);
      resolve(room);
    };
    for (const socket of sockets) socket.on("room_update", tryFinish);
    tryFinish();
  });
}

function nextAck(socket: Socket, pred: (ack: GameActionAck) => boolean, label: string): Promise<GameActionAck> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      socket.off("game_action_ack", onAck);
      reject(new Error(`ack timeout: ${label}`));
    }, 8_000);
    const onAck = (ack: GameActionAck) => {
      if (!pred(ack)) return;
      clearTimeout(timer);
      socket.off("game_action_ack", onAck);
      resolve(ack);
    };
    socket.on("game_action_ack", onAck);
  });
}

function useHostFirstDeck(): () => void {
  const prev = process.env.SETIMIG_TEST_DECK_SEED;
  const shuffle = process.env.SETIMIG_TEST_SHUFFLE_SEED;
  process.env.SETIMIG_TEST_DECK_SEED = "4";
  delete process.env.SETIMIG_TEST_SHUFFLE_SEED;
  if (process.env.NODE_ENV === "production") process.env.NODE_ENV = "test";
  resetTestDeckSeedWarningsForTests();
  return () => {
    if (prev === undefined) delete process.env.SETIMIG_TEST_DECK_SEED;
    else process.env.SETIMIG_TEST_DECK_SEED = prev;
    if (shuffle === undefined) delete process.env.SETIMIG_TEST_SHUFFLE_SEED;
    else process.env.SETIMIG_TEST_SHUFFLE_SEED = shuffle;
    resetTestDeckSeedWarningsForTests();
  };
}

function rigSafeHand(room: Room, player: Player): void {
  const slot = player.handSlots[0];
  assert.ok(slot, "el torn té una mà");
  slot.cards = [{ id: "ack-c0", card: { suit: "hearts", value: 2, points: 2 }, faceUp: true }];
  slot.status = "playing";
  slot.mortOffered = false;
  slot.swapOffered = null;
  slot.blindPair = false;
  slot.mort = false;
  player.activeSlotIndex = 0;
  player.status = "playing";
  room.deck.push({ suit: "clubs", value: 1, points: 1 });
  room.actionHoldEndsAt = null;
  room.actionHoldThen = undefined;
  room.queuedActions = undefined;
}

describe("ack de hit i stand", () => {
  let dataDir: string;
  let restoreDeck: () => void;

  beforeEach(async () => {
    dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "setimig-ack-"));
    process.env.BALANCE_DATA_DIR = dataDir;
    process.env.SETIMIG_TEST_FAST = "1";
    restoreDeck = useHostFirstDeck();
    resetGameStateForTests();
    resetPrivateRoomStoreCacheForTests();
  });

  afterEach(async () => {
    setHostTimersPausedForTests(false);
    restoreDeck();
    delete process.env.SETIMIG_TEST_FAST;
    await removeTestDataDir(dataDir);
  });

  it("sala privada: hit i stand arriben amb el mateix format que l'aposta, també encuats", async () => {
    const hostToken = issuePlayerToken(HOST_ID)!;
    const guestToken = issuePlayerToken(GUEST_ID)!;
    const http = createServer();
    const io = new SocketIOServer(http, { cors: { origin: "*" } });
    await setupGameHandlers(io);
    await new Promise<void>((resolve) => http.listen(0, "127.0.0.1", resolve));
    const address = http.address();
    assert.ok(address && typeof address !== "string");
    const url = `http://127.0.0.1:${address.port}`;
    const host = await connect(url);
    const guest = await connect(url);
    setHostTimersPausedForTests(true);
    const guestAcks: GameActionAck[] = [];
    guest.on("game_action_ack", (ack: GameActionAck) => guestAcks.push(ack));

    try {
      const hostJoined = waitJoined(host);
      host.emit("create_private_table", {
        playerName: "Host",
        playerId: HOST_ID,
        playerToken: hostToken,
      });
      const created = await hostJoined;
      const guestJoined = waitJoined(guest);
      guest.emit("join_private_table", {
        inviteCode: created.inviteCode,
        playerName: "Guest",
        playerId: GUEST_ID,
        playerToken: guestToken,
      });
      await guestJoined;

      const seated = getRoomSnapshotForTests(created.id);
      assert.ok(seated);
      fillPrivateBots(seated, 3);
      const bankerReady = whenRoom(created.id, [host, guest], (room) => room.players.some((p) => p.isBanker));
      host.emit("start_game", { roomId: created.id, playerToken: hostToken, actionSeq: 1 });
      const drawn = await bankerReady;
      beginBettingPhase(getGameHostForTests(), drawn);
      clearRoomTimers(getGameHostForTests(), drawn);

      const betAckPromise = nextAck(host, (ack) => ack.action === "place_bet", "aposta");
      host.emit("place_bet", {
        roomId: created.id,
        amount: drawn.minBet,
        playerToken: hostToken,
        actionSeq: 2,
        actionId: "bet-ack-1",
      });
      const betAck = await betAckPromise;
      assert.deepEqual(betAck, {
        action: "place_bet",
        actionId: "bet-ack-1",
        roomId: created.id,
        amount: drawn.minBet,
      });

      const playingReady = whenRoom(created.id, [host, guest], (room) => room.phase === "playing");
      guest.emit("place_bet", {
        roomId: created.id,
        amount: drawn.minBet,
        playerToken: guestToken,
        actionSeq: 1,
      });
      const playing = await playingReady;
      clearRoomTimers(getGameHostForTests(), playing);
      const hostPlayer = playing.players.find((p) => p.playerId === HOST_ID);
      assert.ok(hostPlayer);
      assert.equal(currentPlayer(playing)?.playerId, HOST_ID);
      rigSafeHand(playing, hostPlayer);

      const hitAckPromise = nextAck(host, (ack) => ack.action === "hit" && ack.actionId === "hit-1", "hit");
      host.emit("hit", {
        roomId: created.id,
        playerToken: hostToken,
        actionSeq: 3,
        actionId: "hit-1",
      });
      const hitAck = await hitAckPromise;
      assert.deepEqual(hitAck, { action: "hit", actionId: "hit-1", roomId: created.id });
      assert.deepEqual(
        Object.keys(hitAck).sort(),
        Object.keys(betAck).filter((key) => key !== "amount").sort(),
      );
      assert.equal(hitAck.roomId, betAck.roomId);
      assert.equal(hostPlayer.handSlots[0]!.cards.length, 2);
      assert.equal(hostPlayer.handSlots[0]!.cards[1]!.card.points, 1);

      const retryPromise = nextAck(host, (ack) => ack.actionId === "hit-1", "reintent hit");
      host.emit("hit", {
        roomId: created.id,
        playerToken: hostToken,
        actionSeq: 4,
        actionId: "hit-1",
      });
      const retryAck = await retryPromise;
      assert.deepEqual(retryAck, hitAck);
      assert.equal(hostPlayer.handSlots[0]!.cards.length, 2, "el mateix actionId no demana una altra carta");

      playing.deck.push({ suit: "diamonds", value: 1, points: 1 });
      let strayAck = false;
      const onStray = (ack: GameActionAck) => {
        if (!ack.actionId) strayAck = true;
      };
      host.on("game_action_ack", onStray);
      host.emit("hit", created.id);
      const bareDeadline = Date.now() + 4_000;
      while (hostPlayer.handSlots[0]!.cards.length < 3) {
        assert.ok(Date.now() < bareDeadline, "el hit sense id no s'ha aplicat");
        await new Promise((r) => setTimeout(r, 15));
      }
      await new Promise((r) => setTimeout(r, 30));
      host.off("game_action_ack", onStray);
      assert.equal(strayAck, false, "sense id no hi ha ack, igual que l'aposta");
      assert.equal(hostPlayer.handSlots[0]!.cards.length, 3);

      playing.actionHoldEndsAt = Date.now() + 60_000;
      playing.actionHoldThen = "continue";
      const beforeQueue = hostPlayer.handSlots[0]!.cards.length;
      const standAckPromise = nextAck(host, (ack) => ack.action === "stand", "stand encuat");
      host.emit("stand", {
        roomId: created.id,
        playerToken: hostToken,
        actionSeq: 5,
        actionId: "stand-1",
      });
      const standAck = await standAckPromise;
      assert.deepEqual(standAck, { action: "stand", actionId: "stand-1", roomId: created.id });
      assert.equal(hostPlayer.handSlots[0]!.status, "playing", "el stand encuat encara no s'aplica");
      assert.equal(hostPlayer.handSlots[0]!.cards.length, beforeQueue);
      assert.equal(playing.queuedActions?.length, 1);
      assert.equal(playing.queuedActions?.[0]?.kind, "stand");
      assert.equal(currentPlayer(playing)?.playerId, HOST_ID);

      const standRetryPromise = nextAck(host, (ack) => ack.actionId === "stand-1", "reintent stand");
      host.emit("stand", {
        roomId: created.id,
        playerToken: hostToken,
        actionSeq: 6,
        actionId: "stand-1",
      });
      assert.deepEqual(await standRetryPromise, standAck);
      assert.equal(playing.queuedActions?.length, 1, "el reintent no torna a encuar");

      const requestAckPromise = nextAck(host, (ack) => ack.actionId === "req-hit-1", "requestId");
      host.emit("hit", {
        roomId: created.id,
        playerToken: hostToken,
        actionSeq: 7,
        requestId: "req-hit-1",
      });
      const requestAck = await requestAckPromise;
      assert.deepEqual(requestAck, { action: "hit", actionId: "req-hit-1", roomId: created.id });
      assert.equal(playing.queuedActions?.some((entry) => entry.kind === "hit"), true);

      playing.actionHoldThen = "nextTurn";
      playing.queuedActions = undefined;
      const ignoredPromise = nextAck(host, (ack) => ack.actionId === "ignored-hit", "ignorat");
      host.emit("hit", {
        roomId: created.id,
        playerToken: hostToken,
        actionSeq: 8,
        actionId: "ignored-hit",
      });
      assert.deepEqual(await ignoredPromise, { action: "hit", actionId: "ignored-hit", roomId: created.id });
      assert.equal(playing.queuedActions, undefined, "amb la mà tancada no s'encua, però hi ha ack");
      assert.equal(hostPlayer.handSlots[0]!.cards.length, beforeQueue);

      const turnErr = new Promise<{ code?: string; message?: string; actionId?: string }>((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("game_error timeout")), 8_000);
        guest.once("game_error", (err: { code?: string; message?: string; actionId?: string }) => {
          clearTimeout(timer);
          resolve(err);
        });
      });
      guest.emit("hit", {
        roomId: created.id,
        playerToken: guestToken,
        actionSeq: 2,
        actionId: "guest-hit",
      });
      const err = await turnErr;
      assert.equal(err.code, "BAD_TURN");
      assert.equal(err.actionId, "guest-hit");
      assert.equal(guestAcks.length, 0, "l'error no envia game_action_ack");
      assert.equal(currentPlayer(getRoomSnapshotForTests(created.id)!)?.playerId, HOST_ID);
    } finally {
      host.disconnect();
      guest.disconnect();
      io.close();
      await new Promise<void>((resolve) => http.close(() => resolve()));
      setHostTimersPausedForTests(false);
    }
  });

  it("socket del solo: hit i stand es confirmen igual que l'aposta", async () => {
    const http = createServer();
    const io = new SocketIOServer(http, { cors: { origin: "*" } });
    await setupGameHandlers(io);
    await new Promise<void>((resolve) => http.listen(0, "127.0.0.1", resolve));
    const address = http.address();
    assert.ok(address && typeof address !== "string");
    const url = `http://127.0.0.1:${address.port}`;
    const socket = await connect(url);
    let roomId = "";
    let betSent = false;

    try {
      const joined = waitJoined(socket);
      socket.emit("join_solo_room", {
        playerName: "Solo",
        playerId: SOLO_ID,
        botCount: 1,
        practiceMode: true,
        intent: "new",
      });
      const room = await joined;
      roomId = room.id;

      const betAckPromise = nextAck(socket, (ack) => ack.action === "place_bet", "aposta solo");
      const turn = await new Promise<Room>((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("el solo no arriba al torn humà")), 20_000);
        const look = () => {
          const snap = getRoomSnapshotForTests(roomId);
          const human = snap?.players.find((p) => !p.isBot && p.id === socket.id);
          if (!snap || !human) return;
          if (snap.phase === "betting" && !human.isBanker && human.bet === 0 && !betSent) {
            betSent = true;
            socket.emit("place_bet", { roomId, amount: snap.minBet, actionId: "solo-bet-1" });
          }
          const mine =
            (snap.phase === "playing" && currentPlayer(snap)?.id === human.id) ||
            (snap.phase === "banker" && human.isBanker);
          if (!mine) return;
          clearTimeout(timer);
          socket.off("room_update", look);
          setHostTimersPausedForTests(true);
          clearRoomTimers(getGameHostForTests(), snap);
          resolve(snap);
        };
        socket.on("room_update", look);
        socket.on("joined_room", look);
        look();
      });

      const betAck = await betAckPromise;
      assert.deepEqual(betAck, {
        action: "place_bet",
        actionId: "solo-bet-1",
        roomId,
        amount: betAck.amount,
      });
      assert.equal(typeof betAck.amount, "number");
      assert.ok((betAck.amount ?? 0) > 0);

      const human = turn.players.find((p) => p.id === socket.id);
      assert.ok(human);
      rigSafeHand(turn, human);
      const phase = turn.phase;

      const hitAckPromise = nextAck(socket, (ack) => ack.action === "hit", "hit solo");
      socket.emit("hit", { roomId, actionId: "solo-hit-1" });
      const hitAck = await hitAckPromise;
      assert.deepEqual(hitAck, { action: "hit", actionId: "solo-hit-1", roomId });
      assert.deepEqual(
        Object.keys(hitAck).sort(),
        Object.keys(betAck).filter((key) => key !== "amount").sort(),
      );

      turn.actionHoldEndsAt = Date.now() + 60_000;
      turn.actionHoldThen = "continue";
      const standAckPromise = nextAck(socket, (ack) => ack.action === "stand", "stand solo");
      socket.emit("stand", { roomId, actionId: "solo-stand-1" });
      const standAck = await standAckPromise;
      assert.deepEqual(standAck, { action: "stand", actionId: "solo-stand-1", roomId });
      assert.equal(human.handSlots[0]!.status, "playing");
      assert.equal(turn.queuedActions?.[0]?.kind, "stand");
      assert.equal(turn.phase, phase);

      const errors: { code?: string; actionId?: string }[] = [];
      socket.on("game_error", (err: { code?: string; actionId?: string }) => errors.push(err));
      socket.emit("hit", { roomId: "no-such-room", actionId: "missing" });
      await new Promise((r) => setTimeout(r, 30));
      assert.equal(errors.length, 0, "sala inexistent: ni ack ni error, com abans");
    } finally {
      socket.disconnect();
      io.close();
      await new Promise<void>((resolve) => http.close(() => resolve()));
      setHostTimersPausedForTests(false);
    }
  });
});
