import assert from "node:assert/strict";
import { after, before, beforeEach, describe, it } from "node:test";
import { createHash, generateKeyPairSync, randomBytes, sign as cryptoSign, type KeyObject } from "node:crypto";
import { mkdirSync, mkdtempSync, readFileSync, rmSync } from "node:fs";
import { createServer, type Server } from "node:http";
import type { AddressInfo } from "node:net";
import os from "node:os";
import path from "node:path";
import express from "express";

const dataDir = mkdtempSync(path.join(os.tmpdir(), "setimig-passkey-"));
process.env.BALANCE_DATA_DIR = dataDir;
process.env.PROFILE_DATA_DIR = path.join(dataDir, "profiles");
process.env.PUBLIC_BASE_URL = "https://sevenhalf.club";
process.env.WEBAUTHN_RP_ID = "sevenhalf.club";
process.env.WEBAUTHN_ORIGIN = "https://sevenhalf.club";

const { registerAuthRoutes } = await import("./authRoutes.ts");
const pk = await import("./passkeys.ts");
const { resetIdentityStoreForTests, identityStorePath, loginWithIdentity, getIdentitySummary } = await import("./identityStore.ts");
const { resetSignupNoticesForTests } = await import("../mail/signupNotice.ts");
const { issuePlayerToken, verifyPlayerToken } = await import("../playerToken.ts");

// --- Autenticador de programari mínim (ES256, attestation "none") ------------------------------

function cbor(v: unknown): Buffer {
  const head = (major: number, n: number): Buffer => {
    if (n < 24) return Buffer.from([(major << 5) | n]);
    if (n < 256) return Buffer.from([(major << 5) | 24, n]);
    if (n < 65536) return Buffer.from([(major << 5) | 25, n >> 8, n & 255]);
    const b = Buffer.alloc(5);
    b[0] = (major << 5) | 26;
    b.writeUInt32BE(n, 1);
    return b;
  };
  if (typeof v === "number") return v >= 0 ? head(0, v) : head(1, -1 - v);
  if (typeof v === "string") {
    const s = Buffer.from(v, "utf8");
    return Buffer.concat([head(3, s.length), s]);
  }
  if (Buffer.isBuffer(v) || v instanceof Uint8Array) return Buffer.concat([head(2, v.length), Buffer.from(v)]);
  if (v instanceof Map) {
    const parts = [head(5, v.size)];
    for (const [k, val] of v) parts.push(cbor(k), cbor(val));
    return Buffer.concat(parts);
  }
  throw new Error("cbor: tipus no suportat");
}

class SoftAuthenticator {
  readonly credId = randomBytes(16);
  private readonly key: KeyObject;
  private readonly pub: { x: string; y: string };
  counter = 0;
  userHandle: string | null = null;
  constructor(
    readonly rpId = "sevenhalf.club",
    readonly origin = "https://sevenhalf.club",
  ) {
    const { privateKey, publicKey } = generateKeyPairSync("ec", { namedCurve: "P-256" });
    this.key = privateKey;
    const j = publicKey.export({ format: "jwk" }) as { x: string; y: string };
    this.pub = { x: j.x, y: j.y };
  }
  get id(): string {
    return this.credId.toString("base64url");
  }
  private authData(withCred: boolean, flagsExtra = 0): Buffer {
    const rpHash = createHash("sha256").update(this.rpId).digest();
    const flags = 0x01 | 0x04 | flagsExtra | (withCred ? 0x40 : 0); // UP | UV | AT
    const cnt = Buffer.alloc(4);
    cnt.writeUInt32BE(this.counter);
    if (!withCred) return Buffer.concat([rpHash, Buffer.from([flags]), cnt]);
    const cose = cbor(
      new Map<number, unknown>([
        [1, 2],
        [3, -7],
        [-1, 1],
        [-2, Buffer.from(this.pub.x, "base64url")],
        [-3, Buffer.from(this.pub.y, "base64url")],
      ]),
    );
    const len = Buffer.alloc(2);
    len.writeUInt16BE(this.credId.length);
    return Buffer.concat([rpHash, Buffer.from([flags]), cnt, Buffer.alloc(16), len, this.credId, cose]);
  }
  create(options: { challenge: string; user: { id: string } }, opts: { uv?: boolean } = {}) {
    this.userHandle = options.user.id;
    const clientDataJSON = Buffer.from(JSON.stringify({ type: "webauthn.create", challenge: options.challenge, origin: this.origin, crossOrigin: false }));
    let ad = this.authData(true);
    if (opts.uv === false) ad[32] = ad[32]! & ~0x04;
    const attestationObject = cbor(new Map<string, unknown>([["fmt", "none"], ["attStmt", new Map()], ["authData", ad]]));
    return {
      id: this.id,
      rawId: this.id,
      type: "public-key",
      clientExtensionResults: {},
      response: {
        clientDataJSON: clientDataJSON.toString("base64url"),
        attestationObject: attestationObject.toString("base64url"),
        transports: ["internal", "hybrid"],
      },
    };
  }
  get(options: { challenge: string }, opts: { counter?: number; origin?: string } = {}) {
    if (opts.counter !== undefined) this.counter = opts.counter;
    else this.counter += 1;
    const clientDataJSON = Buffer.from(
      JSON.stringify({ type: "webauthn.get", challenge: options.challenge, origin: opts.origin ?? this.origin, crossOrigin: false }),
    );
    const ad = this.authData(false);
    const sig = cryptoSign("sha256", Buffer.concat([ad, createHash("sha256").update(clientDataJSON).digest()]), this.key);
    return {
      id: this.id,
      rawId: this.id,
      type: "public-key",
      clientExtensionResults: {},
      response: {
        clientDataJSON: clientDataJSON.toString("base64url"),
        authenticatorData: ad.toString("base64url"),
        signature: sig.toString("base64url"),
        userHandle: this.userHandle,
      },
    };
  }
}

// --- Servidor de prova ----------------------------------------------------------------------------

let server: Server;
let base = "";
before(async () => {
  const app = express();
  app.use(express.json({ limit: "100kb" }));
  registerAuthRoutes(app);
  pk.registerPasskeyRoutes(app);
  server = createServer(app);
  await new Promise<void>((r) => server.listen(0, "127.0.0.1", r));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});
after(() => server.close());

const origLog = console.log;
const origWarn = console.warn;
beforeEach(() => {
  rmSync(dataDir, { recursive: true, force: true });
  mkdirSync(dataDir, { recursive: true });
  resetIdentityStoreForTests();
  resetSignupNoticesForTests();
  pk.resetPasskeysForTests();
  console.log = () => {};
  console.warn = () => {};
});
after(() => {
  console.log = origLog;
  console.warn = origWarn;
});

async function call(method: string, p: string, body?: unknown, token?: string) {
  const res = await fetch(base + p, {
    method,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    ...(body !== undefined ? { body: JSON.stringify(body) } : {}),
  });
  return { status: res.status, body: (await res.json()) as Record<string, any> };
}

const P = "a1".repeat(24);
const Q = "b2".repeat(24);

async function register(auth: SoftAuthenticator, playerId = P, name = "iPhone de la Marta") {
  const token = issuePlayerToken(playerId)!;
  const o = await call("POST", "/api/auth/passkey/register/options", {}, token);
  assert.equal(o.status, 200);
  return call("POST", "/api/auth/passkey/register/verify", { response: auth.create(o.body as never), name }, token);
}

async function login(auth: SoftAuthenticator, opts: { counter?: number; origin?: string } = {}, token?: string) {
  const o = await call("POST", "/api/auth/passkey/login/options", {});
  assert.equal(o.status, 200);
  return call("POST", "/api/auth/passkey/login/verify", { challengeId: o.body.challengeId, response: auth.get(o.body.options, opts) }, token);
}

describe("passkeys WebAuthn", () => {
  it("providers: passkey actiu amb rpId sevenhalf.club", async () => {
    const p = await (await fetch(base + "/api/auth/providers")).json();
    assert.equal(p.passkey, true);
    assert.equal(p.rpId, "sevenhalf.club");
  });

  it("opcions de registre: rp, usuari opac (mai el playerId), resident key i UV obligatoris", async () => {
    const o = await call("POST", "/api/auth/passkey/register/options", {}, issuePlayerToken(P)!);
    assert.equal(o.body.rp.id, "sevenhalf.club");
    assert.equal(o.body.rp.name, "Seven Half Club");
    assert.notEqual(Buffer.from(o.body.user.id, "base64url").toString("utf8"), P);
    assert.equal(o.body.authenticatorSelection.residentKey, "required");
    assert.equal(o.body.authenticatorSelection.userVerification, "required");
    assert.equal(o.body.attestation, "none");
  });

  it("cal una sessió amb token per registrar, llistar i esborrar", async () => {
    assert.equal((await call("POST", "/api/auth/passkey/register/options", {})).status, 401);
    assert.equal((await call("POST", "/api/auth/passkey/register/options", { playerId: P })).status, 401, "l'id llegat no basta");
    assert.equal((await call("GET", "/api/auth/passkeys")).status, 401);
  });

  it("registre + entrada amb un toc al mateix compte (mateix tipus de token)", async () => {
    const a = new SoftAuthenticator();
    const r = await register(a);
    assert.equal(r.status, 200);
    assert.equal(r.body.passkey.id, a.id);
    assert.equal(r.body.passkey.name, "iPhone de la Marta");
    const l = await login(a);
    assert.equal(l.status, 200);
    assert.equal(l.body.playerId, P);
    assert.equal(l.body.method, "passkey");
    assert.equal(l.body.created, false);
    assert.equal(verifyPlayerToken(l.body.playerToken)?.playerId, P);
    const disk = JSON.parse(readFileSync(identityStorePath(), "utf8"));
    assert.equal(disk.passkeys[a.id].counter, 1);
    assert.ok(disk.passkeys[a.id].lastUsedAt);
    assert.equal(disk.passkeys[a.id].playerId, P);
  });

  it("entrar amb passkey des d'un navegador amb un altre compte: switchedAccount, sense fusionar", async () => {
    const a = new SoftAuthenticator();
    await register(a);
    const l = await login(a, {}, issuePlayerToken(Q)!);
    assert.equal(l.body.playerId, P);
    assert.equal(l.body.switchedAccount, true);
  });

  it("repte d'un sol ús: reutilitzar el challengeId falla", async () => {
    const a = new SoftAuthenticator();
    await register(a);
    const o = await call("POST", "/api/auth/passkey/login/options", {});
    const resp = a.get(o.body.options);
    assert.equal((await call("POST", "/api/auth/passkey/login/verify", { challengeId: o.body.challengeId, response: resp })).status, 200);
    const again = await call("POST", "/api/auth/passkey/login/verify", { challengeId: o.body.challengeId, response: resp });
    assert.equal(again.status, 400);
    assert.equal(again.body.code, "NO_CHALLENGE");
  });

  it("comptador que no avança (possible clon) → rebutjat", async () => {
    const a = new SoftAuthenticator();
    await register(a);
    assert.equal((await login(a, { counter: 5 })).status, 200);
    const l = await login(a, { counter: 5 });
    assert.equal(l.status, 400);
    assert.equal(l.body.code, "VERIFICATION_FAILED");
  });

  it("origen diferent → rebutjat", async () => {
    const a = new SoftAuthenticator();
    await register(a);
    const l = await login(a, { origin: "https://evil.example" });
    assert.equal(l.status, 400);
  });

  it("credencial desconeguda → 404 UNKNOWN_CREDENTIAL (no crea cap compte)", async () => {
    const l = await login(new SoftAuthenticator());
    assert.equal(l.status, 404);
    assert.equal(l.body.code, "UNKNOWN_CREDENTIAL");
  });

  it("registre sense verificació d'usuari (UV) → rebutjat", async () => {
    const a = new SoftAuthenticator();
    const token = issuePlayerToken(P)!;
    const o = await call("POST", "/api/auth/passkey/register/options", {}, token);
    const r = await call("POST", "/api/auth/passkey/register/verify", { response: a.create(o.body as never, { uv: false }) }, token);
    assert.equal(r.status, 400);
  });

  it("la mateixa credencial no es pot registrar dues vegades", async () => {
    const a = new SoftAuthenticator();
    assert.equal((await register(a)).status, 200);
    const r = await register(a, Q);
    assert.equal(r.status, 409);
    assert.equal(r.body.code, "ALREADY_REGISTERED");
  });

  it("llistar i esborrar (només les pròpies)", async () => {
    const a = new SoftAuthenticator();
    await register(a);
    const list = await call("GET", "/api/auth/passkeys", undefined, issuePlayerToken(P)!);
    assert.equal(list.body.passkeys.length, 1);
    assert.equal((await call("DELETE", `/api/auth/passkeys/${a.id}`, undefined, issuePlayerToken(Q)!)).status, 404);
    assert.equal((await call("DELETE", `/api/auth/passkeys/${a.id}`, undefined, issuePlayerToken(P)!)).status, 200);
    assert.equal((await login(a)).status, 404);
    const me = await call("GET", "/api/auth/me", undefined, issuePlayerToken(P)!);
    assert.equal(me.body.passkeys, 0);
  });

  it("un compte anònim amb passkey encara pot enllaçar el seu correu després", async () => {
    await register(new SoftAuthenticator());
    const r = await loginWithIdentity({ kind: "email", email: "p@x.cat", current: { playerId: P, legacy: false }, allowCreate: false });
    assert.ok(r.ok && r.playerId === P && r.linked);
    assert.deepEqual(await getIdentitySummary(P), { emails: ["p@x.cat"], google: false, passkeys: 1 });
  });
});
