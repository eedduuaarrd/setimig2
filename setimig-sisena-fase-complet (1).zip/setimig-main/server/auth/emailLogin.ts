import { randomBytes, randomInt, timingSafeEqual } from "node:crypto";
import { signWithPlayerSecret } from "../playerToken.ts";
import { hasMailTestTransport, mailCanDeliver, mailFrom, sendMail } from "../mail/mailer.ts";
import { BREVO_TRACKING_OFF_HEADERS, sendBrevoLoginCode } from "../mail/brevoClient.ts";
import { renderLoginCodeMail } from "../mail/loginCodeTemplate.ts";
import { normalizeEmail, type CurrentPlayer } from "./identityStore.ts";
import { FixedWindowLimiter, publicBaseUrl } from "./authCommon.ts";

/**
 * Inici de sessió per correu: codi de 6 xifres (i enllaç màgic, desactivat per defecte al correu).
 *
 * - Caducitat: 10 minuts. Un sol ús: el repte es consumeix amb el primer codi/enllaç correcte.
 * - Només es desen hashos (HMAC amb PLAYER_TOKEN_SECRET i propòsit propi), mai el codi ni l'enllaç.
 * - Un repte nou per al mateix correu invalida l'anterior.
 * - 5 codis erronis invaliden el repte.
 * - Límits: 3 enviaments per correu i 10 per IP cada 15 min; 20 verificacions fallides per IP cada 15 min.
 * - Resposta constant a `start` (no revela si el correu té compte). Si el límit per correu
 *   s'ha superat, la resposta és la mateixa però no s'envia res.
 * - L'enllaç porta el secret al fragment (#): no arriba al servidor ni als logs. El client el
 *   bescanvia amb POST (els escàners de correu no el consumeixen).
 */
export const EMAIL_CHALLENGE_TTL_MS = 10 * 60 * 1000;
export const MAX_CODE_ATTEMPTS = 5;
export const START_PER_EMAIL = 3;
export const START_PER_IP = 10;
export const VERIFY_FAILS_PER_IP = 20;
export const LIMIT_WINDOW_MS = 15 * 60 * 1000;
const PURPOSE_CODE = "setimig-email-code-v1";
const PURPOSE_LINK = "setimig-email-link-v1";
const MAX_PENDING = 20_000;

type Challenge = {
  id: string;
  email: string;
  codeHash: Buffer;
  linkHash: Buffer;
  exp: number;
  attempts: number;
  ageConfirmed: boolean;
  /** Compte (amb token) del navegador que l'ha demanat; només s'usa si el que verifica no en té. */
  startPlayer: CurrentPlayer;
};

const challenges = new Map<string, Challenge>();
const byEmail = new Map<string, string>();
const startEmailLimiter = new FixedWindowLimiter(START_PER_EMAIL, LIMIT_WINDOW_MS);
const startIpLimiter = new FixedWindowLimiter(START_PER_IP, LIMIT_WINDOW_MS);
const verifyFailLimiter = new FixedWindowLimiter(VERIFY_FAILS_PER_IP, LIMIT_WINDOW_MS);

export function emailLoginAvailable(): boolean {
  return mailCanDeliver() || hasMailTestTransport();
}

function prune(now: number): void {
  for (const [id, c] of challenges) {
    if (c.exp <= now) {
      challenges.delete(id);
      if (byEmail.get(c.email) === id) byEmail.delete(c.email);
    }
  }
}

function drop(c: Challenge): void {
  challenges.delete(c.id);
  if (byEmail.get(c.email) === c.id) byEmail.delete(c.email);
}

function hashCode(id: string, code: string): Buffer {
  return signWithPlayerSecret(PURPOSE_CODE, `${id}:${code}`);
}

function hashLink(id: string, secret: string): Buffer {
  return signWithPlayerSecret(PURPOSE_LINK, `${id}:${secret}`);
}

function same(a: Buffer, b: Buffer): boolean {
  return a.length === b.length && timingSafeEqual(a, b);
}

export type StartResult =
  | { ok: true }
  | { ok: false; error: "BAD_EMAIL" | "RATE_LIMIT" | "UNAVAILABLE"; retryAfterSec?: number };

export function magicLinkUrl(linkToken: string): string {
  return `${publicBaseUrl()}/login/correu#t=${encodeURIComponent(linkToken)}`;
}

/** Pantalla d'entrada del codi, SENSE cap token: obrir-la no inicia sessió. */
export function loginPageUrl(): string {
  return `${publicBaseUrl()}/login/correu`;
}

/**
 * Enllaç màgic amb token dins del correu: DESACTIVAT per defecte.
 * Brevo (smtp-relay.brevo.com) reescriu tots els enllaços de la part HTML cap al seu rastrejador
 * (sendibt2.com) i hi afegeix un píxel; les capçaleres X-Mailin-Track* no ho eviten (prova real
 * del 27/10/2026) i al compte només es pot anonimitzar. Per això el correu és només text pla, porta
 * el codi i, com a molt, l'enllaç a la pantalla de login sense token. MAIL_LOGIN_MAGIC_LINK=1 el
 * torna a posar (al text pla) si algun dia el proveïdor no fa seguiment.
 */
export function magicLinkInMail(env: NodeJS.ProcessEnv | Record<string, string | undefined> = process.env): boolean {
  return (env.MAIL_LOGIN_MAGIC_LINK ?? "").trim() === "1";
}

export const MAIL_LOCALES = ["ca", "en", "es", "it", "pt-BR"] as const;
export type MailLocale = (typeof MAIL_LOCALES)[number];
export const DEFAULT_MAIL_LOCALE: MailLocale = "en";

/** Normalitza un codi d'idioma ("pt", "pt-PT", "EN-us", "ca_ES"...) a un dels 5 de l'app, o null. */
export function normalizeMailLocale(raw: unknown): MailLocale | null {
  if (typeof raw !== "string") return null;
  const tag = raw.trim().replace(/_/g, "-").toLowerCase();
  if (!tag || tag.length > 35 || !/^[a-z]{2,3}(-[a-z0-9]{1,8})*$/.test(tag)) return null;
  const primary = tag.split("-")[0]!;
  if (primary === "pt") return "pt-BR";
  return (MAIL_LOCALES as readonly string[]).includes(primary) ? (primary as MailLocale) : null;
}

/** Primer idioma suportat d'una capçalera Accept-Language, per ordre de q. */
export function localeFromAcceptLanguage(header: unknown): MailLocale | null {
  if (typeof header !== "string" || !header) return null;
  const items = header
    .slice(0, 500)
    .split(",")
    .map((part, i) => {
      const [tag, ...params] = part.trim().split(";");
      const qParam = params.map((p) => p.trim()).find((p) => p.startsWith("q="));
      const q = qParam ? Number(qParam.slice(2)) : 1;
      return { tag: (tag ?? "").trim(), q: Number.isFinite(q) ? q : 0, i };
    })
    .filter((x) => x.tag && x.tag !== "*" && x.q > 0)
    .sort((a, b) => b.q - a.q || a.i - b.i);
  for (const it of items) {
    const l = normalizeMailLocale(it.tag);
    if (l) return l;
  }
  return null;
}

/** Ordre: `locale` (o `lang`) vàlid del cos → Accept-Language → anglès. */
export function resolveMailLocale(bodyLocale: unknown, acceptLanguage: unknown): MailLocale {
  return normalizeMailLocale(bodyLocale) ?? localeFromAcceptLanguage(acceptLanguage) ?? DEFAULT_MAIL_LOCALE;
}

type LoginMailTexts = {
  subject: (code: string) => string;
  intro: (code: string) => string;
  page: string;
  magic: string;
  expiry: string;
  ignore: string;
};

const LOGIN_MAIL: Record<MailLocale, LoginMailTexts> = {
  ca: {
    subject: (c) => `${c} és el teu codi de Seven Half Club`,
    intro: (c) => `El teu codi per entrar a Seven Half Club: ${c}`,
    page: "Escriu-lo a la pantalla d'inici de sessió:",
    magic: "O obre aquest enllaç en aquest dispositiu:",
    expiry: "Caduca d'aquí a 10 minuts i només es pot fer servir un cop.",
    ignore: "Si no l'has demanat tu, ignora aquest correu.",
  },
  en: {
    subject: (c) => `${c} is your Seven Half Club code`,
    intro: (c) => `Your Seven Half Club sign-in code: ${c}`,
    page: "Enter it on the sign-in screen:",
    magic: "Or open this link on this device:",
    expiry: "It expires in 10 minutes and can only be used once.",
    ignore: "If you didn't request it, ignore this email.",
  },
  es: {
    subject: (c) => `${c} es tu código de Seven Half Club`,
    intro: (c) => `Tu código para entrar en Seven Half Club: ${c}`,
    page: "Escríbelo en la pantalla de inicio de sesión:",
    magic: "O abre este enlace en este dispositivo:",
    expiry: "Caduca en 10 minutos y solo se puede usar una vez.",
    ignore: "Si no lo has pedido tú, ignora este correo.",
  },
  it: {
    subject: (c) => `${c} è il tuo codice di Seven Half Club`,
    intro: (c) => `Il tuo codice per accedere a Seven Half Club: ${c}`,
    page: "Inseriscilo nella schermata di accesso:",
    magic: "Oppure apri questo link su questo dispositivo:",
    expiry: "Scade tra 10 minuti e si può usare una sola volta.",
    ignore: "Se non l'hai richiesto tu, ignora questa email.",
  },
  "pt-BR": {
    subject: (c) => `${c} é o seu código do Seven Half Club`,
    intro: (c) => `Seu código para entrar no Seven Half Club: ${c}`,
    page: "Digite-o na tela de login:",
    magic: "Ou abra este link neste dispositivo:",
    expiry: "Ele expira em 10 minutos e só pode ser usado uma vez.",
    ignore: "Se você não pediu, ignore este e-mail.",
  },
};

/**
 * Correu del codi, sencer en un sol idioma: HTML amb la marca del login i alternativa en text pla.
 * L'HTML no porta imatges ni `<a href>` (Brevo reescriu els enllaços). El codi va també a l'assumpte.
 */
export function buildLoginMail(
  code: string,
  locale: MailLocale,
  magicLink: string | null,
): { subject: string; text: string; html: string } {
  const t = LOGIN_MAIL[locale] ?? LOGIN_MAIL[DEFAULT_MAIL_LOCALE];
  return renderLoginCodeMail({
    locale,
    code,
    subject: t.subject(code),
    intro: t.intro(code),
    pageLine: t.page,
    loginUrl: loginPageUrl(),
    expiry: t.expiry,
    ignore: t.ignore,
    magicLine: magicLink ? t.magic : null,
    magicUrl: magicLink,
  });
}

export function startEmailLogin(input: {
  email: unknown;
  ip: string;
  ageConfirmed: boolean;
  startPlayer: CurrentPlayer;
  /** Idioma del correu (ja resolt amb resolveMailLocale). Per defecte, anglès. */
  locale?: MailLocale;
  now?: number;
}): StartResult {
  const now = input.now ?? Date.now();
  if (!emailLoginAvailable()) return { ok: false, error: "UNAVAILABLE" };
  const email = normalizeEmail(input.email);
  if (!email) return { ok: false, error: "BAD_EMAIL" };
  if (!startIpLimiter.hit(input.ip, now)) return { ok: false, error: "RATE_LIMIT" };
  // Límit per correu: 429 clar amb retryAfter (abans era un 202 que no enviava res). No revela si el
  // correu té compte: el límit s'aplica igual a tots els correus.
  if (!startEmailLimiter.hit(email, now)) {
    const retryAfterSec = Math.max(1, Math.ceil(startEmailLimiter.retryAfterMs(email, now) / 1000));
    return { ok: false, error: "RATE_LIMIT", retryAfterSec };
  }
  prune(now);
  if (challenges.size >= MAX_PENDING) return { ok: false, error: "RATE_LIMIT" };

  const prev = byEmail.get(email);
  if (prev) challenges.delete(prev);
  const id = randomBytes(12).toString("base64url");
  const code = String(randomInt(0, 1_000_000)).padStart(6, "0");
  const secret = randomBytes(24).toString("base64url");
  challenges.set(id, {
    id,
    email,
    codeHash: hashCode(id, code),
    linkHash: hashLink(id, secret),
    exp: now + EMAIL_CHALLENGE_TTL_MS,
    attempts: 0,
    ageConfirmed: input.ageConfirmed,
    startPlayer: input.startPlayer && !input.startPlayer.legacy ? input.startPlayer : null,
  });
  byEmail.set(email, id);
  const mail = buildLoginMail(
    code,
    input.locale ?? DEFAULT_MAIL_LOCALE,
    magicLinkInMail() ? magicLinkUrl(`${id}.${secret}`) : null,
  );
  // Sense esperar l'enviament: la resposta triga el mateix tant si el correu té compte com si no.
  const brevoKey = (process.env.BREVO_API_KEY ?? "").trim();
  if (brevoKey && !hasMailTestTransport()) {
    const from = mailFrom();
    void sendBrevoLoginCode(
      { to: email, subject: mail.subject, text: mail.text, html: mail.html, from: { email: from.address, name: from.name } },
      { apiKey: brevoKey }
    ).catch(() => undefined);
  } else {
    void sendMail({
      to: email,
      kind: "login_code",
      subject: mail.subject,
      text: mail.text,
      html: mail.html,
      headers: BREVO_TRACKING_OFF_HEADERS,
    }).catch(() => undefined);
  }
  return { ok: true };
}

export type VerifyError = "BAD_REQUEST" | "INVALID_CODE" | "EXPIRED_OR_USED" | "RATE_LIMIT";

export type VerifyResult =
  | { ok: true; email: string; ageConfirmed: boolean; startPlayer: CurrentPlayer; challengeId: string }
  | { ok: false; error: VerifyError };

/** Consumeix un repte ja validat amb consume:false. Retorna false si ja no hi era. */
export function consumeEmailChallenge(id: string): boolean {
  const c = challenges.get(id);
  if (!c) return false;
  drop(c);
  return true;
}

/**
 * Valida i CONSUMEIX el repte (codi o enllaç). Síncron: no hi pot haver dues verificacions alhora.
 * Amb consume:false el valida igual (errors, caducitat i límit d'intents idèntics) però el deixa viu:
 * la ruta el consumeix després amb consumeEmailChallenge si no cal confirmar l'edat.
 */
export function verifyEmailLogin(input: {
  email?: unknown;
  code?: unknown;
  linkToken?: unknown;
  ip: string;
  consume?: boolean;
  now?: number;
}): VerifyResult {
  const now = input.now ?? Date.now();
  const consume = input.consume !== false;
  if (verifyFailLimiter.blocked(input.ip, now)) return { ok: false, error: "RATE_LIMIT" };
  const fail = (error: VerifyError): VerifyResult => {
    verifyFailLimiter.hit(input.ip, now);
    return { ok: false, error };
  };

  if (typeof input.linkToken === "string" && input.linkToken) {
    const tok = input.linkToken.trim();
    if (tok.length > 200) return fail("BAD_REQUEST");
    const dot = tok.indexOf(".");
    if (dot <= 0) return fail("BAD_REQUEST");
    const id = tok.slice(0, dot);
    const secret = tok.slice(dot + 1);
    const c = challenges.get(id);
    if (!c) return fail("EXPIRED_OR_USED");
    if (c.exp <= now) {
      drop(c);
      return fail("EXPIRED_OR_USED");
    }
    if (!same(hashLink(id, secret), c.linkHash)) return fail("INVALID_CODE");
    if (consume) drop(c);
    return { ok: true, email: c.email, ageConfirmed: c.ageConfirmed, startPlayer: c.startPlayer, challengeId: c.id };
  }

  const email = normalizeEmail(input.email);
  const code = typeof input.code === "string" ? input.code.replace(/\s+/g, "") : "";
  if (!email || !/^\d{6}$/.test(code)) return fail("BAD_REQUEST");
  const id = byEmail.get(email);
  const c = id ? challenges.get(id) : undefined;
  if (!c) return fail("EXPIRED_OR_USED");
  if (c.exp <= now) {
    drop(c);
    return fail("EXPIRED_OR_USED");
  }
  if (!same(hashCode(c.id, code), c.codeHash)) {
    c.attempts += 1;
    if (c.attempts >= MAX_CODE_ATTEMPTS) drop(c);
    return fail("INVALID_CODE");
  }
  if (consume) drop(c);
  return { ok: true, email: c.email, ageConfirmed: c.ageConfirmed, startPlayer: c.startPlayer, challengeId: c.id };
}

export function resetEmailLoginForTests(): void {
  challenges.clear();
  byEmail.clear();
  startEmailLimiter.reset();
  startIpLimiter.reset();
  verifyFailLimiter.reset();
}

export function pendingEmailChallengesForTests(): number {
  return challenges.size;
}
