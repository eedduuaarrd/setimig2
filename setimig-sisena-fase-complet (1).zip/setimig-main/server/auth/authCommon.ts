import type { Request, Response } from "express";
import { isAllowedOrigin, normalizeOrigin, PRIMARY_ORIGIN } from "../allowedOrigins.ts";
import { clientKey } from "../httpRateLimit.ts";
import { resolvePlayerFromRequest } from "../httpPlayerAuth.ts";
import { issuePlayerToken, readTokenFromAuthHeader, verifyPlayerToken } from "../playerToken.ts";
import type { CurrentPlayer } from "./identityStore.ts";

type Env = NodeJS.ProcessEnv | Record<string, string | undefined>;

/** Origen públic de l'app (enllaços dels correus, redirecció de Google). */
export function publicBaseUrl(env: Env = process.env): string {
  return normalizeOrigin(env.PUBLIC_BASE_URL) ?? PRIMARY_ORIGIN;
}

export function originAllowed(req: Request): boolean {
  return isAllowedOrigin(req.headers.origin, req.headers.host);
}

export function rateKey(req: Request): string {
  return clientKey(req) ?? "local";
}

/** Finestra fixa simple per a límits d'autenticació. */
export class FixedWindowLimiter {
  private buckets = new Map<string, { start: number; n: number }>();
  constructor(
    readonly limit: number,
    readonly windowMs: number,
  ) {}
  /** Compta un intent i diu si encara és dins el límit. */
  hit(key: string, now = Date.now()): boolean {
    let b = this.buckets.get(key);
    if (!b || now - b.start >= this.windowMs) {
      b = { start: now, n: 0 };
      this.buckets.set(key, b);
      if (this.buckets.size > 50_000) {
        for (const [k, v] of this.buckets) if (now - v.start >= this.windowMs) this.buckets.delete(k);
      }
    }
    b.n += 1;
    return b.n <= this.limit;
  }
  /** Està bloquejat (sense comptar cap intent nou)? */
  blocked(key: string, now = Date.now()): boolean {
    const b = this.buckets.get(key);
    return !!b && now - b.start < this.windowMs && b.n >= this.limit;
  }
  /** Mil·lisegons fins que s'obre la finestra següent (0 si no hi ha cap finestra activa). */
  retryAfterMs(key: string, now = Date.now()): number {
    const b = this.buckets.get(key);
    if (!b) return 0;
    return Math.max(0, b.start + this.windowMs - now);
  }
  reset(): void {
    this.buckets.clear();
  }
}

/**
 * Jugador actual del navegador (per enllaçar-hi una identitat nova). Accepta el token de sempre o,
 * per als perfils antics sense token, l'id llegat (`playerId` al cos).
 */
export function currentPlayer(req: Request): CurrentPlayer {
  const r = resolvePlayerFromRequest(req);
  return r ? { playerId: r.playerId, legacy: r.legacy } : null;
}

/** Jugador amb token vàlid (obligatori per gestionar passkeys i veure identitats). */
export function tokenPlayer(req: Request): string | null {
  const token = readTokenFromAuthHeader(req.headers.authorization);
  const v = token ? verifyPlayerToken(token) : null;
  return v?.playerId ?? null;
}

export type AuthSuccess = {
  playerId: string;
  playerToken: string;
  method: "email" | "google" | "passkey";
  created: boolean;
  linked: boolean;
  /** El navegador tenia un altre compte; no s'ha fusionat (el client hauria d'avisar). */
  switchedAccount: boolean;
};

export function buildAuthSuccess(
  playerId: string,
  method: AuthSuccess["method"],
  flags: { created?: boolean; linked?: boolean; switchedFrom?: string },
): AuthSuccess | null {
  const playerToken = issuePlayerToken(playerId);
  if (!playerToken) return null;
  return {
    playerId,
    playerToken,
    method,
    created: !!flags.created,
    linked: !!flags.linked,
    switchedAccount: !!flags.switchedFrom,
  };
}

export function sendAuthError(res: Response, status: number, code: string, error: string, retryAfterSec?: number): void {
  if (retryAfterSec) res.setHeader("Retry-After", String(retryAfterSec));
  res.status(status).json(retryAfterSec ? { error, code, retryAfter: retryAfterSec } : { error, code });
}

export function bool(v: unknown): boolean {
  return v === true || v === "true" || v === "1" || v === 1;
}
