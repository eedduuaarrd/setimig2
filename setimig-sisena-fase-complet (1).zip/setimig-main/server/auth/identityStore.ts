import { randomBytes } from "node:crypto";
import fs from "fs/promises";
import path from "path";
import { sanitizePlayerId } from "../balances.ts";
import { isAccountDeleted } from "../deletedAccounts.ts";
import { writeJsonAtomic } from "../writeCoalescing.ts";
import { registerAccountIdSource, type SignupMethod } from "../mail/signupNotice.ts";

/**
 * Identitats verificades → compte existent (playerId).
 *
 * data/identities.json (escriptura atòmica tmp+rename, serialitzada):
 * - `emails`:   correu verificat (minúscules) → playerId. Mateix correu = mateix compte.
 * - `google`:   `sub` de Google → playerId.
 * - `passkeys`: id de credencial WebAuthn (base64url) → passkey (clau pública, comptador…).
 * - `players`:  playerId → metadades (via de creació, correus, Google, id d'usuari WebAuthn).
 * - `log`:      darrers casos especials (canvi de compte, enllaç d'un compte anònim…), sense correus.
 *
 * No toca mai balances.json ni els perfils: un compte és el playerId de sempre, i el login només
 * emet el mateix token signat (PLAYER_TOKEN_SECRET) que ja fa servir l'app.
 *
 * Regles d'enllaç (`loginWithIdentity`):
 * 1. Si la identitat (o el correu verificat) ja té compte → s'entra en AQUEST compte. Si el
 *    navegador tenia un altre compte, NO es fusionen: es registra el canvi (`switch`).
 * 2. Si és nova i el navegador té un compte sense cap identitat verificada (anònim) → s'enllaça a
 *    aquest compte (mateix playerId, mateix saldo).
 * 3. Si és nova i no hi ha compte anònim enllaçable → compte nou (només amb confirmació 18+).
 */

export type IdentityKind = "email" | "google" | "passkey";

export type StoredPasskey = {
  playerId: string;
  /** Clau pública COSE en base64url. */
  publicKey: string;
  counter: number;
  transports?: string[];
  deviceType?: string;
  backedUp?: boolean;
  name: string;
  createdAt: number;
  lastUsedAt?: number;
};

export type IdentityPlayer = {
  createdVia?: SignupMethod;
  createdAt?: number;
  linkedAt?: number;
  emails?: string[];
  googleSub?: string;
  /** user.id de WebAuthn (aleatori, opac; mai el playerId). */
  webauthnUserId?: string;
};

export type AuthLogEntry = {
  at: number;
  type: "link" | "create" | "switch" | "google_linked_by_email" | "passkey_added" | "passkey_removed";
  kind: IdentityKind;
  playerId: string;
  /** Compte que tenia el navegador (quan és diferent): mai es fusiona. */
  fromPlayerId?: string;
  legacy?: boolean;
};

type Store = {
  version: 1;
  emails: Record<string, string>;
  google: Record<string, string>;
  passkeys: Record<string, StoredPasskey>;
  players: Record<string, IdentityPlayer>;
  log: AuthLogEntry[];
};

const LOG_CAP = 1000;

function dataDir(): string {
  return process.env.BALANCE_DATA_DIR || path.join(process.cwd(), "data");
}

export function identityStorePath(): string {
  return path.join(dataDir(), "identities.json");
}

function emptyStore(): Store {
  return { version: 1, emails: {}, google: {}, passkeys: {}, players: {}, log: [] };
}

let cache: Store | null = null;
let chain: Promise<unknown> = Promise.resolve();
let sourceRegistered = false;

function obj<T>(v: unknown): Record<string, T> {
  return v && typeof v === "object" && !Array.isArray(v) ? (v as Record<string, T>) : {};
}

async function load(): Promise<Store> {
  if (!sourceRegistered) {
    sourceRegistered = true;
    registerAccountIdSource(async () => Object.keys((await load()).players));
  }
  if (cache) return cache;
  let raw: string;
  try {
    raw = await fs.readFile(identityStorePath(), "utf8");
  } catch (err) {
    if ((err as NodeJS.ErrnoException)?.code === "ENOENT") {
      cache = emptyStore();
      return cache;
    }
    throw err;
  }
  // Fitxer malmès: error (no s'inicia cap login) i NO es reescriu mai.
  const parsed = JSON.parse(raw) as Partial<Store>;
  cache = {
    version: 1,
    emails: obj<string>(parsed.emails),
    google: obj<string>(parsed.google),
    passkeys: obj<StoredPasskey>(parsed.passkeys),
    players: obj<IdentityPlayer>(parsed.players),
    log: Array.isArray(parsed.log) ? parsed.log : [],
  };
  return cache;
}

async function save(store: Store): Promise<void> {
  if (store.log.length > LOG_CAP) store.log = store.log.slice(-LOG_CAP);
  await writeJsonAtomic(identityStorePath(), store);
}

function serial<T>(fn: () => Promise<T>): Promise<T> {
  const next = chain.then(fn, fn);
  chain = next.catch(() => undefined);
  return next;
}

export function normalizeEmail(raw: unknown): string | null {
  if (typeof raw !== "string") return null;
  const e = raw.trim().toLowerCase();
  if (e.length > 254) return null;
  return /^[^\s@<>()",;:]{1,64}@[a-z0-9.-]{1,190}\.[a-z]{2,24}$/.test(e) ? e : null;
}

export function newPlayerId(): string {
  return randomBytes(24).toString("hex");
}

/**
 * El compte ja té un correu o un Google verificats? Llavors no s'hi enllaça cap correu/Google nou
 * (dispositiu compartit: un altre no es pot apropiar del compte). Les passkeys no compten aquí:
 * un compte anònim amb passkey pot afegir-hi el correu més endavant.
 */
function hasAnyIdentity(store: Store, playerId: string): boolean {
  const p = store.players[playerId];
  if (!p) return false;
  return (p.emails?.length ?? 0) > 0 || !!p.googleSub;
}

function logEntry(store: Store, e: AuthLogEntry): void {
  store.log.push(e);
  const extra = e.fromPlayerId ? ` from=${e.fromPlayerId.slice(0, 8)}` : "";
  console.log(`[auth] ${e.type} kind=${e.kind} player=${e.playerId.slice(0, 8)}${extra}${e.legacy ? " legacy" : ""}`);
}

function bindEmail(store: Store, playerId: string, email: string): void {
  store.emails[email] = playerId;
  const p = (store.players[playerId] ??= {});
  p.emails = Array.from(new Set([...(p.emails ?? []), email]));
}

export type CurrentPlayer = { playerId: string; legacy: boolean } | null;

export type LoginInput = {
  kind: "email" | "google";
  /** Correu VERIFICAT (per a Google, només si email_verified). */
  email?: string | null;
  googleSub?: string | null;
  current?: CurrentPlayer;
  /** Es pot crear un compte nou (confirmació 18+ rebuda). */
  allowCreate: boolean;
  now?: number;
};

export type LoginResult =
  | {
      ok: true;
      playerId: string;
      created: boolean;
      linked: boolean;
      /** El navegador tenia un altre compte: no s'ha fusionat, s'entra al de la identitat. */
      switchedFrom?: string;
    }
  | { ok: false; error: "AGE_CONFIRMATION_REQUIRED" | "BAD_IDENTITY" };

export async function loginWithIdentity(input: LoginInput): Promise<LoginResult> {
  const now = input.now ?? Date.now();
  const email = input.email ? normalizeEmail(input.email) : null;
  const sub = typeof input.googleSub === "string" && /^[A-Za-z0-9_-]{1,255}$/.test(input.googleSub) ? input.googleSub : null;
  if (input.kind === "email" && !email) return { ok: false, error: "BAD_IDENTITY" };
  if (input.kind === "google" && !sub) return { ok: false, error: "BAD_IDENTITY" };
  // Un compte esborrat no es pot tornar a fer servir com a compte actual (p. ex. un repte de
  // correu demanat abans d'esborrar-lo).
  const currentRaw = input.current ? sanitizePlayerId(input.current.playerId) : null;
  const currentId = currentRaw && !isAccountDeleted(currentRaw) ? currentRaw : null;
  const legacy = !!input.current?.legacy;

  return serial(async () => {
    const store = await load();
    let owner: string | undefined = sub ? store.google[sub] : undefined;
    let viaEmail = false;
    if (!owner && email) {
      owner = store.emails[email];
      viaEmail = !!owner;
    }

    if (owner) {
      let dirty = false;
      if (sub && viaEmail) {
        const p = (store.players[owner] ??= {});
        if (!p.googleSub) {
          p.googleSub = sub;
          store.google[sub] = owner;
          logEntry(store, { at: now, type: "google_linked_by_email", kind: "google", playerId: owner });
          dirty = true;
        }
      }
      if (sub && email && !store.emails[email]) {
        bindEmail(store, owner, email);
        dirty = true;
      }
      let switchedFrom: string | undefined;
      if (currentId && currentId !== owner) {
        switchedFrom = currentId;
        logEntry(store, { at: now, type: "switch", kind: input.kind, playerId: owner, fromPlayerId: currentId, legacy });
        dirty = true;
      }
      if (dirty) await save(store);
      return { ok: true, playerId: owner, created: false, linked: false, ...(switchedFrom ? { switchedFrom } : {}) };
    }

    // Identitat nova.
    let target: string;
    let created = false;
    let linked = false;
    let switchedFrom: string | undefined;
    if (currentId && !hasAnyIdentity(store, currentId)) {
      target = currentId;
      linked = true;
      const p = (store.players[target] ??= {});
      p.linkedAt = now;
      logEntry(store, { at: now, type: "link", kind: input.kind, playerId: target, legacy });
    } else {
      if (!input.allowCreate) return { ok: false, error: "AGE_CONFIRMATION_REQUIRED" };
      target = newPlayerId();
      created = true;
      store.players[target] = { createdVia: input.kind, createdAt: now };
      if (currentId) switchedFrom = currentId;
      logEntry(store, {
        at: now,
        type: "create",
        kind: input.kind,
        playerId: target,
        ...(currentId ? { fromPlayerId: currentId } : {}),
      });
    }
    if (email) bindEmail(store, target, email);
    if (sub) {
      store.google[sub] = target;
      store.players[target]!.googleSub = sub;
    }
    await save(store);
    return { ok: true, playerId: target, created, linked, ...(switchedFrom ? { switchedFrom } : {}) };
  });
}

export type IdentitySummary = {
  emails: string[];
  google: boolean;
  passkeys: number;
};

/** Forma mínima del magatzem per llistar comptes (p. ex. lectura síncrona del JSON). */
export type IdentityStoreAccountsSlice = {
  emails?: Record<string, string>;
  google?: Record<string, string>;
  passkeys?: Record<string, Pick<StoredPasskey, "playerId"> | StoredPasskey>;
  players?: Record<string, IdentityPlayer>;
};

/**
 * playerIds amb compte verificat. Mateix criteri que `playerHasAccount` (correu o Google a
 * `players`, o alguna passkey), i a més les entrades dels mapes `emails` / `google` /
 * `passkeys` per si el fitxer ha quedat desalineat. El fan servir l'script d'orfes i els tests.
 */
export function accountPlayerIdsFromStore(store: IdentityStoreAccountsSlice | null | undefined): Set<string> {
  const out = new Set<string>();
  if (!store || typeof store !== "object") return out;
  const emails = obj<string>(store.emails);
  const google = obj<string>(store.google);
  const passkeys = obj<StoredPasskey>(store.passkeys);
  const players = obj<IdentityPlayer>(store.players);

  const passkeysByPlayer = new Map<string, number>();
  for (const pk of Object.values(passkeys)) {
    if (pk && typeof pk.playerId === "string" && pk.playerId) {
      passkeysByPlayer.set(pk.playerId, (passkeysByPlayer.get(pk.playerId) ?? 0) + 1);
      out.add(pk.playerId);
    }
  }
  for (const [playerId, p] of Object.entries(players)) {
    const hasEmail = (p?.emails?.length ?? 0) > 0;
    const hasGoogle = !!p?.googleSub;
    const hasPk = (passkeysByPlayer.get(playerId) ?? 0) > 0;
    if (hasEmail || hasGoogle || hasPk) out.add(playerId);
  }
  for (const pid of Object.values(emails)) {
    if (typeof pid === "string" && pid) out.add(pid);
  }
  for (const pid of Object.values(google)) {
    if (typeof pid === "string" && pid) out.add(pid);
  }
  return out;
}

/** El jugador té un compte verificat (correu, Google o passkey)? Sense això no pot jugar. */
export async function playerHasAccount(playerIdRaw: unknown): Promise<boolean> {
  const summary = await getIdentitySummary(playerIdRaw);
  return summary.emails.length > 0 || summary.google || summary.passkeys > 0;
}

export async function getIdentitySummary(playerIdRaw: unknown): Promise<IdentitySummary> {
  const playerId = sanitizePlayerId(playerIdRaw);
  const store = await load();
  const p = playerId ? store.players[playerId] : undefined;
  return {
    emails: [...(p?.emails ?? [])],
    google: !!p?.googleSub,
    passkeys: playerId ? Object.values(store.passkeys).filter((k) => k.playerId === playerId).length : 0,
  };
}

export async function emailOwner(emailRaw: unknown): Promise<string | null> {
  const email = normalizeEmail(emailRaw);
  if (!email) return null;
  return (await load()).emails[email] ?? null;
}

/** Comprova que el fitxer es pot llegir (al començar el servidor). */
/**
 * Esborrat de compte: correus, Google, passkeys, metadades i entrades del registre del compte.
 * Les entrades del registre on el compte només apareix com a origen (`fromPlayerId`) d'un altre
 * jugador es conserven però s'anonimitzen (sense el playerId esborrat). Idempotent.
 */
export async function deleteIdentitiesForPlayer(
  playerIdRaw: unknown,
): Promise<{ emails: number; google: number; passkeys: number; player: boolean; log: number }> {
  const playerId = sanitizePlayerId(playerIdRaw);
  const out = { emails: 0, google: 0, passkeys: 0, player: false, log: 0 };
  if (!playerId) return out;
  return serial(async () => {
    const store = await load();
    for (const [email, pid] of Object.entries(store.emails)) {
      if (pid === playerId) {
        delete store.emails[email];
        out.emails += 1;
      }
    }
    for (const [sub, pid] of Object.entries(store.google)) {
      if (pid === playerId) {
        delete store.google[sub];
        out.google += 1;
      }
    }
    for (const [credId, pk] of Object.entries(store.passkeys)) {
      if (pk?.playerId === playerId) {
        delete store.passkeys[credId];
        out.passkeys += 1;
      }
    }
    out.player = playerId in store.players;
    delete store.players[playerId];
    const before = store.log.length;
    store.log = store.log
      .filter((e) => e.playerId !== playerId)
      .map((e) => {
        if (e.fromPlayerId !== playerId) return e;
        const { fromPlayerId: _drop, ...rest } = e;
        out.log += 1;
        return rest;
      });
    out.log += before - store.log.length;
    if (out.emails || out.google || out.passkeys || out.player || out.log) await save(store);
    return out;
  });
}

export async function checkIdentityStore(): Promise<void> {
  await load();
}

export async function identityStoreSnapshotForTests(): Promise<Store> {
  return JSON.parse(JSON.stringify(await load())) as Store;
}

export function resetIdentityStoreForTests(): void {
  cache = null;
  chain = Promise.resolve();
  sourceRegistered = false;
}

/** Ús intern dels mòduls d'autenticació (passkeys). */
export const __internal = { load, save, serial, logEntry, hasAnyIdentity };
