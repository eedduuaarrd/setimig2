import { randomBytes } from "node:crypto";
import type { AuthSuccess } from "./authCommon.ts";

/**
 * Codis d'un sol ús (2 min) per portar el resultat d'un login amb redirecció (Google) fins al
 * client sense posar el token de jugador a cap URL: el callback redirigeix a
 * /login/google#code=<codi> i el client fa POST /api/auth/exchange { code }.
 */
export const RESULT_CODE_TTL_MS = 2 * 60 * 1000;
const pending = new Map<string, { result: Omit<AuthSuccess, "playerToken">; exp: number }>();

export function mintResultCode(result: Omit<AuthSuccess, "playerToken">, now = Date.now()): string {
  for (const [k, v] of pending) if (v.exp <= now) pending.delete(k);
  const code = randomBytes(24).toString("base64url");
  pending.set(code, { result, exp: now + RESULT_CODE_TTL_MS });
  return code;
}

export function consumeResultCode(code: unknown, now = Date.now()): Omit<AuthSuccess, "playerToken"> | null {
  if (typeof code !== "string" || code.length > 100) return null;
  const e = pending.get(code);
  if (!e) return null;
  pending.delete(code);
  return e.exp > now ? e.result : null;
}

export function resetResultCodesForTests(): void {
  pending.clear();
}
