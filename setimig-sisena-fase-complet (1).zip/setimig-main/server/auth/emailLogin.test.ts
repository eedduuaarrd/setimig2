import assert from "node:assert/strict";
import { after, before, beforeEach, describe, it } from "node:test";
import { mkdirSync, mkdtempSync, rmSync } from "node:fs";
import { createServer, type Server } from "node:http";
import type { AddressInfo } from "node:net";
import os from "node:os";
import path from "node:path";
import express from "express";

const dataDir = mkdtempSync(path.join(os.tmpdir(), "setimig-emaillogin-"));
process.env.BALANCE_DATA_DIR = dataDir;
process.env.PROFILE_DATA_DIR = path.join(dataDir, "profiles");
process.env.PUBLIC_BASE_URL = "https://sevenhalf.club";
// Aquests tests cobreixen també el flux de l'enllaç màgic (desactivat per defecte al correu).
process.env.MAIL_LOGIN_MAGIC_LINK = "1";

const { setMailTransportForTests } = await import("../mail/mailer.ts");
const { resetSignupNoticesForTests } = await import("../mail/signupNotice.ts");
const {
  MAIL_LOCALES,
  buildLoginMail,
  localeFromAcceptLanguage,
  normalizeMailLocale,
  resolveMailLocale,
  EMAIL_CHALLENGE_TTL_MS,
  MAX_CODE_ATTEMPTS,
  START_PER_EMAIL,
  START_PER_IP,
  pendingEmailChallengesForTests,
  resetEmailLoginForTests,
  startEmailLogin,
  verifyEmailLogin,
} = await import("./emailLogin.ts");
const { registerAuthRoutes } = await import("./authRoutes.ts");
const { resetIdentityStoreForTests, emailOwner } = await import("./identityStore.ts");
const { issuePlayerToken, verifyPlayerToken } = await import("../playerToken.ts");

type Mail = {
  to: string;
  subject: string;
  text: string;
  html?: string;
  kind: string;
  headers?: Record<string, string>;
};
let mails: Mail[] = [];

function lastCode(): string {
  const m = [...mails].reverse().find((x) => x.kind === "login_code");
  return /(\d{6})/.exec(m!.subject)![1]!;
}
function lastLinkToken(): string {
  const m = [...mails].reverse().find((x) => x.kind === "login_code");
  return decodeURIComponent(/#t=([^\s]+)/.exec(m!.text)![1]!);
}
const flush = () => new Promise((r) => setTimeout(r, 30));

let server: Server;
let base = "";

before(async () => {
  const app = express();
  app.use(express.json());
  registerAuthRoutes(app);
  server = createServer(app);
  await new Promise<void>((r) => server.listen(0, "127.0.0.1", r));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});
after(() => server.close());

beforeEach(() => {
  rmSync(dataDir, { recursive: true, force: true });
  mkdirSync(dataDir, { recursive: true });
  resetEmailLoginForTests();
  resetIdentityStoreForTests();
  resetSignupNoticesForTests();
  mails = [];
  setMailTransportForTests(async (m) => {
    mails.push(m);
    return { ok: true, provider: "cloudflare", delivered: true };
  });
});

async function post(p: string, body: unknown, token?: string) {
  const res = await fetch(base + p, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: JSON.stringify(body),
  });
  return { status: res.status, body: (await res.json()) as Record<string, unknown> };
}

const silence = () => {
  const o = console.log;
  console.log = () => {};
  return o;
};

describe("login per correu (lògica)", () => {
  it("codi de 6 xifres, un sol ús", async () => {
    assert.deepEqual(startEmailLogin({ email: "m@x.cat", ip: "1", ageConfirmed: true, startPlayer: null }), { ok: true });
    await flush();
    const code = lastCode();
    assert.match(code, /^\d{6}$/);
    const ok = verifyEmailLogin({ email: "M@x.cat", code, ip: "1" });
    assert.ok(ok.ok && ok.email === "m@x.cat" && ok.ageConfirmed);
    assert.deepEqual(verifyEmailLogin({ email: "m@x.cat", code, ip: "1" }), { ok: false, error: "EXPIRED_OR_USED" });
  });

  it("enllaç màgic al fragment, un sol ús i invalida també el codi", async () => {
    startEmailLogin({ email: "m@x.cat", ip: "1", ageConfirmed: false, startPlayer: null });
    await flush();
    assert.match(mails[0]!.text, /https:\/\/sevenhalf\.club\/login\/correu#t=/);
    const tok = lastLinkToken();
    const code = lastCode();
    assert.ok(verifyEmailLogin({ linkToken: tok, ip: "1" }).ok);
    assert.equal(verifyEmailLogin({ linkToken: tok, ip: "1" }).ok, false);
    assert.equal(verifyEmailLogin({ email: "m@x.cat", code, ip: "1" }).ok, false);
  });

  it("caduca als 10 minuts", async () => {
    const t0 = Date.now();
    startEmailLogin({ email: "m@x.cat", ip: "1", ageConfirmed: true, startPlayer: null, now: t0 });
    await flush();
    assert.deepEqual(verifyEmailLogin({ email: "m@x.cat", code: lastCode(), ip: "1", now: t0 + EMAIL_CHALLENGE_TTL_MS + 1 }), {
      ok: false,
      error: "EXPIRED_OR_USED",
    });
  });

  it("un repte nou invalida l'anterior", async () => {
    startEmailLogin({ email: "m@x.cat", ip: "1", ageConfirmed: true, startPlayer: null });
    await flush();
    const first = lastCode();
    startEmailLogin({ email: "m@x.cat", ip: "1", ageConfirmed: true, startPlayer: null });
    await flush();
    const second = lastCode();
    if (first !== second) assert.equal(verifyEmailLogin({ email: "m@x.cat", code: first, ip: "1" }).ok, false);
    assert.equal(pendingEmailChallengesForTests(), first !== second ? 1 : 0);
  });

  it(`${MAX_CODE_ATTEMPTS} codis erronis invaliden el repte`, async () => {
    startEmailLogin({ email: "m@x.cat", ip: "1", ageConfirmed: true, startPlayer: null });
    await flush();
    const code = lastCode();
    const wrong = code === "000000" ? "111111" : "000000";
    for (let i = 0; i < MAX_CODE_ATTEMPTS; i++) {
      assert.deepEqual(verifyEmailLogin({ email: "m@x.cat", code: wrong, ip: "1" }), { ok: false, error: "INVALID_CODE" });
    }
    assert.deepEqual(verifyEmailLogin({ email: "m@x.cat", code, ip: "1" }), { ok: false, error: "EXPIRED_OR_USED" });
  });

  it("límit per correu: RATE_LIMIT amb retryAfterSec i no s'envia res més", async () => {
    const t0 = Date.now();
    for (let i = 0; i < START_PER_EMAIL; i++) {
      assert.deepEqual(startEmailLogin({ email: "m@x.cat", ip: `ip${i}`, ageConfirmed: true, startPlayer: null, now: t0 }), { ok: true });
    }
    const r = startEmailLogin({ email: "m@x.cat", ip: "ipx", ageConfirmed: true, startPlayer: null, now: t0 + 1000 });
    assert.ok("error" in r && r.error === "RATE_LIMIT" && r.retryAfterSec! > 0);
    await flush();
    assert.equal(mails.length, START_PER_EMAIL);
  });

  it("HTTP: START_PER_EMAIL superat → 429 RATE_LIMIT amb retryAfter i Retry-After", async () => {
    for (let i = 0; i < START_PER_EMAIL; i++) {
      assert.equal((await post("/api/auth/email/start", { email: "lim@x.cat" })).status, 202);
    }
    const res = await fetch(base + "/api/auth/email/start", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: "lim@x.cat" }),
    });
    assert.equal(res.status, 429);
    const body = (await res.json()) as Record<string, unknown>;
    assert.equal(body.code, "RATE_LIMIT");
    assert.equal(typeof body.retryAfter, "number");
    assert.ok((body.retryAfter as number) > 0);
    assert.equal(res.headers.get("retry-after"), String(body.retryAfter));
    await flush();
    assert.equal(mails.filter((m) => m.to === "lim@x.cat").length, START_PER_EMAIL);
  });

  it("registre amb un sol correu: sense 18+ el codi segueix viu; amb 18+ el mateix codi crea i es consumeix", async () => {
    await post("/api/auth/email/start", { email: "un@x.cat" });
    await flush();
    const code = lastCode();
    const r1 = await post("/api/auth/email/verify", { email: "un@x.cat", code });
    assert.equal(r1.status, 403);
    assert.equal(r1.body.code, "AGE_CONFIRMATION_REQUIRED");
    assert.equal(pendingEmailChallengesForTests(), 1);
    const o = silence();
    let r2;
    try {
      r2 = await post("/api/auth/email/verify", { email: "un@x.cat", code, ageConfirmed: true });
      await flush();
    } finally {
      console.log = o;
    }
    assert.equal(r2.status, 200);
    assert.equal(r2.body.created, true);
    assert.equal(pendingEmailChallengesForTests(), 0);
    const r3 = await post("/api/auth/email/verify", { email: "un@x.cat", code, ageConfirmed: true });
    assert.equal(r3.status, 410);
  });

  it("sense 18+ un codi erroni segueix comptant intents i acaba invalidant el repte", async () => {
    await post("/api/auth/email/start", { email: "er@x.cat" });
    await flush();
    const code = lastCode();
    const wrong = code === "000000" ? "111111" : "000000";
    for (let i = 0; i < MAX_CODE_ATTEMPTS; i++) {
      assert.equal((await post("/api/auth/email/verify", { email: "er@x.cat", code: wrong })).status, 400);
    }
    assert.equal((await post("/api/auth/email/verify", { email: "er@x.cat", code, ageConfirmed: true })).status, 410);
  });

  it("límit per IP: RATE_LIMIT", () => {
    for (let i = 0; i < START_PER_IP; i++) startEmailLogin({ email: `u${i}@x.cat`, ip: "9", ageConfirmed: true, startPlayer: null });
    assert.deepEqual(startEmailLogin({ email: "z@x.cat", ip: "9", ageConfirmed: true, startPlayer: null }), { ok: false, error: "RATE_LIMIT" });
  });
});

describe("login per correu (HTTP)", () => {
  it("start: mateixa resposta per a correus amb compte i sense", async () => {
    const o = silence();
    try {
      await (await import("./identityStore.ts")).loginWithIdentity({ kind: "email", email: "te@x.cat", current: null, allowCreate: true });
    } finally {
      console.log = o;
    }
    const a = await post("/api/auth/email/start", { email: "te@x.cat" });
    const b = await post("/api/auth/email/start", { email: "no-te@x.cat" });
    assert.equal(a.status, 202);
    assert.deepEqual(a, b);
    assert.equal((await post("/api/auth/email/start", { email: "dolent" })).status, 400);
  });

  it("anònim amb token: verificar enllaça el compte i retorna un token del MATEIX playerId", async () => {
    const anon = "c".repeat(48);
    const token = issuePlayerToken(anon)!;
    await post("/api/auth/email/start", { email: "anon@x.cat" }, token);
    await flush();
    const o = silence();
    let r;
    try {
      r = await post("/api/auth/email/verify", { email: "anon@x.cat", code: lastCode() }, token);
    } finally {
      console.log = o;
    }
    assert.equal(r.status, 200);
    assert.equal(r.body.playerId, anon);
    assert.equal(r.body.linked, true);
    assert.equal(r.body.created, false);
    assert.equal(verifyPlayerToken(r.body.playerToken)?.playerId, anon);
    assert.equal(await emailOwner("anon@x.cat"), anon);
  });

  it("enllaç obert en un altre navegador: entra al compte que l'havia demanat (amb token)", async () => {
    const anon = "d".repeat(48);
    await post("/api/auth/email/start", { email: "d@x.cat" }, issuePlayerToken(anon)!);
    await flush();
    const o = silence();
    let r;
    try {
      r = await post("/api/auth/email/verify", { linkToken: lastLinkToken() });
    } finally {
      console.log = o;
    }
    assert.equal(r.status, 200);
    assert.equal(r.body.playerId, anon);
  });

  it("compte nou sense 18+ → 403 AGE_CONFIRMATION_REQUIRED; amb 18+ → created i avís de registre", async () => {
    await post("/api/auth/email/start", { email: "nou@x.cat" });
    await flush();
    const r1 = await post("/api/auth/email/verify", { email: "nou@x.cat", code: lastCode() });
    assert.equal(r1.status, 403);
    assert.equal(r1.body.code, "AGE_CONFIRMATION_REQUIRED");

    await post("/api/auth/email/start", { email: "nou@x.cat", ageConfirmed: true });
    await flush();
    const o = silence();
    let r2;
    try {
      r2 = await post("/api/auth/email/verify", { email: "nou@x.cat", code: lastCode() });
      for (let i = 0; i < 50 && !mails.some((m) => m.kind === "signup_notice"); i++) await flush();
    } finally {
      console.log = o;
    }
    assert.equal(r2.status, 200);
    assert.equal(r2.body.created, true);
    const notice = mails.find((m) => m.kind === "signup_notice");
    assert.ok(notice);
    assert.match(notice!.text, /Via de registre: correu/);
    assert.doesNotMatch(notice!.text, /nou@x\.cat/);
  });

  it("codi erroni → 400 INVALID_CODE; origen estrany → 403", async () => {
    await post("/api/auth/email/start", { email: "e@x.cat" });
    await flush();
    const wrong = lastCode() === "123456" ? "654321" : "123456";
    const r = await post("/api/auth/email/verify", { email: "e@x.cat", code: wrong });
    assert.equal(r.status, 400);
    assert.equal(r.body.code, "INVALID_CODE");
    const res = await fetch(base + "/api/auth/email/start", {
      method: "POST",
      headers: { "Content-Type": "application/json", Origin: "https://dolent.example" },
      body: JSON.stringify({ email: "e@x.cat" }),
    });
    assert.equal(res.status, 403);
  });

  it("providers i me", async () => {
    const p = await (await fetch(base + "/api/auth/providers")).json();
    assert.equal(p.email, true);
    assert.equal((await fetch(base + "/api/auth/me")).status, 401);
    const anon = "e".repeat(48);
    const me = await (await fetch(base + "/api/auth/me", { headers: { Authorization: `Bearer ${issuePlayerToken(anon)}` } })).json();
    assert.deepEqual(me, { playerId: anon, emails: [], google: false, passkeys: 0, verified: false });
  });

  it("sense canal de correu (mode log) el login per correu no està disponible", async () => {
    setMailTransportForTests(null);
    const p = await (await fetch(base + "/api/auth/providers")).json();
    assert.equal(p.email, false);
    const r = await post("/api/auth/email/start", { email: "m@x.cat" });
    assert.equal(r.status, 503);
  });
});

describe("correu del codi: sense seguiment i en l'idioma de la UI", () => {
  const INTRO: Record<string, RegExp> = {
    ca: /^El teu codi per entrar a Seven Half Club: \d{6}$/m,
    en: /^Your Seven Half Club sign-in code: \d{6}$/m,
    es: /^Tu código para entrar en Seven Half Club: \d{6}$/m,
    it: /^Il tuo codice per accedere a Seven Half Club: \d{6}$/m,
    "pt-BR": /^Seu código para entrar no Seven Half Club: \d{6}$/m,
  };
  const SUBJECT: Record<string, RegExp> = {
    ca: /^\d{6} és el teu codi de Seven Half Club$/,
    en: /^\d{6} is your Seven Half Club code$/,
    es: /^\d{6} es tu código de Seven Half Club$/,
    it: /^\d{6} è il tuo codice di Seven Half Club$/,
    "pt-BR": /^\d{6} é o seu código do Seven Half Club$/,
  };
  const lastMail = () => [...mails].reverse().find((x) => x.kind === "login_code")!;

  it("per defecte: HTML de marca i text pla, cap token ni enllaç màgic", async () => {
    const prev = process.env.MAIL_LOGIN_MAGIC_LINK;
    delete process.env.MAIL_LOGIN_MAGIC_LINK;
    try {
      startEmailLogin({ email: "t@x.cat", ip: "1", ageConfirmed: true, startPlayer: null });
      await flush();
    } finally {
      process.env.MAIL_LOGIN_MAGIC_LINK = prev;
    }
    const m = lastMail();
    assert.match(m.html ?? "", /Seven Half Club/);
    assert.match(m.html ?? "", /#0b0b0b/);
    assert.ok((m.html ?? "").includes(lastCode()));
    assert.doesNotMatch(m.html ?? "", /<a\b|<img\b|sendibt|sendinblue|brevo\.com/i);
    assert.equal(m.headers?.["X-Mailin-Track"], "0");
    assert.equal(m.headers?.["X-Mailin-Track-Clicks"], "0");
    assert.equal(m.headers?.["X-Mailin-Track-Opens"], "0");
    assert.doesNotMatch(m.text, /#t=/);
    assert.doesNotMatch(m.text, /sendibt|brevo|sendinblue/i);
    assert.match(m.text, /^https:\/\/sevenhalf\.club\/login\/correu$/m);
    assert.ok(verifyEmailLogin({ email: "t@x.cat", code: lastCode(), ip: "1" }).ok, "el codi continua funcionant");
  });

  it("els 5 idiomes: assumpte i cos sencers en el mateix idioma", () => {
    for (const l of MAIL_LOCALES) {
      const m = buildLoginMail("123456", l, null);
      assert.match(m.subject, SUBJECT[l]!, l);
      assert.match(m.text, INTRO[l]!, l);
      assert.match(m.html, new RegExp(INTRO[l]!.source.replace(/^\^/, "").replace(/\$$/, "")), l);
      for (const other of MAIL_LOCALES) {
        if (other !== l) assert.doesNotMatch(m.text, INTRO[other]!, `${l} no conté ${other}`);
      }
      assert.match(m.html, /123456/);
    }
    // Ca i en no es barregen (abans l'última línia sempre sortia en anglès).
    assert.doesNotMatch(buildLoginMail("123456", "ca", null).text, /code|expires/i);
    assert.doesNotMatch(buildLoginMail("123456", "en", null).text, /codi|caduca/i);
  });

  it("normalització de l'idioma i Accept-Language", () => {
    assert.equal(normalizeMailLocale("es"), "es");
    assert.equal(normalizeMailLocale("pt"), "pt-BR");
    assert.equal(normalizeMailLocale("pt-PT"), "pt-BR");
    assert.equal(normalizeMailLocale("pt_BR"), "pt-BR");
    assert.equal(normalizeMailLocale("EN-us"), "en");
    assert.equal(normalizeMailLocale("ca-ES"), "ca");
    assert.equal(normalizeMailLocale("fr"), null);
    assert.equal(normalizeMailLocale("<script>"), null);
    assert.equal(normalizeMailLocale(42), null);
    assert.equal(localeFromAcceptLanguage("fr-FR,fr;q=0.9,it;q=0.8,en;q=0.7"), "it");
    assert.equal(localeFromAcceptLanguage("de, es;q=0.2, ca;q=0.5"), "ca");
    assert.equal(localeFromAcceptLanguage("de,fr"), null);
    assert.equal(resolveMailLocale("es", "it"), "es");
    assert.equal(resolveMailLocale("xx", "it-IT"), "it");
    assert.equal(resolveMailLocale(undefined, undefined), "en");
  });

  it("HTTP: locale → Accept-Language → anglès (i àlies lang)", async () => {
    const cases: Array<[Record<string, unknown>, string | undefined, string]> = [
      [{ email: "a1@x.cat", locale: "es" }, "ca-ES,ca;q=0.9", "es"],
      [{ email: "a2@x.cat", lang: "pt-BR" }, undefined, "pt-BR"],
      [{ email: "a3@x.cat" }, "it-IT,it;q=0.9", "it"],
      [{ email: "a4@x.cat", locale: "fr" }, "ca", "ca"],
      [{ email: "a5@x.cat", locale: "zz" }, "de-DE", "en"],
      [{ email: "a6@x.cat" }, undefined, "en"],
    ];
    for (const [body, al, expected] of cases) {
      const headers: Record<string, string> = { "Content-Type": "application/json" };
      if (al) headers["Accept-Language"] = al;
      const res = await fetch(base + "/api/auth/email/start", { method: "POST", headers, body: JSON.stringify(body) });
      assert.equal(res.status, 202);
      await flush();
      const m = lastMail();
      assert.equal(m.to, body.email);
      assert.match(m.subject, SUBJECT[expected]!, `${JSON.stringify(body)} / ${al} → ${expected}`);
      assert.match(m.text, INTRO[expected]!);
    }
  });
});
