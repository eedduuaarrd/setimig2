import assert from "node:assert/strict";
import { after, before, beforeEach, describe, it } from "node:test";
import { generateKeyPairSync, sign as cryptoSign, createHash } from "node:crypto";
import { mkdirSync, mkdtempSync, rmSync } from "node:fs";
import { createServer, type Server } from "node:http";
import type { AddressInfo } from "node:net";
import os from "node:os";
import path from "node:path";
import express from "express";

const dataDir = mkdtempSync(path.join(os.tmpdir(), "setimig-google-"));
process.env.BALANCE_DATA_DIR = dataDir;
process.env.PROFILE_DATA_DIR = path.join(dataDir, "profiles");
process.env.PUBLIC_BASE_URL = "https://sevenhalf.club";
process.env.GOOGLE_CLIENT_ID = "cid.apps.googleusercontent.com";
process.env.GOOGLE_CLIENT_SECRET = "gsecret";

const { setMailTransportForTests } = await import("../mail/mailer.ts");
const { resetSignupNoticesForTests } = await import("../mail/signupNotice.ts");
const g = await import("./googleAuth.ts");
const { registerAuthRoutes } = await import("./authRoutes.ts");
const { resetIdentityStoreForTests, loginWithIdentity, emailOwner } = await import("./identityStore.ts");
const { resetResultCodesForTests } = await import("./loginResultCodes.ts");
const { issuePlayerToken, verifyPlayerToken } = await import("../playerToken.ts");

const { privateKey, publicKey } = generateKeyPairSync("rsa", { modulusLength: 2048 });
const { privateKey: otherKey } = generateKeyPairSync("rsa", { modulusLength: 2048 });
const KID = "k1";
const jwk = { ...(publicKey.export({ format: "jwk" }) as object), kid: KID, alg: "RS256", use: "sig" };

function makeIdToken(claims: Record<string, unknown>, opts: { key?: typeof privateKey; kid?: string; alg?: string } = {}): string {
  const header = { alg: opts.alg ?? "RS256", kid: opts.kid ?? KID, typ: "JWT" };
  const h = Buffer.from(JSON.stringify(header)).toString("base64url");
  const p = Buffer.from(JSON.stringify(claims)).toString("base64url");
  const sig = cryptoSign("RSA-SHA256", Buffer.from(`${h}.${p}`), opts.key ?? privateKey).toString("base64url");
  return `${h}.${p}.${sig}`;
}

function baseClaims(nonce: string, extra: Record<string, unknown> = {}): Record<string, unknown> {
  const now = Math.floor(Date.now() / 1000);
  return {
    iss: "https://accounts.google.com",
    aud: "cid.apps.googleusercontent.com",
    sub: "1100220033",
    email: "marta@gmail.com",
    email_verified: true,
    given_name: "Marta",
    iat: now,
    exp: now + 3600,
    nonce,
    ...extra,
  };
}

/** Fals Google: JWKS i endpoint de tokens (comprova PKCE i paràmetres). */
let nextIdToken: (nonce: string) => string = (n) => makeIdToken(baseClaims(n));
let lastTokenRequest: URLSearchParams | null = null;
let lastNonce = "";
let lastChallenge = "";
let jwksFetches = 0;
g.setGoogleFetchForTests((async (url: string, init?: RequestInit) => {
  if (url === g.GOOGLE_JWKS_URL) {
    jwksFetches += 1;
    return new Response(JSON.stringify({ keys: [jwk] }), { headers: { "cache-control": "public, max-age=3600" } });
  }
  if (url === g.GOOGLE_TOKEN_URL) {
    lastTokenRequest = new URLSearchParams(String(init?.body));
    const verifier = lastTokenRequest.get("code_verifier") ?? "";
    if (createHash("sha256").update(verifier).digest("base64url") !== lastChallenge) {
      return new Response(JSON.stringify({ error: "invalid_grant" }), { status: 400 });
    }
    if (lastTokenRequest.get("code") !== "good-code") return new Response(JSON.stringify({ error: "invalid_grant" }), { status: 400 });
    return new Response(JSON.stringify({ id_token: nextIdToken(lastNonce), access_token: "x" }));
  }
  return new Response("not found", { status: 404 });
}) as unknown as typeof fetch);

let server: Server;
let base = "";
before(async () => {
  const app = express();
  app.use(express.json());
  registerAuthRoutes(app);
  g.registerGoogleAuthRoutes(app);
  server = createServer(app);
  await new Promise<void>((r) => server.listen(0, "127.0.0.1", r));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
});
after(() => server.close());

let mails: { kind: string; text: string }[] = [];
const origLog = console.log;
const origWarn = console.warn;
beforeEach(() => {
  rmSync(dataDir, { recursive: true, force: true });
  mkdirSync(dataDir, { recursive: true });
  resetIdentityStoreForTests();
  resetSignupNoticesForTests();
  resetResultCodesForTests();
  g.resetGoogleAuthForTests();
  nextIdToken = (n) => makeIdToken(baseClaims(n));
  mails = [];
  setMailTransportForTests(async (m) => {
    mails.push(m);
    return { ok: true, provider: "cloudflare", delivered: true };
  });
  console.log = () => {};
  console.warn = () => {};
});
after(() => {
  console.log = origLog;
  console.warn = origWarn;
});

async function startFlow(body: Record<string, unknown>, token?: string): Promise<{ state: string; cookie: string; url: URL }> {
  const res = await fetch(base + "/api/auth/google/start", {
    method: "POST",
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: JSON.stringify(body),
  });
  assert.equal(res.status, 200);
  const { url } = (await res.json()) as { url: string };
  const u = new URL(url);
  const setCookie = res.headers.get("set-cookie") ?? "";
  const cookie = /sm_g_state=([^;]+)/.exec(setCookie)![1]!;
  lastNonce = u.searchParams.get("nonce")!;
  lastChallenge = u.searchParams.get("code_challenge")!;
  return { state: u.searchParams.get("state")!, cookie, url: u };
}

async function callback(q: Record<string, string>, cookie?: string): Promise<{ status: number; location: string }> {
  const res = await fetch(`${base}/api/auth/google/callback?${new URLSearchParams(q)}`, {
    redirect: "manual",
    headers: cookie ? { Cookie: `sm_g_state=${cookie}` } : {},
  });
  return { status: res.status, location: res.headers.get("location") ?? "" };
}

async function exchange(code: string) {
  const res = await fetch(base + "/api/auth/exchange", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ code }),
  });
  return { status: res.status, body: (await res.json()) as Record<string, unknown> };
}

describe("Google OIDC", () => {
  it("providers: google actiu només amb GOOGLE_CLIENT_ID i GOOGLE_CLIENT_SECRET", async () => {
    assert.equal((await (await fetch(base + "/api/auth/providers")).json()).google, true);
    const saved = process.env.GOOGLE_CLIENT_SECRET;
    delete process.env.GOOGLE_CLIENT_SECRET;
    try {
      assert.equal((await (await fetch(base + "/api/auth/providers")).json()).google, false);
      assert.equal((await fetch(base + "/api/auth/google/start", { method: "POST" })).status, 404);
    } finally {
      process.env.GOOGLE_CLIENT_SECRET = saved;
    }
  });

  it("start: URL amb PKCE S256, state, nonce, scopes i redirect exacte; galeta HttpOnly Secure Lax", async () => {
    const res = await fetch(base + "/api/auth/google/start", { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" });
    const { url } = (await res.json()) as { url: string };
    const u = new URL(url);
    assert.equal(u.origin + u.pathname, "https://accounts.google.com/o/oauth2/v2/auth");
    assert.equal(u.searchParams.get("redirect_uri"), "https://sevenhalf.club/api/auth/google/callback");
    assert.equal(u.searchParams.get("scope"), "openid email profile");
    assert.equal(u.searchParams.get("code_challenge_method"), "S256");
    assert.equal(u.searchParams.get("response_type"), "code");
    assert.ok(u.searchParams.get("state") && u.searchParams.get("nonce"));
    const sc = res.headers.get("set-cookie")!;
    assert.match(sc, /HttpOnly/);
    assert.match(sc, /Secure/);
    assert.match(sc, /SameSite=Lax/);
    assert.match(sc, /Path=\/api\/auth\/google/);
  });

  it("flux complet: compte nou amb 18+, token del mateix tipus i avís de registre", async () => {
    const f = await startFlow({ ageConfirmed: true });
    const cb = await callback({ code: "good-code", state: f.state }, f.cookie);
    assert.equal(cb.status, 303);
    assert.match(cb.location, /^https:\/\/sevenhalf\.club\/login\/google#code=/);
    assert.equal(lastTokenRequest!.get("redirect_uri"), "https://sevenhalf.club/api/auth/google/callback");
    assert.equal(lastTokenRequest!.get("grant_type"), "authorization_code");
    const code = decodeURIComponent(cb.location.split("#code=")[1]!);
    const ex = await exchange(code);
    assert.equal(ex.status, 200);
    assert.equal(ex.body.created, true);
    assert.equal(ex.body.method, "google");
    assert.equal(verifyPlayerToken(ex.body.playerToken)?.playerId, ex.body.playerId);
    assert.equal(await emailOwner("marta@gmail.com"), ex.body.playerId);
    // El codi de bescanvi és d'un sol ús.
    assert.equal((await exchange(code)).status, 410);
    for (let i = 0; i < 50 && mails.length === 0; i++) await new Promise((r) => setTimeout(r, 10));
    assert.match(mails[0]!.text, /Nom \/ àlies: Marta/);
    assert.match(mails[0]!.text, /Via de registre: Google/);
  });

  it("anònim amb token: Google s'enllaça al seu playerId", async () => {
    const anon = "f".repeat(48);
    const f = await startFlow({}, issuePlayerToken(anon)!);
    const cb = await callback({ code: "good-code", state: f.state }, f.cookie);
    const ex = await exchange(decodeURIComponent(cb.location.split("#code=")[1]!));
    assert.equal(ex.body.playerId, anon);
    assert.equal(ex.body.linked, true);
  });

  it("mateix correu verificat que un compte per correu → mateix compte", async () => {
    const r = await loginWithIdentity({ kind: "email", email: "marta@gmail.com", current: null, allowCreate: true });
    assert.ok(r.ok);
    const f = await startFlow({});
    const cb = await callback({ code: "good-code", state: f.state }, f.cookie);
    const ex = await exchange(decodeURIComponent(cb.location.split("#code=")[1]!));
    assert.equal(ex.body.playerId, (r as { playerId: string }).playerId);
    assert.equal(ex.body.created, false);
  });

  it("correu NO verificat: no s'usa per enllaçar amb un compte existent", async () => {
    const r = await loginWithIdentity({ kind: "email", email: "marta@gmail.com", current: null, allowCreate: true });
    nextIdToken = (n) => makeIdToken(baseClaims(n, { email_verified: false }));
    const f = await startFlow({ ageConfirmed: true });
    const cb = await callback({ code: "good-code", state: f.state }, f.cookie);
    const ex = await exchange(decodeURIComponent(cb.location.split("#code=")[1]!));
    assert.notEqual(ex.body.playerId, (r as { playerId: string }).playerId);
    assert.equal(ex.body.created, true);
  });

  it("compte nou sense 18+ → #error=AGE_CONFIRMATION_REQUIRED", async () => {
    const f = await startFlow({});
    const cb = await callback({ code: "good-code", state: f.state }, f.cookie);
    assert.match(cb.location, /#error=AGE_CONFIRMATION_REQUIRED$/);
  });

  it("CSRF: sense galeta o amb una altra galeta → STATE_MISMATCH; state d'un sol ús", async () => {
    const f = await startFlow({ ageConfirmed: true });
    assert.match((await callback({ code: "good-code", state: f.state })).location, /#error=STATE_MISMATCH/);
    // El state ja s'ha consumit.
    assert.match((await callback({ code: "good-code", state: f.state }, f.cookie)).location, /#error=BAD_STATE/);
    const f2 = await startFlow({ ageConfirmed: true });
    assert.match((await callback({ code: "good-code", state: f2.state }, "galeta-dolenta")).location, /#error=STATE_MISMATCH/);
    assert.match((await callback({ code: "good-code", state: "inventat" }, f2.cookie)).location, /#error=BAD_STATE/);
  });

  it("error de Google (l'usuari cancel·la) → ACCESS_DENIED", async () => {
    const f = await startFlow({});
    assert.match((await callback({ error: "access_denied", state: f.state }, f.cookie)).location, /#error=ACCESS_DENIED/);
  });

  it("codi rebutjat per Google → TOKEN_EXCHANGE_FAILED", async () => {
    const f = await startFlow({ ageConfirmed: true });
    assert.match((await callback({ code: "dolent", state: f.state }, f.cookie)).location, /#error=TOKEN_EXCHANGE_FAILED/);
  });

  for (const [label, mk] of [
    ["signatura d'una altra clau", (n: string) => makeIdToken(baseClaims(n), { key: otherKey })],
    ["iss incorrecte", (n: string) => makeIdToken(baseClaims(n, { iss: "https://evil.example" }))],
    ["aud d'un altre client", (n: string) => makeIdToken(baseClaims(n, { aud: "altre.apps.googleusercontent.com" }))],
    ["caducat", (n: string) => makeIdToken(baseClaims(n, { exp: Math.floor(Date.now() / 1000) - 3600 }))],
    ["nonce diferent", () => makeIdToken(baseClaims("un-altre-nonce"))],
    ["alg none", (n: string) => makeIdToken(baseClaims(n), { alg: "none" })],
    ["kid desconegut", (n: string) => makeIdToken(baseClaims(n), { kid: "zz" })],
  ] as const) {
    it(`ID token rebutjat: ${label} → BAD_ID_TOKEN`, async () => {
      nextIdToken = mk;
      const f = await startFlow({ ageConfirmed: true });
      assert.match((await callback({ code: "good-code", state: f.state }, f.cookie)).location, /#error=BAD_ID_TOKEN/);
    });
  }

  it("JWKS en memòria cau (no es baixa a cada login)", async () => {
    jwksFetches = 0;
    for (let i = 0; i < 3; i++) {
      const f = await startFlow({ ageConfirmed: true });
      await callback({ code: "good-code", state: f.state }, f.cookie);
    }
    assert.equal(jwksFetches, 1);
  });

  it("readCookie", () => {
    assert.equal(g.readCookie("a=1; sm_g_state=abc_DEF-1; b=2", "sm_g_state"), "abc_DEF-1");
    assert.equal(g.readCookie("sm_g_state=<script>", "sm_g_state"), null);
    assert.equal(g.readCookie(undefined, "sm_g_state"), null);
  });
});
