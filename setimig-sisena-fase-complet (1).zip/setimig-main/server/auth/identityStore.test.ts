import assert from "node:assert/strict";
import { beforeEach, describe, it } from "node:test";
import { existsSync, mkdtempSync, readFileSync, rmSync, writeFileSync, mkdirSync } from "node:fs";
import os from "node:os";
import path from "node:path";

const dataDir = mkdtempSync(path.join(os.tmpdir(), "setimig-ident-"));
process.env.BALANCE_DATA_DIR = dataDir;
process.env.PROFILE_DATA_DIR = path.join(dataDir, "profiles");

const {
  emailOwner,
  getIdentitySummary,
  identityStorePath,
  identityStoreSnapshotForTests,
  loginWithIdentity,
  normalizeEmail,
  resetIdentityStoreForTests,
} = await import("./identityStore.ts");
const { countAccounts, resetSignupNoticesForTests } = await import("../mail/signupNotice.ts");

const ANON = "a".repeat(48);
const OTHER = "b".repeat(48);
const quiet = () => {
  const o = console.log;
  console.log = () => {};
  return () => (console.log = o);
};

describe("magatzem d'identitats", () => {
  let restore: () => void;
  beforeEach(() => {
    rmSync(dataDir, { recursive: true, force: true });
    mkdirSync(dataDir, { recursive: true });
    resetIdentityStoreForTests();
    resetSignupNoticesForTests();
    restore?.();
    restore = quiet();
  });

  it("normalitza correus", () => {
    assert.equal(normalizeEmail("  Marta@Exemple.CAT "), "marta@exemple.cat");
    assert.equal(normalizeEmail("dolent"), null);
  });

  it("un anònim que entra per primer cop enllaça el seu playerId (mateix compte, mateix saldo)", async () => {
    const r = await loginWithIdentity({ kind: "email", email: "m@x.cat", current: { playerId: ANON, legacy: false }, allowCreate: false });
    assert.deepEqual(r, { ok: true, playerId: ANON, created: false, linked: true });
    assert.equal(await emailOwner("M@X.cat"), ANON);
    const disk = JSON.parse(readFileSync(identityStorePath(), "utf8"));
    assert.equal(disk.emails["m@x.cat"], ANON);
    assert.equal(disk.log[0].type, "link");
  });

  it("mateix correu = mateix compte, encara que el navegador en tingui un altre (sense fusionar)", async () => {
    await loginWithIdentity({ kind: "email", email: "m@x.cat", current: { playerId: ANON, legacy: false }, allowCreate: false });
    const r = await loginWithIdentity({ kind: "email", email: "m@x.cat", current: { playerId: OTHER, legacy: false }, allowCreate: true });
    assert.deepEqual(r, { ok: true, playerId: ANON, created: false, linked: false, switchedFrom: OTHER });
    const snap = await identityStoreSnapshotForTests();
    assert.equal(snap.players[OTHER], undefined, "el compte del navegador no es toca");
    assert.equal(snap.log.at(-1)?.type, "switch");
    assert.equal(snap.log.at(-1)?.fromPlayerId, OTHER);
  });

  it("sense compte al navegador: crea un compte nou només amb 18+ confirmat", async () => {
    const no = await loginWithIdentity({ kind: "email", email: "n@x.cat", current: null, allowCreate: false });
    assert.deepEqual(no, { ok: false, error: "AGE_CONFIRMATION_REQUIRED" });
    assert.equal(existsSync(identityStorePath()), false, "no s'escriu res");
    const yes = await loginWithIdentity({ kind: "email", email: "n@x.cat", current: null, allowCreate: true });
    assert.ok(yes.ok && yes.created && /^[a-f0-9]{48}$/.test(yes.playerId));
    const again = await loginWithIdentity({ kind: "email", email: "N@x.cat", current: null, allowCreate: true });
    assert.ok(again.ok && !again.created && again.playerId === (yes as { playerId: string }).playerId);
  });

  it("un compte que ja té identitat no s'enllaça a un correu nou: se'n crea un altre", async () => {
    await loginWithIdentity({ kind: "email", email: "m@x.cat", current: { playerId: ANON, legacy: false }, allowCreate: false });
    const r = await loginWithIdentity({ kind: "email", email: "altre@x.cat", current: { playerId: ANON, legacy: false }, allowCreate: true });
    assert.ok(r.ok && r.created && r.playerId !== ANON && r.switchedFrom === ANON);
    assert.equal(await emailOwner("m@x.cat"), ANON);
  });

  it("Google: el correu verificat existent porta al mateix compte i hi queda enllaçat el sub", async () => {
    await loginWithIdentity({ kind: "email", email: "m@x.cat", current: { playerId: ANON, legacy: false }, allowCreate: false });
    const g = await loginWithIdentity({ kind: "google", googleSub: "1234567890", email: "m@x.cat", current: null, allowCreate: true });
    assert.deepEqual(g, { ok: true, playerId: ANON, created: false, linked: false });
    const g2 = await loginWithIdentity({ kind: "google", googleSub: "1234567890", email: null, current: null, allowCreate: true });
    assert.ok(g2.ok && g2.playerId === ANON);
    assert.deepEqual(await getIdentitySummary(ANON), { emails: ["m@x.cat"], google: true, passkeys: 0 });
  });

  it("Google: un sub conegut no pren el correu d'un altre compte", async () => {
    await loginWithIdentity({ kind: "google", googleSub: "g1", email: "g@x.cat", current: { playerId: ANON, legacy: false }, allowCreate: false });
    await loginWithIdentity({ kind: "email", email: "o@x.cat", current: { playerId: OTHER, legacy: false }, allowCreate: false });
    const r = await loginWithIdentity({ kind: "google", googleSub: "g1", email: "o@x.cat", current: null, allowCreate: true });
    assert.ok(r.ok && r.playerId === ANON);
    assert.equal(await emailOwner("o@x.cat"), OTHER);
  });

  it("crides simultànies amb el mateix correu nou creen UN sol compte", async () => {
    const rs = await Promise.all(
      Array.from({ length: 5 }, () => loginWithIdentity({ kind: "email", email: "c@x.cat", current: null, allowCreate: true })),
    );
    const ids = new Set(rs.map((r) => (r.ok ? r.playerId : "")));
    assert.equal(ids.size, 1);
    assert.equal(rs.filter((r) => r.ok && r.created).length, 1);
  });

  it("fitxer malmès: no es reescriu i el login falla", async () => {
    writeFileSync(identityStorePath(), "{trencat");
    await assert.rejects(loginWithIdentity({ kind: "email", email: "z@x.cat", current: null, allowCreate: true }));
    assert.equal(readFileSync(identityStorePath(), "utf8"), "{trencat");
  });

  it("els comptes creats per login compten al total de comptes", async () => {
    await loginWithIdentity({ kind: "email", email: "c1@x.cat", current: null, allowCreate: true });
    await loginWithIdentity({ kind: "email", email: "c2@x.cat", current: { playerId: ANON, legacy: true }, allowCreate: true });
    assert.equal(await countAccounts(), 2);
  });
});
