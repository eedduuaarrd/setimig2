import { createHash, createPublicKey, randomBytes, timingSafeEqual, verify as cryptoVerify, type JsonWebKey } from "node:crypto";
import type { Express, Request, Response } from "express";
import { notifySignupLater } from "../mail/signupNotice.ts";
import { bool, buildAuthSuccess, currentPlayer, originAllowed, publicBaseUrl, rateKey, sendAuthError, FixedWindowLimiter } from "./authCommon.ts";
import type { CurrentPlayer } from "./identityStore.ts";
import { loginWithIdentity } from "./identityStore.ts";
import { consumeResultCode, mintResultCode } from "./loginResultCodes.ts";
import { registerProviderFlags } from "./authRoutes.ts";

/**
 * Google OIDC (flux «authorization code» + PKCE S256 + state + nonce).
 *
 * Només actiu si hi ha GOOGLE_CLIENT_ID i GOOGLE_CLIENT_SECRET a l'env (si no, /api/auth/providers
 * diu google:false i les rutes responen 404).
 *
 * 1. POST /api/auth/google/start { ageConfirmed? } (amb el token del jugador si en té) → { url }.
 *    També GET /api/auth/google/start?ageConfirmed=1 → 302 a Google (sense compte actual).
 *    Desa l'estat al servidor (10 min) i posa la galeta `sm_g_state` (HttpOnly, Secure, SameSite=Lax,
 *    Path=/api/auth/google) que lliga l'estat al navegador (protecció CSRF de login).
 * 2. GET /api/auth/google/callback?code&state → canvia el codi per tokens, verifica l'ID token amb
 *    el JWKS de Google (signatura RS256, iss, aud, exp, iat, nonce, email_verified) i fa el login.
 *    Redirigeix (303) a {PUBLIC_BASE_URL}/login/google#code=<codi d'un sol ús> o #error=<CODI>.
 * 3. POST /api/auth/exchange { code } → { playerId, playerToken, ... } (com el login per correu).
 */
export const GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth";
export const GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token";
export const GOOGLE_JWKS_URL = "https://www.googleapis.com/oauth2/v3/certs";
export const GOOGLE_ISSUERS = ["https://accounts.google.com", "accounts.google.com"];
export const GOOGLE_STATE_TTL_MS = 10 * 60 * 1000;
export const GOOGLE_STATE_COOKIE = "sm_g_state";
export const GOOGLE_CALLBACK_PATH = "/api/auth/google/callback";
const CLOCK_SKEW_S = 60;
const MAX_PENDING = 20_000;

type Env = NodeJS.ProcessEnv | Record<string, string | undefined>;

export function googleConfig(env: Env = process.env): { clientId: string; clientSecret: string; redirectUri: string } | null {
  const clientId = (env.GOOGLE_CLIENT_ID ?? "").trim();
  const clientSecret = (env.GOOGLE_CLIENT_SECRET ?? "").trim();
  if (!clientId || !clientSecret) return null;
  return { clientId, clientSecret, redirectUri: `${publicBaseUrl(env)}${GOOGLE_CALLBACK_PATH}` };
}

let fetchImpl: typeof fetch = (input, init) => fetch(input, init);
export function setGoogleFetchForTests(f: typeof fetch | null): void {
  fetchImpl = f ?? ((input, init) => fetch(input, init));
  jwksCache = null;
}

type PendingState = {
  binder: string;
  verifier: string;
  nonce: string;
  exp: number;
  ageConfirmed: boolean;
  current: CurrentPlayer;
};
const states = new Map<string, PendingState>();
const startLimiter = new FixedWindowLimiter(20, 15 * 60 * 1000);

function b64urlSha256(s: string): string {
  return createHash("sha256").update(s).digest("base64url");
}

export function createGoogleAuthRequest(opts: { ageConfirmed: boolean; current: CurrentPlayer; now?: number }):
  | { url: string; binder: string; state: string }
  | null {
  const cfg = googleConfig();
  if (!cfg) return null;
  const now = opts.now ?? Date.now();
  for (const [k, v] of states) if (v.exp <= now) states.delete(k);
  if (states.size >= MAX_PENDING) return null;
  const state = randomBytes(24).toString("base64url");
  const binder = randomBytes(24).toString("base64url");
  const verifier = randomBytes(48).toString("base64url");
  const nonce = randomBytes(24).toString("base64url");
  states.set(state, { binder, verifier, nonce, exp: now + GOOGLE_STATE_TTL_MS, ageConfirmed: opts.ageConfirmed, current: opts.current });
  const q = new URLSearchParams({
    client_id: cfg.clientId,
    redirect_uri: cfg.redirectUri,
    response_type: "code",
    scope: "openid email profile",
    state,
    nonce,
    code_challenge: b64urlSha256(verifier),
    code_challenge_method: "S256",
    prompt: "select_account",
  });
  return { url: `${GOOGLE_AUTH_URL}?${q.toString()}`, binder, state };
}

// --- Verificació de l'ID token ------------------------------------------------

type Jwk = JsonWebKey & { kid?: string; alg?: string; use?: string };
let jwksCache: { keys: Jwk[]; exp: number; fetchedAt: number } | null = null;

async function getJwks(forceRefresh: boolean, now: number): Promise<Jwk[]> {
  if (jwksCache && !forceRefresh && jwksCache.exp > now) return jwksCache.keys;
  if (jwksCache && forceRefresh && now - jwksCache.fetchedAt < 60_000) return jwksCache.keys;
  const res = await fetchImpl(GOOGLE_JWKS_URL, { signal: AbortSignal.timeout(10_000) });
  if (!res.ok) throw new Error(`JWKS HTTP ${res.status}`);
  const body = (await res.json()) as { keys?: Jwk[] };
  const keys = Array.isArray(body.keys) ? body.keys : [];
  const maxAge = Number(/max-age=(\d+)/.exec(res.headers.get("cache-control") ?? "")?.[1] ?? 3600);
  jwksCache = { keys, exp: now + Math.min(Math.max(maxAge, 60), 86_400) * 1000, fetchedAt: now };
  return keys;
}

export type GoogleClaims = {
  sub: string;
  email?: string;
  email_verified?: boolean | string;
  name?: string;
  given_name?: string;
  nonce?: string;
};

export type IdTokenError = "MALFORMED" | "BAD_ALG" | "UNKNOWN_KEY" | "BAD_SIGNATURE" | "BAD_ISSUER" | "BAD_AUDIENCE" | "EXPIRED" | "BAD_NONCE";

export async function verifyGoogleIdToken(
  idToken: unknown,
  opts: { clientId: string; nonce: string; now?: number },
): Promise<{ ok: true; claims: GoogleClaims } | { ok: false; error: IdTokenError }> {
  const now = opts.now ?? Date.now();
  if (typeof idToken !== "string" || idToken.length > 8192) return { ok: false, error: "MALFORMED" };
  const parts = idToken.split(".");
  if (parts.length !== 3) return { ok: false, error: "MALFORMED" };
  let header: { alg?: string; kid?: string };
  let payload: Record<string, unknown>;
  try {
    header = JSON.parse(Buffer.from(parts[0]!, "base64url").toString("utf8"));
    payload = JSON.parse(Buffer.from(parts[1]!, "base64url").toString("utf8"));
  } catch {
    return { ok: false, error: "MALFORMED" };
  }
  if (header.alg !== "RS256") return { ok: false, error: "BAD_ALG" };
  let keys = await getJwks(false, now);
  let jwk = keys.find((k) => k.kid === header.kid);
  if (!jwk) {
    keys = await getJwks(true, now);
    jwk = keys.find((k) => k.kid === header.kid);
  }
  if (!jwk || jwk.kty !== "RSA") return { ok: false, error: "UNKNOWN_KEY" };
  let valid = false;
  try {
    const key = createPublicKey({ key: jwk, format: "jwk" });
    valid = cryptoVerify("RSA-SHA256", Buffer.from(`${parts[0]}.${parts[1]}`), key, Buffer.from(parts[2]!, "base64url"));
  } catch {
    valid = false;
  }
  if (!valid) return { ok: false, error: "BAD_SIGNATURE" };
  if (typeof payload.iss !== "string" || !GOOGLE_ISSUERS.includes(payload.iss)) return { ok: false, error: "BAD_ISSUER" };
  const aud = payload.aud;
  const audOk = Array.isArray(aud) ? aud.includes(opts.clientId) && payload.azp === opts.clientId : aud === opts.clientId;
  if (!audOk) return { ok: false, error: "BAD_AUDIENCE" };
  const nowS = Math.floor(now / 1000);
  if (typeof payload.exp !== "number" || payload.exp + CLOCK_SKEW_S < nowS) return { ok: false, error: "EXPIRED" };
  if (typeof payload.iat === "number" && payload.iat - CLOCK_SKEW_S > nowS) return { ok: false, error: "EXPIRED" };
  if (typeof payload.nonce !== "string" || payload.nonce !== opts.nonce) return { ok: false, error: "BAD_NONCE" };
  if (typeof payload.sub !== "string" || !payload.sub) return { ok: false, error: "MALFORMED" };
  return { ok: true, claims: payload as unknown as GoogleClaims };
}

// --- Callback ---------------------------------------------------------------

export type GoogleCallbackError =
  | "DISABLED"
  | "ACCESS_DENIED"
  | "BAD_STATE"
  | "STATE_MISMATCH"
  | "TOKEN_EXCHANGE_FAILED"
  | "BAD_ID_TOKEN"
  | "AGE_CONFIRMATION_REQUIRED"
  | "INTERNAL";

export async function handleGoogleCallback(input: {
  code: unknown;
  state: unknown;
  error?: unknown;
  binderCookie: string | null;
  current: CurrentPlayer;
  now?: number;
}): Promise<{ ok: true; resultCode: string } | { ok: false; error: GoogleCallbackError }> {
  const cfg = googleConfig();
  if (!cfg) return { ok: false, error: "DISABLED" };
  const now = input.now ?? Date.now();
  const stateKey = typeof input.state === "string" ? input.state : "";
  const st = stateKey ? states.get(stateKey) : undefined;
  if (stateKey) states.delete(stateKey); // un sol ús, també si falla
  if (input.error) return { ok: false, error: "ACCESS_DENIED" };
  if (!st || st.exp <= now) return { ok: false, error: "BAD_STATE" };
  const a = Buffer.from(input.binderCookie ?? "");
  const b = Buffer.from(st.binder);
  if (a.length !== b.length || !timingSafeEqual(a, b)) return { ok: false, error: "STATE_MISMATCH" };
  if (typeof input.code !== "string" || !input.code || input.code.length > 2048) return { ok: false, error: "TOKEN_EXCHANGE_FAILED" };

  let idToken: unknown;
  try {
    const res = await fetchImpl(GOOGLE_TOKEN_URL, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        code: input.code,
        client_id: cfg.clientId,
        client_secret: cfg.clientSecret,
        redirect_uri: cfg.redirectUri,
        grant_type: "authorization_code",
        code_verifier: st.verifier,
      }).toString(),
      signal: AbortSignal.timeout(10_000),
    });
    const body = (await res.json().catch(() => null)) as { id_token?: unknown; error?: unknown } | null;
    if (!res.ok || !body?.id_token) {
      console.warn(`[auth] google token exchange HTTP ${res.status} ${typeof body?.error === "string" ? body.error : ""}`);
      return { ok: false, error: "TOKEN_EXCHANGE_FAILED" };
    }
    idToken = body.id_token;
  } catch (err) {
    console.warn(`[auth] google token exchange: ${err instanceof Error ? err.name : "error"}`);
    return { ok: false, error: "TOKEN_EXCHANGE_FAILED" };
  }

  let verified;
  try {
    verified = await verifyGoogleIdToken(idToken, { clientId: cfg.clientId, nonce: st.nonce, now });
  } catch (err) {
    console.warn(`[auth] google JWKS: ${err instanceof Error ? err.message : "error"}`);
    return { ok: false, error: "BAD_ID_TOKEN" };
  }
  if ("error" in verified) {
    console.warn(`[auth] google id_token rebutjat: ${verified.error}`);
    return { ok: false, error: "BAD_ID_TOKEN" };
  }
  const c = verified.claims;
  const emailVerified = c.email_verified === true || c.email_verified === "true";
  const current = input.current ?? st.current;
  const login = await loginWithIdentity({
    kind: "google",
    googleSub: c.sub,
    email: emailVerified && typeof c.email === "string" ? c.email : null,
    current,
    allowCreate: st.ageConfirmed,
    now,
  });
  if ("error" in login) return { ok: false, error: login.error === "AGE_CONFIRMATION_REQUIRED" ? login.error : "INTERNAL" };
  if (login.created) {
    notifySignupLater({
      playerId: login.playerId,
      method: "google",
      displayName: (c.given_name || c.name || "").toString(),
      email: emailVerified ? c.email : null,
    });
  }
  const resultCode = mintResultCode({
    playerId: login.playerId,
    method: "google",
    created: login.created,
    linked: login.linked,
    switchedAccount: !!login.switchedFrom,
  });
  return { ok: true, resultCode };
}

// --- Galetes i rutes ----------------------------------------------------------

export function readCookie(header: unknown, name: string): string | null {
  if (typeof header !== "string") return null;
  for (const part of header.split(";")) {
    const i = part.indexOf("=");
    if (i < 0) continue;
    if (part.slice(0, i).trim() === name) {
      const v = part.slice(i + 1).trim();
      return /^[A-Za-z0-9_-]{1,100}$/.test(v) ? v : null;
    }
  }
  return null;
}

function stateCookie(value: string, maxAgeS: number): string {
  const secure = publicBaseUrl().startsWith("https:") ? "; Secure" : "";
  return `${GOOGLE_STATE_COOKIE}=${value}; Path=/api/auth/google; HttpOnly; SameSite=Lax; Max-Age=${maxAgeS}${secure}`;
}

const exchangeFailLimiter = new FixedWindowLimiter(20, 15 * 60 * 1000);

export function registerGoogleAuthRoutes(app: Express): void {
  registerProviderFlags(() => ({ google: !!googleConfig() }));

  const start = (req: Request, res: Response, mode: "json" | "redirect") => {
    if (!googleConfig()) return sendAuthError(res, 404, "DISABLED", "L'inici de sessió amb Google no està activat.");
    if (mode === "json" && !originAllowed(req)) return sendAuthError(res, 403, "BAD_ORIGIN", "Origen no permès.");
    if (!startLimiter.hit(rateKey(req))) return sendAuthError(res, 429, "RATE_LIMIT", "Massa intents. Espera uns minuts.", 900);
    const ageConfirmed = bool(req.body?.ageConfirmed ?? req.query?.ageConfirmed);
    const r = createGoogleAuthRequest({ ageConfirmed, current: mode === "json" ? currentPlayer(req) : null });
    if (!r) return sendAuthError(res, 503, "RATE_LIMIT", "Massa peticions. Torna-ho a provar.");
    res.setHeader("Set-Cookie", stateCookie(r.binder, Math.floor(GOOGLE_STATE_TTL_MS / 1000)));
    if (mode === "json") return void res.json({ url: r.url });
    res.redirect(302, r.url);
  };
  app.post("/api/auth/google/start", (req, res) => start(req, res, "json"));
  app.get("/api/auth/google/start", (req, res) => start(req, res, "redirect"));

  app.get(GOOGLE_CALLBACK_PATH, async (req: Request, res: Response) => {
    res.setHeader("Set-Cookie", stateCookie("", 0));
    res.setHeader("Referrer-Policy", "no-referrer");
    const base = `${publicBaseUrl()}/login/google`;
    let r: Awaited<ReturnType<typeof handleGoogleCallback>>;
    try {
      r = await handleGoogleCallback({
        code: req.query.code,
        state: req.query.state,
        error: req.query.error,
        binderCookie: readCookie(req.headers.cookie, GOOGLE_STATE_COOKIE),
        current: null,
      });
    } catch (err) {
      console.error("[auth] google callback:", err instanceof Error ? err.message : err);
      r = { ok: false, error: "INTERNAL" };
    }
    if ("error" in r) {
      if (r.error !== "ACCESS_DENIED") console.warn(`[auth] google callback error=${r.error}`);
      return void res.redirect(303, `${base}#error=${r.error}`);
    }
    res.redirect(303, `${base}#code=${encodeURIComponent(r.resultCode)}`);
  });

  app.post("/api/auth/exchange", (req: Request, res: Response) => {
    if (!originAllowed(req)) return sendAuthError(res, 403, "BAD_ORIGIN", "Origen no permès.");
    const key = rateKey(req);
    if (exchangeFailLimiter.blocked(key)) return sendAuthError(res, 429, "RATE_LIMIT", "Massa intents. Espera uns minuts.", 900);
    const result = consumeResultCode(req.body?.code);
    if (!result) {
      exchangeFailLimiter.hit(key);
      return sendAuthError(res, 410, "EXPIRED_OR_USED", "Aquest inici de sessió ha caducat o ja s'ha fet servir. Torna-ho a provar.");
    }
    const body = buildAuthSuccess(result.playerId, result.method, {
      created: result.created,
      linked: result.linked,
      switchedFrom: result.switchedAccount ? "x" : undefined,
    });
    if (!body) return sendAuthError(res, 400, "BAD_IDENTITY", "Identitat no vàlida.");
    res.json(body);
  });
}

export function resetGoogleAuthForTests(): void {
  states.clear();
  startLimiter.reset();
  exchangeFailLimiter.reset();
  jwksCache = null;
}
