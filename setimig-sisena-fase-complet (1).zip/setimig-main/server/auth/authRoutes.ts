import { clearSessionCookie } from "../sessionCookie.ts";
import type { Express, Request, Response } from "express";
import { notifySignupLater } from "../mail/signupNotice.ts";
import {
  bool,
  buildAuthSuccess,
  currentPlayer,
  originAllowed,
  rateKey,
  sendAuthError,
  tokenPlayer,
} from "./authCommon.ts";
import { consumeEmailChallenge, emailLoginAvailable, resolveMailLocale, startEmailLogin, verifyEmailLogin } from "./emailLogin.ts";
import { getIdentitySummary, loginWithIdentity } from "./identityStore.ts";
import { deleteAccount } from "../accountDeletion.ts";
import { readTokenFromAuthHeader, verifyPlayerToken } from "../playerToken.ts";
import { readSessionCookie } from "../sessionCookie.ts";
import { revokePresentedToken } from "../revokedTokens.ts";
import { disconnectSocketsWithToken } from "../requireLogin.ts";

/**
 * Rutes d'inici de sessió (totes sota /api/auth/). Contracte per al client a docs/auth-contracte.md.
 * Les respostes d'èxit retornen el MATEIX parell { playerId, playerToken } que /api/player-session:
 * el client el desa a setimig_player_id / setimig_player_token com sempre.
 */

/** Proveïdors extra (Google, passkeys) que s'hi afegeixen des dels seus mòduls. */
const providerFlags: Array<() => Record<string, unknown>> = [];

export function registerProviderFlags(fn: () => Record<string, unknown>): void {
  providerFlags.push(fn);
}

export const ACCOUNT_DELETE_CONFIRM = "DELETE_MY_ACCOUNT";

function badOrigin(res: Response): void {
  sendAuthError(res, 403, "BAD_ORIGIN", "Origen no permès.");
}

const EMAIL_ERRORS: Record<string, [number, string]> = {
  BAD_EMAIL: [400, "Correu no vàlid."],
  RATE_LIMIT: [429, "Massa intents. Espera uns minuts."],
  UNAVAILABLE: [503, "L'inici de sessió per correu no està disponible ara mateix."],
  BAD_REQUEST: [400, "Petició no vàlida."],
  INVALID_CODE: [400, "Codi incorrecte."],
  EXPIRED_OR_USED: [410, "El codi o l'enllaç ha caducat o ja s'ha fet servir. Demana'n un de nou."],
  AGE_CONFIRMATION_REQUIRED: [403, "Cal confirmar que tens 18 anys o més per crear un compte."],
  BAD_IDENTITY: [400, "Identitat no vàlida."],
};

function emailError(res: Response, code: string, retryAfterSec?: number): void {
  const [status, msg] = EMAIL_ERRORS[code] ?? [400, "Error."];
  sendAuthError(res, status, code, msg, code === "RATE_LIMIT" ? (retryAfterSec ?? 900) : undefined);
}

export function registerAuthRoutes(app: Express): void {
  app.get("/api/auth/providers", (_req: Request, res: Response) => {
    const flags: Record<string, unknown> = { email: emailLoginAvailable(), google: false, passkey: false };
    for (const fn of providerFlags) Object.assign(flags, fn());
    res.json(flags);
  });

  const sendMe = async (req: Request, res: Response) => {
    // `tokenPlayer` passa per `verifyPlayerToken`, que rebutja un token de la llista de revocats.
    const playerId = tokenPlayer(req);
    if (!playerId) return sendAuthError(res, 401, "AUTH_REQUIRED", "Cal una sessió amb token.");
    try {
      const s = await getIdentitySummary(playerId);
      res.json({ playerId, emails: s.emails, google: s.google, passkeys: s.passkeys, verified: s.emails.length > 0 || s.google || s.passkeys > 0 });
    } catch (err) {
      console.error("[auth] me:", err instanceof Error ? err.message : err);
      sendAuthError(res, 500, "INTERNAL", "Error intern. Torna-ho a provar.");
    }
  };
  app.get("/api/auth/me", (req, res) => void sendMe(req, res));
  // Mateixa sessió, fora del prefix obert /api/auth: el middleware de login també rebutja el token revocat.
  app.get("/api/me", (req, res) => void sendMe(req, res));

  /**
   * Esborrat del compte propi (perfil). Cal el token (Authorization: Bearer) i la confirmació
   * explícita al cos: { "confirm": "DELETE_MY_ACCOUNT" }. Després, el token deixa de valer.
   */
  // Tanca la sessió al servidor: esborra la galeta setimig_session (el client esborra localStorage).
  // Revoca el Bearer i la galeta, i la cadena renovada d'aquesta sessió (no els altres dispositius).
  app.post("/api/auth/logout", async (req: Request, res: Response) => {
    res.setHeader("Cache-Control", "no-store");
    clearSessionCookie(res);
    const tokens = new Set([readTokenFromAuthHeader(req.headers.authorization), readSessionCookie(req)]);
    try {
      for (const t of tokens) {
        const v = t ? verifyPlayerToken(t) : null;
        if (!t || !v) continue;
        await revokePresentedToken(t, v.exp, v.sid);
        disconnectSocketsWithToken(t, v.sid);
      }
    } catch (err) {
      console.error("[auth] logout:", err instanceof Error ? err.message : err);
      return sendAuthError(res, 500, "INTERNAL", "Error intern. Torna-ho a provar.");
    }
    res.json({ ok: true });
  });

  app.post("/api/account/delete", async (req: Request, res: Response) => {
    if (!originAllowed(req)) return badOrigin(res);
    const playerId = tokenPlayer(req);
    if (!playerId) return sendAuthError(res, 401, "AUTH_REQUIRED", "Cal una sessió amb token.");
    if (req.body?.confirm !== ACCOUNT_DELETE_CONFIRM) {
      return sendAuthError(res, 400, "CONFIRMATION_REQUIRED", `Cal confirmar amb confirm: "${ACCOUNT_DELETE_CONFIRM}".`);
    }
    try {
      await deleteAccount(playerId);
      clearSessionCookie(res);
      console.log("[auth] compte esborrat a petició del jugador");
      res.json({ ok: true, deleted: true });
    } catch (err) {
      console.error("[auth] account delete:", err instanceof Error ? err.message : err);
      sendAuthError(res, 500, "INTERNAL", "Error intern. Torna-ho a provar.");
    }
  });

  app.post("/api/auth/email/start", (req: Request, res: Response) => {
    if (!originAllowed(req)) return badOrigin(res);
    const r = startEmailLogin({
      email: req.body?.email,
      ip: rateKey(req),
      ageConfirmed: bool(req.body?.ageConfirmed),
      startPlayer: currentPlayer(req),
      locale: resolveMailLocale(req.body?.locale ?? req.body?.lang, req.headers["accept-language"]),
    });
    if ("error" in r) return emailError(res, r.error, r.retryAfterSec);
    res.status(202).json({ ok: true, expiresInSec: 600 });
  });

  app.post("/api/auth/email/verify", async (req: Request, res: Response) => {
    if (!originAllowed(req)) return badOrigin(res);
    const v = verifyEmailLogin({
      email: req.body?.email,
      code: req.body?.code,
      linkToken: req.body?.linkToken,
      ip: rateKey(req),
      consume: false,
    });
    if ("error" in v) return emailError(res, v.error);
    const allowCreate = v.ageConfirmed || bool(req.body?.ageConfirmed);
    // Amb 18+ confirmat es consumeix ja (abans de cap await), com sempre. Sense, el repte es deixa viu
    // fins saber si cal crear compte: si respon AGE_CONFIRMATION_REQUIRED, el client pot tornar a
    // enviar el MATEIX codi amb ageConfirmed=true (registre amb un sol correu).
    if (allowCreate) consumeEmailChallenge(v.challengeId);
    try {
      const current = currentPlayer(req) ?? v.startPlayer;
      const login = await loginWithIdentity({
        kind: "email",
        email: v.email,
        current,
        allowCreate,
      });
      if (!allowCreate && !("error" in login && login.error === "AGE_CONFIRMATION_REQUIRED")) {
        consumeEmailChallenge(v.challengeId);
      }
      if ("error" in login) return emailError(res, login.error);
      const body = buildAuthSuccess(login.playerId, "email", login);
      if (!body) return emailError(res, "BAD_IDENTITY");
      if (login.created) notifySignupLater({ playerId: login.playerId, method: "email", email: v.email });
      res.json(body);
    } catch (err) {
      console.error("[auth] email verify:", err instanceof Error ? err.message : err);
      sendAuthError(res, 500, "INTERNAL", "Error intern. Torna-ho a provar.");
    }
  });
}
