import { randomBytes } from "node:crypto";
import type { Express, Request, Response } from "express";
import {
  generateAuthenticationOptions,
  generateRegistrationOptions,
  verifyAuthenticationResponse,
  verifyRegistrationResponse,
} from "@simplewebauthn/server";
import { sanitizePlayerId } from "../balances.ts";
import { getProfile } from "../profiles.ts";
import { buildAuthSuccess, currentPlayer, FixedWindowLimiter, originAllowed, publicBaseUrl, rateKey, sendAuthError, tokenPlayer } from "./authCommon.ts";
import { registerProviderFlags } from "./authRoutes.ts";
import { __internal, type StoredPasskey } from "./identityStore.ts";

/**
 * Passkeys WebAuthn (Face ID / Touch ID / Windows Hello / clau del gestor de contrasenyes).
 *
 * - Registre des del perfil amb una sessió activa (token): /api/auth/passkey/register/{options,verify}.
 * - Entrada amb un toc (credencials «discoverable», sense correu): /api/auth/passkey/login/{options,verify}.
 * - Llista i esborrat: GET /api/auth/passkeys, DELETE /api/auth/passkeys/:id.
 * - rpId: WEBAUTHN_RP_ID (per defecte sevenhalf.club); orígens: WEBAUTHN_ORIGIN (llista separada per
 *   comes, per defecte https://sevenhalf.club).
 * - Reptes d'un sol ús de 5 minuts; verificació d'usuari obligatòria (UV); comptador de signatures
 *   (un comptador que no avança es rebutja: possible clon).
 * - Una passkey només permet entrar en un compte existent: mai en crea cap.
 */
export const PASSKEY_CHALLENGE_TTL_MS = 5 * 60 * 1000;
export const MAX_PASSKEYS_PER_PLAYER = 10;
const RP_NAME = "Seven Half Club";
const MAX_PENDING = 20_000;

type Env = NodeJS.ProcessEnv | Record<string, string | undefined>;

export function webauthnConfig(env: Env = process.env): { rpID: string; origins: string[] } {
  const base = publicBaseUrl(env);
  const rpID = (env.WEBAUTHN_RP_ID ?? "").trim().toLowerCase() || new URL(base).hostname;
  const origins = (env.WEBAUTHN_ORIGIN ?? "")
    .split(",")
    .map((s) => s.trim().replace(/\/+$/, ""))
    .filter(Boolean);
  return { rpID, origins: origins.length ? origins : [base] };
}

const regChallenges = new Map<string, { challenge: string; exp: number }>();
const loginChallenges = new Map<string, { challenge: string; exp: number }>();
const optionsLimiter = new FixedWindowLimiter(30, 15 * 60 * 1000);
const loginFailLimiter = new FixedWindowLimiter(20, 15 * 60 * 1000);

function prune(map: Map<string, { exp: number }>, now: number): void {
  for (const [k, v] of map) if (v.exp <= now) map.delete(k);
}

function b64urlToBytes(s: string): Uint8Array<ArrayBuffer> {
  const b = Buffer.from(s, "base64url");
  const out = new Uint8Array(new ArrayBuffer(b.length));
  out.set(b);
  return out;
}

function bytesToB64url(u: Uint8Array): string {
  return Buffer.from(u).toString("base64url");
}

function cleanName(raw: unknown): string {
  const s = typeof raw === "string" ? raw.replace(/[\u0000-\u001f\u007f<>]/g, "").trim().slice(0, 40) : "";
  return s || "Passkey";
}

export type PasskeyView = {
  id: string;
  name: string;
  createdAt: number;
  lastUsedAt: number | null;
  deviceType: string | null;
  backedUp: boolean;
};

function view(id: string, k: StoredPasskey): PasskeyView {
  return {
    id,
    name: k.name,
    createdAt: k.createdAt,
    lastUsedAt: k.lastUsedAt ?? null,
    deviceType: k.deviceType ?? null,
    backedUp: !!k.backedUp,
  };
}

export async function passkeyRegistrationOptions(playerIdRaw: unknown, now = Date.now()) {
  const playerId = sanitizePlayerId(playerIdRaw);
  if (!playerId) return null;
  const { rpID } = webauthnConfig();
  const { load, save, serial } = __internal;
  const { userIdB64, existing, userName } = await serial(async () => {
    const store = await load();
    const p = (store.players[playerId] ??= {});
    let dirty = false;
    if (!p.webauthnUserId) {
      p.webauthnUserId = randomBytes(32).toString("base64url");
      dirty = true;
    }
    if (dirty) await save(store);
    const existing = Object.entries(store.passkeys)
      .filter(([, k]) => k.playerId === playerId)
      .map(([id, k]) => ({ id, transports: k.transports }));
    return { userIdB64: p.webauthnUserId, existing, userName: p.emails?.[0] ?? null };
  });
  if (existing.length >= MAX_PASSKEYS_PER_PLAYER) return { error: "TOO_MANY" as const };
  const profile = await getProfile(playerId).catch(() => null);
  const displayName = profile?.displayName?.trim() || "Jugador";
  const options = await generateRegistrationOptions({
    rpName: RP_NAME,
    rpID,
    userID: b64urlToBytes(userIdB64),
    userName: userName ?? displayName,
    userDisplayName: displayName,
    attestationType: "none",
    excludeCredentials: existing.map((c) => ({ id: c.id, transports: c.transports as never })),
    authenticatorSelection: { residentKey: "required", userVerification: "required" },
    timeout: PASSKEY_CHALLENGE_TTL_MS,
  });
  prune(regChallenges, now);
  regChallenges.set(playerId, { challenge: options.challenge, exp: now + PASSKEY_CHALLENGE_TTL_MS });
  return { options };
}

export type PasskeyError =
  | "NO_CHALLENGE"
  | "VERIFICATION_FAILED"
  | "ALREADY_REGISTERED"
  | "TOO_MANY"
  | "UNKNOWN_CREDENTIAL"
  | "RATE_LIMIT"
  | "NOT_FOUND";

export async function passkeyRegistrationVerify(
  playerIdRaw: unknown,
  response: unknown,
  nameRaw: unknown,
  now = Date.now(),
): Promise<{ ok: true; passkey: PasskeyView } | { ok: false; error: PasskeyError }> {
  const playerId = sanitizePlayerId(playerIdRaw);
  if (!playerId) return { ok: false, error: "VERIFICATION_FAILED" };
  const ch = regChallenges.get(playerId);
  regChallenges.delete(playerId);
  if (!ch || ch.exp <= now) return { ok: false, error: "NO_CHALLENGE" };
  const { rpID, origins } = webauthnConfig();
  let result;
  try {
    result = await verifyRegistrationResponse({
      response: response as never,
      expectedChallenge: ch.challenge,
      expectedOrigin: origins,
      expectedRPID: rpID,
      requireUserVerification: true,
    });
  } catch (err) {
    console.warn(`[auth] passkey registre rebutjat: ${err instanceof Error ? err.message.slice(0, 120) : "error"}`);
    return { ok: false, error: "VERIFICATION_FAILED" };
  }
  if (!result.verified || !result.registrationInfo) return { ok: false, error: "VERIFICATION_FAILED" };
  const info = result.registrationInfo;
  const cred = info.credential;
  const { load, save, serial, logEntry } = __internal;
  return serial(async () => {
    const store = await load();
    if (store.passkeys[cred.id]) return { ok: false as const, error: "ALREADY_REGISTERED" as const };
    const count = Object.values(store.passkeys).filter((k) => k.playerId === playerId).length;
    if (count >= MAX_PASSKEYS_PER_PLAYER) return { ok: false as const, error: "TOO_MANY" as const };
    const stored: StoredPasskey = {
      playerId,
      publicKey: bytesToB64url(cred.publicKey),
      counter: cred.counter,
      transports: Array.isArray(cred.transports) ? cred.transports.map(String) : undefined,
      deviceType: info.credentialDeviceType,
      backedUp: info.credentialBackedUp,
      name: cleanName(nameRaw),
      createdAt: now,
    };
    store.passkeys[cred.id] = stored;
    store.players[playerId] ??= {};
    logEntry(store, { at: now, type: "passkey_added", kind: "passkey", playerId });
    await save(store);
    return { ok: true as const, passkey: view(cred.id, stored) };
  });
}

export async function passkeyLoginOptions(ip: string, now = Date.now()) {
  if (!optionsLimiter.hit(ip, now)) return { error: "RATE_LIMIT" as const };
  prune(loginChallenges, now);
  if (loginChallenges.size >= MAX_PENDING) return { error: "RATE_LIMIT" as const };
  const { rpID } = webauthnConfig();
  const options = await generateAuthenticationOptions({
    rpID,
    userVerification: "required",
    allowCredentials: [],
    timeout: PASSKEY_CHALLENGE_TTL_MS,
  });
  const challengeId = randomBytes(16).toString("base64url");
  loginChallenges.set(challengeId, { challenge: options.challenge, exp: now + PASSKEY_CHALLENGE_TTL_MS });
  return { options, challengeId };
}

export async function passkeyLoginVerify(
  challengeId: unknown,
  response: unknown,
  ip: string,
  now = Date.now(),
): Promise<{ ok: true; playerId: string } | { ok: false; error: PasskeyError }> {
  if (loginFailLimiter.blocked(ip, now)) return { ok: false, error: "RATE_LIMIT" };
  const fail = (error: PasskeyError) => {
    loginFailLimiter.hit(ip, now);
    return { ok: false as const, error };
  };
  const ch = typeof challengeId === "string" ? loginChallenges.get(challengeId) : undefined;
  if (typeof challengeId === "string") loginChallenges.delete(challengeId);
  if (!ch || ch.exp <= now) return fail("NO_CHALLENGE");
  const credId = (response as { id?: unknown } | null)?.id;
  if (typeof credId !== "string" || credId.length > 1024) return fail("UNKNOWN_CREDENTIAL");
  const { load, save, serial } = __internal;
  const store = await load();
  const stored = store.passkeys[credId];
  if (!stored) return fail("UNKNOWN_CREDENTIAL");
  const { rpID, origins } = webauthnConfig();
  let result;
  try {
    result = await verifyAuthenticationResponse({
      response: response as never,
      expectedChallenge: ch.challenge,
      expectedOrigin: origins,
      expectedRPID: rpID,
      credential: {
        id: credId,
        publicKey: b64urlToBytes(stored.publicKey),
        counter: stored.counter,
        transports: stored.transports as never,
      },
      requireUserVerification: true,
    });
  } catch (err) {
    console.warn(`[auth] passkey login rebutjat: ${err instanceof Error ? err.message.slice(0, 120) : "error"}`);
    return fail("VERIFICATION_FAILED");
  }
  if (!result.verified) return fail("VERIFICATION_FAILED");
  const newCounter = result.authenticationInfo.newCounter;
  return serial(async () => {
    const s = await load();
    const k = s.passkeys[credId];
    if (!k) return { ok: false as const, error: "UNKNOWN_CREDENTIAL" as const };
    // Protecció anti-clon: si el comptador és actiu, ha d'avançar (comprovat també dins la cua).
    if (newCounter > 0 && newCounter <= k.counter) return { ok: false as const, error: "VERIFICATION_FAILED" as const };
    k.counter = newCounter;
    k.lastUsedAt = now;
    await save(s);
    return { ok: true as const, playerId: k.playerId };
  });
}

export async function listPasskeys(playerIdRaw: unknown): Promise<PasskeyView[]> {
  const playerId = sanitizePlayerId(playerIdRaw);
  if (!playerId) return [];
  const store = await __internal.load();
  return Object.entries(store.passkeys)
    .filter(([, k]) => k.playerId === playerId)
    .map(([id, k]) => view(id, k))
    .sort((a, b) => a.createdAt - b.createdAt);
}

export async function removePasskey(playerIdRaw: unknown, credId: unknown, now = Date.now()): Promise<boolean> {
  const playerId = sanitizePlayerId(playerIdRaw);
  if (!playerId || typeof credId !== "string") return false;
  const { load, save, serial, logEntry } = __internal;
  return serial(async () => {
    const store = await load();
    const k = store.passkeys[credId];
    if (!k || k.playerId !== playerId) return false;
    delete store.passkeys[credId];
    logEntry(store, { at: now, type: "passkey_removed", kind: "passkey", playerId });
    await save(store);
    return true;
  });
}

const ERR: Record<PasskeyError | "AUTH_REQUIRED", [number, string]> = {
  AUTH_REQUIRED: [401, "Cal haver entrat per gestionar les passkeys."],
  NO_CHALLENGE: [400, "La petició ha caducat. Torna-ho a provar."],
  VERIFICATION_FAILED: [400, "No s'ha pogut verificar la passkey."],
  ALREADY_REGISTERED: [409, "Aquesta passkey ja està registrada."],
  TOO_MANY: [409, `Com a màxim ${MAX_PASSKEYS_PER_PLAYER} passkeys per compte.`],
  UNKNOWN_CREDENTIAL: [404, "Aquesta passkey no correspon a cap compte."],
  RATE_LIMIT: [429, "Massa intents. Espera uns minuts."],
  NOT_FOUND: [404, "No s'ha trobat la passkey."],
};

function err(res: Response, code: keyof typeof ERR): void {
  const [status, msg] = ERR[code];
  sendAuthError(res, status, code, msg, code === "RATE_LIMIT" ? 900 : undefined);
}

export function registerPasskeyRoutes(app: Express): void {
  registerProviderFlags(() => ({ passkey: true, rpId: webauthnConfig().rpID }));

  app.post("/api/auth/passkey/register/options", async (req: Request, res: Response) => {
    if (!originAllowed(req)) return sendAuthError(res, 403, "BAD_ORIGIN", "Origen no permès.");
    const playerId = tokenPlayer(req);
    if (!playerId) return err(res, "AUTH_REQUIRED");
    try {
      const r = await passkeyRegistrationOptions(playerId);
      if (!r) return err(res, "AUTH_REQUIRED");
      if ("error" in r) return err(res, r.error);
      res.json(r.options);
    } catch (e) {
      console.error("[auth] passkey options:", e instanceof Error ? e.message : e);
      sendAuthError(res, 500, "INTERNAL", "Error intern. Torna-ho a provar.");
    }
  });

  app.post("/api/auth/passkey/register/verify", async (req: Request, res: Response) => {
    if (!originAllowed(req)) return sendAuthError(res, 403, "BAD_ORIGIN", "Origen no permès.");
    const playerId = tokenPlayer(req);
    if (!playerId) return err(res, "AUTH_REQUIRED");
    try {
      const r = await passkeyRegistrationVerify(playerId, req.body?.response, req.body?.name);
      if ("error" in r) return err(res, r.error);
      res.json({ ok: true, passkey: r.passkey });
    } catch (e) {
      console.error("[auth] passkey verify:", e instanceof Error ? e.message : e);
      sendAuthError(res, 500, "INTERNAL", "Error intern. Torna-ho a provar.");
    }
  });

  app.post("/api/auth/passkey/login/options", async (req: Request, res: Response) => {
    if (!originAllowed(req)) return sendAuthError(res, 403, "BAD_ORIGIN", "Origen no permès.");
    try {
      const r = await passkeyLoginOptions(rateKey(req));
      if ("error" in r) return err(res, r.error);
      res.json({ challengeId: r.challengeId, options: r.options });
    } catch (e) {
      console.error("[auth] passkey login options:", e instanceof Error ? e.message : e);
      sendAuthError(res, 500, "INTERNAL", "Error intern. Torna-ho a provar.");
    }
  });

  app.post("/api/auth/passkey/login/verify", async (req: Request, res: Response) => {
    if (!originAllowed(req)) return sendAuthError(res, 403, "BAD_ORIGIN", "Origen no permès.");
    try {
      const r = await passkeyLoginVerify(req.body?.challengeId, req.body?.response, rateKey(req));
      if ("error" in r) return err(res, r.error);
      const cur = currentPlayer(req);
      const switchedFrom = cur && cur.playerId !== r.playerId ? cur.playerId : undefined;
      if (switchedFrom) {
        console.log(`[auth] switch kind=passkey player=${r.playerId.slice(0, 8)} from=${switchedFrom.slice(0, 8)}`);
      }
      const body = buildAuthSuccess(r.playerId, "passkey", { switchedFrom });
      if (!body) return err(res, "UNKNOWN_CREDENTIAL");
      res.json(body);
    } catch (e) {
      console.error("[auth] passkey login verify:", e instanceof Error ? e.message : e);
      sendAuthError(res, 500, "INTERNAL", "Error intern. Torna-ho a provar.");
    }
  });

  app.get("/api/auth/passkeys", async (req: Request, res: Response) => {
    const playerId = tokenPlayer(req);
    if (!playerId) return err(res, "AUTH_REQUIRED");
    res.json({ passkeys: await listPasskeys(playerId) });
  });

  app.delete("/api/auth/passkeys/:id", async (req: Request, res: Response) => {
    if (!originAllowed(req)) return sendAuthError(res, 403, "BAD_ORIGIN", "Origen no permès.");
    const playerId = tokenPlayer(req);
    if (!playerId) return err(res, "AUTH_REQUIRED");
    const ok = await removePasskey(playerId, req.params.id);
    if (!ok) return err(res, "NOT_FOUND");
    res.json({ ok: true });
  });
}

export function resetPasskeysForTests(): void {
  regChallenges.clear();
  loginChallenges.clear();
  optionsLimiter.reset();
  loginFailLimiter.reset();
}
