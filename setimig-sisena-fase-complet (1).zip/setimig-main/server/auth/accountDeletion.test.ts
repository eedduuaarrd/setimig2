import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import fs from "node:fs";
import { createServer, type Server } from "node:http";
import type { AddressInfo } from "node:net";
import os from "node:os";
import path from "node:path";
import express from "express";

/**
 * Esborrat de compte (endpoint + funció compartida): el token deixa de valer, no queda res del
 * compte, els altres jugadors queden intactes, i és idempotent.
 */
const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), "setimig-esborrat-"));
process.env.BALANCE_DATA_DIR = dataDir;
process.env.PROFILE_DATA_DIR = path.join(dataDir, "profiles");
process.env.SETIMIG_WRITE_COALESCE_MS = "0";
process.env.SETIMIG_ANALYTICS_SALT = "sal-de-prova-0123456789abcdef";
process.env.PUBLIC_BASE_URL = "https://sevenhalf.club";

const { setMailTransportForTests } = await import("../mail/mailer.ts");
const { registerAuthRoutes } = await import("./authRoutes.ts");
const { loginWithIdentity, emailOwner, __internal } = await import("./identityStore.ts");
const { issuePlayerToken, verifyPlayerToken, resolvePlayerIdFromParts } = await import("../playerToken.ts");
const { setBalance, getAccountEntry, flushBalanceWrites, addBalance } = await import("../balances.ts");
const { upsertProfile } = await import("../profiles.ts");
const { addWeeklyChipsWon, withEngagement, flushWeeklyWrites } = await import("../achievementsStore.ts");
const { getOrCreatePlayerFriendsRecord, addFriendByCode, listFriendPlayerIds } = await import("../friends/friendsStore.ts");
const { pseudonymousId } = await import("../analytics.ts");
const { deleteAccount, inspectAccount } = await import("../accountDeletion.ts");
const { isAccountDeleted } = await import("../deletedAccounts.ts");

const A = "a".repeat(8) + "-esborrat-0001";
const B = "b".repeat(8) + "-altre-0002";
const WEEK = "2026-W44";

let server: Server;
let base = "";
const files = {
  profileB: path.join(dataDir, "profiles", `${B}.json`),
};

function silence<T>(fn: () => Promise<T>): Promise<T> {
  const o = console.log;
  console.log = () => undefined;
  return fn().finally(() => {
    console.log = o;
  });
}

async function post(p: string, body: unknown, token?: string) {
  const res = await fetch(base + p, {
    method: "POST",
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: JSON.stringify(body),
  });
  return { status: res.status, body: (await res.json()) as Record<string, unknown> };
}

function readJson(rel: string): any {
  return JSON.parse(fs.readFileSync(path.join(dataDir, rel), "utf8"));
}

before(async () => {
  setMailTransportForTests(async () => ({ ok: true, provider: "log", delivered: false }));
  const app = express();
  app.use(express.json());
  registerAuthRoutes(app);
  server = createServer(app);
  await new Promise<void>((r) => server.listen(0, "127.0.0.1", r));
  base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;

  // Dos comptes amb dades a tots els magatzems.
  await silence(async () => {
    for (const [id, email] of [
      [A, "a@x.cat"],
      [B, "b@x.cat"],
    ] as const) {
      await loginWithIdentity({ kind: "email", email, current: { playerId: id, legacy: false }, allowCreate: true });
      await upsertProfile(id, { displayName: id === A ? "Esborrable" : "Es queda" });
      await setBalance(id, id === A ? 30_000 : 12_345);
      await addWeeklyChipsWon(WEEK, id, id === A ? 900 : 400);
      await withEngagement(id, (f) => {
        f.counters.realWins += 1;
      });
    }
  });
  // Passkeys de tots dos (directament al magatzem d'identitats).
  await __internal.serial(async () => {
    const s = await __internal.load();
    s.passkeys.credA = { playerId: A, publicKey: "x", counter: 0, name: "A", createdAt: 1 };
    s.passkeys.credB = { playerId: B, publicKey: "y", counter: 0, name: "B", createdAt: 1 };
    s.log.push({ at: 2, type: "switch", kind: "email", playerId: B, fromPlayerId: A });
    await __internal.save(s);
  });
  // Amics mutus.
  const codeA = (await getOrCreatePlayerFriendsRecord(A)).friendCode;
  const codeB = (await getOrCreatePlayerFriendsRecord(B)).friendCode;
  assert.deepEqual(await addFriendByCode(A, codeB), { ok: true });
  assert.deepEqual(await addFriendByCode(B, codeA), { ok: true });
  // Fitxers per jugador, agregat antic, marca solo i analítica.
  for (const dir of ["player-stats", "campaign-progress"]) {
    fs.mkdirSync(path.join(dataDir, dir), { recursive: true });
    for (const id of [A, B]) fs.writeFileSync(path.join(dataDir, dir, `${id}.json`), JSON.stringify({ version: 1 }), "utf8");
  }
  fs.writeFileSync(
    path.join(dataDir, "player-stats-aggregate.json"),
    JSON.stringify({ players: { [A]: { handsPlayed: 3 }, [B]: { handsPlayed: 4 } } }),
  );
  fs.writeFileSync(
    path.join(dataDir, "solo-isolated-sessions.json"),
    JSON.stringify({ sessions: { [A]: { mode: "practice", updatedAt: 1 }, [B]: { mode: "practice", updatedAt: 1 } } }),
  );
  fs.mkdirSync(path.join(dataDir, "analytics"), { recursive: true });
  const pa = await pseudonymousId(A);
  const pb = await pseudonymousId(B);
  fs.writeFileSync(
    path.join(dataDir, "analytics", "events-2026-10-27.jsonl"),
    `${JSON.stringify({ pid: pa, e: "x" })}\n${JSON.stringify({ pid: pb, e: "y" })}\n${JSON.stringify({ pid: pa, e: "z" })}\n`,
  );
  await flushBalanceWrites();
  await flushWeeklyWrites();
});

after(() => {
  server.close();
  fs.rmSync(dataDir, { recursive: true, force: true });
});

describe("esborrat de compte", () => {
  let tokenA = "";
  let profileBBefore = "";

  it("abans: l'inventari troba totes les dades de A", async () => {
    const inv = await inspectAccount(A);
    const text = inv.items.join("\n");
    for (const re of [/perfil/, /saldo: 30000/, /correus verificats: a\*\*\*@x\.cat/, /passkeys: 1/, /estadístiques/, /assoliments/, /campanya/, /agregat antic/, /rànquing 2026-W44: 900/, /registre d'amics/, /llista d'amics de 1/, /partida solo/, /analítica .*: 2/]) {
      assert.match(text, re);
    }
    tokenA = issuePlayerToken(A)!;
    assert.equal(verifyPlayerToken(tokenA)?.playerId, A);
    profileBBefore = fs.readFileSync(files.profileB, "utf8");
  });

  it("endpoint: sense token 401, sense confirmació 400 (i no esborra res)", async () => {
    assert.equal((await post("/api/account/delete", { confirm: "DELETE_MY_ACCOUNT" })).status, 401);
    const r = await post("/api/account/delete", { confirm: "si" }, tokenA);
    assert.equal(r.status, 400);
    assert.equal(r.body.code, "CONFIRMATION_REQUIRED");
    assert.equal(isAccountDeleted(A), false);
    assert.ok(await getAccountEntry(A));
  });

  it("endpoint amb confirmació: esborra tot i el token deixa de valer", async () => {
    const r = await silence(() => post("/api/account/delete", { confirm: "DELETE_MY_ACCOUNT" }, tokenA));
    assert.equal(r.status, 200);
    assert.deepEqual(r.body, { ok: true, deleted: true });

    assert.equal(verifyPlayerToken(tokenA), null, "el token antic ja no val");
    assert.equal(issuePlayerToken(A), null, "no se n'emet cap de nou");
    assert.equal(resolvePlayerIdFromParts({ legacyPlayerId: A }), null, "ni el playerId antic sense token");
    const me = await fetch(base + "/api/auth/me", { headers: { Authorization: `Bearer ${tokenA}` } });
    assert.equal(me.status, 401);
    assert.equal((await post("/api/account/delete", { confirm: "DELETE_MY_ACCOUNT" }, tokenA)).status, 401);

    const inv = await inspectAccount(A);
    assert.deepEqual(inv.items, [], `no queda res: ${inv.items.join("; ")}`);
    assert.equal(inv.alreadyDeleted, true);
    assert.equal(await emailOwner("a@x.cat"), null);
    // El fitxer de comptes esborrats no conté el playerId en clar.
    assert.doesNotMatch(fs.readFileSync(path.join(dataDir, "deleted-accounts.json"), "utf8"), new RegExp(A));
  });

  it("els altres jugadors queden intactes", async () => {
    assert.equal(fs.readFileSync(files.profileB, "utf8"), profileBBefore, "perfil de B idèntic byte a byte");
    assert.equal((await getAccountEntry(B))?.chips, 12_345);
    assert.equal(await emailOwner("b@x.cat"), B);
    const ids = readJson("identities.json");
    assert.equal(ids.passkeys.credB.playerId, B);
    assert.equal(ids.passkeys.credA, undefined);
    const sw = ids.log.find((e: any) => e.type === "switch");
    assert.equal(sw.playerId, B);
    assert.equal(sw.fromPlayerId, undefined, "entrada de B conservada però anonimitzada");
    assert.deepEqual(readJson(`weekly-leaderboard/${WEEK}.json`).chipsWon, { [B]: 400 });
    assert.deepEqual(await listFriendPlayerIds(B), []);
    assert.ok(fs.existsSync(path.join(dataDir, "player-stats", `${B}.json`)));
    assert.ok(fs.existsSync(path.join(dataDir, "campaign-progress", `${B}.json`)));
    assert.ok(fs.existsSync(path.join(dataDir, "player-engagement", `${B}.json`)));
    assert.deepEqual(Object.keys(readJson("player-stats-aggregate.json").players), [B]);
    assert.deepEqual(Object.keys(readJson("solo-isolated-sessions.json").sessions), [B]);
    const lines = fs.readFileSync(path.join(dataDir, "analytics", "events-2026-10-27.jsonl"), "utf8").trim().split("\n");
    assert.equal(lines.length, 1);
    assert.match(lines[0]!, /"e":"y"/);
    const tokenB = issuePlayerToken(B)!;
    assert.equal(verifyPlayerToken(tokenB)?.playerId, B);
  });

  it("idempotent: tornar-ho a fer no canvia cap fitxer", async () => {
    const snap = () =>
      ["identities.json", "balances.json", "friends.json", "deleted-accounts.json", `weekly-leaderboard/${WEEK}.json`].map((f) =>
        fs.readFileSync(path.join(dataDir, f), "utf8"),
      );
    const before1 = snap();
    const r = await deleteAccount(A);
    assert.equal(r.newlyDeleted, false);
    assert.equal(r.balance.chips, null);
    assert.equal(r.profile, false);
    assert.deepEqual(r.weeklyLeaderboards, []);
    await flushBalanceWrites();
    assert.deepEqual(snap(), before1);
  });

  it("escriptures tardanes (partida en curs) no fan reaparèixer el compte", async () => {
    await addBalance(A, 500);
    await flushBalanceWrites();
    assert.equal(readJson("balances.json").accounts[A], undefined);
    await addWeeklyChipsWon(WEEK, A, 100);
    await flushWeeklyWrites();
    assert.equal(readJson(`weekly-leaderboard/${WEEK}.json`).chipsWon[A], undefined);
    await withEngagement(A, (f) => {
      f.counters.realWins += 1;
    });
    assert.equal(fs.existsSync(path.join(dataDir, "player-engagement", `${A}.json`)), false);
    await upsertProfile(A, { displayName: "Torna" });
    assert.equal(fs.existsSync(path.join(dataDir, "profiles", `${A}.json`)), false);
  });

  it("el mateix correu després d'esborrar: compte NOU (mai el playerId esborrat)", async () => {
    const r = await silence(() =>
      loginWithIdentity({ kind: "email", email: "a@x.cat", current: { playerId: A, legacy: false }, allowCreate: true }),
    );
    assert.ok("playerId" in r && r.playerId !== A && r.created);
  });
});
