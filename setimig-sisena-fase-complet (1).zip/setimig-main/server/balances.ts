import fs from "fs/promises";
import path from "path";
import { randomUUID } from "crypto";
import { DEFAULT_CHIPS } from "../shared/chips.ts";
import { capProcessedSessions, retentionLimits } from "./dataRetention.ts";
import { coalesceDelayMs, registerFlusher, writeJsonAtomic, writeJsonAtomicSync } from "./writeCoalescing.ts";
import { accountsDeletedInThisProcess } from "./deletedAccounts.ts";

export { DEFAULT_CHIPS };

function balanceDataDir(): string {
  return process.env.BALANCE_DATA_DIR || path.join(process.cwd(), "data");
}

function balanceStorePath(): string {
  return path.join(balanceDataDir(), "balances.json");
}

export type BalanceAccount = {
  chips: number;
  lastClaimAt?: number | null;
};

/** Compra d'entrada solo descomptada del saldo i encara no tancada (vegeu soloBuyIn.ts). */
export type OpenSoloBuyIn = {
  playerId: string;
  amount: number;
  roomId: string;
  at: number;
};

interface BalanceStore {
  accounts: Record<string, BalanceAccount>;
  processedSessions: string[];
  /** Absent als fitxers antics; es crea en obrir la primera compra. */
  openSoloBuyIns?: Record<string, OpenSoloBuyIn>;
}

let cache: BalanceStore | null = null;
let writeChain: Promise<void> = Promise.resolve();

/** Índex en memòria de processedSessions (evita recórrer la llista sencera a cada consulta). */
const sessionIndexes = new WeakMap<string[], { len: number; set: Set<string> }>();

function sessionIndex(store: BalanceStore): Set<string> {
  const list = store.processedSessions;
  let idx = sessionIndexes.get(list);
  if (!idx || idx.len > list.length) {
    idx = { len: 0, set: new Set() };
    sessionIndexes.set(list, idx);
  }
  for (let i = idx.len; i < list.length; i++) idx.set.add(list[i]!);
  idx.len = list.length;
  return idx.set;
}

function hasProcessedSession(store: BalanceStore, sessionId: string): boolean {
  return sessionIndex(store).has(sessionId);
}

function pushProcessedSession(store: BalanceStore, sessionId: string): void {
  store.processedSessions.push(sessionId);
  const capped = capProcessedSessions(store.processedSessions, retentionLimits().processedSessions);
  if (capped !== store.processedSessions) store.processedSessions = capped;
}

function emptyStore(): BalanceStore {
  return { accounts: {}, processedSessions: [] };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

async function loadStore(): Promise<BalanceStore> {
  if (cache) return cache;

  let raw: string;
  try {
    raw = await fs.readFile(balanceStorePath(), "utf8");
  } catch (error) {
    if (error instanceof Error && "code" in error && error.code === "ENOENT") {
      cache = emptyStore();
      return cache;
    }
    throw error;
  }

  const parsed: unknown = JSON.parse(raw);
  if (!isRecord(parsed) || !isRecord(parsed.accounts)) {
    throw new Error("Invalid balance store format");
  }
  if (parsed.processedSessions !== undefined && !Array.isArray(parsed.processedSessions)) {
    throw new Error("Invalid balance store format");
  }
  cache = {
    accounts: parsed.accounts as Record<string, BalanceAccount>,
    processedSessions: Array.isArray(parsed.processedSessions) ? parsed.processedSessions as string[] : [],
  };
  if (isRecord(parsed.openSoloBuyIns)) {
    cache.openSoloBuyIns = parsed.openSoloBuyIns as Record<string, OpenSoloBuyIn>;
  }
  return cache;
}

/** Ruta pendent d'escriure (es captura en marcar brut) i temporitzador del buidat agrupat. */
let dirtyPath: string | null = null;
let flushTimer: ReturnType<typeof setTimeout> | null = null;

function clearFlushTimer(): void {
  if (flushTimer) {
    clearTimeout(flushTimer);
    flushTimer = null;
  }
}

/**
 * Desa el store. Per defecte agrupa escriptures (com a molt una cada ~1,5 s);
 * `immediate` (pagaments Stripe) escriu ara mateix. Sempre tmp + rename.
 * S'ha de cridar dins d'una tasca de `enqueueWrite`.
 */
async function persistStore(store: BalanceStore, immediate = false): Promise<void> {
  // Un compte esborrat no torna a aparèixer encara que una partida en curs li pagués alguna cosa.
  for (const id of accountsDeletedInThisProcess()) delete store.accounts[id];
  cache = store;
  const delay = coalesceDelayMs();
  if (immediate || delay === 0) {
    clearFlushTimer();
    dirtyPath = null;
    await writeJsonAtomic(balanceStorePath(), store);
    return;
  }
  if (!dirtyPath) dirtyPath = balanceStorePath();
  if (!flushTimer) {
    flushTimer = setTimeout(() => {
      flushTimer = null;
      void flushBalanceWrites().catch((err) => console.error("[balances] flush failed:", err));
    }, delay);
    flushTimer.unref?.();
  }
}

/** Escriu ara els canvis pendents (ordenat amb la resta d'escriptures del store). */
export function flushBalanceWrites(): Promise<void> {
  clearFlushTimer();
  return enqueueWrite(async () => {
    if (!dirtyPath || !cache) return;
    const target = dirtyPath;
    dirtyPath = null;
    try {
      await writeJsonAtomic(target, cache);
    } catch (err) {
      if (!dirtyPath) dirtyPath = target;
      throw err;
    }
  });
}

function flushBalanceWritesSync(): void {
  clearFlushTimer();
  if (!dirtyPath || !cache) return;
  const target = dirtyPath;
  dirtyPath = null;
  writeJsonAtomicSync(target, cache);
}

registerFlusher({ name: "balances", flush: flushBalanceWrites, flushSync: flushBalanceWritesSync });

function enqueueWrite(task: () => Promise<void>): Promise<void> {
  writeChain = writeChain.then(task, task);
  return writeChain;
}

export async function runBalanceTransaction<T>(fn: (store: BalanceStore) => T | Promise<T>): Promise<T> {
  let result!: T;
  await enqueueWrite(async () => {
    const store = await loadStore();
    result = await fn(store);
    await persistStore(store);
  });
  return result;
}

const PLAYER_ID_RE = /^[a-zA-Z0-9_-]{8,64}$/;

export function sanitizePlayerId(raw: unknown): string | null {
  if (typeof raw !== "string") return null;
  const id = raw.trim();
  return PLAYER_ID_RE.test(id) ? id : null;
}

/**
 * Esborra el saldo d'un compte i les seves compres d'entrada solo obertes (esborrat de compte).
 * Idempotent. Escriu de seguida (no espera el buidat agrupat).
 */
export async function deleteBalanceAccount(playerId: string): Promise<{ chips: number | null; openSoloBuyIns: number }> {
  const out = await runBalanceTransaction((store) => {
    const chips = playerId in store.accounts ? Math.floor(store.accounts[playerId]!.chips) : null;
    delete store.accounts[playerId];
    let open = 0;
    for (const [key, entry] of Object.entries(store.openSoloBuyIns ?? {})) {
      if (entry?.playerId === playerId) {
        delete store.openSoloBuyIns![key];
        open += 1;
      }
    }
    return { chips, openSoloBuyIns: open };
  });
  await flushBalanceWrites();
  return out;
}

export async function getAccountEntry(playerId: string): Promise<BalanceAccount | undefined> {
  const store = await loadStore();
  return store.accounts[playerId];
}

/** Mateixa regla que `getBalance`: enter ≥ 0, o el saldo per defecte si el valor no és vàlid. */
export function normalizeStoredChips(raw: unknown): number {
  const chips = typeof raw === "number" ? Math.floor(raw) : NaN;
  return Number.isFinite(chips) && chips >= 0 ? chips : DEFAULT_CHIPS;
}

/**
 * Llista el saldo de tots els comptes. Només llegeix el store (memòria o balances.json):
 * no escriu ni canvia el format del fitxer.
 */
export async function listBalanceChips(): Promise<{ playerId: string; chips: number }[]> {
  const store = await loadStore();
  const out: { playerId: string; chips: number }[] = [];
  for (const [playerId, account] of Object.entries(store.accounts)) {
    out.push({ playerId, chips: normalizeStoredChips(account?.chips) });
  }
  return out;
}

export async function getBalance(playerId: string): Promise<number> {
  const entry = await getAccountEntry(playerId);
  if (!entry) return DEFAULT_CHIPS;
  return normalizeStoredChips(entry.chips);
}

export async function setBalance(playerId: string, chips: number): Promise<number> {
  const next = Math.max(0, Math.min(Math.floor(chips), 999_999_999));
  await enqueueWrite(async () => {
    const store = await loadStore();
    const prev = store.accounts[playerId];
    store.accounts[playerId] = { chips: next, lastClaimAt: prev?.lastClaimAt ?? null };
    await persistStore(store);
  });
  return next;
}

export async function addBalance(playerId: string, delta: number): Promise<number> {
  const store = await loadStore();
  const current = store.accounts[playerId]?.chips ?? DEFAULT_CHIPS;
  return setBalance(playerId, current + delta);
}

export async function isSessionProcessed(sessionId: string): Promise<boolean> {
  const store = await loadStore();
  return hasProcessedSession(store, sessionId);
}

export async function markSessionProcessed(sessionId: string): Promise<void> {
  await enqueueWrite(async () => {
    const store = await loadStore();
    if (!hasProcessedSession(store, sessionId)) {
      pushProcessedSession(store, sessionId);
      await persistStore(store, true);
    }
  });
}

export async function creditCheckoutSession(
  sessionId: string,
  playerId: string,
  chips: number
): Promise<{ chips: number; credited: number; alreadyProcessed: boolean }> {
  let result = { chips: DEFAULT_CHIPS, credited: 0, alreadyProcessed: false };
  await enqueueWrite(async () => {
    const store = await loadStore();
    if (hasProcessedSession(store, sessionId)) {
      const current = store.accounts[playerId]?.chips ?? DEFAULT_CHIPS;
      result = { chips: current, credited: 0, alreadyProcessed: true };
      return;
    }
    const prev = store.accounts[playerId];
    const current = prev?.chips ?? DEFAULT_CHIPS;
    const next = Math.max(0, Math.min(Math.floor(current + chips), 999_999_999));
    store.accounts[playerId] = { chips: next, lastClaimAt: prev?.lastClaimAt ?? null };
    pushProcessedSession(store, sessionId);
    await persistStore(store, true);
    result = { chips: next, credited: chips, alreadyProcessed: false };
  });
  return result;
}

function clampChips(chips: number): number {
  return Math.max(0, Math.min(Math.floor(chips), 999_999_999));
}

export type OpenSoloBuyInResult = {
  ok: boolean;
  /** Id de la compra oberta (buit si `ok` és fals). */
  id: string;
  /** Compra realment descomptada: min(compra completa, saldo). 0 si `ok` és fals. */
  amount: number;
  /** Saldo després del descompte (o el saldo actual si `ok` és fals). */
  balance: number;
  /** Compra completa de la partida (2.000 o les fitxes de campanya). */
  required: number;
};

/**
 * Descompta la compra d'entrada i la desa com a oberta en la MATEIXA escriptura de balances.json
 * (o les dues coses o cap). La compra és min(compra completa, saldo): mai deixa el saldo negatiu.
 * Només falla si el saldo és 0.
 */
export async function openSoloBuyIn(playerId: string, fullAmount: number, roomId: string): Promise<OpenSoloBuyInResult> {
  const required = Math.max(0, Math.floor(fullAmount));
  let result!: OpenSoloBuyInResult;
  await enqueueWrite(async () => {
    const store = await loadStore();
    const prev = store.accounts[playerId];
    const current = prev?.chips ?? DEFAULT_CHIPS;
    const amount = Math.min(required, Math.max(0, Math.floor(current)));
    if (amount <= 0) {
      result = { ok: false, id: "", amount: 0, balance: Math.max(0, current), required };
      return;
    }
    const id = `sb-${Date.now().toString(36)}-${randomUUID().slice(0, 12)}`;
    const next = clampChips(current - amount);
    store.accounts[playerId] = { chips: next, lastClaimAt: prev?.lastClaimAt ?? null };
    store.openSoloBuyIns = { ...(store.openSoloBuyIns ?? {}), [id]: { playerId, amount, roomId, at: Date.now() } };
    await persistStore(store, true);
    result = { ok: true, id, amount, balance: next, required };
  });
  return result;
}

/**
 * Tanca una compra oberta i abona `credit` com a increment sobre el saldo ACTUAL (dins la cua
 * d'escriptures): els pagaments fets al saldo mentre la compra era oberta es conserven. Idempotent:
 * si la compra ja no és oberta (ja tancada o retornada en arrencar), no fa res.
 */
export async function closeSoloBuyIn(
  id: string,
  credit: number
): Promise<{ closed: boolean; credited: number; balance: number | null }> {
  let result: { closed: boolean; credited: number; balance: number | null } = { closed: false, credited: 0, balance: null };
  await enqueueWrite(async () => {
    const store = await loadStore();
    const open = store.openSoloBuyIns?.[id];
    if (!open) return;
    const prev = store.accounts[open.playerId];
    const current = prev?.chips ?? DEFAULT_CHIPS;
    const credited = Math.max(0, Math.floor(credit));
    const next = clampChips(current + credited);
    store.accounts[open.playerId] = { chips: next, lastClaimAt: prev?.lastClaimAt ?? null };
    const rest = { ...store.openSoloBuyIns };
    delete rest[id];
    store.openSoloBuyIns = rest;
    await persistStore(store, true);
    result = { closed: true, credited, balance: next };
  });
  return result;
}

export async function listOpenSoloBuyIns(): Promise<Record<string, OpenSoloBuyIn>> {
  const store = await loadStore();
  return { ...(store.openSoloBuyIns ?? {}) };
}

/**
 * En arrencar: les partides solo només viuen en memòria, així que tota compra oberta que no
 * pertanyi a una sala viva és d'una partida perduda pel reinici. Es retorna la compra sencera.
 */
export async function refundOrphanSoloBuyIns(isLive: (id: string, entry: OpenSoloBuyIn) => boolean): Promise<number> {
  const open = await listOpenSoloBuyIns();
  let refunded = 0;
  for (const [id, entry] of Object.entries(open)) {
    if (isLive(id, entry)) continue;
    const r = await closeSoloBuyIn(id, entry.amount);
    if (r.closed) {
      refunded += 1;
      console.warn(
        `[saldo] compra solo oberta en arrencar: es retornen ${entry.amount} fitxes a ${entry.playerId} (sala ${entry.roomId})`
      );
    }
  }
  return refunded;
}

export type BalanceAdjustmentResult =
  | { status: "applied"; before: number; after: number; increment: number }
  | { status: "already-applied"; current: number }
  | { status: "guard-failed"; current: number; expectedCurrent: number };

/**
 * Ajust manual del saldo (restauracions, vegeu scripts/restore-balances.ts), tot dins la mateixa
 * transacció de la cua d'escriptures i amb escriptura immediata (tmp + rename):
 * - Idempotent: si `marker` ja és a processedSessions, no fa res ("already-applied").
 * - Guarda: només s'aplica si el saldo actual és exactament `expectedCurrent`; si no, no escriu res.
 * - Increment sobre el saldo actual (mai sobreescriu amb un valor absolut) i marca a processedSessions.
 */
export async function applyBalanceAdjustment(input: {
  playerId: string;
  increment: number;
  expectedCurrent: number;
  marker: string;
}): Promise<BalanceAdjustmentResult> {
  const increment = Math.trunc(input.increment);
  let result!: BalanceAdjustmentResult;
  await enqueueWrite(async () => {
    const store = await loadStore();
    const prev = store.accounts[input.playerId];
    const current = prev?.chips ?? DEFAULT_CHIPS;
    if (hasProcessedSession(store, input.marker)) {
      result = { status: "already-applied", current };
      return;
    }
    if (current !== input.expectedCurrent) {
      result = { status: "guard-failed", current, expectedCurrent: input.expectedCurrent };
      return;
    }
    const next = clampChips(current + increment);
    store.accounts[input.playerId] = { chips: next, lastClaimAt: prev?.lastClaimAt ?? null };
    pushProcessedSession(store, input.marker);
    await persistStore(store, true);
    result = { status: "applied", before: current, after: next, increment: next - current };
  });
  return result;
}

/** Test helper: reset in-memory cache between isolated tests. */
export function resetBalanceStoreCacheForTests() {
  try {
    flushBalanceWritesSync();
  } catch {
    /* el directori de proves pot haver desaparegut */
  }
  dirtyPath = null;
  cache = null;
}
