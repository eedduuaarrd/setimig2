import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { allowSocketEvent, createSocketEventBucket } from "./socketRateLimit.ts";

describe("socket flood guard", () => {
  it("allows up to max events per window and resets after it", () => {
    const b = createSocketEventBucket(0);
    for (let i = 0; i < 5; i++) assert.equal(allowSocketEvent(b, 10, 5, 1000), true);
    assert.equal(allowSocketEvent(b, 20, 5, 1000), false);
    assert.equal(allowSocketEvent(b, 999, 5, 1000), false);
    assert.equal(allowSocketEvent(b, 1000, 5, 1000), true);
  });
});

import { checkApiRate, resetApiRateLimitForTests, API_MAX_WRITES } from "./httpRateLimit.ts";

describe("api rate limit", () => {
  it("limits writes per client within a window", () => {
    resetApiRateLimitForTests();
    for (let i = 0; i < API_MAX_WRITES; i++) assert.equal(checkApiRate("1.2.3.4", true, 1000), true);
    assert.equal(checkApiRate("1.2.3.4", true, 1001), false);
    assert.equal(checkApiRate("5.6.7.8", true, 1001), true);
    assert.equal(checkApiRate("1.2.3.4", true, 1000 + 60_000), true);
  });
});
