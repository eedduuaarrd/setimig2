import { createHmac, randomBytes } from "node:crypto";
import fsSync from "node:fs";
import fs from "fs/promises";
import path from "path";
import { pruneDailyEventFiles, retentionLimits } from "./dataRetention.ts";

/**
 * Analítica pròpia (first-party), sense dades personals.
 * - `pid` = HMAC-SHA256(playerId, sal del servidor) truncat: pseudònim, rotable canviant la sal.
 * - Mai es desa IP, user-agent, nom, avatar, email ni cookies (no n'hi ha de tercers).
 * - Un fitxer JSONL per dia (UTC) a data/analytics/, podat amb `retentionLimits().analyticsDays`.
 */

export const GAME_MODES = ["solo_ai", "practice", "private", "tournament", "campaign"] as const;
export type GameMode = (typeof GAME_MODES)[number];

type FieldSpec =
  | { t: "bool" }
  | { t: "int"; min: number; max: number }
  | { t: "enum"; values: readonly string[] }
  | { t: "key" };

const bool = { t: "bool" } as const;
const int = (min: number, max: number) => ({ t: "int", min, max }) as const;
const oneOf = (values: readonly string[]) => ({ t: "enum", values }) as const;
const key = { t: "key" } as const;
const mode = oneOf(GAME_MODES);
const limitType = oneOf(["time", "hands", "chips"]);

/** Els 14 esdeveniments mínims (17 noms) de l'informe d'analítica del 26/10/2026. */
export const EVENT_SCHEMAS: Record<string, Record<string, FieldSpec>> = {
  player_registered: { ageGateOk: bool },
  session_start: { daysSinceRegister: int(0, 100_000) },
  session_end: { durationSec: int(0, 86_400), handsInSession: int(0, 100_000) },
  game_started: { mode, roomType: oneOf(["solo", "private"]), players: int(0, 16), bots: int(0, 16), minBet: int(0, 1_000_000_000) },
  hand_completed: {
    mode,
    result: oneOf(["win", "lose", "bust", "push"]),
    chipDelta: int(-1_000_000_000, 1_000_000_000),
    wasBanker: bool,
    handIndex: int(1, 100_000_000),
  },
  game_finished: { mode, hands: int(0, 100_000), durationSec: int(0, 864_000), endedBy: oneOf(["complete", "leave", "disconnect"]) },
  private_room_created: { roomHash: key, viaInvite: bool },
  private_room_joined: { roomHash: key, viaInvite: bool },
  tournament_finished: { position: int(1, 16), entrants: int(1, 16) },
  daily_reward_claimed: { streakDay: int(0, 10_000), amount: int(0, 1_000_000_000) },
  mission_progress: { missionKey: key, progress: int(0, 1_000_000_000) },
  mission_claimed: { missionKey: key, progress: int(0, 1_000_000_000) },
  limit_set: { limitType, value: int(0, 1_000_000_000) },
  limit_hit: { limitType, value: int(0, 1_000_000_000) },
  break_taken: { limitType, value: int(0, 1_000_000_000) },
  chips_depleted: { mode },
  exp_exposure: { expId: key, variant: key },
};

export const ANALYTICS_EVENT_NAMES = Object.keys(EVENT_SCHEMAS);

/** Esdeveniments que el client pot enviar a POST /api/events; la resta només els emet el servidor. */
export const CLIENT_EVENTS = new Set(["session_start", "session_end", "limit_set", "limit_hit", "break_taken", "exp_exposure"]);

export type AnalyticsRecord = {
  event: string;
  ts: number;
  pid: string;
  sid: string | null;
  appVersion: string | null;
  platform: "pwa" | "web" | "server";
  isTest: boolean;
} & Record<string, unknown>;

const SID_RE = /^[A-Za-z0-9_-]{8,40}$/;
const VERSION_RE = /^[A-Za-z0-9._-]{1,24}$/;
const KEY_RE = /^[A-Za-z0-9_.:-]{1,48}$/;

/** Valida i neteja els camps extra: només es conserven els del catàleg i amb el tipus correcte. */
export function sanitizeProps(event: string, raw: unknown): Record<string, unknown> | null {
  const schema = EVENT_SCHEMAS[event];
  if (!schema) return null;
  const out: Record<string, unknown> = {};
  if (raw === undefined || raw === null) return out;
  if (typeof raw !== "object" || Array.isArray(raw)) return null;
  const input = raw as Record<string, unknown>;
  for (const [field, spec] of Object.entries(schema)) {
    const v = input[field];
    if (v === undefined || v === null) continue;
    switch (spec.t) {
      case "bool":
        if (typeof v === "boolean") out[field] = v;
        break;
      case "int":
        if (typeof v === "number" && Number.isFinite(v)) out[field] = Math.min(spec.max, Math.max(spec.min, Math.round(v)));
        break;
      case "enum":
        if (typeof v === "string" && spec.values.includes(v)) out[field] = v;
        break;
      case "key":
        if (typeof v === "string" && KEY_RE.test(v)) out[field] = v;
        break;
    }
  }
  return out;
}

// --- Emmagatzematge -------------------------------------------------------

export function analyticsDir(): string {
  if (process.env.ANALYTICS_DATA_DIR) return process.env.ANALYTICS_DATA_DIR;
  const base = process.env.BALANCE_DATA_DIR || path.join(process.cwd(), "data");
  return path.join(base, "analytics");
}

function dayKey(ts: number): string {
  return new Date(ts).toISOString().slice(0, 10);
}

export function eventFilePath(ts: number): string {
  return path.join(analyticsDir(), `events-${dayKey(ts)}.jsonl`);
}

let saltPromise: Promise<string> | null = null;
let saltDir: string | null = null;

async function loadSalt(): Promise<string> {
  const fromEnv = process.env.SETIMIG_ANALYTICS_SALT;
  if (fromEnv && fromEnv.length >= 16) return fromEnv;
  const dir = analyticsDir();
  const file = path.join(dir, ".salt");
  try {
    const existing = (await fs.readFile(file, "utf8")).trim();
    if (existing.length >= 32) return existing;
  } catch {
    /* es crea a sota */
  }
  await fs.mkdir(dir, { recursive: true });
  const fresh = randomBytes(32).toString("hex");
  await fs.writeFile(file, fresh, { encoding: "utf8", mode: 0o600 });
  return fresh;
}

function salt(): Promise<string> {
  const dir = analyticsDir();
  if (!saltPromise || saltDir !== dir) {
    saltDir = dir;
    saltPromise = loadSalt().catch((err) => {
      saltPromise = null;
      throw err;
    });
  }
  return saltPromise;
}

/** Id pseudònim: HMAC-SHA256(playerId, sal) — no es pot revertir sense la sal del servidor. */
export async function pseudonymousId(playerId: string): Promise<string> {
  return createHmac("sha256", await salt()).update(`pid:${playerId}`).digest("hex").slice(0, 32);
}

/** Hash curt d'una sala (no es desa ni l'id ni el codi d'invitació). */
export async function roomHash(roomId: string): Promise<string> {
  return createHmac("sha256", await salt()).update(`room:${roomId}`).digest("hex").slice(0, 16);
}

let writeChain: Promise<void> = Promise.resolve();
let lastPrunedDay: string | null = null;

async function appendRecord(record: AnalyticsRecord): Promise<void> {
  const task = writeChain.then(async () => {
    const dir = analyticsDir();
    await fs.mkdir(dir, { recursive: true });
    const today = dayKey(record.ts);
    if (lastPrunedDay !== today) {
      lastPrunedDay = today;
      await pruneDailyEventFiles(dir, retentionLimits().analyticsDays, today);
    }
    await fs.appendFile(eventFilePath(record.ts), `${JSON.stringify(record)}\n`, "utf8");
  });
  writeChain = task.catch(() => undefined);
  return task;
}

/** Espera que s'hagin escrit els esdeveniments pendents (tests i apagada). */
export function flushAnalytics(): Promise<void> {
  return writeChain;
}

/** Poda a l'arrencada (mateixa política que la resta de data/). */
export async function pruneAnalyticsOnStartup(nowMs: number = Date.now()): Promise<string[]> {
  return pruneDailyEventFiles(analyticsDir(), retentionLimits().analyticsDays, dayKey(nowMs));
}

/**
 * La sal amb què el servidor calcula els pseudònims ja existeix (a l'env o a <dir>/.salt).
 * Si no, esborrar per pid crearia una sal nova i no trobaria res: millor no fer-ho.
 */
export function analyticsSaltKnown(): boolean {
  const fromEnv = process.env.SETIMIG_ANALYTICS_SALT;
  if (fromEnv && fromEnv.length >= 16) return true;
  try {
    return fsSync.readFileSync(path.join(analyticsDir(), ".salt"), "utf8").trim().length >= 32;
  } catch {
    return false;
  }
}

/** Dret a l'oblit: esborra totes les línies d'un jugador (per pid). */
export async function deleteAnalyticsForPlayer(playerId: string): Promise<number> {
  const pid = await pseudonymousId(playerId);
  await flushAnalytics();
  let removed = 0;
  const dir = analyticsDir();
  let names: string[] = [];
  try {
    names = await fs.readdir(dir);
  } catch {
    return 0;
  }
  for (const name of names.filter((n) => n.endsWith(".jsonl"))) {
    const file = path.join(dir, name);
    const lines = (await fs.readFile(file, "utf8")).split("\n").filter(Boolean);
    const kept = lines.filter((l) => !l.includes(`"pid":"${pid}"`));
    if (kept.length !== lines.length) {
      removed += lines.length - kept.length;
      await fs.writeFile(file, kept.length ? `${kept.join("\n")}\n` : "", "utf8");
    }
  }
  return removed;
}

// --- Jugadors de prova ----------------------------------------------------

const DEFAULT_TEST_NAME_RE = /^(test|tester|audit|e2e|qa|prova|smoke|playwright|edu)\b/i;
const TEST_ID_RE = /(^|[-_])(test|e2e|audit|smoke)/i;
const testCache = new Map<string, boolean>();

function testNameRe(): RegExp {
  const raw = process.env.SETIMIG_ANALYTICS_TEST_NAME_RE;
  if (raw) {
    try {
      return new RegExp(raw, "i");
    } catch {
      /* valor per defecte */
    }
  }
  return DEFAULT_TEST_NAME_RE;
}

/** Marca de prova calculada al servidor (el nom només es fa servir aquí; no es desa). */
export function isTestIdentity(playerId: string, displayName?: string | null): boolean {
  if (process.env.SETIMIG_ANALYTICS_ALL_TEST === "1") return true;
  if (TEST_ID_RE.test(playerId)) return true;
  return !!displayName && testNameRe().test(displayName.trim());
}

/** Recorda la marca de prova d'un jugador (es crida quan es coneix el nom: perfil o taula). */
export function rememberTestFlag(playerId: string, displayName?: string | null): boolean {
  const flag = isTestIdentity(playerId, displayName);
  if (testCache.size > 10_000) testCache.clear();
  testCache.set(playerId, flag);
  return flag;
}

async function resolveTestFlag(playerId: string): Promise<boolean> {
  const cached = testCache.get(playerId);
  if (cached !== undefined) return cached;
  let name: string | null = null;
  try {
    const { getProfile } = await import("./profiles.ts");
    name = (await getProfile(playerId))?.displayName ?? null;
  } catch {
    name = null;
  }
  return rememberTestFlag(playerId, name);
}

// --- API -----------------------------------------------------------------

export type TrackContext = {
  sid?: unknown;
  appVersion?: unknown;
  platform?: unknown;
  /** Marca de prova del client (p. ex. navigator.webdriver). Només pot afegir, mai treure. */
  isTest?: unknown;
  ts?: number;
};

/** Construeix el registre validat. Retorna null si l'esdeveniment o els camps no són vàlids. */
export async function buildRecord(
  playerId: string,
  event: string,
  props: unknown,
  ctx: TrackContext = {},
): Promise<AnalyticsRecord | null> {
  if (!playerId || playerId.startsWith("bot-")) return null;
  const clean = sanitizeProps(event, props);
  if (!clean) return null;
  const platform = ctx.platform === "pwa" || ctx.platform === "web" ? ctx.platform : "server";
  const serverTest = await resolveTestFlag(playerId);
  return {
    event,
    ts: ctx.ts ?? Date.now(),
    pid: await pseudonymousId(playerId),
    sid: typeof ctx.sid === "string" && SID_RE.test(ctx.sid) ? ctx.sid : null,
    appVersion: typeof ctx.appVersion === "string" && VERSION_RE.test(ctx.appVersion) ? ctx.appVersion : null,
    platform,
    isTest: serverTest || ctx.isTest === true,
    ...clean,
  };
}

/** Desa un esdeveniment. Mai llança: l'analítica no pot trencar el joc. */
export async function track(playerId: string, event: string, props?: unknown, ctx?: TrackContext): Promise<boolean> {
  try {
    const record = await buildRecord(playerId, event, props, ctx);
    if (!record) return false;
    await appendRecord(record);
    return true;
  } catch (err) {
    console.error("[analytics] track failed:", err instanceof Error ? err.message : err);
    return false;
  }
}

/** Variant fire-and-forget per als punts del joc. */
export function trackLater(playerId: string | undefined | null, event: string, props?: unknown): void {
  if (!playerId) return;
  void track(playerId, event, props);
}

// --- Partides i sessions en memòria ---------------------------------------

type RoomLike = {
  id: string;
  isPrivate?: boolean;
  soloAi?: boolean;
  practiceMode?: boolean;
  fastTournament?: boolean;
  campaignLevel?: number | null;
  minBet?: number;
  players: { playerId: string; isBot?: boolean; chips: number; name?: string }[];
};

export function roomMode(room: RoomLike): GameMode {
  if (room.isPrivate) return "private";
  if (room.fastTournament) return "tournament";
  if (room.practiceMode) return "practice";
  if (room.campaignLevel != null) return "campaign";
  return "solo_ai";
}

type GameTrack = { startedAt: number; hands: number; mode: GameMode };
const games = new Map<string, GameTrack>();
const sessionHands = new Map<string, number>();

const gameKey = (roomId: string, playerId: string) => `${roomId}|${playerId}`;

function humans(room: RoomLike) {
  return room.players.filter((p) => !p.isBot && p.playerId && !p.playerId.startsWith("bot-"));
}

/** `game_started` per a cada humà de la sala que encara no tenia partida oberta. */
export function trackGameStarted(room: RoomLike, opts: { restart?: boolean; nowMs?: number } = {}): void {
  const nowMs = opts.nowMs ?? Date.now();
  const mode = roomMode(room);
  const bots = room.players.filter((p) => p.isBot).length;
  for (const p of humans(room)) {
    const k = gameKey(room.id, p.playerId);
    // Sala IA reutilitzada: una partida nova tanca l'anterior com a abandonada.
    if (opts.restart && games.has(k)) trackGameFinished(room, p.playerId, "leave", nowMs);
    if (games.has(k)) continue;
    games.set(k, { startedAt: nowMs, hands: 0, mode });
    if (p.name) rememberTestFlag(p.playerId, p.name);
    trackLater(p.playerId, "game_started", {
      mode,
      roomType: room.isPrivate ? "private" : "solo",
      players: room.players.length,
      bots,
      minBet: room.minBet ?? 0,
    });
  }
}

/** `game_finished` (i, al torneig ràpid, `tournament_finished`) per a un jugador. */
export function trackGameFinished(
  room: RoomLike,
  playerId: string | undefined,
  endedBy: "complete" | "leave" | "disconnect",
  nowMs: number = Date.now(),
): void {
  if (!playerId) return;
  const k = gameKey(room.id, playerId);
  const g = games.get(k);
  if (!g) return;
  games.delete(k);
  trackLater(playerId, "game_finished", {
    mode: g.mode,
    hands: g.hands,
    durationSec: Math.round((nowMs - g.startedAt) / 1000),
    endedBy,
  });
  if (g.mode === "tournament") {
    trackLater(playerId, "tournament_finished", tournamentPlacement(room, playerId));
  }
}

/** Posició al torneig: 1 + jugadors amb més fitxes (o vius, si el jugador ha quedat a 0). */
export function tournamentPlacement(room: RoomLike, playerId: string): { position: number; entrants: number } {
  const me = room.players.find((p) => p.playerId === playerId);
  const myChips = me?.chips ?? 0;
  const ahead = room.players.filter((p) => p.playerId !== playerId && p.chips > myChips).length;
  return { position: Math.max(1, ahead + 1), entrants: Math.max(1, room.players.length) };
}

/** `private_room_created` / `private_room_joined` amb el hash de la sala (mai el codi). */
export function trackPrivateRoom(
  event: "private_room_created" | "private_room_joined",
  room: { id: string },
  player: { playerId: string; name?: string },
  viaInvite: boolean,
): void {
  if (player.name) rememberTestFlag(player.playerId, player.name);
  void roomHash(room.id)
    .then((hash) => track(player.playerId, event, { roomHash: hash, viaInvite }))
    .catch(() => undefined);
}

/** Comptadors per mà: per partida oberta i per sessió. */
export function noteHandForGame(roomId: string, playerId: string): number {
  sessionHands.set(playerId, (sessionHands.get(playerId) ?? 0) + 1);
  const g = games.get(gameKey(roomId, playerId));
  if (g) g.hands += 1;
  return g?.hands ?? 0;
}

export function startSessionCounter(playerId: string): void {
  sessionHands.set(playerId, 0);
}

export function takeSessionHands(playerId: string): number {
  const n = sessionHands.get(playerId) ?? 0;
  sessionHands.delete(playerId);
  return n;
}

export function resetAnalyticsForTests(): void {
  games.clear();
  sessionHands.clear();
  testCache.clear();
  saltPromise = null;
  saltDir = null;
  lastPrunedDay = null;
}
