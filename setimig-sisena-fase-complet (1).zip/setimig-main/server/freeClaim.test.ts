import { describe, it, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";
import fs from "fs/promises";
import path from "path";
import os from "os";
import {
  claimFreeChips,
  FREE_CLAIM_CHIPS,
  FREE_CLAIM_INTERVAL_MS,
  getFreeClaimStatus,
} from "./freeClaim";
import { getBalance, resetBalanceStoreCacheForTests, sanitizePlayerId, setBalance } from "./balances";

const PLAYER_ID = "freeclaimtestplayer01";

describe("free claim", () => {
  let dataDir = "";

  beforeEach(async () => {
    dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "setimig-bal-"));
    process.env.BALANCE_DATA_DIR = dataDir;
    resetBalanceStoreCacheForTests();
    assert.ok(sanitizePlayerId(PLAYER_ID));
  });

  afterEach(async () => {
    delete process.env.BALANCE_DATA_DIR;
    resetBalanceStoreCacheForTests();
    if (dataDir) await fs.rm(dataDir, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 });
  });

  it("allows first claim and credits 10_000 CF", async () => {
    const before = await getBalance(PLAYER_ID);
    const status = await getFreeClaimStatus(PLAYER_ID, 1_000_000);
    assert.equal(status.claimable, true);

    const result = await claimFreeChips(PLAYER_ID, 1_000_000);
    assert.equal(result.ok, true);
    if (!result.ok) return;
    assert.equal(result.credited, FREE_CLAIM_CHIPS);
    assert.equal(result.chips, before + FREE_CLAIM_CHIPS);
    assert.equal(await getBalance(PLAYER_ID), before + FREE_CLAIM_CHIPS);
  });

  it("rejects second claim before 4 hours", async () => {
    const t0 = 2_000_000_000_000;
    const first = await claimFreeChips(PLAYER_ID, t0);
    assert.equal(first.ok, true);

    const tooSoon = await claimFreeChips(PLAYER_ID, t0 + FREE_CLAIM_INTERVAL_MS - 1_000);
    assert.equal(tooSoon.ok, false);
    if (tooSoon.ok) return;
    assert.equal(tooSoon.code, "TOO_SOON");
    assert.equal(tooSoon.freeClaim.claimable, false);
    assert.ok(tooSoon.freeClaim.secondsUntilClaim > 0);
    assert.equal(await getBalance(PLAYER_ID), first.ok ? first.chips : 0);
  });

  it("allows claim again after 4 hours", async () => {
    const t0 = 3_000_000_000_000;
    const first = await claimFreeChips(PLAYER_ID, t0);
    assert.equal(first.ok, true);
    const chipsAfterFirst = first.ok ? first.chips : 0;

    const second = await claimFreeChips(PLAYER_ID, t0 + FREE_CLAIM_INTERVAL_MS);
    assert.equal(second.ok, true);
    if (!second.ok) return;
    assert.equal(second.chips, chipsAfterFirst + FREE_CLAIM_CHIPS);
  });

  it("does not overwrite a malformed balance store on the next write", async () => {
    const file = path.join(dataDir, "balances.json");
    for (const contents of ["{", JSON.stringify({ accounts: [], processedSessions: [] })]) {
      await fs.writeFile(file, contents, "utf8");
      resetBalanceStoreCacheForTests();

      await assert.rejects(setBalance(PLAYER_ID, 123));
      assert.equal(await fs.readFile(file, "utf8"), contents);
    }
  });

  it("double-click is idempotent within cooldown", async () => {
    const t0 = 4_000_000_000_000;
    const a = await claimFreeChips(PLAYER_ID, t0);
    const b = await claimFreeChips(PLAYER_ID, t0 + 5);
    assert.equal(a.ok, true);
    assert.equal(b.ok, false);
    if (!a.ok) return;
    assert.equal(await getBalance(PLAYER_ID), a.chips);
  });
});
