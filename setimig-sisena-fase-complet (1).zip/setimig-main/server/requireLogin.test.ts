import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { createServer, type Server } from "node:http";
import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import express from "express";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket as ClientSocket } from "socket.io-client";
import { registerApiNotFound } from "./spaFallback.ts";
import { issuePlayerToken } from "./playerToken.ts";
import {
  AUTH_REQUIRED,
  isOpenApiPath,
  registerSocketLoginGate,
  requireLoginMiddleware,
} from "./requireLogin.ts";

const dataDir = mkdtempSync(path.join(os.tmpdir(), "setimig-login-req-"));
process.env.BALANCE_DATA_DIR = dataDir;
process.env.PROFILE_DATA_DIR = path.join(dataDir, "profiles");
process.env.PLAYER_TOKEN_SECRET = "test-login-obligatori-secret";

const { loginWithIdentity, resetIdentityStoreForTests } = await import("./auth/identityStore.ts");

const ACCOUNT_ID = "loginacct00000000000000000000000000000001";
const ORPHAN_ID = "loginorphan00000000000000000000000000001";

async function seedAccount(playerId: string, email: string): Promise<void> {
  const r = await loginWithIdentity({
    kind: "email",
    email,
    current: { playerId, legacy: false },
    allowCreate: false,
  });
  assert.ok(r.ok, `seed ${email}`);
  assert.equal(r.playerId, playerId);
}

describe("isOpenApiPath", () => {
  it("obre salut i auth, tanca la resta", () => {
    assert.equal(isOpenApiPath("/api/health"), true);
    assert.equal(isOpenApiPath("/health"), true);
    assert.equal(isOpenApiPath("/api/auth/providers"), true);
    assert.equal(isOpenApiPath("/api/auth/email/start"), true);
    assert.equal(isOpenApiPath("/api/auth/me"), true);
    assert.equal(isOpenApiPath("/api/player-session"), false);
    assert.equal(isOpenApiPath("/api/balance"), false);
    assert.equal(isOpenApiPath("/api/desconeguda"), false);
    assert.equal(isOpenApiPath("/login"), false);
    assert.equal(isOpenApiPath("/api/handoff/exchange"), true);
    assert.equal(isOpenApiPath("/api/handoff/mint"), false);
    assert.equal(isOpenApiPath("/api/handoff/stats"), false);
    assert.equal(isOpenApiPath("/api/handoff"), false);
    assert.equal(isOpenApiPath("/api/handoff/"), false);
    assert.equal(isOpenApiPath("/api/handoff/exchange/"), false);
    assert.equal(isOpenApiPath("/api/handoff/exchange/extra"), false);
    assert.equal(isOpenApiPath("/api/handoff/exchangex"), false);
    assert.equal(isOpenApiPath("/api/handoffx/exchange"), false);
  });
});

describe("requireLoginMiddleware + socket", () => {
  let server: Server;
  let base = "";
  let io: SocketIOServer;

  before(async () => {
    mkdirSync(dataDir, { recursive: true });
    resetIdentityStoreForTests();
    await seedAccount(ACCOUNT_ID, "compte@test.cat");

    const app = express();
    app.use(express.json());
    app.use(requireLoginMiddleware);
    app.get("/api/health", (_req, res) => res.json({ ok: true }));
    app.get("/api/auth/providers", (_req, res) => res.json({ email: true }));
    app.post("/api/player-session", (_req, res) => res.json({ ok: true }));
    app.post("/api/handoff/exchange", (_req, res) => res.json({ exchanged: true }));
    app.post("/api/handoff/mint", (_req, res) => res.json({ minted: true }));
    app.post("/api/tables", (_req, res) => res.json({ created: true }));
    app.post("/api/bots", (_req, res) => res.json({ bots: true }));
    app.post("/api/practice", (_req, res) => res.json({ practice: true }));
    app.get("/api/balance", (_req, res) => res.json({ chips: 1000 }));
    registerApiNotFound(app);
    app.get("/login", (_req, res) => res.type("html").send("<html>login</html>"));

    server = createServer(app);
    io = new SocketIOServer(server, { cors: { origin: "*" } });
    registerSocketLoginGate(io);
    io.on("connection", (socket) => {
      socket.emit("ready", { playerId: socket.data.playerId });
    });

    await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", () => resolve()));
    const addr = server.address();
    const port = typeof addr === "object" && addr ? addr.port : 0;
    base = `http://127.0.0.1:${port}`;
  });

  after(async () => {
    io.close();
    await new Promise<void>((resolve, reject) => server.close((err) => (err ? reject(err) : resolve())));
    rmSync(dataDir, { recursive: true, force: true });
  });

  async function json(path: string, init: RequestInit = {}) {
    const res = await fetch(base + path, init);
    const body = await res.json().catch(() => null);
    return { status: res.status, body, allow: res.headers.get("allow") };
  }

  it("401 sense sessió en endpoints de joc representatius", async () => {
    for (const [method, path] of [
      ["POST", "/api/tables"],
      ["POST", "/api/bots"],
      ["POST", "/api/practice"],
      ["GET", "/api/balance"],
      ["POST", "/api/player-session"],
    ] as const) {
      const init: RequestInit = { method, headers: { "content-type": "application/json" } };
      if (method !== "GET") init.body = "{}";
      const r = await json(path, init);
      assert.equal(r.status, 401, path);
      assert.deepEqual(r.body, { error: AUTH_REQUIRED });
    }
  });

  it("token anònim (sense compte) també 401", async () => {
    const token = issuePlayerToken(ORPHAN_ID);
    assert.ok(token);
    const r = await json("/api/balance", { headers: { Authorization: `Bearer ${token}` } });
    assert.equal(r.status, 401);
    assert.deepEqual(r.body, { error: AUTH_REQUIRED });
  });

  it("rutes obertes sense sessió", async () => {
    const health = await json("/api/health");
    assert.equal(health.status, 200);
    assert.deepEqual(health.body, { ok: true });
    const providers = await json("/api/auth/providers");
    assert.equal(providers.status, 200);
    assert.deepEqual(providers.body, { email: true });
    const login = await fetch(base + "/login");
    assert.equal(login.status, 200);
    assert.match(await login.text(), /login/);
    const exchange = await json("/api/handoff/exchange", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    assert.equal(exchange.status, 200);
    assert.deepEqual(exchange.body, { exchanged: true });
  });

  it("mint i la resta de /api/handoff segueixen exigint sessió (camí exacte)", async () => {
    for (const path of [
      "/api/handoff/mint",
      "/api/handoff/stats",
      "/api/handoff/exchange/",
      "/api/handoff/exchange/extra",
      "/api/handoff/exchangex",
    ]) {
      const r = await json(path, {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ playerId: ORPHAN_ID }),
      });
      assert.equal(r.status, 401, path);
      assert.deepEqual(r.body, { error: AUTH_REQUIRED });
    }
  });

  it("/api desconeguda sense sessió → 401 (abans del 404)", async () => {
    const r = await json("/api/ruta-inventada");
    assert.equal(r.status, 401);
    assert.deepEqual(r.body, { error: AUTH_REQUIRED });
  });

  it("/api desconeguda amb sessió de compte → 404 NOT_FOUND", async () => {
    resetIdentityStoreForTests();
    await seedAccount(ACCOUNT_ID, "compte@test.cat");
    const token = issuePlayerToken(ACCOUNT_ID);
    assert.ok(token);
    const r = await json("/api/ruta-inventada", { headers: { Authorization: `Bearer ${token}` } });
    assert.equal(r.status, 404);
    assert.deepEqual(r.body, { error: "NOT_FOUND" });
  });

  it("amb sessió de compte els endpoints de joc funcionen", async () => {
    resetIdentityStoreForTests();
    await seedAccount(ACCOUNT_ID, "compte@test.cat");
    const token = issuePlayerToken(ACCOUNT_ID);
    assert.ok(token);
    const headers = { Authorization: `Bearer ${token}`, "content-type": "application/json" };
    for (const [method, path, expect] of [
      ["POST", "/api/tables", { created: true }],
      ["POST", "/api/bots", { bots: true }],
      ["POST", "/api/practice", { practice: true }],
      ["GET", "/api/balance", { chips: 1000 }],
      ["POST", "/api/player-session", { ok: true }],
      ["POST", "/api/handoff/mint", { minted: true }],
      ["POST", "/api/handoff/exchange", { exchanged: true }],
    ] as const) {
      const r = await json(path, { method, headers, body: method === "GET" ? undefined : "{}" });
      assert.equal(r.status, 200, path);
      assert.deepEqual(r.body, expect);
    }
  });

  it("socket sense token → connect_error auth_required", async () => {
    const err = await new Promise<Error>((resolve, reject) => {
      const socket: ClientSocket = ioClient(base, { transports: ["websocket"], forceNew: true, reconnection: false });
      const timer = setTimeout(() => {
        socket.close();
        reject(new Error("timeout"));
      }, 5_000);
      socket.on("connect", () => {
        clearTimeout(timer);
        socket.close();
        reject(new Error("hauria d'haver fallat"));
      });
      socket.on("connect_error", (e) => {
        clearTimeout(timer);
        socket.close();
        resolve(e);
      });
    });
    assert.equal(err.message, AUTH_REQUIRED);
  });

  it("socket amb token de compte → connecta", async () => {
    resetIdentityStoreForTests();
    await seedAccount(ACCOUNT_ID, "compte@test.cat");
    const token = issuePlayerToken(ACCOUNT_ID);
    assert.ok(token);
    const ready = await new Promise<{ playerId: string }>((resolve, reject) => {
      const socket: ClientSocket = ioClient(base, {
        transports: ["websocket"],
        forceNew: true,
        reconnection: false,
        auth: { token },
      });
      const timer = setTimeout(() => {
        socket.close();
        reject(new Error("timeout"));
      }, 5_000);
      socket.on("connect_error", (e) => {
        clearTimeout(timer);
        socket.close();
        reject(e);
      });
      socket.on("ready", (payload) => {
        clearTimeout(timer);
        socket.close();
        resolve(payload);
      });
    });
    assert.equal(ready.playerId, ACCOUNT_ID);
  });
});
