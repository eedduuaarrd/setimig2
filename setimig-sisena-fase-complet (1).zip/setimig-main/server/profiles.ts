import fs from "fs/promises";
import path from "path";
import { sanitizePlayerId } from "./balances.ts";
import { isAccountDeleted } from "./deletedAccounts.ts";
import {
  parseAvatarPatch,
  parseStoredAvatar,
  resolveProfileAvatar,
  type PlayerAvatarConfig,
} from "../shared/playerAvatar.ts";

export type PlayerProfile = {
  displayName: string;
  avatarDataUrl: string | null;
  avatar?: PlayerAvatarConfig | null;
  updatedAt: number;
  /** Primer cop que es va desar el perfil (ms UTC). No es sobreescriu mai. Absent en perfils antics. */
  createdAt?: number;
  /** Última activitat coneguda (ms UTC), amb una resolució de `LAST_SEEN_RESOLUTION_MS`. */
  lastSeen?: number;
};

/** Només es reescriu `lastSeen` si l'anterior té més d'aquesta antiguitat (evita escriptures per petició). */
export const LAST_SEEN_RESOLUTION_MS = 10 * 60 * 1000;

function finiteTs(v: unknown): number | undefined {
  return typeof v === "number" && Number.isFinite(v) && v > 0 ? v : undefined;
}

export class InvalidAvatarError extends Error {
  override name = "InvalidAvatarError";
}

const MAX_NAME = 24;
const MAX_AVATAR_BYTES = 180_000;

function profileDir(): string {
  return process.env.PROFILE_DATA_DIR || path.join(process.cwd(), "data", "profiles");
}

function profilePath(playerId: string): string {
  return path.join(profileDir(), `${playerId}.json`);
}

function defaultProfile(displayName = "Jugador"): PlayerProfile {
  return { displayName: displayName.slice(0, MAX_NAME), avatarDataUrl: null, updatedAt: Date.now() };
}

export function normalizeDisplayName(name: unknown): string {
  if (typeof name !== "string") return "Jugador";
  const trimmed = name.trim().slice(0, MAX_NAME);
  return trimmed || "Jugador";
}

export function validateAvatarDataUrl(dataUrl: unknown): string | null {
  if (dataUrl === null || dataUrl === undefined || dataUrl === "") return null;
  if (typeof dataUrl !== "string" || !/^data:image\/(?:jpeg|png|webp|gif);base64,[A-Za-z0-9+/=]+$/.test(dataUrl)) return null;
  if (dataUrl.length > MAX_AVATAR_BYTES * 1.4) return null;
  return dataUrl;
}

export function resolvedAvatarForProfile(profile: PlayerProfile, playerId: string): PlayerAvatarConfig {
  return resolveProfileAvatar(profile.avatar, profile.displayName, playerId);
}

/** Esborra el perfil (nom, avatar…) d'un compte. Idempotent. */
export async function deleteProfile(playerIdRaw: unknown): Promise<boolean> {
  const playerId = sanitizePlayerId(playerIdRaw);
  if (!playerId) return false;
  try {
    await fs.rm(profilePath(playerId));
    return true;
  } catch (err) {
    if ((err as NodeJS.ErrnoException)?.code === "ENOENT") return false;
    throw err;
  }
}

export async function getProfile(playerIdRaw: unknown): Promise<PlayerProfile | null> {
  const playerId = sanitizePlayerId(playerIdRaw);
  if (!playerId) return null;
  let raw: string;
  try {
    raw = await fs.readFile(profilePath(playerId), "utf8");
  } catch (error: unknown) {
    if (typeof error === "object" && error !== null && "code" in error && error.code === "ENOENT") {
      return null;
    }
    throw error;
  }
  const parsed = JSON.parse(raw) as Partial<PlayerProfile>;
  const displayName = normalizeDisplayName(parsed.displayName);
  let avatar: PlayerAvatarConfig | undefined;
  if (parsed.avatar !== undefined && parsed.avatar !== null) {
    // Lectura: els colors retirats (verds) es tradueixen al substitut.
    const strict = parseStoredAvatar(parsed.avatar, displayName);
    if (strict !== null && strict !== "clear") avatar = strict;
  }
  return {
    displayName,
    avatarDataUrl: validateAvatarDataUrl(parsed.avatarDataUrl),
    avatar,
    updatedAt: typeof parsed.updatedAt === "number" ? parsed.updatedAt : Date.now(),
    ...(finiteTs(parsed.createdAt) ? { createdAt: finiteTs(parsed.createdAt) } : {}),
    ...(finiteTs(parsed.lastSeen) ? { lastSeen: finiteTs(parsed.lastSeen) } : {}),
  };
}

export async function upsertProfile(
  playerIdRaw: unknown,
  patch: { displayName?: unknown; avatarDataUrl?: unknown; avatar?: unknown }
): Promise<PlayerProfile | null> {
  const playerId = sanitizePlayerId(playerIdRaw);
  if (!playerId) return null;
  const stored = await getProfile(playerId);
  const existing = stored ?? defaultProfile();
  const now = Date.now();
  const displayName =
    patch.displayName !== undefined ? normalizeDisplayName(patch.displayName) : existing.displayName;

  let avatar = existing.avatar;
  if (patch.avatar !== undefined) {
    const parsed = parseAvatarPatch(patch.avatar, displayName);
    if (parsed === null) throw new InvalidAvatarError();
    avatar = parsed === "clear" ? undefined : parsed;
  }

  const next: PlayerProfile = {
    displayName,
    avatarDataUrl:
      patch.avatarDataUrl !== undefined ? validateAvatarDataUrl(patch.avatarDataUrl) : existing.avatarDataUrl,
    avatar,
    updatedAt: now,
    // Perfils antics sense createdAt: no s'inventa la data de registre.
    ...(stored ? (stored.createdAt ? { createdAt: stored.createdAt } : {}) : { createdAt: now }),
    lastSeen: now,
  };
  await writeProfileFile(playerId, next);
  return next;
}

async function writeProfileFile(playerId: string, profile: PlayerProfile): Promise<void> {
  // Compte esborrat: no es torna a crear cap fitxer (p. ex. una partida que acaba després).
  if (isAccountDeleted(playerId)) return;
  await fs.mkdir(profileDir(), { recursive: true });
  await fs.writeFile(profilePath(playerId), JSON.stringify(profile, null, 2), "utf8");
}

/**
 * Actualitza `lastSeen` d'un perfil existent (no en crea cap ni toca createdAt/updatedAt).
 * Retorna el perfil (actualitzat o no) o null si no existeix.
 */
export async function touchLastSeen(playerIdRaw: unknown, nowMs: number = Date.now()): Promise<PlayerProfile | null> {
  const playerId = sanitizePlayerId(playerIdRaw);
  if (!playerId) return null;
  const profile = await getProfile(playerId);
  if (!profile) return null;
  if (profile.lastSeen !== undefined && nowMs - profile.lastSeen < LAST_SEEN_RESOLUTION_MS) return profile;
  const next: PlayerProfile = { ...profile, lastSeen: nowMs };
  await writeProfileFile(playerId, next);
  return next;
}
