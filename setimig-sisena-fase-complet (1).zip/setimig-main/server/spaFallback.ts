import type { Express, Request, RequestHandler, Response } from "express";
import path from "path";

/**
 * Fallback SPA de `dist/` en producció.
 *
 * - Les rutes de l app (sense extensió: `/`, `/t/ABC123`, `/partida/x`) reben `index.html`.
 * - Una petició l últim segment de la qual té extensió (`/foo.js`, `/manifest.json`,
 *   `/assets/vell-XXXX.css`) i que `express.static` no ha trobat és un fitxer que no existeix:
 *   retorna 404. Abans retornava `index.html` amb 200, i això feia que el navegador, el
 *   service worker o Cloudflare guardessin HTML com si fos JS/CSS.
 *
 * Les rutes `/api/*` i socket.io es resolen abans i no passen per aquí.
 */
export function hasFileExtension(requestPath: string): boolean {
  const last = requestPath.split("/").pop() ?? "";
  return path.posix.extname(last) !== "";
}

export function spaFallbackHandler(distPath: string): RequestHandler {
  const indexHtml = path.join(distPath, "index.html");
  return (req: Request, res: Response) => {
    if (hasFileExtension(req.path)) {
      res.status(404).type("text/plain").send("Not found");
      return;
    }
    res.sendFile(indexHtml);
  };
}

/** Nom antic del manifest: l app fa servir `/site.webmanifest`. */
export const LEGACY_MANIFEST_PATH = "/manifest.webmanifest";
export const MANIFEST_PATH = "/site.webmanifest";

export function registerManifestRedirect(app: Express): void {
  app.get(LEGACY_MANIFEST_PATH, (_req, res) => {
    res.redirect(301, MANIFEST_PATH);
  });
}

const API_CATCH_ALL = ["/api", "/api/*"];

type RouteLayer = { route?: { path: unknown; methods: Record<string, boolean> }; match?: (p: string) => boolean };

/** Mètodes (en majúscules) registrats a `app` per a `requestPath`. Buit si la ruta no existeix. */
export function allowedMethodsFor(app: Express | Request["app"], requestPath: string): string[] {
  const stack: RouteLayer[] = (app as unknown as { _router?: { stack: RouteLayer[] } })._router?.stack ?? [];
  const methods = new Set<string>();
  for (const layer of stack) {
    if (!layer.route || typeof layer.match !== "function") continue;
    // Només rutes /api concretes: ni el comodí de la SPA ("*") ni aquest mateix catch-all.
    if (typeof layer.route.path !== "string" || !layer.route.path.startsWith("/api/")) continue;
    if (!layer.match(requestPath)) continue;
    for (const [m, on] of Object.entries(layer.route.methods)) {
      if (on) methods.add(m.toUpperCase());
    }
  }
  if (methods.has("GET")) methods.add("HEAD");
  return [...methods].sort();
}

/**
 * Les rutes `/api/*` que no existeixen no han de caure al fallback de la SPA (index.html amb 200).
 * - ruta coneguda amb un altre mètode → 405 `{ error: "METHOD_NOT_ALLOWED" }` + capçalera `Allow`;
 * - ruta desconeguda → 404 `{ error: "NOT_FOUND" }`.
 * S'ha de registrar DESPRÉS de totes les rutes `/api/*` i abans del fallback SPA.
 */
export function registerApiNotFound(app: Express): void {
  app.all(API_CATCH_ALL, apiNotFoundHandler);
}

function apiNotFoundHandler(req: Request, res: Response): void {
  const allowed = allowedMethodsFor(req.app, req.path);
  if (allowed.length > 0) {
    res.setHeader("Allow", allowed.join(", "));
    res.status(405).json({ error: "METHOD_NOT_ALLOWED" });
    return;
  }
  res.status(404).json({ error: "NOT_FOUND" });
}
