import { randomBytes, timingSafeEqual } from "node:crypto";
import type { Express, Request, Response } from "express";
import { sanitizePlayerId } from "./balances.ts";
import { issuePlayerToken, signWithPlayerSecret, verifyPlayerToken, readTokenFromAuthHeader } from "./playerToken.ts";
import { resolvePlayerFromRequest } from "./httpPlayerAuth.ts";
import { clientKey } from "./httpRateLimit.ts";
import { isAllowedOrigin, PRIMARY_ORIGIN, normalizeOrigin } from "./allowedOrigins.ts";
import { getMigrationStats, recordDomainMigrated } from "./domainMigration.ts";

/**
 * Traspàs de compte entre dominis (setimig.supercbb.com -> sevenhalf.club).
 *
 * L'identitat del jugador viu al localStorage de cada origen (setimig_player_id,
 * setimig_player_token), i un origen nou no hi té accés. El servidor és el mateix, així que
 * no cal copiar cap dada: només cal que el client del domini nou rebi un token per al
 * MATEIX playerId (mateix saldo, perfil, estadístiques i amics).
 *
 * 1. Domini antic, jugador autenticat: POST /api/handoff/mint -> token de traspàs
 *    (vàlid 5 min, d'un sol ús, signat amb HMAC i desat al servidor).
 * 2. Domini nou: POST /api/handoff/exchange { transferToken } -> { playerId, playerToken }.
 *    El token es consumeix de manera atòmica: un segon intent falla.
 *
 * Opcionalment el client hi pot adjuntar `clientState` (preferències del localStorage, màx.
 * 16 KB), que es retorna en el bescanvi.
 */
export const HANDOFF_TTL_MS = 5 * 60 * 1000;
export const HANDOFF_PURPOSE = "setimig-handoff-v1";
export const MAX_CLIENT_STATE_BYTES = 16 * 1024;
export const MINT_LIMIT = 5;
export const MINT_WINDOW_MS = 10 * 60 * 1000;
export const EXCHANGE_FAIL_LIMIT = 10;
export const EXCHANGE_WINDOW_MS = 10 * 60 * 1000;
const MAX_PENDING = 50_000;

type Pending = { playerId: string; exp: number; clientState?: string };
const pending = new Map<string, Pending>();
const mintBuckets = new Map<string, { start: number; n: number }>();
const exchangeFailBuckets = new Map<string, { start: number; n: number }>();

export type HandoffError =
  | "BAD_TOKEN"
  | "BAD_SIGNATURE"
  | "EXPIRED"
  | "USED_OR_UNKNOWN"
  | "RATE_LIMIT"
  | "BAD_PLAYER"
  | "CLIENT_STATE_TOO_LARGE";

function b64url(s: string): string {
  return Buffer.from(s, "utf8").toString("base64url");
}

function prune(now: number): void {
  for (const [k, v] of pending) if (v.exp <= now) pending.delete(k);
}

function hit(buckets: Map<string, { start: number; n: number }>, key: string, windowMs: number, now: number): number {
  let b = buckets.get(key);
  if (!b || now - b.start >= windowMs) {
    b = { start: now, n: 0 };
    buckets.set(key, b);
  }
  b.n += 1;
  if (buckets.size > 20_000) {
    for (const [k, v] of buckets) if (now - v.start >= windowMs) buckets.delete(k);
  }
  return b.n;
}

function failCount(key: string | null, now: number): number {
  if (!key) return 0;
  const b = exchangeFailBuckets.get(key);
  if (!b || now - b.start >= EXCHANGE_WINDOW_MS) return 0;
  return b.n;
}

export function mintHandoffToken(
  playerIdRaw: unknown,
  opts: { now?: number; clientState?: unknown } = {},
): { ok: true; transferToken: string; expiresAt: number } | { ok: false; error: HandoffError } {
  const now = opts.now ?? Date.now();
  const playerId = sanitizePlayerId(playerIdRaw);
  if (!playerId) return { ok: false, error: "BAD_PLAYER" };
  let clientState: string | undefined;
  if (opts.clientState !== undefined && opts.clientState !== null) {
    if (typeof opts.clientState !== "string") return { ok: false, error: "CLIENT_STATE_TOO_LARGE" };
    if (Buffer.byteLength(opts.clientState, "utf8") > MAX_CLIENT_STATE_BYTES) {
      return { ok: false, error: "CLIENT_STATE_TOO_LARGE" };
    }
    clientState = opts.clientState;
  }
  if (hit(mintBuckets, playerId, MINT_WINDOW_MS, now) > MINT_LIMIT) return { ok: false, error: "RATE_LIMIT" };
  prune(now);
  if (pending.size >= MAX_PENDING) return { ok: false, error: "RATE_LIMIT" };
  const nonce = randomBytes(18).toString("base64url");
  const exp = now + HANDOFF_TTL_MS;
  const body = b64url(JSON.stringify({ n: nonce, p: playerId, e: exp }));
  const sig = signWithPlayerSecret(HANDOFF_PURPOSE, body).toString("base64url");
  pending.set(nonce, { playerId, exp, clientState });
  return { ok: true, transferToken: `h1.${body}.${sig}`, expiresAt: exp };
}

/** Valida i CONSUMEIX el token (un sol ús). Síncron: no hi pot haver dos bescanvis alhora. */
export function consumeHandoffToken(
  tokenRaw: unknown,
  opts: { now?: number; rateKey?: string | null } = {},
): { ok: true; playerId: string; clientState?: string } | { ok: false; error: HandoffError } {
  const now = opts.now ?? Date.now();
  const rateKey = opts.rateKey ?? null;
  if (failCount(rateKey, now) >= EXCHANGE_FAIL_LIMIT) return { ok: false, error: "RATE_LIMIT" };
  const fail = (error: HandoffError) => {
    if (rateKey) hit(exchangeFailBuckets, rateKey, EXCHANGE_WINDOW_MS, now);
    return { ok: false as const, error };
  };
  if (typeof tokenRaw !== "string" || tokenRaw.length > 512) return fail("BAD_TOKEN");
  const parts = tokenRaw.split(".");
  if (parts.length !== 3 || parts[0] !== "h1" || !parts[1] || !parts[2]) return fail("BAD_TOKEN");
  const [, body, sigPart] = parts;
  const expected = signWithPlayerSecret(HANDOFF_PURPOSE, body);
  const actual = Buffer.from(sigPart, "base64url");
  if (actual.length !== expected.length || !timingSafeEqual(actual, expected)) return fail("BAD_SIGNATURE");
  let payload: { n?: unknown; p?: unknown; e?: unknown };
  try {
    payload = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
  } catch {
    return fail("BAD_TOKEN");
  }
  if (typeof payload.n !== "string" || typeof payload.p !== "string" || typeof payload.e !== "number") {
    return fail("BAD_TOKEN");
  }
  const entry = pending.get(payload.n);
  if (payload.e <= now) {
    pending.delete(payload.n);
    return fail("EXPIRED");
  }
  if (!entry || entry.playerId !== payload.p || entry.exp !== payload.e) return fail("USED_OR_UNKNOWN");
  pending.delete(payload.n);
  if (entry.exp <= now) return fail("EXPIRED");
  return { ok: true, playerId: entry.playerId, clientState: entry.clientState };
}

export function resetHandoffForTests(): void {
  pending.clear();
  mintBuckets.clear();
  exchangeFailBuckets.clear();
}

export function pendingHandoffCountForTests(): number {
  return pending.size;
}

const ERROR_STATUS: Record<HandoffError, number> = {
  BAD_TOKEN: 400,
  BAD_SIGNATURE: 400,
  EXPIRED: 410,
  USED_OR_UNKNOWN: 410,
  RATE_LIMIT: 429,
  BAD_PLAYER: 400,
  CLIENT_STATE_TOO_LARGE: 413,
};

const ERROR_MESSAGE: Record<HandoffError, string> = {
  BAD_TOKEN: "Enllaç de traspàs no vàlid.",
  BAD_SIGNATURE: "Enllaç de traspàs no vàlid.",
  EXPIRED: "L'enllaç de traspàs ha caducat. Torna-ho a provar des del domini antic.",
  USED_OR_UNKNOWN: "Aquest enllaç de traspàs ja s'ha fet servir o ha caducat.",
  RATE_LIMIT: "Massa intents. Espera uns minuts.",
  BAD_PLAYER: "Identitat de jugador invalida.",
  CLIENT_STATE_TOO_LARGE: "Dades del client massa grans.",
};

function sendError(res: Response, error: HandoffError): void {
  if (error === "RATE_LIMIT") res.setHeader("Retry-After", "600");
  res.status(ERROR_STATUS[error]).json({ error: ERROR_MESSAGE[error], code: error });
}

function originAllowed(req: Request): boolean {
  return isAllowedOrigin(req.headers.origin, req.headers.host);
}

function targetOrigin(): string {
  return normalizeOrigin(process.env.HANDOFF_TARGET_ORIGIN) ?? PRIMARY_ORIGIN;
}

/** Rutes HTTP del traspàs. Totes sota /api/handoff/ (el 301 del domini antic les ha d'excloure). */
export function registerHandoffRoutes(app: Express): void {
  app.post("/api/handoff/mint", (req: Request, res: Response) => {
    res.setHeader("Cache-Control", "no-store");
    if (!originAllowed(req)) return void res.status(403).json({ error: "Origen no permès.", code: "BAD_ORIGIN" });
    const resolved = resolvePlayerFromRequest(req);
    if (!resolved) return void sendError(res, "BAD_PLAYER");
    const minted = mintHandoffToken(resolved.playerId, { clientState: req.body?.clientState });
    if ("error" in minted) return void sendError(res, minted.error);
    const target = targetOrigin();
    console.log(`[handoff] mint player=${resolved.playerId.slice(0, 8)} legacy=${resolved.legacy}`);
    res.json({
      transferToken: minted.transferToken,
      expiresAt: minted.expiresAt,
      // Al fragment (#): no viatja al servidor, ni a Cloudflare ni al Referer.
      targetUrl: `${target}/#handoff=${encodeURIComponent(minted.transferToken)}`,
    });
  });

  app.post("/api/handoff/exchange", (req: Request, res: Response) => {
    res.setHeader("Cache-Control", "no-store");
    if (!originAllowed(req)) return void res.status(403).json({ error: "Origen no permès.", code: "BAD_ORIGIN" });
    const result = consumeHandoffToken(req.body?.transferToken, { rateKey: clientKey(req) });
    if ("error" in result) {
      console.warn(`[handoff] exchange failed: ${result.error}`);
      return void sendError(res, result.error);
    }
    const playerToken = issuePlayerToken(result.playerId);
    if (!playerToken) return void sendError(res, "BAD_PLAYER");
    // Si el client del domini nou ja tenia una identitat pròpia (diferent), l'informem perquè
    // decideixi; el compte que guanya és sempre el del traspàs.
    const currentToken = readTokenFromAuthHeader(req.headers.authorization);
    const current = currentToken ? verifyPlayerToken(currentToken) : null;
    const replacedPlayerId = current && current.playerId !== result.playerId ? current.playerId : undefined;
    recordDomainMigrated(result.playerId);
    console.log(`[handoff] exchange ok player=${result.playerId.slice(0, 8)}`);
    res.json({
      playerId: result.playerId,
      playerToken,
      clientState: result.clientState,
      replacedPlayerId,
    });
  });

  // Només des del mateix VPS (curl 127.0.0.1:<port>): darrere Cloudflare sempre hi ha IP de client.
  app.get("/api/handoff/stats", (req: Request, res: Response) => {
    res.setHeader("Cache-Control", "no-store");
    if (clientKey(req) !== null) return void res.status(404).json({ error: "Not found" });
    res.json(getMigrationStats());
  });
}
