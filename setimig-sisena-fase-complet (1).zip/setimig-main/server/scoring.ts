export { scoreCards } from "../shared/scoring.ts";
