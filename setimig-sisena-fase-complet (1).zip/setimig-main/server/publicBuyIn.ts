/**
 * Saldo real a les taules públiques multijugador (ni solo, ni privades, ni pràctica/torneig).
 *
 * Mateix model que les solo (soloBuyIn.ts), però amb un llibre per jugador:
 * - En seure: compra d'entrada descomptada del saldo real i desada com a oberta a balances.json
 *   (atòmic, mai saldo negatiu; reutilitza `openSoloBuyIn`). El seient té aquestes fitxes.
 * - Cada mà liquidada suma al llibre del jugador el seu `chipDelta`.
 * - En sortir (Sortir o desconnexió): s'abona el resultat verificat (fitxes finals = compra + mans)
 *   com a increment sobre el saldo ACTUAL (`closeSoloBuyIn`); si no quadra, només la compra.
 *   Idempotent: el llibre surt de la sala abans de cap `await` i la compra es tanca un sol cop.
 * - Mai s'escriuen les fitxes de taula com a saldo (ni després de cada mà ni en sortir): els
 *   pagaments al saldo fets mentrestant (assoliments, missions, compres, una altra pestanya) es
 *   conserven sempre.
 * - Reinici amb el jugador assegut: les sales públiques només viuen en memòria; en arrencar es
 *   retorna la compra sencera (`refundOrphanSoloBuyIns`), com a les solo.
 *
 * Avui el servidor no té cap camí per seure a una taula pública (des del #12 només hi ha solo i
 * privades): aquest mòdul fa que, si n'hi torna a haver, el saldo real no es pugui trepitjar.
 */
import { roomUsesIsolatedPlayChips } from "../shared/fastTournament.ts";
import type { Player, Room } from "../shared/gameEngine.ts";
import { openSoloBuyIn, closeSoloBuyIn, type OpenSoloBuyInResult } from "./balances.ts";
import { addLedgerHand, ledgerChipDeltaForSeat, soloBuyInPayout, type SoloBuyInLedger, type SoloBuyInPayout } from "./soloBuyIn.ts";

export function roomUsesPublicBuyIn(
  room: Pick<Room, "soloAi" | "isPrivate" | "practiceMode" | "fastTournament">
): boolean {
  return !room.soloAi && !room.isPrivate && !room.practiceMode && !roomUsesIsolatedPlayChips(room);
}

/**
 * Seu un humà a una taula pública amb compra d'entrada: min(compra completa, saldo). Si ja té una
 * compra oberta en aquesta sala (p. ex. una segona petició), no se'n descompta cap altra.
 */
export async function seatPublicPlayerWithBuyIn(
  room: Room,
  seat: Player,
  fullAmount: number
): Promise<OpenSoloBuyInResult> {
  const existing = room.realBuyIns?.[seat.playerId];
  if (existing) {
    return { ok: true, id: existing.id, amount: existing.amount, balance: -1, required: fullAmount };
  }
  const result = await openSoloBuyIn(seat.playerId, fullAmount, room.id);
  if (result.ok) {
    room.realBuyIns = {
      ...(room.realBuyIns ?? {}),
      [seat.playerId]: { id: result.id, playerId: seat.playerId, amount: result.amount, handsNet: 0, hands: 0 },
    };
    seat.chips = result.amount;
  }
  return result;
}

/** Cridat en liquidar cada mà (síncron): suma el `chipDelta` de cada jugador amb compra oberta. */
export function recordPublicHandsOnLedger(room: Room): void {
  const ledgers = room.realBuyIns;
  const results = room.lastRound?.results;
  if (!ledgers || !results) return;
  for (const ledger of Object.values(ledgers)) {
    const seat = room.players.find((p) => p.playerId === ledger.playerId && !p.isBot);
    if (!seat) continue;
    addLedgerHand(ledger, room.handSeq, ledgerChipDeltaForSeat(results, seat));
  }
}

/**
 * Tanca la compra oberta del jugador (si n'hi ha). Sense compra oberta no s'escriu res: mai es
 * fa servir el valor de les fitxes de taula com a saldo.
 */
export async function settlePublicBuyIn(room: Room, seat: Player, reason: string): Promise<SoloBuyInPayout | null> {
  const ledger: SoloBuyInLedger | undefined = room.realBuyIns?.[seat.playerId];
  if (!ledger) return null;
  const rest = { ...room.realBuyIns };
  delete rest[seat.playerId];
  room.realBuyIns = Object.keys(rest).length ? rest : undefined;
  const payout = soloBuyInPayout(room, ledger, seat);
  if (!payout.verified) {
    console.error(
      `[saldo] compra de taula pública que no quadra (${reason}): sala ${room.id}, jugador ${ledger.playerId}, ` +
        `esperat ${payout.expected}, real ${payout.actual ?? "sense seient"}; ` +
        (payout.credit === ledger.amount
          ? `es retorna només la compra (${ledger.amount})`
          : `s'abonen les fitxes de taula (${payout.credit})`)
    );
  }
  await closeSoloBuyIn(ledger.id, payout.credit);
  return payout;
}

/** Ids de les compres obertes de les sales vives (per no retornar-les en arrencar). */
export function livePublicBuyInIds(rooms: Iterable<Room>): string[] {
  const ids: string[] = [];
  for (const room of rooms) {
    for (const ledger of Object.values(room.realBuyIns ?? {})) ids.push(ledger.id);
  }
  return ids;
}
