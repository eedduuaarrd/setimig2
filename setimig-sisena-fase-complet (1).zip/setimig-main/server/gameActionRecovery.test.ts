import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createServer } from "http";
import { mkdtemp, rm } from "node:fs/promises";
import path from "node:path";
import { tmpdir } from "node:os";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket } from "socket.io-client";
import { setupGameHandlers, getRoomSnapshotForTests, resetGameStateForTests } from "./game.ts";
import { issuePlayerToken } from "./playerToken.ts";
import type { RoomView } from "../src/gameTypes.ts";

const HOST_ID = "actionrecoveryhost01";
const GUEST_ID = "actionrecoveryguest1";
process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";

function connect(url: string): Promise<Socket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.once("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.once("connect_error", (error) => {
      clearTimeout(timer);
      reject(error);
    });
  });
}

function waitJoined(socket: Socket): Promise<RoomView> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("join timeout")), 15_000);
    socket.once("joined_room", (room: RoomView) => {
      clearTimeout(timer);
      resolve(room);
    });
  });
}

function waitRoom(socket: Socket, predicate: (room: RoomView) => boolean): Promise<RoomView> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      socket.off("room_update", onUpdate);
      reject(new Error("room update timeout"));
    }, 30_000);
    const onUpdate = (room: RoomView) => {
      if (!predicate(room)) return;
      clearTimeout(timer);
      socket.off("room_update", onUpdate);
      resolve(room);
    };
    socket.on("room_update", onUpdate);
  });
}

function waitForEvent<T>(socket: Socket, event: string): Promise<T> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`${event} timeout`)), 10_000);
    socket.once(event, (payload: T) => {
      clearTimeout(timer);
      resolve(payload);
    });
  });
}

describe("game action recovery", () => {
  it("acknowledges an accepted bet once, deduplicates its retry, and resumes after a disconnect mid-hand", async () => {
    const previousDataDir = process.env.BALANCE_DATA_DIR;
    const previousFast = process.env.SETIMIG_TEST_FAST;
    const dataDir = await mkdtemp(path.join(tmpdir(), "setimig-action-recovery-"));
    process.env.BALANCE_DATA_DIR = dataDir;
    delete process.env.SETIMIG_TEST_FAST;
    resetGameStateForTests();

    const http = createServer();
    const io = new SocketIOServer(http, { cors: { origin: "*" } });
    await setupGameHandlers(io);
    await new Promise<void>((resolve) => http.listen(0, "127.0.0.1", resolve));
    const address = http.address();
    assert.ok(address && typeof address !== "string");
    const url = `http://127.0.0.1:${address.port}`;
    const host = await connect(url);
    const guest = await connect(url);
    let rejoinSocket: Socket | undefined;

    try {
      const hostToken = issuePlayerToken(HOST_ID)!;
      const guestToken = issuePlayerToken(GUEST_ID)!;
      const hostJoined = waitJoined(host);
      host.emit("create_private_table", { playerName: "Host", playerId: HOST_ID, playerToken: hostToken });
      const hostRoom = await hostJoined;
      assert.ok(hostRoom.inviteCode);

      const guestJoined = waitJoined(guest);
      guest.emit("join_private_table", {
        inviteCode: hostRoom.inviteCode,
        playerName: "Guest",
        playerId: GUEST_ID,
        playerToken: guestToken,
      });
      const guestRoom = await guestJoined;
      const bettingUpdate = waitRoom(host, (room) => room.phase === "betting");
      host.emit("start_game", { roomId: hostRoom.id, playerToken: hostToken, actionSeq: 1 });
      const bettingRoom = await bettingUpdate;

      const bettor = bettingRoom.players.find((player) => !player.isBanker && !player.isBot);
      assert.ok(bettor);
      const bettorSocket = bettor.id === host.id ? host : guest;
      const bettorToken = bettor.id === host.id ? hostToken : guestToken;
      const bettorSeatToken = bettor.id === host.id ? hostRoom.viewerSeatToken : guestRoom.viewerSeatToken;
      assert.ok(bettorSeatToken);
      const sequence = bettor.id === host.id ? 2 : 1;
      const amount = bettingRoom.minBet;
      const action = {
        roomId: bettingRoom.id,
        amount,
        playerToken: bettorToken,
        actionSeq: sequence,
        actionId: "retryable-bet-001",
      };
      const firstAckPromise = waitForEvent<{ action: string; actionId: string; amount: number }>(
        bettorSocket,
        "game_action_ack"
      );
      bettorSocket.emit("place_bet", action);
      const firstAck = await firstAckPromise;
      assert.deepEqual(firstAck, {
        action: "place_bet",
        actionId: action.actionId,
        roomId: bettingRoom.id,
        amount,
      });

      const retryAckPromise = waitForEvent<{ actionId: string; amount: number }>(bettorSocket, "game_action_ack");
      bettorSocket.emit("place_bet", action);
      const retryAck = await retryAckPromise;
      assert.equal(retryAck.actionId, action.actionId);
      assert.equal(retryAck.amount, amount);

      const appliedPlayer = getRoomSnapshotForTests(bettingRoom.id)?.players.find(
        (player) => player.seatToken === bettorSeatToken
      );
      assert.ok(appliedPlayer);
      assert.equal(appliedPlayer.bet, amount);
      assert.equal(appliedPlayer.chips, bettor.chips - amount);

      const otherSocket = bettorSocket === host ? guest : host;
      const absentSeatUpdate = waitRoom(otherSocket, (room) =>
        room.players.some((player) => player.id.startsWith("offline-"))
      );
      // Desconnexió (no «Sortir»): el seient es guarda durant la gràcia i es pot reprendre.
      bettorSocket.disconnect();
      await absentSeatUpdate;

      rejoinSocket = await connect(url);
      const rejoinedPromise = waitJoined(rejoinSocket);
      rejoinSocket.emit("join_private_table", {
        inviteCode: hostRoom.inviteCode,
        playerName: bettor.name,
        seatToken: bettorSeatToken,
        playerId: bettor.id === host.id ? HOST_ID : GUEST_ID,
        playerToken: bettorToken,
      });
      const resumed = await rejoinedPromise;
      assert.equal(resumed.viewerSeatToken, bettorSeatToken);
      assert.ok(resumed.players.some((player) => player.id === rejoinSocket!.id && player.bet === amount));
    } finally {
      rejoinSocket?.disconnect();
      host.disconnect();
      guest.disconnect();
      io.close();
      await new Promise<void>((resolve) => http.close(() => resolve()));
      resetGameStateForTests();
      await rm(dataDir, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 });
      if (previousDataDir === undefined) delete process.env.BALANCE_DATA_DIR;
      else process.env.BALANCE_DATA_DIR = previousDataDir;
      if (previousFast === undefined) delete process.env.SETIMIG_TEST_FAST;
      else process.env.SETIMIG_TEST_FAST = previousFast;
    }
  });
});
