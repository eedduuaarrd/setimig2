/**
 * Adreça on escolta el servidor HTTP.
 *
 * Per defecte 127.0.0.1: a producció Caddy fa de proxy a 127.0.0.1:4450 i el
 * port no ha de quedar obert a internet. Es pot canviar amb SETIMIG_HOST
 * (preferent) o HOST, p. ex. SETIMIG_HOST=0.0.0.0 per provar des de la xarxa local.
 */
export const DEFAULT_LISTEN_HOST = "127.0.0.1";

export function resolveListenHost(env: NodeJS.ProcessEnv = process.env): string {
  const fromEnv = (env.SETIMIG_HOST ?? env.HOST ?? "").trim();
  return fromEnv || DEFAULT_LISTEN_HOST;
}
