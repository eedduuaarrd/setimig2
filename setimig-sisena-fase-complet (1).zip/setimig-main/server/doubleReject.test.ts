/**
 * `double_bet` rebutjat: `game_error` amb codi de motiu i `actionId`, a privada i a solo.
 * L'estat de la mà no canvia.
 */
import { describe, it, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { createServer } from "node:http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket } from "socket.io-client";
import {
  applyAuthoritativeSoloAction,
  getRoomSnapshotForTests,
  resetGameStateForTests,
  setHostTimersPausedForTests,
  setupGameHandlers,
} from "./game.ts";
import { issuePlayerToken } from "./playerToken.ts";
import { resetPrivateRoomStoreCacheForTests } from "./privateRoomStore.ts";
import { clearRoomTimers, type HandSlot, type Player, type Room } from "../shared/gameEngine.ts";
import { DOUBLE_REJECT_CODE, ENGINE_MESSAGES } from "../shared/gameMessages.ts";
import { removeTestDataDir } from "./testing/testDataDir.ts";

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";

const HOST_ID = "dblrejhost00000001";
const GUEST_ID = "dblrejguest0000001";
const SOLO_ID = "dblrejsolo00000001";

function connect(url: string): Promise<Socket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.on("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.on("connect_error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

function waitJoined(socket: Socket): Promise<{ id: string; inviteCode?: string }> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("join timeout")), 15_000);
    socket.once("joined_room", (room: { id: string; inviteCode?: string }) => {
      clearTimeout(timer);
      resolve(room);
    });
  });
}

function nextError(socket: Socket): Promise<{ code?: string; message?: string; actionId?: string }> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("game_error timeout")), 8_000);
    socket.once("game_error", (err: { code?: string; message?: string; actionId?: string }) => {
      clearTimeout(timer);
      resolve(err);
    });
  });
}

function baseSlot(extra: Partial<HandSlot> = {}): HandSlot {
  return {
    id: "h",
    bet: 100,
    cards: [{ id: "c0", card: { suit: "hearts", value: 4, points: 4 }, faceUp: true }],
    doubled: false,
    canDouble: true,
    mort: false,
    blindPair: false,
    blindUntilBankEnd: false,
    mortOffered: false,
    status: "playing",
    ...extra,
  };
}

function fingerprint(room: Room): string {
  return JSON.stringify({
    phase: room.phase,
    pot: room.pot,
    turn: room.turnPlayerIndex,
    players: room.players.map((p) => ({
      id: p.id,
      chips: p.chips,
      bet: p.bet,
      slots: p.handSlots.map((s) => ({
        bet: s.bet,
        doubled: s.doubled,
        canDouble: s.canDouble,
        n: s.cards.length,
        status: s.status,
        fromSplit: s.fromSplit === true,
        mort: s.mort,
        blind: s.blindPair,
      })),
    })),
  });
}

/** Deixa la sala en torn de `actor`, amb normes de la casa i una mà que es podria doblar. */
function rig(room: Room, actor: Player, banker: Player): void {
  clearRoomTimers(
    { emitRoomUpdate() {}, schedule: () => 0 as unknown as ReturnType<typeof setTimeout>, clearTimeout() {} },
    room,
  );
  room.houseRulesEnabled = true;
  room.phase = "playing";
  room.actionHoldEndsAt = null;
  room.queuedActions = undefined;
  room.pot = 100;
  room.deck = [
    { suit: "clubs", value: 2, points: 2 },
    { suit: "diamonds", value: 3, points: 3 },
  ];
  banker.isBanker = true;
  banker.chips = 50_000;
  banker.bet = 0;
  banker.status = "waiting";
  banker.handSlots = [baseSlot({ bet: 0, canDouble: false })];
  actor.isBanker = false;
  actor.chips = 1_000;
  actor.bet = 100;
  actor.status = "playing";
  actor.activeSlotIndex = 0;
  actor.handSlots = [baseSlot()];
  const nonBankers = room.players.filter((p) => !p.isBanker);
  room.turnPlayerIndex = Math.max(0, nonBankers.findIndex((p) => p.id === actor.id));
}

describe("double_bet rebutjat envia game_error", () => {
  let dataDir: string;

  beforeEach(async () => {
    dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "setimig-dbl-"));
    process.env.BALANCE_DATA_DIR = dataDir;
    process.env.SETIMIG_TEST_FAST = "1";
    resetGameStateForTests();
    resetPrivateRoomStoreCacheForTests();
    setHostTimersPausedForTests(true);
  });

  afterEach(async () => {
    setHostTimersPausedForTests(false);
    resetGameStateForTests();
    delete process.env.SETIMIG_TEST_FAST;
    await removeTestDataDir(dataDir);
  });

  async function withServer(run: (url: string) => Promise<void>) {
    const http = createServer();
    const io = new SocketIOServer(http, { cors: { origin: "*" } });
    await setupGameHandlers(io);
    await new Promise<void>((resolve) => http.listen(0, "127.0.0.1", resolve));
    const address = http.address();
    assert.ok(address && typeof address !== "string");
    try {
      await run(`http://127.0.0.1:${address.port}`);
    } finally {
      io.close();
      await new Promise<void>((resolve) => http.close(() => resolve()));
    }
  }

  it("taula privada: cada motiu, amb actionId, i l'estat no canvia", async () => {
    await withServer(async (url) => {
      const host = await connect(url);
      const guest = await connect(url);
      try {
        const hostToken = issuePlayerToken(HOST_ID)!;
        const guestToken = issuePlayerToken(GUEST_ID)!;
        const created = waitJoined(host);
        host.emit("create_private_table", {
          playerName: "Amfitrió",
          playerId: HOST_ID,
          playerToken: hostToken,
          houseRulesEnabled: true,
        });
        const table = await created;
        const joined = waitJoined(guest);
        guest.emit("join_private_table", {
          inviteCode: table.inviteCode,
          playerName: "Convidat",
          playerId: GUEST_ID,
          playerToken: guestToken,
        });
        await joined;

        const room = getRoomSnapshotForTests(table.id)!;
        const actor = room.players.find((p) => p.playerId === HOST_ID)!;
        const banker = room.players.find((p) => p.playerId === GUEST_ID)!;
        rig(room, actor, banker);

        const expectReject = async (
          label: string,
          payload: Record<string, unknown>,
          code: string,
          message: string,
          actionId: string,
          from: Socket = host,
        ) => {
          const before = fingerprint(room);
          const pending = nextError(from);
          from.emit("double_bet", payload);
          const err = await pending;
          assert.equal(err.code, code, label);
          assert.equal(err.message, message, label);
          assert.equal(err.actionId, actionId, label);
          assert.equal(fingerprint(room), before, label);
        };

        await expectReject(
          "fora de sala",
          { roomId: "no-such", actionId: "fora" },
          "NOT_IN_ROOM",
          ENGINE_MESSAGES.cannotDoubleNow,
          "fora",
        );

        room.phase = "settlement";
        await expectReject(
          "fase",
          { roomId: room.id, actionId: "fase" },
          "BAD_PHASE",
          "Acció no permesa en aquesta fase.",
          "fase",
        );
        room.phase = "playing";

        await expectReject(
          "torn",
          { roomId: room.id, actionId: "torn" },
          "BAD_TURN",
          "No és el teu torn.",
          "torn",
          guest,
        );

        actor.handSlots[0]!.doubled = true;
        actor.handSlots[0]!.canDouble = false;
        await expectReject(
          "ja doblada",
          { roomId: room.id, actionId: "ja" },
          DOUBLE_REJECT_CODE.alreadyDoubled,
          ENGINE_MESSAGES.alreadyDoubled,
          "ja",
        );

        actor.handSlots[0] = baseSlot({
          fromSplit: true,
          splitFromDoubled: true,
          canDouble: false,
          doubled: false,
          cards: [
            { id: "a", card: { suit: "spades", value: 12, points: 0.5 }, faceUp: true },
            { id: "b", card: { suit: "clubs", value: 3, points: 3 }, faceUp: true },
          ],
        });
        await expectReject(
          "split ja doblat",
          { roomId: room.id, requestId: "split-id" },
          DOUBLE_REJECT_CODE.splitAlreadyDoubled,
          ENGINE_MESSAGES.splitAlreadyDoubled,
          "split-id",
        );

        actor.handSlots[0] = baseSlot({
          fromSplit: true,
          canDouble: false,
          doubled: false,
          cards: [
            { id: "a", card: { suit: "spades", value: 10, points: 0.5 }, faceUp: true },
            { id: "b", card: { suit: "clubs", value: 5, points: 5 }, faceUp: true },
          ],
        });
        await expectReject(
          "mà separada",
          { roomId: room.id, actionId: "separada" },
          DOUBLE_REJECT_CODE.splitCannotDouble,
          ENGINE_MESSAGES.splitCannotDouble,
          "separada",
        );

        actor.handSlots[0] = baseSlot({ canDouble: false });
        await expectReject(
          "canDouble",
          { roomId: room.id, actionId: "no" },
          DOUBLE_REJECT_CODE.cannotDouble,
          ENGINE_MESSAGES.cannotDouble,
          "no",
        );

        actor.handSlots[0] = baseSlot();
        actor.handSlots[0]!.cards.push({ id: "c1", card: { suit: "clubs", value: 2, points: 2 }, faceUp: true });
        await expectReject(
          "cartes",
          { roomId: room.id, actionId: "cartes" },
          DOUBLE_REJECT_CODE.wrongCards,
          ENGINE_MESSAGES.cannotDouble,
          "cartes",
        );

        actor.handSlots[0] = baseSlot();
        actor.chips = 10;
        await expectReject(
          "fitxes",
          { roomId: room.id, actionId: "fitxes" },
          DOUBLE_REJECT_CODE.notEnoughChips,
          ENGINE_MESSAGES.noChipsDouble,
          "fitxes",
        );

        actor.chips = 1_000;
        banker.chips = 100;
        await expectReject(
          "banca",
          { roomId: room.id, actionId: "banca" },
          DOUBLE_REJECT_CODE.bankCannotCover,
          ENGINE_MESSAGES.bankCannotCoverDouble,
          "banca",
        );

        banker.chips = 50_000;
        room.houseRulesEnabled = false;
        await expectReject(
          "casa",
          { roomId: room.id, actionId: "casa" },
          DOUBLE_REJECT_CODE.houseRules,
          ENGINE_MESSAGES.cannotDouble,
          "casa",
        );

        room.houseRulesEnabled = true;
        actor.handSlots[0] = baseSlot({ mortOffered: true });
        await expectReject(
          "mort pendent",
          { roomId: room.id, actionId: "mort" },
          DOUBLE_REJECT_CODE.decideMortFirst,
          ENGINE_MESSAGES.decideMortFirst,
          "mort",
        );

        actor.handSlots[0] = baseSlot({ swapOffered: 3 });
        await expectReject(
          "canvi pendent",
          { roomId: room.id, actionId: "canvi" },
          DOUBLE_REJECT_CODE.decideSwapFirst,
          ENGINE_MESSAGES.decideSwapFirst,
          "canvi",
        );

        actor.handSlots[0] = baseSlot({ mort: true, canDouble: false });
        await expectReject(
          "mort",
          { roomId: room.id, actionId: "mort-fet" },
          DOUBLE_REJECT_CODE.mort,
          ENGINE_MESSAGES.cannotDouble,
          "mort-fet",
        );

        actor.handSlots[0] = baseSlot({ blindPair: true });
        await expectReject(
          "cega",
          { roomId: room.id, actionId: "cega" },
          DOUBLE_REJECT_CODE.blindPairLocked,
          ENGINE_MESSAGES.blindPairLocked,
          "cega",
        );
      } finally {
        host.disconnect();
        guest.disconnect();
      }
    });
  });

  it("solo per socket i per HTTP: el mateix motor, amb actionId", async () => {
    await withServer(async (url) => {
      const socket = await connect(url);
      try {
        const joined = waitJoined(socket);
        socket.emit("join_solo_room", {
          playerName: "Solo",
          playerId: SOLO_ID,
          botCount: 1,
          practiceMode: true,
          houseRulesEnabled: true,
          intent: "new",
        });
        const table = await joined;
        const room = getRoomSnapshotForTests(table.id)!;
        const actor = room.players.find((p) => p.playerId === SOLO_ID)!;
        const banker = room.players.find((p) => p.isBot)!;
        rig(room, actor, banker);

        room.phase = "banker";
        const phaseBefore = fingerprint(room);
        const phaseErr = nextError(socket);
        socket.emit("double_bet", { roomId: room.id, actionId: "solo-fase" });
        const phase = await phaseErr;
        assert.equal(phase.code, DOUBLE_REJECT_CODE.badPhase);
        assert.equal(phase.message, ENGINE_MESSAGES.cannotDoubleNow);
        assert.equal(phase.actionId, "solo-fase");
        assert.equal(fingerprint(room), phaseBefore);
        room.phase = "playing";

        actor.handSlots[0] = baseSlot({ canDouble: false });
        const before = fingerprint(room);
        const cannot = nextError(socket);
        socket.emit("double_bet", { roomId: room.id, actionId: "solo-no" });
        const err = await cannot;
        assert.equal(err.code, DOUBLE_REJECT_CODE.cannotDouble);
        assert.equal(err.message, ENGINE_MESSAGES.cannotDouble);
        assert.equal(err.actionId, "solo-no");
        assert.equal(fingerprint(room), before);

        const token = issuePlayerToken(SOLO_ID)!;
        const seq = () => (actor.lastActionSeq ?? 0) + 1;
        const http = await applyAuthoritativeSoloAction(
          SOLO_ID,
          "double_bet",
          { actionId: "http-fitxes" },
          { playerToken: token, actionSeq: seq() },
        );
        assert.equal(http.error?.code, DOUBLE_REJECT_CODE.cannotDouble);
        assert.equal(http.error?.actionId, "http-fitxes");
        assert.equal(fingerprint(room), before);

        actor.handSlots[0] = baseSlot();
        actor.chips = 0;
        const poor = await applyAuthoritativeSoloAction(
          SOLO_ID,
          "double_bet",
          { actionId: "http-pobre" },
          { playerToken: token, actionSeq: seq() },
        );
        assert.equal(poor.error?.code, DOUBLE_REJECT_CODE.notEnoughChips);
        assert.equal(poor.error?.message, ENGINE_MESSAGES.noChipsDouble);
        assert.equal(poor.error?.actionId, "http-pobre");
        assert.equal(actor.chips, 0);
        assert.equal(actor.handSlots[0]!.doubled, false);

        actor.chips = 1_000;
        actor.handSlots[0] = baseSlot({
          fromSplit: true,
          canDouble: false,
          cards: [
            { id: "a", card: { suit: "hearts", value: 10, points: 0.5 }, faceUp: true },
            { id: "b", card: { suit: "clubs", value: 11, points: 0.5 }, faceUp: true },
          ],
        });
        const splitHand = await applyAuthoritativeSoloAction(
          SOLO_ID,
          "double_bet",
          { actionId: "http-separada" },
          { playerToken: token, actionSeq: seq() },
        );
        assert.equal(splitHand.error?.code, DOUBLE_REJECT_CODE.splitCannotDouble);
        assert.equal(splitHand.error?.message, ENGINE_MESSAGES.splitCannotDouble);
        assert.equal(splitHand.error?.actionId, "http-separada");
        assert.equal(actor.handSlots[0]!.doubled, false);
        assert.equal(actor.handSlots.length, 1);
      } finally {
        socket.disconnect();
      }
    });
  });
});
