/**
 * Ajudes de test per a directoris de dades temporals (no s'importa des del codi de producció).
 *
 * El servidor escriu en diferit (escriptures agrupades, cadenes d'escriptura per store i
 * estadístiques «fire-and-forget»). Esborrar el directori mentre una escriptura és en vol
 * donava ENOENT (rename d'un .tmp a un directori ja esborrat) o ENOTEMPTY (un fitxer nou creat
 * durant l'esborrat). Aquí primer s'aturen els temporitzadors del joc, es buiden totes les cues
 * d'escriptura fins que no en queda cap, i després s'esborra amb reintents.
 */
import fs from "node:fs/promises";
import { resetGameStateForTests } from "../game.ts";
import { flushAllPendingWrites } from "../writeCoalescing.ts";
import { flushPrivateRoomStoreWritesForTests } from "../privateRoomStore.ts";
import { flushPlayerStatsWritesForTests } from "../playerStats.ts";
import { flushEngagementWritesForTests } from "../achievementsStore.ts";
import { flushFriendsStoreWritesForTests } from "../friends/friendsStore.ts";
import { flushSoloIsolatedSessionWritesForTests } from "../soloIsolatedSessions.ts";

/** Atura el joc i espera que totes les escriptures pendents hagin acabat. */
export async function drainServerWritesForTests(): Promise<void> {
  resetGameStateForTests();
  // Unes quantes passades: una escriptura en pot encadenar una altra (p. ex. stats → assoliments).
  // Els errors d'escriptura ja els comprova cada test; aquí només s'espera que acabin.
  const settle = (p: Promise<void>) => p.catch(() => undefined);
  for (let i = 0; i < 5; i++) {
    await settle(flushPrivateRoomStoreWritesForTests());
    await settle(flushPlayerStatsWritesForTests());
    await settle(flushEngagementWritesForTests());
    await settle(flushFriendsStoreWritesForTests());
    await settle(flushSoloIsolatedSessionWritesForTests());
    await settle(flushAllPendingWrites());
    await new Promise<void>((r) => setImmediate(r));
  }
}

/** Buida les escriptures i esborra el directori; reintenta si encara hi entra alguna cosa. */
export async function removeTestDataDir(dir: string): Promise<void> {
  for (let attempt = 0; ; attempt++) {
    await drainServerWritesForTests();
    try {
      await fs.rm(dir, { recursive: true, force: true, maxRetries: 10, retryDelay: 20 });
      return;
    } catch (err) {
      const code = (err as NodeJS.ErrnoException).code;
      if (attempt >= 4 || (code !== "ENOTEMPTY" && code !== "EBUSY")) throw err;
    }
  }
}
