import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { mkdtempSync, mkdirSync, rmSync, writeFileSync } from "node:fs";
import { createServer, type Server } from "node:http";
import os from "node:os";
import path from "node:path";
import express from "express";

const dataDir = mkdtempSync(path.join(os.tmpdir(), "setimig-html-login-"));
process.env.BALANCE_DATA_DIR = dataDir;
process.env.PROFILE_DATA_DIR = path.join(dataDir, "profiles");
process.env.PLAYER_TOKEN_SECRET = "test-html-estatic-login-secret";

const { loginWithIdentity } = await import("./auth/identityStore.ts");
const { issuePlayerToken } = await import("./playerToken.ts");
const { registerManifestRedirect } = await import("./spaFallback.ts");
const { mountStaticDist } = await import("./staticAssets.ts");

const ACCOUNT_ID = "htmlacct000000000000000000000000000000001";
const ORPHAN_ID = "htmlorphan0000000000000000000000000000001";

describe("HTML estàtic de dist/ amb login obligatori", () => {
  let dist = "";
  let server: Server;
  let base = "";
  let token = "";
  let orphanToken = "";

  before(async () => {
    mkdirSync(dataDir, { recursive: true });
    const r = await loginWithIdentity({
      kind: "email",
      email: "html@example.com",
      current: { playerId: ACCOUNT_ID, legacy: false },
      allowCreate: false,
    });
    assert.ok(r.ok);
    token = issuePlayerToken(ACCOUNT_ID)!;
    orphanToken = issuePlayerToken(ORPHAN_ID)!;
    dist = mkdtempSync(path.join(os.tmpdir(), "setimig-html-dist-"));
    const w = (rel: string, body: string) => {
      mkdirSync(path.dirname(path.join(dist, rel)), { recursive: true });
      writeFileSync(path.join(dist, rel), body);
    };
    w("index.html", "<!doctype html><title>Shell</title>");
    w("offline.html", "<!doctype html><title>Offline</title>");
    w("regles/index.html", "<!doctype html><title>Regles</title>");
    w("regles/ca/index.html", "<!doctype html><title>Regles CA</title>");
    w("faq/index.html", "<!doctype html><title>FAQ</title>");
    w("altre.html", "<!doctype html><title>Altre</title>");
    w("privacy/index.html", "<!doctype html><title>Privacy</title>");
    w("terms/index.html", "<!doctype html><title>Terms</title>");
    w("assets/index-AAAA.js", "console.log(1);");
    w("assets/index-AAAA.css", "body{}");
    w("assets/font-AAAA.woff2", "font");
    w("icons/icon-192.png", "png");
    w("sw.js", "self.addEventListener(fetch,()=>{});");
    w("site.webmanifest", "{\"name\":\"Set i Mig\"}");
    const app = express();
    registerManifestRedirect(app);
    mountStaticDist(app, dist);
    server = createServer(app);
    await new Promise<void>((r2) => server.listen(0, "127.0.0.1", () => r2()));
    base = `http://127.0.0.1:${(server.address() as { port: number }).port}`;
  });

  after(async () => {
    await new Promise<void>((r) => server.close(() => r()));
    rmSync(dist, { recursive: true, force: true });
    rmSync(dataDir, { recursive: true, force: true });
  });

  const get = (p: string, tok?: string) =>
    fetch(base + p, { redirect: "manual", headers: tok ? { authorization: `Bearer ${tok}` } : {} });

  it("sense sessió: /regles, /regles/, /faq/ i altres HTML → /login?next=", async () => {
    const cases: Array<[string, string]> = [
      ["/regles", "/login?next=%2Fregles"],
      ["/regles/", "/login?next=%2Fregles%2F"],
      ["/regles/index.html", "/login?next=%2Fregles%2Findex.html"],
      ["/regles/ca/", "/login?next=%2Fregles%2Fca%2F"],
      ["/faq/", "/login?next=%2Ffaq%2F"],
      ["/faq", "/login?next=%2Ffaq"],
      ["/altre.html", "/login?next=%2Faltre.html"],
    ];
    for (const [p, loc] of cases) {
      const res = await get(p);
      assert.equal(res.status, 302, p);
      assert.equal(res.headers.get("location"), loc, p);
      assert.doesNotMatch(await res.text(), /Regles|FAQ|Altre/, p);
    }
  });

  it("token sense compte també redirigeix", async () => {
    const res = await get("/regles/", orphanToken);
    assert.equal(res.status, 302);
  });

  it("públics sense sessió: /privacy, /terms, /login, shell i offline", async () => {
    for (const [p, re] of [
      ["/privacy", /Privacy/],
      ["/terms", /Terms/],
      ["/login", /Shell/],
      ["/login/correu", /Shell/],
      ["/", /Shell/],
      ["/offline.html", /Offline/],
    ] as Array<[string, RegExp]>) {
      const res = await get(p);
      assert.equal(res.status, 200, p);
      assert.match(await res.text(), re, p);
    }
  });

  it("assets, sw.js, manifest i icones continuen públics", async () => {
    for (const p of [
      "/assets/index-AAAA.js",
      "/assets/index-AAAA.css",
      "/assets/font-AAAA.woff2",
      "/icons/icon-192.png",
      "/sw.js",
      "/site.webmanifest",
    ]) {
      const res = await get(p);
      assert.equal(res.status, 200, p);
    }
  });

  it("galeta setimig_session: vàlida → 200; invàlida o sense compte → 302", async () => {
    const withCookie = (p: string, c: string) => fetch(base + p, { redirect: "manual", headers: { cookie: c } });
    const ok = await withCookie("/regles/", `altra=1; setimig_session=${token}`);
    assert.equal(ok.status, 200);
    assert.match(await ok.text(), /Regles/);
    assert.equal((await withCookie("/faq/", `setimig_session=${token}`)).status, 200);
    for (const c of [`setimig_session=${token}x`, "setimig_session=brossa.brossa", `setimig_session=${orphanToken}`, "setimig_session="]) {
      const res = await withCookie("/regles/", c);
      assert.equal(res.status, 302, c.slice(0, 20));
      assert.equal(res.headers.get("location"), "/login?next=%2Fregles%2F");
    }
  });

  it("amb sessió: HTML accessible com abans", async () => {
    const r1 = await get("/regles/", token);
    assert.equal(r1.status, 200);
    assert.match(await r1.text(), /Regles/);
    const r2 = await get("/faq/", token);
    assert.equal(r2.status, 200);
    const r3 = await get("/regles", token);
    assert.equal(r3.status, 301);
    assert.equal(r3.headers.get("location"), "/regles/");
  });
});
