import type { Request, Response } from "express";
import { isAllowedOrigin } from "./allowedOrigins.ts";
import { playerHasAccount } from "./auth/identityStore.ts";
import {
  issuePlayerToken,
  readTokenFromAuthHeader,
  resolvePlayerIdFromParts,
  verifyPlayerToken,
} from "./playerToken.ts";
import { hashToken, linkTokenToSession } from "./revokedTokens.ts";
import { readSessionCookie } from "./sessionCookie.ts";

type CredentialRequest = Pick<Request, "headers" | "body" | "query"> & { path?: string; method?: string };

export type RenewalCredential = {
  token: string;
  playerId: string;
  exp: number;
  sid?: string;
  /** `bearer`: Authorization o playerToken al cos/query. `cookie`: només la galeta. */
  source: "bearer" | "cookie";
};

export function resolvePlayerFromRequest(req: Request): { playerId: string; legacy: boolean } | null {
  const token =
    readTokenFromAuthHeader(req.headers.authorization) ??
    (typeof req.body?.playerToken === "string" ? req.body.playerToken : null) ??
    (typeof req.query?.playerToken === "string" ? req.query.playerToken : null);

  const legacyPlayerId =
    req.body?.playerId ?? req.query?.playerId ?? req.body?.playerID ?? req.query?.playerID;

  return resolvePlayerIdFromParts({ token, legacyPlayerId });
}

/**
 * Primer token explícit, amb el mateix ordre de sempre: Authorization, cos, query.
 * Si n'hi ha un de no buit però invàlid, no es mira el següent (no es canvia de compte).
 */
function firstExplicitToken(req: CredentialRequest): string | null {
  return (
    readTokenFromAuthHeader(req.headers.authorization) ??
    (typeof req.body?.playerToken === "string" && req.body.playerToken.trim() ? req.body.playerToken.trim() : null) ??
    (typeof req.query?.playerToken === "string" && req.query.playerToken.trim() ? req.query.playerToken.trim() : null)
  );
}

/**
 * Qui guanya a la renovació:
 * - Un token explícit vàlid (Bearer, o playerToken al cos/query) guanya sempre, encara que
 *   la galeta sigui d'un altre compte. No es fusionen els playerId.
 * - Si aquest token falta, és invàlid, ha caducat o està revocat, i `allowCookie` és cert,
 *   es recupera la galeta `setimig_session` amb les mateixes condicions (vàlida, no caducada, no revocada).
 * - Si no n'hi ha cap, null. No es crea cap usuari.
 */
export function resolveRenewalCredential(
  req: CredentialRequest,
  opts?: { allowCookie?: boolean },
): RenewalCredential | null {
  const explicit = firstExplicitToken(req);
  if (explicit) {
    const verified = verifyPlayerToken(explicit);
    if (verified) {
      return { token: explicit, playerId: verified.playerId, exp: verified.exp, sid: verified.sid, source: "bearer" };
    }
    if (!opts?.allowCookie) return null;
  } else if (!opts?.allowCookie) {
    return null;
  }
  const cookie = readSessionCookie(req);
  if (!cookie) return null;
  const verified = verifyPlayerToken(cookie);
  if (!verified) return null;
  return { token: cookie, playerId: verified.playerId, exp: verified.exp, sid: verified.sid, source: "cookie" };
}

/**
 * Renova una sessió existent. Emet un token nou de la mateixa sessió (no crea jugadors).
 * El token anterior continua valent fins al logout, que revoca tota la cadena.
 * La galeta només es consulta aquí; la resta de l'API no l'accepta.
 */
export async function createPlayerSession(
  req: CredentialRequest,
): Promise<{ playerId: string; playerToken: string } | null> {
  const cred = resolveRenewalCredential(req, { allowCookie: true });
  if (!cred) return null;
  const sid = cred.sid ?? hashToken(cred.token);
  const playerToken = issuePlayerToken(cred.playerId, undefined, sid);
  if (!playerToken) return null;
  const child = verifyPlayerToken(playerToken);
  await linkTokenToSession(cred.token, sid, Math.max(cred.exp, child?.exp ?? cred.exp));
  return { playerId: cred.playerId, playerToken };
}

/**
 * POST /api/player-session. La galeta, si és la credencial que guanya, passa pel mateix
 * control d'origen que el login (SameSite=Lax ja evita el POST creuat; això tanca l'origen).
 * Cal compte verificat: no es crea ningú.
 */
export async function handleRenewPlayerSession(req: Request, res: Response): Promise<void> {
  const cred = resolveRenewalCredential(req, { allowCookie: true });
  if (cred?.source === "cookie" && !isAllowedOrigin(req.headers.origin, req.headers.host)) {
    res.status(403).json({ error: "Origen no permès.", code: "BAD_ORIGIN" });
    return;
  }
  if (!cred || !(await playerHasAccount(cred.playerId))) {
    res.status(401).json({ error: "auth_required" });
    return;
  }
  try {
    const session = await createPlayerSession(req);
    if (!session) {
      res.status(401).json({ error: "auth_required" });
      return;
    }
    res.json(session);
  } catch (err) {
    console.error("[api] player-session:", err instanceof Error ? err.message : err);
    res.status(500).json({ error: "Error intern. Torna-ho a provar." });
  }
}

export function sendPlayerResponse(
  res: { json: (body: unknown) => unknown },
  body: Record<string, unknown>,
): void {
  res.json(body);
}
