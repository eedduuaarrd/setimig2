import Stripe from "stripe";

export function isPaymentsEnabled(): boolean {
  return process.env.PAYMENTS_ENABLED === "true";
}

function isLiveStripeKey(key: string): boolean {
  const trimmed = key.trim();
  return (
    trimmed.startsWith("sk_live") ||
    trimmed.startsWith("pk_live") ||
    trimmed.startsWith("rk_live")
  );
}

/** Stripe client only when PAYMENTS_ENABLED=true and keys are test-mode. */
export function createStripeClient(): Stripe | null {
  if (!isPaymentsEnabled()) {
    return null;
  }

  const secretKey = process.env.STRIPE_SECRET_KEY?.trim() ?? "";
  const publishableKey = process.env.STRIPE_PUBLISHABLE_KEY?.trim() ?? "";

  if (!secretKey) {
    return null;
  }

  if (isLiveStripeKey(secretKey) || (publishableKey && isLiveStripeKey(publishableKey))) {
    console.error(
      "[payments] Claus Stripe LIVE (sk_live_/pk_live_/rk_live_) no permeses. Pagaments desactivats.",
    );
    return null;
  }

  if (!secretKey.startsWith("sk_test_")) {
    console.error(
      "[payments] STRIPE_SECRET_KEY ha de ser sk_test_... Pagaments desactivats.",
    );
    return null;
  }

  if (publishableKey && !publishableKey.startsWith("pk_test_")) {
    console.error(
      "[payments] STRIPE_PUBLISHABLE_KEY ha de ser pk_test_... Pagaments desactivats.",
    );
    return null;
  }

  return new Stripe(secretKey);
}
