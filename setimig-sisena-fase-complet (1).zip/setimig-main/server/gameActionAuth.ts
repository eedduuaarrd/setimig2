import type { Room } from "../shared/gameEngine.ts";
import type { Player } from "../shared/gameEngine.ts";
import { currentPlayer } from "../shared/gameEngine.ts";
import { issuePlayerToken, verifyPlayerToken } from "./playerToken.ts";

export type GameActionError = { message: string; code: string };

export type PrivateActionMeta = {
  playerToken?: unknown;
  actionSeq?: unknown;
};

export function verifyPrivatePlayerToken(
  player: Player,
  playerToken: unknown
): GameActionError | null {
  const verified = verifyPlayerToken(playerToken);
  if (!verified) {
    return { message: "Token de jugador invalid o caducat.", code: "BAD_TOKEN" };
  }
  if (verified.playerId !== player.playerId) {
    return { message: "El token no correspon a aquest seient.", code: "BAD_TOKEN" };
  }
  return null;
}

export function consumePrivateActionSeq(player: Player, actionSeq: unknown): GameActionError | null {
  if (typeof actionSeq !== "number" || !Number.isInteger(actionSeq) || actionSeq < 1) {
    return { message: "Seqüència d'acció invalida.", code: "BAD_ACTION_SEQ" };
  }
  const last = player.lastActionSeq ?? 0;
  if (actionSeq <= last) {
    return { message: "Acció duplicada o reenviada.", code: "REPLAY" };
  }
  player.lastActionSeq = actionSeq;
  return null;
}

export function validatePrivateTurn(
  room: Room,
  player: Player,
  opts: { requireTurn?: boolean; allowedPhases?: Room["phase"][] }
): GameActionError | null {
  if (opts.allowedPhases && !opts.allowedPhases.includes(room.phase)) {
    return { message: "Acció no permesa en aquesta fase.", code: "BAD_PHASE" };
  }
  if (opts.requireTurn && room.phase === "playing") {
    const turn = currentPlayer(room);
    if (!turn || turn.seatToken !== player.seatToken) {
      return { message: "No és el teu torn.", code: "BAD_TURN" };
    }
  }
  if (opts.requireTurn && room.phase === "banker") {
    const banker = room.players.find((p) => p.isBanker);
    if (!banker || banker.seatToken !== player.seatToken) {
      return { message: "No és el teu torn.", code: "BAD_TURN" };
    }
  }
  return null;
}

/** Cap token enviat (absent, null o cadena buida): el client és de camí llegat lligat al socket. */
export function isMissingPlayerToken(playerToken: unknown): boolean {
  return playerToken === undefined || playerToken === null || (typeof playerToken === "string" && !playerToken.trim());
}

/** Socket-bound clients often emit legacy string payloads without token/seq; fill safely. */
export function normalizePrivateActionMeta(player: Player, meta: PrivateActionMeta): PrivateActionMeta {
  let playerToken = meta.playerToken;
  const verified = verifyPlayerToken(playerToken);
  if (!verified || verified.playerId !== player.playerId) {
    if (isMissingPlayerToken(playerToken)) {
      playerToken = issuePlayerToken(player.playerId) ?? undefined;
    }
  }
  let actionSeq = meta.actionSeq;
  if (typeof actionSeq !== "number" || !Number.isInteger(actionSeq) || actionSeq < 1) {
    actionSeq = (player.lastActionSeq ?? 0) + 1;
  }
  return { playerToken, actionSeq };
}

export function authorizePrivateAction(
  room: Room,
  player: Player | undefined,
  meta: PrivateActionMeta,
  opts: { requireTurn?: boolean; allowedPhases?: Room["phase"][] }
): GameActionError | null {
  if (!room.isPrivate) return null;
  if (!player || player.isBot) {
    return { message: "Jugador no trobat a la taula.", code: "NOT_IN_ROOM" };
  }
  const normalized = normalizePrivateActionMeta(player, meta);
  const tokenErr = verifyPrivatePlayerToken(player, normalized.playerToken);
  if (tokenErr) return tokenErr;
  const seqErr = consumePrivateActionSeq(player, normalized.actionSeq);
  if (seqErr) return seqErr;
  return validatePrivateTurn(room, player, opts);
}

/**
 * Partida solo servida per HTTP (el client no té l'estat). A diferència de la taula privada,
 * el token no es pot ometre ni reemetre: cada acció porta el Bearer del jugador i una seqüència.
 */
export function authorizeSoloClientAction(
  room: Room,
  player: Player | undefined,
  meta: PrivateActionMeta,
  opts: { requireTurn?: boolean; allowedPhases?: Room["phase"][] }
): GameActionError | null {
  if (!room.soloAi) {
    return { message: "Aquesta sala no és una partida solo.", code: "NOT_SOLO" };
  }
  if (!player || player.isBot || player.playerId !== room.soloHumanPlayerId) {
    return { message: "Jugador no trobat a la taula.", code: "NOT_IN_ROOM" };
  }
  const tokenErr = verifyPrivatePlayerToken(player, meta.playerToken);
  if (tokenErr) return tokenErr;
  const seqErr = consumePrivateActionSeq(player, meta.actionSeq);
  if (seqErr) return seqErr;
  return validatePrivateTurn(room, player, opts);
}
