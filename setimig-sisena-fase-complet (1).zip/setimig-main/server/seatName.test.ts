import { describe, it, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";
import fs from "fs/promises";
import os from "os";
import path from "path";
import { createServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket } from "socket.io-client";
import { resetGameStateForTests, setupGameHandlers } from "./game.ts";
import { upsertProfile } from "./profiles.ts";
import { resetBalanceStoreCacheForTests, setBalance } from "./balances.ts";
import { getChipRankingView } from "./chipRanking.ts";
import { resetPrivateRoomStoreCacheForTests } from "./privateRoomStore.ts";

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";

const HOST_ID = "nomclaraqa01";
const GUEST_ID = "nomconvidat01";

function connect(url: string): Promise<Socket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.on("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.on("connect_error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

function waitJoined(socket: Socket): Promise<{ players?: { name: string; isBot?: boolean }[] }> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("join timeout")), 15_000);
    socket.once("joined_room", (room) => {
      clearTimeout(timer);
      resolve(room);
    });
  });
}

async function startServer() {
  const http = createServer();
  const io = new SocketIOServer(http, { cors: { origin: "*" } });
  await setupGameHandlers(io);
  await new Promise<void>((r) => http.listen(0, "127.0.0.1", () => r()));
  const port = (http.address() as { port: number }).port;
  return { url: `http://127.0.0.1:${port}`, http, io };
}

describe("el nom del perfil és el de la taula i el del rànquing", () => {
  let dataDir: string;

  beforeEach(async () => {
    dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "setimig-seat-name-"));
    process.env.BALANCE_DATA_DIR = dataDir;
    process.env.PROFILE_DATA_DIR = path.join(dataDir, "profiles");
    resetBalanceStoreCacheForTests();
    resetGameStateForTests();
    resetPrivateRoomStoreCacheForTests();
  });

  afterEach(async () => {
    resetGameStateForTests();
    await fs.rm(dataDir, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 });
  });

  it("ignora el nom aleatori del client si el perfil ja té displayName", async () => {
    await upsertProfile(HOST_ID, { displayName: "Clara QA" });
    await upsertProfile(GUEST_ID, { displayName: "Otger" });
    await setBalance(HOST_ID, 5_000);
    await setBalance(GUEST_ID, 4_000);
    const { url, http, io } = await startServer();
    const host = await connect(url);
    const guest = await connect(url);
    try {
      host.emit("create_private_table", { playerName: "Núria", playerId: HOST_ID });
      const created = await waitJoined(host);
      const hostSeat = created.players?.find((p) => !p.isBot);
      assert.equal(hostSeat?.name, "Clara QA");

      guest.emit("join_solo_room", { playerName: "Núria", playerId: GUEST_ID, botCount: 1 });
      const solo = await waitJoined(guest);
      const human = solo.players?.find((p) => !p.isBot);
      assert.equal(human?.name, "Otger");

      const ranking = await getChipRankingView(HOST_ID);
      assert.equal(ranking.me.displayName, "Clara QA");
      assert.equal(
        ranking.entries.some((e) => e.displayName === "Núria"),
        false
      );
      assert.equal(ranking.entries.find((e) => e.displayName === "Otger")?.displayName, "Otger");
    } finally {
      host.disconnect();
      guest.disconnect();
      io.close();
      await new Promise<void>((r) => http.close(() => r()));
    }
  });
});
