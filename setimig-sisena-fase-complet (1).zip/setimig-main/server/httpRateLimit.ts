import type { NextFunction, Request, Response } from "express";
import { trustedClientIp } from "./clientIp.ts";

/**
 * Small in-memory per-client limiter for /api (fixed window). Behind Cloudflare →
 * Caddy (loopback) the client is identified by CF-Connecting-IP; that header is ignored
 * when the connection does not come from loopback (socket address is used instead).
 * Direct loopback calls without the header (health checks, local gates) are not limited.
 */
export const API_WINDOW_MS = 60_000;
export const API_MAX_REQUESTS = 120;
export const API_MAX_WRITES = 30;

type Bucket = { start: number; all: number; writes: number };
const buckets = new Map<string, Bucket>();

export function resetApiRateLimitForTests(): void {
  buckets.clear();
}

export function clientKey(req: Pick<Request, "headers" | "socket">): string | null {
  return trustedClientIp(req.socket.remoteAddress, req.headers);
}

export function checkApiRate(key: string, isWrite: boolean, now = Date.now()): boolean {
  let b = buckets.get(key);
  if (!b || now - b.start >= API_WINDOW_MS) {
    b = { start: now, all: 0, writes: 0 };
    buckets.set(key, b);
    if (buckets.size > 20_000) {
      for (const [k, v] of buckets) if (now - v.start >= API_WINDOW_MS) buckets.delete(k);
    }
  }
  b.all += 1;
  if (isWrite) b.writes += 1;
  return b.all <= API_MAX_REQUESTS && b.writes <= API_MAX_WRITES;
}

export function apiRateLimit(req: Request, res: Response, next: NextFunction): void {
  if (!req.path.startsWith("/api/") || req.path === "/api/health") return next();
  const key = clientKey(req);
  if (!key) return next();
  const isWrite = req.method !== "GET" && req.method !== "HEAD";
  if (checkApiRate(key, isWrite)) return next();
  res.setHeader("Retry-After", "60");
  res.status(429).json({ error: "Massa peticions. Torna-ho a provar d'aquí a un minut.", code: "RATE_LIMIT" });
}
