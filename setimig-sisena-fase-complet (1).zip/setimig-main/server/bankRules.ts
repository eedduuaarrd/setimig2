export * from "../shared/bankRules.ts";
