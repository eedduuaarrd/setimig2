export * from "../../shared/ai/deck.ts";
