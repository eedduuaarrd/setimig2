import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { fullShoeHistogram, histogramTotal, remainingFromSeen } from "./deck.ts";
import {
  decideBetAmount,
  decideHitOrStand,
  decideMort,
  probBustOneDraw,
  type StrategyContext,
} from "./strategy.ts";
import type { Card } from "../../src/gameTypes.ts";

function card(value: number): Card {
  const points = value >= 10 ? 0.5 : value;
  return { suit: "hearts", value, points };
}

describe("deck counting", () => {
  it("full shoe is ONE 40-card deck", () => {
    assert.equal(histogramTotal(fullShoeHistogram()), 40);
    assert.equal(fullShoeHistogram().get(0.5), 12);
    assert.equal(fullShoeHistogram().get(7), 4);
  });

  it("remaining shrinks when cards seen", () => {
    const seen = [card(7), card(7), card(1)];
    const rem = remainingFromSeen(seen);
    assert.equal(histogramTotal(rem), 37);
    assert.equal(rem.get(7), 2);
  });

  it("bots see 37.5% bust risk at 5 points with four 7s and four 6s out", () => {
    const seen = [card(7), card(7), card(7), card(7), card(6), card(6), card(6), card(6)];
    const rem = remainingFromSeen(seen);
    assert.equal(histogramTotal(rem), 32);
    assert.equal(probBustOneDraw(5, rem), 0.375);
  });
});

describe("probBustOneDraw", () => {
  it("high score has high bust probability", () => {
    const hist = remainingFromSeen([]);
    const p = probBustOneDraw(7, hist);
    assert.ok(p > 0.3);
  });

  it("moderate score has lower bust probability than near 7", () => {
    const hist = remainingFromSeen([]);
    const low = probBustOneDraw(4, hist);
    const high = probBustOneDraw(7, hist);
    assert.ok(low < high);
  });
});

describe("decideBetAmount", () => {
  it("respects min bet and chips", () => {
    assert.equal(decideBetAmount({ minBet: 100, chips: 5000 }), 200);
    assert.equal(decideBetAmount({ minBet: 100, chips: 150 }), 100);
  });
});

describe("decideHitOrStand", () => {
  it("stands on 7.5", () => {
    const ctx: StrategyContext = {
      seen: [],
      hand: [card(7), card(10)],
      minBet: 100,
      chips: 5000,
      bet: 100,
      rivalVisibleMax: 5,
      bankerTargetScores: [],
      isBanker: false,
      mortOffered: false,
      canDouble: false,
      canSplit: false,
      blindPair: false,
    };
    assert.equal(decideHitOrStand(ctx), "stand");
  });

  it("hits on low total", () => {
    const ctx: StrategyContext = {
      seen: [],
      hand: [card(2)],
      minBet: 100,
      chips: 5000,
      bet: 100,
      rivalVisibleMax: 6,
      bankerTargetScores: [],
      isBanker: false,
      mortOffered: false,
      canDouble: false,
      canSplit: false,
      blindPair: false,
    };
    assert.equal(decideHitOrStand(ctx), "hit");
  });

  it("banker stands when beating visible targets", () => {
    const ctx: StrategyContext = {
      seen: [],
      hand: [card(6), card(10)],
      minBet: 100,
      chips: 5000,
      bet: 0,
      rivalVisibleMax: 0,
      bankerTargetScores: [5, 5.5],
      isBanker: true,
      mortOffered: false,
      canDouble: false,
      canSplit: false,
      blindPair: false,
    };
    assert.equal(decideHitOrStand(ctx), "stand");
  });
});

describe("decideMort", () => {
  it("declines mort with large stack", () => {
    const ctx: StrategyContext = {
      seen: [],
      hand: [card(7)],
      minBet: 100,
      chips: 50000,
      bet: 100,
      rivalVisibleMax: 0,
      bankerTargetScores: [],
      isBanker: false,
      mortOffered: true,
      canDouble: false,
      canSplit: false,
      blindPair: false,
    };
    assert.equal(decideMort(ctx), false);
  });
});
