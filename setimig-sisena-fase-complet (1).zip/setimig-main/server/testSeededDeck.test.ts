/**
 * La llavor entra per create_private_table i només si SETIMIG_TEST_SEEDED_DECK=1.
 * Sense la variable, o en producció, el camp s'ignora.
 */
import { describe, it, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";
import fs from "fs/promises";
import os from "os";
import path from "path";
import { createServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket } from "socket.io-client";
import { resetGameStateForTests, setupGameHandlers } from "./game.ts";
import { flushPrivateRoomStoreWritesForTests, resetPrivateRoomStoreCacheForTests } from "./privateRoomStore.ts";
import { resetPrivateSeededDeckWarningsForTests } from "../shared/testSeededDeck.ts";

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";

type Card = { suit: string; value: number };
type View = {
  phase: string;
  players: { id: string; name: string; isBanker: boolean }[];
  bankDraw?: { playerId: string; card: Card }[] | null;
  testDeckSeed?: number;
  deckSeed?: number;
};

function connect(url: string): Promise<Socket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.on("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.on("connect_error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

function waitJoined(socket: Socket): Promise<{ id: string; inviteCode?: string }> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("join timeout")), 15_000);
    socket.once("joined_room", (room) => {
      clearTimeout(timer);
      resolve(room);
    });
  });
}

function waitBankDraw(socket: Socket): Promise<View> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("bank_draw timeout")), 15_000);
    const onUpdate = (room: View) => {
      if (room.phase === "bank_draw" && (room.bankDraw?.length ?? 0) >= 2) {
        clearTimeout(timer);
        socket.off("room_update", onUpdate);
        resolve(room);
      }
    };
    socket.on("room_update", onUpdate);
  });
}

async function startServer(): Promise<{ url: string; http: ReturnType<typeof createServer>; io: SocketIOServer }> {
  const http = createServer();
  const io = new SocketIOServer(http, { cors: { origin: "*" } });
  await setupGameHandlers(io);
  await new Promise<void>((r) => http.listen(0, "127.0.0.1", () => r()));
  const port = (http.address() as { port: number }).port;
  return { url: `http://127.0.0.1:${port}`, http, io };
}

async function stopServer(io: SocketIOServer, http: ReturnType<typeof createServer>) {
  io.close();
  await new Promise<void>((r) => http.close(() => r()));
}

function cardKey(room: View): string {
  const host = room.players[0]!;
  const draw = room.bankDraw!.find((e) => e.playerId === host.id)!.card;
  return `${draw.suit}:${draw.value}:${host.isBanker ? "bank" : "play"}`;
}

async function deal(url: string, ids: { host: string; guest: string }, deckSeed: number): Promise<View> {
  const host = await connect(url);
  const guest = await connect(url);
  try {
    host.emit("create_private_table", {
      playerName: "Host",
      playerId: ids.host,
      houseRulesEnabled: true,
      deckSeed,
    });
    const created = await waitJoined(host);
    assert.equal(JSON.stringify(created).includes("testDeckSeed"), false);
    assert.equal(JSON.stringify(created).includes("deckSeed"), false);
    const drawn = waitBankDraw(host);
    guest.emit("join_private_table", {
      inviteCode: created.inviteCode,
      playerName: "Guest",
      playerId: ids.guest,
    });
    await waitJoined(guest);
    host.emit("start_game", created.id);
    const view = await drawn;
    assert.equal(view.testDeckSeed, undefined);
    assert.equal(view.deckSeed, undefined);
    return view;
  } finally {
    guest.disconnect();
    host.disconnect();
  }
}

describe("create_private_table · deckSeed", () => {
  let dataDir: string;
  const prev = {
    flag: process.env.SETIMIG_TEST_SEEDED_DECK,
    node: process.env.NODE_ENV,
    deck: process.env.SETIMIG_TEST_DECK_SEED,
    shuffle: process.env.SETIMIG_TEST_SHUFFLE_SEED,
  };

  beforeEach(async () => {
    dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "setimig-seed-deck-"));
    process.env.BALANCE_DATA_DIR = dataDir;
    delete process.env.SETIMIG_TEST_DECK_SEED;
    delete process.env.SETIMIG_TEST_SHUFFLE_SEED;
    resetGameStateForTests();
    resetPrivateRoomStoreCacheForTests();
    resetPrivateSeededDeckWarningsForTests();
  });

  afterEach(async () => {
    const restore = (key: string, value: string | undefined) => {
      if (value === undefined) delete process.env[key];
      else process.env[key] = value;
    };
    restore("SETIMIG_TEST_SEEDED_DECK", prev.flag);
    restore("NODE_ENV", prev.node);
    restore("SETIMIG_TEST_DECK_SEED", prev.deck);
    restore("SETIMIG_TEST_SHUFFLE_SEED", prev.shuffle);
    resetGameStateForTests();
    resetPrivateSeededDeckWarningsForTests();
    await flushPrivateRoomStoreWritesForTests();
    await fs.rm(dataDir, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 });
  });

  it("sense SETIMIG_TEST_SEEDED_DECK, deckSeed no fixa la baralla", async () => {
    delete process.env.SETIMIG_TEST_SEEDED_DECK;
    delete process.env.NODE_ENV;
    const { url, http, io } = await startServer();
    try {
      const a = await deal(url, { host: "seedhostA1", guest: "seedguestA" }, 3);
      const b = await deal(url, { host: "seedhostB1", guest: "seedguestB" }, 3);
      assert.notEqual(cardKey(a), cardKey(b));
    } finally {
      await stopServer(io, http);
    }
  });

  it("amb SETIMIG_TEST_SEEDED_DECK=1, deckSeed 3 deixa l'amfitrió de banca", async () => {
    process.env.SETIMIG_TEST_SEEDED_DECK = "1";
    delete process.env.NODE_ENV;
    const { url, http, io } = await startServer();
    try {
      const view = await deal(url, { host: "seedhostC1", guest: "seedguestC" }, 3);
      const hostPlayer = view.players[0]!;
      const hostCard = view.bankDraw!.find((e) => e.playerId === hostPlayer.id)!.card;
      const guestCard = view.bankDraw!.find((e) => e.playerId !== hostPlayer.id)!.card;
      assert.equal(hostPlayer.isBanker, true);
      assert.equal(hostCard.value, 11);
      assert.equal(hostCard.suit, "clubs");
      assert.equal(guestCard.value, 2);
      assert.equal(guestCard.suit, "hearts");
    } finally {
      await stopServer(io, http);
    }
  });

});
