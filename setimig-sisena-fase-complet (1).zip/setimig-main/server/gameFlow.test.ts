import { describe, it, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";
import { createServer, type Server as HttpServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket as ClientSocket } from "socket.io-client";
import { setupGameHandlers } from "./game.ts";
import type { RoomView } from "../src/gameTypes.ts";
import { resetBalanceStoreCacheForTests, setBalance } from "./balances.ts";
import { issuePlayerToken } from "./playerToken.ts";
import { getGameHostForTests, getRoomSnapshotForTests, resetGameStateForTests } from "./game.ts";

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";

const TEST_PLAYER_ID = "pas7flowtestplayer01";
const TEST_SHUFFLE_SEED = "84001";
const PRIVATE_HOST_ID = "flowprivhost00001";
const PRIVATE_GUEST_ID = "flowprivguest001";

type TestServer = { url: string; http: HttpServer; io: SocketIOServer };

type ActionSeqRef = { value: number };

async function startTestServer(): Promise<TestServer> {
  const http = createServer();
  const io = new SocketIOServer(http, { cors: { origin: "*" } });
  await setupGameHandlers(io);
  await new Promise<void>((resolve) => http.listen(0, "127.0.0.1", () => resolve()));
  const addr = http.address();
  const port = typeof addr === "object" && addr ? addr.port : 0;
  return { url: `http://127.0.0.1:${port}`, http, io };
}

async function stopTestServer(server: TestServer): Promise<void> {
  server.io.close();
  await new Promise<void>((resolve, reject) => {
    server.http.close((err) => (err ? reject(err) : resolve()));
  });
}

function connect(url: string): Promise<ClientSocket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.on("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.on("connect_error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

function totalChips(room: RoomView): number {
  const pot = room.pot ?? 0;
  const jp = room.jackpot ?? 0;
  const players = (room.players ?? []).reduce((sum, p) => sum + (p.chips ?? 0), 0);
  return players + pot + jp;
}

function captureChipBaseline(room: RoomView): number {
  return totalChips(room);
}

function currentTurnId(room: RoomView): string | undefined {
  if (room.turnPlayerId) return room.turnPlayerId;
  const list = room.players ?? [];
  const bankerIdx = list.findIndex((p) => p.isBanker);
  const nonBankers =
    bankerIdx < 0
      ? list.filter((p) => !p.isBanker)
      : (() => {
          const ordered: typeof list = [];
          for (let i = 1; i <= list.length; i += 1) {
            const p = list[(bankerIdx + i) % list.length]!;
            if (!p.isBanker) ordered.push(p);
          }
          return ordered;
        })();
  if (room.phase === "playing") return nonBankers[room.turnIndex ?? 0]?.id;
  if (room.phase === "banker") return list.find((p) => p.isBanker)?.id;
  return undefined;
}

function autoRespondSolo(socket: ClientSocket, room: RoomView, humanSocketId: string) {
  const me = room.players?.find((p) => p.id === humanSocketId);
  if (!me) return;

  if (me.pendingBankChoice) {
    socket.emit("bank_keep_choice", { roomId: room.id, keep: false });
    return;
  }

  if (room.phase === "betting" && !me.isBanker && me.status === "betting" && me.bet === 0) {
    socket.emit("place_bet", { roomId: room.id, amount: room.minBet ?? 100 });
    return;
  }

  const turnId = currentTurnId(room);
  if (turnId !== humanSocketId) return;

  if (room.phase === "playing" && me.pendingChoices?.canMort) {
    socket.emit("mort_action", { roomId: room.id, accept: false });
    return;
  }

  if (room.phase === "playing" || room.phase === "banker") {
    socket.emit("stand", room.id);
  }
}

function autoRespondPrivate(
  socket: ClientSocket,
  room: RoomView,
  socketId: string,
  playerToken: string,
  seq: ActionSeqRef
) {
  const me = room.players?.find((p) => p.id === socketId);
  if (!me || me.isBot) return;

  if (me.pendingBankChoice) {
    socket.emit("bank_keep_choice", {
      roomId: room.id,
      keep: false,
      playerToken,
      actionSeq: seq.value++,
    });
    return;
  }

  if (room.phase === "betting" && !me.isBanker && me.status === "betting" && me.bet === 0) {
    socket.emit("place_bet", {
      roomId: room.id,
      amount: room.minBet ?? 100,
      playerToken,
      actionSeq: seq.value++,
    });
    return;
  }

  const turnId = currentTurnId(room);
  if (turnId !== socketId) return;

  if (room.phase === "playing" && me.pendingChoices?.canMort) {
    socket.emit("mort_action", {
      roomId: room.id,
      accept: false,
      playerToken,
      actionSeq: seq.value++,
    });
    return;
  }

  if (room.phase === "playing" || room.phase === "banker") {
    socket.emit("stand", {
      roomId: room.id,
      playerToken,
      actionSeq: seq.value++,
    });
  }
}

function bindGameErrors(socket: ClientSocket, onFatal: (err: Error) => void) {
  socket.on("game_error", (err: { message?: string; code?: string }) => {
    const msg = err.message ?? "";
    if (err.code === "BAD_TURN" || msg.includes("No és el teu torn")) return;
    if (msg.includes("Ja has apostat")) return;
    if (err.code === "BAD_PHASE") return;
    onFatal(new Error(msg || err.code || "game_error"));
  });
}

async function joinSoloAndPlayHands(
  url: string,
  botCount: 1 | 2 | 3 | 4 | 5 | 6,
  targetHands: number,
  timeoutMs = 45_000
): Promise<{ handsPlayed: number; lastRoom: RoomView }> {
  const socket = await connect(url);
  let lastRoom: RoomView | null = null;
  let joinedId = "";
  let chipBaseline: number | null = null;

  const done = new Promise<{ handsPlayed: number; lastRoom: RoomView }>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`timeout after ${timeoutMs}ms`)), timeoutMs);

    const onRoom = (room: RoomView) => {
      lastRoom = room;
      if (chipBaseline === null && (room.players?.length ?? 0) >= botCount + 1) {
        chipBaseline = captureChipBaseline(room);
      }
      autoRespondSolo(socket, room, joinedId);
      const stats = room.sessionStats;
      if (stats && stats.handsPlayed >= targetHands) {
        clearTimeout(timer);
        socket.off("room_update", onRoom);
        socket.off("joined_room", onJoin);
        resolve({ handsPlayed: stats.handsPlayed, lastRoom: room });
      }
    };

    const onJoin = (room: RoomView) => {
      joinedId = socket.id;
      lastRoom = room;
      onRoom(room);
    };

    socket.on("joined_room", onJoin);
    socket.on("room_update", onRoom);
    bindGameErrors(socket, (err) => {
      clearTimeout(timer);
      reject(err);
    });

    socket.emit("join_solo_room", {
      playerName: "FlowTest",
      playerId: `${TEST_PLAYER_ID}-${botCount}`,
      botCount,
    });
  });

  try {
    return await done;
  } finally {
    socket.disconnect();
  }
}

async function playSoloUntilMatch(
  url: string,
  playerId: string,
  timeoutMs = 60_000
): Promise<RoomView> {
  const socket = await connect(url);
  let joinedId = "";
  let chipBaseline: number | null = null;

  const done = new Promise<RoomView>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`match timeout after ${timeoutMs}ms`)), timeoutMs);

    const onRoom = (room: RoomView) => {
      if (chipBaseline === null && (room.players?.length ?? 0) >= 2) {
        chipBaseline = captureChipBaseline(room);
      }
      autoRespondSolo(socket, room, joinedId);
      if (room.matchResult && room.phase === "waiting") {
        clearTimeout(timer);
        socket.off("room_update", onRoom);
        socket.off("joined_room", onJoin);
        resolve(room);
      }
    };

    const onJoin = (room: RoomView) => {
      joinedId = socket.id;
      onRoom(room);
    };

    socket.on("joined_room", onJoin);
    socket.on("room_update", onRoom);
    bindGameErrors(socket, (err) => {
      clearTimeout(timer);
      reject(err);
    });

    socket.emit("join_solo_room", {
      playerName: "MatchTest",
      playerId,
      botCount: 1,
    });
  });

  try {
    return await done;
  } finally {
    socket.disconnect();
  }
}

describe("solo AI full game flow", () => {
  beforeEach(() => {
    process.env.SETIMIG_TEST_FAST = "1";
    process.env.SETIMIG_TEST_SHUFFLE_SEED = TEST_SHUFFLE_SEED;
    resetGameStateForTests();
    resetBalanceStoreCacheForTests();
  });

  afterEach(() => {
    resetGameStateForTests();
  });

  afterEach(() => {
    delete process.env.SETIMIG_TEST_FAST;
    delete process.env.SETIMIG_TEST_SHUFFLE_SEED;
  });

  for (const bots of [1, 3, 6] as const) {
    it(`completes ${bots} bot(s) through multiple hands without errors`, async () => {
      const server = await startTestServer();
      const targetHands = bots >= 4 ? 1 : 2;
      try {
        const { handsPlayed, lastRoom } = await joinSoloAndPlayHands(
          server.url,
          bots,
          targetHands,
          45_000
        );
        assert.ok(handsPlayed >= targetHands, `expected >= ${targetHands} hands, got ${handsPlayed}`);
        assert.ok(
          ["waiting", "betting", "playing", "banker", "settlement", "bank_draw"].includes(lastRoom.phase)
        );
        assert.ok((lastRoom.players?.length ?? 0) >= bots + 1);
        const human = lastRoom.players?.find((p) => !p.isBot);
        assert.ok(human);
        assert.ok(typeof lastRoom.jackpot === "number" && lastRoom.jackpot >= 0);
      } finally {
        await stopTestServer(server);
      }
    });
  }

  it("plays solo vs bots to match winner with chip conservation", async () => {
    const soloId = `${TEST_PLAYER_ID}-matchwin`;
    // Saldo per a la compra d'entrada solo (2.000); abans no calia.
    await setBalance(soloId, 10_000);
    const server = await startTestServer();
    try {
      const room = await playSoloUntilMatch(server.url, soloId);
      assert.ok(room.matchResult);
      assert.ok(room.matchResult!.winnerName);
      assert.ok(
        room.matchResult!.viewerOutcome === "win" ||
          room.matchResult!.viewerOutcome === "eliminated" ||
          room.matchResult!.viewerOutcome === "lose"
      );
    } finally {
      await stopTestServer(server);
    }
  });

  it("quick_rematch starts a new hand after match end", async () => {
    const soloId = `${TEST_PLAYER_ID}-rematch`;
    // Saldo per a dues compres d'entrada solo (partida + revenja); abans no calia.
    await setBalance(soloId, 10_000);
    const server = await startTestServer();
    const socket = await connect(server.url);
    let joinedId = "";
    let chipBaseline: number | null = null;

    try {
      await new Promise<void>((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("rematch flow timeout")), 60_000);
        let requestedRematch = false;

        const onRoom = (room: RoomView) => {
          if (chipBaseline === null && (room.players?.length ?? 0) >= 2) {
            chipBaseline = captureChipBaseline(room);
          }
          autoRespondSolo(socket, room, joinedId);

          if (room.matchResult && room.phase === "waiting") {
            requestedRematch = true;
            socket.emit("quick_rematch", room.id);
            return;
          }

          if (requestedRematch && !room.matchResult && room.phase === "betting") {
            clearTimeout(timer);
            socket.off("room_update", onRoom);
            socket.off("joined_room", onJoin);
            resolve();
          }
        };

        const onJoin = (room: RoomView) => {
          joinedId = socket.id;
          onRoom(room);
        };

        socket.on("joined_room", onJoin);
        socket.on("room_update", onRoom);
        bindGameErrors(socket, reject);

        socket.emit("join_solo_room", {
          playerName: "RematchTest",
          playerId: soloId,
          botCount: 1,
        });
      });
    } finally {
      socket.disconnect();
      await stopTestServer(server);
    }
  });
});

describe("private table two-human flow", () => {
  beforeEach(() => {
    process.env.SETIMIG_TEST_FAST = "1";
    process.env.SETIMIG_TEST_SHUFFLE_SEED = TEST_SHUFFLE_SEED;
    resetGameStateForTests();
    resetBalanceStoreCacheForTests();
  });

  afterEach(() => {
    resetGameStateForTests();
  });

  afterEach(() => {
    delete process.env.SETIMIG_TEST_FAST;
    delete process.env.SETIMIG_TEST_SHUFFLE_SEED;
  });

  it("rejects a private-table rematch request from an outsider", async () => {
    const hostToken = issuePlayerToken(PRIVATE_HOST_ID)!;
    const guestToken = issuePlayerToken(PRIVATE_GUEST_ID)!;
    const server = await startTestServer();
    const host = await connect(server.url);
    const guest = await connect(server.url);
    const outsider = await connect(server.url);

    try {
      const hostRoom = await new Promise<RoomView>((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("host join timeout")), 15_000);
        host.once("joined_room", (room) => {
          clearTimeout(timer);
          resolve(room);
        });
        host.emit("create_private_table", {
          playerName: "Host",
          playerId: PRIVATE_HOST_ID,
          playerToken: hostToken,
        });
      });

      await new Promise<void>((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("guest join timeout")), 15_000);
        guest.once("joined_room", () => {
          clearTimeout(timer);
          resolve();
        });
        guest.emit("join_private_table", {
          inviteCode: hostRoom.inviteCode,
          playerName: "Guest",
          playerId: PRIVATE_GUEST_ID,
          playerToken: guestToken,
        });
      });

      const room = getRoomSnapshotForTests(hostRoom.id);
      assert.ok(room);
      room.phase = "waiting";
      room.matchEnded = true;
      const errorPromise = new Promise<{ code?: string } | null>((resolve) => {
        const timer = setTimeout(() => resolve(null), 500);
        outsider.once("game_error", (error) => {
          clearTimeout(timer);
          resolve(error);
        });
      });

      outsider.emit("quick_rematch", hostRoom.id);
      const error = await errorPromise;
      assert.equal(error?.code, "BAD");
      assert.equal(room.phase, "waiting");
      assert.equal(room.matchEnded, true);
    } finally {
      host.disconnect();
      guest.disconnect();
      outsider.disconnect();
      await stopTestServer(server);
    }
  });

  it("two humans finish to a chip leader with conservation", async () => {
    const hostToken = issuePlayerToken(PRIVATE_HOST_ID)!;
    const guestToken = issuePlayerToken(PRIVATE_GUEST_ID)!;
    const server = await startTestServer();
    const host = await connect(server.url);
    const guest = await connect(server.url);
    const hostSeq: ActionSeqRef = { value: 1 };
    const guestSeq: ActionSeqRef = { value: 1 };
    let chipBaseline: number | null = null;

    try {
      const hostRoom = await new Promise<RoomView>((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("host join timeout")), 15_000);
        host.once("joined_room", (room) => {
          clearTimeout(timer);
          resolve(room);
        });
        host.emit("create_private_table", {
          playerName: "Host",
          playerId: PRIVATE_HOST_ID,
          playerToken: hostToken,
        });
      });

      await new Promise<void>((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("guest join timeout")), 15_000);
        guest.once("joined_room", () => {
          clearTimeout(timer);
          resolve();
        });
        guest.emit("join_private_table", {
          inviteCode: hostRoom.inviteCode,
          playerName: "Guest",
          playerId: PRIVATE_GUEST_ID,
          playerToken: guestToken,
        });
      });

      host.emit("start_game", {
        roomId: hostRoom.id,
        playerToken: hostToken,
        actionSeq: hostSeq.value++,
      });

      const finalRoom = await new Promise<RoomView>((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("private match timeout")), 90_000);
        let hostId = host.id;
        let guestId = guest.id;

        const onUpdate = (room: RoomView) => {
          if (chipBaseline === null && room.phase === "betting") {
            chipBaseline = captureChipBaseline(room);
          }

          autoRespondPrivate(host, room, hostId, hostToken, hostSeq);
          autoRespondPrivate(guest, room, guestId, guestToken, guestSeq);

          if (room.matchResult && room.phase === "waiting") {
            clearTimeout(timer);
            host.off("room_update", onUpdate);
            guest.off("room_update", onUpdate);
            resolve(room);
          }
        };

        host.on("room_update", onUpdate);
        guest.on("room_update", onUpdate);
        bindGameErrors(host, reject);
        bindGameErrors(guest, reject);
      });

      assert.ok(finalRoom.matchResult);
      assert.ok(finalRoom.matchResult!.winnerName);
      const humans = (finalRoom.players ?? []).filter((p) => !p.isBot);
      assert.equal(humans.length, 2);
    } finally {
      host.disconnect();
      guest.disconnect();
      await stopTestServer(server);
    }
  });
});
