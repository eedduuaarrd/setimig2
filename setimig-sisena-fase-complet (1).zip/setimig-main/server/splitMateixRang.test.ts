/**
 * Servidor: «split_hands» amb 5+6 (valor diferent) es rebutja amb «Split no disponible.»
 * (code BAD) i no toca l'estat. 5+5, Rei+Rei i Sota+Rei s'accepten.
 */
import { describe, it, before, after, beforeEach } from "node:test";
import assert from "node:assert/strict";
import fs from "fs/promises";
import os from "os";
import path from "path";
import { createServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket } from "socket.io-client";
import { getGameHostForTests, getRoomSnapshotForTests, resetGameStateForTests, setupGameHandlers } from "./game.ts";
import { issuePlayerToken } from "./playerToken.ts";
import { flushBalanceWrites, resetBalanceStoreCacheForTests } from "./balances.ts";
import { clearRoomTimers, roomToView, type Player, type Room } from "../shared/gameEngine.ts";
import { applyBankerToPlayer } from "../shared/bankRotation.ts";
import { ENGINE_MESSAGES } from "../shared/gameMessages.ts";
import type { Card } from "../src/gameTypes.ts";

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";

const SOTA = 10;
const REI = 12;

function card(value: number, suit: Card["suit"]): Card {
  return { suit, value, points: 0.5 };
}

let dataRoot = "";

async function startServer() {
  const http = createServer();
  const io = new SocketIOServer(http, { cors: { origin: "*" } });
  await setupGameHandlers(io);
  await new Promise<void>((r) => http.listen(0, "127.0.0.1", () => r()));
  const port = (http.address() as { port: number }).port;
  return { http, io, url: `http://127.0.0.1:${port}` };
}

async function stopServer(s: Awaited<ReturnType<typeof startServer>>) {
  s.io.close();
  await new Promise<void>((r) => s.http.close(() => r()));
}

/** Entra a una solo, espera que arrenqui la mà i deixa l'humà amb el torn i la parella donada. */
async function riggedHumanTurn(socket: Socket, playerId: string, pair: [Card, Card]): Promise<{ room: Room; human: Player }> {
  const roomId = await new Promise<string>((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("join timeout")), 15_000);
    socket.once("joined_room", (room: { id: string }) => {
      clearTimeout(timer);
      resolve(room.id);
    });
    socket.emit("join_solo_room", { playerName: "Separa", playerId, botCount: 1 });
  });
  const host = getGameHostForTests();
  const deadline = Date.now() + 15_000;
  let room = getRoomSnapshotForTests(roomId);
  while (!(room && room.phase === "betting" && room.players.some((p) => p.isBanker))) {
    assert.ok(Date.now() < deadline, `la mà no ha arrencat (fase ${room?.phase})`);
    await new Promise((r) => setTimeout(r, 5));
    room = getRoomSnapshotForTests(roomId);
  }
  clearRoomTimers(host, room);
  room.houseRulesEnabled = true;
  const bot = room.players.find((p) => p.isBot)!;
  const human = room.players.find((p) => !p.isBot)!;
  assert.equal(human.id, socket.id);
  applyBankerToPlayer(room.players, bot.id);
  bot.chips = 50_000;
  bot.handSlots = [];
  room.phase = "playing";
  room.turnPlayerIndex = 0; // l'únic que no fa de banca és l'humà
  human.chips = 1_000;
  human.bet = 100;
  human.status = "playing";
  human.activeSlotIndex = 0;
  human.handSlots = [
    {
      id: "rigged",
      bet: 100,
      cards: [
        { id: "a", card: pair[0], faceUp: true },
        { id: "b", card: pair[1], faceUp: true },
      ],
      doubled: false,
      canDouble: false,
      mort: false,
      blindPair: false,
      blindUntilBankEnd: false,
      mortOffered: false,
      status: "playing",
    },
  ];
  return { room, human };
}

function snapshot(room: Room, human: Player) {
  return structuredClone({
    phase: room.phase,
    pot: room.pot,
    turn: room.turnPlayerIndex,
    chips: human.chips,
    bet: human.bet,
    active: human.activeSlotIndex,
    slots: human.handSlots,
  });
}

describe("servidor: split_hands amb el mateix valor o dues figures", () => {
  before(async () => {
    dataRoot = await fs.mkdtemp(path.join(os.tmpdir(), "setimig-split-rang-"));
    process.env.BALANCE_DATA_DIR = dataRoot;
    // Sense SETIMIG_TEST_FAST: el termini real del torn (segons) no venç durant la comprovació,
    // així «l'estat no canvia» mesura només l'acció rebutjada.
    resetBalanceStoreCacheForTests();
  });

  beforeEach(() => {
    resetGameStateForTests();
  });

  after(async () => {
    resetGameStateForTests();
    await flushBalanceWrites().catch(() => undefined);
    resetBalanceStoreCacheForTests();
    await fs.rm(dataRoot, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 }).catch(() => undefined);
    delete process.env.BALANCE_DATA_DIR;
  });

  it("5+6: game_error «Split no disponible.» (BAD) i l'estat no canvia", async () => {
    const server = await startServer();
    const socket = ioClient(server.url, { transports: ["websocket"], forceNew: true });
    try {
      await new Promise<void>((r) => socket.once("connect", () => r()));
      const { room, human } = await riggedHumanTurn(socket, "splitrang0000001", [card(5, "hearts"), card(6, "spades")]);
      const before = snapshot(room, human);
      const err = await new Promise<{ message: string; code?: string }>((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("sense game_error")), 10_000);
        socket.once("game_error", (e: { message: string; code?: string }) => {
          clearTimeout(timer);
          resolve(e);
        });
        socket.emit("split_hands", { roomId: room.id });
      });
      assert.equal(err.message, ENGINE_MESSAGES.splitUnavailable);
      assert.equal(err.code, "BAD");
      // Deixa acabar commitRoom abans de comparar.
      await new Promise((r) => setTimeout(r, 50));
      assert.deepEqual(snapshot(room, human), before);
      assert.equal(human.handSlots.length, 1);
    } finally {
      socket.disconnect();
      await stopServer(server);
    }
  });

  it("Rei+Rei: split_hands s'accepta i hi ha dues mans", async () => {
    const server = await startServer();
    const socket = ioClient(server.url, { transports: ["websocket"], forceNew: true });
    try {
      await new Promise<void>((r) => socket.once("connect", () => r()));
      const { room, human } = await riggedHumanTurn(socket, "splitrang0000002", [card(REI, "hearts"), card(REI, "spades")]);
      let gotError: unknown = null;
      socket.on("game_error", (e) => {
        gotError = e;
      });
      socket.emit("split_hands", { roomId: room.id });
      const deadline = Date.now() + 10_000;
      while (human.handSlots.length < 2) {
        assert.ok(Date.now() < deadline, "no s'ha separat");
        await new Promise((r) => setTimeout(r, 5));
      }
      assert.equal(gotError, null);
      assert.equal(human.handSlots[0]!.cards[0]!.card.value, REI);
      assert.equal(human.handSlots[1]!.cards[0]!.card.value, REI);
      clearRoomTimers(getGameHostForTests(), room);
    } finally {
      socket.disconnect();
      await stopServer(server);
    }
  });

  it("Sota+Rei: la vista del jugador porta canSplit i split_hands s'accepta", async () => {
    const server = await startServer();
    const socket = ioClient(server.url, { transports: ["websocket"], forceNew: true });
    try {
      await new Promise<void>((r) => socket.once("connect", () => r()));
      const { room, human } = await riggedHumanTurn(socket, "splitrang0000003", [card(SOTA, "clubs"), card(REI, "diamonds")]);
      const me = roomToView(room, human.id, getGameHostForTests()).players.find((p) => p.id === human.id);
      assert.equal(me?.pendingChoices?.canSplit, true);
      assert.equal(me?.activeSlotIndex, 0);
      assert.equal(me?.handSlots.length, 1);
      assert.equal(me?.handSlots[0]?.bet, 100);
      assert.equal(me?.handSlots[0]?.doubled, false);
      let gotError: unknown = null;
      socket.on("game_error", (e) => {
        gotError = e;
      });
      socket.emit("split_hands", { roomId: room.id });
      const deadline = Date.now() + 10_000;
      while (human.handSlots.length < 2) {
        assert.ok(Date.now() < deadline, "no s'ha separat");
        await new Promise((r) => setTimeout(r, 5));
      }
      assert.equal(gotError, null);
      assert.equal(human.handSlots[0]!.cards[0]!.card.value, SOTA);
      assert.equal(human.handSlots[1]!.cards[0]!.card.value, REI);
      clearRoomTimers(getGameHostForTests(), room);
    } finally {
      socket.disconnect();
      await stopServer(server);
    }
  });

  // Normes de la casa: «swap_action» (jugar o canviar el primer 3 / 4).
  it("swap_action: canvia el 4 per una carta nova; payload sense booleà → game_error", async () => {
    const server = await startServer();
    const socket = ioClient(server.url, { transports: ["websocket"], forceNew: true });
    try {
      await new Promise<void>((r) => socket.once("connect", () => r()));
      const { room, human } = await riggedHumanTurn(socket, "swapquatre000001", [card(REI, "hearts"), card(REI, "spades")]);
      const four: Card = { suit: "clubs", value: 4, points: 4 };
      human.handSlots[0]!.cards = [{ id: "q", card: four, faceUp: false }];
      human.handSlots[0]!.swapOffered = 4;
      human.handSlots[0]!.canDouble = true;
      const errors: unknown[] = [];
      socket.on("game_error", (e) => errors.push(e));
      socket.emit("swap_action", { roomId: room.id, swap: "sí" });
      const d1 = Date.now() + 10_000;
      while (errors.length === 0) {
        assert.ok(Date.now() < d1, "sense game_error");
        await new Promise((r) => setTimeout(r, 5));
      }
      assert.equal(human.handSlots[0]!.swapOffered, 4, "el payload dolent no toca l'estat");
      const bad = errors[0] as { code?: string; message?: string };
      assert.equal(bad.code, "BAD");
      assert.equal(bad.message, "Acció no vàlida.");
      // Un 4 canviat que torna a ser 4 es torna a oferir (#290). El munt es fixa a un 5
      // perquè el test comprovi el canvi, no la cadena.
      room.deck = [card(5, "hearts")];
      socket.emit("swap_action", { roomId: room.id, swap: true });
      const d2 = Date.now() + 10_000;
      while (human.handSlots[0]!.swapOffered) {
        assert.ok(Date.now() < d2, "no s'ha canviat");
        await new Promise((r) => setTimeout(r, 5));
      }
      assert.equal(errors.length, 1);
      assert.equal(human.handSlots[0]!.swappedFour, true);
      assert.equal(human.handSlots[0]!.cards.length, 1);
      assert.notEqual(human.handSlots[0]!.cards[0]!.id, "q");
      clearRoomTimers(getGameHostForTests(), room);
    } finally {
      socket.disconnect();
      await stopServer(server);
    }
  });

  it("mort_action i swap_action accepten actionSeq opcional; canviar el 3 acaba el torn", async () => {
    const hostId = "swap3privhost00001";
    const playerToken = issuePlayerToken(hostId)!;
    const server = await startServer();
    const socket = ioClient(server.url, { transports: ["websocket"], forceNew: true });
    const errors: { message?: string; code?: string }[] = [];
    try {
      await new Promise<void>((r) => socket.once("connect", () => r()));
      socket.on("game_error", (e: { message?: string; code?: string }) => errors.push(e));
      const joined = await new Promise<{ id: string }>((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("join timeout")), 10_000);
        socket.once("joined_room", (room: { id: string }) => {
          clearTimeout(timer);
          resolve(room);
        });
        socket.emit("create_private_table", {
          playerName: "Amfitrio",
          playerId: hostId,
          playerToken,
          houseRulesEnabled: true,
        });
      });
      const room = getRoomSnapshotForTests(joined.id)!;
      const human = room.players.find((p) => p.id === socket.id)!;
      room.houseRulesEnabled = true;
      room.phase = "playing";
      room.turnPlayerIndex = 0;
      room.pot = 100;
      room.deck = [
        { suit: "clubs", value: 4, points: 4 },
        { suit: "diamonds", value: 2, points: 2 },
      ];
      const banker: Player = {
        id: "bank-seat",
        playerId: "bank-seat",
        seatToken: "bank-seat",
        name: "Banca",
        chips: 50_000,
        bet: 0,
        isBanker: true,
        isBot: false,
        status: "waiting",
        handSlots: [
          {
            id: "bank-hand",
            bet: 0,
            cards: [{ id: "bc", card: { suit: "spades", value: 5, points: 5 }, faceUp: false }],
            doubled: false,
            canDouble: false,
            mort: false,
            blindPair: false,
            blindUntilBankEnd: false,
            mortOffered: false,
            status: "playing",
          },
        ],
        activeSlotIndex: 0,
        lastRoyal7Payout: 0,
        royal7AsBankerStreak: 0,
      };
      human.chips = 1_000;
      human.bet = 100;
      human.status = "playing";
      human.activeSlotIndex = 0;
      human.handSlots = [
        {
          id: "mort-hand",
          bet: 100,
          cards: [{ id: "seven", card: { suit: "hearts", value: 7, points: 7 }, faceUp: false }],
          doubled: false,
          canDouble: false,
          mort: false,
          blindPair: false,
          blindUntilBankEnd: false,
          mortOffered: true,
          status: "playing",
        },
      ];
      room.players = [banker, human];

      const until = async (pred: () => boolean, label: string) => {
        const deadline = Date.now() + 10_000;
        while (!pred()) {
          assert.ok(Date.now() < deadline, label);
          await new Promise((r) => setTimeout(r, 5));
        }
      };

      socket.emit("mort_action", { roomId: room.id, accept: false, playerToken });
      await until(() => human.handSlots[0]!.mortOffered === false, "mort_action sense actionSeq");
      assert.equal(errors.length, 0);
      assert.equal(human.lastActionSeq, 1);

      human.handSlots[0] = {
        id: "swap-four",
        bet: 100,
        cards: [{ id: "four", card: { suit: "clubs", value: 4, points: 4 }, faceUp: false }],
        doubled: false,
        canDouble: true,
        mort: false,
        blindPair: false,
        blindUntilBankEnd: false,
        mortOffered: false,
        swapOffered: 4,
        status: "playing",
      };
      socket.emit("swap_action", { roomId: room.id, swap: false, playerToken });
      await until(() => human.handSlots[0]!.swapOffered == null, "swap_action sense actionSeq");
      assert.equal(errors.length, 0);
      assert.equal(human.lastActionSeq, 2);
      assert.equal(room.phase, "playing");

      human.handSlots[0] = {
        id: "swap-three",
        bet: 100,
        cards: [{ id: "three", card: { suit: "diamonds", value: 3, points: 3 }, faceUp: false }],
        doubled: false,
        canDouble: true,
        mort: false,
        blindPair: false,
        blindUntilBankEnd: false,
        mortOffered: false,
        swapOffered: 3,
        status: "playing",
      };
      socket.emit("swap_action", { roomId: room.id, swap: true, playerToken, actionSeq: 3 });
      await until(
        () => human.handSlots[0]!.status === "stood" && room.phase === "banker",
        "canviar el 3 no ha acabat el torn"
      );
      clearRoomTimers(getGameHostForTests(), room);
      assert.equal(errors.length, 0);
      assert.equal(human.lastActionSeq, 3);
      assert.equal(human.handSlots[0]!.blindPair, true);
      assert.equal(human.lastHandAction, "Canvia");

      for (const event of ["hit", "stand", "double_bet", "split_hands"] as const) {
        const before = errors.length;
        socket.emit(event, { roomId: room.id, playerToken });
        await until(() => errors.length > before, `${event} s'havia d'haver rebutjat`);
        assert.ok(errors.at(-1)?.message, event);
      }
      assert.equal(room.phase, "banker");
      assert.equal(human.handSlots[0]!.status, "stood");
      clearRoomTimers(getGameHostForTests(), room);
    } finally {
      socket.disconnect();
      await stopServer(server);
    }
  });

  it("card_peeked arrenca el termini; un duplicat no el mou; el rival no el veu", async () => {
    const server = await startServer();
    const socket = ioClient(server.url, { transports: ["websocket"], forceNew: true });
    try {
      await new Promise<void>((r) => socket.once("connect", () => r()));
      const { room, human } = await riggedHumanTurn(socket, "peektermin0000001", [card(REI, "hearts"), card(REI, "spades")]);
      human.handSlots[0]!.cards = [{ id: "four", card: { suit: "clubs", value: 4, points: 4 }, faceUp: false }];
      human.handSlots[0]!.swapOffered = 4;
      const safety = Date.now() + 999_999;
      room.mortDeadlineAt = safety;
      room.offerClockCardId = null;
      const errors: unknown[] = [];
      socket.on("game_error", (e) => errors.push(e));
      socket.emit("card_peeked", { roomId: room.id, cardId: "no-such" });
      await new Promise((r) => setTimeout(r, 40));
      assert.equal(room.mortDeadlineAt, safety);
      socket.emit("card_peeked", { roomId: room.id, cardId: "four" });
      const deadline = Date.now() + 10_000;
      while (room.mortDeadlineAt === safety) {
        assert.ok(Date.now() < deadline, "el peek no ha arrencat el termini");
        await new Promise((r) => setTimeout(r, 5));
      }
      const started = room.mortDeadlineAt!;
      assert.ok(started < safety);
      socket.emit("card_peeked", { roomId: room.id, cardId: "four" });
      await new Promise((r) => setTimeout(r, 40));
      assert.equal(room.mortDeadlineAt, started);
      assert.equal(errors.length, 0);
      const gameHost = getGameHostForTests();
      const bot = room.players.find((p) => p.isBot)!;
      assert.equal(roomToView(room, human.id, gameHost).mortDeadline, started);
      assert.equal(roomToView(room, bot.id, gameHost).mortDeadline, null);
      clearRoomTimers(gameHost, room);
    } finally {
      socket.disconnect();
      await stopServer(server);
    }
  });
});
