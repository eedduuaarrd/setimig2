/**
 * Compra d'entrada (buy-in) de les partides solo amb saldo real.
 *
 * - En seure: es descompta la compra del saldo real i es desa com a «compra oberta» a
 *   balances.json, tot en la mateixa transacció (mai saldo negatiu).
 * - Durant la partida: cada mà liquidada suma al llibre el resultat del jugador que el servidor
 *   registra a `lastRound.results` (`HandResultLine.chipDelta`).
 * - En sortir (Sortir, lobby, final de partida, desconnexió, partida nova): s'abona el romanent
 *   de la taula si quadra amb la compra + les mans, o si és més baix (una mà no registrada no
 *   torna la compra sencera: això esborraria les pèrdues, i sumar-hi el romanent les pagaria
 *   dues vegades). Si les fitxes de taula superen el que el llibre pot explicar, només la compra.
 *   Tancar una compra és idempotent (només una vegada per id).
 * - Si el servidor es reinicia amb una compra oberta, en arrencar es retorna la compra.
 * - Pagaments al saldo durant la partida (assoliments com «Primera victòria», missions, fitxes
 *   gratis, compres): van directament al saldo real, mai a les fitxes de taula. La verificació
 *   només mira fitxes de taula (compra + mans), i el tancament és un increment atòmic sobre el saldo
 *   ACTUAL (mai una còpia del saldo de quan es va seure), així que cada pagament compta una sola
 *   vegada: saldo final = saldo en seure − compra + fitxes finals verificades + pagaments.
 *
 * El mode pràctica i el torneig ràpid (fitxes aïllades) i les taules privades no hi passen.
 */
import { roomUsesIsolatedPlayChips } from "../shared/fastTournament.ts";
import type { Player, Room } from "../shared/gameEngine.ts";
import { closeSoloBuyIn, openSoloBuyIn, type OpenSoloBuyInResult } from "./balances.ts";

export type SoloBuyInLedger = {
  id: string;
  playerId: string;
  amount: number;
  /** Suma dels resultats de les mans liquidades al servidor per a aquest jugador i partida. */
  handsNet: number;
  hands: number;
  /** `room.handSeq` de l'última mà ja sumada: un segon avís de la mateixa mà no compta dues vegades. */
  lastHandSeq?: number;
};

export function roomUsesSoloBuyIn(room: Pick<Room, "soloAi" | "isPrivate" | "practiceMode" | "fastTournament">): boolean {
  return !!room.soloAi && !room.isPrivate && !roomUsesIsolatedPlayChips(room);
}

/**
 * Obre la compra (descompte atòmic del saldo): min(compra completa, saldo). No toca la sala si el
 * saldo és 0. Les fitxes del seient s'ajusten amb `applySoloBuyInChips` un cop muntada la partida.
 */
export async function openSoloBuyInForRoom(
  room: Room,
  playerId: string,
  fullAmount: number
): Promise<OpenSoloBuyInResult> {
  const result = await openSoloBuyIn(playerId, fullAmount, room.id);
  if (result.ok) {
    room.soloBuyIn = { id: result.id, playerId, amount: result.amount, handsNet: 0, hands: 0 };
  }
  return result;
}

/**
 * El jugador seu amb tantes fitxes de taula com la compra real (pot ser menys de la compra
 * completa si el saldo no hi arriba). Els bots mantenen les fitxes inicials; el total de la
 * partida (`phaseB.chipPool`) es recalcula perquè l'invariant de fitxes continuï quadrant.
 */
export function applySoloBuyInChips(room: Room): void {
  const ledger = room.soloBuyIn;
  if (!ledger) return;
  const seat = room.players.find((p) => p.playerId === ledger.playerId);
  if (!seat) return;
  seat.chips = ledger.amount;
  if (room.phaseB) {
    room.phaseB.chipPool =
      room.players.reduce((sum, p) => sum + p.chips + p.bet, 0) + (room.pot ?? 0) + (room.jackpot ?? 0);
  }
}

type LedgerResultLine = { name: string; chipDelta?: number; params?: { seatId?: string } };

/**
 * El delta del seient, no el del primer homònim. Dos «Pau» (el del vídeo de liquidació) no es
 * barregen: si no, el llibre es queda el delta de l'altre i la verificació falla.
 */
export function ledgerChipDeltaForSeat(results: LedgerResultLine[], seat: { id: string; name: string }): number {
  const owned = results.find((r) => r.params?.seatId != null && r.params.seatId === seat.id);
  const line = owned ?? results.find((r) => (r.params?.seatId == null || r.params.seatId === "") && r.name === seat.name);
  const delta = line?.chipDelta;
  return typeof delta === "number" && Number.isFinite(delta) ? delta : 0;
}

/** Suma el delta d'una mà una sola vegada per `handSeq`. */
export function addLedgerHand(ledger: SoloBuyInLedger, handSeq: number | undefined, delta: number): void {
  if (handSeq != null && ledger.lastHandSeq === handSeq) return;
  ledger.handsNet += delta;
  ledger.hands += 1;
  if (handSeq != null) ledger.lastHandSeq = handSeq;
}

/**
 * Cridat en liquidar cada mà (síncron, abans de res): suma el `chipDelta` que el servidor ha
 * registrat per al jugador a `lastRound.results` (fitxes després de liquidar − inici de la mà).
 * Les línies amb resultat 0 no hi surten: compten com a 0.
 */
export function recordSoloHandOnLedger(room: Room): void {
  const ledger = room.soloBuyIn;
  const results = room.lastRound?.results;
  if (!ledger || !results) return;
  const seat = room.players.find((p) => p.playerId === ledger.playerId);
  if (!seat) return;
  addLedgerHand(ledger, room.handSeq, ledgerChipDeltaForSeat(results, seat));
}

export type SoloBuyInPayout = {
  verified: boolean;
  credit: number;
  expected: number;
  actual: number | null;
};

/**
 * Què s'abona en tancar. A mitja mà (aposta feta però sense liquidar), l'aposta compta per a la
 * verificació però no es retorna (docs/aposta-ma-abandonada.md). La resta del seient sí.
 * Tancar dues vegades no abona dos cops.
 */
export function soloBuyInPayout(room: Room, ledger: SoloBuyInLedger, seat: Player | undefined): SoloBuyInPayout {
  const expected = ledger.amount + ledger.handsNet;
  if (!seat) return { verified: false, credit: ledger.amount, expected, actual: null };
  const midHand = room.phase !== "waiting" && room.phase !== "settlement";
  const actual = seat.chips + (midHand ? seat.bet : 0);
  if (seat.chips < 0) return { verified: false, credit: ledger.amount, expected, actual };
  // Quadra: el romanent (a mitja mà l'aposta es perd, no es torna).
  if (actual === expected) return { verified: true, credit: seat.chips, expected, actual };
  // El seient té menys del que el llibre explica (mà no vista, o el delta d'un homònim).
  // S'abona el romanent real. Tornar la compra sencera esborraria les pèrdues; tornar la compra
  // i el romanent (2.000 + 1.200) deixaria el lobby per sobre del saldo d'entrada.
  if (seat.chips <= expected) return { verified: false, credit: seat.chips, expected, actual };
  return { verified: false, credit: ledger.amount, expected, actual };
}

/**
 * Tanca la compra oberta de la sala (si n'hi ha). El llibre es treu de la sala abans de cap
 * `await`, i el tancament a balances.json només s'aplica si la compra encara és oberta:
 * mai s'abona dues vegades.
 */
export async function settleSoloBuyIn(room: Room, seat: Player | undefined, reason: string): Promise<SoloBuyInPayout | null> {
  const ledger = room.soloBuyIn;
  if (!ledger) return null;
  room.soloBuyIn = undefined;
  const target = seat && seat.playerId === ledger.playerId ? seat : room.players.find((p) => p.playerId === ledger.playerId);
  const payout = soloBuyInPayout(room, ledger, target);
  if (!payout.verified) {
    const returned =
      payout.credit === ledger.amount
        ? `es retorna només la compra (${ledger.amount})`
        : `s'abonen les fitxes de taula (${payout.credit})`;
    console.error(
      `[saldo] compra solo que no quadra (${reason}): sala ${room.id}, jugador ${ledger.playerId}, ` +
        `esperat ${payout.expected}, real ${payout.actual ?? "sense seient"}; ${returned}`
    );
  }
  await closeSoloBuyIn(ledger.id, payout.credit);
  return payout;
}
