import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { mkdtempSync, rmSync } from "node:fs";
import { createServer, type Server } from "node:http";
import os from "node:os";
import path from "node:path";
import express from "express";

const dataDir = mkdtempSync(path.join(os.tmpdir(), "setimig-cookie-"));
process.env.BALANCE_DATA_DIR = dataDir;
process.env.PROFILE_DATA_DIR = path.join(dataDir, "profiles");
process.env.PLAYER_TOKEN_SECRET = "test-session-cookie-secret";

const { issuePlayerToken } = await import("./playerToken.ts");
const { buildAuthSuccess } = await import("./auth/authCommon.ts");
const { createPlayerSession } = await import("./httpPlayerAuth.ts");
const { registerAuthRoutes } = await import("./auth/authRoutes.ts");
const { sessionCookieMiddleware, SESSION_COOKIE } = await import("./sessionCookie.ts");

const PID = "cookieacct0000000000000000000000000000001";

function cookieOf(res: Response): string {
  return res.headers.getSetCookie().find((c) => c.startsWith(SESSION_COOKIE + "=")) ?? "";
}
function assertAttrs(c: string): void {
  assert.match(c, /; Path=\//);
  assert.match(c, /; HttpOnly/);
  assert.match(c, /; Secure/);
  assert.match(c, /; SameSite=Lax/);
}

describe("galeta de sessió setimig_session", () => {
  let server: Server;
  let base = "";
  before(async () => {
    const app = express();
    app.use(express.json());
    app.use(sessionCookieMiddleware);
    // Mateix camí que correu / Google / passkey: buildAuthSuccess + res.json.
    for (const m of ["email", "google", "passkey"] as const) {
      app.post(`/api/test-login/${m}`, (_req, res) => res.json(buildAuthSuccess(PID, m, {})));
    }
    app.post("/api/player-session", async (req, res) => {
      const s = await createPlayerSession(req);
      if (!s) return res.status(401).json({ error: "auth_required" });
      return res.json(s);
    });
    app.post("/api/res", (_req, res) => res.json({ ok: true }));
    registerAuthRoutes(app);
    server = createServer(app);
    await new Promise<void>((r) => server.listen(0, "127.0.0.1", () => r()));
    base = `http://127.0.0.1:${(server.address() as { port: number }).port}`;
  });
  after(async () => {
    await new Promise<void>((r) => server.close(() => r()));
    rmSync(dataDir, { recursive: true, force: true });
  });

  it("login (correu, Google, passkey) posa la galeta amb atributs i Max-Age del token", async () => {
    for (const m of ["email", "google", "passkey"]) {
      const res = await fetch(`${base}/api/test-login/${m}`, { method: "POST" });
      const body = (await res.json()) as { playerToken: string };
      const c = cookieOf(res);
      assert.ok(c.startsWith(`${SESSION_COOKIE}=${body.playerToken};`), m);
      assertAttrs(c);
      const maxAge = Number(/Max-Age=(\d+)/.exec(c)?.[1]);
      assert.ok(maxAge > 364 * 24 * 3600 && maxAge <= 365 * 24 * 3600, m);
    }
  });

  it("renovació POST /api/player-session posa la galeta; sense token, cap", async () => {
    const tok = issuePlayerToken(PID)!;
    const ok = await fetch(`${base}/api/player-session`, { method: "POST", headers: { authorization: `Bearer ${tok}` } });
    assert.equal(ok.status, 200);
    assertAttrs(cookieOf(ok));
    const no = await fetch(`${base}/api/player-session`, { method: "POST" });
    assert.equal(no.status, 401);
    assert.equal(cookieOf(no), "");
    const plain = await fetch(`${base}/api/res`, { method: "POST" });
    assert.equal(cookieOf(plain), "");
  });

  it("POST /api/auth/logout esborra la galeta", async () => {
    const res = await fetch(`${base}/api/auth/logout`, { method: "POST" });
    assert.equal(res.status, 200);
    const c = cookieOf(res);
    assert.ok(c.startsWith(`${SESSION_COOKIE}=;`));
    assertAttrs(c);
    assert.match(c, /Max-Age=0/);
  });
});
