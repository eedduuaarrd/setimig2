import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import fs from "fs/promises";
import path from "path";
import {
  capCampaignAttempts,
  capProcessedSessions,
  pruneEngagementMissions,
  pruneWeeklyLeaderboardDir,
  rotateTimestampedBackups,
} from "./dataRetention.ts";
import {
  creditCheckoutSession,
  isSessionProcessed,
  resetBalanceStoreCacheForTests,
} from "./balances.ts";
import {
  readCampaignFileForTests,
  recordCampaignAttempt,
  resetCampaignProgressCacheForTests,
} from "./campaignProgress.ts";
import { appendRoomChatEntry, getRoomChatHistory, resetRoomChatHistoryForTests } from "./social/roomChatHistory.ts";
import { loadAllPrivateRooms, resetPrivateRoomStoreCacheForTests } from "./privateRoomStore.ts";

const DATA_ROOT = path.join(process.cwd(), "data", `retention-test-${Date.now()}`);

describe("retenció de data/", () => {
  before(async () => {
    process.env.BALANCE_DATA_DIR = DATA_ROOT;
    await fs.mkdir(DATA_ROOT, { recursive: true });
  });

  after(async () => {
    await fs.rm(DATA_ROOT, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 }).catch(() => undefined);
    for (const k of [
      "BALANCE_DATA_DIR",
      "SETIMIG_KEEP_PROCESSED_SESSIONS",
      "SETIMIG_KEEP_CAMPAIGN_ATTEMPTS",
      "SETIMIG_MAX_CHAT_ROOMS",
      "SETIMIG_PRIVATE_ROOM_TTL_DAYS",
    ]) {
      delete process.env[k];
    }
    resetBalanceStoreCacheForTests();
    resetCampaignProgressCacheForTests();
    resetRoomChatHistoryForTests();
    resetPrivateRoomStoreCacheForTests();
  });

  it("rota les còpies balances.json.bak-* i conserva les més recents i l'original", async () => {
    const dir = path.join(DATA_ROOT, "bak");
    await fs.mkdir(dir, { recursive: true });
    const file = path.join(dir, "balances.json");
    await fs.writeFile(file, "{}");
    for (let i = 10; i < 25; i++) {
      await fs.writeFile(`${file}.bak-2026-10-${i}T00-00-00-000Z`, "{}");
    }
    const removed = await rotateTimestampedBackups(file, 5);
    assert.equal(removed.length, 10);
    const left = (await fs.readdir(dir)).sort();
    assert.deepEqual(left, [
      "balances.json",
      "balances.json.bak-2026-10-20T00-00-00-000Z",
      "balances.json.bak-2026-10-21T00-00-00-000Z",
      "balances.json.bak-2026-10-22T00-00-00-000Z",
      "balances.json.bak-2026-10-23T00-00-00-000Z",
      "balances.json.bak-2026-10-24T00-00-00-000Z",
    ]);
  });

  it("el rànquing setmanal conserva les K setmanes més recents i la protegida", async () => {
    const dir = path.join(DATA_ROOT, "weekly");
    await fs.mkdir(dir, { recursive: true });
    for (let w = 1; w <= 20; w++) {
      await fs.writeFile(path.join(dir, `2026-W${String(w).padStart(2, "0")}.json`), "{}");
    }
    await fs.writeFile(path.join(dir, "altres.txt"), "x");
    await pruneWeeklyLeaderboardDir(dir, 3, "2026-W02");
    const left = (await fs.readdir(dir)).sort();
    assert.deepEqual(left, ["2026-W02.json", "2026-W18.json", "2026-W19.json", "2026-W20.json", "altres.txt"]);
  });

  it("missions: esborra dies antics però mai els assoliments", () => {
    const file = {
      missionProgress: {
        "2026-01-01-play_hands-6": { progress: 6 },
        "2026-01-20-win_hands-3": { progress: 1 },
        "2026-01-21-win_hands-3": { progress: 2 },
      } as Record<string, unknown>,
      rewardLedger: ["achievement:first_win", "mission:2026-01-01-play_hands-6", "mission:2026-01-21-win_hands-3"],
    };
    assert.equal(pruneEngagementMissions(file, 14), true);
    assert.deepEqual(Object.keys(file.missionProgress).sort(), ["2026-01-20-win_hands-3", "2026-01-21-win_hands-3"]);
    assert.deepEqual(file.rewardLedger, ["achievement:first_win", "mission:2026-01-21-win_hands-3"]);
    assert.equal(pruneEngagementMissions(file, 14), false);
  });

  it("campanya: limita intents però conserva la 1a victòria de cada nivell", () => {
    const rows = [
      { at: 1, level: 1, won: true },
      { at: 2, level: 2, won: true },
      ...Array.from({ length: 50 }, (_, i) => ({ at: 10 + i, level: 3, won: false })),
    ];
    const capped = capCampaignAttempts(rows, 10);
    assert.equal(capped.length, 12);
    assert.deepEqual(capped.slice(0, 2).map((r) => r.level), [1, 2]);
    assert.equal(capped.at(-1)!.at, 59);
    assert.equal(capCampaignAttempts(rows.slice(0, 5), 10).length, 5);
  });

  it("campanya (store): el fitxer no creix sense límit i els nivells superats es mantenen", async () => {
    process.env.SETIMIG_KEEP_CAMPAIGN_ATTEMPTS = "5";
    resetCampaignProgressCacheForTests();
    const pid = "retentioncamp01";
    await recordCampaignAttempt({ playerId: pid, level: 1, roomId: "r0", won: true, endingChips: 10, startingChips: 5, at: 1 });
    for (let i = 0; i < 20; i++) {
      await recordCampaignAttempt({ playerId: pid, level: 2, roomId: `r${i + 1}`, won: false, endingChips: 0, startingChips: 5, at: 2 + i });
    }
    resetCampaignProgressCacheForTests();
    const file = await readCampaignFileForTests(pid);
    assert.equal(file.completions.length, 6);
    assert.equal(file.completions[0]!.won, true);
    assert.equal(file.highestUnlocked, 2);
  });

  it("sessions de pagament: índex i topall, sense doble abonament de les recents", async () => {
    assert.deepEqual(capProcessedSessions(["a", "b", "c"], 2), ["b", "c"]);
    process.env.SETIMIG_KEEP_PROCESSED_SESSIONS = "3";
    resetBalanceStoreCacheForTests();
    for (let i = 0; i < 6; i++) {
      await creditCheckoutSession(`cs_${i}`, "retentionpay01", 10);
    }
    const again = await creditCheckoutSession("cs_5", "retentionpay01", 10);
    assert.equal(again.alreadyProcessed, true);
    assert.equal(await isSessionProcessed("cs_0"), false);
    assert.equal(await isSessionProcessed("cs_4"), true);
    const raw = JSON.parse(await fs.readFile(path.join(DATA_ROOT, "balances.json"), "utf8"));
    assert.deepEqual(raw.processedSessions, ["cs_3", "cs_4", "cs_5"]);
  });

  it("xat: limita el nombre de sales en memòria", () => {
    process.env.SETIMIG_MAX_CHAT_ROOMS = "3";
    resetRoomChatHistoryForTests();
    for (let i = 0; i < 5; i++) {
      appendRoomChatEntry(`room-${i}`, { kind: "message", sender: "a", text: "hola", timestamp: "t" });
    }
    assert.equal(getRoomChatHistory("room-0").length, 0);
    assert.equal(getRoomChatHistory("room-1").length, 0);
    assert.equal(getRoomChatHistory("room-4").length, 1);
    for (let i = 0; i < 100; i++) {
      appendRoomChatEntry("room-4", { kind: "message", sender: "a", text: `m${i}`, timestamp: "t" });
    }
    assert.equal(getRoomChatHistory("room-4", 1000).length, 40);
  });

  it("taules privades: descarta només les abandonades més enllà del TTL", async () => {
    process.env.SETIMIG_PRIVATE_ROOM_TTL_DAYS = "30";
    resetPrivateRoomStoreCacheForTests();
    const old = Date.now() - 31 * 86_400_000;
    const base = { isPrivate: true, players: [], sessionStats: {} };
    await fs.writeFile(
      path.join(DATA_ROOT, "private-rooms.json"),
      JSON.stringify({
        rooms: {
          vella: { ...base, id: "vella", inviteCode: "OLD1", persistedAt: old },
          recent: { ...base, id: "recent", inviteCode: "NEW1", persistedAt: Date.now() },
          legacy: { ...base, id: "legacy", inviteCode: "LEG1" },
        },
        inviteIndex: { OLD1: "vella", NEW1: "recent", LEG1: "legacy" },
      })
    );
    const loaded = await loadAllPrivateRooms();
    assert.deepEqual(loaded.rooms.map((r) => r.id).sort(), ["legacy", "recent"]);
    assert.equal(loaded.inviteIndex.has("OLD1"), false);
    assert.equal("persistedAt" in loaded.rooms[0]!, false);
    resetPrivateRoomStoreCacheForTests();
    const again = await loadAllPrivateRooms();
    assert.deepEqual(again.rooms.map((r) => r.id).sort(), ["legacy", "recent"]);
  });
});
