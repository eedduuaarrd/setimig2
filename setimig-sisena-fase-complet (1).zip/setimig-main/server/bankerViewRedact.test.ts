import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { emptyRoomBase, roomToView, type GameHost, type Player } from "../shared/gameEngine.ts";

describe("server roomToView banker redaction", () => {
  const host: GameHost = { emitRoomUpdate() {}, schedule: setTimeout, clearTimeout };

  it("does not leak banker card values on the wire during playing", () => {
    const room = emptyRoomBase("srv-redact", "Srv", 100, 0);
    room.phase = "playing";
    const secret = { suit: "hearts" as const, value: 7, points: 7 };
    const banker: Player = {
      id: "bank",
      playerId: "bank",
      seatToken: "b",
      name: "Bank",
      chips: 5_000,
      bet: 0,
      isBanker: true,
      status: "stood",
      handSlots: [
        {
          id: "bs",
          bet: 0,
          cards: [{ id: "c1", card: secret, faceUp: true }],
          doubled: false,
          canDouble: false,
          mort: false,
          blindPair: false,
          blindUntilBankEnd: false,
          mortOffered: false,
          status: "stood",
        },
      ],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    room.players = [
      banker,
      {
        id: "guest",
        playerId: "guest",
        seatToken: "g",
        name: "Guest",
        chips: 2_000,
        bet: 100,
        isBanker: false,
        status: "playing",
        handSlots: [],
        activeSlotIndex: 0,
        lastRoyal7Payout: 0,
        royal7AsBankerStreak: 0,
      },
    ];

    const payload = JSON.stringify(roomToView(room, "guest", host));
    assert.doesNotMatch(payload, /"value":7/);
    assert.doesNotMatch(payload, /hearts/);
  });
});
