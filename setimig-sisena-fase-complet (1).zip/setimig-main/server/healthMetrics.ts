import { execFileSync } from "child_process";
import { readFileSync } from "fs";
import path from "path";

/** Recomptes agregats de taules (sense identificadors ni noms de jugadors). */
export type GameCounts = {
  rooms: number;
  activeGames: number;
  privateRooms: number;
  soloRooms: number;
  humanPlayers: number;
  connectedHumans: number;
  bots: number;
  sockets: number;
};

export const EMPTY_GAME_COUNTS: GameCounts = {
  rooms: 0,
  activeGames: 0,
  privateRooms: 0,
  soloRooms: 0,
  humanPlayers: 0,
  connectedHumans: 0,
  bots: 0,
  sockets: 0,
};

const startedAt = Date.now();
let versionCache: { package: string; commit: string | null } | null = null;

function readPackageVersion(): string {
  try {
    const raw = readFileSync(path.join(process.cwd(), "package.json"), "utf8");
    const v = (JSON.parse(raw) as { version?: unknown }).version;
    return typeof v === "string" ? v : "unknown";
  } catch {
    return "unknown";
  }
}

function readGitCommit(): string | null {
  const fromEnv = process.env.SETIMIG_GIT_SHA?.trim();
  if (fromEnv && /^[0-9a-f]{7,40}$/i.test(fromEnv)) return fromEnv.toLowerCase();
  try {
    const out = execFileSync("git", ["rev-parse", "HEAD"], {
      cwd: process.cwd(),
      timeout: 2_000,
      stdio: ["ignore", "pipe", "ignore"],
    })
      .toString()
      .trim();
    return /^[0-9a-f]{40}$/.test(out) ? out : null;
  } catch {
    return null;
  }
}

/** Versió del paquet i commit (es calcula un sol cop per procés). */
export function getAppVersion(): { package: string; commit: string | null; commitShort: string | null } {
  if (!versionCache) versionCache = { package: readPackageVersion(), commit: readGitCommit() };
  return { ...versionCache, commitShort: versionCache.commit ? versionCache.commit.slice(0, 7) : null };
}

/** Test helper */
export function resetAppVersionCacheForTests(): void {
  versionCache = null;
}

function mb(bytes: number): number {
  return Math.round((bytes / 1_048_576) * 10) / 10;
}

export function buildHealthPayload(opts: { stripe: boolean; games: GameCounts; now?: number }) {
  const now = opts.now ?? Date.now();
  const mem = process.memoryUsage();
  return {
    // Camps antics (compatibilitat): no es canvien.
    ok: true,
    stripe: opts.stripe,
    // Nous camps (només dades agregades, cap dada personal).
    version: getAppVersion(),
    node: process.version,
    startedAt: new Date(startedAt).toISOString(),
    uptimeSec: Math.round(process.uptime()),
    serverTime: new Date(now).toISOString(),
    games: { ...opts.games },
    memory: {
      rssMb: mb(mem.rss),
      heapUsedMb: mb(mem.heapUsed),
      heapTotalMb: mb(mem.heapTotal),
      externalMb: mb(mem.external),
    },
  };
}
