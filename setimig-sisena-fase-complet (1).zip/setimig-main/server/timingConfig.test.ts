import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  humanBetTimeoutMs,
  humanTurnTimeoutMs,
  soloSettlementMs,
} from "./bots.ts";
import { BET_WINDOW_MS, PLAY_WINDOW_MS } from "../shared/turnTiming.ts";

describe("timing config (SETIMIG_TEST_FAST)", () => {
  it("uses short timeouts in test mode", () => {
    process.env.SETIMIG_TEST_FAST = "1";
    assert.ok(humanBetTimeoutMs() < 500);
    assert.ok(humanTurnTimeoutMs() < 500);
    assert.ok(soloSettlementMs() < 500);
    delete process.env.SETIMIG_TEST_FAST;
    assert.equal(humanBetTimeoutMs(), BET_WINDOW_MS);
    assert.equal(humanTurnTimeoutMs(), PLAY_WINDOW_MS);
    assert.equal(BET_WINDOW_MS, 18_000);
    assert.equal(PLAY_WINDOW_MS, 22_000);
  });
});
