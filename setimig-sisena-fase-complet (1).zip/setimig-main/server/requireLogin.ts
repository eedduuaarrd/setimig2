import type { NextFunction, Request, Response } from "express";
import type { Server as SocketIOServer, Socket } from "socket.io";
import { playerHasAccount } from "./auth/identityStore.ts";
import { resolveRenewalCredential } from "./httpPlayerAuth.ts";
import { readTokenFromAuthHeader, verifyPlayerToken } from "./playerToken.ts";
import { hashToken, lineageSession, lineageSessionByHash } from "./revokedTokens.ts";

/** Cos JSON i missatge de connect_error quan falta sessió de compte. */
export const AUTH_REQUIRED = "auth_required" as const;

export type AccountSession = { playerId: string };

/**
 * Rutes /api que queden obertes sense sessió: salut, inici de sessió i el bescanvi
 * del traspàs de domini. Només camins exactes, tret del prefix /api/auth/ (login).
 *
 * POST /api/handoff/exchange és obert perquè el domini nou encara no té sessió.
 * La prova és el codi d'un sol ús (signatura, caducitat, consum atòmic, límit i origen).
 *
 * /api/handoff/mint queda tancat: a més del Bearer, accepta un playerId sol sense
 * prova de possessió. Obrir-lo deixaria emetre un codi per a un jugador aliè.
 */
export function isOpenApiPath(pathname: string): boolean {
  if (pathname === "/api/health" || pathname === "/health") return true;
  if (pathname === "/api/auth" || pathname.startsWith("/api/auth/")) return true;
  if (pathname === "/api/handoff/exchange") return true;
  return false;
}

function tokenFromSocketHandshake(socket: Socket): string | null {
  const auth = socket.handshake.auth as { token?: unknown; playerToken?: unknown } | undefined;
  if (typeof auth?.token === "string" && auth.token.trim()) return auth.token.trim();
  if (typeof auth?.playerToken === "string" && auth.playerToken.trim()) return auth.playerToken.trim();
  const header = readTokenFromAuthHeader(socket.handshake.headers.authorization);
  if (header) return header;
  const q = socket.handshake.query?.playerToken;
  if (typeof q === "string" && q.trim()) return q.trim();
  if (Array.isArray(q) && typeof q[0] === "string" && q[0].trim()) return q[0].trim();
  return null;
}

/**
 * Token HMAC vàlid d'un jugador amb compte (correu / Google / passkey).
 * La galeta `setimig_session` només compta a POST /api/player-session (recuperar la sessió).
 * La resta de /api no la llegeix: no obre una superfície CSRF nova.
 */
export async function resolveAccountSession(
  req: Pick<Request, "headers" | "body" | "query"> & { path?: string; method?: string },
): Promise<AccountSession | null> {
  const allowCookie = req.method === "POST" && req.path === "/api/player-session";
  const cred = resolveRenewalCredential(req, { allowCookie });
  if (!cred) return null;
  if (!(await playerHasAccount(cred.playerId))) return null;
  return { playerId: cred.playerId };
}

export function sendAuthRequired(res: Response): void {
  res.status(401).json({ error: AUTH_REQUIRED });
}

/**
 * Bloqueja /api/* sense sessió de compte. Ordre: abans de les rutes i del 404/405.
 * Sense sessió → 401 { error: "auth_required" } (també per a /api desconegudes).
 * Amb sessió, una /api desconeguda continua donant 404 NOT_FOUND (#247).
 */
export function requireLoginMiddleware(req: Request, res: Response, next: NextFunction): void {
  if (!req.path.startsWith("/api/")) {
    next();
    return;
  }
  if (isOpenApiPath(req.path)) {
    next();
    return;
  }
  void resolveAccountSession(req)
    .then((session) => {
      if (!session) {
        sendAuthRequired(res);
        return;
      }
      (req as Request & { accountPlayerId?: string }).accountPlayerId = session.playerId;
      next();
    })
    .catch((err) => next(err));
}

/**
 * Rebutja el handshake de socket.io sense compte. El client rebrà connect_error
 * amb err.message === "auth_required". Auth: handshake.auth.token (o playerToken),
 * Authorization: Bearer, o query.playerToken.
 */
let gateIo: SocketIOServer | null = null;

/** Desconnecta els sockets d'aquest token i de la mateixa sessió (renovacions incloses). */
export function disconnectSocketsWithToken(token: string, sessionId?: string | null): void {
  const h = hashToken(token);
  const sid = sessionId || lineageSession(token);
  for (const s of gateIo?.sockets.sockets.values() ?? []) {
    const sh = typeof s.data?.tokenHash === "string" ? s.data.tokenHash : "";
    const ss = typeof s.data?.sessionId === "string" ? s.data.sessionId : "";
    if (sh === h || (sid !== null && sid !== "" && (ss === sid || lineageSessionByHash(sh) === sid))) {
      s.disconnect(true);
    }
  }
}

export function registerSocketLoginGate(io: SocketIOServer): void {
  gateIo = io;
  io.use((socket, next) => {
    const token = tokenFromSocketHandshake(socket);
    const verified = token ? verifyPlayerToken(token) : null;
    if (!verified) {
      next(new Error(AUTH_REQUIRED));
      return;
    }
    void playerHasAccount(verified.playerId)
      .then((ok) => {
        if (!ok) {
          next(new Error(AUTH_REQUIRED));
          return;
        }
        socket.data.playerId = verified.playerId;
        socket.data.tokenHash = hashToken(token as string);
        socket.data.sessionId = verified.sid ?? lineageSession(token as string) ?? undefined;
        next();
      })
      .catch(() => next(new Error(AUTH_REQUIRED)));
  });
}
