/**
 * Límit d'intents fallits d'entrar a una taula privada per codi, per IP
 * (no per socket: reconnectar no reinicia el comptador).
 */
export const JOIN_FAIL_WINDOW_MS = 60_000;
export const JOIN_MAX_FAILS = 10;
export const JOIN_BLOCK_MS = 5 * 60_000;

type Entry = { windowStart: number; fails: number; blockedUntil: number };
const entries = new Map<string, Entry>();

export function resetJoinAttemptLimitForTests(): void {
  entries.clear();
}

function prune(now: number): void {
  if (entries.size <= 20_000) return;
  for (const [k, e] of entries) {
    if (e.blockedUntil <= now && now - e.windowStart >= JOIN_FAIL_WINDOW_MS) entries.delete(k);
  }
}

export function isJoinBlocked(key: string | null, now = Date.now()): boolean {
  if (!key) return false;
  const e = entries.get(key);
  return !!e && e.blockedUntil > now;
}

/** Registra un intent fallit; retorna true si la IP queda bloquejada. */
export function recordJoinFailure(key: string | null, now = Date.now()): boolean {
  if (!key) return false;
  let e = entries.get(key);
  if (!e || now - e.windowStart >= JOIN_FAIL_WINDOW_MS) {
    e = { windowStart: now, fails: 0, blockedUntil: e?.blockedUntil ?? 0 };
    entries.set(key, e);
    prune(now);
  }
  e.fails += 1;
  if (e.fails >= JOIN_MAX_FAILS) {
    e.blockedUntil = now + JOIN_BLOCK_MS;
    e.fails = 0;
    e.windowStart = now;
  }
  return e.blockedUntil > now;
}
