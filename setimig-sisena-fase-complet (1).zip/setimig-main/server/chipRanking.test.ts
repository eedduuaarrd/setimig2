import assert from "node:assert/strict";
import { after, before, describe, it } from "node:test";
import { createServer, type Server } from "node:http";
import { mkdtempSync, readFileSync, rmSync, unlinkSync, writeFileSync } from "node:fs";
import os from "node:os";
import path from "node:path";
import express from "express";
import { DEFAULT_CHIPS } from "../shared/chips.ts";
import { API_MAX_REQUESTS, apiRateLimit, resetApiRateLimitForTests } from "./httpRateLimit.ts";
import { issuePlayerToken } from "./playerToken.ts";
import { AUTH_REQUIRED, requireLoginMiddleware } from "./requireLogin.ts";
import { isTestIdentity } from "./analytics.ts";
import {
  compareChipRanking,
  handleGetRanking,
  isExcludedFromChipRanking,
  loadHiddenRankingIds,
  rankingHiddenFilePath,
} from "./chipRanking.ts";

process.env.SETIMIG_TEST_FAST = "1";
process.env.PLAYER_TOKEN_SECRET = "ranking-unit-secret";
const dataDir = mkdtempSync(path.join(os.tmpdir(), "setimig-ranking-"));
process.env.BALANCE_DATA_DIR = dataDir;
process.env.PROFILE_DATA_DIR = path.join(dataDir, "profiles");

const { loginWithIdentity, resetIdentityStoreForTests } = await import("./auth/identityStore.ts");
const { flushBalanceWrites, resetBalanceStoreCacheForTests, setBalance } = await import("./balances.ts");
const { markAccountDeleted, resetDeletedAccountsForTests } = await import("./deletedAccounts.ts");
const { upsertProfile } = await import("./profiles.ts");

const VIEWER = "rkviewer01";
const ZEN = "rkzen00001";
const ANNA = "rktieaaa01";
const MARTA = "rktiebbb01";
const GEMMA_A = "rktieccc01";
const GEMMA_B = "rktieddd01";
const EDU = "rkedu000001";
const EDUARD = "rkeduard001";
const QA = "rkqamaria01";
const NOBAL = "rknobal0001";
const BY_ID = "xx-e2e-player01";
const BOT_COLON = "bot:lobby0001";
const BOT_DASH = "bot-abcdefgh";
const DELETED = "rankdeleted1";

const EMAILS: Record<string, string> = {
  [VIEWER]: "nora.secret@example.com",
  [ZEN]: "zen.secret@example.com",
  [NOBAL]: "nobal.secret@example.com",
};

const PRIVATE_IDS = [VIEWER, ZEN, ANNA, MARTA, GEMMA_A, GEMMA_B, EDU, EDUARD, QA, NOBAL, BY_ID, BOT_COLON, BOT_DASH, DELETED];
const HIDDEN_NAMES = ["Bot Visible", "Id Marcat", "Esborrat Visible"];

describe("GET /api/ranking", () => {
  let server: Server;
  let base = "";
  let viewerToken = "";
  let zenToken = "";
  let nobalToken = "";
  let balancesBefore = "";
  let deletedBefore = "";
  let profileBefore = "";

  before(async () => {
    resetIdentityStoreForTests();
    resetBalanceStoreCacheForTests();
    resetDeletedAccountsForTests();
    resetApiRateLimitForTests();

    async function account(id: string, email: string) {
      const r = await loginWithIdentity({
        kind: "email",
        email,
        current: { playerId: id, legacy: false },
        allowCreate: false,
      });
      assert.equal(r.ok, true, email);
    }

    await account(VIEWER, EMAILS[VIEWER]!);
    await account(ZEN, EMAILS[ZEN]!);
    await account(NOBAL, EMAILS[NOBAL]!);

    await upsertProfile(VIEWER, { displayName: "Nora" });
    await setBalance(VIEWER, 10);
    await upsertProfile(ZEN, { displayName: "Zen" });
    await setBalance(ZEN, 9000);
    await upsertProfile(ANNA, { displayName: "Anna" });
    await setBalance(ANNA, 8000);
    await upsertProfile(MARTA, { displayName: "Marta" });
    await setBalance(MARTA, 8000);
    await upsertProfile(GEMMA_A, { displayName: "Gemma" });
    await setBalance(GEMMA_A, 7000);
    await upsertProfile(GEMMA_B, { displayName: "Gemma" });
    await setBalance(GEMMA_B, 7000);

    for (let i = 0; i < 50; i += 1) {
      const id = `rkfill${String(i).padStart(4, "0")}`;
      PRIVATE_IDS.push(id);
      await upsertProfile(id, { displayName: `Pila ${String(i).padStart(2, "0")}` });
      await setBalance(id, 5000 - i);
    }

    await setBalance(BOT_COLON, 9_000_000);
    await upsertProfile(BOT_DASH, { displayName: "Bot Visible" });
    await setBalance(BOT_DASH, 8_000_000);
    await upsertProfile(BY_ID, { displayName: "Id Marcat" });
    await setBalance(BY_ID, 7_000_000);
    await upsertProfile(EDU, { displayName: "Edu" });
    await setBalance(EDU, 6500);
    await upsertProfile(EDUARD, { displayName: "Eduard" });
    await setBalance(EDUARD, 6400);
    await upsertProfile(QA, { displayName: "QA Maria" });
    await setBalance(QA, 6300);
    await upsertProfile(DELETED, { displayName: "Esborrat Visible" });
    await setBalance(DELETED, 555_555);
    await markAccountDeleted(DELETED);

    await flushBalanceWrites();
    balancesBefore = readFileSync(path.join(dataDir, "balances.json"), "utf8");
    deletedBefore = readFileSync(path.join(dataDir, "deleted-accounts.json"), "utf8");
    profileBefore = readFileSync(path.join(dataDir, "profiles", `${VIEWER}.json`), "utf8");

    viewerToken = issuePlayerToken(VIEWER)!;
    zenToken = issuePlayerToken(ZEN)!;
    nobalToken = issuePlayerToken(NOBAL)!;
    assert.ok(viewerToken && zenToken && nobalToken);

    const app = express();
    app.use(apiRateLimit);
    app.use(requireLoginMiddleware);
    app.get("/api/ranking", (req, res) => void handleGetRanking(req, res));
    server = createServer(app);
    await new Promise<void>((resolve) => server.listen(0, "127.0.0.1", () => resolve()));
    const addr = server.address();
    const port = typeof addr === "object" && addr ? addr.port : 0;
    base = `http://127.0.0.1:${port}`;
  });

  after(async () => {
    if (server) await new Promise<void>((resolve, reject) => server.close((err) => (err ? reject(err) : resolve())));
    resetBalanceStoreCacheForTests();
    resetDeletedAccountsForTests();
    resetIdentityStoreForTests();
    rmSync(dataDir, { recursive: true, force: true });
  });

  async function ranking(token?: string, headers: Record<string, string> = {}) {
    const res = await fetch(base + "/api/ranking", {
      headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}), ...headers },
    });
    const body = await res.json().catch(() => null);
    return { status: res.status, body, retryAfter: res.headers.get("retry-after") };
  }

  function assertNoPrivate(body: unknown) {
    const raw = JSON.stringify(body);
    assert.equal(raw.includes("playerId"), false);
    assert.equal(raw.includes("email"), false);
    assert.equal(raw.includes("token"), false);
    assert.equal(raw.includes("@"), false);
    for (const id of PRIVATE_IDS) assert.equal(raw.includes(id), false, id);
    for (const email of Object.values(EMAILS)) assert.equal(raw.includes(email), false, email);
    const view = body as { entries: Record<string, unknown>[]; me: Record<string, unknown> };
    for (const entry of view.entries) assert.deepEqual(Object.keys(entry).sort(), ["chips", "displayName", "rank"]);
    assert.deepEqual(Object.keys(view.me).sort(), ["chips", "displayName", "inTop", "rank"]);
    assert.deepEqual(Object.keys(view).sort(), ["entries", "me", "totalPlayers"]);
  }

  it("401 sense sessió, amb token invàlid i amb token sense compte", async () => {
    const none = await ranking();
    assert.equal(none.status, 401);
    assert.deepEqual(none.body, { error: AUTH_REQUIRED });

    const bad = await ranking("no-es-un-token");
    assert.equal(bad.status, 401);
    assert.deepEqual(bad.body, { error: AUTH_REQUIRED });

    const orphan = issuePlayerToken("rkorphan0001");
    assert.ok(orphan);
    const anon = await ranking(orphan);
    assert.equal(anon.status, 401);
    assert.deepEqual(anon.body, { error: AUTH_REQUIRED });
  });

  it("top 50 ordenat, empat determinista i posició de qui queda fora", async () => {
    const a = await ranking(viewerToken);
    const b = await ranking(viewerToken);
    assert.equal(a.status, 200);
    assert.deepEqual(a.body, b.body);
    assertNoPrivate(a.body);

    const view = a.body as {
      entries: { rank: number; displayName: string; chips: number }[];
      me: { rank: number | null; displayName: string; chips: number; inTop: boolean };
      totalPlayers: number;
    };
    assert.equal(view.entries.length, 50);
    assert.equal(view.totalPlayers, 59);
    assert.deepEqual(view.entries[0], { rank: 1, displayName: "Zen", chips: 9000 });
    assert.deepEqual(view.entries[1], { rank: 2, displayName: "Anna", chips: 8000 });
    assert.deepEqual(view.entries[2], { rank: 3, displayName: "Marta", chips: 8000 });
    assert.deepEqual(view.entries[3], { rank: 4, displayName: "Gemma", chips: 7000 });
    assert.deepEqual(view.entries[4], { rank: 5, displayName: "Gemma", chips: 7000 });
    assert.deepEqual(view.entries[5], { rank: 6, displayName: "Edu", chips: 6500 });
    assert.deepEqual(view.entries[6], { rank: 7, displayName: "Eduard", chips: 6400 });
    assert.deepEqual(view.entries[7], { rank: 8, displayName: "QA Maria", chips: 6300 });
    for (let i = 0; i < view.entries.length; i += 1) {
      assert.equal(view.entries[i]!.rank, i + 1);
      if (i > 0) assert.ok(view.entries[i]!.chips <= view.entries[i - 1]!.chips);
    }
    assert.equal(view.entries.some((e) => e.displayName === "Nora"), false);
    assert.deepEqual(view.me, { rank: 59, displayName: "Nora", chips: 10, inTop: false });
    for (const name of HIDDEN_NAMES) assert.equal(JSON.stringify(view.entries).includes(name), false, name);
  });

  it("qui és al top rep la seva posició dins de la llista", async () => {
    const view = (await ranking(zenToken)).body as {
      entries: { rank: number; displayName: string; chips: number }[];
      me: { rank: number | null; displayName: string; chips: number; inTop: boolean };
    };
    assert.equal(view.me.rank, 1);
    assert.equal(view.me.inTop, true);
    assert.equal(view.me.chips, 9000);
    assert.equal(view.me.displayName, "Zen");
    assert.deepEqual(view.entries[0], { rank: 1, displayName: "Zen", chips: 9000 });
    assertNoPrivate(view);
  });

  it("el nom no exclou; l'id de prova, els bots i els esborrats sí", async () => {
    const view = (await ranking(viewerToken)).body as {
      entries: { displayName: string }[];
      totalPlayers: number;
    };
    const names = view.entries.map((e) => e.displayName);
    for (const name of ["Edu", "Eduard", "QA Maria"]) assert.equal(names.includes(name), true, name);
    for (const name of HIDDEN_NAMES) assert.equal(names.includes(name), false, name);
    assert.equal(view.totalPlayers, 59);
    assert.equal(isExcludedFromChipRanking(BY_ID), true);
    assert.equal(isExcludedFromChipRanking("ab-test-player01"), true);
    assert.equal(isExcludedFromChipRanking(BOT_COLON), true);
    assert.equal(isExcludedFromChipRanking(BOT_DASH), true);
    assert.equal(isExcludedFromChipRanking(EDU), false);
    assert.equal(isExcludedFromChipRanking(EDUARD), false);
    assert.equal(isExcludedFromChipRanking(QA), false);
  });

  it("isTestIdentity continua marcant el nom edu; el rànquing no", () => {
    assert.equal(isTestIdentity(EDU, "Edu"), true);
    assert.equal(isTestIdentity(EDU, "edu"), true);
    assert.equal(isTestIdentity(QA, "QA Maria"), true);
    assert.equal(isTestIdentity(BY_ID, "Id Marcat"), true);
    assert.equal(isExcludedFromChipRanking(EDU), false);
    assert.equal(isExcludedFromChipRanking(QA), false);
    const prev = process.env.SETIMIG_ANALYTICS_TEST_NAME_RE;
    process.env.SETIMIG_ANALYTICS_TEST_NAME_RE = "^maria\\b";
    try {
      assert.equal(isTestIdentity("rkmaria0001", "Maria"), true);
      assert.equal(isTestIdentity("rkmaria0001", "Edu"), false);
      assert.equal(isExcludedFromChipRanking("rkmaria0001"), false);
    } finally {
      if (prev === undefined) delete process.env.SETIMIG_ANALYTICS_TEST_NAME_RE;
      else process.env.SETIMIG_ANALYTICS_TEST_NAME_RE = prev;
    }
  });

  it("sense saldo desat, la posició usa el saldo per defecte i no escriu balances.json", async () => {
    const view = (await ranking(nobalToken)).body as {
      me: { rank: number | null; chips: number; inTop: boolean; displayName: string };
      entries: { displayName: string }[];
    };
    assert.equal(view.me.chips, DEFAULT_CHIPS);
    assert.equal(view.me.rank, 1);
    assert.equal(view.me.inTop, true);
    assert.equal(view.me.displayName, "Jugador");
    assert.equal(readFileSync(path.join(dataDir, "balances.json"), "utf8"), balancesBefore);
    assert.equal(readFileSync(path.join(dataDir, "deleted-accounts.json"), "utf8"), deletedBefore);
    assert.equal(readFileSync(path.join(dataDir, "profiles", `${VIEWER}.json`), "utf8"), profileBefore);
  });

  it("l'empat de nom i fitxes es desfà pel playerId, de manera estable", () => {
    const gemmaA = { playerId: GEMMA_A, displayName: "Gemma", chips: 7000 };
    const gemmaB = { playerId: GEMMA_B, displayName: "Gemma", chips: 7000 };
    assert.ok(compareChipRanking(gemmaA, gemmaB) < 0);
    assert.ok(compareChipRanking(gemmaB, gemmaA) > 0);
    assert.equal(compareChipRanking(gemmaA, { ...gemmaA }), 0);
    const anna = { playerId: ANNA, displayName: "Anna", chips: 8000 };
    const marta = { playerId: MARTA, displayName: "Marta", chips: 8000 };
    assert.ok(compareChipRanking(anna, marta) < 0);
  });

  it("429 quan se supera el rate limit, amb el mateix cos que la resta de /api", async () => {
    resetApiRateLimitForTests();
    const headers = { "cf-connecting-ip": "203.0.113.50" };
    for (let i = 0; i < API_MAX_REQUESTS; i += 1) {
      const ok = await ranking(viewerToken, headers);
      assert.equal(ok.status, 200, `petició ${i + 1}`);
    }
    const limited = await ranking(viewerToken, headers);
    assert.equal(limited.status, 429);
    assert.equal(limited.retryAfter, "60");
    assert.deepEqual(limited.body, {
      error: "Massa peticions. Torna-ho a provar d'aquí a un minut.",
      code: "RATE_LIMIT",
    });
    assert.equal(readFileSync(path.join(dataDir, "balances.json"), "utf8"), balancesBefore);
  });

  it("ranking-hidden.json treu l'id del top i de la posició pròpia sense tocar balances.json", async () => {
    const hiddenPath = rankingHiddenFilePath();
    const balancesPath = path.join(dataDir, "balances.json");
    const before = readFileSync(balancesPath, "utf8");
    writeFileSync(hiddenPath, JSON.stringify({ playerIds: [ZEN, 12, "  ", ""] }));
    try {
      const hidden = await loadHiddenRankingIds();
      assert.equal(hidden.has(ZEN), true);
      assert.equal(isExcludedFromChipRanking(ZEN, hidden), true);
      assert.equal(isExcludedFromChipRanking(ZEN), false);

      const asViewer = (await ranking(viewerToken)).body as {
        entries: { rank: number; displayName: string; chips: number }[];
        me: { rank: number | null; displayName: string; inTop: boolean };
        totalPlayers: number;
      };
      assert.equal(asViewer.entries.some((e) => e.displayName === "Zen"), false);
      assert.equal(asViewer.entries[0]?.displayName, "Anna");
      assert.equal(asViewer.entries[0]?.rank, 1);
      assert.equal(asViewer.totalPlayers, 58);
      assert.equal(asViewer.me.displayName, "Nora");
      assert.notEqual(asViewer.me.rank, null);

      const asZen = (await ranking(zenToken)).body as {
        entries: { displayName: string }[];
        me: { rank: number | null; displayName: string; chips: number; inTop: boolean };
        totalPlayers: number;
      };
      assert.equal(asZen.me.rank, null);
      assert.equal(asZen.me.inTop, false);
      assert.equal(asZen.me.displayName, "Zen");
      assert.equal(asZen.me.chips, 9000);
      assert.equal(asZen.entries.some((e) => e.displayName === "Zen"), false);
      assert.equal(asZen.totalPlayers, 58);
      assert.equal(readFileSync(balancesPath, "utf8"), before);
    } finally {
      unlinkSync(hiddenPath);
    }

    const restored = (await ranking(zenToken)).body as {
      me: { rank: number | null; displayName: string };
      entries: { displayName: string }[];
      totalPlayers: number;
    };
    assert.equal(restored.me.rank, 1);
    assert.equal(restored.me.displayName, "Zen");
    assert.equal(restored.entries[0]?.displayName, "Zen");
    assert.equal(restored.totalPlayers, 59);
    assert.equal(readFileSync(balancesPath, "utf8"), before);
  });

  it("sense fitxer o amb JSON trencat el rànquing és el d'ara i balances.json no canvia", async () => {
    const hiddenPath = rankingHiddenFilePath();
    const balancesPath = path.join(dataDir, "balances.json");
    const before = readFileSync(balancesPath, "utf8");
    try {
      unlinkSync(hiddenPath);
    } catch {
      /* no hi era */
    }

    const open = (await ranking(viewerToken)).body as {
      entries: { displayName: string }[];
      me: { rank: number | null };
      totalPlayers: number;
    };
    assert.equal(open.totalPlayers, 59);
    assert.equal(open.entries[0]?.displayName, "Zen");
    assert.equal(open.me.rank, 59);
    assert.equal((await loadHiddenRankingIds()).size, 0);

    for (const broken of ["{ no és json", "null", "[]", '{"playerIds":{"a":1}}', ""]) {
      writeFileSync(hiddenPath, broken);
      const ids = await loadHiddenRankingIds();
      assert.equal(ids.size, 0, broken);
      const view = (await ranking(viewerToken)).body as {
        entries: { displayName: string }[];
        me: { rank: number | null; displayName: string };
        totalPlayers: number;
      };
      assert.equal(view.totalPlayers, 59, broken);
      assert.equal(view.entries[0]?.displayName, "Zen", broken);
      assert.equal(view.me.rank, 59, broken);
      assert.equal(view.me.displayName, "Nora", broken);
    }

    assert.equal(readFileSync(balancesPath, "utf8"), before);
    unlinkSync(hiddenPath);
    assert.equal(readFileSync(balancesPath, "utf8"), before);
  });
});
