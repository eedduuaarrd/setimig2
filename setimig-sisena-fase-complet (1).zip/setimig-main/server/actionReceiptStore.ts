type ReceiptEntry = {
  expiresAt: number;
  result: Promise<unknown>;
};

export type ActionReceiptStore = {
  run<T>(key: string, actionId: string | undefined, operation: () => T | Promise<T>): Promise<T>;
  clear(): void;
};

export function isActionReceiptId(value: unknown): value is string {
  return typeof value === "string" && value.trim().length > 0 && value.length <= 128;
}

/** Shares the result of a repeated action ID so transport retries cannot apply it twice. */
export function createActionReceiptStore(options: { ttlMs?: number; maxEntries?: number; now?: () => number } = {}): ActionReceiptStore {
  const ttlMs = options.ttlMs ?? 120_000;
  const maxEntries = options.maxEntries ?? 5_000;
  const now = options.now ?? Date.now;
  const receipts = new Map<string, ReceiptEntry>();
  let lastObservedAt = Number.NEGATIVE_INFINITY;

  function pruneExpired(at: number) {
    for (const [key, entry] of receipts) {
      if (entry.expiresAt > at) break;
      receipts.delete(key);
    }
  }

  return {
    async run<T>(key, actionId, operation) {
      if (!isActionReceiptId(actionId)) return operation();

      const at = Math.max(lastObservedAt, now());
      lastObservedAt = at;
      pruneExpired(at);
      const receiptKey = `${key}\u0000${actionId}`;
      const existing = receipts.get(receiptKey);
      if (existing) return existing.result as Promise<T>;

      const result = Promise.resolve().then(operation);
      receipts.set(receiptKey, { expiresAt: at + ttlMs, result });
      while (receipts.size > maxEntries) {
        const oldestKey = receipts.keys().next().value as string | undefined;
        if (oldestKey === undefined) break;
        receipts.delete(oldestKey);
      }
      return result;
    },
    clear() {
      receipts.clear();
    },
  };
}
