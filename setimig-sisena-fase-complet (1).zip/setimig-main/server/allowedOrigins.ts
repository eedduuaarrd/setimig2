/**
 * Orígens (esquema + host + port) des d on es pot fer servir l app.
 *
 * - Per defecte: el domini nou (https://sevenhalf.club, https://www.sevenhalf.club) i l antic
 *   (https://setimig.supercbb.com) mentre duri la migració.
 * - `ALLOWED_ORIGINS` (llista separada per comes) substitueix la llista per defecte.
 * - L origen d `APP_URL` sempre hi és.
 * - Fora de producció també s accepta http://localhost:* i http://127.0.0.1:*.
 * - Una petició del mateix origen (Origin == Host de la petició) sempre s accepta: així els
 *   servidors de prova a 127.0.0.1:<port> en mode producció continuen funcionant.
 */
export const OLD_ORIGIN = "https://setimig.supercbb.com";
export const PRIMARY_ORIGIN = "https://sevenhalf.club";
export const DEFAULT_ALLOWED_ORIGINS: readonly string[] = [
  PRIMARY_ORIGIN,
  "https://www.sevenhalf.club",
  OLD_ORIGIN,
];

type Env = NodeJS.ProcessEnv | Record<string, string | undefined>;

/** Normalitza a `esquema://host[:port]` en minúscules, o null si no és un origen http(s). */
export function normalizeOrigin(raw: unknown): string | null {
  if (typeof raw !== "string" || !raw.trim()) return null;
  try {
    const u = new URL(raw.trim());
    if (u.protocol !== "https:" && u.protocol !== "http:") return null;
    return u.origin.toLowerCase();
  } catch {
    return null;
  }
}

export function configuredAllowedOrigins(env: Env = process.env): string[] {
  const fromEnv = (env.ALLOWED_ORIGINS ?? "")
    .split(",")
    .map((s) => normalizeOrigin(s))
    .filter((s): s is string => !!s);
  const list = fromEnv.length > 0 ? fromEnv : [...DEFAULT_ALLOWED_ORIGINS];
  const app = normalizeOrigin(env.APP_URL);
  if (app && !list.includes(app)) list.push(app);
  return list;
}

function isLocalDevOrigin(origin: string): boolean {
  try {
    const u = new URL(origin);
    return u.protocol === "http:" && (u.hostname === "localhost" || u.hostname === "127.0.0.1");
  } catch {
    return false;
  }
}

function headerString(v: string | string[] | undefined): string | undefined {
  return Array.isArray(v) ? v[0] : v;
}

/** L origen és a la llista configurada (sense comptar el mateix origen ni localhost). */
export function isListedOrigin(origin: unknown, env: Env = process.env): boolean {
  const o = normalizeOrigin(origin);
  return !!o && configuredAllowedOrigins(env).includes(o);
}

/**
 * Decideix si una petició amb aquesta capçalera Origin es pot atendre.
 * Sense Origin (clients no navegador, tests, health checks) es permet: el control d origen
 * només té sentit per a navegadors.
 */
export function isAllowedOrigin(
  originRaw: unknown,
  requestHost?: string | string[],
  env: Env = process.env,
): boolean {
  if (originRaw === undefined || originRaw === null || originRaw === "") return true;
  const origin = normalizeOrigin(originRaw);
  if (!origin) return false;
  if (configuredAllowedOrigins(env).includes(origin)) return true;
  const host = headerString(requestHost)?.trim().toLowerCase();
  if (host && new URL(origin).host === host) return true;
  if (env.NODE_ENV !== "production" && isLocalDevOrigin(origin)) return true;
  return false;
}

/** Origen públic a fer servir en enllaços absoluts (invitacions): el de la petició si és a la llista. */
export function publicOriginFor(originRaw: unknown, env: Env = process.env): string | null {
  const o = normalizeOrigin(originRaw);
  return o && configuredAllowedOrigins(env).includes(o) ? o : null;
}

export function defaultPublicOrigin(env: Env = process.env): string {
  return normalizeOrigin(env.APP_URL) ?? OLD_ORIGIN;
}

export type DomainKind = "old" | "new" | "other";

/** Classifica un Host (sense port) per a la mètrica de migració. */
export function domainKindForHost(hostRaw: unknown): DomainKind {
  if (typeof hostRaw !== "string") return "other";
  const host = hostRaw.trim().toLowerCase().replace(/:\d+$/, "");
  if (host === "setimig.supercbb.com") return "old";
  if (host === "sevenhalf.club" || host === "www.sevenhalf.club") return "new";
  return "other";
}

type MinimalReq = { headers: Record<string, string | string[] | undefined>; method?: string; path?: string };
type MinimalRes = {
  setHeader(name: string, value: string): unknown;
  status(code: number): { end(): unknown; json(body: unknown): unknown };
};

function corsOriginAllowed(origin: string, env: Env): boolean {
  return isListedOrigin(origin, env) || (env.NODE_ENV !== "production" && isLocalDevOrigin(origin));
}

/**
 * Opcions de socket.io: CORS per als orígens de la llista i rebuig del handshake (HTTP 403)
 * quan el navegador envia un Origin que no és ni de la llista ni del mateix host.
 */
export function socketIoOriginOptions(env: Env = process.env) {
  return {
    cors: {
      origin: (origin: string | undefined, cb: (err: Error | null, allow?: boolean) => void) => {
        cb(null, !!origin && corsOriginAllowed(origin, env));
      },
    },
    allowRequest: (
      req: { headers: Record<string, string | string[] | undefined> },
      cb: (err: string | null | undefined, success: boolean) => void,
    ) => {
      const ok = isAllowedOrigin(req.headers.origin, req.headers.host, env);
      if (!ok) console.warn(`[origin] socket rebutjat: ${String(req.headers.origin).slice(0, 80)}`);
      cb(ok ? null : "Origen no permès", ok);
    },
  };
}

/**
 * CORS de /api/*: només per als orígens de la llista (sense cookies; l'autenticació va per
 * Authorization: Bearer). Un preflight d'un origen desconegut rep 403. Les peticions del
 * mateix origen no necessiten CORS i no canvien.
 */
export function apiCorsMiddleware(env: Env = process.env) {
  return (req: MinimalReq, res: MinimalRes, next: () => void) => {
    if (!req.path?.startsWith("/api/")) return next();
    const originHeader = req.headers.origin;
    const origin = Array.isArray(originHeader) ? originHeader[0] : originHeader;
    if (!origin) return next();
    const allowed = corsOriginAllowed(origin, env);
    if (allowed) {
      res.setHeader("Access-Control-Allow-Origin", normalizeOrigin(origin) ?? origin);
      res.setHeader("Vary", "Origin");
      res.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
      res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
      res.setHeader("Access-Control-Max-Age", "600");
    }
    if (req.method === "OPTIONS") {
      if (allowed) return void res.status(204).end();
      if (!isAllowedOrigin(origin, req.headers.host, env)) {
        return void res.status(403).json({ error: "Origen no permès.", code: "BAD_ORIGIN" });
      }
    }
    next();
  };
}
