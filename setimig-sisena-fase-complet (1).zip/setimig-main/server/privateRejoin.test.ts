import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { createServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket } from "socket.io-client";
import { setupGameHandlers } from "./game.ts";
import { issuePlayerToken } from "./playerToken.ts";

const HOST_ID = "privrejoinhost0001";
const GUEST_ID = "privrejoinguest001";

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";

function connect(url: string): Promise<Socket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.on("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.on("connect_error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

function waitGameError(socket: Socket): Promise<{ code?: string }> {
  return new Promise((resolve) => socket.once("game_error", resolve));
}

function waitJoined(socket: Socket): Promise<{
  inviteCode?: string;
  viewerSeatToken?: string;
  playerToken?: string;
  id: string;
  phase?: string;
}> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("join timeout")), 15_000);
    socket.once("joined_room", (room) => {
      clearTimeout(timer);
      resolve(room);
    });
  });
}

describe("private table rejoin", () => {
  it("rejects invalid socket tokens instead of downgrading to the submitted player ID", async () => {
    const http = createServer();
    const io = new SocketIOServer(http, { cors: { origin: "*" } });
    await setupGameHandlers(io);
    await new Promise<void>((resolve) => http.listen(0, "127.0.0.1", resolve));
    const port = (http.address() as { port: number }).port;
    const client = await connect(`http://127.0.0.1:${port}`);

    try {
      const createError = waitGameError(client);
      client.emit("create_private_table", {
        playerName: "Host",
        playerId: HOST_ID,
        playerToken: "not-a-valid-token",
      });
      assert.equal((await createError).code, "BAD_TOKEN");

      const soloError = waitGameError(client);
      client.emit("join_solo_room", {
        playerName: "Host",
        playerId: HOST_ID,
        playerToken: "not-a-valid-token",
      });
      assert.equal((await soloError).code, "BAD_TOKEN");
    } finally {
      client.disconnect();
      io.close();
      await new Promise<void>((resolve) => http.close(() => resolve()));
    }
  });

  it("keeps seat mid-hand after disconnect and seatToken rejoin", async () => {
    process.env.SETIMIG_TEST_FAST = "1";
    const http = createServer();
    const io = new SocketIOServer(http, { cors: { origin: "*" } });
    await setupGameHandlers(io);
    await new Promise<void>((r) => http.listen(0, "127.0.0.1", () => r()));
    const port = (http.address() as { port: number }).port;
    const url = `http://127.0.0.1:${port}`;

    const host = await connect(url);
    const hostToken = issuePlayerToken(HOST_ID)!;
    host.emit("create_private_table", {
      playerName: "Host",
      playerId: HOST_ID,
    });
    const hostRoom = await waitJoined(host);
    assert.ok(hostRoom.inviteCode);
    assert.equal(hostRoom.playerToken, undefined);

    const guest = await connect(url);
    guest.emit("join_private_table", {
      inviteCode: hostRoom.inviteCode,
      playerName: "Guest",
      playerId: GUEST_ID,
    });
    const guestRoom = await waitJoined(guest);
    assert.equal(guestRoom.playerToken, undefined);
    const guestSeat = guestRoom.viewerSeatToken;
    assert.ok(guestSeat);

    host.emit("fill_private_bots", {
      roomId: hostRoom.id,
      playerToken: hostToken,
      actionSeq: 1,
    });
    await new Promise((r) => setTimeout(r, 120));
    host.emit("start_game", {
      roomId: hostRoom.id,
      playerToken: hostToken,
      actionSeq: 2,
    });

    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("game never started")), 45_000);
      guest.on("room_update", (room: { phase: string }) => {
        if (room.phase === "betting" || room.phase === "playing") {
          clearTimeout(timer);
          resolve();
        }
      });
    });

    guest.disconnect();
    await new Promise((r) => setTimeout(r, 250));

    const guest2 = await connect(url);
    guest2.emit("join_private_table", {
      inviteCode: hostRoom.inviteCode,
      playerName: "Guest",
      seatToken: guestSeat,
      playerId: GUEST_ID,
    });
    const resumed = await waitJoined(guest2);
    assert.equal(resumed.viewerSeatToken, guestSeat);
    assert.equal(resumed.playerToken, undefined);

    try {
      assert.ok(resumed.id);
    } finally {
      delete process.env.SETIMIG_TEST_FAST;
      host.disconnect();
      guest2.disconnect();
      io.close();
      await new Promise<void>((r) => http.close(() => r()));
    }
  });
});
