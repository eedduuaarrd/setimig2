import fs from "fs";
import fsp from "fs/promises";
import path from "path";

/**
 * Escriptures agrupades (debounce) per a fitxers JSON calents com balances.json i el rànquing
 * setmanal: en lloc de reescriure el fitxer sencer a cada mà, es marca "brut" i es buida
 * com a molt cada `coalesceDelayMs()` (per defecte 1,5 s). Sempre atòmic (tmp + rename).
 * En SIGTERM/SIGINT i en sortir del procés es buida tot el que quedi pendent.
 */
export function coalesceDelayMs(): number {
  const raw = process.env.SETIMIG_WRITE_COALESCE_MS;
  if (raw !== undefined && raw !== "") {
    const n = Number(raw);
    if (Number.isFinite(n) && n >= 0) return Math.min(Math.floor(n), 10_000);
  }
  // Tests ràpids: escriptura immediata (comportament anterior) llevat que ho demanin explícitament.
  return process.env.SETIMIG_TEST_FAST === "1" ? 0 : 1_500;
}

const writeCounts = new Map<string, number>();

function countWrite(filePath: string): void {
  const key = path.basename(path.dirname(filePath)) === "weekly-leaderboard" ? "weekly-leaderboard" : path.basename(filePath);
  writeCounts.set(key, (writeCounts.get(key) ?? 0) + 1);
}

/** Nombre d'escriptures a disc per fitxer (per a la prova de càrrega i tests). */
export function getWriteCounts(): Record<string, number> {
  return Object.fromEntries(writeCounts);
}

export function resetWriteCounts(): void {
  writeCounts.clear();
}

export async function writeJsonAtomic(filePath: string, data: unknown): Promise<void> {
  await fsp.mkdir(path.dirname(filePath), { recursive: true });
  const tmp = `${filePath}.tmp`;
  await fsp.writeFile(tmp, JSON.stringify(data, null, 2), "utf8");
  await fsp.rename(tmp, filePath);
  countWrite(filePath);
}

export function writeJsonAtomicSync(filePath: string, data: unknown): void {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const tmp = `${filePath}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2), "utf8");
  fs.renameSync(tmp, filePath);
  countWrite(filePath);
}

type Flusher = { name: string; flush: () => Promise<void>; flushSync: () => void };
const flushers: Flusher[] = [];

export function registerFlusher(flusher: Flusher): void {
  if (!flushers.some((f) => f.name === flusher.name)) flushers.push(flusher);
}

/** Buida totes les escriptures pendents (asíncron, respecta l'ordre de cada store). */
export async function flushAllPendingWrites(): Promise<void> {
  for (const f of flushers) {
    try {
      await f.flush();
    } catch (err) {
      console.error(`[flush] ${f.name}:`, err);
    }
  }
}

/** Buidat síncron per a l'event `exit` (no hi pot haver feina asíncrona). */
export function flushAllPendingWritesSync(): void {
  for (const f of flushers) {
    try {
      f.flushSync();
    } catch (err) {
      console.error(`[flush] ${f.name} (sync):`, err);
    }
  }
}

let shutdownInstalled = false;

/** SIGTERM/SIGINT: buida i surt amb 0. `exit`: buidat síncron de seguretat. */
export function installShutdownFlush(timeoutMs = 5_000): void {
  if (shutdownInstalled) return;
  shutdownInstalled = true;
  let stopping = false;
  const onSignal = (sig: NodeJS.Signals) => {
    if (stopping) return;
    stopping = true;
    console.log(`[shutdown] ${sig}: guardant escriptures pendents…`);
    const guard = setTimeout(() => {
      flushAllPendingWritesSync();
      process.exit(0);
    }, timeoutMs);
    void flushAllPendingWrites().finally(() => {
      clearTimeout(guard);
      flushAllPendingWritesSync();
      process.exit(0);
    });
  };
  process.on("SIGTERM", onSignal);
  process.on("SIGINT", onSignal);
  process.on("exit", () => flushAllPendingWritesSync());
}
