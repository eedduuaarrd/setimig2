import type { Request, Response } from "express";
import { resolvePlayerFromRequest } from "./httpPlayerAuth.ts";
import { getProfile, touchLastSeen } from "./profiles.ts";
import { CLIENT_EVENTS, startSessionCounter, takeSessionHands, track } from "./analytics.ts";

const DAY_MS = 86_400_000;

/**
 * POST /api/events — esdeveniments del client (first-party, mateix origen).
 * Cos: { event, sid, appVersion, platform, isTest, props }. Respon 204 (o 400 si no és vàlid).
 * No es llegeix ni es desa la IP, el user-agent ni cap cookie.
 */
export async function handlePostEvent(req: Request, res: Response): Promise<void> {
  const resolved = resolvePlayerFromRequest(req);
  if (!resolved) {
    res.status(400).json({ error: "Identitat de jugador invalida." });
    return;
  }
  const body = (req.body ?? {}) as Record<string, unknown>;
  const event = typeof body.event === "string" ? body.event : "";
  if (!CLIENT_EVENTS.has(event)) {
    res.status(400).json({ error: "Esdeveniment no permès.", code: "BAD_EVENT" });
    return;
  }
  const props: Record<string, unknown> =
    body.props && typeof body.props === "object" && !Array.isArray(body.props) ? { ...(body.props as object) } : {};
  const playerId = resolved.playerId;
  const now = Date.now();

  try {
    if (event === "session_start") {
      const profile = (await touchLastSeen(playerId, now)) ?? (await getProfile(playerId));
      if (profile?.createdAt) props.daysSinceRegister = Math.floor((now - profile.createdAt) / DAY_MS);
      else delete props.daysSinceRegister;
      startSessionCounter(playerId);
    } else if (event === "session_end") {
      props.handsInSession = takeSessionHands(playerId);
    }
    const ok = await track(playerId, event, props, {
      sid: body.sid,
      appVersion: body.appVersion,
      platform: body.platform,
      isTest: body.isTest,
      ts: now,
    });
    if (!ok) {
      res.status(400).json({ error: "Esdeveniment invalid.", code: "BAD_EVENT" });
      return;
    }
    res.status(204).end();
  } catch (error: unknown) {
    console.error("[api] /api/events", error instanceof Error ? error.message : error);
    res.status(500).json({ error: "Error intern. Torna-ho a provar." });
  }
}
