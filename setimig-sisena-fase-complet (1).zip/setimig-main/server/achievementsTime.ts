/** Calendar helpers in Europe/Madrid (no DST bugs for day/week boundaries). */

const TZ = "Europe/Madrid";

type MadridParts = { year: number; month: number; day: number; weekday: number };

/** Crear un Intl.DateTimeFormat és car (~ms): el reutilitzem (es cridava 4 cops per mà resolta). */
let madridFormatter: Intl.DateTimeFormat | null = null;

function madridDtf(): Intl.DateTimeFormat {
  if (!madridFormatter) {
    madridFormatter = new Intl.DateTimeFormat("en-US", {
      timeZone: TZ,
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      weekday: "short",
    });
  }
  return madridFormatter;
}

function madridPartsAt(ms: number): MadridParts {
  const parts = madridDtf().formatToParts(new Date(ms));
  const get = (type: string) => parts.find((p) => p.type === type)?.value ?? "";
  const weekdayMap: Record<string, number> = {
    Mon: 1,
    Tue: 2,
    Wed: 3,
    Thu: 4,
    Fri: 5,
    Sat: 6,
    Sun: 7,
  };
  const wd = weekdayMap[get("weekday")] ?? 1;
  return {
    year: Number(get("year")),
    month: Number(get("month")),
    day: Number(get("day")),
    weekday: wd,
  };
}

export function madridDayKey(ms: number = Date.now()): string {
  const p = madridPartsAt(ms);
  const mm = String(p.month).padStart(2, "0");
  const dd = String(p.day).padStart(2, "0");
  return `${p.year}-${mm}-${dd}`;
}

/** ISO week Monday–Sunday label for the Madrid calendar week containing `ms`. */
export function madridWeekKey(ms: number = Date.now()): string {
  const p = madridPartsAt(ms);
  const utcNoon = Date.UTC(p.year, p.month - 1, p.day, 12, 0, 0);
  const mondayOffset = p.weekday === 7 ? -6 : 1 - p.weekday;
  const mondayMs = utcNoon + mondayOffset * 86_400_000;
  const mon = madridPartsAt(mondayMs);
  const thursdayMs = mondayMs + 3 * 86_400_000;
  const th = madridPartsAt(thursdayMs);
  const jan1 = Date.UTC(th.year, 0, 1, 12, 0, 0);
  const weekNum = Math.floor((thursdayMs - jan1) / (7 * 86_400_000)) + 1;
  const w = String(weekNum).padStart(2, "0");
  return `${mon.year}-W${w}`;
}
