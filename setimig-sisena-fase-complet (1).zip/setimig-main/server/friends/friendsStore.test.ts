import { describe, it, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";
import fs from "fs/promises";
import os from "os";
import path from "path";
import {
  addFriendByCode,
  flushFriendsStoreWritesForTests,
  getFriendCodeForPlayer,
  getOrCreatePlayerFriendsRecord,
  getPersistentTableCode,
  listFriendPlayerIds,
  removeFriendByCode,
  resetFriendsStoreCacheForTests,
  setPersistentTableCode,
} from "./friendsStore.ts";

const PLAYER_A = "friendplayeraaaa01";
const PLAYER_B = "friendplayerbbbb02";

describe("friendsStore", () => {
  let dataDir = "";

  beforeEach(async () => {
    dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "setimig-friends-"));
    process.env.FRIENDS_DATA_DIR = dataDir;
    resetFriendsStoreCacheForTests();
  });

  afterEach(async () => {
    delete process.env.FRIENDS_DATA_DIR;
    resetFriendsStoreCacheForTests();
    if (dataDir) await fs.rm(dataDir, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 });
  });

  it("creates stable friend codes and persists with backup", async () => {
    const record = await getOrCreatePlayerFriendsRecord(PLAYER_A);
    assert.match(record.friendCode, /^F[A-Z0-9]{4,10}$/);
    await flushFriendsStoreWritesForTests();

    const storePath = path.join(dataDir, "friends.json");
    const backupPath = path.join(dataDir, "friends.json.bak");
    assert.ok(await fs.stat(storePath));

    resetFriendsStoreCacheForTests();
    const again = await getFriendCodeForPlayer(PLAYER_A);
    assert.equal(again, record.friendCode);

    await setPersistentTableCode(PLAYER_A, "ABCDE");
    await flushFriendsStoreWritesForTests();
    assert.ok(await fs.stat(backupPath));
    assert.equal(await getPersistentTableCode(PLAYER_A), "ABCDE");
  });

  it("adds and removes friends by code", async () => {
    const codeB = await getFriendCodeForPlayer(PLAYER_B);
    assert.ok(codeB);

    const add = await addFriendByCode(PLAYER_A, codeB);
    assert.equal(add.ok, true);
    const ids = await listFriendPlayerIds(PLAYER_A);
    assert.deepEqual(ids, [PLAYER_B]);

    const remove = await removeFriendByCode(PLAYER_A, codeB);
    assert.equal(remove.ok, true);
    assert.deepEqual(await listFriendPlayerIds(PLAYER_A), []);
    assert.deepEqual(await listFriendPlayerIds(PLAYER_B), []);
  });
});
