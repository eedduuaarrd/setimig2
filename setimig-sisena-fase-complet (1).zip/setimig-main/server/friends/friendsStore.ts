import fs from "fs/promises";
import path from "path";
import { sanitizePlayerId } from "../balances.ts";
import { generateInviteCode, normalizeInviteCode } from "../privateRooms.ts";

export type PlayerFriendsRecord = {
  friendCode: string;
  friendPlayerIds: string[];
  persistentTableCode?: string | null;
};

type FriendsStoreFile = {
  players: Record<string, PlayerFriendsRecord>;
  friendCodeIndex: Record<string, string>;
};

let cache: FriendsStoreFile | null = null;
let writeChain: Promise<void> = Promise.resolve();

function dataDir(): string {
  return process.env.FRIENDS_DATA_DIR || process.env.BALANCE_DATA_DIR || path.join(process.cwd(), "data");
}

function storePath(): string {
  return path.join(dataDir(), "friends.json");
}

function backupPath(): string {
  return path.join(dataDir(), "friends.json.bak");
}

function emptyStore(): FriendsStoreFile {
  return { players: {}, friendCodeIndex: {} };
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}

function generateFriendCode(existing: Set<string>): string {
  for (let i = 0; i < 50; i++) {
    const code = `F${generateInviteCode(6)}`;
    if (!existing.has(code)) return code;
  }
  return `F${generateInviteCode(6)}${Math.random().toString(36).slice(2, 4).toUpperCase()}`;
}

function normalizeFriendCode(raw: unknown): string | null {
  if (typeof raw !== "string") return null;
  const code = raw.trim().toUpperCase();
  if (!/^F[A-Z0-9]{4,10}$/.test(code)) return null;
  return code;
}

async function loadStore(): Promise<FriendsStoreFile> {
  if (cache) return cache;

  let raw: string;
  try {
    raw = await fs.readFile(storePath(), "utf8");
  } catch (error) {
    if (error instanceof Error && "code" in error && error.code === "ENOENT") {
      cache = emptyStore();
      return cache;
    }
    throw error;
  }

  const parsed: unknown = JSON.parse(raw);
  if (!isRecord(parsed)) {
    throw new Error("Invalid friends store format");
  }
  const players = isRecord(parsed.players) ? (parsed.players as FriendsStoreFile["players"]) : {};
  const friendCodeIndex = isRecord(parsed.friendCodeIndex)
    ? (parsed.friendCodeIndex as FriendsStoreFile["friendCodeIndex"])
    : {};
  cache = { players, friendCodeIndex };
  return cache;
}

async function persistStore(store: FriendsStoreFile): Promise<void> {
  cache = store;
  const p = storePath();
  await fs.mkdir(dataDir(), { recursive: true });
  try {
    await fs.copyFile(p, backupPath());
  } catch (error) {
    if (!(error instanceof Error && "code" in error && error.code === "ENOENT")) {
      throw error;
    }
  }
  const tmp = `${p}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(store, null, 2), "utf8");
  await fs.rename(tmp, p);
}

function enqueueWrite<T>(task: (store: FriendsStoreFile) => T | Promise<T>): Promise<T> {
  let result!: T;
  writeChain = writeChain.then(async () => {
    const store = await loadStore();
    result = await task(store);
    await persistStore(store);
  });
  return writeChain.then(() => result);
}

/**
 * Esborrat de compte: el registre propi, els seus codis i la seva presència a les llistes
 * d'amics dels altres (la resta de cada llista queda igual).
 */
export async function deleteFriendsForPlayer(playerId: string): Promise<{ own: boolean; codes: number; refs: number }> {
  let out = { own: false, codes: 0, refs: 0 };
  writeChain = writeChain.then(async () => {
    const store = await loadStore();
    const own = playerId in store.players;
    delete store.players[playerId];
    let codes = 0;
    for (const [code, pid] of Object.entries(store.friendCodeIndex)) {
      if (pid === playerId) {
        delete store.friendCodeIndex[code];
        codes += 1;
      }
    }
    let refs = 0;
    for (const rec of Object.values(store.players)) {
      const list = (rec as { friendPlayerIds?: unknown }).friendPlayerIds;
      if (Array.isArray(list) && list.includes(playerId)) {
        (rec as { friendPlayerIds: string[] }).friendPlayerIds = list.filter((f) => f !== playerId);
        refs += 1;
      }
    }
    out = { own, codes, refs };
    // Idempotent: si no hi havia res, no s'escriu.
    if (!own && !codes && !refs) return;
    await persistStore(store);
    // La còpia .bak tenia les dades d'abans: es substitueix per l'estat ja esborrat.
    await fs.copyFile(storePath(), backupPath());
  });
  await writeChain;
  return out;
}

export function resetFriendsStoreCacheForTests(): void {
  cache = null;
  writeChain = Promise.resolve();
}

export async function flushFriendsStoreWritesForTests(): Promise<void> {
  await writeChain;
}

export async function getOrCreatePlayerFriendsRecord(playerIdRaw: string): Promise<PlayerFriendsRecord> {
  const playerId = sanitizePlayerId(playerIdRaw);
  if (!playerId) throw new Error("Invalid player id");

  return enqueueWrite((store) => {
    const existing = store.players[playerId];
    if (existing) return existing;

    const used = new Set(Object.keys(store.friendCodeIndex));
    const friendCode = generateFriendCode(used);
    const record: PlayerFriendsRecord = {
      friendCode,
      friendPlayerIds: [],
      persistentTableCode: null,
    };
    store.players[playerId] = record;
    store.friendCodeIndex[friendCode] = playerId;
    return record;
  });
}

export async function getFriendCodeForPlayer(playerIdRaw: string): Promise<string | null> {
  const playerId = sanitizePlayerId(playerIdRaw);
  if (!playerId) return null;
  const record = await getOrCreatePlayerFriendsRecord(playerId);
  return record.friendCode;
}

export async function resolvePlayerIdByFriendCode(codeRaw: unknown): Promise<string | null> {
  const code = normalizeFriendCode(codeRaw);
  if (!code) return null;
  const store = await loadStore();
  const playerId = store.friendCodeIndex[code];
  return sanitizePlayerId(playerId);
}

export async function listFriendPlayerIds(playerIdRaw: string): Promise<string[]> {
  const playerId = sanitizePlayerId(playerIdRaw);
  if (!playerId) return [];
  const record = await getOrCreatePlayerFriendsRecord(playerId);
  return [...record.friendPlayerIds];
}

export async function addFriendByCode(
  playerIdRaw: string,
  friendCodeRaw: unknown,
): Promise<{ ok: true } | { ok: false; code: string }> {
  const playerId = sanitizePlayerId(playerIdRaw);
  if (!playerId) return { ok: false, code: "BAD_PLAYER" };
  const targetId = await resolvePlayerIdByFriendCode(friendCodeRaw);
  if (!targetId) return { ok: false, code: "FRIEND_NOT_FOUND" };
  if (targetId === playerId) return { ok: false, code: "SELF_FRIEND" };

  await enqueueWrite((store) => {
    const me = store.players[playerId] ?? {
      friendCode: generateFriendCode(new Set(Object.keys(store.friendCodeIndex))),
      friendPlayerIds: [],
    };
    if (!store.players[playerId]) {
      store.players[playerId] = me;
      store.friendCodeIndex[me.friendCode] = playerId;
    }
    if (!me.friendPlayerIds.includes(targetId)) {
      me.friendPlayerIds.push(targetId);
    }
    const them = store.players[targetId];
    if (them && !them.friendPlayerIds.includes(playerId)) {
      them.friendPlayerIds.push(playerId);
    }
  });
  return { ok: true };
}

export async function removeFriendByCode(
  playerIdRaw: string,
  friendCodeRaw: unknown,
): Promise<{ ok: true } | { ok: false; code: string }> {
  const playerId = sanitizePlayerId(playerIdRaw);
  if (!playerId) return { ok: false, code: "BAD_PLAYER" };
  const targetId = await resolvePlayerIdByFriendCode(friendCodeRaw);
  if (!targetId) return { ok: false, code: "FRIEND_NOT_FOUND" };

  await enqueueWrite((store) => {
    const me = store.players[playerId];
    if (!me) return;
    me.friendPlayerIds = me.friendPlayerIds.filter((id) => id !== targetId);
    const them = store.players[targetId];
    if (them) {
      them.friendPlayerIds = them.friendPlayerIds.filter((id) => id !== playerId);
    }
  });
  return { ok: true };
}

export async function getPersistentTableCode(playerIdRaw: string): Promise<string | null> {
  const playerId = sanitizePlayerId(playerIdRaw);
  if (!playerId) return null;
  const record = await getOrCreatePlayerFriendsRecord(playerId);
  const code = record.persistentTableCode;
  if (!code) return null;
  return normalizeInviteCode(code);
}

export async function setPersistentTableCode(
  playerIdRaw: string,
  codeRaw: unknown,
): Promise<{ ok: true; code: string | null } | { ok: false; code: string }> {
  const playerId = sanitizePlayerId(playerIdRaw);
  if (!playerId) return { ok: false, code: "BAD_PLAYER" };
  let next: string | null = null;
  if (codeRaw !== null && codeRaw !== undefined && codeRaw !== "") {
    next = normalizeInviteCode(codeRaw);
    if (!next) return { ok: false, code: "BAD_TABLE_CODE" };
  }

  await enqueueWrite(async (store) => {
    const record = store.players[playerId] ?? {
      friendCode: generateFriendCode(new Set(Object.keys(store.friendCodeIndex))),
      friendPlayerIds: [],
    };
    if (!store.players[playerId]) {
      store.players[playerId] = record;
      store.friendCodeIndex[record.friendCode] = playerId;
    }
    record.persistentTableCode = next;
  });
  return { ok: true, code: next };
}

export { normalizeFriendCode };
