import type { Request, Response } from "express";
import { resolvePlayerFromRequest, sendPlayerResponse } from "../httpPlayerAuth.ts";
import { getProfile } from "../profiles.ts";
import {
  addFriendByCode,
  getFriendCodeForPlayer,
  getPersistentTableCode,
  listFriendPlayerIds,
  normalizeFriendCode,
  removeFriendByCode,
  setPersistentTableCode,
} from "./friendsStore.ts";

export async function handleGetFriends(req: Request, res: Response): Promise<void> {
  const resolved = resolvePlayerFromRequest(req);
  if (!resolved) {
    res.status(400).json({ error: "Identitat de jugador invalida." });
    return;
  }
  const ids = await listFriendPlayerIds(resolved.playerId);
  const friends = [];
  for (const id of ids) {
    const code = await getFriendCodeForPlayer(id);
    const profile = await getProfile(id);
    friends.push({
      code,
      displayName: profile?.displayName ?? "Jugador",
    });
  }
  sendPlayerResponse(res, { friends });
}

export async function handlePostFriends(req: Request, res: Response): Promise<void> {
  const resolved = resolvePlayerFromRequest(req);
  if (!resolved) {
    res.status(400).json({ error: "Identitat de jugador invalida." });
    return;
  }
  const body = req.body;
  if (body?.persistentTableCode !== undefined) {
    const result = await setPersistentTableCode(resolved.playerId, body.persistentTableCode);
    if (result.ok === false) {
      res.status(400).json({ error: "Codi de taula invalid.", code: result.code });
      return;
    }
    sendPlayerResponse(res, { persistentTableCode: result.code });
    return;
  }

  const code = body?.code ?? body?.friendCode;
  const result = await addFriendByCode(resolved.playerId, code);
  if (result.ok === false) {
    const status = result.code === "FRIEND_NOT_FOUND" ? 404 : 400;
    const message =
      result.code === "SELF_FRIEND"
        ? "No pots afegir-te com amic."
        : result.code === "FRIEND_NOT_FOUND"
          ? "Codi d'amic no trobat."
          : "Codi d'amic invalid.";
    res.status(status).json({ error: message, code: result.code });
    return;
  }
  sendPlayerResponse(res, { ok: true });
}

export async function handleDeleteFriend(req: Request, res: Response): Promise<void> {
  const resolved = resolvePlayerFromRequest(req);
  if (!resolved) {
    res.status(400).json({ error: "Identitat de jugador invalida." });
    return;
  }
  const code = normalizeFriendCode(req.params.code);
  if (!code) {
    res.status(400).json({ error: "Codi d'amic invalid." });
    return;
  }
  const result = await removeFriendByCode(resolved.playerId, code);
  if (result.ok === false) {
    res.status(404).json({ error: "Codi d'amic no trobat.", code: result.code });
    return;
  }
  sendPlayerResponse(res, { ok: true });
}

export async function handleGetFriendCode(req: Request, res: Response): Promise<void> {
  const resolved = resolvePlayerFromRequest(req);
  if (!resolved) {
    res.status(400).json({ error: "Identitat de jugador invalida." });
    return;
  }
  const code = await getFriendCodeForPlayer(resolved.playerId);
  const persistentTableCode = await getPersistentTableCode(resolved.playerId);
  sendPlayerResponse(res, { code, persistentTableCode });
}

export async function resolveInviteCodeForHost(
  playerId: string,
  allocate: () => string,
  isCodeTaken: (code: string) => boolean,
): Promise<string> {
  const persistent = await getPersistentTableCode(playerId);
  if (persistent && !isCodeTaken(persistent)) {
    return persistent;
  }
  return allocate();
}
