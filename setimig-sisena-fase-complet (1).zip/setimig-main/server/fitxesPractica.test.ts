import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import fs from "fs/promises";
import path from "path";
import { createServer } from "http";
import { Server } from "socket.io";
import { io as ioClient } from "socket.io-client";
import { getBalance, resetBalanceStoreCacheForTests, setBalance } from "./balances.ts";
import { flushAllPendingWrites, getWriteCounts, resetWriteCounts } from "./writeCoalescing.ts";
import { getRoomSnapshotForTests, resetGameStateForTests, setupGameHandlers } from "./game.ts";
import {
  applyPlaceBet,
  beginBettingPhase,
  currentPlayer,
  emptyRoomBase,
  type GameHost,
  type Player,
  type Room,
} from "../shared/gameEngine.ts";
import { PHASE_B_START_CHIPS } from "../shared/matchPhaseB.ts";

const DATA_ROOT = path.join(process.cwd(), "data", `fitxes-practica-test-${Date.now()}`);

function seat(id: string, extra: Partial<Player> = {}): Player {
  return {
    id,
    playerId: id,
    seatToken: id,
    name: id,
    chips: 2_000,
    bet: 0,
    isBanker: false,
    status: "waiting",
    handSlots: [],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
    ...extra,
  };
}

describe("mode pràctica: fitxes de pràctica separades del saldo real (S-P2-1)", () => {
  before(() => {
    process.env.BALANCE_DATA_DIR = DATA_ROOT;
    process.env.SETIMIG_TEST_FAST = "1";
    resetBalanceStoreCacheForTests();
  });

  after(async () => {
    resetGameStateForTests();
    await fs.rm(DATA_ROOT, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 }).catch(() => undefined);
    delete process.env.BALANCE_DATA_DIR;
  });

  it("una partida de pràctica amb apostes i liquidació no llegeix ni escriu el saldo real", async () => {
    const playerId = "practicechips0001";
    await setBalance(playerId, 12_345);
    await flushAllPendingWrites();
    resetWriteCounts();

    resetGameStateForTests();
    const httpServer = createServer();
    const io = new Server(httpServer);
    await setupGameHandlers(io);
    await new Promise<void>((resolve) => httpServer.listen(0, resolve));
    const port = (httpServer.address() as { port: number }).port;
    const socket = ioClient(`http://127.0.0.1:${port}`, { transports: ["websocket"] });
    await new Promise<void>((resolve) => socket.on("connect", () => resolve()));

    try {
      const roomId = await new Promise<string>((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("timeout join")), 8000);
        socket.once("joined_room", (payload: { id: string }) => {
          clearTimeout(timer);
          resolve(payload.id);
        });
        socket.emit("join_solo_room", {
          playerName: "Practica",
          playerId,
          botCount: 1,
          botDifficulty: "easy",
          practiceMode: true,
        });
      });

      // Simulem un canvi real del saldo mentre es juga (p. ex. fitxes gratis en una altra pestanya).
      await setBalance(playerId, 5_000);
      await flushAllPendingWrites();
      resetWriteCounts();

      let sawHumanBet = 0;
      let sawPracticeStart = 0;
      await new Promise<void>((resolve, reject) => {
        const deadline = Date.now() + 15_000;
        let betSent = "";
        const tick = () => {
          const snap = getRoomSnapshotForTests(roomId);
          const human = snap?.players.find((p) => !p.isBot);
          if (snap && human) {
            assert.equal(snap.practiceMode, true);
            assert.ok(human.chips >= 0, "les fitxes de pràctica no poden ser negatives");
            if (!sawPracticeStart && snap.phase === "betting") sawPracticeStart = human.chips + human.bet;
            if (snap.phase === "betting" && !human.isBanker && human.bet === 0) {
              const key = `${snap.phaseB?.handsCompleted ?? 0}`;
              if (betSent !== key) {
                betSent = key;
                socket.emit("place_bet", { roomId, amount: snap.minBet });
              }
            }
            if (human.bet > 0) sawHumanBet = Math.max(sawHumanBet, human.bet);
            if (snap.phase === "playing" && currentPlayer(snap)?.id === human.id) {
              socket.emit("stand", roomId);
            }
            if (sawHumanBet > 0 && snap.lastRound?.results?.some((r) => r.name === human.name)) {
              resolve();
              return;
            }
          }
          if (Date.now() > deadline) {
            reject(new Error(`no s'ha liquidat cap mà de pràctica (fase ${snap?.phase})`));
            return;
          }
          setTimeout(tick, 25);
        };
        tick();
      });

      assert.ok(sawHumanBet > 0, "en pràctica el jugador aposta (amb fitxes de pràctica)");
      assert.equal(sawPracticeStart, PHASE_B_START_CHIPS, "les fitxes de pràctica comencen a una quantitat fixa");
      const snap = getRoomSnapshotForTests(roomId)!;
      assert.equal(snap.soloRealBalances?.has(playerId) ?? false, false, "no es llegeix el saldo real");

      socket.emit("leave_room", roomId);
      await new Promise((r) => setTimeout(r, 300));
      await flushAllPendingWrites();
      assert.equal(getWriteCounts()["balances.json"] ?? 0, 0, "cap escriptura a balances.json");
      resetBalanceStoreCacheForTests();
      assert.equal(await getBalance(playerId), 5_000, "el saldo real no canvia (ni es restaura una còpia antiga)");
    } finally {
      socket.disconnect();
      io.close();
      await new Promise<void>((r) => httpServer.close(() => r()));
    }
  });

  it("en pràctica no s'aposta sol pel jugador i no pot apostar més del que té", () => {
    const scheduled: number[] = [];
    const host: GameHost = {
      emitRoomUpdate() {},
      schedule: (_fn, ms) => {
        scheduled.push(ms);
        return scheduled.length as unknown as ReturnType<typeof setTimeout>;
      },
      clearTimeout() {},
    };
    const room: Room = emptyRoomBase("practice-bets", "Pràctica", 100, 0);
    room.practiceMode = true;
    room.soloAi = true;
    const human = seat("human");
    room.players = [human, seat("bot-a", { isBot: true, isBanker: true, chips: 50_000 })];
    beginBettingPhase(host, room);
    assert.equal(room.phase, "betting");
    assert.equal(human.bet, 0, "l'aposta la tria el jugador");
    assert.equal(room.bettingDeadlineAt, null);
    assert.equal(room.turnDeadlineAt, null);
    applyPlaceBet(room, human, human.chips + 100);
    assert.ok(human.chips >= 0, "les fitxes de pràctica no poden quedar negatives");
    assert.ok(human.bet <= 2_000, "no es pot apostar més del que es té");
    assert.equal(human.chips + human.bet, 2_000);
  });
});
