import { describe, it, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";
import fs from "fs/promises";
import os from "os";
import path from "path";
import { createServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket } from "socket.io-client";
import { resetGameStateForTests, setupGameHandlers } from "./game.ts";
import { issuePlayerToken } from "./playerToken.ts";
import { resetPrivateRoomStoreCacheForTests } from "./privateRoomStore.ts";

const HOST_ID = "uniqnamehost000001";
const GUEST_A = "uniqnameguesta0001";
const GUEST_B = "uniqnameguestb0001";

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";

function connect(url: string): Promise<Socket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.on("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.on("connect_error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

function waitJoined(socket: Socket): Promise<{ inviteCode?: string; players?: { name: string }[] }> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("join timeout")), 15_000);
    socket.once("joined_room", (room) => {
      clearTimeout(timer);
      resolve(room);
    });
  });
}

async function startServer() {
  const http = createServer();
  const io = new SocketIOServer(http, { cors: { origin: "*" } });
  await setupGameHandlers(io);
  await new Promise<void>((r) => http.listen(0, "127.0.0.1", () => r()));
  const port = (http.address() as { port: number }).port;
  return { url: `http://127.0.0.1:${port}`, http, io };
}

describe("unique player names in private rooms", () => {
  let dataDir: string;

  beforeEach(async () => {
    dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "setimig-uniq-names-"));
    process.env.BALANCE_DATA_DIR = dataDir;
    resetGameStateForTests();
    resetPrivateRoomStoreCacheForTests();
  });

  afterEach(async () => {
    resetGameStateForTests();
    await fs.rm(dataDir, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 });
  });

  it("suffixes the second human with the same requested name", async () => {
    const hostToken = issuePlayerToken(HOST_ID)!;
    const guestAToken = issuePlayerToken(GUEST_A)!;
    const guestBToken = issuePlayerToken(GUEST_B)!;
    const { url, http, io } = await startServer();

    const host = await connect(url);
    host.emit("create_private_table", {
      playerName: "Anna",
      playerId: HOST_ID,
      playerToken: hostToken,
    });
    const hostRoom = await waitJoined(host);

    const guestA = await connect(url);
    guestA.emit("join_private_table", {
      inviteCode: hostRoom.inviteCode,
      playerName: "Anna",
      playerId: GUEST_A,
      playerToken: guestAToken,
    });
    const joinedA = await waitJoined(guestA);
    const guestB = await connect(url);
    guestB.emit("join_private_table", {
      inviteCode: hostRoom.inviteCode,
      playerName: "Anna",
      playerId: GUEST_B,
      playerToken: guestBToken,
    });
    const joinedB = await waitJoined(guestB);

    const names = joinedB.players?.map((p) => p.name).sort();
    assert.deepEqual(names, ["Anna", "Anna 2", "Anna 3"]);

    host.disconnect();
    guestA.disconnect();
    guestB.disconnect();
    io.close();
    await new Promise<void>((r) => http.close(() => r()));
  });
});
