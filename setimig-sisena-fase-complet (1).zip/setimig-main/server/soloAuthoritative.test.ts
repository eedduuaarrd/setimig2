import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { flushBalanceWrites, getBalance, resetBalanceStoreCacheForTests, setBalance } from "./balances.ts";
import { getRoomSnapshotForTests, resetGameStateForTests } from "./game.ts";
import { issuePlayerToken } from "./playerToken.ts";
import {
  actAuthoritativeSolo,
  closeAuthoritativeSolo,
  flushSoloIsolatedSessionWritesForTests,
  markSoloIsolatedSessionActive,
  markSoloIsolatedSessionLost,
  openAuthoritativeSolo,
  readAuthoritativeSoloView,
  resumeAuthoritativeSolo,
  soloClientJson,
} from "./soloIsolatedSessions.ts";
import type { Card } from "../src/gameTypes.ts";
import type { HandSlot, Player } from "../shared/gameEngine.ts";

const DATA = path.join(os.tmpdir(), `setimig-solo-auth-${process.pid}`);

function tokenFor(playerId: string): string {
  const token = issuePlayerToken(playerId);
  assert.ok(token);
  return token;
}

function slot(id: string, card: Card & { leakMark?: string }, faceUp: boolean): HandSlot {
  return {
    id,
    bet: 0,
    doubled: false,
    canDouble: false,
    mort: false,
    blindPair: false,
    blindUntilBankEnd: false,
    mortOffered: false,
    status: "playing",
    cards: [{ id: `${id}-card`, card, faceUp }],
  };
}

describe("solo autoritativa al servidor", () => {
  before(() => {
    process.env.BALANCE_DATA_DIR = DATA;
    process.env.SETIMIG_TEST_FAST = "1";
    delete process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD;
    resetBalanceStoreCacheForTests();
    resetGameStateForTests();
  });

  after(async () => {
    resetGameStateForTests();
    await flushBalanceWrites();
    await flushSoloIsolatedSessionWritesForTests();
    await fs.rm(DATA, { recursive: true, force: true });
    delete process.env.BALANCE_DATA_DIR;
    delete process.env.SETIMIG_TEST_FAST;
  });

  it("la vista enviada al client no conté les cartes tapades de bots ni de banca, ni el mazo", async () => {
    const playerId = "soloViewRedact01";
    const token = tokenFor(playerId);
    const opened = await openAuthoritativeSolo(playerId, "Vista", token, {
      botCount: 1,
      botDifficulty: "easy",
      practiceMode: true,
      houseRulesEnabled: true,
      intent: "new",
    });
    assert.equal(opened.error, null);
    assert.ok(opened.view);
    assert.equal(opened.view.houseRulesEnabled, true);
    assert.equal(opened.view.practiceMode, true);
    assert.equal(JSON.stringify(soloClientJson(opened.view)).includes('"deck"'), false);

    const room = getRoomSnapshotForTests(`solo-${playerId}`);
    assert.ok(room);
    room.phase = "playing";
    const secretBot = { suit: "clubs" as const, value: 9, points: 9, leakMark: "SOLO_SECRET_BOT" };
    const secretBank = { suit: "diamonds" as const, value: 6, points: 6, leakMark: "SOLO_SECRET_BANK" };
    const bot = room.players.find((p) => p.isBot);
    assert.ok(bot);
    bot.isBanker = false;
    bot.handSlots = [slot("bot-slot", secretBot, false)];
    const banker: Player = {
      ...bot,
      id: "bank-secret",
      playerId: "bot-bank-secret",
      seatToken: "bank-secret-seat",
      name: "Banca",
      isBot: true,
      isBanker: true,
      handSlots: [slot("bank-slot", secretBank, true)],
    };
    room.players.push(banker);
    room.deck.unshift({ suit: "swords", value: 1, points: 1, leakMark: "SOLO_SECRET_DECK" } as unknown as Card);

    const wire = JSON.stringify(soloClientJson(readAuthoritativeSoloView(playerId)!));
    assert.equal(wire.includes("SOLO_SECRET_BOT"), false);
    assert.equal(wire.includes("SOLO_SECRET_BANK"), false);
    assert.equal(wire.includes("SOLO_SECRET_DECK"), false);
    assert.equal(wire.includes('"deck"'), false);
    const parsed = JSON.parse(wire) as { players: { isBot?: boolean; isBanker?: boolean; handSlots: { cards: { card: unknown }[] }[] }[] };
    for (const player of parsed.players) {
      if (!player.isBot && !player.isBanker) continue;
      for (const hand of player.handSlots) {
        for (const card of hand.cards) assert.equal(card.card, null);
      }
    }
    assert.equal(getRoomSnapshotForTests(`solo-${playerId}`)?.botDifficulty, "easy");
    room.deck = room.deck.filter((card) => !("leakMark" in card));

    const acted = await actAuthoritativeSolo(playerId, "hit", {}, { playerToken: token, actionSeq: 1 });
    const actedWire = JSON.stringify(acted.view ? soloClientJson(acted.view) : {});
    assert.equal(actedWire.includes("SOLO_SECRET_BOT"), false);
    assert.equal(actedWire.includes("SOLO_SECRET_BANK"), false);
    assert.equal(actedWire.includes("SOLO_SECRET_DECK"), false);
    assert.equal(actedWire.includes('"deck"'), false);

    const replay = await actAuthoritativeSolo(playerId, "stand", {}, { playerToken: token, actionSeq: 1 });
    assert.equal(replay.error?.code, "REPLAY");
    const other = tokenFor("soloOtherPlayer1");
    const denied = await actAuthoritativeSolo(playerId, "stand", {}, { playerToken: other, actionSeq: 2 });
    assert.equal(denied.error?.code, "BAD_TOKEN");
    const deniedWire = JSON.stringify(denied.view ? soloClientJson(denied.view) : {});
    assert.equal(deniedWire.includes("SOLO_SECRET"), false);

    await closeAuthoritativeSolo(playerId);
  });

  it("la pràctica no toca el saldo, desa només el mode i es pot refer", async () => {
    const playerId = "soloPractice0001";
    await setBalance(playerId, 4321);
    const token = tokenFor(playerId);
    const opened = await openAuthoritativeSolo(playerId, "Practica", token, {
      botCount: 2,
      botDifficulty: "normal",
      practiceMode: true,
      houseRulesEnabled: true,
      intent: "new",
    });
    assert.equal(opened.error, null);
    assert.equal(opened.view?.practiceMode, true);
    assert.equal(await getBalance(playerId), 4321);
    await flushSoloIsolatedSessionWritesForTests();
    const raw = await fs.readFile(path.join(DATA, "solo-isolated-sessions.json"), "utf8");
    const parsed = JSON.parse(raw) as { sessions: Record<string, { mode: string; houseRulesEnabled?: boolean }> };
    assert.equal(parsed.sessions[playerId]?.mode, "practice");
    assert.equal(parsed.sessions[playerId]?.houseRulesEnabled, true);
    assert.equal(raw.includes("SOLO_SECRET"), false);
    assert.equal(raw.includes('"deck"'), false);

    await closeAuthoritativeSolo(playerId);
    assert.equal(await getBalance(playerId), 4321);
    markSoloIsolatedSessionActive(playerId, {
      mode: "practice",
      botCount: 2,
      botDifficulty: "normal",
      houseRulesEnabled: true,
    });
    markSoloIsolatedSessionLost(playerId);
    const resumed = await resumeAuthoritativeSolo(playerId, "Practica", token);
    assert.equal(resumed?.error, null);
    assert.equal(resumed?.view?.practiceMode, true);
    assert.equal(await getBalance(playerId), 4321);
    const resumedWire = JSON.stringify(resumed?.view ? soloClientJson(resumed.view) : {});
    assert.equal(resumedWire.includes('"deck"'), false);
    await closeAuthoritativeSolo(playerId);
  });

  it("la solo normal obre i tanca la compra al mateix balances.json", async () => {
    const playerId = "soloBuyIn000001";
    await setBalance(playerId, 5000);
    const token = tokenFor(playerId);
    const opened = await openAuthoritativeSolo(playerId, "Saldo", token, {
      botCount: 1,
      botDifficulty: "easy",
      intent: "new",
    });
    assert.equal(opened.error, null);
    assert.equal(opened.view?.practiceMode, false);
    await flushBalanceWrites();
    const mid = JSON.parse(await fs.readFile(path.join(DATA, "balances.json"), "utf8")) as {
      accounts: Record<string, { chips: number }>;
      processedSessions: unknown[];
      openSoloBuyIns?: Record<string, { playerId: string; amount: number; roomId: string }>;
    };
    assert.equal(typeof mid.accounts[playerId]?.chips, "number");
    assert.ok(mid.accounts[playerId]!.chips < 5000);
    assert.ok(Array.isArray(mid.processedSessions));
    const open = Object.values(mid.openSoloBuyIns ?? {});
    assert.equal(open.some((entry) => entry.playerId === playerId && entry.roomId === `solo-${playerId}`), true);

    const left = await closeAuthoritativeSolo(playerId, opened.view?.viewerSeatToken);
    assert.equal(left, true);
    await flushBalanceWrites();
    const after = JSON.parse(await fs.readFile(path.join(DATA, "balances.json"), "utf8")) as {
      accounts: Record<string, { chips: number }>;
      openSoloBuyIns?: Record<string, unknown>;
    };
    assert.equal(Object.keys(after.openSoloBuyIns ?? {}).length, 0);
    assert.equal(after.accounts[playerId]?.chips, 5000);
  });

  it("reprendre sense sala ni marca no cobra cap compra", async () => {
    const playerId = "soloNoResume0001";
    await setBalance(playerId, 5000);
    const resumed = await resumeAuthoritativeSolo(playerId, "Ningú", tokenFor(playerId));
    assert.equal(resumed, null);
    assert.equal(await getBalance(playerId), 5000);
    assert.equal(readAuthoritativeSoloView(playerId), null);
  });
});
