import type { Player } from "../shared/gameEngine.ts";
import { defaultAvatarConfig } from "../shared/playerAvatar.ts";
import { getProfile, resolvedAvatarForProfile } from "./profiles.ts";

export async function avatarConfigForPlayer(playerId: string, displayName: string) {
  const profile = await getProfile(playerId);
  if (!profile) return defaultAvatarConfig(displayName, playerId);
  return resolvedAvatarForProfile(profile, playerId);
}

export async function assignPlayerAvatar(player: Player): Promise<void> {
  if (player.isBot) {
    player.avatar = defaultAvatarConfig(player.name, player.playerId);
    return;
  }
  player.avatar = await avatarConfigForPlayer(player.playerId, player.name);
}
