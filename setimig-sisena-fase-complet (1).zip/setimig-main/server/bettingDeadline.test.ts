import { describe, it, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";
import fs from "fs/promises";
import os from "os";
import path from "path";
import { createServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket } from "socket.io-client";
import { getRoomSnapshotForTests, resetGameStateForTests, setupGameHandlers } from "./game.ts";
import { issuePlayerToken } from "./playerToken.ts";
import { resetPrivateRoomStoreCacheForTests } from "./privateRoomStore.ts";
import { removeTestDataDir } from "./testing/testDataDir.ts";

const HOST_ID = "betdeadlinehost0001";
const GUEST_ID = "betdeadlineguest001";

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";

function connect(url: string): Promise<Socket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.on("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.on("connect_error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

function waitJoined(socket: Socket): Promise<{ id: string; inviteCode?: string }> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("join timeout")), 15_000);
    socket.once("joined_room", (room) => {
      clearTimeout(timer);
      resolve(room);
    });
  });
}

async function startServer() {
  const http = createServer();
  const io = new SocketIOServer(http, { cors: { origin: "*" } });
  await setupGameHandlers(io);
  await new Promise<void>((r) => http.listen(0, "127.0.0.1", () => r()));
  const port = (http.address() as { port: number }).port;
  return { url: `http://127.0.0.1:${port}`, http, io };
}

describe("betting deadline (private table)", () => {
  let dataDir: string;

  beforeEach(async () => {
    dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "setimig-bet-deadline-"));
    process.env.BALANCE_DATA_DIR = dataDir;
    process.env.SETIMIG_TEST_FAST = "1";
    resetGameStateForTests();
    resetPrivateRoomStoreCacheForTests();
  });

  afterEach(async () => {
    delete process.env.SETIMIG_TEST_FAST;
    // Atura els temporitzadors del joc i buida totes les escriptures abans d'esborrar (abans: ENOENT).
    await removeTestDataDir(dataDir);
  });

  it("inactive human is auto-bet and the hand advances without stalling", async () => {
    const hostToken = issuePlayerToken(HOST_ID)!;
    const guestToken = issuePlayerToken(GUEST_ID)!;
    const { url, http, io } = await startServer();

    const host = await connect(url);
    host.emit("create_private_table", {
      playerName: "Host",
      playerId: HOST_ID,
      playerToken: hostToken,
    });
    const hostRoom = await waitJoined(host);

    const guest = await connect(url);
    guest.emit("join_private_table", {
      inviteCode: hostRoom.inviteCode,
      playerName: "Guest",
      playerId: GUEST_ID,
      playerToken: guestToken,
    });
    await waitJoined(guest);

    let actionSeq = 1;
    host.emit("start_game", {
      roomId: hostRoom.id,
      playerToken: hostToken,
      actionSeq: actionSeq++,
    });

    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("betting timeout")), 10_000);
      const onBetting = (room: { phase: string }) => {
        if (room.phase === "betting") {
          clearTimeout(timer);
          host.off("room_update", onBetting);
          guest.off("room_update", onBetting);
          resolve();
        }
      };
      host.on("room_update", onBetting);
      guest.on("room_update", onBetting);
    });

    let pinnedDeadline: number | null = null;
    host.on("room_update", (room: { phase: string; turnDeadlineAt?: number | null }) => {
      if (room.phase === "betting" && room.turnDeadlineAt) {
        if (pinnedDeadline === null) pinnedDeadline = room.turnDeadlineAt;
        else assert.equal(room.turnDeadlineAt, pinnedDeadline);
      }
    });

    host.emit("place_bet", {
      roomId: hostRoom.id,
      amount: 100,
      playerToken: hostToken,
      actionSeq: actionSeq++,
    });

    await new Promise<void>((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error("hand did not advance")), 5_000);
      const onUpdate = (room: { phase: string }) => {
        if (room.phase === "playing") {
          clearTimeout(timer);
          host.off("room_update", onUpdate);
          resolve();
        }
      };
      host.on("room_update", onUpdate);
    });

    const snap = getRoomSnapshotForTests(hostRoom.id);
    assert.ok(snap);
    assert.equal(snap!.phase, "playing");
    const guestSeat = snap!.players.find((p) => p.playerId === GUEST_ID);
    const hostSeat = snap!.players.find((p) => p.playerId === HOST_ID);
    if (guestSeat?.isBanker) {
      assert.ok((hostSeat?.bet ?? 0) >= 100);
    } else {
      assert.ok((guestSeat?.bet ?? 0) >= 100);
    }

    host.disconnect();
    guest.disconnect();
    io.close();
    await new Promise<void>((r) => http.close(() => r()));
  });
});
