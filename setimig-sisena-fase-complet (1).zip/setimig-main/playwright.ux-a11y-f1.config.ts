import { defineConfig, devices } from "@playwright/test";
import { catalanStorageState } from "./e2e/catalanLocale";
import { e2eServerEnv } from "./e2e/helpers/e2eServerEnv";

// Playwright accepts either webServer.port or webServer.url, not both.
const port = Number(process.env.E2E_PORT || process.env.PORT || 3000);
const baseURL = `http://127.0.0.1:${port}`;

export default defineConfig({
  testDir: "./e2e",
  testMatch: "ux-a11y-f1.spec.ts",
  timeout: 180_000,
  retries: 0,
  projects: [{ name: "chromium", use: { ...devices["Desktop Chrome"], browserName: "chromium" } }],
  use: {
    locale: "ca-ES",
    storageState: catalanStorageState(),
    baseURL,
  },
  globalTeardown: "./e2e/helpers/e2eGlobalTeardown.ts",
  webServer: {
    command: `cross-env PORT=${port} npm run dev`,
    env: e2eServerEnv({ PORT: String(port) }),
    url: baseURL,
    reuseExistingServer: false,
    timeout: 180_000,
  },
});
