import { defineConfig } from "@playwright/test";
import { catalanStorageState } from "./e2e/catalanLocale";
const port = Number(process.env.SETIMIG_E2E_PORT ?? 3196);
const appUrl = `http://127.0.0.1:${port}`;
export default defineConfig({testDir:"./e2e",testMatch:"fase6.spec.ts",timeout:120_000,
 use:{baseURL:appUrl,locale:"ca-ES",storageState:catalanStorageState()},
 webServer:{command:`npm run build && cross-env NODE_ENV=production PORT=${port} APP_URL=${appUrl} PLAYER_TOKEN_SECRET=playwright-e2e-test-secret npm run start`,url:appUrl,reuseExistingServer:false,timeout:120_000}});
