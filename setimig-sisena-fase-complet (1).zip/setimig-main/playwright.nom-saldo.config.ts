import fs from "node:fs";
import path from "node:path";
import { defineConfig, devices } from "@playwright/test";
import { e2eServerEnv } from "./e2e/helpers/e2eServerEnv";

/** Port propi: ni 4450, ni 3179, ni 3177. */
const port = 3517;
const appUrl = `http://127.0.0.1:${port}`;
const env = e2eServerEnv();
const profiles = env.PROFILE_DATA_DIR!;
fs.mkdirSync(profiles, { recursive: true });
fs.mkdirSync(env.BALANCE_DATA_DIR!, { recursive: true });
fs.writeFileSync(
  path.join(profiles, "nomclaraqa01.json"),
  JSON.stringify({ displayName: "Clara QA", avatarDataUrl: null, updatedAt: 1 })
);
fs.writeFileSync(
  path.join(env.BALANCE_DATA_DIR!, "balances.json"),
  JSON.stringify({
    accounts: {
      nomclaraqa01: { chips: 8_000, lastClaimAt: null },
      saldosort01: { chips: 10_000, lastClaimAt: null },
      saldosort02: { chips: 10_000, lastClaimAt: null },
    },
    processedSessions: [],
  })
);

export default defineConfig({
  testDir: "./e2e",
  testMatch: "nom-saldo-sortida.spec.ts",
  timeout: 120_000,
  retries: 0,
  workers: 1,
  projects: [{ name: "chromium", use: { ...devices["Desktop Chrome"], browserName: "chromium" } }],
  use: {
    locale: "ca-ES",
    baseURL: appUrl,
  },
  globalTeardown: "./e2e/helpers/e2eGlobalTeardown.ts",
  webServer: {
    command: "npm run dev",
    env: { ...env, PORT: String(port), APP_URL: appUrl, SETIMIG_HOST: "127.0.0.1" },
    url: `${appUrl}/api/health`,
    reuseExistingServer: false,
    timeout: 120_000,
  },
});
