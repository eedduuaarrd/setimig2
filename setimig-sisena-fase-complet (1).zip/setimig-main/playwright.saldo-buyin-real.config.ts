import fs from "fs";
import path from "path";
import { defineConfig, devices } from "@playwright/test";
import { e2eServerEnv } from "./e2e/helpers/e2eServerEnv";

const port = Number(process.env.SETIMIG_E2E_PORT ?? process.env.PORT ?? 3177);
const appUrl = process.env.APP_URL ?? `http://127.0.0.1:${port}`;

/**
 * #209 contra el servidor real (sense simulacions): saldo 0 → INSUFFICIENT_BALANCE i pràctica;
 * saldo parcial (750) → seu amb 750 fitxes i el saldo de la capçalera surt del servidor;
 * 24.500 → 22.500 en seure, 24.500 en sortir sense jugar i 22.500 + fitxes finals en sortir després de jugar.
 * Els saldos es sembren al directori de dades temporal ABANS d'arrencar el servidor.
 */
const env = e2eServerEnv();
fs.mkdirSync(env.BALANCE_DATA_DIR, { recursive: true });
fs.writeFileSync(
  path.join(env.BALANCE_DATA_DIR, "balances.json"),
  JSON.stringify({
    accounts: {
      buyinreal0zero: { chips: 0, lastClaimAt: Date.now() },
      buyinreal0part: { chips: 750, lastClaimAt: Date.now() },
      buyinreal0full: { chips: 24_500, lastClaimAt: Date.now() },
      buyinreal0play: { chips: 24_500, lastClaimAt: Date.now() },
    },
    processedSessions: [],
  })
);

export default defineConfig({
  testDir: "./e2e",
  testMatch: "saldo-buyin-real.spec.ts",
  timeout: 120_000,
  retries: 0,
  workers: 1,
  projects: [{ name: "chromium", use: { ...devices["Pixel 5"], browserName: "chromium" } }],
  use: {
    locale: "en-US",
    baseURL: appUrl,
    viewport: { width: 390, height: 844 },
  },
  globalTeardown: "./e2e/helpers/e2eGlobalTeardown.ts",
  webServer: {
    command: `npm run build && cross-env NODE_ENV=production PORT=${port} APP_URL=${appUrl} PLAYER_TOKEN_SECRET=playwright-e2e-test-secret npm run start`,
    env,
    url: appUrl,
    reuseExistingServer: false,
    timeout: 180_000,
  },
});
