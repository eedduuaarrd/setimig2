# Setimig UX V18 — lectura dels resultats

Aquesta iteració afina la pantalla de liquidació de la mà, sense canviar les regles ni els valors calculats.

## Canvis
- Cada fila de resultat té un tractament visual coherent amb victòria, derrota o empat.
- El balanç de fitxes destaca en verd quan és positiu, vermell quan és negatiu i neutre quan és zero; el text i el signe continuen sent visibles, per no dependre només del color.
- La fila del jugador actual queda emmarcada i identificada amb l'etiqueta «Tu».
- Es conserva l'etiqueta de banca i s'afegeixen noms accessibles al canvi de fitxes.
- Interacció hover subtil només en dispositius amb ratolí, sense moure la interfície en pantalles tàctils; es respecta `prefers-reduced-motion`.

## Validació
- Canvi limitat a la presentació dels resultats i accessibilitat; no modifica els resultats ni els esdeveniments del joc.
- Cal executar `npm ci`, `npm run check` i `npm test` amb les dependències disponibles i provar una mà completa abans del desplegament.
