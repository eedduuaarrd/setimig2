import { defineConfig } from "@playwright/test";
import { catalanStorageState } from "./e2e/catalanLocale";
import { e2eServerEnv } from "./e2e/helpers/e2eServerEnv";

const port = Number(process.env.SETIMIG_E2E_PORT ?? 3304);
const appUrl = process.env.APP_URL ?? `http://127.0.0.1:${port}`;

/** QA v164 → v165: punts propis, encavalcament a 1280 i cara tapada fora del DOM. */
export default defineConfig({
  testDir: "./e2e",
  testMatch: "qa-v165.spec.ts",
  timeout: 240_000,
  retries: 0,
  workers: 1,
  use: { browserName: "chromium", baseURL: appUrl, locale: "ca-ES", storageState: catalanStorageState(), colorScheme: "dark" },
  globalTeardown: "./e2e/helpers/e2eGlobalTeardown.ts",
  webServer: {
    command: `npm run build && cross-env NODE_ENV=production PORT=${port} APP_URL=${appUrl} PLAYER_TOKEN_SECRET=playwright-e2e-test-secret npm run start`,
    env: e2eServerEnv(),
    url: appUrl,
    reuseExistingServer: true,
    timeout: 180_000,
  },
});
