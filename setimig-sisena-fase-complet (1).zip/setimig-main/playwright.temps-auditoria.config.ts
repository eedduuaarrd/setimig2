import { defineConfig, devices } from "@playwright/test";
import { e2eServerEnv } from "./e2e/helpers/e2eServerEnv";

/** Port propi: ni 4450, ni 3179, ni 3177. */
const port = 3488;
const appUrl = `http://127.0.0.1:${port}`;
const env = e2eServerEnv();

export default defineConfig({
  testDir: "./e2e",
  testMatch: "temps-auditoria.spec.ts",
  timeout: 120_000,
  retries: 0,
  workers: 1,
  projects: [{ name: "chromium", use: { ...devices["Desktop Chrome"], browserName: "chromium" } }],
  use: {
    locale: "ca-ES",
    baseURL: appUrl,
    viewport: { width: 390, height: 844 },
  },
  globalTeardown: "./e2e/helpers/e2eGlobalTeardown.ts",
  webServer: {
    command: "npm run dev",
    env: { ...env, PORT: String(port), APP_URL: appUrl, SETIMIG_HOST: "127.0.0.1" },
    url: `${appUrl}/api/health`,
    reuseExistingServer: false,
    timeout: 120_000,
  },
});
