# Cinquena fase: estabilitat i qualitat

## Millores efectives
- Els botons d'acció i la confirmació d'apostes no envien accions quan el socket no està connectat, encara que el navegador tingui internet. Partida local offline exceptuada.
- Les accions HIT/STAND mostren estat pendent, després ACK rebut (sense confondre-ho amb finalització), mantenen el bloqueig fins a l'actualització autoritativa i es recuperen d'un error amb el mateix actionId.
- Traça local d'incidències limitada a 30 registres de sessió, sense cartes, saldos, identitats ni tokens; només categories i fases reconegudes.
- Ajustos tàctils, accessibilitat de focus, marges segurs i paisatge en mòbil.
- Proves unitàries de la traça, incloent-hi 1000 esdeveniments.

## Funcionalitats que el codi ja conservava
- actionId/rebuts idempotents i protecció contra duplicats en servidor.
- Reconnexió de taules solo i privades amb estat del servidor i overlay.
- Explicacions de liquidació, historial de mans, temporitzadors i controls de mà.
- Tests de flux de partida, apostes, splits, banca, reconnexió i errors de servidor.

## Límit de l'abast
Aquest paquet no certifica que totes les deu propostes siguin completament noves o verificades end-to-end. El simulador de 1000 esdeveniments afegit comprova la seguretat del registre d'incidències, no simula 1000 mans reals. La compilació i les proves end-to-end depenen de les dependències i d'un navegador executables. No es modifiquen les regles de puntuació ni el motor de pagament.

## Proves reproduïbles
`npm run test:stability` (Node 22.16+): executa les proves de registre, rebuts d'acció i simulació existent de 500 mans per dificultat. Les proves completes Socket.IO i navegador requereixen `npm ci`.
