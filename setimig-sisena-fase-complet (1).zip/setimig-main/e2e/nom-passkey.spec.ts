/**
 * Nom i passkey (QA Face ID v179): el diàleg «tria el teu nom» només surt si el compte no té nom,
 * i la passkey es desa amb el nom real (no «Jugador»). API simulada; autenticador virtual (CDP WebAuthn).
 */
import { openLoginEmail, blockSocketIoCtx } from "./helpers/loginSession.ts";
import { expect, test, type Browser, type BrowserContext, type Page } from "@playwright/test";

const PID = "nom-passkey-01";
const TOKEN = "nom.passkey.token";
const AGE_OK = () => JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" });
const b64u = (s: string) => Buffer.from(s).toString("base64url");

type State = { displayName: string; puts: string[]; regOptions: number };

function base(): string {
  const port = Number(process.env.E2E_PORT || process.env.PORT || 3000);
  return `http://localhost:${port}`;
}

async function newCtx(browser: Browser, state: State): Promise<BrowserContext> {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, locale: "ca-ES", colorScheme: "dark" });
  await ctx.addInitScript((age) => {
    if (sessionStorage.getItem("np_seeded") !== "1") {
      sessionStorage.setItem("np_seeded", "1");
      sessionStorage.setItem("setimig_intro_launch_v1", "1");
      localStorage.setItem("setimig.locale", "ca");
      localStorage.setItem("setimig_age_gate", age);
      localStorage.setItem("setimig_home_intro_v1", "1");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
    }
    // Registra el nom que rep navigator.credentials.create (user.name / user.displayName).
    const orig = navigator.credentials?.create?.bind(navigator.credentials);
    if (orig) {
      navigator.credentials.create = (opts?: CredentialCreationOptions) => {
        const u = opts?.publicKey?.user;
        if (u) sessionStorage.setItem("np_created_user", JSON.stringify({ name: u.name, displayName: u.displayName }));
        return orig(opts);
      };
    }
  }, AGE_OK());
  await blockSocketIoCtx(ctx);
  const success = () => ({ playerId: PID, playerToken: TOKEN, method: "email", created: false, linked: true, switchedAccount: false });
  await ctx.route(/\/api\//, async (route) => {
    const req = route.request();
    const url = new URL(req.url());
    switch (`${req.method()} ${url.pathname}`) {
      case "GET /api/auth/providers":
        return route.fulfill({ json: { email: true, google: false, passkey: true, rpId: "localhost" } });
      case "POST /api/auth/email/start":
        return route.fulfill({ status: 202, json: { ok: true, expiresInSec: 600 } });
      case "POST /api/auth/email/verify":
        return route.fulfill({ json: success() });
      case "GET /api/profile":
        return route.fulfill({ json: { displayName: state.displayName, avatarDataUrl: null } });
      case "PUT /api/profile": {
        const body = req.postDataJSON() as { displayName?: string };
        state.puts.push(String(body.displayName));
        if (body.displayName) state.displayName = body.displayName;
        return route.fulfill({ json: { displayName: state.displayName, avatarDataUrl: null } });
      }
      case "POST /api/auth/passkey/register/options":
        // Com el servidor: user.displayName surt del perfil desat en aquest moment.
        state.regOptions++;
        return route.fulfill({
          json: {
            challenge: b64u("reg-challenge-0123456789"),
            rp: { id: "localhost", name: "Seven Half Club" },
            user: { id: b64u(PID), name: "nuria@example.com", displayName: state.displayName },
            pubKeyCredParams: [{ type: "public-key", alg: -7 }],
            authenticatorSelection: { residentKey: "required", userVerification: "required" },
            excludeCredentials: [],
            timeout: 60000,
          },
        });
      case "POST /api/auth/passkey/register/verify":
        return route.fulfill({ json: { ok: true, passkey: { id: "pk1", name: "iPhone" } } });
      case "GET /api/auth/me":
        return route.fulfill({ json: { playerId: PID, emails: ["nuria@example.com"], google: false, passkeys: 0, verified: true } });
      case "POST /api/player-session":
        // Com el servidor real: sense Bearer ni galeta, 401.
        if (!route.request().headers()["authorization"]) return route.fulfill({ status: 401, json: { error: "auth_required" } });
        return route.fulfill({ json: { playerId: PID, playerToken: TOKEN } });
      case "GET /api/balance":
        return route.fulfill({ json: { chips: 1000, freeClaim: { available: false, nextAt: null } } });
      default:
        return route.fulfill({ status: 404, json: { error: "no", code: "NOT_FOUND" } });
    }
  });
  return ctx;
}

async function addAuthenticator(page: Page) {
  const cdp = await page.context().newCDPSession(page);
  await cdp.send("WebAuthn.enable");
  const { authenticatorId } = await cdp.send("WebAuthn.addVirtualAuthenticator", {
    options: { protocol: "ctap2", transport: "internal", hasResidentKey: true, hasUserVerification: true, isUserVerified: true, automaticPresenceSimulation: true },
  });
  return { cdp, authenticatorId };
}

async function loginWithEmail(page: Page) {
  await openLoginEmail(page);
  await page.getByTestId("login-email-input").fill("nuria@example.com");
  await page.getByTestId("login-email-submit").click();
  await page.getByTestId("login-code-input").fill("123456");
  await page.getByTestId("login-code-submit").click();
}

async function expectNoNameGate(page: Page) {
  await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 30_000 });
  // Durant uns segons (perfil carregat) el diàleg no ha d'aparèixer mai.
  for (let i = 0; i < 6; i++) {
    await expect(page.locator("#name-gate-title")).toHaveCount(0);
    await page.waitForTimeout(500);
  }
}

test("compte sense nom: el nom es demana un cop al login i la passkey es desa amb el nom real", async ({ browser }) => {
  const state: State = { displayName: "Jugador", puts: [], regOptions: 0 };
  const ctx = await newCtx(browser, state);
  const page = await ctx.newPage();
  const { cdp, authenticatorId } = await addAuthenticator(page);
  await page.goto(`${base()}/login`);
  await loginWithEmail(page);
  await expect(page.getByTestId("login-name-step")).toBeVisible();
  expect(state.regOptions).toBe(0);
  await page.getByTestId("login-name-input").fill("Núria QA");
  await page.getByTestId("login-name-submit").click();
  await expect(page.getByTestId("login-passkey-prompt")).toBeVisible();
  await page.getByTestId("login-passkey-activate").click();
  await page.waitForURL((u) => u.pathname !== "/login", { timeout: 15_000 });
  expect(state.puts).toEqual(["Núria QA"]);
  const created = JSON.parse((await page.evaluate(() => sessionStorage.getItem("np_created_user"))) || "{}");
  expect(created.displayName).toBe("Núria QA");
  expect(created.displayName).not.toBe("Jugador");
  const { credentials } = await cdp.send("WebAuthn.getCredentials", { authenticatorId });
  expect(credentials).toHaveLength(1);
  await expectNoNameGate(page);
  await ctx.close();
});

test("compte amb nom: tornar a entrar (sense nom local) no mostra el diàleg del nom", async ({ browser }) => {
  const state: State = { displayName: "Núria QA", puts: [], regOptions: 0 };
  const ctx = await newCtx(browser, state);
  const page = await ctx.newPage();
  await page.goto(`${base()}/login`);
  await loginWithEmail(page);
  await page.waitForURL((u) => u.pathname !== "/login", { timeout: 15_000 });
  await expectNoNameGate(page);
  // Recàrrega i nova entrada sense nom al dispositiu (com després de tancar sessió).
  await page.evaluate(() => localStorage.removeItem("setimig_player_name"));
  await page.reload();
  await expectNoNameGate(page);
  expect(state.puts).toEqual([]);
  await ctx.close();
});

test("sessió sense nom a l'app: el diàleg surt un cop i no torna", async ({ browser }) => {
  const state: State = { displayName: "Jugador", puts: [], regOptions: 0 };
  const ctx = await newCtx(browser, state);
  await ctx.addInitScript(([pid, tok]) => {
    localStorage.setItem("setimig_player_id", pid);
    localStorage.setItem("setimig_player_token", tok);
  }, [PID, TOKEN]);
  const page = await ctx.newPage();
  await page.goto(`${base()}/`);
  await expect(page.locator("#name-gate-title")).toBeVisible({ timeout: 30_000 });
  await page.locator('input[name="displayName"]').fill("Pau QA");
  await page.locator('input[name="displayName"]').press("Enter");
  await expect(page.locator("#name-gate-title")).toHaveCount(0);
  await expect.poll(() => state.puts).toEqual(["Pau QA"]);
  await page.evaluate(() => localStorage.removeItem("setimig_player_name"));
  await page.reload();
  await expectNoNameGate(page);
  await ctx.close();
});
