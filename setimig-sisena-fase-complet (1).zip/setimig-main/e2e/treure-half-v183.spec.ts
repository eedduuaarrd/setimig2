import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * v183: la tira de descarts «Mig: 2 R 5 7…» (room.centerDiscard) ja no surt a la mesa,
 * ni durant el torn propi ni durant el torn d'un rival, a cap mida.
 */
const SIZES = [
  { name: "390", width: 390, height: 844 },
  { name: "1280", width: 1280, height: 800 },
] as const;

async function startSolo(page: Page) {
  await seedE2eSession(page, e2ePoolId());
  await page.addInitScript(() => {
    if (sessionStorage.getItem("qa_half") === "1") return;
    sessionStorage.setItem("qa_half", "1");
    for (const k of ["setimig_onboarding_v1", "setimig_interactive_tutorial_v1", "setimig_table_tutorial_v1"]) localStorage.setItem(k, "1");
    localStorage.setItem("setimig.locale", "ca");
    localStorage.setItem("setimig_player_name", "Test Half");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
    sessionStorage.setItem("setimig_intro_launch_v1", "1");
  });
  await page.goto("/");
  const skip = page.getByTestId("interactive-tutorial-skip");
  await expect(page.getByTestId("lobby-context").or(skip).first()).toBeVisible({ timeout: 45_000 });
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  await page.getByTestId("ai-bot-picker-start").click();
  await page.getByTestId("bet-confirm").filter({ visible: true }).first().click({ timeout: 30_000 });
}

const noStrip = async (page: Page) => {
  const found = await page.evaluate(() =>
    [...document.querySelectorAll("span")].some((s) => /^(Mig|Half|Media|Metà|Meio):?$/i.test((s.textContent ?? "").trim())),
  );
  expect(found).toBe(false);
};

for (const size of SIZES) {
  test(`sense tira de descarts a ${size.name}px`, async ({ page }) => {
    await page.setViewportSize({ width: size.width, height: size.height });
    await startSolo(page);
    const stand = page.getByTestId("action-stand").filter({ visible: true }).first();
    await expect(stand).toBeVisible({ timeout: 30_000 });
    await noStrip(page);
    await stand.click();
    // Torn del rival / banca.
    for (let i = 0; i < 6; i++) {
      await page.waitForTimeout(500);
      await noStrip(page);
    }
  });
}
