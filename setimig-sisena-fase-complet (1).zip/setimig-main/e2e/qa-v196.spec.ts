import { expect, test, type Page } from "@playwright/test";
import { passAgeGateToLobby } from "./helpers/ageGateLobby";
import { createPrivateTable, readInviteCode } from "./helpers/tableFlow";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * QA v196 (retest de la v195, P3 de client):
 * b) A 1024, el «±N» (fx-chip-delta) no tapa mai la pista de figura (face-hint-card) ni cap etiqueta, mans 1–3.
 * c) «Doblar» només surt quan pendingChoices.canDouble és cert (amagat, no desactivat).
 * a) («T’has passat») té test unitari a src/lib/typography.test.ts.
 */
const visible = (page: Page, id: string) => page.getByTestId(id).filter({ visible: true }).first();
const COVERED =
  "[data-testid=face-hint-card], .face-hint-bubble, [data-testid=seat-name], .v2-seat-name, .seat-action-bubble, [data-testid=settled-hand-chip], [data-testid=split-hand-label], [data-testid=table-pot], [data-testid=fx-result-badge]";

async function tap(p: Page, id: string) {
  const l = visible(p, id);
  if (!(await l.isVisible().catch(() => false))) return false;
  if (!(await l.isEnabled({ timeout: 300 }).catch(() => false))) return false;
  await l.click({ timeout: 2_000 }).catch(() => {});
  return true;
}

async function deltaHits(p: Page): Promise<{ hits: string[]; deltas: number }> {
  return p.evaluate((SEL) => {
    const vis = (e: Element) => {
      const r = e.getBoundingClientRect();
      if (r.width <= 0 || r.height <= 0) return null;
      for (let n: Element | null = e; n; n = n.parentElement) {
        const s = getComputedStyle(n);
        if (s.display === "none" || s.visibility === "hidden" || Number(s.opacity) < 0.15) return null;
      }
      return r;
    };
    const ov = (a: DOMRect, b: DOMRect) => Math.min(a.right, b.right) - Math.max(a.left, b.left) > 2 && Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top) > 2;
    const labels = Array.from(document.querySelectorAll(SEL)).map((e) => ({ e, r: vis(e) })).filter((x) => x.r) as { e: Element; r: DOMRect }[];
    const hits: string[] = [];
    let deltas = 0;
    for (const d of Array.from(document.querySelectorAll("[data-testid=fx-chip-delta]"))) {
      const r = vis(d);
      if (!r) continue;
      deltas++;
      for (const l of labels) if (ov(r, l.r)) hits.push(`${d.textContent} sobre ${l.e.getAttribute("data-testid") ?? l.e.className} «${(l.e.getAttribute("aria-label") ?? l.e.textContent ?? "").trim().slice(0, 30)}» [${[r.left, r.top, r.width, r.height].map(Math.round)}] vs [${[l.r.left, l.r.top, l.r.width, l.r.height].map(Math.round)}] beside=${d.getAttribute("data-fx-beside")} vw=${innerWidth}`);
    }
    return { hits, deltas };
  }, COVERED);
}

test("b) 1024: el «±N» de la liquidació no tapa la pista de figura ni etiquetes (mans 1–3)", async ({ browser }) => {
  test.setTimeout(420_000);
  const vp = { width: 1024, height: 768 };
  const ctxs = await Promise.all([0, 1].map(() => browser.newContext({ viewport: vp })));
  const pages = await Promise.all(ctxs.map((c) => c.newPage()));
  await passAgeGateToLobby(pages[0], "Amfitrio196", { playerId: e2ePoolId(), online: true });
  await createPrivateTable(pages[0]);
  const code = await readInviteCode(pages[0]);
  await passAgeGateToLobby(pages[1], "Convidat196", { playerId: e2ePoolId(), online: true });
  await pages[1].goto(`/?t=${code}`);
  await expect(pages[0].getByTestId("start-game-button")).toBeVisible({ timeout: 30_000 });
  await pages[0].getByTestId("start-game-button").click();

  const hits: string[] = [];
  let deltasSeen = 0;
  for (let hand = 1; hand <= 3; hand++) {
    let player: Page | null = null;
    await expect.poll(async () => {
      for (const p of pages) if (await visible(p, "bet-confirm").isVisible().catch(() => false)) player = p;
      return player != null;
    }, { timeout: 60_000 }).toBe(true);
    const bank = pages.find((p) => p !== player)!;
    for (const p of pages) for (const id of ["table-tutorial-skip", "interactive-tutorial-skip"]) await p.getByTestId(id).click({ timeout: 300 }).catch(() => {});
    await visible(player!, "bet-confirm").click();
    const end = Date.now() + 90_000;
    while (Date.now() < end && !(await visible(player!, "settlement-sheet").isVisible().catch(() => false))) {
      await tap(player!, "action-stand");
      await tap(bank, "action-stand");
      await player!.waitForTimeout(250);
    }
    await expect(visible(player!, "settlement-sheet")).toBeVisible({ timeout: 30_000 });
    const t0 = Date.now();
    while (Date.now() - t0 < 4_500 && (await visible(player!, "settlement-sheet").isVisible().catch(() => false))) {
      for (const p of pages) {
        const s = await deltaHits(p);
        deltasSeen += s.deltas;
        hits.push(...s.hits.map((h) => `mà ${hand}: ${h}`));
      }
      await player!.waitForTimeout(80);
    }
    await expect(visible(player!, "settlement-sheet")).toBeHidden({ timeout: 30_000 }).catch(() => {});
  }
  expect(deltasSeen, "s'ha vist algun «±N»").toBeGreaterThan(0);
  expect(Array.from(new Set(hits)).slice(0, 8), "«±N» damunt de la pista de figura o d'una etiqueta").toEqual([]);
  await Promise.all(ctxs.map((c) => c.close()));
});

async function startSolo(page: Page) {
  await seedE2eSession(page, e2ePoolId());
  await page.addInitScript(() => {
    if (sessionStorage.getItem("q196") === "1") return;
    sessionStorage.setItem("q196", "1");
    for (const k of ["setimig_onboarding_v1", "setimig_interactive_tutorial_v1", "setimig_table_tutorial_v1", "setimig_house_rules_enabled"]) localStorage.setItem(k, "1");
    localStorage.setItem("setimig.locale", "ca");
    localStorage.setItem("setimig_player_name", "Test QA196");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
    sessionStorage.setItem("setimig_intro_launch_v1", "1");
  });
  await page.goto("/");
  const skip = page.getByTestId("interactive-tutorial-skip");
  await expect(page.getByTestId("lobby-context").or(skip).first()).toBeVisible({ timeout: 45_000 });
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.getByTestId("lobby-context").click();
  await page.getByTestId("ai-bot-count-1").click();
  const cb = page.getByTestId("house-rules-toggle").locator("input");
  if ((await cb.count()) && !(await cb.isChecked())) await cb.check({ force: true });
  await page.getByTestId("ai-bot-picker-start").click();
  await page.getByTestId("bet-confirm").filter({ visible: true }).first().click({ timeout: 30_000 });
}

for (const vp of [{ width: 1024, height: 768, id: "action-double" }, { width: 390, height: 844, id: "mobile-double-chip" }]) {
  test.describe(`c) Doblar a ${vp.width}`, () => {
    test.use({ viewport: { width: vp.width, height: vp.height } });
    test("«Doblar» surt amb la primera carta (≥44 px) i desapareix quan canDouble és fals", async ({ page }) => {
      test.setTimeout(180_000);
      let shown = 0;
      let checked = 0;
      for (let round = 0; round < 4 && checked === 0; round++) {
        if (round === 0) await startSolo(page);
        const hit = visible(page, "action-hit");
        await expect(hit.or(visible(page, "settlement-sheet")).first()).toBeVisible({ timeout: 60_000 });
        if (await hit.isEnabled({ timeout: 5_000 }).catch(() => false)) {
          await page.waitForTimeout(800);
          const dbl = visible(page, vp.id);
          if (await dbl.isVisible().catch(() => false)) {
            shown++;
            expect((await dbl.boundingBox())!.height, "Doblar ≥44 px").toBeGreaterThanOrEqual(44);
          }
          await hit.click();
          // Amb dues cartes (sense separar) el motor ja no deixa doblar: el botó no hi és (ni desactivat).
          await page.waitForTimeout(2_500);
          if (await visible(page, "action-stand").isVisible().catch(() => false)) {
            await expect(page.getByTestId(vp.id).filter({ visible: true })).toHaveCount(0);
            await expect(page.getByRole("button", { name: /^Doblar/ }).filter({ visible: true })).toHaveCount(0);
            checked++;
          }
        }
        const end = Date.now() + 60_000;
        while (Date.now() < end && !(await visible(page, "settlement-sheet").isVisible().catch(() => false))) {
          await tap(page, "action-stand");
          await page.waitForTimeout(500);
        }
        await tap(page, "settlement-next-hand");
        await page.getByTestId("bet-confirm").filter({ visible: true }).first().click({ timeout: 30_000 }).catch(() => {});
      }
      expect(checked, "s'ha comprovat una mà amb dues cartes").toBeGreaterThan(0);
      console.log(`[v196] ${vp.width}: Doblar visible amb 1 carta ${shown} cops`);
    });
  });
}
