import { expect, test, type Locator, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * QA 4de8597 (v172): a la liquidació no surt mai el total propi (ni a la píndola de resultat
 * ni a l'etiqueta de la mà) i res no s'encavalca.
 * Cal SETIMIG_TEST_DECK_SEED=3 (doblar + separar) o SETIMIG_TEST_DECK_SEED=217 (Mort contra 7½).
 */
const SEED = process.env.SETIMIG_TEST_DECK_SEED;
const OUT = "/workspace/liq-punts-v172";
const SIZES = [
  { name: "390", width: 390, height: 844 },
  { name: "1280", width: 1280, height: 800 },
] as const;
const POINTS = /\d|½/;

async function startSolo(page: Page) {
  const pid = e2ePoolId();
  await seedE2eSession(page, pid);
  await page.addInitScript(() => {
    if (sessionStorage.getItem("qa_llavor") === "1") return;
    sessionStorage.setItem("qa_llavor", "1");
    for (const k of ["setimig_onboarding_v1", "setimig_interactive_tutorial_v1", "setimig_table_tutorial_v1", "setimig_house_rules_enabled"]) localStorage.setItem(k, "1");
    localStorage.setItem("setimig.locale", "ca");
    localStorage.setItem("setimig_player_name", "Test Llavor");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
    sessionStorage.setItem("setimig_intro_launch_v1", "1");
  });
  await page.goto("/");
  const skip = page.getByTestId("interactive-tutorial-skip");
  await expect(page.getByTestId("lobby-context").or(skip).first()).toBeVisible({ timeout: 45_000 });
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  if (await page.getByTestId("ai-bot-count-1").isVisible().catch(() => false)) await page.getByTestId("ai-bot-count-1").click();
  const cb = page.getByTestId("house-rules-toggle").locator("input");
  if (!(await cb.isChecked())) await cb.check({ force: true });
  await page.getByTestId("ai-bot-picker-start").click();
  await page.getByTestId("bet-confirm").filter({ visible: true }).first().click({ timeout: 30_000 });
}

async function peek(page: Page) {
  const g = page.getByTestId("peek-curl-grab").filter({ visible: true }).first();
  await expect(g).toBeVisible({ timeout: 20_000 });
  const b = (await g.boundingBox())!;
  const x = b.x + b.width / 2;
  const y0 = b.y + b.height * 0.95;
  await page.mouse.move(x, y0);
  await page.mouse.down();
  for (let i = 1; i <= 8; i++) await page.mouse.move(x, y0 - i * b.height * 0.08);
  await page.mouse.up();
  await page.waitForTimeout(700);
}

const doubleBtn = (page: Page, mobile: boolean) =>
  mobile ? page.getByTestId("mobile-double-chip").filter({ visible: true }).first() : page.getByRole("button", { name: /^doblar$/i }).filter({ visible: true }).first();

async function toSettlement(page: Page, doStand = true) {
  const sheet = page.getByTestId("settlement-sheet");
  for (let i = 0; i < 300 && !(await sheet.isVisible().catch(() => false)); i++) {
    if (!doStand) { await page.waitForTimeout(300); continue; }
    const stand = page.getByTestId("action-stand").filter({ visible: true }).first();
    // #317: «Plantar-se» només existeix al torn propi. isEnabled()/click() sobre un locator buit
    // esperen actionTimeout (15 s) i la liquidació (més curta) passa sense que el bucle la vegi.
    if ((await stand.isVisible().catch(() => false)) && (await stand.isEnabled({ timeout: 500 }).catch(() => false)))
      await stand.click({ timeout: 1000 }).catch(() => {});
    await page.waitForTimeout(300);
  }
  await expect(sheet).toBeVisible();
  await page.waitForTimeout(1200);
}



type Box = { x: number; y: number; width: number; height: number };
const overlap = (a: Box, b: Box) =>
  a.x < b.x + b.width - 1 && b.x < a.x + a.width - 1 && a.y < b.y + b.height - 1 && b.y < a.y + a.height - 1;

async function boxes(l: Locator): Promise<Box[]> {
  const out: Box[] = [];
  for (const el of await l.all()) {
    if (!(await el.isVisible().catch(() => false))) continue;
    const b = await el.boundingBox();
    if (b) out.push(b);
  }
  return out;
}

/** Cap total propi: files de la liquidació, xip de la mà pròpia i píndoles sobre la mà pròpia. */
async function expectNoOwnTotal(page: Page) {
  for (const row of await page.getByTestId("settlement-hand-row").all()) {
    expect((await row.innerText()).replace(/^\s*(Mà|Hand|Mano|Mão)\s+\d+/i, "")).not.toMatch(POINTS);
  }
  for (const chip of await page.getByTestId("settled-hand-chip").all()) {
    expect(await chip.innerText()).not.toMatch(POINTS);
  }
  for (const row of await page.locator('[data-testid="settlement-result-row"][data-self="true"]').all()) {
    // Fila pròpia: nom + motiu sense punts; l'import (+600/−400) va a part.
    const reason = (await row.locator("div").first().innerText()).replace("Test Llavor", "");
    expect(reason, "total propi a la fila de la liquidació").not.toMatch(POINTS);
  }
  // La píndola «Perd · ½» de la mà pròpia ja no existeix; les dels rivals no cauen sobre la meva mà.
  // Les cartes pròpies (el contenidor del seient és més alt que el que es veu).
  const own = await boxes(page.locator('[data-testid="local-player-seat"] .spanish-card'));
  for (const badge of await page.getByTestId("fx-result-badge").all()) {
    const b = await badge.boundingBox();
    if (!b) continue;
    for (const o of own) expect(overlap(b, o), `píndola «${await badge.innerText()}» sobre la mà pròpia`).toBe(false);
  }
}

async function expectNoOverlaps(page: Page, mobile: boolean) {
  const card = (await page.locator(".settlement-card").boundingBox())!;
  for (const b of await boxes(page.getByTestId("fx-result-badge"))) expect(overlap(b, card), "píndola sobre la liquidació").toBe(false);
  // v185: el plafó (opac) ara queda per sobre de la taula; una etiqueta que hi queda a sota no es veu i no tapa res.
  const underSheet = (b: Box) => overlap(b, card) && b.y >= card.y;
  const labels = [...(await boxes(page.getByTestId("settled-hand-chip"))), ...(await boxes(page.getByTestId("fx-result-badge")))].filter((b) => !underSheet(b));
  const against = async (re: RegExp, what: string, set: Box[]) => {
    const targets = await boxes(page.getByText(re));
    for (const l of set) for (const tb of targets) expect(overlap(l, tb), what).toBe(false);
  };
  if (mobile) {
    await against(/^[−-]400$/, "etiqueta sobre «−400»", labels);
    await against(/Mort.*es destapa/i, "etiqueta sobre l'avís del Mort", labels);
  } else {
    await against(/Mà 1 · Doblada/, "banca sobre «Mà 1 · Doblada»", await boxes(page.locator("[data-seat-banker=true]")));
  }
  if (!mobile) {
    const banks = await boxes(page.locator("[data-seat-banker=true]"));
    for (const p of await boxes(page.locator(".desktop-hand-panel"))) for (const bk of banks) expect(overlap(p, bk), "banca sobre la mà").toBe(false);
  }
}

for (const size of SIZES) {
  const mobile = size.width < 600;
  test.describe(`Liquidació sense punts v172 @${size.name}`, () => {
    test.use({ viewport: { width: size.width, height: size.height }, isMobile: mobile, hasTouch: mobile });

    test("llavor 3: doblar + separar", async ({ page }) => {
      test.skip(SEED !== "3", "cal SETIMIG_TEST_DECK_SEED=3");
      await startSolo(page);
      await peek(page);
      await doubleBtn(page, mobile).click({ timeout: 20_000 });
      const split = page.getByRole("button", { name: /separar|split/i }).filter({ visible: true }).first();
      await split.click({ timeout: 20_000 });
      await page.waitForTimeout(2000);
      await toSettlement(page);
      await page.screenshot({ path: `${OUT}/3-${size.name}.png` });
      await expect(page.getByTestId("settlement-hand-row")).toHaveCount(2);
      await expectNoOwnTotal(page);
      await expectNoOverlaps(page, mobile);
    });

    test("llavor 217: Mort contra 7½", async ({ page }) => {
      test.skip(SEED !== "217", "cal SETIMIG_TEST_DECK_SEED=217");
      await startSolo(page);
      await peek(page);
      await page.getByTestId("mort-accept").click({ timeout: 20_000 });
      await toSettlement(page, false);
      await page.screenshot({ path: `${OUT}/217-${size.name}.png` });
      await expectNoOwnTotal(page);
      await expectNoOverlaps(page, mobile);
    });
  });
}
