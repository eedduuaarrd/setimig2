import { expect, test } from "@playwright/test";

test("private-table sheet remains reachable on a short viewport", async ({ page }) => {
  await page.setViewportSize({ width: 320, height: 568 });
  await page.goto("/e2e/fixtures/friends-lobby-modal.html");

  const panel = page.getByTestId("friends-table-section");
  await expect(panel).toBeVisible();
  const initialBounds = await panel.evaluate((element) => {
    const rect = element.getBoundingClientRect();
    return {
      top: rect.top,
      bottom: rect.bottom,
      clientHeight: element.clientHeight,
      scrollHeight: element.scrollHeight,
      overflowY: getComputedStyle(element).overflowY,
    };
  });

  expect(initialBounds.top).toBeGreaterThanOrEqual(0);
  expect(initialBounds.bottom).toBeLessThanOrEqual(568);
  expect(initialBounds.scrollHeight).toBeGreaterThan(initialBounds.clientHeight);
  expect(initialBounds.overflowY).toBe("auto");

  await panel.evaluate((element) => {
    element.scrollTop = element.scrollHeight;
  });
  await expect(page.getByTestId("join-private-table")).toBeInViewport();
});
