import AxeBuilder from "@axe-core/playwright";
import { expect, test } from "@playwright/test";
import { passAgeGateToLobby } from "./helpers/ageGateLobby";
import { matchEndSnapshotJson, seedAgeGateFresh, seedLobby, splitTurnSnapshotJson } from "./helpers/uxA11yFixtures";

test.describe("UX-A11Y F1", () => {
  test("UX-01 age gate accept reachable at 568x320 landscape", async ({ page }) => {
    await page.setViewportSize({ width: 568, height: 320 });
    await seedAgeGateFresh(page);
    await page.goto("/");
    const accept = page.getByTestId("age-gate-accept");
    await accept.waitFor({ state: "visible" });
    const gate = page.getByTestId("age-gate");
    const scrollable = await gate.evaluate((el) => {
      const style = getComputedStyle(el);
      return style.overflowY === "auto" || style.overflowY === "scroll";
    });
    expect(scrollable).toBeTruthy();
    const box = await accept.boundingBox();
    expect(box).not.toBeNull();
    const viewport = page.viewportSize()!;
    const inView =
      box!.y + box!.height <= viewport.height + 1 && box!.y >= 0;
    if (!inView) {
      await gate.evaluate((el) => {
        el.scrollTop = el.scrollHeight;
      });
    }
    await expect(accept).toBeInViewport();
  });

  test("UX-06 lobby guide links meet 44px touch target", async ({ page }) => {
    await page.setViewportSize({ width: 390, height: 844 });
    await passAgeGateToLobby(page);
    // Des de #181 (Lobby v4.1) la guia ja no es repeteix al peu: és l'enllaç «Com jugar» del lobby (/com-jugar).
    const guide = page.getByTestId("lobby-open-tutorial");
    await expect(guide).toHaveAttribute("href", "/com-jugar");
    await expect(page.locator('[data-testid="legal-footer"] a[href="/com-jugar"]')).toHaveCount(0);
    const targets = [
      guide,
      page.locator('[data-testid="legal-footer"]').getByRole("link", { name: "Legal" }),
    ];
    for (const target of targets) {
      await expect(target).toBeVisible();
      const box = await target.boundingBox();
      expect(box).not.toBeNull();
      expect(box!.height).toBeGreaterThanOrEqual(44);
      expect(box!.width).toBeGreaterThanOrEqual(44);
    }
  });

  test("UX-07 legal footer links pass axe contrast at 844x390", async ({ page }) => {
    await page.setViewportSize({ width: 844, height: 390 });
    await passAgeGateToLobby(page);
    const results = await new AxeBuilder({ page })
      .include('[data-testid="legal-footer"]')
      .withTags(["wcag2aa", "wcag21aa"])
      .analyze();
    const contrast = results.violations.filter((v) => v.id === "color-contrast");
    expect(contrast).toEqual([]);
  });

  test("UX-02 match end overlay contrast (axe)", async ({ page }) => {
    const playerId = "a11y-match-end-player";
    await page.setViewportSize({ width: 320, height: 568 });
    await page.addInitScript(
      ({ snapshot, pid }) => {
        localStorage.setItem("setimig_player_id", pid);
        localStorage.setItem("setimig_player_name", "FinTest");
        localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
        localStorage.setItem(
          "setimig_age_gate",
          JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
        );
        localStorage.setItem("setimig_local_solo_snapshot", snapshot);
        sessionStorage.setItem("setimig_solo_rejoin", "1");
        sessionStorage.setItem("setimig_solo_local", "1");
      },
      { snapshot: matchEndSnapshotJson(playerId, "FinTest"), pid: playerId }
    );
    await page.goto("/");
    await expect(page.getByTestId("match-end-overlay")).toBeVisible({ timeout: 60_000 });
    const results = await new AxeBuilder({ page })
      .include('[data-testid="match-end-overlay"]')
      .withTags(["wcag2aa", "wcag21aa"])
      .analyze();
    const contrast = results.violations.filter((v) => v.id === "color-contrast");
    expect(contrast).toEqual([]);
  });

  test("UX-05 match end actions visible without inner scroll", async ({ page }) => {
    const playerId = "a11y-match-actions-player";
    await page.setViewportSize({ width: 320, height: 568 });
    await page.addInitScript(
      ({ snapshot, pid }) => {
        localStorage.setItem("setimig_player_id", pid);
        localStorage.setItem("setimig_player_name", "ActTest");
        localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
        localStorage.setItem(
          "setimig_age_gate",
          JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
        );
        localStorage.setItem("setimig_local_solo_snapshot", snapshot);
        sessionStorage.setItem("setimig_solo_rejoin", "1");
        sessionStorage.setItem("setimig_solo_local", "1");
      },
      { snapshot: matchEndSnapshotJson(playerId, "ActTest"), pid: playerId }
    );
    await page.goto("/");
    await expect(page.getByTestId("match-revenge-button")).toBeVisible({ timeout: 60_000 });
    await expect(page.getByTestId("match-lobby-button")).toBeInViewport();
  });

  test("UX-04 cards readable at 640x450 (200% zoom layout)", async ({ page }) => {
    await page.setViewportSize({ width: 640, height: 450 });
    await passAgeGateToLobby(page);
    await page.getByTestId("lobby-context").click();
    await page.getByTestId("ai-bot-count-1").click();
    await page.getByRole("button", { name: "Començar" }).click();
    await page.getByTestId("bet-confirm").click({ timeout: 120_000 });
    const card = page.locator(".spanish-card-size-player, .spanish-card-size-opponent").first();
    await expect(card).toBeVisible({ timeout: 60_000 });
    const box = await card.boundingBox();
    expect(box).not.toBeNull();
    expect(box!.height).toBeGreaterThanOrEqual(40);
  });

  test("UX-04 cards have accessible Catalan names and min size at 320x568", async ({ page }) => {
    await page.setViewportSize({ width: 320, height: 568 });
    await passAgeGateToLobby(page);
    await page.getByTestId("lobby-context").click();
    await page.getByTestId("ai-bot-count-1").click();
    await page.getByRole("button", { name: "Començar" }).click();
    await page.getByTestId("bet-confirm").click({ timeout: 120_000 });
    const card = page.getByRole("img", { name: /d'oros|de copes|d'espases|de bastos|Cavall|Sota|Rei/i }).first();
    await expect(card).toBeVisible({ timeout: 60_000 });
    const label = await card.getAttribute("aria-label");
    expect(label).toMatch(/d'|de /);
    const box = await card.boundingBox();
    expect(box).not.toBeNull();
    expect(box!.height).toBeGreaterThanOrEqual(40);
    expect(box!.width).toBeGreaterThanOrEqual(24);
  });

  test("UX-08 prominent centered turn prompt explains the active player's action", async ({ page }) => {
    const playerId = "a11y-turn-prompt-player";
    const snapshot = JSON.parse(splitTurnSnapshotJson(playerId, "PromptTest")) as {
      room: { practiceMode?: boolean };
    };
    // Practice mode keeps the restored human turn on screen: a normal solo hand
    // arms a ~22s timeout and then the bank plays, and the mobile three-band layout
    // does not mount CurrentTurnPrompt during card play.
    snapshot.room.practiceMode = true;
    await page.setViewportSize({ width: 390, height: 844 });
    await page.addInitScript(
      ({ snapshot: stored, pid }) => {
        localStorage.setItem("setimig_player_id", pid);
        localStorage.setItem("setimig_player_name", "PromptTest");
        localStorage.setItem("setimig_onboarding_v1", "1");
        localStorage.setItem("setimig_interactive_tutorial_v1", "1");
        localStorage.setItem(
          "setimig_age_gate",
          JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
        );
        localStorage.setItem("setimig_local_solo_snapshot", stored);
        sessionStorage.setItem("setimig_solo_rejoin", "1");
        sessionStorage.setItem("setimig_solo_local", "1");
      },
      { snapshot: JSON.stringify(snapshot), pid: playerId }
    );
    await page.goto("/");
    const live = page.getByTestId("game-live-region");
    await expect(live).toContainText("Et toca", { timeout: 60_000 });
    await expect(live).toContainText(/separa la parella.*demana carta.*planta't/i);
    const banner = page.getByTestId("turn-banner");
    await expect(banner).toBeVisible();
    await expect(banner).toContainText("Et toca");
    const box = await banner.boundingBox();
    expect(box).not.toBeNull();
    expect(Math.abs(box!.x + box!.width / 2 - 195)).toBeLessThan(48);
    expect(box!.y).toBeGreaterThanOrEqual(0);
    expect(box!.y).toBeLessThan(220);
    await expect(page.getByTestId("mobile-split-button")).toBeVisible();
    await expect(page.getByTestId("action-stand")).toBeVisible();
    const results = await new AxeBuilder({ page })
      .include('[data-testid="status-pill"]')
      .withTags(["wcag2aa", "wcag21aa"])
      .analyze();
    expect(results.violations.filter((v) => v.id === "color-contrast")).toEqual([]);
  });

  test("UX-03 live region announces match end totals", async ({ page }) => {
    const playerId = "a11y-live-region-player";
    await page.setViewportSize({ width: 390, height: 844 });
    await page.addInitScript(
      ({ snapshot, pid }) => {
        localStorage.setItem("setimig_player_id", pid);
        localStorage.setItem("setimig_player_name", "LiveTest");
        localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
        localStorage.setItem(
          "setimig_age_gate",
          JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
        );
        localStorage.setItem("setimig_local_solo_snapshot", snapshot);
        sessionStorage.setItem("setimig_solo_rejoin", "1");
        sessionStorage.setItem("setimig_solo_local", "1");
      },
      { snapshot: matchEndSnapshotJson(playerId, "LiveTest"), pid: playerId }
    );
    await page.goto("/");
    await expect(page.getByTestId("game-live-region")).toContainText(/fitxes/i, { timeout: 60_000 });
    await expect(page.getByTestId("game-live-region")).toContainText(/partida|guanyat/i);
  });
});
