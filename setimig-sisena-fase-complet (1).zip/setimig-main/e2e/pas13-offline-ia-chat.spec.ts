import { expect, test } from "@playwright/test";
import fs from "node:fs";
import path from "node:path";
import { startAiGameFromLobby } from "./helpers/aiLobby";
import { passAgeGateToLobby } from "./helpers/ageGateLobby";
import { openTableChat } from "./helpers/tableFlow";

const MOBILE = { width: 390, height: 844 } as const;

function screenshotDir(): string {
  const candidates = [
    "/cursor/stores/self/media/pas13",
    path.join(process.cwd(), "media/pas13"),
  ];
  for (const dir of candidates) {
    try {
      fs.mkdirSync(dir, { recursive: true });
      return dir;
    } catch {
      /* try next */
    }
  }
  return candidates[candidates.length - 1];
}

/** GameView is lazy. context.setOffline against the Vite dev server fails that import and the table error boundary opens. */
async function preloadTableModule(page: import("@playwright/test").Page) {
  await page.evaluate(async (specifier: string) => {
    // A parameter, not a literal, so tsc does not resolve the Vite URL as a module.
    await import(specifier);
  }, "/src/GameView.tsx");
}

test("PAS 13 — IA local sense socket (offline)", async ({ page, context }) => {
  test.setTimeout(120_000);
  await page.setViewportSize(MOBILE);
  await passAgeGateToLobby(page, "Pas13Off", { playerId: "pas13offline01xx" });
  await preloadTableModule(page);
  await context.setOffline(true);
  await expect(page.getByTestId("play-with-friends-button")).toHaveAttribute("aria-disabled", "true");
  await startAiGameFromLobby(page, 2);
  await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 45_000 });
  // The seat wrapper is empty (and therefore hidden) until cards are dealt.
  await expect(page.getByTestId("action-dock")).toBeVisible();
  await expect(page.getByTestId("offline-table-chip")).toBeVisible();
  await page.screenshot({ path: path.join(screenshotDir(), "01-offline-table.png"), fullPage: false });
});

test("PAS 13 — xat bottom sheet en partida IA local", async ({ page, context }) => {
  test.setTimeout(120_000);
  await page.setViewportSize(MOBILE);
  await passAgeGateToLobby(page, "Pas13Chat", { playerId: "pas13chat01xxxxx" });
  await preloadTableModule(page);
  await context.setOffline(true);
  await expect(page.getByTestId("play-with-friends-button")).toHaveAttribute("aria-disabled", "true");
  await startAiGameFromLobby(page, 2);
  await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 45_000 });
  await openTableChat(page);
  await page.getByRole("textbox", { name: "Escriu un missatge al xat" }).fill("Hola taula!");
  await page.getByRole("button", { name: "Enviar missatge" }).click();
  await expect(page.getByTestId("table-chat-sheet").getByText("Hola taula!")).toBeVisible();
  await page.screenshot({ path: path.join(screenshotDir(), "02-chat-sheet.png"), fullPage: false });
});
