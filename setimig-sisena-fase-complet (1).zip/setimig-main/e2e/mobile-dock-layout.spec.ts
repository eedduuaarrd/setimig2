import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";
import { playingTurnSnapshotJson } from "./helpers/mobileDockLayoutFixtures.ts";

const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844 },
  { tag: "375x667", width: 375, height: 667 },
  { tag: "360x740", width: 360, height: 740 },
] as const;

async function seedLocalSolo(page: Page, snapshot: string, playerId: string, playerName: string) {
  await seedE2eSession(page, playerId);
  await page.addInitScript(
    ({ snap, pid, pname }) => {
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", pname);
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_house_rules_enabled", "1");
      localStorage.setItem(
        "setimig_age_gate",
        JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
      );
      localStorage.setItem("setimig_local_solo_snapshot", snap);
      sessionStorage.setItem("setimig_solo_rejoin", "1");
      sessionStorage.setItem("setimig_solo_local", "1");
    },
    { snap: snapshot, pid: playerId, pname: playerName }
  );
}

function rectsOverlap(
  a: { x: number; y: number; width: number; height: number },
  b: { x: number; y: number; width: number; height: number }
) {
  return a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y + b.height && a.y + a.height > b.y;
}

async function assertNoHorizontalOverflow(page: Page) {
  const metrics = await page.evaluate(() => ({
    scrollWidth: document.documentElement.scrollWidth,
    innerWidth: window.innerWidth,
  }));
  expect(metrics.scrollWidth).toBeLessThanOrEqual(metrics.innerWidth + 1);
}

async function assertActionButtons(page: Page) {
  const hit = page.getByTestId("action-hit");
  const stand = page.getByTestId("action-stand");
  await expect(hit).toBeVisible({ timeout: 30_000 });
  await expect(stand).toBeVisible();
  const hitBox = await hit.boundingBox();
  const standBox = await stand.boundingBox();
  expect(hitBox).not.toBeNull();
  expect(standBox).not.toBeNull();
  if (!hitBox || !standBox) return;
  expect(hitBox.width).toBeGreaterThan(100);
  expect(standBox.width).toBeGreaterThan(100);
  const vw = page.viewportSize()?.width ?? 390;
  expect(hitBox.x + hitBox.width).toBeLessThanOrEqual(vw + 1);
  expect(standBox.x + standBox.width).toBeLessThanOrEqual(vw + 1);
}

async function assertHandFanAndPoints(page: Page) {
  const data = await page.evaluate(() => {
    const cards = Array.from(document.querySelectorAll('[data-testid="local-hand-card"]')).map((el) => {
      const r = el.getBoundingClientRect();
      return { left: r.left, right: r.right, width: r.width, top: r.top, bottom: r.bottom };
    });
    const points = document.querySelector('[data-testid="my-hand-points"]');
    const hint = document.querySelector('[data-testid="own-first-card-hint"]');
    const dock = document.querySelector('[data-testid="action-dock"]');
    const pr = points?.getBoundingClientRect();
    const hr = hint?.getBoundingClientRect();
    const dr = dock?.getBoundingClientRect();
    return {
      cards,
      points: pr ? { x: pr.x, y: pr.y, width: pr.width, height: pr.height } : null,
      hint: hr ? { x: hr.x, y: hr.y, width: hr.width, height: hr.height } : null,
      dock: dr ? { x: dr.x, y: dr.y, width: dr.width, height: dr.height } : null,
    };
  });

  expect(data.cards.length).toBeGreaterThanOrEqual(2);
  for (let i = 0; i < data.cards.length - 1; i++) {
    const visible = data.cards[i + 1].left - data.cards[i].left;
    const fraction = visible / data.cards[i].width;
    // Disseny aprovat: cartes més grans, ventall més tancat (≥20% visible).
    expect(fraction).toBeGreaterThanOrEqual(0.2);
  }

  if (data.points) {
    for (const card of data.cards) {
      const cardRect = {
        x: card.left,
        y: card.top,
        width: card.width,
        height: card.bottom - card.top,
      };
      expect(rectsOverlap(data.points, cardRect)).toBe(false);
    }
    if (data.dock) {
      expect(rectsOverlap(data.points, data.dock)).toBe(false);
    }
  }

  if (data.hint && data.dock) {
    expect(rectsOverlap(data.hint, data.dock)).toBe(false);
  }

  if (data.cards.length && data.dock) {
    for (const card of data.cards) {
      const cardRect = {
        x: card.left,
        y: card.top,
        width: card.width,
        height: card.bottom - card.top,
      };
      expect(rectsOverlap(cardRect, data.dock)).toBe(false);
    }
  }
}

for (const vp of VIEWPORTS) {
  test.describe(`dock mòbil ${vp.tag}`, () => {
    test.use({ viewport: { width: vp.width, height: vp.height } });

    for (const practice of [false, true] as const) {
      test(`accions visibles (${practice ? "pràctica" : "normal"}, ${vp.tag})`, async ({ page }) => {
        const playerId = e2ePoolId();
        const snapshot = playingTurnSnapshotJson(playerId, "DockTest", 2, practice);
        await seedLocalSolo(page, snapshot, playerId, "DockTest");
        await page.route("**/socket.io/**", (route) => route.abort());
        await page.goto("/");
        await assertActionButtons(page);
        await assertNoHorizontalOverflow(page);
        await assertHandFanAndPoints(page);
      });
    }

    for (const cardCount of [2, 3, 4, 5] as const) {
      test(`ventall ${cardCount} cartes ≥40% visible (${vp.tag})`, async ({ page }) => {
        const playerId = e2ePoolId();
        const snapshot = playingTurnSnapshotJson(playerId, "FanTest", cardCount, false);
        await seedLocalSolo(page, snapshot, playerId, "FanTest");
        await page.route("**/socket.io/**", (route) => route.abort());
        await page.goto("/");
        await expect(page.getByTestId("local-hand-card").first()).toBeVisible({ timeout: 30_000 });
        await assertHandFanAndPoints(page);
        await assertNoHorizontalOverflow(page);
      });
    }
  });
}
