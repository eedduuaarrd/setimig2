import { expect, test, type Browser, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";
import { passAgeGateToLobby } from "./helpers/ageGateLobby";
import { openFriendsLobby } from "./helpers/friendsLobby";

/**
 * v178: doblar complet (llavor 3), el Mort a la vista del rival (llavor 4) i els retocs del vídeo de les 23:03
 * (píndola de resultat, aposta/saldo, «Tu» a la fila, Pot sense «7½», etiqueta del focus).
 * Cal SETIMIG_TEST_DECK_SEED (docs/baralla-de-prova.md).
 */
const SEED = process.env.SETIMIG_TEST_DECK_SEED;
type Box = { x: number; y: number; width: number; height: number };
const overlap = (a: Box, b: Box) =>
  a.x < b.x + b.width - 1 && b.x < a.x + a.width - 1 && a.y < b.y + b.height - 1 && b.y < a.y + a.height - 1;
const num = (s: string) => Number(s.replace(/[^\d]/g, ""));

async function startSolo(page: Page, bots: number, confirm = true) {
  await seedE2eSession(page, e2ePoolId());
  await page.addInitScript(() => {
    if (sessionStorage.getItem("qa_llavor") === "1") return;
    sessionStorage.setItem("qa_llavor", "1");
    for (const k of ["setimig_onboarding_v1", "setimig_interactive_tutorial_v1", "setimig_table_tutorial_v1", "setimig_house_rules_enabled"]) localStorage.setItem(k, "1");
    localStorage.setItem("setimig.locale", "ca");
    localStorage.setItem("setimig_player_name", "Test Llavor");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
    sessionStorage.setItem("setimig_intro_launch_v1", "1");
  });
  await page.goto("/");
  const skip = page.getByTestId("interactive-tutorial-skip");
  await expect(page.getByTestId("lobby-context").or(skip).first()).toBeVisible({ timeout: 45_000 });
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  await page.getByTestId(`ai-bot-count-${bots}`).click();
  const cb = page.getByTestId("house-rules-toggle").locator("input");
  if ((await cb.count()) && !(await cb.isChecked())) await cb.check({ force: true });
  await page.getByTestId("ai-bot-picker-start").click();
  if (confirm) await page.getByTestId("bet-confirm").filter({ visible: true }).first().click({ timeout: 30_000 });
}

const grab = (page: Page) => page.getByTestId("peek-curl-grab").filter({ visible: true }).first();
const host = (page: Page) => page.getByTestId("peek-curl-host").filter({ visible: true }).first();
async function swipe(page: Page) {
  await expect(grab(page)).toBeVisible({ timeout: 30_000 });
  const b = (await grab(page).boundingBox())!;
  const x = b.x + b.width / 2, y0 = b.y + b.height * 0.95, y1 = b.y + b.height * 0.3;
  await page.mouse.move(x, y0);
  await page.mouse.down();
  for (let i = 1; i <= 8; i++) { await page.mouse.move(x, y0 + ((y1 - y0) * i) / 8); await page.waitForTimeout(40); }
  await page.mouse.up();
}
const visibleNow = (page: Page, id: string) => page.getByTestId(id).filter({ visible: true }).first().isVisible({ timeout: 400 }).catch(() => false);

/** Planta (només al torn propi) fins que surt el full de liquidació. */
async function untilSettlement(page: Page, onStep?: (i: number) => Promise<void>) {
  const sheet = page.getByTestId("settlement-sheet");
  for (let i = 0; i < 150 && !(await sheet.isVisible().catch(() => false)); i++) {
    if (onStep) await onStep(i);
    const st = page.getByTestId("action-stand").filter({ visible: true }).first();
    if (await st.isVisible({ timeout: 300 }).catch(() => false)) await st.click({ timeout: 2_000 }).catch(() => {});
    await page.waitForTimeout(700);
  }
  await expect(sheet).toBeVisible();
}

test.describe("Doblar complet v178 @390x844", () => {
  test.use({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  test("Doblar ×2: aposta ×2, saldo −aposta, una carta, torn tancat en plantar i liquidació doble", async ({ page }) => {
    test.skip(SEED !== "3", "cal SETIMIG_TEST_DECK_SEED=3");
    await startSolo(page, 1);
    await swipe(page);
    const dbl = page.getByTestId("mobile-double-chip").filter({ visible: true }).first();
    await expect(dbl).toBeVisible({ timeout: 15_000 });
    const bet0 = num(await page.getByTestId("own-bet-amount").first().innerText());
    const bal0 = num(await page.getByTestId("own-bet-balance").first().innerText());
    expect(bet0).toBeGreaterThan(0);
    const cards0 = await page.locator("[data-card-id]").evaluateAll((es) => new Set(es.map((e) => e.getAttribute("data-card-id"))).size);
    await dbl.click();
    await expect(page.getByTestId("mobile-double-chip")).toHaveCount(0, { timeout: 10_000 });
    await expect.poll(async () => num(await page.getByTestId("own-bet-amount").first().innerText()), { timeout: 10_000 }).toBe(bet0 * 2);
    expect(num(await page.getByTestId("own-bet-balance").first().innerText()), "el saldo baixa l'import extra").toBe(bal0 - bet0);
    await page.waitForTimeout(1500);
    const cards1 = await page.locator("[data-card-id]").evaluateAll((es) => new Set(es.map((e) => e.getAttribute("data-card-id"))).size);
    expect(cards1 - cards0, "una sola carta").toBe(1);
    // Regla del motor (docs/baralla-de-prova.md): «Doblar no planta». Després de doblar no es torna a doblar;
    // plantar-se tanca el torn i ja no queda cap acció pròpia.
    console.log(`[v178] doblar: aposta ${bet0}→${bet0 * 2}, saldo ${bal0}→${bal0 - bet0}, demanar visible=${await visibleNow(page, "action-hit")}`);
    const stand = page.getByTestId("action-stand").filter({ visible: true }).first();
    if (await stand.isVisible({ timeout: 2_000 }).catch(() => false)) await stand.click();
    await expect.poll(() => visibleNow(page, "action-stand"), { timeout: 10_000 }).toBe(false);
    expect(await visibleNow(page, "action-hit"), "torn tancat: sense «Demanar»").toBe(false);
    expect(await visibleNow(page, "mobile-double-chip"), "no es torna a doblar").toBe(false);
    await untilSettlement(page);
    const row = page.locator('[data-testid="settlement-result-row"][data-self="true"]').first();
    await expect(row).toBeVisible();
    const txt = await row.innerText();
    const delta = num(txt.split("\n").pop() ?? txt);
    const outcome = await row.getAttribute("data-outcome");
    console.log(`[v178] liquidació pròpia: ${outcome} «${txt.replace(/\n/g, " | ")}»`);
    if (outcome !== "push") expect([bet0 * 2, bet0 * 4], "paga o cobra el doble").toContain(delta);
  });
});

test.describe("Mort a la vista del rival v178 @390x844", () => {
  test("acceptar el Mort: el 7 queda destapat al client propi i al del rival", async ({ browser }) => {
    // A una taula privada el sorteig de banca gasta les dues primeres cartes del munt: amb la llavor 4 el 7
    // va al sorteig. La llavor 46 hi posa el 3 i el 6, i el 7 d'oros és la carta inicial de qui no banca.
    test.skip(SEED !== "46", "cal SETIMIG_TEST_DECK_SEED=46 (Mort a taula privada; docs/baralla-de-prova.md)");
    test.setTimeout(240_000);
    const [a, b] = await twoAtTable(browser);
    // Qui no fa de banca rep el 7 d'espases: l'oferta del Mort surt quan mira la carta.
    let me: Page | null = null;
    for (let i = 0; i < 60 && !me; i++) {
      for (const p of [a, b]) {
        const bet = p.getByTestId("bet-confirm").filter({ visible: true }).first();
        if (await bet.isVisible({ timeout: 200 }).catch(() => false)) await bet.click({ timeout: 2_000 }).catch(() => {});
        // El torn propi: «Demanar»/«Plantar-se» només surten a qui juga (des del #317); la banca també té carta tapada.
        if ((await visibleNow(p, "action-hit")) || (await visibleNow(p, "action-stand"))) { me = p; break; }
      }
      await a.waitForTimeout(500);
    }
    expect(me, "un dels dos té el torn amb la carta tapada").not.toBeNull();
    const rival = me === a ? b : a;
    const id = (await host(me!).locator("[data-card-id]").first().getAttribute("data-card-id"))!;
    await swipe(me!);
    await me!.getByTestId("mort-accept").click({ timeout: 20_000 });
    await expect(me!.locator(`[data-card-id="${id}"][data-face="up"]`).first()).toBeVisible({ timeout: 8_000 });
    await expect(rival.locator(`[data-card-id="${id}"][data-face="up"]`).first(), "el rival veu el 7 destapat").toBeVisible({ timeout: 10_000 });
    await expect(rival.locator(`[data-card-id="${id}"][data-face="down"]`).filter({ visible: true })).toHaveCount(0);
  });
});

async function twoAtTable(browser: Browser): Promise<[Page, Page]> {
  const vp = { viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true };
  const a = await (await browser.newContext(vp)).newPage();
  const b = await (await browser.newContext(vp)).newPage();
  for (const p of [a, b]) await p.addInitScript(() => {
    for (const k of ["setimig_table_tutorial_v1"]) localStorage.setItem(k, "1");
    sessionStorage.setItem("setimig_intro_launch_v1", "1");
  });
  await passAgeGateToLobby(a, "Amfitrio", { online: true });
  await openFriendsLobby(a);
  const cb = a.getByTestId("house-rules-toggle").locator("input");
  if ((await cb.count()) && !(await cb.isChecked())) await cb.check({ force: true });
  await a.getByTestId("create-private-table-inline").click();
  await expect(a.getByTestId("private-waiting-panel")).toBeVisible({ timeout: 30_000 });
  const code = (await a.getByTestId("private-invite-code").innerText()).trim().split(/\s+/).pop()!;
  expect(code).toMatch(/^[A-Z0-9]{4,8}$/);
  await seedE2eSession(b, e2ePoolId());
  await b.addInitScript(() => {
    localStorage.setItem("setimig_player_name", "Convidat");
    for (const k of ["setimig_onboarding_v1", "setimig_interactive_tutorial_v1"]) localStorage.setItem(k, "1");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
  });
  await b.goto(`/?t=${code}`);
  await expect(b.getByTestId("private-waiting-panel")).toBeVisible({ timeout: 30_000 });
  // Una taula privada en necessita 3: s'omple amb un bot.
  if (!(await a.getByTestId("start-game-button").isVisible({ timeout: 3_000 }).catch(() => false))) await a.getByTestId("fill-private-bots").click();
  await expect(a.getByTestId("start-game-button")).toBeVisible({ timeout: 30_000 });
  await a.getByTestId("start-game-button").click();
  return [a, b];
}

/** Retocs del vídeo de les 23:03, a 390 i a 1280. */
for (const size of [{ name: "390", width: 390, height: 844 }, { name: "1280", width: 1280, height: 800 }]) {
  const mobile = size.width < 600;
  test.describe(`Vídeo 23:03 v178 @${size.name}`, () => {
    test.use({ viewport: { width: size.width, height: size.height }, isMobile: mobile, hasTouch: mobile });
    test("res tapat ni retallat; el Pot és un import; l'etiqueta del focus és d'un seient real", async ({ page }) => {
      test.skip(!SEED, "cal SETIMIG_TEST_DECK_SEED");
      test.setTimeout(240_000);
      await startSolo(page, 3);
      const issues: string[] = [];
      await untilSettlement(page, async () => {
        const r = await page.evaluate(() => {
          const ov = (a: DOMRect, b: DOMRect) => a.x < b.right - 1 && b.x < a.right - 1 && a.y < b.bottom - 1 && b.y < a.bottom - 1;
          const out: string[] = [];
          // (b) aposta · saldo: cap element visible a sobre (el punt de la fitxa no toca l'import).
          const amt = document.querySelector('[data-testid="own-bet-amount"]');
          const dot = document.querySelector('[data-testid="own-bet-chip-dot"]');
          const bal = document.querySelector('[data-testid="own-bet-balance"]');
          if (amt && dot && bal && amt.getBoundingClientRect().width > 0) {
            const a = amt.getBoundingClientRect(), d = dot.getBoundingClientRect(), b = bal.getBoundingClientRect();
            if (d.right > a.left - 2) out.push(`b: punt enganxat ${d.right}>${a.left}`);
            for (const r of [a, b]) {
              const top = document.elementFromPoint(r.x + r.width / 2, r.y + r.height / 2);
              if (top && top !== amt && top !== bal && !amt.contains(top) && !bal.contains(top) && !top.contains(amt) && getComputedStyle(top).pointerEvents !== "none")
                out.push(`b: tapat per ${top.className}`);
            }
          }
          // (c) «Tu» a la fila: la carta no queda retallada per cap avantpassat que retalli.
          for (const c of document.querySelectorAll('[data-seat-self="true"] .spanish-card')) {
            const r = c.getBoundingClientRect();
            if (r.top < 0) out.push(`c: fora de pantalla ${r.top}`);
            for (let p = c.parentElement; p; p = p.parentElement) {
              const cs = getComputedStyle(p);
              if (cs.overflow === "visible" && cs.overflowY === "visible" && cs.clipPath === "none") continue;
              const pr = p.getBoundingClientRect();
              if (r.top < pr.top - 1) out.push(`c: retallada per dalt per ${p.className} ${r.top}<${pr.top}`);
            }
          }
          // (d) el Pot: només etiqueta i import, cap puntuació.
          const pot = document.querySelector('[data-testid="v2-pot"]');
          if (pot) {
            const deck = pot.querySelector(".table-deck-stack");
            const after = deck ? getComputedStyle(deck, "::after").content : "none";
            if (after && after !== "none" && after !== "normal" && /\d/.test(after)) out.push(`d: el mall del Pot mostra ${after}`);
            const amount = pot.querySelector('[data-testid="v2-pot-amount"]')?.textContent ?? "";
            if (!/^[\d.,\s\u00a0]+$/.test(amount)) out.push(`d: import del Pot «${amount}»`);
          }
          // (e) l'etiqueta «Cartes de X» és d'un jugador real de la taula.
          const lbl = document.querySelector('[data-testid="focus-turn-label"]')?.textContent ?? "";
          (window as unknown as { __lbl: string[] }).__lbl = [...((window as unknown as { __lbl?: string[] }).__lbl ?? []), lbl];
          return out;
        });
        issues.push(...r);
      });
      // (a) píndoles de resultat: mai sobre les cartes del seu seient (es comprova quan la fila ja s'ha recol·locat).
      await page.waitForTimeout(1800);
      const a = await page.evaluate(() => {
        const ov = (a: DOMRect, b: DOMRect) => a.x < b.right - 1 && b.x < a.right - 1 && a.y < b.bottom - 1 && b.y < a.bottom - 1;
        const out: string[] = [];
        const badges = [...document.querySelectorAll<HTMLElement>('[data-testid="fx-result-badge"]')];
        for (const bd of badges) {
          const seat = document.querySelector(`[data-seat-player="${CSS.escape(bd.dataset.fxSeat ?? "")}"]`);
          for (const c of seat?.querySelectorAll(".spanish-card") ?? [])
            if (ov(bd.getBoundingClientRect(), c.getBoundingClientRect())) out.push(`a: «${bd.textContent}» tapa una carta del seient`);
        }
        return { out, n: badges.length };
      });
      issues.push(...a.out);
      const labels = await page.evaluate(() => (window as unknown as { __lbl?: string[] }).__lbl ?? []);
      console.log(`[v178 ${size.name}] píndoles=${a.n} etiquetes=${[...new Set(labels.filter(Boolean))].join(" / ")}`);
      expect(issues, issues.join("\n")).toEqual([]);
    });
  });
}
