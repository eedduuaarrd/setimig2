import AxeBuilder from "@axe-core/playwright";
import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eLaunch } from "./helpers/e2eSession.ts";

/** Lobby v4 · PR-L1 (lobby-v4.md §3, criteris 1–7 + axe). Només mesures calculades, sense captures. */
const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844, symbol: 192 },
  { tag: "375x667", width: 375, height: 667, symbol: 160 },
  { tag: "360x740", width: 360, height: 740, symbol: 160 },
] as const;

async function seedLobby(page: Page, _label: string, withRecent = false) {
  // Sessió real (login obligatori): compte e2e del pool + intro ja vista.
  const id = e2ePoolId();
  await seedE2eLaunch(page, id);
  await page.addInitScript(
    ({ pid, age, recent }) => {
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", "LobbyV4");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_home_intro_v1", "1");
      localStorage.setItem("setimig_age_gate", age);
      if (recent) {
        localStorage.setItem(
          "setimig_recent_tables_v1",
          JSON.stringify([
            { id: "r1", label: "Partida contra la IA", soloAi: true, at: Date.now() },
            { id: "r2", label: "Taula AB12CD", soloAi: false, inviteCode: "AB12CD", at: Date.now() - 1000 },
          ])
        );
      }
    },
    { pid: id, age: JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }), recent: withRecent }
  );
}

async function openLobby(page: Page) {
  await page.goto("/");
  await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 60_000 });
  await page.waitForTimeout(500);
  // Lobby v4.1: l'stagger acaba a 520 ms; mesura amb totes les animacions acabades.
  await page.evaluate(() => Promise.all(document.getAnimations().filter((a) => a.effect?.getComputedTiming().iterations !== Infinity).map((a) => a.finished.catch(() => undefined))));
}

async function measure(page: Page) {
  return page.evaluate(() => {
    const shell = document.querySelector(".lobby-shell") as HTMLElement;
    const main = document.querySelector("main") as HTMLElement;
    const cta = document.querySelector('[data-testid="play-vs-ai-button"]') as HTMLElement;
    const ctaRect = cta.getBoundingClientRect();
    const ctaCs = getComputedStyle(cta);
    // Logo «C · Fum daurat»: el símbol ara és un PNG decoratiu (abans, SVG inline).
    const svg = document.querySelector('[data-testid="lobby-welcome"] img[aria-hidden="true"]') as HTMLImageElement | null;
    const visible = (el: Element) => {
      const r = el.getBoundingClientRect();
      const cs = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && cs.visibility !== "hidden" && cs.display !== "none";
    };
    const small = Array.from(main.querySelectorAll("button, a, summary"))
      .filter(visible)
      .map((el) => ({ el, r: el.getBoundingClientRect() }))
      .filter(({ r }) => r.width < 44 || r.height < 44)
      .map(({ el, r }) => `${el.textContent?.trim().slice(0, 20)} ${Math.round(r.width)}x${Math.round(r.height)}`);
    const allowed = new Set(["11,11,11", "22,22,22", "31,31,31", "245,242,235", "255,255,255"]);
    const badColors: string[] = [];
    const parse = (v: string) => {
      const m = v.match(/rgba?\(([^)]+)\)/);
      if (!m) return null;
      const parts = m[1].split(/[ ,/]+/).filter(Boolean).map(Number);
      return { rgb: parts.slice(0, 3).join(","), a: parts.length > 3 ? parts[3] : 1 };
    };
    for (const el of Array.from(main.querySelectorAll("*"))) {
      if (!visible(el)) continue;
      const cs = getComputedStyle(el);
      const props: Array<[string, string]> = [
        ["color", cs.color],
        ["bg", cs.backgroundColor],
        ["bt", cs.borderTopColor],
        ["br", cs.borderRightColor],
        ["bb", cs.borderBottomColor],
        ["bl", cs.borderLeftColor],
      ];
      for (const [k, v] of props) {
        const p = parse(v);
        if (!p) {
          badColors.push(`${k}=${v}`);
          continue;
        }
        if (p.a === 0) continue;
        if (!allowed.has(p.rgb)) badColors.push(`${el.tagName.toLowerCase()}.${String(el.getAttribute("class") ?? "").slice(0, 40)} ${k}=${v}`);
      }
      if (/gradient/.test(cs.backgroundImage)) badColors.push(`${el.tagName.toLowerCase()} gradient`);
      if (cs.boxShadow !== "none") badColors.push(`${el.tagName.toLowerCase()} box-shadow ${cs.boxShadow}`);
    }
    return {
      shellScroll: shell.scrollHeight,
      shellClient: shell.clientHeight,
      docScroll: document.documentElement.scrollHeight,
      innerHeight: window.innerHeight,
      ctaBottom: ctaRect.bottom,
      ctaHeight: ctaRect.height,
      ctaBg: ctaCs.backgroundColor,
      ctaColor: ctaCs.color,
      ctaFont: `${ctaCs.fontFamily.split(",")[0]} ${ctaCs.fontWeight} ${ctaCs.fontSize}`,
      svgHeight: svg ? svg.getBoundingClientRect().height : 0,
      logoSrc: svg?.getAttribute("src") ?? "",
      logoBorder: svg ? getComputedStyle(svg).borderTopWidth : null,
      small,
      badColors: Array.from(new Set(badColors)),
      emoji: /\p{Extended_Pictographic}/u.test(main.innerText),
      hasGuide: !!document.querySelector('[data-testid="lobby-quick-guide"]'),
      recentRows: document.querySelectorAll('[data-testid="lobby-recent-tables"]').length,
      rewardsHidden: (document.querySelector('[data-slot="rewards"]') as HTMLElement | null)?.hidden ?? null,
    };
  });
}

for (const vp of VIEWPORTS) {
  test.describe(`lobby v4 L1 ${vp.tag}`, () => {
    test.use({ viewport: { width: vp.width, height: vp.height } });

    test(`criteris 1–6 i axe (${vp.tag})`, async ({ page }) => {
      await seedLobby(page, `lobby-v4-${vp.tag}`);
      await openLobby(page);
      await expect(page.locator("main").getByRole("button", { name: /^Jugar$/ })).toBeVisible();
      const m = await measure(page);
      console.log(`[lobby-v4] ${vp.tag} ${JSON.stringify(m)}`);
      // 1. Sense scroll.
      expect(m.shellScroll).toBeLessThanOrEqual(m.shellClient);
      expect(m.docScroll).toBeLessThanOrEqual(m.innerHeight);
      // 2. CTA «Jugar» (lobby v4.1 C3: el grup es centra; el bottom passa a 55–68 % de H).
      expect(m.ctaBottom).toBeGreaterThanOrEqual(m.innerHeight * 0.55);
      expect(m.ctaBottom).toBeLessThanOrEqual(m.innerHeight * 0.68);
      expect(m.ctaHeight).toBeGreaterThanOrEqual(52);
      expect(m.ctaHeight).toBeLessThanOrEqual(56);
      expect(m.ctaBg).toBe("rgb(245, 242, 235)");
      expect(m.ctaColor).toBe("rgb(11, 11, 11)");
      // 3. Símbol del hero (v163 més gran), PNG transparent sense filet.
      expect(m.svgHeight).toBeGreaterThanOrEqual(vp.symbol);
      // v163: cartes a min(45vw, 30vh) + halo esvaït (logo-splash-v163.png); cap ≤ 50 % de l'alçada.
      expect(m.svgHeight).toBeLessThanOrEqual(vp.height * 0.5);
      expect(m.logoSrc).toContain("/brand/logo-splash-v163");
      expect(m.logoBorder).toBe("0px");
      // 4. Objectius ≥ 44×44.
      expect(m.small).toEqual([]);
      // 5. Només tokens v3, sense or, gradients ni ombres.
      expect(m.badColors).toEqual([]);
      // 6. Sense emojis.
      expect(m.emoji).toBe(false);
      expect(m.hasGuide).toBe(false);
      expect(m.rewardsHidden).toBe(true);

      const axe = await new AxeBuilder({ page }).analyze();
      expect(axe.violations.map((v) => `${v.id}: ${v.nodes.map((n) => n.target.join(" ")).join(" | ")}`)).toEqual([]);
    });

    test(`criteri 7: ordre de Tab i focus visible (${vp.tag})`, async ({ page }) => {
      await seedLobby(page, `lobby-v4-tab-${vp.tag}`);
      await openLobby(page);
      const seen: Array<{ name: string; outline: string; width: string }> = [];
      for (let i = 0; i < 25 && seen.length < 3; i += 1) {
        await page.keyboard.press("Tab");
        const f = await page.evaluate(() => {
          const el = document.activeElement as HTMLElement | null;
          if (!el || !el.closest("main")) return null;
          const cs = getComputedStyle(el);
          return { name: (el.getAttribute("aria-label") ?? el.textContent ?? "").trim(), outline: cs.outlineStyle, width: cs.outlineWidth, fv: el.matches(":focus-visible") };
        });
        if (f) {
          expect(f.fv).toBe(true);
          seen.push({ name: f.name, outline: f.outline, width: f.width });
        }
      }
      console.log(`[lobby-v4] tab ${vp.tag} ${JSON.stringify(seen)}`);
      // Lobby v4.1 C5: la línia de context és el 2n objectiu (obre la configuració).
      expect(seen.map((s) => s.name)).toEqual(["Jugar", "Contra 3 rivals · Normal", "Amb amics"]);
      for (const s of seen) {
        expect(s.outline).not.toBe("none");
        expect(s.width).toBe("2px");
      }
    });

    test(`amb partides recents: lobby v4.1 C1 ja no les mostra, sense scroll (${vp.tag})`, async ({ page }) => {
      await seedLobby(page, `lobby-v4-rec-${vp.tag}`, true);
      await openLobby(page);
      const m = await measure(page);
      console.log(`[lobby-v4] recents ${vp.tag} shell ${m.shellScroll}/${m.shellClient} doc ${m.docScroll}/${m.innerHeight}`);
      expect(m.recentRows).toBe(0);
      expect(m.shellScroll).toBeLessThanOrEqual(m.shellClient);
      expect(m.docScroll).toBeLessThanOrEqual(m.innerHeight);
      expect(m.ctaBottom).toBeLessThanOrEqual(m.innerHeight * 0.68);
      expect(m.small).toEqual([]);
      expect(m.badColors).toEqual([]);
    });

    test(`«Com jugar» obre el tutorial (${vp.tag})`, async ({ page }) => {
      await seedLobby(page, `lobby-v4-tut-${vp.tag}`);
      await openLobby(page);
      await page.getByTestId("lobby-open-tutorial").click();
      await expect(page.getByRole("dialog").first()).toBeVisible({ timeout: 10_000 });
    });
  });
}
