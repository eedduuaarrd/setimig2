import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/** Normes de la casa (PR #282): oferta «Jugar/Canviar» del 3 i el 4, i revelació del Mort. Només mesures. */
type Card = { suit: "hearts" | "diamonds" | "clubs" | "spades"; value: number; points: number };
const card = (value: number, suit: Card["suit"] = "hearts"): Card => ({ suit, value, points: value >= 10 ? 0.5 : value });
const FIGURES = Array.from({ length: 12 }, (_, i) => card(10 + (i % 3), (["hearts", "diamonds", "clubs", "spades"] as const)[i % 4]));

function slot(id: string, cards: { c: Card; up: boolean }[], bet: number, status: string, extra: Record<string, unknown> = {}) {
  return {
    id, bet, status, doubled: false, canDouble: false, mort: false, blindPair: false, blindUntilBankEnd: false, mortOffered: false,
    cards: cards.map((x, i) => ({ id: `${id}-c${i}`, card: x.c, faceUp: x.up })),
    ...extra,
  };
}
function seat(id: string, name: string, isBanker: boolean, isBot: boolean, bet: number, status: string, hand: ReturnType<typeof slot>) {
  return {
    id, playerId: id.startsWith("local-human-") ? id.slice(12) : id, seatToken: `${id}-token`, name,
    chips: isBanker ? 5000 : 900, bet, isBanker, isBot, status, handSlots: [hand], activeSlotIndex: 0, lastRoyal7Payout: 0, royal7AsBankerStreak: 0,
  };
}
function snapshot(pid: string, room: Record<string, unknown>): string {
  return JSON.stringify({
    version: 1, playerId: pid, playerName: "Edu", botCount: 1, difficulty: "normal",
    room: {
      id: `local-normes-${pid}`, name: "Partida IA", pot: 100, minBet: 100, jackpot: 0, lastRound: null, centerDiscard: [],
      soloAi: true, soloHumanPlayerId: pid, soloBotCount: 1,
      sessionStats: [[pid, { handsPlayed: 2, handsWon: 0, netCf: 0, winStreak: 0, lastOutcome: null }]],
      matchProgress: { handNumber: 3, totalHands: 10 }, matchEnded: false, matchResult: null, houseRulesEnabled: true,
      turnDeadlineAt: Date.now() + 60_000, deck: FIGURES, ...room,
    },
  });
}
const human = (pid: string) => `local-human-${pid}`;
async function seed(page: Page, snap: string, pid: string) {
  await seedE2eSession(page, pid);
  await page.addInitScript(({ snap, pid }) => {
    if (sessionStorage.getItem("normes_seeded") === "1") return;
    sessionStorage.setItem("normes_seeded", "1");
    localStorage.setItem("setimig_player_id", pid);
    localStorage.setItem("setimig_player_name", "Edu");
    localStorage.setItem("setimig_onboarding_v1", "1");
    localStorage.setItem("setimig_interactive_tutorial_v1", "1");
    localStorage.setItem("setimig_table_tutorial_v1", "1");
    localStorage.setItem("setimig_house_rules_enabled", "1");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
    localStorage.setItem("setimig_local_solo_snapshot", snap);
    sessionStorage.setItem("setimig_solo_rejoin", "1");
    sessionStorage.setItem("setimig_solo_local", "1");
  }, { snap, pid });
  await page.route("**/socket.io/**", (route) => route.abort());
}


/** v155 (Edu): en el peek es veu l'índex; Demanar/Plantar-se sempre visibles; revelar és secundari; ajuda sencera. */
function snap7(pid: string, mortOffered: boolean) {
  return snapshot(pid, {
    phase: "playing", turnPlayerIndex: 0,
    players: [
      seat(human(pid), "Edu", false, false, 100, "playing", slot(`${human(pid)}-hand`, [{ c: card(7, "clubs"), up: false }], 100, "playing", { mortOffered })),
      seat("bot-n-bank", "Laia", true, true, 0, "playing", slot("bot-n-bank-hand", [{ c: card(5, "clubs"), up: false }], 0, "playing")),
    ],
  });
}

async function mainActions(page: Page) {
  const hit = page.getByTestId("action-hit");
  const stand = page.getByTestId("action-stand");
  await expect(hit).toBeVisible({ timeout: 20_000 });
  await expect(stand).toBeVisible();
  await expect(hit).toBeInViewport();
  await expect(stand).toBeInViewport();
  const hb = (await hit.boundingBox())!;
  const sb = (await stand.boundingBox())!;
  expect(hb.height).toBeGreaterThanOrEqual(44);
  expect(sb.height).toBeGreaterThanOrEqual(44);
  // Cap element per sobre del centre dels botons.
  for (const loc of [hit, stand]) {
    const top = await loc.evaluate((el) => {
      const r = el.getBoundingClientRect();
      const t = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
      const ok = !!t && (el === t || el.contains(t)); return ok;
    });
    expect(top, "el botó principal no queda tapat").toBeTruthy();
  }
  return { hb, sb };
}

for (const vp of [{ w: 390, h: 844 }, { w: 1280, h: 800 }]) {
  for (const mort of [false, true]) {
    test(`v155: Demanar/Plantar-se visibles i revelar secundari (${vp.w}${mort ? ", oferta Mort" : ""})`, async ({ page }) => {
      await page.setViewportSize({ width: vp.w, height: vp.h });
      const pid = e2ePoolId();
      await seed(page, snap7(pid, mort), pid);
      await page.goto("/");
      await expect(page.getByTestId("home-intro")).toHaveCount(0, { timeout: 45_000 });
      const { hb } = await mainActions(page);
      const reveal = page.getByTestId("reveal-card-action");
      if (await reveal.count()) {
        const rb = (await reveal.first().boundingBox())!;
        expect(rb.height).toBeLessThanOrEqual(hb.height);
        const fs = async (l: typeof reveal) => parseFloat(await l.first().evaluate((el) => getComputedStyle(el).fontSize));
        expect(await fs(reveal)).toBeLessThanOrEqual(await fs(page.getByTestId("action-hit")));
      }
      const hint = page.getByTestId("reveal-card-rule-hint");
      if (await hint.count()) {
        const m = await hint.evaluate((el) => {
          const r = el.getBoundingClientRect();
          let clipped = el.scrollWidth > el.clientWidth + 1 || el.scrollHeight > el.clientHeight + 1;
          let p = el.parentElement;
          while (p && p !== document.body && !clipped) {
            const cs = getComputedStyle(p);
            const pr = p.getBoundingClientRect();
            if (/(hidden|clip)/.test(cs.overflow + cs.overflowX + cs.overflowY) && (r.top < pr.top - 1 || r.bottom > pr.bottom + 1 || r.left < pr.left - 1 || r.right > pr.right + 1)) clipped = true;
            p = p.parentElement;
          }
          return { clipped, l: r.left, r: r.right, iw: innerWidth };
        });
        expect(m.clipped, JSON.stringify(m)).toBeFalsy();
        expect(m.l).toBeGreaterThanOrEqual(0);
        expect(m.r).toBeLessThanOrEqual(m.iw);
      }
    });
  }

  test(`v155: en el peek la regió destapada inclou l'índex i no demana carta (${vp.w})`, async ({ page }) => {
    await page.setViewportSize({ width: vp.w, height: vp.h });
    const pid = e2ePoolId();
    await seed(page, snap7(pid, false), pid);
    await page.goto("/");
    const grab = page.getByTestId("peek-curl-grab").first();
    await expect(grab).toBeVisible({ timeout: 45_000 });
    await expect(page.getByTestId("home-intro")).toHaveCount(0, { timeout: 15_000 });
    const count = () => page.locator('[data-testid="local-hand-card"], .desktop-own-hand > *').count();
    const before = await count();
    const host = page.getByTestId("peek-curl-host").first();
    const hbox = (await host.boundingBox())!;
    const gb = (await grab.boundingBox())!;
    const fire = (phase: "down" | "move" | "up", y: number) =>
      grab.evaluate((el, a) => {
        const type = a.phase === "down" ? "pointerdown" : a.phase === "move" ? "pointermove" : "pointerup";
        (a.phase === "down" ? el : window).dispatchEvent(new PointerEvent(type, {
          bubbles: true, cancelable: true, view: window, clientX: a.x, clientY: a.y,
          pointerId: 1, pointerType: "mouse", isPrimary: true, buttons: a.phase === "up" ? 0 : 1, button: 0,
        }));
      }, { phase, x: gb.x + gb.width / 2, y });
    const y0 = gb.y + Math.min(gb.height * 0.7, gb.height - 4);
    await fire("down", y0);
    for (const f of [0.3, 0.5, 0.7, 0.9]) {
      for (let i = 1; i <= 4; i++) { await fire("move", y0 - hbox.height * f * (i / 4)); await page.waitForTimeout(30); }
      await expect(host).toHaveAttribute("data-peeking", "yes");
      const top = Number(await host.getAttribute("data-face-top"));
      const rows = Number(await host.getAttribute("data-face-rows"));
      // L'índex és a la cantonada de dalt de la cara (≈ 0–20 % de l'alçada): la cara destapada comença dins la carta.
      expect(top, `face-top a ${f}`).toBeGreaterThanOrEqual(-0.005);
      if (f >= 0.5) expect(rows, `face-rows a ${f}`).toBeGreaterThanOrEqual(0.2);
    }
    await fire("up", y0 - hbox.height * 0.9);
    await page.waitForTimeout(1_000);
    expect(await count(), "el peek no demana carta").toBeLessThanOrEqual(before);
  });
}
