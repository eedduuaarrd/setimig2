import { expect, test, type Page } from "@playwright/test";
import { passAgeGateToLobby } from "./helpers/ageGateLobby";
import { createPrivateTable, readInviteCode } from "./helpers/tableFlow";
import { e2ePoolId } from "./helpers/e2eSession.ts";

/**
 * QA v195 (retest de la v194, tot P3 de client):
 * 1) Cap fx-flow-chip queda quieta fora d'un destí (pot o mà) més de 300 ms.
 * 2) El «+N» de la liquidació no tapa noms ni etiquetes («Es planta», «BANCA», «Banca · Nom»).
 * 3) La pastilla «Passat» queda dins de la caixa de la seva mà (1024 i 390).
 * 4) A 390, l'import de la fitxa i own-bet-chip no se solapen amb etiquetes ni amb la fila del resultat.
 * Llavors de la QA: NODE_ENV=test SETIMIG_TEST_DECK_SEED=46 (Passat a la mà 2) o 217.
 */
const SEED = process.env.SETIMIG_TEST_DECK_SEED;
const visible = (page: Page, id: string) => page.getByTestId(id).filter({ visible: true }).first();
const LABELS =
  "[data-testid=seat-name], .v2-seat-name, .seat-action-bubble, [data-testid=settled-hand-chip], [data-testid=split-hand-label], [data-testid=table-pot], [data-testid=fx-result-badge]";

async function tap(p: Page, id: string) {
  const l = visible(p, id);
  if (!(await l.isVisible().catch(() => false))) return false;
  if (!(await l.isEnabled({ timeout: 300 }).catch(() => false))) return false;
  await l.click({ timeout: 2_000 }).catch(() => {});
  return true;
}

async function twoPlayerTable(browser: import("@playwright/test").Browser, vp: { width: number; height: number }) {
  const ctxs = await Promise.all([0, 1].map(() => browser.newContext({ viewport: vp })));
  const pages = await Promise.all(ctxs.map((c) => c.newPage()));
  await passAgeGateToLobby(pages[0], "Amfitrio195", { playerId: e2ePoolId(), online: true });
  await createPrivateTable(pages[0]);
  const code = await readInviteCode(pages[0]);
  await passAgeGateToLobby(pages[1], "Convidat195", { playerId: e2ePoolId(), online: true });
  await pages[1].goto(`/?t=${code}`);
  await expect(pages[0].getByTestId("start-game-button")).toBeVisible({ timeout: 30_000 });
  await pages[0].getByTestId("start-game-button").click();
  return { ctxs, pages };
}

type Sample = {
  t: number;
  chips: { k: string; x: number; y: number; onTarget: boolean }[];
  deltaHits: string[];
  passat: string[];
  ownBet: string[];
};

/** Mostra de la liquidació al navegador del jugador. */
async function sample(p: Page): Promise<Sample> {
  return p.evaluate((LABELS) => {
    const vis = (e: Element) => {
      const r = e.getBoundingClientRect();
      if (r.width <= 0 || r.height <= 0) return null;
      let n: Element | null = e;
      while (n) {
        const s = getComputedStyle(n);
        if (s.display === "none" || s.visibility === "hidden" || Number(s.opacity) < 0.15) return null;
        n = n.parentElement;
      }
      return r;
    };
    const ov = (a: DOMRect, b: DOMRect, m = 2) => Math.min(a.right, b.right) - Math.max(a.left, b.left) > m && Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top) > m;
    const near = (a: DOMRect, b: DOMRect, pad: number) => a.left + a.width / 2 > b.left - pad && a.left + a.width / 2 < b.right + pad && a.top + a.height / 2 > b.top - pad && a.top + a.height / 2 < b.bottom + pad;
    const targets = Array.from(document.querySelectorAll(".table-deck-stack, [data-testid=v2-pot], [data-testid=table-pot], [data-seat-player], [data-testid=local-player-seat], [data-seat-fan-slot]"))
      .map(vis)
      .filter(Boolean) as DOMRect[];
    const chips = Array.from(document.querySelectorAll<HTMLElement>("[data-testid=fx-flow-chip]")).map((c, i) => {
      const r = vis(c);
      if (!r) return null;
      return { k: `${i}:${c.dataset.fxFrom ?? ""}:${c.textContent}`, x: Math.round(r.left + r.width / 2), y: Math.round(r.top + r.height / 2), onTarget: targets.some((t) => near(r, t, 32)) };
    }).filter(Boolean) as Sample["chips"];
    const labels = Array.from(document.querySelectorAll(LABELS)).map((e) => ({ e, r: vis(e) })).filter((x) => x.r) as { e: Element; r: DOMRect }[];
    const deltaHits: string[] = [];
    for (const d of Array.from(document.querySelectorAll("[data-testid=fx-chip-delta]"))) {
      const r = vis(d);
      if (!r) continue;
      for (const l of labels) if (ov(r, l.r)) deltaHits.push(`${d.textContent} sobre «${(l.e.textContent ?? "").trim().slice(0, 30)}»`);
    }
    const passat: string[] = [];
    for (const c of Array.from(document.querySelectorAll<HTMLElement>("[data-testid=settled-hand-chip]"))) {
      const r = vis(c);
      if (!r) continue;
      const host = c.parentElement!;
      const cards = Array.from(host.querySelectorAll("[data-testid=local-hand-card], [data-testid=face-hint-card], .desktop-own-hand > *")).map(vis).filter(Boolean) as DOMRect[];
      if (!cards.length) continue;
      const box = { left: Math.min(...cards.map((x) => x.left)), right: Math.max(...cards.map((x) => x.right)), top: Math.min(...cards.map((x) => x.top)), bottom: Math.max(...cards.map((x) => x.bottom)) };
      const cx = r.left + r.width / 2;
      const inside = cx >= box.left && cx <= box.right && r.bottom >= box.top - 2 && r.top <= box.bottom;
      if (!inside) passat.push(`«${c.textContent}» @${Math.round(r.left)},${Math.round(r.top)} fora de la mà ${Math.round(box.left)}-${Math.round(box.right)} × ${Math.round(box.top)}-${Math.round(box.bottom)}`);
    }
    const ownBet: string[] = [];
    const rows = Array.from(document.querySelectorAll("[data-testid=settlement-sheet] *")).filter((e) => e.children.length === 0).map(vis).filter(Boolean) as DOMRect[];
    for (const id of ["own-bet-chip", "own-bet-row"]) {
      const e = document.querySelector(`[data-testid=${id}]`);
      const r = e && vis(e);
      if (!r) continue;
      if (rows.some((q) => ov(r, q))) ownBet.push(`${id} sobre la liquidació`);
      for (const l of labels) if (ov(r, l.r)) ownBet.push(`${id} sobre «${(l.e.textContent ?? "").trim().slice(0, 30)}»`);
    }
    return { t: performance.now(), chips, deltaHits, passat, ownBet };
  }, LABELS);
}

/** Juga `hands` mans; el jugador demana carta fins que la mà acaba (`hit`) o es planta, i la banca es planta. */
async function playAndMeasure(pages: Page[], hands: number, hit: (hand: number) => boolean) {
  const out = { stuck: [] as string[], delta: [] as string[], passat: [] as string[], ownBet: [] as string[], passatSeen: 0 };
  for (let hand = 1; hand <= hands; hand++) {
    let player: Page | null = null;
    await expect.poll(async () => {
      for (const p of pages) if (await visible(p, "bet-confirm").isVisible().catch(() => false)) player = p;
      return player != null;
    }, { timeout: 60_000 }).toBe(true);
    const bank = pages.find((p) => p !== player)!;
    for (const p of pages) for (const id of ["table-tutorial-skip", "interactive-tutorial-skip"]) await p.getByTestId(id).click({ timeout: 300 }).catch(() => {});
    await visible(player!, "bet-confirm").click();
    const end = Date.now() + 90_000;
    while (Date.now() < end && !(await visible(player!, "settlement-sheet").isVisible().catch(() => false))) {
      if (!(hit(hand) ? await tap(player!, "action-hit") : false)) await tap(player!, "action-stand");
      await tap(bank, "action-stand");
      await player!.waitForTimeout(250);
    }
    await expect(visible(player!, "settlement-sheet")).toBeVisible({ timeout: 30_000 });
    // ~4,5 s de liquidació: posició de cada fitxa del flux.
    const still = new Map<string, { x: number; y: number; since: number; on: boolean }>();
    const t0 = Date.now();
    while (Date.now() - t0 < 4_500 && (await visible(player!, "settlement-sheet").isVisible().catch(() => false))) {
      const s = await sample(player!);
      for (const c of s.chips) {
        const prev = still.get(c.k);
        if (prev && Math.hypot(prev.x - c.x, prev.y - c.y) < 2) {
          if (!c.onTarget && s.t - prev.since > 300) out.stuck.push(`mà ${hand}: fitxa ${c.k} quieta a ${c.x},${c.y} ${Math.round(s.t - prev.since)} ms`);
        } else still.set(c.k, { x: c.x, y: c.y, since: s.t, on: c.onTarget });
      }
      out.delta.push(...s.deltaHits.map((d) => `mà ${hand}: ${d}`));
      out.passat.push(...s.passat.map((d) => `mà ${hand}: ${d}`));
      out.ownBet.push(...s.ownBet.map((d) => `mà ${hand}: ${d}`));
      out.passatSeen += await player!.getByTestId("settled-hand-chip").filter({ hasText: /Passat/ }).count();
      await player!.waitForTimeout(60);
    }
    await expect(visible(player!, "settlement-sheet")).toBeHidden({ timeout: 30_000 }).catch(() => {});
  }
  for (const k of ["stuck", "delta", "passat", "ownBet"] as const) out[k] = Array.from(new Set(out[k])).slice(0, 8);
  return out;
}

for (const vp of [{ width: 1024, height: 768 }, { width: 390, height: 844 }]) {
  test(`${vp.width}: fitxes sense òrfenes, «+N» lliure, «Passat» a la mà i aposta pròpia lliure`, async ({ browser }) => {
    test.setTimeout(420_000);
    const { ctxs, pages } = await twoPlayerTable(browser, vp);
    // Mà 1 i 3: es planta; mà 2: demana carta fins que acaba (amb la llavor 46, es passa).
    const r = await playAndMeasure(pages, 3, (h) => h === 2);
    expect(r.stuck, "fitxa del flux quieta fora d'un destí > 300 ms").toEqual([]);
    expect(r.delta, "«+N» damunt d'un nom o etiqueta").toEqual([]);
    expect(r.passat, "«Passat» separat de la seva mà").toEqual([]);
    if (vp.width === 390) expect(r.ownBet, "own-bet-chip o import sobre etiquetes / fila del resultat").toEqual([]);
    if (SEED === "46") expect(r.passatSeen, "la llavor 46 ha de mostrar «Passat»").toBeGreaterThan(0);
    await Promise.all(ctxs.map((c) => c.close()));
  });
}
