import { expect, test, type Page } from "@playwright/test";
import { seedE2eSession } from "./helpers/e2eSession.ts";
import { gestPeekTurnSnapshot } from "./helpers/gestLliscarFixtures.ts";

/** Taula gran (v147): sense punts propis, sense «carta segura», cartes grans al teu torn, taula ampla a PC. */
const PID = "gest-player-1";
const VIEWPORTS = [
  { width: 375, height: 667 },
  { width: 390, height: 844 },
  { width: 1280, height: 800 },
  { width: 1920, height: 1080 },
];
/** Alçada de la carta pròpia al torn abans d'aquesta PR (mesurada a main v145). */
const BEFORE_H: Record<number, number> = { 375: 158, 390: 225, 1280: 124, 1920: 205 };

async function open(page: Page) {
  await seedE2eSession(page, PID);
  await page.addInitScript(
    ({ snap, pid }) => {
      if (sessionStorage.getItem("tg_seeded") === "1") return;
      sessionStorage.setItem("tg_seeded", "1");
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", "Edu");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_house_rules_enabled", "1");
      localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
      localStorage.setItem("setimig_local_solo_snapshot", snap);
      sessionStorage.setItem("setimig_solo_rejoin", "1");
      sessionStorage.setItem("setimig_solo_local", "1");
    },
    { snap: gestPeekTurnSnapshot(PID, "Edu", "house"), pid: PID },
  );
  await page.route("**/socket.io/**", (r) => r.abort());
  await page.goto("/");
  await expect(page.getByTestId("peek-curl-host").first()).toBeVisible({ timeout: 45_000 });
  await expect(page.locator(".home-intro")).toHaveCount(0, { timeout: 15_000 });
  await page.waitForTimeout(600);
}

/** Text + aria de tota la pàgina, sense les regles. */
async function pageText(page: Page) {
  return page.evaluate(() => {
    const parts: string[] = [document.body.innerText];
    document.querySelectorAll("[aria-label],[title]").forEach((el) => {
      parts.push(el.getAttribute("aria-label") ?? "", el.getAttribute("title") ?? "");
    });
    return parts.join("\n");
  });
}

for (const vp of VIEWPORTS) {
  test.describe(`taula gran ${vp.width}`, () => {
    test.use({ viewport: vp });

    test("sense punts propis ni percentatge, carta gran i dins la pantalla", async ({ page }) => {
      await open(page);
      {
        const c = (await page.getByTestId("peek-curl-host").first().boundingBox())!;
        const r = (await page.locator(".game-table-root").first().boundingBox())!;
        const bx = (sel: string) => page.evaluate((q) => { const e = document.querySelector(q); return e ? e.getBoundingClientRect().toJSON() as DOMRect : null; }, sel);
        const ring = await bx(".game-seat-ring");
        const opp = await bx(".spanish-card-size-opponent, .spanish-card-size-bank");
        const dock = await bx(".game-action-dock");
        console.log(`[taula-gran] ${vp.width}x${vp.height} carta ${c.width.toFixed(0)}x${c.height.toFixed(0)} taula ${r.width.toFixed(0)} seients ${ring?.width.toFixed(0)} rival ${opp?.height.toFixed(0)} dock ${dock?.width.toFixed(0)}`);
      }
      const txt = await pageText(page);
      expect(txt).not.toMatch(/\b(Points|Punts|Puntos|Punti|Pontos)\b/);
      expect(txt).not.toMatch(/safe card|carta segura|carta sicura/i);
      expect(txt).not.toMatch(/\b5\s*(de|of|di)\s*(oros|diamonds|ors|denari|ouros)/i);
      await expect(page.getByTestId("my-hand-points")).toHaveCount(0);
      await expect(page.getByTestId("live-total-value")).toHaveCount(0);
      const hit = page.getByTestId("action-hit");
      await expect(hit).toBeVisible();
      expect(await hit.innerText()).not.toMatch(/%/);

      const card = page.getByTestId("peek-curl-host").first();
      const box = (await card.boundingBox())!;
      console.log(`[taula-gran] ${vp.width}x${vp.height} carta ${box.width.toFixed(0)}x${box.height.toFixed(0)}`);
      expect(box.height).toBeGreaterThanOrEqual(BEFORE_H[vp.width] * 1.4 - 1);
      expect(box.x).toBeGreaterThanOrEqual(0);
      expect(box.y).toBeGreaterThanOrEqual(0);
      expect(box.x + box.width).toBeLessThanOrEqual(vp.width);
      expect(box.y + box.height).toBeLessThanOrEqual(vp.height);
      // No tapa els botons d'acció.
      const hb = (await hit.boundingBox())!;
      const sb = (await page.getByTestId("action-stand").boundingBox())!;
      for (const b of [hb, sb]) {
        const overlap = !(box.y + box.height <= b.y || b.y + b.height <= box.y || box.x + box.width <= b.x || b.x + b.width <= box.x);
        expect(overlap).toBe(false);
        expect(b.height).toBeGreaterThanOrEqual(44);
      }
      const sw = await page.evaluate(() => document.documentElement.scrollWidth);
      expect(sw).toBeLessThanOrEqual(vp.width);

      if (vp.width >= 1280) {
        const root = (await page.locator(".game-table-root").first().boundingBox())!;
        const seats = await page.locator(".game-seat-ring").first().boundingBox();
        console.log(`[taula-gran] ${vp.width} taula ${root.width.toFixed(0)} (${((root.width / vp.width) * 100).toFixed(0)}%) seients ${seats?.width.toFixed(0)}`);
        const heightLimited = root.height >= vp.height * 0.8;
        expect(root.width >= vp.width * 0.8 || heightLimited).toBe(true);
      }
    });

    test("cap quadre a la carta pròpia amb el ratolí; el focus de teclat dels botons es veu", async ({ page }) => {
      await open(page);
      const host = page.getByTestId("peek-curl-host").first();
      const b = (await host.boundingBox())!;
      await page.mouse.click(b.x + b.width / 2, b.y + b.height / 2);
      await page.waitForTimeout(300);
      const deco = await page.evaluate(() => {
        const els = [
          ...document.querySelectorAll('[data-testid="peek-curl-host"], [data-testid="peek-curl-host"] *, .desktop-own-card, .spanish-card-turn-active'),
        ];
        return els
          .map((el) => {
            const cs = getComputedStyle(el);
            return cs.outlineStyle !== "none" && parseFloat(cs.outlineWidth) > 0 ? `outline:${el.className}` : "";
          })
          .filter(Boolean);
      });
      expect(deco).toEqual([]);
      for (let i = 0; i < 40; i++) {
        await page.keyboard.press("Tab");
        if (await page.evaluate(() => !!document.activeElement?.matches("button.game-action-button, button.reveal-card-action"))) break;
      }
      // Botó d'acció enfocat amb el teclat: l'anell continua visible.
      expect(await page.evaluate(() => document.activeElement?.tagName)).toBe("BUTTON");
      const ring = await page.evaluate(() => {
        const el = document.activeElement as HTMLElement;
        const cs = getComputedStyle(el);
        return { o: cs.outlineStyle, w: parseFloat(cs.outlineWidth), sh: cs.boxShadow };
      });
      expect(ring.o !== "none" && ring.w > 0 || ring.sh !== "none").toBe(true);
    });
  });
}

test("carta tapada: només es veu el valor mentre l'aixeques", async ({ page }) => {
  await open(page);
  const host = page.getByTestId("peek-curl-host").first();
  await expect(host.locator(".spanish-card").first()).toHaveAttribute("data-face", "down");
  await expect(host).toHaveAttribute("data-peeking", "no");
  await expect(page.locator(".spanish-card[data-face='up'][data-card-id]")).toHaveCount(0);
  const grabEl = page.getByTestId("peek-curl-grab").first();
  const hb = (await host.boundingBox())!;
  const gb = (await grabEl.boundingBox())!;
  await grabEl.evaluate((el, a) => {
    const fire = (type: string, y: number, buttons: number, on: EventTarget = el) =>
      on.dispatchEvent(new PointerEvent(type, { bubbles: true, cancelable: true, view: window, clientX: a.x, clientY: y, pointerId: 1, pointerType: "mouse", isPrimary: true, buttons, button: 0 }));
    fire("pointerdown", a.y, 1);
    for (let i = 1; i <= 30; i++) fire("pointermove", a.y - a.d * (i / 30), 1, window);
  }, { x: gb.x + gb.width / 2, y: gb.y + Math.min(gb.height * 0.7, gb.height - 4), d: hb.height * 0.35 });
  await expect(host).toHaveAttribute("data-peeking", "yes", { timeout: 1500 });
  await grabEl.evaluate((el) => window.dispatchEvent(new PointerEvent("pointerup", { bubbles: true, pointerId: 1, pointerType: "mouse", isPrimary: true })));
  await expect(host).toHaveAttribute("data-peeking", "no", { timeout: 1500 });
  await expect(host.locator(".spanish-card").first()).toHaveAttribute("data-face", "down");
});
