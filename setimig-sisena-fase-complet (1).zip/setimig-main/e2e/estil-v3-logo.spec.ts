import AxeBuilder from "@axe-core/playwright";
import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eLaunch, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * v3 · estil logo (estetica-casino-v2.md «v3»): negre #0B0B0B, superfícies #161616/#1F1F1F,
 * marfil #F5F2EB, or només al torn i al 7½ natural, radi de carta 4 px, marc art déco només
 * a la liquidació, la capçalera i la targeta principal del lobby, Cinzel + Cormorant propis.
 * Només mesures d'estils calculats: cap captura.
 */
const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844 },
  { tag: "375x667", width: 375, height: 667 },
  { tag: "360x740", width: 360, height: 740 },
] as const;

const BG = "rgb(11, 11, 11)";
const SURFACE = "rgb(22, 22, 22)";
const SURFACE_2 = "rgb(31, 31, 31)";
const IVORY = "rgb(245, 242, 235)";
const IVORY_65 = "rgba(245, 242, 235, 0.65)";

const GOLD_ALLOWED = [
  "[data-accent]",
  '[data-seat-active="true"]',
  ".seat-active",
  ".rival-strip-seat-turn",
  ".active-turn-hand-score",
  ".turn-spotlight-name",
  ".hand-sevenhalf-natural",
].join(", ");

// Lobby v4 (PR-L1): el marc és a tota la pantalla del lobby (`lobby-main`) i s'hi dibuixa amb 4 escaires
// (spans) en lloc de gradients, perquè lobby-v4.md §3 criteri 5 prohibeix background-image a la main.
const FRAME_ALLOWED = '[data-testid="app-header"], [data-testid="lobby-main"], [data-testid="settlement-sheet"]';

async function seed(page: Page, playerId: string, snapshot?: string) {
  // Sessió real (login obligatori). Al lobby, intro ja vista; amb snapshot, com els altres specs de solo.
  if (snapshot) await seedE2eSession(page, playerId);
  else await seedE2eLaunch(page, playerId);
  return page.addInitScript(
    ({ playerId, snapshot }) => {
      if (sessionStorage.getItem("setimig_e2e_seeded") === "1") return;
      sessionStorage.setItem("setimig_e2e_seeded", "1");
      localStorage.setItem("setimig_player_id", playerId);
      localStorage.setItem("setimig_player_name", "Marfil");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem(
        "setimig_age_gate",
        JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
      );
      if (snapshot) {
        const parsed = JSON.parse(snapshot) as { room?: { settlementStartedAt?: number; lastRound?: { at?: number } } };
        if (parsed.room?.settlementStartedAt) {
          parsed.room.settlementStartedAt = Date.now();
          if (parsed.room.lastRound) parsed.room.lastRound.at = Date.now();
        }
        localStorage.setItem("setimig_house_rules_enabled", "1");
        localStorage.setItem("setimig_local_solo_snapshot", JSON.stringify(parsed));
        sessionStorage.setItem("setimig_solo_rejoin", "1");
        sessionStorage.setItem("setimig_solo_local", "1");
      }
    },
    { playerId, snapshot: snapshot ?? null }
  );
}

async function axeViolations(page: Page) {
  const results = await new AxeBuilder({ page }).withTags(["wcag2a", "wcag2aa", "wcag21aa"]).analyze();
  return results.violations.map((v) => `${v.id}: ${v.nodes.map((n) => n.target.join(" ")).join(" | ")}`);
}

/** Elements visibles que pinten or (#C8A96B) fora del torn i del 7½ natural. */
async function strayGold(page: Page) {
  return page.evaluate((allowed) => {
    const GOLD = /200,\s*169,\s*107/;
    const out: string[] = [];
    for (const el of Array.from(document.querySelectorAll<HTMLElement>("body *"))) {
      // Il·lustracions SVG de les cartes (pal d'oros, figures): art de la baralla, no UI.
      if (el.closest("svg")) continue;
      const r = el.getBoundingClientRect();
      if (r.width === 0 || r.height === 0) continue;
      const cs = getComputedStyle(el);
      if (cs.visibility === "hidden" || cs.display === "none") continue;
      const paints: string[] = [cs.color, cs.backgroundColor, cs.backgroundImage, cs.boxShadow, cs.textDecorationColor];
      for (const side of ["Top", "Right", "Bottom", "Left"] as const) {
        if (parseFloat(cs.getPropertyValue(`border-${side.toLowerCase()}-width`)) > 0 && cs.getPropertyValue(`border-${side.toLowerCase()}-style`) !== "none") {
          paints.push(cs.getPropertyValue(`border-${side.toLowerCase()}-color`));
        }
      }
      if (cs.outlineStyle !== "none" && parseFloat(cs.outlineWidth) > 0) paints.push(cs.outlineColor);
      const hasText = Array.from(el.childNodes).some((n) => n.nodeType === 3 && n.textContent?.trim());
      const relevant = paints.filter((p, i) => i !== 0 || hasText);
      if (relevant.some((p) => GOLD.test(p)) && !el.closest(allowed)) {
        out.push(`${el.tagName.toLowerCase()}.${String(el.className).slice(0, 60)} «${(el.textContent ?? "").trim().slice(0, 24)}»`);
      }
    }
    return out;
  }, GOLD_ALLOWED);
}

async function frames(page: Page) {
  return page.evaluate((allowed) => {
    const all = Array.from(document.querySelectorAll<HTMLElement>(".deco-frame")).filter((el) => el.getBoundingClientRect().width > 0);
    const gradientFrames = all.filter((el) => !el.classList.contains("lobby-v4"));
    const lobby = all.filter((el) => el.classList.contains("lobby-v4"));
    return {
      stray: all.filter((el) => !el.closest(allowed)).map((el) => String(el.className).slice(0, 60)),
      corners: [
        ...gradientFrames.map((el) => (getComputedStyle(el).backgroundImage.match(/linear-gradient/g) ?? []).length),
        ...lobby.map((el) => el.querySelectorAll(":scope > .lobby-v4-corner").length * 2),
      ],
      sizes: [
        ...gradientFrames.map((el) => getComputedStyle(el).backgroundSize.includes("1.5px")),
        ...lobby.map((el) =>
          Array.from(el.querySelectorAll<HTMLElement>(":scope > .lobby-v4-corner")).every((c) => {
            const h = getComputedStyle(c, "::before");
            const v = getComputedStyle(c, "::after");
            return h.width === "14px" && h.height === "1.5px" && v.width === "1.5px" && v.height === "14px";
          })
        ),
      ],
      count: all.length,
    };
  }, FRAME_ALLOWED);
}

async function overflow(page: Page) {
  return page.evaluate(() => ({
    sw: document.documentElement.scrollWidth,
    sh: document.documentElement.scrollHeight,
    iw: window.innerWidth,
    ih: window.innerHeight,
  }));
}

for (const vp of VIEWPORTS) {
  test.describe(`estil v3 logo ${vp.tag}`, () => {
    test.use({ viewport: { width: vp.width, height: vp.height } });

    test("lobby: negre, superfície, marfil, marc a capçalera i lobby, fonts pròpies, axe 0", async ({ page }) => {
      await seed(page, e2ePoolId());
      await page.goto("/");
      await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 60_000 });
      await expect(page).toHaveTitle(/^Seven Half Club/);
      // Lobby v4.1 C1: al lobby la capçalera ja no porta la marca (només saldo i perfil).
      await expect(page.getByTestId("app-header-title")).toHaveCount(0);
      await page.waitForTimeout(650);

      const s = await page.evaluate(() => {
        const cs = (sel: string) => getComputedStyle(document.querySelector(sel) as Element);
        return {
          body: getComputedStyle(document.body).backgroundColor,
          text: getComputedStyle(document.body).color,
          card: cs('[data-testid="play-vs-ai-button"]').backgroundColor,
          eyebrow: cs(".lobby-v4-context").color,
          header: cs(".header-balance-value").fontFamily,
          headline: cs(".lobby-v4-wordmark").fontFamily,
        };
      });
      expect(s.body).toBe(BG);
      expect(s.text).toBe(IVORY);
      // Lobby v4: CTA «Jugar» marfil sòlid, línia de context al 65 % i wordmark «SET I MIG» en Cinzel.
      expect(s.card).toBe(IVORY);
      expect(s.eyebrow).toBe(IVORY_65);
      expect(s.header).toContain("Cormorant");
      expect(s.headline).toContain("Cinzel");

      const fonts = await page.evaluate(async () => {
        await Promise.all([document.fonts.load('500 14px "Cinzel"'), document.fonts.load('600 20px "Cormorant Garamond"')]);
        await document.fonts.ready;
        const woff = performance.getEntriesByType("resource").map((e) => e.name).filter((n) => n.endsWith(".woff2"));
        return {
          cinzel: document.fonts.check('500 14px "Cinzel"'),
          cormorant: document.fonts.check('600 20px "Cormorant Garamond"'),
          cinzelFile: woff.some((n) => /cinzel/i.test(n)),
          ownOrigin: woff.length > 0 && woff.every((n) => n.startsWith(location.origin)),
        };
      });
      expect(fonts).toEqual({ cinzel: true, cormorant: true, cinzelFile: true, ownOrigin: true });

      // Lobby v4.1 C4: cap .deco-frame al lobby ni a la capçalera. Logo «C · Fum daurat»: sense el marc 3:4 ni escaires.
      const f = await frames(page);
      expect(f.stray).toEqual([]);
      expect(f.count).toBe(0);
      const hero = await page.evaluate(() => {
        const img = document.querySelector<HTMLImageElement>('[data-testid="lobby-hero-symbol"]');
        const wrap = document.querySelector<HTMLElement>('[data-testid="lobby-hero-logo"]');
        const ics = img ? getComputedStyle(img) : null;
        const wcs = wrap ? getComputedStyle(wrap) : null;
        return {
          frames: document.querySelectorAll('[data-testid="lobby-hero-frame"], .lobby-v41-frame, .lobby-v4-corner').length,
          logo: !!img,
          src: img?.getAttribute("src") ?? "",
          wrapBorder: wcs?.borderTopWidth,
          imgBorder: ics?.borderTopWidth,
          imgShadow: ics?.boxShadow,
          wrapW: wrap ? Math.round(wrap.getBoundingClientRect().width) : 0,
        };
      });
      // Sense el quadrat del voltant: PNG transparent (brand/logo-splash-v163, v163) i cap filet ni ombra al wrap.
      expect(hero.frames).toBe(0);
      expect(hero.logo).toBe(true);
      expect(hero.src).toContain("/brand/logo-splash-v163");
      expect(hero.wrapBorder).toBe("0px");
      expect(hero.imgBorder).toBe("0px");
      expect(hero.imgShadow).toBe("none");
      expect(hero.wrapW).toBeGreaterThanOrEqual(160);
      expect(hero.wrapW).toBeLessThanOrEqual(200);

      expect(await strayGold(page), "or fora del torn / 7½").toEqual([]);
      const o = await overflow(page);
      expect(o.sw).toBeLessThanOrEqual(o.iw + 1);
      expect(await axeViolations(page), "axe lobby").toEqual([]);
    });


  });
}
