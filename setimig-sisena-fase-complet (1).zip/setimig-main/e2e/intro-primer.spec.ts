/**
 * Intro primer (Edu 28/10): a cada obertura de l'app l'intro és el primer que es pinta,
 * amb sessió o sense; després /login?next=… o el lobby/destí. Un cop per arrencada.
 */
import { expect, test, type Browser, type Page, type Route } from "@playwright/test";
import { blockSocketIoCtx, mockLoginSession } from "./helpers/loginSession";

const PID = "intro-player-01";
const TOKEN = "intro.token";
const WATCH = ["home-intro", "login-page", "lobby-main", "header-profile"];

async function newCtx(browser: Browser, session: boolean) {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, locale: "en-US", colorScheme: "dark", reducedMotion: "reduce" });
  await ctx.addInitScript(
    ({ session, pid, token, watch }) => {
      if (!localStorage.getItem("intro_seeded")) {
        localStorage.setItem("intro_seeded", "1");
        localStorage.setItem("setimig.locale", "en");
        localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
        if (session) {
          localStorage.setItem("setimig_player_id", pid);
          localStorage.setItem("setimig_player_token", token);
          localStorage.setItem("setimig_player_name", "Edu");
          localStorage.setItem("setimig_onboarding_v1", "1");
          localStorage.setItem("setimig_interactive_tutorial_v1", "1");
        }
      }
      const w = window as unknown as { __seen: string[]; __cls: number };
      w.__seen = [];
      w.__cls = 0;
      try {
        new PerformanceObserver((l) => {
          for (const e of l.getEntries() as unknown as { value: number; hadRecentInput: boolean }[]) if (!e.hadRecentInput) w.__cls += e.value;
        }).observe({ type: "layout-shift", buffered: true });
      } catch {
        /* no CLS API */
      }
      const scan = () => {
        for (const id of watch) {
          if (w.__seen.includes(id)) continue;
          if (document.querySelector(`[data-testid="${id}"], .${id}`)) w.__seen.push(id);
        }
      };
      new MutationObserver(scan).observe(document, { childList: true, subtree: true });
    },
    { session, pid: PID, token: TOKEN, watch: WATCH }
  );
  // El token de prova no és vàlid al servidor real: el socket no ha de connectar (connect_error auth_required esborraria la sessió).
  await ctx.routeWebSocket(/socket\.io/, () => {});
  await ctx.route(/\/socket\.io\//, (route) => route.abort());
  await ctx.route(/\/api\//, async (route: Route) => {
    const p = new URL(route.request().url()).pathname;
    if (p === "/api/auth/providers") return route.fulfill({ json: { email: true, google: true, passkey: true, rpId: "sevenhalf.club" } });
    if (p === "/api/player-session" && !route.request().headers()["authorization"]) return route.fulfill({ status: 401, json: { error: "auth_required" } });
    if (p === "/api/player-session") return route.fulfill({ json: { playerId: PID, playerToken: TOKEN } });
    if (p === "/api/balance") return route.fulfill({ json: { chips: 1000, freeClaim: { available: false, nextAt: null } } });
    if (p === "/api/auth/me") return route.fulfill({ json: { playerId: PID, emails: ["edu@example.com"], google: false, passkeys: 0, verified: true } });
    // Sense servidor real de sessions: la resta d'/api no ha de tornar 401 (esborraria la sessió).
    return route.fulfill({ status: 404, json: { error: "no", code: "NOT_FOUND" } });
  });
  return ctx;
}

const seen = (page: Page) => page.evaluate(() => (window as unknown as { __seen: string[] }).__seen);

async function expectIntroFirst(page: Page) {
  await expect.poll(() => seen(page)).toContain("home-intro");
  const s = await seen(page);
  expect(s[0]).toBe("home-intro");
  expect(s).not.toContain("login-page");
  expect(s).not.toContain("lobby-main");
  expect(s).not.toContain("header-profile");
}

for (const [label, path] of [
  ["/", "/"],
  ["deep link /com-jugar", "/com-jugar"],
  ["PWA start_url", "/?source=pwa"],
] as const) {
  test(`sense sessió · ${label}: intro primer → /login`, async ({ browser }) => {
    const ctx = await newCtx(browser, false);
    const page = await ctx.newPage();
    await page.goto(path);
    await expectIntroFirst(page);
    await expect(page).toHaveURL(/\/login(\?|$)/, { timeout: 15_000 });
    if (path === "/com-jugar") expect(new URL(page.url()).searchParams.get("next")).toBe("/com-jugar");
    await expect(page.getByTestId("login-page")).toBeVisible();
    // El login ja era a sota (sense recàrrega): l'intro s'ha retirat i no es torna a reproduir.
    await expect(page.getByTestId("launch-intro")).toHaveCount(0);
    await ctx.close();
  });

  test(`amb sessió · ${label}: intro primer → destí`, async ({ browser }) => {
    const ctx = await newCtx(browser, true);
    const page = await ctx.newPage();
    await page.goto(path);
    await expectIntroFirst(page);
    await expect(page.getByTestId("home-intro")).toHaveCount(0, { timeout: 15_000 });
    await expect(page.getByTestId("login-page")).toHaveCount(0);
    if (path === "/com-jugar") expect(new URL(page.url()).pathname).toBe("/com-jugar");
    else await expect(page.locator("button.header-profile").first()).toBeVisible({ timeout: 30_000 });
    await page.waitForTimeout(500);
    const cls = await page.evaluate(() => (window as unknown as { __cls: number }).__cls);
    expect(cls).toBeLessThan(0.1);
    await ctx.close();
  });
}

test("una nova arrencada (pestanya nova) torna a mostrar l'intro; recàrrega a la mateixa no", async ({ browser }) => {
  const ctx = await newCtx(browser, true);
  const page = await ctx.newPage();
  await page.goto("/");
  await expectIntroFirst(page);
  await expect(page.locator("button.header-profile").first()).toBeVisible({ timeout: 30_000 });
  await expect(page.getByTestId("launch-intro")).toHaveCount(0, { timeout: 15_000 });
  await page.reload();
  await expect(page.locator("button.header-profile").first()).toBeVisible({ timeout: 30_000 });
  expect(await seen(page)).not.toContain("home-intro");
  const page2 = await ctx.newPage();
  await page2.goto("/");
  await expectIntroFirst(page2);
  await ctx.close();
});

/**
 * Visita en FRED de debò (bug #264 a prod): context nou sense storageState, sense SW, sense
 * init scripts; viewport iPhone 13. Amb moviment reduït l'intro durava 320 ms i semblava que
 * anés directe a /login. Mostregem des de l'inici de la navegació quin element surt primer.
 */
const IPHONE13 = { viewport: { width: 390, height: 844 }, deviceScaleFactor: 3, isMobile: true, hasTouch: true };

async function firstSeen(page: Page, ms: number) {
  const t0 = Date.now();
  let introAt = -1;
  let loginAt = -1;
  while (Date.now() - t0 < ms && loginAt < 0) {
    const s = await page
      .evaluate(() => {
        const vis = (sel: string) => {
          const el = document.querySelector(sel) as HTMLElement | null;
          if (!el) return false;
          const r = el.getBoundingClientRect();
          return r.width > 0 && r.height > 0 && getComputedStyle(el).visibility !== "hidden";
        };
        return {
          intro: vis('[data-testid="launch-intro"]'),
          // El login es pinta a sota de l'intro amb opacitat 0: compta quan es veu de debò.
          login: (() => {
            const el = document.querySelector('[data-testid="login-page"]');
            if (!el) return false;
            let o = 1;
            for (let n: Element | null = el; n; n = n.parentElement) o *= Number(getComputedStyle(n).opacity);
            return o > 0.5;
          })(),
        };
      })
      .catch(() => null);
    if (s?.intro && introAt < 0) introAt = Date.now() - t0;
    if (s?.login && loginAt < 0) loginAt = Date.now() - t0;
    await page.waitForTimeout(40);
  }
  return { introAt, loginAt };
}

for (const motion of ["no-preference", "reduce"] as const) {
  for (const path of ["/", "/lobby"]) {
    test(`fred ${path} (${motion}): l'intro surt abans del login i després /login`, async ({ browser }) => {
      const ctx = await browser.newContext({ ...IPHONE13, storageState: { cookies: [], origins: [] }, serviceWorkers: "block", reducedMotion: motion });
      const page = await ctx.newPage();
      // Xarxa mòbil (4G): en local sense latència el buit no es reprodueix.
      const cdp = await ctx.newCDPSession(page);
      await cdp.send("Network.enable");
      await cdp.send("Network.emulateNetworkConditions", { offline: false, latency: 150, downloadThroughput: (9 * 1024 * 1024) / 8, uploadThroughput: (3 * 1024 * 1024) / 8 });
      await page.goto(path, { waitUntil: "commit" });
      const { introAt, loginAt } = await firstSeen(page, 15_000);
      expect(introAt, "l'intro ha de sortir").toBeGreaterThanOrEqual(0);
      expect(loginAt, "el login ha de sortir després").toBeGreaterThan(introAt);
      // L'intro s'ha de veure de debò (no un parpelleig), també amb moviment reduït.
      // v161: arrencada més curta (una sola splash).
      expect(loginAt - introAt).toBeGreaterThan(motion === "reduce" ? 600 : 1100);
      if (path === "/lobby") await expect(page).toHaveURL(/\/login\?next=%2Flobby$/);
      else await expect(page).toHaveURL(/\/login$/);
      expect(await page.evaluate(() => sessionStorage.getItem("setimig_intro_launch_v1"))).toBe("1");
      // Recarregar /login a la mateixa arrencada no torna a reproduir l'intro.
      await page.reload();
      await expect(page.getByTestId("login-page")).toBeVisible();
      await page.waitForTimeout(500);
      await expect(page.getByTestId("launch-intro")).toHaveCount(0);
      await ctx.close();
    });
  }
}

/**
 * Sense buit intro → destí (Orquestrador 28/10: 0,4–1,3 s en blanc a l'iPhone 13). Mostregem cada
 * fotograma (requestAnimationFrame) des de l'inici de la pàgina: l'intro o el destí (formulari de
 * login / arrel del lobby) han de ser visibles (opacitat efectiva > 0,5). Temps amb cap dels dos ≤ 150 ms,
 * i mai cap spinner ni fallback de Suspense.
 */
type GapStats = { introStart: number; introEnd: number; destAt: number; gapMs: number; maxGap: number; spinner: boolean; frames: number };

async function gapCtx(browser: Browser, motion: "no-preference" | "reduce", session: boolean) {
  const ctx = await browser.newContext({ ...IPHONE13, storageState: { cookies: [], origins: [] }, serviceWorkers: "block", reducedMotion: motion });
  if (session) {
    await mockLoginSession(ctx, PID, TOKEN);
    await blockSocketIoCtx(ctx);
  }
  await ctx.addInitScript(
    ({ session, pid, token }) => {
      if (session && !sessionStorage.getItem("gap_seeded")) {
        sessionStorage.setItem("gap_seeded", "1");
        localStorage.setItem("setimig_player_id", pid);
        localStorage.setItem("setimig_player_token", token);
        localStorage.setItem("setimig_player_name", "Edu");
        localStorage.setItem("setimig_onboarding_v1", "1");
        localStorage.setItem("setimig_interactive_tutorial_v1", "1");
        localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
      }
      const opa = (el: Element | null) => {
        if (!el) return 0;
        const r = (el as HTMLElement).getBoundingClientRect();
        if (r.width === 0 || r.height === 0) return 0;
        let o = 1;
        for (let n: Element | null = el; n && n.nodeType === 1; n = n.parentElement) {
          const cs = getComputedStyle(n);
          if (cs.visibility === "hidden" || cs.display === "none") return 0;
          o *= Number(cs.opacity);
        }
        return o;
      };
      // Estat a sessionStorage: abans del fix el destí arribava després d'una recàrrega (document nou).
      const KEY = "gap_stats";
      const prev = JSON.parse(sessionStorage.getItem(KEY) || "null");
      const g = prev ?? { introStart: -1, introEnd: -1, destAt: -1, gapMs: 0, maxGap: 0, spinner: false, frames: 0, lastAbs: -1, run: 0 };
      (window as unknown as { __gap: typeof g }).__gap = g;
      let firstFrame = true;
      const tick = (t: number) => {
        const abs = performance.timeOrigin + t;
        g.frames++;
        const intro = opa(document.querySelector('[data-testid="launch-intro"]')) > 0.5;
        const dest =
          opa(document.querySelector('[data-testid="login-page"] button, [data-testid="login-page"] h1')) > 0.5 ||
          opa(document.querySelector('[data-testid="lobby-main"], button.header-profile')) > 0.5;
        if (document.querySelector('[data-testid="app-loading-screen"]')) g.spinner = true;
        if (intro && g.introStart < 0) g.introStart = abs;
        if (intro) g.introEnd = abs;
        if (dest && g.destAt < 0 && g.introStart >= 0) g.destAt = abs;
        // Entre documents (recàrrega) el temps fins al primer fotograma nou compta com a buit.
        if (g.introStart >= 0 && g.lastAbs >= 0 && (!(intro || dest) || firstFrame)) {
          g.gapMs += abs - g.lastAbs;
          g.run += abs - g.lastAbs;
          g.maxGap = Math.max(g.maxGap, g.run);
        } else g.run = 0;
        if (intro || dest) g.run = 0;
        firstFrame = false;
        g.lastAbs = abs;
        sessionStorage.setItem(KEY, JSON.stringify(g));
        if (g.destAt < 0 || abs - g.destAt < 1000) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    },
    { session, pid: PID, token: TOKEN }
  );
  return ctx;
}

for (const motion of ["no-preference", "reduce"] as const) {
  for (const [path, session] of [["/", false], ["/lobby", false], ["/", true]] as const) {
    test(`sense buit ${path} ${session ? "amb" : "sense"} sessió (${motion}): intro → destí ≤150 ms, sense spinner`, async ({ browser }) => {
      const ctx = await gapCtx(browser, motion, session);
      const page = await ctx.newPage();
      // Xarxa mòbil (4G): en local sense latència el buit no es reprodueix.
      const cdp = await ctx.newCDPSession(page);
      await cdp.send("Network.enable");
      await cdp.send("Network.emulateNetworkConditions", { offline: false, latency: 150, downloadThroughput: (9 * 1024 * 1024) / 8, uploadThroughput: (3 * 1024 * 1024) / 8 });
      await page.goto(path, { waitUntil: "commit" });
      await expect
        .poll(() => page.evaluate(() => (window as unknown as { __gap: GapStats }).__gap.destAt), { timeout: 60_000 })
        .toBeGreaterThan(0);
      await page.waitForTimeout(1200);
      const g = await page.evaluate(() => (window as unknown as { __gap: GapStats }).__gap);
      console.log(`[gap] ${path} session=${session} ${motion}: gap=${Math.round(g.gapMs)}ms max=${Math.round(g.maxGap)}ms frames=${g.frames}`);
      expect(g.introStart, "l'intro ha de sortir").toBeGreaterThanOrEqual(0);
      expect(g.gapMs, "temps sense intro ni destí").toBeLessThanOrEqual(150);
      expect(g.spinner, "cap spinner ni fallback de Suspense").toBe(false);
      if (!session) await expect(page).toHaveURL(path === "/lobby" ? /\/login\?next=%2Flobby$/ : /\/login$/);
      else await expect(page.getByTestId("login-page")).toHaveCount(0);
      await ctx.close();
    });
  }
}

/** v180 · nova regla de l'Edu (30/10, substitueix la de 28/10): un toc durant l'intro la salta i va al menú. */
test("intro: un toc la salta i porta directe al destí", async ({ browser }) => {
  const ctx = await newCtx(browser, false);
  const page = await ctx.newPage();
  await page.emulateMedia({ reducedMotion: "no-preference" });
  await page.goto("/login");
  const intro = page.getByTestId("home-intro");
  await expect(intro).toBeVisible();
  const t0 = Date.now();
  await page.waitForTimeout(800);
  await page.mouse.click(195, 420);
  await expect(page.getByTestId("launch-intro")).toHaveCount(0, { timeout: 3_000 });
  await expect(page.getByTestId("login-page")).toBeVisible({ timeout: 5_000 });
  expect(Date.now() - t0).toBeLessThan(5_000);
  await ctx.close();
});

test("intro reduïda: un toc també la salta", async ({ browser }) => {
  const ctx = await newCtx(browser, false);
  const page = await ctx.newPage();
  await page.goto("/login");
  const intro = page.getByTestId("home-intro");
  await expect(intro).toBeVisible();
  await page.mouse.click(195, 420);
  await expect(page.getByTestId("launch-intro")).toHaveCount(0, { timeout: 3_000 });
  await ctx.close();
});
