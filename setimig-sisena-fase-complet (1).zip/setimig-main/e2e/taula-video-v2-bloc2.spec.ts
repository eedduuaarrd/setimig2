import AxeBuilder from "@axe-core/playwright";
import { expect, test, type Page } from "@playwright/test";

/**
 * Taula v2 · bloc 2 (vídeo v2): banca i rivals en una sola fila discreta (nom, cartes petites, aposta)
 * i el Pot plegat a la fila. Partida real contra bots, només mòbil vertical.
 * Mesures: fila sencera dins de la pantalla, cap carta ni píndola fora del seu seient, sense scroll,
 * fila ≤ 112 px, cap caixa de Pot a part, cap fons groc ni verd/vermell, text ≥ 12 px, axe sense
 * serious/critical i CLS ≈ 0 durant la mà. La mà del jugador (bloc 1) continua cabent sobre STAND/HIT.
 * Amb SETIMIG_V2_SHOT / SETIMIG_V2_SHOT_BANK / SETIMIG_V2_SHOT_DESKTOP desa captures per al costat a costat.
 */
const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844 },
  { tag: "375x667", width: 375, height: 667 },
  { tag: "360x740", width: 360, height: 740 },
] as const;

async function seed(page: Page, id: string) {
  await page.addInitScript((pid) => {
    localStorage.setItem("setimig_player_id", pid);
    localStorage.setItem("setimig_player_name", "Edu");
    localStorage.setItem("setimig.locale", "en");
    localStorage.setItem("setimig_onboarding_v1", "1");
    localStorage.setItem("setimig_interactive_tutorial_v1", "1");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
    // CLS acumulat (layout-shift sense input recent) per a tota la sessió.
    const w = window as unknown as { __cls: number; __clsLog: string[] };
    w.__cls = 0;
    w.__clsLog = [];
    try {
      new PerformanceObserver((list) => {
        for (const e of list.getEntries() as unknown as { value: number; hadRecentInput: boolean; sources?: { node?: Node }[] }[]) {
          if (e.hadRecentInput) continue;
          w.__cls += e.value;
          const n = e.sources?.[0]?.node as HTMLElement | undefined;
          w.__clsLog.push(`${e.value.toFixed(4)}:${n?.className?.toString().slice(0, 40) ?? n?.nodeName ?? "?"}`);
        }
      }).observe({ type: "layout-shift", buffered: true });
    } catch {
      /* sense suport */
    }
  }, id);
}

async function start(page: Page, bots: number) {
  await page.goto("/");
  // Lobby v4.1 (#181): «Jugar» ja no obre el diàleg; la línia de context sí.
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  await page.getByTestId(`ai-bot-count-${bots}`).click();
  await page.getByTestId("ai-bot-picker").getByRole("button", { name: /^(Start|Començar)$/ }).click();
}

/** Arriba al primer torn propi amb exactament 2 cartes (apostant si cal). */
async function reachTwoCardTurn(page: Page): Promise<boolean> {
  const deadline = Date.now() + 150_000;
  while (Date.now() < deadline) {
    const bet = page.getByTestId("bet-confirm");
    if ((await bet.isVisible().catch(() => false)) && (await bet.isEnabled().catch(() => false))) {
      await bet.click({ timeout: 2_000 }).catch(() => {});
      await page.waitForTimeout(400);
      continue;
    }
    const stand = page.getByTestId("action-stand");
    if ((await stand.isVisible().catch(() => false)) && (await stand.isEnabled().catch(() => false))) {
      const cards = await page.getByTestId("local-hand-card").count();
      if (cards === 2) {
        await page.waitForTimeout(700);
        if ((await stand.isEnabled().catch(() => false)) && (await page.getByTestId("local-hand-card").count()) === 2) return true;
      } else if (cards === 1) {
        await page.getByTestId("action-hit").click({ timeout: 2_000 }).catch(() => {});
        await expect
          .poll(() => page.getByTestId("local-hand-card").count(), { timeout: 8_000 })
          .toBeGreaterThanOrEqual(2)
          .catch(() => {});
      } else {
        await stand.click({ timeout: 2_000 }).catch(() => {});
      }
    }
    const next = page.getByTestId("settlement-next-hand");
    if (await next.isVisible().catch(() => false)) await next.click({ timeout: 2_000 }).catch(() => {});
    await page.waitForTimeout(300);
  }
  return false;
}

type RowMetrics = {
  vw: number;
  vh: number;
  scrollW: number;
  scrollH: number;
  row: DOMRect | null;
  seats: { name: string; banker: boolean; active: boolean; cards: number; box: DOMRect }[];
  outside: string[];
  overflowX: string[];
  potInRow: boolean;
  potText: string;
  oldPotBoxes: number;
  oldStripSeats: number;
  yellowFill: string[];
  greenRed: string[];
  smallText: string[];
  heroPanel: DOMRect | null;
  stand: DOMRect | null;
  cardH: number;
  bankNameCut: boolean;
  /** Retoc 2: espai entre la fila i el panell, i entre el contingut de la mà (panell + aposta) i la barra d'accions. */
  gapTop: number | null;
  gapBottom: number | null;
  pills: { text: string; kind: string; bg: string; color: string; ratio: number }[];
  turnOutline: string[];
};

async function measureRow(page: Page): Promise<RowMetrics> {
  return page.evaluate(() => {
    const vis = (el: Element) => {
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 0 && r.height > 0 && s.visibility !== "hidden" && s.display !== "none";
    };
    const box = (el: Element | null) => (el ? (el.getBoundingClientRect().toJSON() as DOMRect) : null);
    const row = document.querySelector('[data-testid="v2-seat-row"]');
    const seats = [...document.querySelectorAll<HTMLElement>('[data-testid="v2-seat"]')];
    const outside: string[] = [];
    const overflowX: string[] = [];
    const within = (inner: DOMRect, outer: DOMRect, tol = 0.5) =>
      inner.left >= outer.left - tol && inner.right <= outer.right + tol && inner.top >= outer.top - tol && inner.bottom <= outer.bottom + tol;
    const cells = row ? [...row.children].filter(vis) : [];
    for (const cell of cells) {
      const cb = cell.getBoundingClientRect();
      if (cb.left < -0.5 || cb.right > innerWidth + 0.5 || cb.top < -0.5 || cb.bottom > innerHeight + 0.5) outside.push(`cell@${Math.round(cb.left)},${Math.round(cb.right)}`);
      for (const part of cell.querySelectorAll(".v2-seat-card, [data-testid=v2-seat-pill], .v2-seat-bet, .table-deck-stack, .v2-pot-amount, .v2-pot-label")) {
        if (!vis(part)) continue;
        // Focus del torn: una carta que encara vola (repartiment o tornada del centre a la fila) no és el seu lloc final.
        if (part.getAnimations({ subtree: true }).some((an) => an.playState === "running")) continue;
        const pb = part.getBoundingClientRect();
        if (!within(pb, cb)) outside.push(`${(part as HTMLElement).className.toString().slice(0, 24)}@${Math.round(pb.left)}-${Math.round(pb.right)} in ${Math.round(cb.left)}-${Math.round(cb.right)}`);
      }
      for (const txt of cell.querySelectorAll<HTMLElement>(".v2-pot-amount, .v2-seat-bet, .v2-seat-timer, .v2-seat-points")) {
        if (vis(txt) && txt.scrollWidth > txt.clientWidth + 1) overflowX.push(`${txt.className.toString().slice(0, 20)}:${txt.textContent}`);
      }
    }
    const yellow = (c: string) => {
      const m = c.match(/rgba?\(([\d.]+),\s*([\d.]+),\s*([\d.]+)(?:,\s*([\d.]+))?/);
      if (!m) return false;
      const [R, G, B, A] = [+m[1], +m[2], +m[3], m[4] == null ? 1 : +m[4]];
      return A > 0.01 && R > 200 && G >= 150 && G <= 210 && B < 120;
    };
    const isGreenOrRed = (c: string) => {
      const m = c.match(/rgba?\(([\d.]+),\s*([\d.]+),\s*([\d.]+)(?:,\s*([\d.]+))?/);
      if (!m) return false;
      const [R, G, B, A] = [+m[1], +m[2], +m[3], m[4] == null ? 1 : +m[4]];
      if (A < 0.05) return false;
      const max = Math.max(R, G, B);
      const min = Math.min(R, G, B);
      if (max - min < 40) return false;
      const green = G === max && G - Math.max(R, B) > 30;
      const red = R === max && R - G > 60 && R - B > 60 && !(G > 120 && R > 180);
      return green || red;
    };
    const scope = row ? [row, ...row.querySelectorAll("*")].filter((el) => !el.closest(".spanish-card") && !el.closest(".table-deck-stack")) : [];
    const yellowFill: string[] = [];
    const greenRed: string[] = [];
    for (const el of scope) {
      if (!vis(el)) continue;
      const s = getComputedStyle(el);
      // Retoc 3: l'únic or permès a la fila és #D4AF6A a la píndola «Stands 7½» (excepció de jugabilitat v2 · ítem 3).
      const goldOk = (el as HTMLElement).matches('.v2-seat-pill[data-kind="seven"]') && s.backgroundColor === "rgb(212, 175, 106)";
      if ((yellow(s.backgroundColor) && !goldOk) || yellow(s.color) || yellow(s.borderTopColor)) yellowFill.push(`${(el as HTMLElement).className}`.slice(0, 40));
      for (const c of [s.color, s.backgroundColor, s.borderTopColor]) if (isGreenOrRed(c)) greenRed.push(`${(el as HTMLElement).className}:${c}`.slice(0, 60));
    }
    const smallText = scope
      .filter((el) => vis(el) && !el.closest(".sr-only") && [...el.childNodes].some((n) => n.nodeType === 3 && (n.textContent ?? "").trim()))
      .filter((el) => parseFloat(getComputedStyle(el).fontSize) < 12)
      .map((el) => `${(el.textContent ?? "").trim().slice(0, 20)}@${getComputedStyle(el).fontSize}`);
    const firstCard = row?.querySelector(".v2-seat-card") as HTMLElement | null;
    return {
      vw: innerWidth,
      vh: innerHeight,
      scrollW: document.documentElement.scrollWidth,
      scrollH: document.documentElement.scrollHeight,
      row: box(row),
      seats: seats.map((s) => ({
        name: (s.querySelector(".v2-seat-name")?.textContent ?? "").trim(),
        banker: s.dataset.seatBanker === "true",
        active: s.dataset.seatActive === "true",
        cards: s.querySelectorAll(".v2-seat-card").length,
        box: s.getBoundingClientRect().toJSON() as DOMRect,
      })),
      outside,
      overflowX,
      potInRow: !!row?.querySelector('[data-testid="v2-pot"] .table-deck-stack'),
      potText: (row?.querySelector('[data-testid="v2-pot"]') as HTMLElement | null)?.innerText.replace(/\s+/g, " ").trim() ?? "",
      oldPotBoxes: [...document.querySelectorAll(".table-pot-display")].filter(vis).length,
      oldStripSeats: [...document.querySelectorAll(".rival-strip-seat")].filter(vis).length,
      yellowFill,
      greenRed,
      smallText,
      heroPanel: box(document.querySelector('[data-testid="player-hero-panel"]')),
      stand: box(document.querySelector('[data-testid="action-stand"]')),
      cardH: firstCard?.offsetHeight ?? 0,
      ...(() => {
        const zone = document.querySelector<HTMLElement>('[data-testid="local-player-seat"]');
        const hero = document.querySelector('[data-testid="player-hero-panel"]');
        const dock = document.querySelector(".mobile-action-dock");
        if (!zone || !hero || !row) return { gapTop: null, gapBottom: null };
        // Contingut real de la zona (sense el padding reservat per a la barra d'accions).
        const kids = [...zone.querySelectorAll<HTMLElement>("*")].filter(vis).map((el) => el.getBoundingClientRect().bottom);
        const contentBottom = Math.max(hero.getBoundingClientRect().bottom, ...kids.filter((b) => b <= (dock?.getBoundingClientRect().top ?? innerHeight) + 0.5));
        return {
          gapTop: hero.getBoundingClientRect().top - row.getBoundingClientRect().bottom,
          gapBottom: dock ? dock.getBoundingClientRect().top - contentBottom : null,
        };
      })(),
      pills: [...document.querySelectorAll<HTMLElement>('[data-testid="v2-seat-pill"]')].filter(vis).map((el) => {
        const s = getComputedStyle(el);
        const rgb = (c: string) => (c.match(/[\d.]+/g) ?? []).slice(0, 3).map(Number);
        const lum = (c: number[]) => {
          const f = (v: number) => {
            const x = v / 255;
            return x <= 0.03928 ? x / 12.92 : ((x + 0.055) / 1.055) ** 2.4;
          };
          return 0.2126 * f(c[0]!) + 0.7152 * f(c[1]!) + 0.0722 * f(c[2]!);
        };
        const a = lum(rgb(s.backgroundColor));
        const b = lum(rgb(s.color));
        return {
          text: (el.textContent ?? "").trim(),
          kind: el.dataset.kind ?? "",
          bg: s.backgroundColor,
          color: s.color,
          ratio: (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05),
        };
      }),
      // Retoc 3: el filet de torn (::before) és ivori, mai or.
      turnOutline: [...document.querySelectorAll<HTMLElement>('.v2-seat[data-seat-active="true"]')].map(
        (el) => getComputedStyle(el, "::before").borderTopColor
      ),
      bankNameCut: (() => {
        const n = row?.querySelector<HTMLElement>('[data-seat-banker="true"] .v2-seat-name');
        return !!n && n.scrollWidth > n.clientWidth + 1;
      })(),
    };
  });
}

function expectRow(m: RowMetrics, vp: { width: number; height: number }, label: string) {
  expect(m.row, `${label}: fila present`).not.toBeNull();
  expect(m.oldStripSeats, `${label}: sense la tira antiga de seients`).toBe(0);
  expect(m.oldPotBoxes, `${label}: cap caixa de Pot a part`).toBe(0);
  expect(m.potInRow, `${label}: Pot (i mall) dins de la fila`).toBe(true);
  expect(m.potText).toMatch(/pot\s*[\d.,]+/i);
  expect(m.row!.height, `${label}: fila compacta`).toBeLessThanOrEqual(112);
  expect(m.row!.left).toBeGreaterThanOrEqual(-0.5);
  expect(m.row!.right).toBeLessThanOrEqual(vp.width + 0.5);
  expect(m.row!.top).toBeGreaterThanOrEqual(0);
  expect(m.outside, `${label}: res fora del seu seient ni de la pantalla`).toEqual([]);
  expect(m.overflowX, `${label}: imports sencers`).toEqual([]);
  expect(m.scrollW, `${label}: sense desbordament horitzontal`).toBeLessThanOrEqual(vp.width);
  expect(m.scrollH, `${label}: sense scroll vertical`).toBeLessThanOrEqual(vp.height);
  expect(m.yellowFill, `${label}: cap groc a la fila`).toEqual([]);
  expect(m.greenRed, `${label}: cap verd ni vermell a la fila`).toEqual([]);
  expect(m.smallText, `${label}: res < 12 px`).toEqual([]);
  const bank = m.seats.find((s) => s.banker);
  if (bank) {
    expect(bank.name).toMatch(/^Bank · .+/);
    expect(m.bankNameCut, `${label}: «Bank · nom» sencer`).toBe(false);
  }
  for (const p of m.pills) {
    expect(p.ratio, `${label}: contrast de la píndola «${p.text}» (${p.bg} / ${p.color})`).toBeGreaterThanOrEqual(4.5);
    expect(p.bg, `${label}: píndola sòlida`).not.toMatch(/rgba\(.*,\s*0(\.\d+)?\)$/);
    // Retoc 3 + animació 03: «Stands 7½» or; «Bust · …» píndola apagada #1C1C18; la resta ivori.
    if (p.kind === "seven") {
      expect(p.bg, `${label}: «${p.text}» en or`).toBe("rgb(212, 175, 106)");
      expect(p.color).toBe("rgb(20, 19, 15)");
    } else if (p.kind === "bust") {
      expect(p.bg, `${label}: «${p.text}» apagada`).toBe("rgb(28, 28, 24)");
      expect(p.color, `${label}: text ivori del Bust`).toMatch(/^rgba?\(245,\s*242,\s*235/);
    } else {
      expect(["rgb(245, 242, 235)", "rgb(169, 165, 156)"], `${label}: «${p.text}» sense or`).toContain(p.bg);
      expect(p.color).toBe("rgb(20, 19, 15)");
    }
  }
  for (const c of m.turnOutline) {
    expect(c, `${label}: filet de torn ivori`).toMatch(/^rgba?\(245, 242, 235/);
  }
  if (m.heroPanel) {
    expect(m.row!.bottom, `${label}: la fila no trepitja la mà`).toBeLessThanOrEqual(m.heroPanel.top + 0.5);
    if (m.stand) expect(m.heroPanel.bottom).toBeLessThanOrEqual(m.stand.top + 0.5);
  }
}

for (const vp of VIEWPORTS) {
  test(`taula v2 · bloc 2 · fila de banca i rivals · ${vp.tag}`, async ({ page }) => {
    await page.setViewportSize({ width: vp.width, height: vp.height });
    await seed(page, `v2b2-${vp.width}-${Date.now()}`);
    await start(page, 3);
    const reached = await reachTwoCardTurn(page);
    if (!reached) await page.screenshot({ path: `out/b2-fail-${vp.tag}.png` }).catch(() => {});
    expect(reached, "arriba a un torn propi amb 2 cartes").toBe(true);

    const m = await measureRow(page);
    console.log(`[b2 ${vp.tag}] torn propi: fila ${JSON.stringify(m.row)} carta ${m.cardH}px pot «${m.potText}» seients ${JSON.stringify(m.seats.map((s) => `${s.name}${s.banker ? "(B)" : ""}${s.active ? "*" : ""}:${s.cards}c@${Math.round(s.box.width)}x${Math.round(s.box.height)}`))} heroTop ${m.heroPanel?.top} standTop ${m.stand?.top}`);
    expectRow(m, vp, `torn propi ${vp.tag}`);
    // Retoc 2 (f13): la mà a prop de la fila; l'espai lliure es reparteix 1:2 (abans ≈ 120 px a sobre i ~0 a sota a 390×844).
    console.log(`[b2 ${vp.tag}] buit fila→mà ${m.gapTop?.toFixed(1)} px · mà→accions ${m.gapBottom?.toFixed(1)} px`);
    expect(m.gapTop!, "la mà no s'enganxa a la fila").toBeGreaterThanOrEqual(8);
    expect(m.gapTop!, "la mà no queda lluny de la fila").toBeLessThanOrEqual(64);
    if (m.gapBottom != null) {
      expect(m.gapBottom, "la mà no trepitja les accions").toBeGreaterThanOrEqual(8);
      expect(m.gapBottom, "més aire a sota que a sobre, com a f13").toBeGreaterThanOrEqual(m.gapTop!);
    }
    expect(m.seats.length, "banca + 2 rivals").toBe(3);
    expect(m.seats[0]!.banker, "la banca primer").toBe(true);
    expect(m.seats.filter((s) => s.active), "cap rival marcat al torn propi").toEqual([]);
    const shot = process.env.SETIMIG_V2_SHOT;
    if (shot && vp.width === 390) await page.screenshot({ path: shot });

    const axe = await new AxeBuilder({ page }).analyze();
    const serious = axe.violations.filter((v) => v.impact === "serious" || v.impact === "critical");
    expect(serious.map((v) => `${v.id}: ${v.nodes.map((n) => n.target.join(" ")).join(", ")}`)).toEqual([]);

    // Plantar-se: la banca juga; el seu torn es marca amb el filet (sense groc) i surten píndoles d'estat.
    await page.getByTestId("action-stand").click();
    let sawBankTurn = false;
    let sawPill = false;
    const deadline = Date.now() + 40_000;
    while (Date.now() < deadline && !(sawBankTurn && sawPill)) {
      const r = await measureRow(page).catch(() => null);
      if (r?.row) {
        if (r.seats.some((s) => s.banker && s.active)) {
          sawBankTurn = true;
          expect(r.yellowFill, "torn de la banca sense groc").toEqual([]);
        }
        expect(r.outside, "res fora durant el torn de la banca").toEqual([]);
      }
      if ((await page.getByTestId("v2-seat-pill").count()) > 0) {
        sawPill = true;
        const pills = await page.getByTestId("v2-seat-pill").allInnerTexts();
        console.log(`[b2 ${vp.tag}] píndoles: ${JSON.stringify(pills)}`);
        const pm = await measureRow(page);
        console.log(`[b2 ${vp.tag}] contrast píndoles: ${JSON.stringify(pm.pills)}`);
        for (const p of pills) expect(p).toMatch(/^(Stands( on)? .+|Stands|Bust( · .+)?|Dead Seven)$/);
        const pr = await measureRow(page);
        expectRow(pr, vp, `píndoles ${vp.tag}`);
        if (vp.width === 390 && process.env.SETIMIG_V2_SHOT_BANK) await page.screenshot({ path: process.env.SETIMIG_V2_SHOT_BANK });
      }
      if (await page.getByTestId("settlement-sheet").isVisible().catch(() => false)) break;
      await page.waitForTimeout(120);
    }
    console.log(`[b2 ${vp.tag}] torn banca vist=${sawBankTurn} píndola vista=${sawPill}`);
    expect(sawPill || sawBankTurn, "es veu el torn de la banca o un estat").toBe(true);

    const cls = await page.evaluate(() => {
      const w = window as unknown as { __cls?: number; __clsLog?: string[] };
      return { __cls: w.__cls ?? 0, __clsLog: w.__clsLog ?? [] };
    });
    console.log(`[b2 ${vp.tag}] CLS ${cls.__cls.toFixed(4)} ${cls.__clsLog.slice(-6).join(" ")}`);
    expect(cls.__cls, "CLS de la sessió").toBeLessThanOrEqual(0.05);
  });
}

test("taula v2 · bloc 2 · 6 rivals a 360x740: la fila cap sense retalls", async ({ page }) => {
  await page.setViewportSize({ width: 360, height: 740 });
  await seed(page, `v2b2-6-${Date.now()}`);
  await start(page, 6);
  const reached = await reachTwoCardTurn(page);
  expect(reached).toBe(true);
  const m = await measureRow(page);
  console.log(`[b2 6 rivals] fila ${JSON.stringify(m.row)} seients ${m.seats.length} ${JSON.stringify(m.seats.map((s) => `${s.name}:${s.cards}c@${Math.round(s.box.width)}`))}`);
  expect(m.seats.length).toBe(6);
  expect(m.outside).toEqual([]);
  expect(m.overflowX).toEqual([]);
  expect(m.scrollW).toBeLessThanOrEqual(360);
  expect(m.scrollH).toBeLessThanOrEqual(740);
  expect(m.smallText).toEqual([]);
  if (m.heroPanel) expect(m.row!.bottom).toBeLessThanOrEqual(m.heroPanel.top + 0.5);
  if (m.heroPanel && m.stand) expect(m.heroPanel.bottom).toBeLessThanOrEqual(m.stand.top + 0.5);
});

/** Escriptori 1280×800: només captura (≥ 1024 px no canvia; el muntatge és de la PR #205). */
test("taula v2 · bloc 2 · captura 1280x800", async ({ browser }) => {
  const shot = process.env.SETIMIG_V2_SHOT_DESKTOP;
  test.skip(!shot, "només per a captures");
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 1, isMobile: false, hasTouch: false, locale: "en-US", colorScheme: "dark" });
  const page = await ctx.newPage();
  await seed(page, `v2b2-1280-${Date.now()}`);
  await start(page, 3);
  const deadline = Date.now() + 90_000;
  while (Date.now() < deadline) {
    const bet = page.getByTestId("bet-confirm");
    if ((await bet.isVisible().catch(() => false)) && (await bet.isEnabled().catch(() => false))) {
      await bet.click({ timeout: 2_000 }).catch(() => {});
    } else if (await page.getByTestId("action-stand").isVisible().catch(() => false)) {
      await page.waitForTimeout(900);
      break;
    }
    await page.waitForTimeout(400);
  }
  expect(await page.getByTestId("v2-seat-row").count(), "a escriptori la fila v2 no s'aplica").toBe(0);
  await page.screenshot({ path: shot! });
  await ctx.close();
});
