import { expect, test, type Browser, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";
import { passAgeGateToLobby } from "./helpers/ageGateLobby";
import { openFriendsLobby } from "./helpers/friendsLobby";

/**
 * v199: noves regles de doblar i separar contra el motor real (#358).
 * Dos humans, normes de la casa; el convidat fa de banca i l'amfitrió juga.
 * Cal NODE_ENV=test i SETIMIG_TEST_DECK_SEED = 131, 33, 44 o 601 (docs/baralla-de-prova.md).
 */
const SEED = process.env.SETIMIG_TEST_DECK_SEED;
const vis = (p: Page, id: string) => p.getByTestId(id).filter({ visible: true }).first();
const dbl = (p: Page) => p.getByTestId("mobile-double-chip").or(p.getByTestId("action-double")).filter({ visible: true }).first();
const split = (p: Page) => p.getByTestId("mobile-split-button").filter({ visible: true }).first();

async function swipe(page: Page) {
  const grab = vis(page, "peek-curl-grab");
  await expect(grab).toBeVisible({ timeout: 30_000 });
  const b = (await grab.boundingBox())!;
  const x = b.x + b.width / 2, y0 = b.y + b.height * 0.95, y1 = b.y + b.height * 0.3;
  await page.mouse.move(x, y0);
  await page.mouse.down();
  for (let i = 1; i <= 8; i++) { await page.mouse.move(x, y0 + ((y1 - y0) * i) / 8); await page.waitForTimeout(40); }
  await page.mouse.up();
}

/** Taula privada amb dos humans; torna l'amfitrió amb el torn, després d'apostar i mirar la carta. */
async function hostTurn(browser: Browser): Promise<Page> {
  const vp = { viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true };
  const a = await (await browser.newContext(vp)).newPage();
  const b = await (await browser.newContext(vp)).newPage();
  for (const p of [a, b]) await p.addInitScript(() => {
    localStorage.setItem("setimig_table_tutorial_v1", "1");
    sessionStorage.setItem("setimig_intro_launch_v1", "1");
  });
  await passAgeGateToLobby(a, "Amfitrio", { online: true });
  await openFriendsLobby(a);
  const cb = a.getByTestId("house-rules-toggle").locator("input");
  if ((await cb.count()) && !(await cb.isChecked())) await cb.check({ force: true });
  await a.getByTestId("create-private-table-inline").click();
  await expect(a.getByTestId("private-waiting-panel")).toBeVisible({ timeout: 30_000 });
  const code = (await a.getByTestId("private-invite-code").innerText()).trim().split(/\s+/).pop()!;
  await seedE2eSession(b, e2ePoolId());
  await b.addInitScript(() => {
    localStorage.setItem("setimig_player_name", "Convidat");
    for (const k of ["setimig_onboarding_v1", "setimig_interactive_tutorial_v1"]) localStorage.setItem(k, "1");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
  });
  await b.goto(`/?t=${code}`);
  await expect(b.getByTestId("private-waiting-panel")).toBeVisible({ timeout: 30_000 });
  await expect(a.getByTestId("start-game-button")).toBeVisible({ timeout: 30_000 });
  await a.getByTestId("start-game-button").click();
  await vis(a, "bet-confirm").click({ timeout: 45_000 });
  await swipe(a);
  return a;
}

async function swapFour(a: Page) {
  await expect(vis(a, "swap-offer")).toHaveAttribute("data-offer", "4", { timeout: 20_000 });
  await expect(dbl(a), "amb l'oferta pendent no es pot doblar").toHaveCount(0);
  await vis(a, "swap-swap").click();
  // La carta nova arriba tapada: cal mirar-la perquè surtin les ofertes (Mort, regla del 3).
  if (await vis(a, "peek-curl-grab").isVisible().catch(() => false) || (await vis(a, "peek-curl-grab").waitFor({ timeout: 15_000 }).then(() => true, () => false))) await swipe(a);
}

test.describe("Doblar i separar amb el motor real v199 @390", () => {
  test("131 · després del canvi del 4 la mà és inicial: es dobla el ½, i un cop doblat ja no", async ({ browser }) => {
    test.skip(SEED !== "131", "cal SETIMIG_TEST_DECK_SEED=131");
    const a = await hostTurn(browser);
    await swapFour(a);
    await expect(dbl(a)).toBeEnabled({ timeout: 20_000 });
    await expect(split(a), "amb 1 carta no es separa").toHaveCount(0);
    await dbl(a).click();
    await expect(a.getByTestId("swap-offer")).toHaveCount(0);
    await expect(dbl(a), "només es dobla la primera carta").toHaveCount(0, { timeout: 20_000 });
  });

  test("33 · després del canvi surt el Mort; doblar arriba només en rebutjar-lo", async ({ browser }) => {
    test.skip(SEED !== "33", "cal SETIMIG_TEST_DECK_SEED=33");
    const a = await hostTurn(browser);
    await swapFour(a);
    await expect(vis(a, "mort-decline")).toBeVisible({ timeout: 20_000 });
    await expect(vis(a, "mort-accept")).toBeVisible();
    await expect(dbl(a), "primer cal decidir el Mort").toHaveCount(0);
    await vis(a, "mort-decline").click();
    await expect(dbl(a)).toBeEnabled({ timeout: 20_000 });
  });

  test("44 · després del canvi del 4 surt la regla del 3; «Jugar» deixa doblar el 3", async ({ browser }) => {
    test.skip(SEED !== "44", "cal SETIMIG_TEST_DECK_SEED=44");
    const a = await hostTurn(browser);
    await swapFour(a);
    await expect(vis(a, "swap-offer")).toHaveAttribute("data-offer", "3", { timeout: 20_000 });
    await expect(dbl(a)).toHaveCount(0);
    await vis(a, "swap-play").click();
    await expect(dbl(a)).toBeEnabled({ timeout: 20_000 });
  });

  test("601 · figures diferents (cavall + sota) es separen i les mans separades no es dobles", async ({ browser }) => {
    test.skip(SEED !== "601", "cal SETIMIG_TEST_DECK_SEED=601");
    const a = await hostTurn(browser);
    await swapFour(a);
    await expect(dbl(a)).toBeEnabled({ timeout: 20_000 });
    await dbl(a).click();
    await expect(split(a), "cavall + sota: es pot separar").toBeEnabled({ timeout: 20_000 });
    await split(a).click();
    await expect(a.getByTestId("own-split-hand")).toHaveCount(2, { timeout: 20_000 });
    await expect(dbl(a), "una mà separada no es dobla").toHaveCount(0);
    await expect(split(a), "cavall + 7 no es torna a separar").toHaveCount(0);
  });
});
