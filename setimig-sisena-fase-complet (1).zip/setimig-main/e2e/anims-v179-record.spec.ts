/**
 * Gravació de les 4 animacions v179 a 390×844 (velocitat normal).
 * Executar amb PW_VIDEO=1 i SETIMIG_TEST_DECK_SEED adequat.
 */
import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

const SEED = process.env.SETIMIG_TEST_DECK_SEED;

async function startSolo(page: Page) {
  await seedE2eSession(page, e2ePoolId());
  await page.addInitScript(() => {
    if (sessionStorage.getItem("qa_llavor") === "1") return;
    sessionStorage.setItem("qa_llavor", "1");
    for (const k of [
      "setimig_onboarding_v1",
      "setimig_interactive_tutorial_v1",
      "setimig_table_tutorial_v1",
      "setimig_house_rules_enabled",
    ])
      localStorage.setItem(k, "1");
    localStorage.setItem("setimig.locale", "ca");
    localStorage.setItem("setimig_player_name", "Test Llavor");
    localStorage.setItem(
      "setimig_age_gate",
      JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }),
    );
    sessionStorage.setItem("setimig_intro_launch_v1", "1");
  });
  await page.goto("/");
  const skip = page.getByTestId("interactive-tutorial-skip");
  await expect(page.getByTestId("lobby-context").or(skip).first()).toBeVisible({ timeout: 45_000 });
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  if (await page.getByTestId("ai-bot-count-1").isVisible().catch(() => false)) {
    await page.getByTestId("ai-bot-count-1").click();
  }
  const cb = page.getByTestId("house-rules-toggle").locator("input");
  if ((await cb.count()) && !(await cb.isChecked())) await cb.check({ force: true });
  await page.getByTestId("ai-bot-picker-start").click();
  await page.getByTestId("bet-confirm").filter({ visible: true }).first().click({ timeout: 30_000 });
}

const grab = (page: Page) => page.getByTestId("peek-curl-grab").filter({ visible: true }).first();

async function softPeek(page: Page) {
  const b = (await grab(page).boundingBox())!;
  const x = b.x + b.width / 2;
  const y0 = b.y + b.height * 0.95;
  const y1 = Math.max(4, b.y - b.height * 0.8);
  await page.mouse.move(x, y0);
  await page.mouse.down();
  for (let i = 1; i <= 12; i++) {
    await page.mouse.move(x, y0 + ((y1 - y0) * i) / 12);
    await page.waitForTimeout(25);
  }
  await page.mouse.up();
  await page.waitForTimeout(200);
}

test.describe.configure({ mode: "serial" });
test.use({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });

test("rec peek hint", async ({ page }) => {
  test.skip(SEED !== "3", "seed 3");
  await startSolo(page);
  await expect(grab(page)).toBeVisible({ timeout: 30_000 });
  await expect(page.getByTestId("peek-swipe-hint")).toBeVisible({ timeout: 5_000 });
  await page.waitForTimeout(3000); // un bucle sencer 2,5 s
  await softPeek(page);
  await page.waitForTimeout(500);
});

test("rec fast reveal", async ({ page }) => {
  test.skip(SEED !== "3", "seed 3");
  await startSolo(page);
  await expect(grab(page)).toBeVisible({ timeout: 30_000 });
  await softPeek(page);
  const btn = page.getByTestId("reveal-card-action").filter({ visible: true }).first();
  await expect(btn).toBeVisible({ timeout: 15_000 });
  await page.waitForTimeout(400);
  await btn.click();
  await page.waitForTimeout(1200);
});

test("rec mort success", async ({ page }) => {
  test.skip(SEED !== "4", "seed 4");
  await startSolo(page);
  await expect(grab(page)).toBeVisible({ timeout: 30_000 });
  await softPeek(page);
  await page.getByTestId("mort-accept").click({ timeout: 20_000 });
  await expect(page.getByTestId("mort-reveal")).toBeVisible({ timeout: 90_000 });
  await expect(page.getByTestId("mort-reveal-headline")).toBeVisible({ timeout: 8_000 });
  await page.waitForTimeout(2000);
});

test("rec mort fail", async ({ page }) => {
  test.skip(SEED !== "206", "seed 206");
  await startSolo(page);
  await expect(grab(page)).toBeVisible({ timeout: 30_000 });
  await softPeek(page);
  await page.getByTestId("mort-accept").click({ timeout: 20_000 });
  await expect(page.getByTestId("mort-reveal")).toBeVisible({ timeout: 90_000 });
  await expect(page.getByTestId("mort-reveal-headline")).toBeVisible({ timeout: 8_000 });
  await page.waitForTimeout(2000);
});
