import AxeBuilder from "@axe-core/playwright";
import { expect, test, type Page } from "@playwright/test";

/**
 * Regressió 26/10/2026 (regressio-2026-10-26b.md), només mesures, sense captures:
 * - C-P2-1: CLS d'una partida de 10 mans en mòbil (finestres de sessió de Chrome: buit ≤ 1 s, màx. 5 s) i al final.
 * - C-P2-3: revenja en pràctica → mà nova visible gairebé a l'instant.
 * - Fitxes de pràctica: la liquidació en pràctica diu «Fitxes de pràctica».
 */
const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844 },
  { tag: "360x740", width: 360, height: 740 },
] as const;

type Shift = { t: number; v: number };

async function seedLobby(page: Page, id: string) {
  await page.addInitScript((pid) => {
    localStorage.setItem("setimig_player_id", pid);
    localStorage.setItem("setimig_player_name", "Regressio");
    localStorage.setItem("setimig_onboarding_v1", "1");
    localStorage.setItem("setimig_interactive_tutorial_v1", "1");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
    const w = window as unknown as { __shifts: Shift[] };
    w.__shifts = [];
    new PerformanceObserver((list) => {
      for (const entry of list.getEntries() as unknown as { startTime: number; value: number; hadRecentInput: boolean }[]) {
        if (!entry.hadRecentInput) w.__shifts.push({ t: entry.startTime, v: entry.value });
      }
    }).observe({ type: "layout-shift", buffered: true });
  }, id);
}

/** CLS segons Chrome: la pitjor finestra de sessió (shifts separats < 1 s, finestra ≤ 5 s). */
function maxSessionWindow(shifts: Shift[]): number {
  let best = 0;
  let cur = 0;
  let start = -Infinity;
  let last = -Infinity;
  for (const s of shifts) {
    if (s.t - last > 1000 || s.t - start > 5000) {
      cur = 0;
      start = s.t;
    }
    cur += s.v;
    last = s.t;
    best = Math.max(best, cur);
  }
  return best;
}

async function shifts(page: Page): Promise<Shift[]> {
  return page.evaluate(() => (window as unknown as { __shifts: Shift[] }).__shifts.slice());
}

for (const vp of VIEWPORTS) {
  test(`partida de pràctica de 10 mans: CLS < 0,1, revenja immediata (${vp.tag})`, async ({ page }) => {
    await page.setViewportSize({ width: vp.width, height: vp.height });
    await seedLobby(page, `regcls-${vp.width}-${Date.now()}`);
    await page.goto("/");
    await page.getByTestId("lobby-context").click();
    await page.getByTestId("ai-bot-count-1").click();
    await page.getByTestId("ai-practice-mode").check();
    await page.getByRole("button", { name: "Començar" }).click();

    const revenge = page.getByTestId("match-revenge-button");
    let practiceUnitSeen = false;
    let lastSettlementAt = 0;
    const deadline = Date.now() + 240_000;
    while (Date.now() < deadline && !(await revenge.isVisible().catch(() => false))) {
      const unit = page.getByTestId("settlement-chips-unit");
      if (!practiceUnitSeen && (await unit.isVisible().catch(() => false))) {
        await expect(unit).toHaveText("Fitxes de pràctica");
        practiceUnitSeen = true;
      }
      if (await page.getByTestId("settlement-sheet").isVisible().catch(() => false)) {
        lastSettlementAt = await page.evaluate(() => performance.now());
      }
      for (const id of ["settlement-next-hand", "action-stand", "bet-confirm"]) {
        const button = page.getByTestId(id);
        if ((await button.isVisible().catch(() => false)) && (await button.isEnabled().catch(() => false))) {
          await button.click({ timeout: 2_000 }).catch(() => {});
          break;
        }
      }
      await page.waitForTimeout(200);
    }
    await expect(revenge).toBeVisible();
    await expect(page.getByTestId("match-end-overlay")).toBeVisible();
    await page.waitForTimeout(1_000);

    const all = await shifts(page);
    const total = all.reduce((sum, s) => sum + s.v, 0);
    const cls = maxSessionWindow(all);
    const endCls = all.filter((s) => s.t >= lastSettlementAt - 1_000).reduce((sum, s) => sum + s.v, 0);
    console.log(`[${vp.tag}] CLS (finestra) ${cls.toFixed(3)} · final ${endCls.toFixed(3)} · acumulat 10 mans ${total.toFixed(3)}`);
    expect(practiceUnitSeen).toBe(true);
    expect(cls).toBeLessThan(0.1);
    expect(endCls).toBeLessThan(0.1);

    const axe = await new AxeBuilder({ page }).analyze();
    expect(axe.violations.map((v) => v.id)).toEqual([]);

    // C-P2-3: revenja → la mà nova es veu (sense el full final i amb «Mà 1/10»).
    const t0 = await page.evaluate(() => performance.now());
    await revenge.click();
    await expect(page.getByTestId("match-end-overlay")).toHaveCount(0, { timeout: 5_000 });
    await expect(page.getByTestId("match-hand-counter")).toContainText(/1\s*\/\s*10/, { timeout: 5_000 });
    const rematchMs = (await page.evaluate(() => performance.now())) - t0;
    console.log(`[${vp.tag}] revenja → mà nova ${Math.round(rematchMs)} ms`);
    expect(rematchMs).toBeLessThan(1_000);
  });
}
