import fs from "node:fs";
import path from "node:path";
import { expect, test, type Browser, type Page } from "@playwright/test";
import { playingFaceDownSnapshot, settlementSnapshot } from "./helpers/anim0820Fixtures.ts";

/**
 * PR 5 d'animacions: 08 (banca), 11 (inici), 19 (assoliment), 20 (tutorial).
 * Captures a SETIMIG_ANIM_SHOTS · 390×844, 1280×800 i moviment reduït.
 */
const SHOTS = process.env.SETIMIG_ANIM_SHOTS ?? path.join("test-results", "anim-08-20");
const AGE_OK = () => JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" });
const MOBILE = { width: 390, height: 844 };
const DESKTOP = { width: 1280, height: 800 };

type Kind = "play" | "settle";
type Opts = { reduce?: boolean; desktop?: boolean; showIntro?: boolean; showTutorial?: boolean };

function snapFor(kind: Kind, pid: string): string {
  return kind === "settle" ? settlementSnapshot(pid) : playingFaceDownSnapshot(pid);
}

async function openSolo(browser: Browser, kind: Kind, opts: Opts = {}) {
  const vp = opts.desktop ? DESKTOP : MOBILE;
  const ctx = await browser.newContext({
    viewport: vp,
    deviceScaleFactor: opts.desktop ? 1 : 2,
    locale: "en-US",
    colorScheme: "dark",
    reducedMotion: opts.reduce ? "reduce" : "no-preference",
  });
  const page = await ctx.newPage();
  const pid = `anim0820-${kind}-${vp.width}-${Date.now()}`;
  await page.addInitScript(
    ({ snap, pid, age, showIntro, showTutorial }) => {
      (window as unknown as { __vib: unknown[] }).__vib = [];
      (window as unknown as { __SETIMIG_FREEZE_BOTS?: boolean }).__SETIMIG_FREEZE_BOTS = true;
      try {
        Object.defineProperty(navigator, "vibrate", {
          configurable: true,
          value: (p: unknown) => {
            (window as unknown as { __vib: unknown[] }).__vib.push(p);
            return true;
          },
        });
      } catch {
        /* ignore */
      }
      if (sessionStorage.getItem("a0820_seeded") === "1") return;
      sessionStorage.setItem("a0820_seeded", "1");
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", "Edu");
      localStorage.setItem("setimig.locale", "en");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      if (!showTutorial) localStorage.setItem("setimig_table_tutorial_v1", "1");
      else localStorage.removeItem("setimig_table_tutorial_v1");
      if (!showIntro) localStorage.setItem("setimig_home_intro_v1", "1");
      else localStorage.removeItem("setimig_home_intro_v1");
      localStorage.setItem("setimig_house_rules_enabled", "0");
      localStorage.setItem("setimig_age_gate", age);
      localStorage.setItem("setimig_local_solo_snapshot", snap);
      sessionStorage.setItem("setimig_solo_rejoin", "1");
      sessionStorage.setItem("setimig_solo_local", "1");
    },
    {
      snap: snapFor(kind, pid),
      pid,
      age: AGE_OK(),
      showIntro: !!opts.showIntro,
      showTutorial: !!opts.showTutorial,
    }
  );
  await page.route("**/socket.io/**", (route) => route.abort());
  await page.goto("/");
  return { ctx, page, vp, pid };
}

async function shot(page: Page, name: string) {
  fs.mkdirSync(SHOTS, { recursive: true });
  await page.screenshot({ path: path.join(SHOTS, `${name}.png`) });
}

test("11 · inici (390×844): primera obertura, sense Skip", async ({ browser }) => {
  const { ctx, page } = await openSolo(browser, "play", { showIntro: true });
  await expect(page.getByTestId("home-intro")).toBeVisible({ timeout: 30_000 });
  await shot(page, "11-intro-390");
  await expect(page.getByTestId("home-intro-skip")).toHaveCount(0);
  await expect(page.getByTestId("home-intro")).toHaveCount(0, { timeout: 15_000 });
  const seen = await page.evaluate(() => localStorage.getItem("setimig_home_intro_v1"));
  expect(seen).toBe("1");
  await ctx.close();
});

test("11 · inici reduït (1280×800)", async ({ browser }) => {
  const { ctx, page } = await openSolo(browser, "play", { showIntro: true, reduce: true, desktop: true });
  await expect(page.getByTestId("home-intro")).toBeVisible({ timeout: 30_000 });
  await shot(page, "11-intro-1280-reduced");
  await expect(page.getByTestId("home-intro-skip")).toHaveCount(0);
  await expect
    .poll(async () => page.evaluate(() => localStorage.getItem("setimig_home_intro_v1")))
    .toBe("1");
  await ctx.close();
});

test("20 · tutorial (390×844): coach a la taula", async ({ browser }) => {
  const { ctx, page } = await openSolo(browser, "play", { showTutorial: true });
  await expect(page.getByTestId("game-table-root").or(page.locator(".game-table-root"))).toBeVisible({ timeout: 30_000 }).catch(() => undefined);
  await expect(page.getByTestId("table-tutorial")).toBeVisible({ timeout: 30_000 });
  await expect(page.getByTestId("table-tutorial-coach")).toContainText(/1 of 3|face-down|Your face-down/i);
  await shot(page, "20-tutorial-step1-390");
  await page.getByTestId("table-tutorial-next").click();
  await expect(page.getByTestId("table-tutorial")).toHaveAttribute("data-fx-tutorial", "2");
  await shot(page, "20-tutorial-step2-390");
  await page.getByTestId("table-tutorial-skip").click();
  await expect(page.getByTestId("table-tutorial")).toHaveCount(0);
  const done = await page.evaluate(() => localStorage.getItem("setimig_table_tutorial_v1"));
  expect(done).toBe("1");
  await ctx.close();
});


test("20 · tutorial (1280×800)", async ({ browser }) => {
  const { ctx, page } = await openSolo(browser, "play", { showTutorial: true, desktop: true });
  await expect(page.getByTestId("table-tutorial")).toBeVisible({ timeout: 30_000 });
  await shot(page, "20-tutorial-step1-1280");
  await page.getByTestId("table-tutorial-skip").click();
  await ctx.close();
});

test("19 · assoliment (390×844): toast en cua fora de decisió", async ({ browser }) => {
  const { ctx, page } = await openSolo(browser, "settle");
  await expect(page.locator(".game-table-root")).toBeVisible({ timeout: 30_000 });
  await page.waitForFunction(() => typeof (window as unknown as { __SETIMIG_PUSH_ACHIEVEMENT?: unknown }).__SETIMIG_PUSH_ACHIEVEMENT === "function");
  await page.evaluate(() => {
    (window as unknown as { __SETIMIG_PUSH_ACHIEVEMENT: (n: unknown) => void }).__SETIMIG_PUSH_ACHIEVEMENT({
      id: "natural_seven_half",
      level: 5,
      title: "First perfect 7½",
      rewardPts: 50,
    });
  });
  await expect(page.getByTestId("achievement-toast")).toBeVisible({ timeout: 10_000 });
  await expect(page.getByTestId("achievement-toast")).toContainText(/Level 5|First perfect/i);
  await shot(page, "19-achievement-390");
  await page.getByTestId("achievement-toast-dismiss").click();
  await expect(page.getByTestId("achievement-toast")).toHaveCount(0, { timeout: 5_000 });
  await ctx.close();
});

test("19 · assoliment (1280×800) + reduït", async ({ browser }) => {
  const { ctx, page } = await openSolo(browser, "settle", { desktop: true, reduce: true });
  await expect(page.locator(".game-table-root")).toBeVisible({ timeout: 30_000 });
  await page.waitForFunction(() => typeof (window as unknown as { __SETIMIG_PUSH_ACHIEVEMENT?: unknown }).__SETIMIG_PUSH_ACHIEVEMENT === "function");
  await page.evaluate(() => {
    (window as unknown as { __SETIMIG_PUSH_ACHIEVEMENT: (n: unknown) => void }).__SETIMIG_PUSH_ACHIEVEMENT({
      id: "first_win",
      level: 2,
      title: "First win",
      rewardPts: 20,
    });
  });
  await expect(page.getByTestId("achievement-toast")).toBeVisible({ timeout: 10_000 });
  await shot(page, "19-achievement-1280-reduced");
  await ctx.close();
});

test("08 · banca (390×844): vol del testimoni entre seients", async ({ browser }) => {
  const { ctx, page, pid } = await openSolo(browser, "play");
  await expect(page.locator(".game-table-root")).toBeVisible({ timeout: 30_000 });
  const bankSeat = page.locator('[data-seat-banker="true"]').first();
  await expect(bankSeat).toBeVisible();
  await page.waitForFunction(() => typeof (window as unknown as { __SETIMIG_FORCE_BANK_FLIGHT?: unknown }).__SETIMIG_FORCE_BANK_FLIGHT === "function");
  const ids = await page.evaluate(() => {
    const seats = [...document.querySelectorAll("[data-seat-player]")].map((el) => el.getAttribute("data-seat-player"));
    const bank = document.querySelector('[data-seat-banker="true"]')?.getAttribute("data-seat-player");
    const other = seats.find((id) => id && id !== bank) ?? null;
    return { bank, other };
  });
  expect(ids.bank).toBeTruthy();
  expect(ids.other).toBeTruthy();
  await page.evaluate(
    ({ from, to }) => {
      (window as unknown as { __SETIMIG_FORCE_BANK_FLIGHT: (a: string, b: string) => void }).__SETIMIG_FORCE_BANK_FLIGHT(from!, to!);
    },
    { from: ids.bank, to: ids.other }
  );
  await expect(page.getByTestId("bank-token-flight")).toBeVisible({ timeout: 5_000 });
  await shot(page, "08-bank-flight-390");
  await expect(page.getByTestId("bank-token-flight")).toHaveCount(0, { timeout: 3_000 });
  void pid;
  await ctx.close();
});

test("08 · banca reduït (1280×800)", async ({ browser }) => {
  const { ctx, page } = await openSolo(browser, "play", { desktop: true, reduce: true });
  await expect(page.locator(".game-table-root")).toBeVisible({ timeout: 30_000 });
  await page.waitForFunction(() => typeof (window as unknown as { __SETIMIG_FORCE_BANK_FLIGHT?: unknown }).__SETIMIG_FORCE_BANK_FLIGHT === "function");
  const ids = await page.evaluate(() => {
    const seats = [...document.querySelectorAll("[data-seat-player]")].map((el) => el.getAttribute("data-seat-player"));
    const bank = document.querySelector('[data-seat-banker="true"]')?.getAttribute("data-seat-player");
    const other = seats.find((id) => id && id !== bank) ?? null;
    return { bank, other };
  });
  await page.evaluate(
    ({ from, to }) => {
      (window as unknown as { __SETIMIG_FORCE_BANK_FLIGHT: (a: string, b: string) => void }).__SETIMIG_FORCE_BANK_FLIGHT(from!, to!);
    },
    { from: ids.bank, to: ids.other }
  );
  await expect(page.getByTestId("bank-token-flight")).toBeVisible({ timeout: 5_000 });
  await shot(page, "08-bank-flight-1280-reduced");
  await ctx.close();
});
