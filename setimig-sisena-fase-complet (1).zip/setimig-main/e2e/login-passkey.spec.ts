/**
 * Face ID / passkey al login amb un autenticador virtual (CDP WebAuthn):
 * botó amagat sense marca, finestra després del primer login, «Ara no» recordat, Activa → botó visible → login descobrible.
 * S'obre a `localhost` (WebAuthn no admet IP com a rpId).
 */
import { openLoginEmail, blockSocketIoCtx } from "./helpers/loginSession.ts";
import { expect, test, type Browser, type BrowserContext, type Page } from "@playwright/test";

const PID = "passkey-player-01";
const TOKEN = "passkey.token";
const AGE_OK = () => JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" });
const b64u = (s: string) => Buffer.from(s).toString("base64url");

type Calls = { regVerify: number; loginVerify: number };

function base(): string {
  const port = Number(process.env.E2E_PORT || process.env.PORT || 3000);
  return `http://localhost:${port}`;
}

async function newCtx(browser: Browser, calls: Calls): Promise<BrowserContext> {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, locale: "ca-ES", colorScheme: "dark" });
  await ctx.addInitScript((age) => {
    if (sessionStorage.getItem("pk_seeded") === "1") return;
    sessionStorage.setItem("pk_seeded", "1");
    sessionStorage.setItem("setimig_intro_launch_v1", "1");
    localStorage.setItem("setimig.locale", "ca");
    localStorage.setItem("setimig_age_gate", age);
    localStorage.setItem("setimig_home_intro_v1", "1");
    localStorage.setItem("setimig_player_name", "Edu");
    localStorage.setItem("setimig_onboarding_v1", "1");
    localStorage.setItem("setimig_interactive_tutorial_v1", "1");
  }, AGE_OK());
  await blockSocketIoCtx(ctx);
  const success = (method: string) => ({ playerId: PID, playerToken: TOKEN, method, created: false, linked: true, switchedAccount: false });
  await ctx.route(/\/api\//, async (route) => {
    const req = route.request();
    const url = new URL(req.url());
    const key = `${req.method()} ${url.pathname}`;
    switch (key) {
      case "GET /api/auth/providers":
        return route.fulfill({ json: { email: true, google: true, passkey: true, rpId: "localhost" } });
      case "POST /api/auth/email/start":
        return route.fulfill({ status: 202, json: { ok: true, expiresInSec: 600 } });
      case "POST /api/auth/email/verify":
        return route.fulfill({ json: success("email") });
      case "POST /api/auth/passkey/register/options":
        expect(req.headers()["authorization"]).toBe(`Bearer ${TOKEN}`);
        return route.fulfill({
          json: {
            challenge: b64u("reg-challenge-0123456789"),
            rp: { id: "localhost", name: "Seven Half Club" },
            user: { id: b64u(PID), name: "edu@example.com", displayName: "Edu" },
            pubKeyCredParams: [{ type: "public-key", alg: -7 }],
            authenticatorSelection: { residentKey: "required", userVerification: "required" },
            excludeCredentials: [],
            timeout: 60000,
          },
        });
      case "POST /api/auth/passkey/register/verify":
        calls.regVerify++;
        return route.fulfill({ json: { ok: true, passkey: { id: "pk1", name: "iPhone" } } });
      case "POST /api/auth/passkey/login/options":
        return route.fulfill({ json: { challengeId: "c1", options: { challenge: b64u("login-challenge-0123456789"), rpId: "localhost", userVerification: "required", allowCredentials: [], timeout: 60000 } } });
      case "POST /api/auth/passkey/login/verify": {
        calls.loginVerify++;
        const body = req.postDataJSON() as { response: { response: { userHandle?: string } } };
        expect(body.response.response.userHandle).toBe(b64u(PID));
        return route.fulfill({ json: success("passkey") });
      }
      case "GET /api/auth/me":
        return route.fulfill({ json: { playerId: PID, emails: ["edu@example.com"], google: false, passkeys: 1, verified: true } });
      case "POST /api/player-session":
        // Com el servidor real: sense Bearer ni galeta, 401.
        if (!route.request().headers()["authorization"]) return route.fulfill({ status: 401, json: { error: "auth_required" } });
        return route.fulfill({ json: { playerId: PID, playerToken: TOKEN } });
      case "GET /api/balance":
        return route.fulfill({ json: { chips: 1000, freeClaim: { available: false, nextAt: null } } });
      default:
        return route.fulfill({ status: 404, json: { error: "no", code: "NOT_FOUND" } });
    }
  });
  return ctx;
}

async function addAuthenticator(page: Page) {
  const cdp = await page.context().newCDPSession(page);
  await cdp.send("WebAuthn.enable");
  const { authenticatorId } = await cdp.send("WebAuthn.addVirtualAuthenticator", {
    options: { protocol: "ctap2", transport: "internal", hasResidentKey: true, hasUserVerification: true, isUserVerified: true, automaticPresenceSimulation: true },
  });
  return { cdp, authenticatorId };
}

async function loginWithEmail(page: Page) {
  await openLoginEmail(page);
  await page.getByTestId("login-email-input").fill("edu@example.com");
  await page.getByTestId("login-email-submit").click();
  await page.getByTestId("login-code-input").fill("123456");
  await page.getByTestId("login-code-submit").click();
}

test("primer login amb correu → «Activa Face ID» registra la passkey i torna a ?next=; després login descobrible amb el botó", async ({ browser }) => {
  const calls: Calls = { regVerify: 0, loginVerify: 0 };
  const ctx = await newCtx(browser, calls);
  const page = await ctx.newPage();
  const { cdp, authenticatorId } = await addAuthenticator(page);
  await page.goto(`${base()}/login?next=%2Fcom-jugar`);
  await expect(page.getByTestId("login-email-continue")).toBeVisible();
  await expect(page.getByTestId("login-passkey")).toHaveCount(0);
  await loginWithEmail(page);
  const prompt = page.getByTestId("login-passkey-prompt");
  await expect(prompt).toBeVisible();
  await expect(page.getByRole("dialog")).toHaveAttribute("aria-modal", "true");
  await expect(page.getByTestId("login-passkey-prompt-title")).toHaveText("Vols activar Face ID / Touch ID per entrar més ràpid?");
  await expect(page.getByTestId("login-passkey-activate")).toBeFocused();
  const box = await page.getByTestId("login-passkey-later").boundingBox();
  expect(box!.height).toBeGreaterThanOrEqual(44);
  await page.getByTestId("login-passkey-activate").click();
  await page.waitForURL((u) => u.pathname === "/com-jugar", { timeout: 15_000 });
  // La destinació ha de muntar amb sessió abans d'esborrar-la (si no, el guard redirigeix a /login i avorta el goto).
  await expect(page.getByTestId("com-jugar-toc")).toBeVisible();
  expect(calls.regVerify).toBe(1);
  const { credentials } = await cdp.send("WebAuthn.getCredentials", { authenticatorId });
  expect(credentials).toHaveLength(1);
  expect(credentials[0].isResidentCredential).toBe(true);

  // Sessió tancada: el botó entra sense correu (allowCredentials buit, userHandle).
  // S'esborra des d'un fitxer estàtic (sense l'app muntada) perquè el guard no redirigeixi alhora.
  await page.goto(`${base()}/robots.txt`);
  await page.evaluate(() => {
    localStorage.removeItem("setimig_player_token");
    localStorage.removeItem("setimig_player_id");
  });
  // Sense presència automàtica, l'autoemplenament (mediation: 'conditional') queda pendent i no entra abans de veure el botó.
  await cdp.send("WebAuthn.setAutomaticPresenceSimulation", { authenticatorId, enabled: false });
  await page.goto(`${base()}/login`);
  await expect(page.getByTestId("login-passkey")).toBeVisible();
  await cdp.send("WebAuthn.setAutomaticPresenceSimulation", { authenticatorId, enabled: true });
  // En tornar la presència, la petició condicional pendent pot entrar abans que el clic i
  // desmuntar el botó: tots dos camins acaben al mateix login per passkey.
  await page.getByTestId("login-passkey").click({ timeout: 5_000 }).catch(() => {});
  await page.waitForURL((u) => u.pathname !== "/login", { timeout: 15_000 });
  expect(calls.loginVerify).toBeGreaterThanOrEqual(1);
  expect(await page.evaluate(() => localStorage.getItem("setimig_player_token"))).toBe(TOKEN);
  await ctx.close();
});

test("«Ara no» es recorda en aquest dispositiu (no torna a sortir)", async ({ browser }) => {
  const calls: Calls = { regVerify: 0, loginVerify: 0 };
  const ctx = await newCtx(browser, calls);
  const page = await ctx.newPage();
  await addAuthenticator(page);
  await page.goto(`${base()}/login`);
  await loginWithEmail(page);
  await expect(page.getByTestId("login-passkey-prompt")).toBeVisible();
  await page.keyboard.press("Escape"); // Esc = «Ara no»
  await page.waitForURL((u) => u.pathname !== "/login", { timeout: 15_000 });
  // El lobby ha de muntar amb sessió abans d'esborrar-la (si no, el guard redirigeix a /login i avorta el goto).
  await expect(page.getByTestId("lobby-main")).toBeVisible();
  expect(calls.regVerify).toBe(0);
  // La sessió s'esborra des d'un fitxer estàtic del mateix origen (sense l'app muntada): si
  // s'esborra amb el lobby obert, el guard redirigeix a /login alhora que el goto i l'avorta
  // (net::ERR_ABORTED a la tirada conjunta).
  await page.goto(`${base()}/robots.txt`);
  await page.evaluate(() => {
    localStorage.removeItem("setimig_player_token");
    localStorage.removeItem("setimig_player_id");
  });
  await page.goto(`${base()}/login?next=%2Fcom-jugar`);
  await loginWithEmail(page);
  await page.waitForURL((u) => u.pathname === "/com-jugar", { timeout: 15_000 });
  await expect(page.getByTestId("com-jugar-toc")).toBeVisible();
  await expect(page.getByTestId("login-passkey-prompt")).toHaveCount(0);
  await ctx.close();
});

test("sense marca local el botó de Face ID no surt", async ({ browser }) => {
  const calls: Calls = { regVerify: 0, loginVerify: 0 };
  const ctx = await newCtx(browser, calls);
  const page = await ctx.newPage();
  await addAuthenticator(page);
  await page.goto(`${base()}/login`);
  await expect(page.getByTestId("login-email-continue")).toBeVisible();
  await expect(page.getByTestId("login-passkey")).toHaveCount(0);
  await page.evaluate(() => localStorage.setItem("setimig_passkey_device", "1"));
  await page.reload();
  await expect(page.getByTestId("login-passkey")).toBeVisible();
  await ctx.close();
});
