import { expect, test, type Page } from "@playwright/test";
import { passAgeGateToLobby } from "./helpers/ageGateLobby";
import { createPrivateTable, readInviteCode } from "./helpers/tableFlow";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * QA v194 (última QA de la v193):
 * 1) A 390 amb mans separades, la liquidació no tapa la mà 2 (llavor 3: NODE_ENV=test SETIMIG_TEST_DECK_SEED=3).
 * 2) A 1024 i 1280, «Esperant apostes dels jugadors…» surt una sola vegada (banca).
 * 3) A 1024, a la liquidació, la mà pròpia es veu sencera i cap fitxa tapa el nom de la banca.
 */
type Box = { x: number; y: number; width: number; height: number };
const inter = (a: Box, b: Box) =>
  Math.max(0, Math.min(a.x + a.width, b.x + b.width) - Math.max(a.x, b.x)) * Math.max(0, Math.min(a.y + a.height, b.y + b.height) - Math.max(a.y, b.y));
const visible = (page: Page, id: string) => page.getByTestId(id).filter({ visible: true }).first();
const SEED = process.env.SETIMIG_TEST_DECK_SEED;

async function skipTutorial(page: Page) {
  for (const id of ["table-tutorial-skip", "interactive-tutorial-skip"]) {
    const sk = page.getByTestId(id);
    if (await sk.isVisible().catch(() => false)) await sk.click().catch(() => {});
  }
}

async function startSoloSplit(page: Page) {
  await seedE2eSession(page, e2ePoolId());
  await page.addInitScript(() => {
    if (sessionStorage.getItem("qa194") === "1") return;
    sessionStorage.setItem("qa194", "1");
    for (const k of ["setimig_onboarding_v1", "setimig_interactive_tutorial_v1", "setimig_table_tutorial_v1", "setimig_house_rules_enabled"]) localStorage.setItem(k, "1");
    localStorage.setItem("setimig.locale", "ca");
    localStorage.setItem("setimig_player_name", "Test Split");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
    sessionStorage.setItem("setimig_intro_launch_v1", "1");
  });
  await page.goto("/");
  const skip = page.getByTestId("interactive-tutorial-skip");
  await expect(page.getByTestId("lobby-context").or(skip).first()).toBeVisible({ timeout: 45_000 });
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  if (await page.getByTestId("ai-bot-count-1").isVisible().catch(() => false)) await page.getByTestId("ai-bot-count-1").click();
  const cb = page.getByTestId("house-rules-toggle").locator("input");
  if (!(await cb.isChecked())) await cb.check({ force: true });
  await page.getByTestId("ai-bot-picker-start").click();
  await visible(page, "bet-confirm").click({ timeout: 30_000 });
  await expect(visible(page, "action-stand")).toBeVisible({ timeout: 30_000 });
}

async function twoPlayerTable(browser: import("@playwright/test").Browser, vp: { width: number; height: number }) {
  const ctxs = await Promise.all([0, 1].map(() => browser.newContext({ viewport: vp })));
  const pages = await Promise.all(ctxs.map((c) => c.newPage()));
  await passAgeGateToLobby(pages[0], "Amfitrio194", { playerId: e2ePoolId(), online: true });
  await createPrivateTable(pages[0]);
  const code = await readInviteCode(pages[0]);
  await passAgeGateToLobby(pages[1], "Convidat194", { playerId: e2ePoolId(), online: true });
  await pages[1].goto(`/?t=${code}`);
  await expect(pages[1].locator("[data-testid=private-waiting-panel], [data-testid=game-top-bar]").first()).toBeVisible({ timeout: 30_000 });
  await expect(pages[0].getByTestId("start-game-button")).toBeVisible({ timeout: 30_000 });
  await pages[0].getByTestId("start-game-button").click();
  return { ctxs, pages };
}

async function findRoles(pages: Page[]) {
  let player: Page | null = null;
  await expect
    .poll(async () => {
      for (const p of pages) if (await p.getByTestId("bet-screen").isVisible().catch(() => false)) player = p;
      return player != null;
    }, { timeout: 60_000 })
    .toBe(true);
  return { player: player!, bank: pages.find((p) => p !== player)! };
}

test("390 llavor 3: amb mans separades la liquidació no tapa la mà 2", async ({ browser }) => {
  test.skip(SEED !== "3", "cal SETIMIG_TEST_DECK_SEED=3");
  test.setTimeout(180_000);
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 } });
  const page = await ctx.newPage();
  await startSoloSplit(page);
  await visible(page, "action-hit").click();
  await visible(page, "mobile-split-button").click({ timeout: 20_000 });
  await expect(page.getByTestId("own-split-hand")).toHaveCount(2, { timeout: 20_000 });
  // Em planto a les dues mans (mà 1 de la partida) i espero la liquidació d'aquesta mateixa mà.
  for (let k = 0; k < 2; k++) {
    await expect(visible(page, "action-stand")).toBeEnabled({ timeout: 30_000 });
    await visible(page, "action-stand").click({ timeout: 5_000 });
    await page.waitForTimeout(400);
  }
  await expect(visible(page, "settlement-sheet")).toBeVisible({ timeout: 45_000 });
  await expect(page.getByTestId("match-hand-counter")).toContainText(/1\//);
  await page.waitForTimeout(800);
  const card = (await page.locator(".v176-settle-card").filter({ visible: true }).first().boundingBox())!;
  const hands = page.getByTestId("own-split-hand").filter({ visible: true });
  expect(await hands.count()).toBe(2);
  for (let i = 0; i < 2; i++) {
    const b = (await hands.nth(i).boundingBox())!;
    expect(b.y, `mà ${i + 1} fora de pantalla`).toBeGreaterThanOrEqual(-0.5);
    expect(inter(card, b) / (b.width * b.height), `mà ${i + 1} tapada per la liquidació`).toBeLessThan(0.1);
    // L'etiqueta «Mà N» es veu (cap carta al damunt).
    const lbl = hands.nth(i).getByTestId("split-hand-label");
    const covered = await lbl.evaluate((el) => {
      const r = el.getBoundingClientRect();
      const top = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
      return !!top && top !== el && !el.contains(top);
    });
    expect(covered, `etiqueta de la mà ${i + 1} tapada`).toBe(false);
  }
  // Mai els punts propis.
  await expect(page.getByTestId("settlement-sheet")).not.toContainText(/\bpunts?\b/i);
  await ctx.close();
});

for (const vp of [{ width: 1024, height: 768 }, { width: 1280, height: 720 }]) {
  test(`${vp.width}: «Esperant apostes dels jugadors…» una sola vegada a la banca`, async ({ browser }) => {
    test.setTimeout(180_000);
    const { ctxs, pages } = await twoPlayerTable(browser, vp);
    const { bank } = await findRoles(pages);
    await skipTutorial(bank);
    await expect(bank.getByText("Esperant apostes dels jugadors…").filter({ visible: true }).first()).toBeVisible({ timeout: 20_000 });
    await bank.waitForTimeout(500);
    await expect(bank.getByText("Esperant apostes dels jugadors…").filter({ visible: true })).toHaveCount(1);
    await Promise.all(ctxs.map((c) => c.close()));
  });
}

test("1024 liquidació: la mà pròpia sencera i cap fitxa damunt del nom de la banca", async ({ browser }) => {
  test.setTimeout(240_000);
  const vp = { width: 1024, height: 720 };
  const { ctxs, pages } = await twoPlayerTable(browser, vp);
  const { player, bank } = await findRoles(pages);
  for (const p of pages) await skipTutorial(p);
  await visible(player, "bet-confirm").click();
  await expect(visible(player, "action-stand")).toBeEnabled({ timeout: 30_000 });
  await visible(player, "action-stand").click();
  const end = Date.now() + 60_000;
  while (Date.now() < end && !(await visible(player, "settlement-next-hand").isVisible().catch(() => false))) {
    const bs = visible(bank, "action-stand");
    if (await bs.isEnabled().catch(() => false)) await bs.click({ timeout: 3_000 }).catch(() => {});
    await player.waitForTimeout(300);
  }
  await expect(visible(player, "settlement-next-hand")).toBeVisible({ timeout: 30_000 });
  // La mà pròpia sencera dins de la pantalla i no tapada pel full.
  const sheet = (await player.locator(".v176-settle-card").filter({ visible: true }).first().boundingBox())!;
  const cards = player.locator("[data-testid=focus-mine] :is([data-testid=local-hand-card], [data-testid=face-hint-card], [data-testid=playing-card])").filter({ visible: true });
  expect(await cards.count()).toBeGreaterThan(0);
  const stage = (await player.locator(".game-table-stage").first().boundingBox())!;
  for (const c of await cards.all()) {
    const b = (await c.boundingBox())!;
    expect(b.y + b.height, "mà pròpia tallada per baix").toBeLessThanOrEqual(Math.min(vp.height, stage.y + stage.height) - 16);
    expect(b.y).toBeGreaterThanOrEqual(-0.5);
    const clipped = await c.evaluate((el) => {
      const r = el.getBoundingClientRect();
      let p = el.parentElement;
      while (p) {
        const s = getComputedStyle(p);
        if (s.overflow !== "visible" || s.overflowY !== "visible") {
          const q = p.getBoundingClientRect();
          if (r.bottom > q.bottom + 1 || r.top < q.top - 1) return true;
        }
        p = p.parentElement;
      }
      return false;
    });
    expect(clipped, "mà pròpia retallada pel contenidor").toBe(false);
    expect(inter(sheet, b) / (b.width * b.height)).toBeLessThan(0.1);
  }
  // Mostreig mentre volen les fitxes: cap fitxa del flux damunt del nom de la banca.
  const overlaps: string[] = [];
  const until = Date.now() + 3_000;
  while (Date.now() < until) {
    const hit = await player.evaluate(() => {
      const names = Array.from(document.querySelectorAll<HTMLElement>("[data-seat-banker=true] .v2-seat-name, [data-seat-banker=true] [data-testid=seat-name]"));
      const chips = Array.from(document.querySelectorAll<HTMLElement>("[data-testid=fx-flow-chip], .tfx-chip"));
      for (const n of names) {
        const a = n.getBoundingClientRect();
        if (!a.width) continue;
        for (const c of chips) {
          if (Number(getComputedStyle(c).opacity) < 0.15) continue;
          const b = c.getBoundingClientRect();
          const w = Math.min(a.right, b.right) - Math.max(a.left, b.left);
          const h = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
          if (w > 3 && h > 3) return `${c.className} @${Math.round(b.left)},${Math.round(b.top)}`;
        }
      }
      return null;
    });
    if (hit) overlaps.push(hit);
    await player.waitForTimeout(60);
  }
  expect(overlaps, "fitxa damunt del nom de la banca").toEqual([]);
  await Promise.all(ctxs.map((c) => c.close()));
});
