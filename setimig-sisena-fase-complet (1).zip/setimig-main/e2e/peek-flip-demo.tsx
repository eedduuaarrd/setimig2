import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import type { CSSProperties } from "react";
import "../src/index.css";
import "../src/elegant.css";
import "../src/taulaV2.css";
import "../src/components/peekHint.css";
import MotionToggle from "../src/components/MotionToggle";
import { PeekCurlCard } from "../src/components/PeekCurlCard";

const card = { suit: "spades" as const, value: 7, points: 7 };
const tableStyle: CSSProperties = {
  minHeight: "100vh",
  display: "flex",
  flexDirection: "column",
  alignItems: "center",
  justifyContent: "center",
  gap: "2rem",
  padding: "2rem",
  background: "radial-gradient(ellipse at center, #214239 0%, #142b24 52%, #0e1c18 100%)",
  ["--card-player-h" as string]: "244px",
  ["--card-player-w" as string]: "174px",
};

function Demo() {
  const [faceUp, setFaceUp] = useState(false);
  return (
    <main className="game-table-root game-table-mobile game-table-felt" style={tableStyle} data-testid="demo-table">
      <header style={{ textAlign: "center", color: "#eee5d2", fontFamily: "Cinzel, Georgia, serif" }}>
        <p style={{ margin: 0, fontSize: 12, letterSpacing: ".24em", textTransform: "uppercase", opacity: .72 }}>Set i Mig · mà activa</p>
        <h1 style={{ margin: "8px 0 0", fontSize: 22, fontWeight: 500 }}>Aixeca per girar</h1>
      </header>
      <MotionToggle />
      <div style={{ position: "relative" }}>
        <PeekCurlCard
          card={card}
          faceUp={faceUp}
          cardId="demo-seven-spades"
          size="player"
          className="spanish-card-size-player spanish-card-turn-active"
          canReveal
          onReveal={() => setFaceUp(true)}
          hidePeekHint={!new URLSearchParams(window.location.search).has("showHint")}
        />
      </div>
      <p style={{ margin: 0, color: "#d6cdbb", fontSize: 13, letterSpacing: ".08em" }}>7 d’espases · arrossega cap amunt lentament</p>
    </main>
  );
}

createRoot(document.getElementById("root")!).render(<Demo />);
