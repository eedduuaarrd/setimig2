import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * Vídeo de l'Edu (2a passada), mesures:
 * - ítem 2: «Mà N/10» no se solapa amb cap altre text (aposta ni torn) a 375/390/1280;
 * - ítem 4: cap percentatge a la taula;
 * - ítem 10: a 1280 el pot és visible i no el tapa la carta gran (elementFromPoint).
 */
async function seed(page: Page, id: string) {
  await seedE2eSession(page, id);
  await page.addInitScript((pid) => {
    if (sessionStorage.getItem("__vt2_seeded")) return;
    sessionStorage.setItem("__vt2_seeded", "1");
    localStorage.setItem("setimig_player_id", pid);
    localStorage.setItem("setimig_player_name", "Video");
    localStorage.setItem("setimig_onboarding_v1", "1");
    localStorage.setItem("setimig_interactive_tutorial_v1", "1");
    localStorage.setItem("setimig.locale", "ca");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
  }, id);
}

/** Solapaments entre l'etiqueta «Mà N/10» i qualsevol altre text visible (px²). */
async function handLabelOverlaps(page: Page) {
  return page.evaluate(() => {
    const leaves = [...document.querySelectorAll("body *")].filter((el) => {
      if (![...el.childNodes].some((n) => n.nodeType === 3 && n.textContent!.trim())) return false;
      const cs = getComputedStyle(el);
      if (cs.visibility === "hidden" || Number(cs.opacity) === 0) return false;
      const r = el.getBoundingClientRect();
      return r.width > 0 && r.height > 0 && r.bottom > 0 && r.top < innerHeight;
    });
    const labels = leaves.filter((el) => /^Mà \d+\s*\/\s*\d+$/.test(el.textContent!.trim()));
    const out: string[] = [];
    for (const l of labels) {
      const a = l.getBoundingClientRect();
      for (const o of leaves) {
        if (o === l || o.contains(l) || l.contains(o)) continue;
        const b = o.getBoundingClientRect();
        const w = Math.min(a.right, b.right) - Math.max(a.left, b.left);
        const h = Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top);
        if (w > 1 && h > 1) out.push(`${l.textContent!.trim()} × «${o.textContent!.trim().slice(0, 30)}» ${Math.round(w)}x${Math.round(h)}`);
      }
    }
    return { count: labels.length, out };
  });
}

async function startGame(page: Page) {
  await page.goto("/");
  await page.getByTestId("lobby-context").click();
  await page.getByTestId("ai-bot-count-1").click();
  await page.getByRole("button", { name: "Començar" }).click();
  await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 60_000 });
}

for (const vp of [
  { w: 375, h: 667 },
  { w: 390, h: 844 },
  { w: 1280, h: 800 },
]) {
  test(`vídeo 2a passada · ${vp.w}: «Mà N/10» sense solapar, sense %, pot visible`, async ({ page }) => {
    await page.setViewportSize({ width: vp.w, height: vp.h });
    await seed(page, e2ePoolId());
    await startGame(page);
    let betChecked = false;
    let turnChecked = false;
    let bet = false;
    const deadline = Date.now() + 120_000;
    while (Date.now() < deadline && !turnChecked) {
      const betBtn = page.getByTestId("bet-confirm");
      if (!bet && (await betBtn.isVisible().catch(() => false)) && (await betBtn.isEnabled().catch(() => false))) {
        await page.waitForTimeout(400);
        const o = await handLabelOverlaps(page);
        console.log(`[vt2] ${vp.w} aposta etiquetes=${o.count}`);
        expect(o.out, "aposta: «Mà N/10» sense solapar").toEqual([]);
        betChecked = true;
        await betBtn.click({ timeout: 2_000 }).catch(() => {});
        bet = true;
        continue;
      }
      const stand = page.getByTestId("action-stand");
      if (bet && (await stand.isVisible().catch(() => false)) && (await stand.isEnabled().catch(() => false))) {
        await page.waitForTimeout(500);
        const o = await handLabelOverlaps(page);
        console.log(`[vt2] ${vp.w} torn etiquetes=${o.count}`);
        expect(o.out, "torn: «Mà N/10» sense solapar").toEqual([]);
        const pct = await page.evaluate(() => (document.body.innerText.match(/\d+\s?%/g) ?? []));
        expect(pct, "cap percentatge a la taula").toEqual([]);
        if (vp.w >= 1024) {
          const pot = await page.evaluate(() => {
            const el = document.querySelector("[data-testid=table-pot]");
            if (!el) return "absent";
            const r = el.getBoundingClientRect();
            const cards = [...document.querySelectorAll("[data-testid=local-player-seat] .spanish-card-size-player")].map((c) => c.getBoundingClientRect());
            const inter = cards.some((c) => c.left < r.right && c.right > r.left && c.top < r.bottom && c.bottom > r.top);
            if (inter) return "solapa la carta pròpia";
            const hit = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
            return hit && (hit === el || el.contains(hit)) ? "ok" : `tapat per ${hit?.className}`;
          });
          expect(pot, "pot visible a escriptori").toBe("ok");
        }
        turnChecked = true;
        break;
      }
      await page.waitForTimeout(150);
    }
    expect(betChecked, "pantalla d'aposta mesurada").toBe(true);
    expect(turnChecked, "torn propi mesurat").toBe(true);
  });
}
