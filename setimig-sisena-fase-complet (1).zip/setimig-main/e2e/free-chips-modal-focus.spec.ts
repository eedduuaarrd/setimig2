import { expect, test } from "@playwright/test";

test("free-chips dialog contains focus and restores it on close", async ({ page }) => {
  await page.goto("/e2e/fixtures/free-chips-modal.html");
  const opener = page.getByTestId("open-free-chips");
  await opener.click();

  const dialog = page.getByRole("dialog", { name: "Fitxes gratis" });
  const claim = dialog.getByTestId("claim-free-chips-button");
  const close = dialog.getByRole("button", { name: "Tancar" });
  await expect(dialog).toBeVisible();

  await claim.focus();
  await page.keyboard.press("Shift+Tab");
  await expect(close).toBeFocused();
  await page.keyboard.press("Tab");
  await expect(claim).toBeFocused();

  await page.keyboard.press("Escape");
  await expect(dialog).toHaveCount(0);
  await expect(opener).toBeFocused();
});
