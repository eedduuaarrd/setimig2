import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * QA llavor (v168). Partida solo real amb la baralla fixa (docs/baralla-de-prova.md), 1 rival, Normes de la casa.
 * Cal arrencar-ho amb SETIMIG_TEST_DECK_SEED=3 (doblar/separar) i SETIMIG_TEST_DECK_SEED=4 (Mort):
 * cada test es salta si la llavor del servidor no és la seva.
 */
const SEED = process.env.SETIMIG_TEST_DECK_SEED;
const OUT = "/workspace/qa-llavor-v168";
const SIZES = [
  { name: "390", width: 390, height: 844 },
  { name: "1280", width: 1280, height: 800 },
] as const;

async function startSolo(page: Page) {
  const pid = e2ePoolId();
  await seedE2eSession(page, pid);
  await page.addInitScript(() => {
    if (sessionStorage.getItem("qa_llavor") === "1") return;
    sessionStorage.setItem("qa_llavor", "1");
    for (const k of ["setimig_onboarding_v1", "setimig_interactive_tutorial_v1", "setimig_table_tutorial_v1", "setimig_house_rules_enabled"]) localStorage.setItem(k, "1");
    localStorage.setItem("setimig.locale", "ca");
    localStorage.setItem("setimig_player_name", "Test Llavor");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
    sessionStorage.setItem("setimig_intro_launch_v1", "1");
  });
  await page.goto("/");
  const skip = page.getByTestId("interactive-tutorial-skip");
  await expect(page.getByTestId("lobby-context").or(skip).first()).toBeVisible({ timeout: 45_000 });
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  if (await page.getByTestId("ai-bot-count-1").isVisible().catch(() => false)) await page.getByTestId("ai-bot-count-1").click();
  const cb = page.getByTestId("house-rules-toggle").locator("input");
  if (!(await cb.isChecked())) await cb.check({ force: true });
  await page.getByTestId("ai-bot-picker-start").click();
  await page.getByTestId("bet-confirm").filter({ visible: true }).first().click({ timeout: 30_000 });
}

async function peek(page: Page) {
  const g = page.getByTestId("peek-curl-grab").filter({ visible: true }).first();
  await expect(g).toBeVisible({ timeout: 20_000 });
  const b = (await g.boundingBox())!;
  const x = b.x + b.width / 2;
  const y0 = b.y + b.height * 0.95;
  await page.mouse.move(x, y0);
  await page.mouse.down();
  for (let i = 1; i <= 8; i++) await page.mouse.move(x, y0 - i * b.height * 0.08);
  await page.mouse.up();
  await page.waitForTimeout(700);
}

const doubleBtn = (page: Page, mobile: boolean) =>
  mobile ? page.getByTestId("mobile-double-chip").filter({ visible: true }).first() : page.getByRole("button", { name: /^doblar$/i }).filter({ visible: true }).first();

async function toSettlement(page: Page, doStand = true) {
  const sheet = page.getByTestId("settlement-sheet");
  for (let i = 0; i < 300 && !(await sheet.isVisible().catch(() => false)); i++) {
    if (!doStand) { await page.waitForTimeout(300); continue; }
    const stand = page.getByTestId("action-stand").filter({ visible: true }).first();
    // #317: «Plantar-se» només existeix al torn propi. isEnabled()/click() sobre un locator buit
    // esperen actionTimeout (15 s) i la liquidació (més curta) passa sense que el bucle la vegi.
    if ((await stand.isVisible().catch(() => false)) && (await stand.isEnabled({ timeout: 500 }).catch(() => false)))
      await stand.click({ timeout: 1000 }).catch(() => {});
    await page.waitForTimeout(300);
  }
  await expect(sheet).toBeVisible();
  await page.waitForTimeout(1200);
}


/** Norma de l'Edu: cap punt propi a la liquidació (ni visible ni al lector de pantalla). */
async function expectNoOwnPoints(page: Page) {
  for (const row of await page.getByTestId("settlement-hand-row").all()) {
    const txt = (await row.innerText()).replace(/^\s*(Mà|Hand|Mano|Mão)\s+\d+/i, "");
    expect(txt).not.toMatch(/\d/);
  }
  const result = page.getByTestId("my-hand-result");
  if (await result.count()) {
    const txt = (await result.textContent()) ?? "";
    expect(txt).not.toMatch(/\b(Tu|Tens|Fas|Has fet)\b[^·]*\d|\d+(?:[.,]5|½)\s*(?:vs|contra)/i);
  }
  const title = (await page.locator("#settlement-round-title").innerText()).split("·").map((x) => x.trim());
  expect(new Set(title).size).toBe(title.length);
}

for (const size of SIZES) {
  const mobile = size.width < 600;
  test.describe(`QA llavor v168 @${size.name}`, () => {
    test.use({ viewport: { width: size.width, height: size.height }, isMobile: mobile, hasTouch: mobile });

    test("llavor 3: 2× a la mà 1, Separar traduït, mans separades a la liquidació", async ({ page }) => {
      test.skip(SEED !== "3", "cal SETIMIG_TEST_DECK_SEED=3");
      await startSolo(page);
      await peek(page);
      // Bug 1: el 2× hi és a la mà 1 (també al mòbil).
      await expect(doubleBtn(page, mobile)).toBeVisible({ timeout: 20_000 });
      const box = await doubleBtn(page, mobile).boundingBox();
      expect(box!.height).toBeGreaterThanOrEqual(mobile ? 0 : 44);
      await doubleBtn(page, mobile).click();
      // Bug 2: el botó de separar diu «Separar» a totes les mides.
      const split = page.getByRole("button", { name: /separar|split/i }).filter({ visible: true }).first();
      await expect(split).toBeVisible({ timeout: 20_000 });
      await expect(split).toHaveText(/separar/i);
      await expect(page.getByRole("button", { name: /^split$/i })).toHaveCount(0);
      await page.screenshot({ path: `${OUT}/3-${size.name}-separar.png` });
      await split.click();
      await page.waitForTimeout(2000);
      await toSettlement(page);
      await page.screenshot({ path: `${OUT}/3-${size.name}-liquidacio.png` });
      // Bug 3: cada mà té la seva línia; totes dues porten «Doblada».
      await expect(page.getByTestId("settlement-hand-row")).toHaveCount(2);
      await expectNoOwnPoints(page);
      if (!mobile) {
        const labels = page.getByText(/Mà [12] .*Doblada/i);
        await expect(labels).toHaveCount(2);
        const card = (await page.locator(".settlement-card").boundingBox())!;
        for (const panel of await page.locator(".desktop-hand-panel").all()) {
          const pb = (await panel.boundingBox())!;
          expect(pb.x + pb.width).toBeLessThanOrEqual(card.x + 1);
        }
      }
    });

    test("llavor 4: Mort — sense Destapar durant l'oferta, i «Mort ×2» a la liquidació", async ({ page }) => {
      test.skip(SEED !== "4", "cal SETIMIG_TEST_DECK_SEED=4");
      await startSolo(page);
      await peek(page);
      await expect(page.getByTestId("mort-accept")).toBeVisible({ timeout: 20_000 });
      // Bug 5: «Destapar carta» amagat mentre hi ha l'oferta.
      await expect(page.getByTestId("reveal-card-action").filter({ visible: true })).toHaveCount(0);
      await page.screenshot({ path: `${OUT}/4-${size.name}-oferta.png` });
      await page.getByTestId("mort-accept").click();
      // El Mort acaba el torn sol: no es planta res (si no, es podria plantar la mà 2).
      await toSettlement(page, false);
      await page.screenshot({ path: `${OUT}/4-${size.name}-liquidacio.png` });
      // Bug 4: la fila diu «Mort ×2», no «Doble ×2».
      const self = page.locator('[data-testid="settlement-result-row"][data-self="true"]');
      await expect(self).toContainText(/Mort ×2/);
      await expect(page.getByTestId("settlement-sheet")).not.toContainText(/Doble ×2/);
      await expectNoOwnPoints(page);
    });
  });
}
