import AxeBuilder from "@axe-core/playwright";
import { expect, test, type Page } from "@playwright/test";
import { safeHalfHandSnapshotJson } from "./helpers/f2ProbabilityFixtures.ts";

const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844 },
  { tag: "375x667", width: 375, height: 667 },
  { tag: "360x740", width: 360, height: 740 },
] as const;

async function seedLocalSolo(page: Page, playerId: string, playerName: string) {
  const snapshot = safeHalfHandSnapshotJson(playerId, playerName);
  await page.addInitScript(
    ({ snap, pid, pname }) => {
      // Compta quants AudioContext es creen (n'hi ha d'haver 0 amb el so apagat).
      const w = window as unknown as Record<string, unknown>;
      w.__smAudioContexts = 0;
      w.__smLastAudioContext = null;
      const Orig = window.AudioContext;
      if (Orig) {
        class Counted extends Orig {
          constructor(...args: ConstructorParameters<typeof AudioContext>) {
            super(...args);
            w.__smAudioContexts = (w.__smAudioContexts as number) + 1;
            w.__smLastAudioContext = this;
          }
        }
        window.AudioContext = Counted as typeof AudioContext;
      }
      if (sessionStorage.getItem("setimig_e2e_seeded") === "1") return;
      sessionStorage.setItem("setimig_e2e_seeded", "1");
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", pname);
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_house_rules_enabled", "1");
      localStorage.setItem(
        "setimig_age_gate",
        JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
      );
      localStorage.setItem("setimig_local_solo_snapshot", snap);
      sessionStorage.setItem("setimig_solo_rejoin", "1");
      sessionStorage.setItem("setimig_solo_local", "1");
    },
    { snap: snapshot, pid: playerId, pname: playerName }
  );
  await page.route("**/socket.io/**", (route) => route.abort());
}

async function openTableMenu(page: Page) {
  await page.getByTestId("table-tools-menu").getByRole("button", { name: /obrir menú de taula/i }).click();
  await expect(page.getByTestId("sound-settings")).toBeVisible();
}

async function closeTableMenu(page: Page) {
  await page.keyboard.press("Escape");
  await expect(page.getByTestId("sound-settings")).toHaveCount(0);
}

async function assertNoHorizontalOverflow(page: Page) {
  const m = await page.evaluate(() => ({
    scrollWidth: document.documentElement.scrollWidth,
    innerWidth: window.innerWidth,
  }));
  expect(m.scrollWidth).toBeLessThanOrEqual(m.innerWidth + 1);
}

async function assertMenuInsideViewport(page: Page) {
  const box = await page.locator("#setimig-table-options").boundingBox();
  expect(box).not.toBeNull();
  const vw = page.viewportSize()!.width;
  expect(box!.x).toBeGreaterThanOrEqual(-1);
  expect(box!.x + box!.width).toBeLessThanOrEqual(vw + 1);
}

async function assertActionButtonsFit(page: Page) {
  for (const id of ["action-hit", "action-stand"]) {
    const btn = page.getByTestId(id);
    await expect(btn).toBeVisible({ timeout: 30_000 });
    const box = await btn.boundingBox();
    expect(box).not.toBeNull();
    expect(box!.width).toBeGreaterThan(100);
  }
  const dockBox = await page.getByTestId("action-dock").boundingBox();
  const vp = page.viewportSize()!;
  expect(dockBox).not.toBeNull();
  expect(dockBox!.x + dockBox!.width).toBeLessThanOrEqual(vp.width + 1);
  expect(dockBox!.y + dockBox!.height).toBeLessThanOrEqual(vp.height + 1);
}

const audioContextCount = (page: Page) =>
  page.evaluate(() => (window as unknown as { __smAudioContexts: number }).__smAudioContexts);

for (const vp of VIEWPORTS) {
  test.describe(`F2.3 so i ambient ${vp.tag}`, () => {
    test.use({ viewport: { width: vp.width, height: vp.height } });

    test("apagat per defecte, sense AudioContext ni motor carregat", async ({ page }) => {
      const engineRequests: string[] = [];
      page.on("request", (req) => {
        if (/soundEngine/i.test(req.url())) engineRequests.push(req.url());
      });
      await seedLocalSolo(page, `f2-so-off-${vp.tag}`, "SoOff");
      await page.goto("/");
      await assertActionButtonsFit(page);
      await assertNoHorizontalOverflow(page);

      await openTableMenu(page);
      await expect(page.getByTestId("sound-effects-toggle")).toHaveAttribute("aria-pressed", "false");
      await expect(page.getByTestId("sound-ambient-toggle")).toHaveAttribute("aria-pressed", "false");
      const slider = page.getByRole("slider", { name: "Volum" });
      await expect(slider).toHaveAttribute("aria-valuetext", "Volum 60 %");
      await assertMenuInsideViewport(page);
      await assertNoHorizontalOverflow(page);

      const axe = await new AxeBuilder({ page })
        .include("#setimig-table-options")
        .include('[data-testid="action-dock"]')
        .analyze();
      expect(axe.violations).toEqual([]);

      await closeTableMenu(page);
      await assertActionButtonsFit(page);
      expect(await audioContextCount(page)).toBe(0);
      expect(engineRequests).toEqual([]);
    });
  });
}

test("activar el so i l'ambient persisteix i s'atura amb la pestanya oculta", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await seedLocalSolo(page, "f2-so-on", "SoOn");
  await page.goto("/");
  await expect(page.getByTestId("action-hit")).toBeVisible({ timeout: 30_000 });
  expect(await audioContextCount(page)).toBe(0);

  await openTableMenu(page);
  await page.getByTestId("sound-effects-toggle").click();
  await expect(page.getByTestId("sound-effects-toggle")).toHaveAttribute("aria-pressed", "true");
  await page.getByTestId("sound-ambient-toggle").click();
  await expect(page.getByTestId("sound-ambient-toggle")).toHaveAttribute("aria-pressed", "true");
  const slider = page.getByRole("slider", { name: "Volum" });
  await slider.fill("30");
  await expect(slider).toHaveAttribute("aria-valuetext", "Volum 30 %");
  await expect.poll(() => audioContextCount(page)).toBe(1);

  const stored = await page.evaluate(() => ({
    effects: localStorage.getItem("setimig_sound_effects"),
    ambient: localStorage.getItem("setimig_sound_ambient"),
    volume: localStorage.getItem("setimig_sound_volume"),
  }));
  expect(stored).toEqual({ effects: "1", ambient: "1", volume: "30" });

  // Pestanya oculta: el context s'ha de suspendre.
  await page.evaluate(() => {
    Object.defineProperty(document, "visibilityState", { configurable: true, get: () => "hidden" });
    document.dispatchEvent(new Event("visibilitychange"));
  });
  await expect
    .poll(() =>
      page.evaluate(
        () => (window as unknown as { __smLastAudioContext: AudioContext | null }).__smLastAudioContext?.state
      )
    )
    .not.toBe("running");

  await page.reload();
  await expect(page.getByTestId("action-hit")).toBeVisible({ timeout: 30_000 });
  // Sense gest nou, el so no arrenca sol després de recarregar (autoplay d'iOS).
  expect(await audioContextCount(page)).toBe(0);
  await openTableMenu(page);
  await expect(page.getByTestId("sound-effects-toggle")).toHaveAttribute("aria-pressed", "true");
  await expect(page.getByTestId("sound-ambient-toggle")).toHaveAttribute("aria-pressed", "true");
  await expect(page.getByRole("slider", { name: "Volum" })).toHaveAttribute("aria-valuetext", "Volum 30 %");
  await assertNoHorizontalOverflow(page);
});
