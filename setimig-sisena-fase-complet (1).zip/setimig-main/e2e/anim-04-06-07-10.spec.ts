import fs from "node:fs";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";
import path from "node:path";
import { expect, test, type Browser, type Page } from "@playwright/test";
import { blockSocketIo, mockLoginSession } from "./helpers/loginSession.ts";
import { animSnapshot } from "./helpers/anim0410Fixtures.ts";

/**
 * Animacions PR 3 (animacions-repartir 04 recollir, 06 fitxes, 07 7½, 10 guanya-perd) sobre la taula real.
 * Partida local (solo IA, sense socket) amb el mall controlat i botons reals: tu tens un 7, demanes i cau la sota
 * (7½ exacte, 07); la banca fa 6½; tu i Pol guanyeu amb 7½ i 7, Anna ja s'ha passat (9½) i perd (10 + 06); «Next hand» recull i
 * barreja (04). Comprova ≤ 600 ms per moviment, només transform/opacity, colors sense verd ni vermell, que els
 * dors recollits no porten cara i el moviment reduït. Captures a SETIMIG_ANIM_SHOTS (390×844 i 1280×800).
 */
const SHOTS = process.env.SETIMIG_ANIM_SHOTS ?? path.join("test-results", "anim-04-10");
const AGE_OK = () => JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" });
type Rec = { cls: string; duration: number; delay: number; props: string[] };

const snap = (pid: string) =>
  animSnapshot({
    playerId: pid,
    phase: "playing",
    seats: [
      { key: "bank", name: "Laia", bank: true, cards: [4], tapada: true },
      { key: "anna", name: "Anna", bet: 200, cards: [5, 10, 4], tapada: true, status: "busted", slotStatus: "busted" },
      { key: "pol", name: "Pol", bet: 100, cards: [3, 4], tapada: true, status: "stood", slotStatus: "stood" },
      { key: "me", name: "Edu", human: true, bet: 300, cards: [7] },
    ],
    turn: 2,
    // Tu: sota (7 + ½ = 7½). Després la banca (la IA decideix quan es planta).
    draws: [10, 11, 2, 5, 5, 5],
  });

async function open(browser: Browser, opts: { reduce?: boolean; desktop?: boolean } = {}) {
  const vp = opts.desktop ? { width: 1280, height: 800 } : { width: 390, height: 844 };
  const ctx = await browser.newContext({ viewport: vp, deviceScaleFactor: opts.desktop ? 1 : 2, locale: "en-US", colorScheme: "dark", reducedMotion: opts.reduce ? "reduce" : "no-preference", serviceWorkers: "block" });
  const page = await ctx.newPage();
  page.on("pageerror", (e) => console.log(`[pageerror] ${e.message}`));
  page.on("console", (m) => m.type() === "error" && console.log(`[console] ${m.text().slice(0, 200)}`));
  const pid = e2ePoolId();
  const token = await seedE2eSession(page, pid);
  await page.addInitScript(
    ({ snap, pid, token, age }) => {
      const w = window as unknown as { __fx: Rec[] };
      w.__fx = [];
      const native = Element.prototype.animate;
      Element.prototype.animate = function (this: Element, ...args: Parameters<Element["animate"]>) {
        const anim = native.apply(this, args);
        const el = this as HTMLElement;
        if (el.classList?.contains("tfx")) {
          const timing = anim.effect?.getTiming();
          const props = new Set<string>();
          for (const k of (anim.effect as KeyframeEffect | null)?.getKeyframes() ?? [])
            for (const p of Object.keys(k)) if (!["offset", "easing", "composite", "computedOffset"].includes(p)) props.add(p);
          w.__fx.push({ cls: el.className, duration: Number(timing?.duration ?? 0), delay: Number(timing?.delay ?? 0), props: [...props] });
        }
        return anim;
      } as Element["animate"];
      if (sessionStorage.getItem("a0410_seeded") === "1") {
        localStorage.setItem("setimig_player_id", pid);
        localStorage.setItem("setimig_player_token", token);
        return;
      }
      sessionStorage.setItem("a0410_seeded", "1");
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_token", token);
      localStorage.setItem("setimig_player_name", "Edu");
      localStorage.setItem("setimig.locale", "en");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_table_tutorial_v1", "1");
      localStorage.setItem("setimig_home_intro_v1", "1");
      localStorage.setItem("setimig_house_rules_enabled", "1");
      localStorage.setItem("setimig_your_turn_hint_v1", "1");
      localStorage.setItem("setimig_age_gate", age);
      localStorage.setItem("setimig_local_solo_snapshot", snap);
      sessionStorage.setItem("setimig_solo_rejoin", "1");
      sessionStorage.setItem("setimig_solo_local", "1");
    },
    { snap: snap(pid), pid, token, age: AGE_OK() }
  );
  await mockLoginSession(ctx, pid, token);
  await blockSocketIo(page);
  await page.goto("/");
  await expect(page.locator(".game-table-root")).toBeVisible({ timeout: 30_000 });
  return { ctx, page };
}

async function shot(page: Page, name: string) {
  fs.mkdirSync(SHOTS, { recursive: true });
  await page.screenshot({ path: path.join(SHOTS, `${name}.png`) });
}
const recs = (page: Page) => page.evaluate(() => (window as unknown as { __fx: Rec[] }).__fx);
const pauseFx = (page: Page) => page.evaluate(() => document.getAnimations().forEach((a) => a.pause()));
const playFx = (page: Page) => page.evaluate(() => document.getAnimations().forEach((a) => a.play()));

/** Colors (rgb) d'un element: cap verd ni vermell dominant. */
function notGreenOrRed(rgb: string) {
  const [r, g, b] = (rgb.match(/\d+(\.\d+)?/g) ?? []).map(Number);
  expect(g - Math.max(r, b) < 30, `verd: ${rgb}`).toBe(true);
  expect(r - Math.max(g, b) < 90 || g > 120, `vermell: ${rgb}`).toBe(true);
}

async function flow(browser: Browser, tag: string, opts: { reduce?: boolean; desktop?: boolean }) {
  const { ctx, page } = await open(browser, opts);
  const hit = page.getByTestId("action-hit");
  await expect(hit).toBeEnabled({ timeout: 20_000 });
  const hb = (await hit.boundingBox())!;
  expect(Math.min(hb.width, hb.height)).toBeGreaterThanOrEqual(44);
  const t0 = Date.now();
  await hit.click();

  // 07 · 7½ exacte
  const sevenHand = page.locator("[data-fx-seven='yes']");
  await expect(sevenHand).toHaveCount(1, { timeout: 10_000 });
  const seven = page.getByTestId("fx-seven-number");
  await page.waitForTimeout(opts.reduce ? 150 : 420);
  await pauseFx(page);
  await shot(page, `07-set-i-mig-${tag}`);
  expect(await page.getByTestId("fx-seven-bloom").count()).toBe(opts.reduce ? 0 : 1);
  // El «7½» no surt dues vegades: si la puntuació gran de la mà ja el mostra, no hi ha número gran.
  const who = await sevenHand.getAttribute("data-fx-seven-number");
  // La puntuació gran pot marcar data-seven=yes un instant després (useLiveTotal ≤ 400 ms).
  // Taula gran (v147): no hi ha puntuació gran pròpia, així que el número és sempre el de l'efecte.
  await expect(page.getByTestId("my-hand-points")).toHaveCount(0);
  const heroSeven = await page.locator("[data-testid='my-hand-points'][data-seven='yes']").isVisible().catch(() => false);
  console.log(`[${tag}] 07 número=${who} heroSeven=${heroSeven}`);
  expect(who).toBe(heroSeven ? "hero" : "fx");
  expect(await seven.count()).toBe(heroSeven ? 0 : 1);
  if (!heroSeven) expect(await seven.evaluate((el) => getComputedStyle(el).fontVariantNumeric)).toContain("tabular-nums");
  await playFx(page);

  // Si l'app no planta sola amb 7½, fem servir el botó real.
  const stand = page.getByTestId("action-stand");
  if (await stand.isEnabled().catch(() => false)) await stand.click().catch(() => {});

  // 10 + 06 · liquidació
  await expect(page.locator(".game-table-root")).toHaveAttribute("data-game-phase", "settlement", { timeout: 30_000 });
  await expect(page.getByTestId("settlement-sheet")).toBeVisible({ timeout: 30_000 });
  await expect(page.locator('[data-testid="settlement-result-row"][data-self="true"]')).toHaveAttribute("data-outcome", "win");
  await expect(page.getByTestId("settlement-sheet")).toHaveClass(/settlement-sheet-win/);
  await expect(page.locator(".settlement-natural")).toContainText("7½");
  const badges = page.getByTestId("fx-result-badge");
  await expect(badges.first()).toBeAttached({ timeout: 5_000 });
  await page.waitForTimeout(opts.reduce ? 200 : 380);
  await pauseFx(page);
  await shot(page, `06-10-liquidacio-${tag}`);
  const tones = await badges.evaluateAll((els) => els.map((e) => ({ tone: e.getAttribute("data-tone"), text: e.textContent, color: getComputedStyle(e).color, num: getComputedStyle(e).fontVariantNumeric })));
  console.log(`[${tag}] badges`, JSON.stringify(tones), `hit→liquidació ${Date.now() - t0} ms`);
  expect(tones.filter((x) => x.tone === "win").length).toBeGreaterThanOrEqual(1);
  expect(tones.filter((x) => x.tone === "lose").length).toBeGreaterThanOrEqual(1);
  for (const x of tones) {
    notGreenOrRed(x.color);
    expect(x.num).toContain("tabular-nums");
  }
  expect(await page.locator("[data-fx-hand='win']").count()).toBeGreaterThanOrEqual(1);
  expect(await page.locator("[data-fx-hand='lose']").count()).toBeGreaterThanOrEqual(1);
  await expect(page.getByTestId("fx-chip-delta").first()).toBeAttached();
  await playFx(page);
  await page.waitForTimeout(700);
  await shot(page, `10-guanya-perd-final-${tag}`);

  // 04 · recollir i barrejar amb el botó real «Next hand»
  const next = page.getByTestId("settlement-next-hand");
  await expect(next).toBeVisible({ timeout: 15_000 });
  const nb = (await next.boundingBox())!;
  expect(Math.min(nb.width, nb.height)).toBeGreaterThanOrEqual(44);
  await next.click();
  if (opts.reduce) {
    await expect(page.getByTestId("fx-shuffled")).toBeAttached({ timeout: 10_000 });
    expect(await page.locator(".tfx-shuffle").count()).toBe(0);
  } else {
    await expect(page.locator(".tfx-back").first()).toBeAttached({ timeout: 10_000 });
    await page.waitForTimeout(250);
    await pauseFx(page);
    await shot(page, `04-recollir-${tag}`);
    // Els dors no porten cap imatge ni cara.
    expect(await page.locator(".tfx-back img, .tfx-back [data-face]").count()).toBe(0);
    await playFx(page);
    await expect(page.getByTestId("fx-shuffle")).toBeAttached({ timeout: 5_000 });
  }
  await page.waitForTimeout(400);
  await shot(page, `04-barreja-${tag}`);

  // Temps i propietats: només transform/opacity; cada moviment ≤ 600 ms (els fos del reduït, 120 ms + espera).
  const all = await recs(page);
  for (const r of all) {
    for (const p of r.props) expect(["transform", "opacity"], `${r.cls}: ${p}`).toContain(p);
    expect(r.duration, r.cls).toBeLessThanOrEqual(600);
    if (opts.reduce) expect(r.props.includes("transform"), `reduït amb transform: ${r.cls}`).toBe(false);
  }
  console.log(`[${tag}] animacions fx: ${all.length}; durades úniques ${[...new Set(all.map((r) => r.duration))].join(",")}`);
  await ctx.close();
}

test("04/06/07/10 · 390×844: 7½, liquidació (fitxes i guanya-perd) i recollir", async ({ browser }) => {
  await flow(browser, "390x844", {});
});
test("04/06/07/10 · 1280×800", async ({ browser }) => {
  await flow(browser, "1280x800", { desktop: true });
});
test("04/06/07/10 · moviment reduït (390×844): fosos de 120 ms, sense vols ni resplendor", async ({ browser }) => {
  await flow(browser, "390x844-reduit", { reduce: true });
});
