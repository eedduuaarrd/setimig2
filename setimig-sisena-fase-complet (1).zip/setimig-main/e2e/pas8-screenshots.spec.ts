import { expect, test } from "@playwright/test";
import { startAiGameFromLobby } from "./helpers/aiLobby";
import { passAgeGateToLobby } from "./helpers/ageGateLobby";
import { playUntilSettlement, settlementSurface, waitForHandSurface } from "./helpers/tableFlow";
import fs from "node:fs";
import path from "node:path";

function screenshotDir(): string {
  const candidates = [
    "/cursor/stores/self/media/pas8",
    path.join(process.cwd(), "media/pas8"),
  ];
  for (const dir of candidates) {
    try {
      fs.mkdirSync(dir, { recursive: true });
      return dir;
    } catch {
      /* try next */
    }
  }
  return candidates[candidates.length - 1];
}

test.describe("PAS 8 mobile screenshots 390x844", () => {
  test.use({ viewport: { width: 390, height: 844 } });

  test("turn, hand result, match end, elimination", async ({ page }) => {
    test.setTimeout(180_000);
    const OUT = screenshotDir();
    await passAgeGateToLobby(page, "Pas8Shot", { playerId: "pas8shotuser01", online: true });
    await startAiGameFromLobby(page, 3);
    await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 45_000 });
    await waitForHandSurface(page);

    const turnCue = page
      .getByTestId("turn-banner")
      .or(page.getByTestId("match-hand-counter"))
      .or(page.getByTestId("status-pill"));
    await expect(turnCue.first()).toBeVisible({ timeout: 60_000 });
    await page.screenshot({ path: path.join(OUT, "01-turn-banner.png"), fullPage: true });

    await playUntilSettlement(page);
    await expect(settlementSurface(page).first()).toBeVisible();
    await page.screenshot({ path: path.join(OUT, "02-hand-result.png"), fullPage: true });

    await page.evaluate(() => {
      const root = document.querySelector(".game-table-root");
      if (!root) return;
      const overlay = document.createElement("div");
      overlay.setAttribute("data-testid", "match-end-overlay");
      overlay.className =
        "absolute inset-0 z-[70] flex items-end justify-center bg-black/75 p-4 pb-[calc(6rem+env(safe-area-inset-bottom))] backdrop-blur-sm";
      overlay.innerHTML = `
        <div class="w-full max-w-md rounded-2xl border border-emerald-400/35 bg-emerald-950/55 p-5 shadow-2xl">
          <h2 class="font-headline text-xl font-bold text-on-surface">Has guanyat la partida</h2>
          <p class="mt-2 text-sm text-on-surface-variant">Guanyador: <span class="font-semibold">Pas8Shot</span></p>
          <ol class="mt-4 space-y-2 text-sm">
            <li class="flex justify-between rounded-xl border border-white/10 bg-black/35 px-3 py-2"><span>1. Pas8Shot (tu)</span><span>12.400 CF</span></li>
            <li class="flex justify-between rounded-xl border border-white/10 bg-black/35 px-3 py-2"><span>2. Laia IA</span><span>7.900 CF</span></li>
          </ol>
          <button type="button" class="btn-primary-solid mt-5 min-h-[56px] w-full rounded-xl py-3.5 text-sm font-semibold uppercase">Tornar a jugar</button>
        </div>`;
      root.appendChild(overlay);
    });
    await page.screenshot({ path: path.join(OUT, "03-match-end.png"), fullPage: true });

    await page.evaluate(() => {
      document.querySelector('[data-testid="match-end-overlay"]')?.remove();
      const root = document.querySelector(".game-table-root");
      if (!root) return;
      const overlay = document.createElement("div");
      overlay.setAttribute("data-testid", "match-end-overlay");
      overlay.className =
        "absolute inset-0 z-[70] flex items-end justify-center bg-black/75 p-4 pb-[calc(6rem+env(safe-area-inset-bottom))] backdrop-blur-sm";
      overlay.innerHTML = `
        <div class="w-full max-w-md rounded-2xl border border-rose-400/35 bg-rose-950/55 p-5 shadow-2xl">
          <h2 class="font-headline text-xl font-bold text-on-surface">Has quedat eliminat</h2>
          <p class="mt-2 text-sm text-on-surface-variant">Guanyador: <span class="font-semibold">Laia IA</span></p>
          <ol class="mt-4 space-y-2 text-sm">
            <li class="flex justify-between rounded-xl border border-white/10 bg-black/35 px-3 py-2"><span>1. Laia IA</span><span>9.200 CF</span></li>
            <li class="flex justify-between rounded-xl border border-rose-400/25 bg-rose-950/30 px-3 py-2"><span>2. Pas8Shot (tu) · eliminat</span><span>40 CF</span></li>
          </ol>
          <button type="button" class="btn-primary-solid mt-5 min-h-[56px] w-full rounded-xl py-3.5 text-sm font-semibold uppercase">Tornar a jugar</button>
        </div>`;
      root.appendChild(overlay);
    });
    await page.screenshot({ path: path.join(OUT, "04-elimination.png"), fullPage: true });
  });
});
