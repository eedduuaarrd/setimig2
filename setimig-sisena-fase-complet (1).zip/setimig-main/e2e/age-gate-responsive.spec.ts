import { expect, test } from "@playwright/test";

test("the unaccepted age gate keeps its name controls inside a compact viewport", async ({ page }) => {
  await page.setViewportSize({ width: 320, height: 568 });
  await page.goto("/");

  const gate = page.getByTestId("age-gate");
  const name = page.getByTestId("age-gate-name");
  const shuffle = page.getByRole("button", { name: "Nom aleatori" });
  await expect(gate).toBeVisible();
  await expect(name).toBeVisible();
  await expect(shuffle).toBeVisible();

  const bounds = await page.evaluate(() => {
    const field = document.querySelector<HTMLElement>('[data-testid="age-gate-name"]');
    const button = document.querySelector<HTMLElement>('button[aria-label="Nom aleatori"]');
    if (!field || !button) throw new Error("Age-gate name controls are missing");
    const fieldRect = field.getBoundingClientRect();
    const buttonRect = button.getBoundingClientRect();
    return {
      viewportWidth: window.innerWidth,
      documentWidth: document.documentElement.scrollWidth,
      fieldRight: fieldRect.right,
      buttonLeft: buttonRect.left,
      buttonRight: buttonRect.right,
    };
  });

  expect(bounds.documentWidth).toBeLessThanOrEqual(bounds.viewportWidth);
  expect(bounds.fieldRight).toBeLessThanOrEqual(bounds.buttonLeft);
  expect(bounds.buttonRight).toBeLessThanOrEqual(bounds.viewportWidth);
});

test("the initial unaccepted age gate does not request gameplay code", async ({ page }) => {
  const gameplayRequests: string[] = [];
  page.on("request", (request) => {
    const url = new URL(request.url());
    if (/(?:^|\/)GameView(?:-[^/]+)?\.(?:tsx?|js)$/i.test(url.pathname)) gameplayRequests.push(url.pathname);
  });

  await page.goto("/");
  await expect(page.getByTestId("age-gate")).toBeVisible();
  await page.waitForLoadState("networkidle");
  await expect(page.getByTestId("age-gate")).toBeVisible();

  expect(gameplayRequests).toEqual([]);
});
