import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * Taula a escriptori baix (captura de l'Edu a ~1024×538, v165): solo amb 3 rivals.
 * Al meu torn es mesuren les caixes: cap seient no toca un altre seient, ni el panell «Accions»,
 * ni la mà pròpia; res no queda retallat; la carta pròpia és gran (≥ 2× l'antiga, ~44 px).
 * Captures només a /workspace/taula-pc-baixa/ (mai al repo).
 */
const SIZES = [
  { tag: "1024x538", width: 1024, height: 538, desktop: true },
  { tag: "1366x768", width: 1366, height: 768, desktop: true },
  { tag: "1280x800", width: 1280, height: 800, desktop: true },
  { tag: "1920x1080", width: 1920, height: 1080, desktop: true },
  { tag: "390x844", width: 390, height: 844, desktop: false },
] as const;
const SHOTS = process.env.TAULA_SHOTS_DIR || "/workspace/taula-pc-baixa";

async function seed(page: Page, id: string) {
  await seedE2eSession(page, id);
  await page.addInitScript((pid) => {
    if (sessionStorage.getItem("__tpb_seeded")) return;
    sessionStorage.setItem("__tpb_seeded", "1");
    localStorage.setItem("setimig_player_id", pid);
    localStorage.setItem("setimig_player_name", "Escriptori");
    localStorage.setItem("setimig_onboarding_v1", "1");
    localStorage.setItem("setimig_interactive_tutorial_v1", "1");
    localStorage.setItem("setimig.locale", "ca");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
  }, id);
}

type Box = { l: number; t: number; r: number; b: number };
const inter = (a: Box, b: Box) => Math.max(0, Math.min(a.r, b.r) - Math.max(a.l, b.l)) * Math.max(0, Math.min(a.b, b.b) - Math.max(a.t, b.t));

async function measure(page: Page) {
  return page.evaluate(() => {
    const box = (el: Element) => {
      const r = el.getBoundingClientRect();
      return { l: r.left, t: r.top, r: r.right, b: r.bottom };
    };
    const union = (el: Element) => {
      const u = box(el);
      el.querySelectorAll("*").forEach((c) => {
        const r = c.getBoundingClientRect();
        if (r.width < 1 || r.height < 1) return;
        const cs = getComputedStyle(c);
        if (cs.visibility === "hidden" || cs.position === "fixed") return;
        u.l = Math.min(u.l, r.left); u.t = Math.min(u.t, r.top); u.r = Math.max(u.r, r.right); u.b = Math.max(u.b, r.bottom);
      });
      return u;
    };
    const seats = [...document.querySelectorAll("[data-testid=game-seat-grid] [data-seat-player]")]
      .filter((el) => getComputedStyle(el).visibility !== "hidden" && !el.closest("[aria-hidden=true]"))
      .map(union);
    const actionsEl = document.querySelector("[data-testid=recent-action-timeline-disclosure] summary");
    const ownCards = [...document.querySelectorAll("[data-testid=focus-mine] .spanish-card-size-player")].map(box);
    return {
      seats,
      actions: actionsEl ? box(actionsEl) : null,
      own: ownCards.length ? { l: Math.min(...ownCards.map((c) => c.l)), t: Math.min(...ownCards.map((c) => c.t)), r: Math.max(...ownCards.map((c) => c.r)), b: Math.max(...ownCards.map((c) => c.b)) } : null,
      ownCardW: ownCards.length ? ownCards[0].r - ownCards[0].l : 0,
      vw: innerWidth,
      vh: innerHeight,
      scrollX: document.documentElement.scrollWidth - innerWidth,
      hints: !!document.querySelector("[data-testid=keyboard-hints]"),
    };
  });
}

for (const vp of SIZES) {
  test(`taula escriptori baix · solo 3 rivals sense encavalcaments (${vp.tag})`, async ({ page }) => {
    await page.setViewportSize({ width: vp.width, height: vp.height });
    await seed(page, e2ePoolId());
    await page.goto("/");
    await page.getByTestId("lobby-context").click();
    await page.getByTestId("ai-bot-count-3").click();
    await page.getByRole("button", { name: "Començar" }).click();
    await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 60_000 });

    let measured = false;
    const deadline = Date.now() + 150_000;
    while (Date.now() < deadline && !measured) {
      const betBtn = page.getByTestId("bet-confirm");
      if ((await betBtn.isVisible().catch(() => false)) && (await betBtn.isEnabled().catch(() => false))) {
        await betBtn.click({ timeout: 2_000 }).catch(() => {});
        await page.waitForTimeout(300);
        continue;
      }
      const stand = page.getByTestId("action-stand");
      if ((await stand.isVisible().catch(() => false)) && (await stand.isEnabled().catch(() => false))) {
        await page.waitForTimeout(700);
        const m = await measure(page);
        await page.screenshot({ path: `${SHOTS}/${vp.tag}.png` }).catch(() => {});
        console.log(`[taula-pc-baixa] ${vp.tag} ${JSON.stringify({ seats: m.seats.length, ownCardW: Math.round(m.ownCardW), actions: m.actions, own: m.own })}`);
        expect(m.scrollX, "sense desbordament horitzontal").toBeLessThanOrEqual(0);
        expect(m.hints, "sense barra de dreceres").toBe(false);
        expect(m.own, "mà pròpia muntada").not.toBeNull();
        const own = m.own!;
        expect(own.l >= 0 && own.r <= m.vw + 0.5 && own.t >= 0 && own.b <= m.vh + 0.5, `mà pròpia sense retallar ${JSON.stringify(own)}`).toBe(true);
        expect(m.ownCardW, "carta pròpia gran (≥ 2× ~44 px)").toBeGreaterThanOrEqual(vp.desktop ? 88 : 60);
        if (vp.desktop) {
          // Centrada a sota.
          expect(Math.abs((own.l + own.r) / 2 - m.vw / 2), "mà pròpia centrada").toBeLessThanOrEqual(m.vw * 0.08);
          expect(m.seats.length, "rivals visibles").toBeGreaterThanOrEqual(2);
          for (let i = 0; i < m.seats.length; i++) {
            const s = m.seats[i];
            expect(s.l >= 0 && s.r <= m.vw + 0.5 && s.t >= 0 && s.b <= m.vh + 0.5, `seient ${i} sense retallar ${JSON.stringify(s)}`).toBe(true);
            for (let j = i + 1; j < m.seats.length; j++) expect(inter(s, m.seats[j]), `seient ${i}/${j}`).toBe(0);
            if (m.actions) expect(inter(s, m.actions), `seient ${i}/Accions`).toBe(0);
            expect(inter(s, own), `seient ${i}/mà pròpia`).toBe(0);
          }
          // Els seients es reparteixen per l'amplada (no arraconats): ocupen ≥ 45 % de l'ample.
          if (m.seats.length >= 2) {
            const span = Math.max(...m.seats.map((s) => s.r)) - Math.min(...m.seats.map((s) => s.l));
            expect(span, "seients repartits en arc").toBeGreaterThanOrEqual(m.vw * 0.45);
          }
        }
        measured = true;
        break;
      }
      await page.waitForTimeout(150);
    }
    expect(measured, "torn propi mesurat").toBe(true);
  });
}
