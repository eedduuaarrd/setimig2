import { expect, test } from "@playwright/test";
import { startAiGameFromLobby } from "./helpers/aiLobby";
import { passAgeGateToLobby } from "./helpers/ageGateLobby";
import { createPrivateTable, handSurface, readInviteCode } from "./helpers/tableFlow";
import fs from "node:fs";
import path from "node:path";

const MOBILE_VIEWPORTS = [
  { name: "390x844", width: 390, height: 844 },
  { name: "360x640-portrait", width: 360, height: 640 },
  { name: "360x640-landscape", width: 640, height: 360 },
] as const;

const DESKTOP_VIEWPORTS = [
  { name: "1280x800", width: 1280, height: 800 },
  { name: "1920x1080", width: 1920, height: 1080 },
] as const;

function screenshotDir(): string {
  const candidates = [
    "/cursor/stores/self/media/pas10",
    path.join(process.cwd(), "media/pas10"),
  ];
  for (const dir of candidates) {
    try {
      fs.mkdirSync(dir, { recursive: true });
      return dir;
    } catch {
      /* try next */
    }
  }
  return candidates[candidates.length - 1];
}

for (const vp of MOBILE_VIEWPORTS) {
  test(`PAS 10 mobile lobby ${vp.name}`, async ({ page }) => {
    await page.setViewportSize({ width: vp.width, height: vp.height });
    await passAgeGateToLobby(page, "Pas10Mobile", { playerId: `pas10mob${vp.name.replace(/\W/g, "").slice(0, 12)}` });
    await expect(page.getByTestId("lobby-main")).toBeVisible();
    await expect(page.getByTestId("play-vs-ai-button")).toBeVisible();
    const overflowX = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 2);
    expect(overflowX).toBe(false);
  });
}

for (const vp of DESKTOP_VIEWPORTS) {
  test(`PAS 10 desktop lobby ${vp.name}`, async ({ page }) => {
    await page.setViewportSize({ width: vp.width, height: vp.height });
    await passAgeGateToLobby(page, "Pas10Desktop", { playerId: `pas10desk${vp.width}` });
    await expect(page.getByTestId("lobby-main")).toBeVisible();
    await expect(page.getByTestId("play-vs-ai-button")).toHaveText(/Jugar/i);
  });
}

test("PAS 10 — rules page in Catalan", async ({ page }) => {
  // The dev server does not serve the directory index: /regles/ca/ is the SPA shell.
  // The Catalan rules document is this file (h1 «Regles del joc», sections, not details).
  await page.goto("/regles/ca/index.html");
  await expect(page.locator("html")).toHaveAttribute("lang", "ca");
  await expect(page.getByRole("heading", { level: 1 })).toHaveText("Regles del joc");
  await expect(page.getByRole("heading", { level: 2, name: "Cartes i banca" })).toBeVisible();
  await expect(page.getByText(/7½|set i mig/i).first()).toBeVisible();
  await expect(page.getByText(/obligatori/i).first()).toBeVisible();
});

test("PAS 10 — two-browser friends flow + reload resume", async ({ browser }) => {
  test.setTimeout(180_000);
  const hostContext = await browser.newContext({ viewport: { width: 390, height: 844 } });
  const guestContext = await browser.newContext({ viewport: { width: 390, height: 844 } });
  const host = await hostContext.newPage();
  const guest = await guestContext.newPage();

  await passAgeGateToLobby(host, "HostPas10", { playerId: "pas10hostuser01", online: true });
  await createPrivateTable(host);
  const code = await readInviteCode(host);

  await passAgeGateToLobby(guest, "GuestPas10", { playerId: "pas10guestuser1", path: `/?t=${code}`, online: true });
  await expect(guest.getByTestId("private-waiting-panel")).toBeVisible({ timeout: 30_000 });

  await host.getByTestId("fill-private-bots").click();
  await expect(host.getByTestId("start-game-button")).toBeVisible({ timeout: 30_000 });
  await host.getByTestId("start-game-button").click();
  await expect(handSurface(host).first()).toBeVisible({ timeout: 60_000 });
  await expect(handSurface(guest).first()).toBeVisible({ timeout: 60_000 });

  await guest.reload();
  await expect(handSurface(guest).first()).toBeVisible({ timeout: 60_000 });

  await hostContext.close();
  await guestContext.close();
});

test("PAS 10 — keyboard shortcuts on desktop", async ({ page }) => {
  await page.setViewportSize({ width: 1280, height: 800 });
  await passAgeGateToLobby(page, "KeyUser", { playerId: "pas10keyboarduser1", online: true });
  await startAiGameFromLobby(page, 3);
  await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 45_000 });
  await expect(page.getByTestId("keyboard-hints")).toHaveCount(0);
  await page.keyboard.press("Escape");
  await expect(page.getByRole("dialog", { name: /Regles del Set i Mig/i })).toBeVisible();
});

test("PAS 10 — regression solo IA still starts", async ({ page }) => {
  await passAgeGateToLobby(page, "RegressSolo", { playerId: "pas10regressolo1", online: true });
  await startAiGameFromLobby(page, 3);
  await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 45_000 });
});

test("PAS 10 — capture screenshots", async ({ page, browser }) => {
  const out = screenshotDir();
  await page.setViewportSize({ width: 390, height: 844 });
  await passAgeGateToLobby(page, "ShotLobby", { playerId: "pas10shotlobby01" });
  await page.screenshot({ path: path.join(out, "01-friends-lobby-mobile.png"), fullPage: true });

  await page.goto("/regles/ca/index.html");
  await page.screenshot({ path: path.join(out, "04-rules-page.png"), fullPage: true });

  await page.setViewportSize({ width: 1280, height: 800 });
  await passAgeGateToLobby(page, "ShotDesktop", { playerId: "pas10shotdesk001", online: true });
  await startAiGameFromLobby(page, 3);
  await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 45_000 });
  await page.screenshot({ path: path.join(out, "02-pc-table.png"), fullPage: true });

  const hostContext = await browser.newContext({ viewport: { width: 390, height: 844 } });
  const host = await hostContext.newPage();
  await passAgeGateToLobby(host, "ShotHost", { playerId: "pas10shothost001", online: true });
  await createPrivateTable(host);
  await expect(host.getByTestId("private-invite-code")).toBeVisible({ timeout: 30_000 });
  await host.screenshot({ path: path.join(out, "03-mobile-private-table.png"), fullPage: true });
  await hostContext.close();
});
