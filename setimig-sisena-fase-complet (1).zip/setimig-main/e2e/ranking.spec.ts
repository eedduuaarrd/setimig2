import { expect, test, type Page } from "@playwright/test";
import { seedE2eLaunch } from "./helpers/e2eSession";
import { blockSocketIo } from "./helpers/loginSession";
import { RANKING_HIDDEN_NAMES, RANKING_VIEWER_ID, RANKING_VIEWER_NAME, RANKING_VIEWER_RANK } from "./helpers/rankingSeed";

async function openLobby(page: Page) {
  await seedE2eLaunch(page, RANKING_VIEWER_ID, { locale: "ca" });
  await page.addInitScript(() => {
    localStorage.setItem("setimig_player_name", "Nora");
    localStorage.setItem("setimig_onboarding_v1", "1");
    localStorage.setItem("setimig_interactive_tutorial_v1", "1");
    localStorage.setItem("setimig_home_intro_v1", "1");
    localStorage.setItem("setimig_install_banner_dismissed", "1");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
  });
  await blockSocketIo(page);
  await page.goto("/");
  await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 60_000 });
  await expect(page.getByTestId("lobby-open-ranking")).toBeVisible();
}

async function expectNoHorizontalOverflow(page: Page) {
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth > document.documentElement.clientWidth + 1);
  expect(overflow).toBe(false);
}

async function expectRanking(page: Page) {
  await page.route("**/api/ranking", async (route) => {
    await new Promise((resolve) => setTimeout(resolve, 400));
    await route.continue();
  });
  await page.getByTestId("lobby-open-ranking").click();
  await expect(page.getByTestId("ranking-loading")).toBeVisible();
  await expect(page.getByTestId("ranking-list")).toBeVisible({ timeout: 20_000 });
  await expect(page.getByTestId("ranking-loading")).toBeHidden();

  const medals = page.locator("[data-medal]");
  await expect(medals).toHaveCount(3);
  await expect(medals.nth(0)).toHaveAttribute("data-medal", "gold");
  await expect(medals.nth(1)).toHaveAttribute("data-medal", "silver");
  await expect(medals.nth(2)).toHaveAttribute("data-medal", "bronze");
  await expect(page.getByTestId("ranking-list").getByTestId("ranking-row")).toHaveCount(50);

  const outside = page.getByTestId("ranking-outside");
  await outside.scrollIntoViewIfNeeded();
  const mine = outside.getByTestId("ranking-row");
  await expect(mine).toHaveAttribute("data-me", "true");
  await expect(mine).toHaveAttribute("data-rank", String(RANKING_VIEWER_RANK));
  await expect(mine).toContainText(RANKING_VIEWER_NAME);

  const screenText = await page.getByTestId("ranking-screen").innerText();
  expect(screenText).toContain("Aina");
  expect(screenText).toContain("Biel");
  expect(screenText).toContain("Clara");
  for (const name of RANKING_HIDDEN_NAMES) expect(screenText).not.toContain(name);
  expect(screenText).not.toContain(RANKING_VIEWER_ID);
  expect(screenText).not.toContain("@");
  await expectNoHorizontalOverflow(page);
}

test("rànquing a 390×844: medalles, fila pròpia fora del top, sense desbordar", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await openLobby(page);
  const box = await page.getByTestId("lobby-open-ranking").boundingBox();
  expect(box).not.toBeNull();
  expect(box!.y).toBeGreaterThanOrEqual(0);
  expect(box!.y + box!.height).toBeLessThanOrEqual(844);
  await expect(page.getByTestId("lobby-open-ranking")).toHaveText(/Rànquing/);
  await expectNoHorizontalOverflow(page);
  await expectRanking(page);
});

test("rànquing a 1280: la mateixa llista cap en una pantalla d'escriptori", async ({ page }) => {
  await page.setViewportSize({ width: 1280, height: 800 });
  await openLobby(page);
  await expect(page.getByTestId("lobby-open-ranking")).toBeVisible();
  await expectRanking(page);
});

test("sense connexió i error, amb reintent", async ({ page, context }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await openLobby(page);

  await context.setOffline(true);
  await page.getByTestId("lobby-open-ranking").click();
  await expect(page.getByTestId("ranking-offline")).toBeVisible();
  await expect(page.getByTestId("ranking-list")).toHaveCount(0);
  await page.getByTestId("ranking-back").click();
  await expect(page.getByTestId("lobby-main")).toBeVisible();

  await context.setOffline(false);
  await page.route("**/api/ranking", (route) => route.fulfill({ status: 500, contentType: "application/json", body: "{}" }));
  await page.getByTestId("lobby-open-ranking").click();
  await expect(page.getByTestId("ranking-error")).toBeVisible();
  await expect(page.getByTestId("ranking-retry")).toBeVisible();

  await page.unroute("**/api/ranking");
  await page.getByTestId("ranking-retry").click();
  await expect(page.getByTestId("ranking-list")).toBeVisible();
  await expect(page.getByTestId("ranking-outside")).toBeVisible();
});

test("el menú tradueix Rànquing a es i en", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await openLobby(page);
  await page.addInitScript(() => localStorage.setItem("setimig.locale", "es"));
  await page.reload();
  await expect(page.getByTestId("lobby-open-ranking")).toHaveText(/Clasificación/);
  await page.addInitScript(() => localStorage.setItem("setimig.locale", "en"));
  await page.reload();
  await expect(page.getByTestId("lobby-open-ranking")).toHaveText(/^Ranking$/);
});
