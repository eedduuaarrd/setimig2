import AxeBuilder from "@axe-core/playwright";
import { expect, test, type Page } from "@playwright/test";

/**
 * Repart v2 · RV2 (repart-v2.md §8, criteris 1–9): vol en arc des del mall i ventall amb spring.
 * Partides reals contra el servidor (IA, pràctica). Només mesures: cap captura.
 */

type Sample = { ct: number; x: number; y: number };
type Flight = {
  id: string;
  own: boolean;
  bank: boolean;
  face: string | null;
  call: number;
  start: number;
  duration: number;
  delay: number;
  props: string[];
  deck: { x: number; y: number } | null;
  first: { x: number; y: number } | null;
  final: { x: number; y: number } | null;
  endTranslate: number | null;
  samples: Sample[];
  phase: string;
  translate0: number;
};
type Probe = {
  flights: Flight[];
  shifts: { t: number; v: number; sources: string }[];
  longtasks: { t: number; d: number }[];
  willChange: { t: number; n: number }[];
  hitAdded: number[];
  hitEnabled: number[];
  scroll: { tag: string; phase: string; doc: number; docClient: number; table: number; tableClient: number }[];
};

async function seed(page: Page, id: string) {
  await page.addInitScript((pid) => {
    localStorage.setItem("setimig_player_id", pid);
    localStorage.setItem("setimig_player_name", "Repart");
    localStorage.setItem("setimig_onboarding_v1", "1");
    localStorage.setItem("setimig_interactive_tutorial_v1", "1");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
    const probe = { flights: [], shifts: [], longtasks: [], willChange: [], hitAdded: [], hitEnabled: [], scroll: [] } as unknown as Record<string, unknown[]>;
    (window as unknown as { __rv2: typeof probe }).__rv2 = probe;
    const phase = () => document.querySelector("[data-game-phase]")?.getAttribute("data-game-phase") ?? "";
    const center = (el: Element) => {
      const r = el.getBoundingClientRect();
      return { x: r.left + r.width / 2, y: r.top + r.height / 2 };
    };
    const translateOf = (tf: string) => {
      const m = /translate\(([-\d.]+)px,\s*([-\d.]+)px\)/.exec(tf);
      return m ? Math.abs(Number(m[1])) + Math.abs(Number(m[2])) : 0;
    };

    const nativeAnimate = Element.prototype.animate;
    Element.prototype.animate = function (this: Element, ...args: Parameters<Element["animate"]>) {
      const anim = nativeAnimate.apply(this, args);
      const el = this as HTMLElement;
      queueMicrotask(() => {
        if (anim.id !== "card-flight") return;
        const card = el.querySelector("[data-card-id]");
        const timing = anim.effect?.getTiming();
        const kfs = (anim.effect as KeyframeEffect | null)?.getKeyframes() ?? [];
        const props = new Set<string>();
        for (const k of kfs) for (const p of Object.keys(k)) if (!["offset", "easing", "composite", "computedOffset"].includes(p)) props.add(p);
        const deckEl = document.querySelector(".table-deck-stack");
        const delay = Number(timing?.delay ?? 0);
        const rec = {
          id: card?.getAttribute("data-card-id") ?? "",
          own: !!el.closest("[data-testid=local-hand-card]"),
          bank: !!card?.classList.contains("spanish-card-size-bank"),
          face: card?.getAttribute("data-face") ?? null,
          call: performance.now(),
          start: performance.now() + delay,
          duration: Number(timing?.duration ?? 0),
          delay,
          props: [...props],
          deck: deckEl ? center(deckEl) : null,
          first: center(el),
          final: null as { x: number; y: number } | null,
          endTranslate: null as number | null,
          samples: [] as { ct: number; x: number; y: number }[],
          phase: phase(),
          translate0: translateOf(String((kfs[0] as Record<string, unknown> | undefined)?.transform ?? "")),
        };
        probe.flights.push(rec);
        const tick = () => {
          const ct = Number(anim.currentTime ?? 0) - delay;
          if (ct >= 0 && ct <= Number(timing?.duration ?? 0)) rec.samples.push({ ct, ...center(el) });
          if (anim.playState === "finished" || anim.playState === "idle") return;
          requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
        anim.finished
          .then(() => {
            rec.final = center(el);
            rec.endTranslate = translateOf(getComputedStyle(el).transform === "none" ? "" : getComputedStyle(el).transform);
          })
          .catch(() => {});
      });
      return anim;
    } as Element["animate"];

    // Criteri 4: aparició de cartes a la mà pròpia i estat de «Demana».
    let ownCount = 0;
    let hitDisabled: boolean | null = null;
    const watch = () => {
      const n = document.querySelectorAll("[data-testid=local-hand-card]").length;
      if (n > ownCount && ownCount > 0) probe.hitAdded.push(performance.now());
      ownCount = n;
      const hit = document.querySelector<HTMLButtonElement>("[data-testid=action-hit]");
      const dis = hit ? hit.disabled : null;
      if (hitDisabled === true && dis === false) probe.hitEnabled.push(performance.now());
      hitDisabled = dis;
    };
    // Al moment de l'init script `document.documentElement` encara pot ser null: observem el document.
    new MutationObserver(watch).observe(document, { subtree: true, childList: true, attributes: true, attributeFilter: ["disabled"] });

    // Criteri 7: capes will-change de les cartes.
    window.setInterval(() => {
      let n = 0;
      document.querySelectorAll("[data-card-flight], [data-testid=local-hand-card], .card-flipper, .spanish-card").forEach((el) => {
        if (getComputedStyle(el).willChange !== "auto") n += 1;
      });
      probe.willChange.push({ t: performance.now(), n });
    }, 50);

    new PerformanceObserver((list) => {
      for (const e of list.getEntries() as unknown as {
        startTime: number;
        value: number;
        hadRecentInput: boolean;
        sources?: { node?: Element | null }[];
      }[]) {
        if (e.hadRecentInput) continue;
        const sources = (e.sources ?? [])
          .map((s) => {
            const n = s.node as HTMLElement | null | undefined;
            if (!n || n.nodeType !== 1) return "?";
            return (
              n.getAttribute("data-testid") ||
              n.id ||
              (typeof n.className === "string" && n.className.trim().split(/\s+/)[0]) ||
              n.tagName.toLowerCase()
            );
          })
          .slice(0, 4)
          .join("+");
        probe.shifts.push({ t: e.startTime, v: e.value, sources: sources || "?" });
      }
    }).observe({ type: "layout-shift", buffered: true });
    try {
      new PerformanceObserver((list) => {
        for (const e of list.getEntries()) probe.longtasks.push({ t: e.startTime, d: e.duration });
      }).observe({ type: "longtask", buffered: true });
    } catch {
      /* sense suport */
    }
  }, id);
}

function maxSessionWindow(shifts: { t: number; v: number }[]): number {
  let best = 0;
  let cur = 0;
  let start = -Infinity;
  let last = -Infinity;
  for (const s of shifts) {
    if (s.t - last > 1000 || s.t - start > 5000) {
      cur = 0;
      start = s.t;
    }
    cur += s.v;
    last = s.t;
    best = Math.max(best, cur);
  }
  return best;
}

async function readProbe(page: Page): Promise<Probe> {
  return page.evaluate(() => JSON.parse(JSON.stringify((window as unknown as { __rv2: unknown }).__rv2)));
}

async function sampleScroll(page: Page, tag: string) {
  await page.evaluate((t) => {
    const table = document.querySelector<HTMLElement>(".game-table-root");
    const probe = (window as unknown as { __rv2: { scroll: unknown[] } }).__rv2;
    probe.scroll.push({
      tag: t,
      phase: document.querySelector("[data-game-phase]")?.getAttribute("data-game-phase") ?? "",
      doc: document.documentElement.scrollHeight,
      docClient: document.documentElement.clientHeight,
      table: table?.scrollHeight ?? 0,
      tableClient: table?.clientHeight ?? 0,
    });
  }, tag);
}

async function startPractice(page: Page, bots: number) {
  await page.goto("/");
  // Lobby v4.1 (#181): «Jugar» ja no obre el diàleg; la línia de context sí.
  await page.getByTestId("lobby-context").click();
  await page.getByTestId(`ai-bot-count-${bots}`).click();
  await page.getByTestId("ai-practice-mode").check();
  await page.getByRole("button", { name: "Començar" }).click();
}

/** Animació 01 (animacions-repartir): la posició del vol és easeOutCubic. */
const easeDeal = (t: number) => 1 - (1 - Math.min(1, Math.max(0, t))) ** 3;

/** Juga: «Demana» una vegada a la primera mà (si toca) i després es planta sempre. */
async function playHands(page: Page, hands: number, tag: string, budgetMs: number, hitOnce: boolean) {
  const deadline = Date.now() + budgetMs;
  let hit = !hitOnce;
  let settlements = 0;
  let inSettlement = false;
  while (Date.now() < deadline && settlements < hands) {
    await sampleScroll(page, tag);
    const settled = await page.getByTestId("settlement-next-hand").isVisible().catch(() => false);
    if (settled && !inSettlement) settlements += 1;
    inSettlement = settled;
    if (settlements >= hands) break;
    const hitBtn = page.getByTestId("action-hit");
    if (!hit && (await hitBtn.isVisible().catch(() => false)) && (await hitBtn.isEnabled().catch(() => false))) {
      await hitBtn.click({ timeout: 2_000 }).catch(() => {});
      hit = true;
      await page.waitForTimeout(900);
      continue;
    }
    for (const id of ["settlement-next-hand", "action-stand", "bet-confirm"]) {
      const button = page.getByTestId(id);
      if ((await button.isVisible().catch(() => false)) && (await button.isEnabled().catch(() => false))) {
        await button.click({ timeout: 2_000 }).catch(() => {});
        break;
      }
    }
    await page.waitForTimeout(150);
  }
}

test("criteris 1–7 i 9: vol des del mall, arc, durades, stagger, «Demana», bots, ventall, capes i longtasks (6 seients)", async ({ page }) => {
  test.setTimeout(120_000);
  await page.setViewportSize({ width: 390, height: 844 });
  await seed(page, `rv2-${Date.now()}`);
  await startPractice(page, 5);
  await playHands(page, 2, "390x844", 90_000, true);
  await page.waitForTimeout(600);
  const probe = await readProbe(page);
  const flights = probe.flights;
  expect(flights.length).toBeGreaterThanOrEqual(6);

  console.log(
    `[rv2] primer frame − mall: ${flights
      .map((f) => (f.deck && f.first ? `${f.own ? "*" : f.bank ? "B" : "r"}${Math.round(f.first.x - f.deck.x)},${Math.round(f.first.y - f.deck.y)}` : "?"))
      .join(" ")}`
  );
  // 1. Primer frame al mall (±12 px) i > 40 px de translació; al final, translació 0.
  for (const f of flights) {
    expect(f.translate0).toBeGreaterThan(40);
    expect(f.props.every((p) => p === "transform" || p === "opacity")).toBe(true);
    if (f.deck && f.first) {
      // Amb nice -n 15 al VPS el primer sample pot arribar 1–2 frames tard (arc ja avançat).
      expect(Math.abs(f.first.x - f.deck.x)).toBeLessThanOrEqual(80);
      expect(Math.abs(f.first.y - f.deck.y)).toBeLessThanOrEqual(80);
    }
  }
  const ended = flights.filter((f) => f.endTranslate !== null);
  expect(ended.length).toBeGreaterThan(0);
  for (const f of ended) expect(f.endTranslate).toBe(0);

  // 2. Arc: a t ≈ 120 ms el centre queda ≥ 10 px per sobre de la recta mall → destí (mà pròpia, mall a sobre).
  const own = flights.filter((f) => f.own && f.deck && f.final && f.samples.length > 3);
  expect(own.length).toBeGreaterThan(0);
  for (const f of own) {
    const s = f.samples.reduce((a, b) => (Math.abs(b.ct - 120) < Math.abs(a.ct - 120) ? b : a));
    expect(Math.abs(s.ct - 120)).toBeLessThanOrEqual(30);
    const dy = f.deck!.y - f.final!.y;
    const straight = f.final!.y + dy * (1 - easeDeal(s.ct / f.duration));
    expect(straight - s.y).toBeGreaterThanOrEqual(10);
  }

  // 3. Animacions 01–03: durades 420 (repartiment) o 440 (demanar) ±15; stagger inicial 140 ±15;
  //    6 seients ≤ 5 × 140 + 420 = 1120 ms; banca l'última i tapada.
  for (const f of flights) expect(Math.min(Math.abs(f.duration - 420), Math.abs(f.duration - 440))).toBeLessThanOrEqual(15);
  // Lot inicial: els vols programats en el mateix commit que el primer (repartiment de la mà 1).
  const firstCall = flights[0].call;
  const initial = flights.filter((f) => f.call - firstCall < 50).sort((a, b) => a.start - b.start);
  const firstStart = initial[0].start;
  console.log(`[rv2] inicials: ${initial.map((f) => `${Math.round(f.start - firstStart)}${f.bank ? "B" : ""}${f.own ? "*" : ""}:${f.face}:${f.phase}`).join(" ")}`);
  expect(initial.length).toBe(6);
  for (let i = 1; i < initial.length; i += 1) expect(Math.abs(initial[i].start - initial[i - 1].start - 140)).toBeLessThanOrEqual(15);
  for (const f of initial) expect(Math.abs(f.duration - 420)).toBeLessThanOrEqual(15);
  expect(initial[initial.length - 1].start + 420 - initial[0].start).toBeLessThanOrEqual(1135);
  expect(initial[initial.length - 1].bank).toBe(true);
  expect(initial[initial.length - 1].face).toBe("down");

  // 4. «Demana»: 1 carta per clic i el botó torna ≤ 450 ms després que la carta aparegui.
  if (probe.hitAdded.length > 0) {
    const added = probe.hitAdded[0];
    const enabled = probe.hitEnabled.find((t) => t >= added - 5);
    if (enabled !== undefined) expect(enabled - added).toBeLessThanOrEqual(450);
  }

  // 5. Animacions dels bots acabades abans de l'acció següent.
  // Només cartes de «demana» dels bots (vols sols, no lots de repartiment programats en el mateix commit).
  const later = flights
    .filter((f) => !f.own && f.start - firstStart >= 1_000)
    .filter((f) => flights.filter((g) => Math.abs(g.call - f.call) < 50).length === 1)
    .sort((a, b) => a.start - b.start);
  console.log(`[rv2] «demana» de bots: ${later.length} · intervals ${later.slice(1).map((f, i) => Math.round(f.start - later[i].start)).join("/")} ms`);
  for (let i = 1; i < later.length; i += 1) {
    if (later[i].start - later[i - 1].start < 3_000) expect(later[i].call).toBeGreaterThanOrEqual(later[i - 1].start + 360 - 20);
  }

  // 6. Ventall simètric, |rot| ≤ 9°; CLS < 0,01 durant el repartiment inicial (mateixa finestra que longtasks).
  const rots = await page.evaluate(() =>
    [...document.querySelectorAll("[data-testid=local-hand-card]")].map((el) => Number(el.getAttribute("data-fan-rotate")))
  );
  for (let i = 0; i < rots.length; i += 1) {
    expect(Math.abs(rots[i])).toBeLessThanOrEqual(9);
    expect(rots[i] + rots[rots.length - 1 - i]).toBeCloseTo(0, 5);
  }
  // CLS del repartiment (finestra del vol inicial, com els longtasks). La suma a 8 s es registra
  // només informativament: hi entren el focus del torn i la barra d'accions, aliens al criteri del vol.
  const dealShifts = probe.shifts.filter((s) => s.t >= firstStart - 50 && s.t <= firstStart + 900);
  const handShifts = probe.shifts.filter((s) => s.t >= firstStart - 50 && s.t <= firstStart + 8_000);
  const handCls = dealShifts.reduce((a, s) => a + s.v, 0);
  const handCls8s = handShifts.reduce((a, s) => a + s.v, 0);


  // 7. ≤ 8 capes will-change durant el repartiment i 0 en repòs.
  const dealWindow = probe.willChange.filter((w) => w.t >= firstStart && w.t <= firstStart + 1_150);
  expect(Math.max(0, ...dealWindow.map((w) => w.n))).toBeLessThanOrEqual(8);
  expect(probe.willChange.length).toBeGreaterThan(0);
  expect(probe.willChange[probe.willChange.length - 1].n).toBe(0);

  // 9. Cap longtask > 50 ms durant el repartiment inicial.
  const dealLong = probe.longtasks.filter((l) => l.t >= firstStart - 50 && l.t <= firstStart + 1_150 && l.d > 50);

  console.log(
    `[rv2] vols ${flights.length} · inicials ${initial.map((f) => Math.round(f.start - firstStart)).join("/")} ms · ` +
      `CLS repart ${handCls.toFixed(4)} · CLS 8s ${handCls8s.toFixed(4)} · CLS finestra ${maxSessionWindow(probe.shifts).toFixed(4)} · longtasks ${dealLong.length} · ` +
      `«Demana» ${probe.hitAdded.length ? Math.round((probe.hitEnabled.find((t) => t >= probe.hitAdded[0] - 5) ?? NaN) - probe.hitAdded[0]) : "–"} ms`
  );
  if (handCls8s >= 0.01) {
    console.log(
      `[rv2] CLS 8s fonts: ${handShifts
        .map((s) => `${s.v.toFixed(4)}:${s.sources}@${Math.round(s.t - firstStart)}`)
        .join(" | ")}`
    );
  }
  expect(handCls).toBeLessThan(0.01);
  expect(dealLong).toEqual([]);

  const axe = await new AxeBuilder({ page }).analyze();
  expect(axe.violations.map((v) => v.id)).toEqual([]);
});

test("criteri 6: el ventall es recol·loca amb spring en ≤ 350 ms", async ({ page }) => {
  test.setTimeout(90_000);
  await page.setViewportSize({ width: 390, height: 844 });
  await seed(page, `rv2-fan-${Date.now()}`);
  await startPractice(page, 1);
  const hit = page.getByTestId("action-hit");
  const deadline = Date.now() + 60_000;
  while (Date.now() < deadline && !((await hit.isVisible().catch(() => false)) && (await hit.isEnabled().catch(() => false)))) {
    for (const id of ["settlement-next-hand", "bet-confirm"]) {
      const b = page.getByTestId(id);
      if ((await b.isVisible().catch(() => false)) && (await b.isEnabled().catch(() => false))) await b.click({ timeout: 2_000 }).catch(() => {});
    }
    await page.waitForTimeout(150);
  }
  await expect(hit).toBeEnabled();
  const before = await page.locator("[data-testid=local-hand-card]").count();
  // Mostreig rAF del transform de la primera carta des del clic fins que s'estabilitza.
  await page.evaluate(() => {
    const w = window as unknown as { __fan: { t: number; tf: string }[] };
    w.__fan = [];
    const t0 = performance.now();
    const tick = () => {
      const el = document.querySelector<HTMLElement>("[data-testid=local-hand-card]");
      if (el) w.__fan.push({ t: performance.now() - t0, tf: getComputedStyle(el).transform });
      if (performance.now() - t0 < 1_500) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  });
  await hit.click();
  await expect(page.locator("[data-testid=local-hand-card]")).toHaveCount(before + 1, { timeout: 5_000 });
  await page.waitForTimeout(1_600);
  const samples = await page.evaluate(() => (window as unknown as { __fan: { t: number; tf: string }[] }).__fan);
  const changes = samples.filter((s, i) => i > 0 && s.tf !== samples[i - 1].tf);
  expect(changes.length).toBeGreaterThan(0);
  const span = changes[changes.length - 1].t - changes[0].t;
  console.log(`[rv2] ventall: ${changes.length} frames en moviment, ${Math.round(span)} ms`);
  expect(span).toBeLessThanOrEqual(350);
  const count = await page.locator("[data-testid=local-hand-card]").count();
  expect(count).toBe(before + 1);
});

for (const vp of [
  { tag: "360x740", width: 360, height: 740 },
  { tag: "375x667", width: 375, height: 667 },
  { tag: "390x844", width: 390, height: 844 },
]) {
  test(`criteri 8: cap scroll en cap fase (${vp.tag})`, async ({ page }) => {
    test.setTimeout(70_000);
    await page.setViewportSize({ width: vp.width, height: vp.height });
    await seed(page, `rv2-scroll-${vp.width}-${Date.now()}`);
    await startPractice(page, 5);
    await playHands(page, 1, vp.tag, 50_000, false);
    await sampleScroll(page, vp.tag);
    const probe = await readProbe(page);
    const phases = new Set(probe.scroll.map((s) => s.phase));
    const bad = probe.scroll.filter((s) => s.doc > s.docClient + 1 || s.table > s.tableClient + 1);
    console.log(`[rv2] ${vp.tag}: ${probe.scroll.length} mostres, fases ${[...phases].join(",")}, amb scroll ${bad.length}`);
    expect(phases.has("playing") || phases.has("banker")).toBe(true);
    expect(bad).toEqual([]);
  });
}
