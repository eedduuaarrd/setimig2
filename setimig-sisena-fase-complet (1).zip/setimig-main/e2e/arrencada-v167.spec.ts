/**
 * v167 · intro literal: port de l'animació de referència (setimig_intro_v163_mobil/pc.mp4, intro163/i.html).
 * Fotogrames fixats amb window.__introRender(t) (com el renderitzador r.py) a 390×844 i 1280×800.
 */
import { expect, test, type Browser } from "@playwright/test";

const PID = "v167-player-01";
const TOKEN = "v167.token";

async function open(browser: Browser, vp: { width: number; height: number }, opts: { session?: boolean; reduce?: boolean } = {}) {
  const ctx = await browser.newContext({ viewport: vp, deviceScaleFactor: 1, locale: "en-US", colorScheme: "dark", reducedMotion: opts.reduce ? "reduce" : "no-preference", storageState: { cookies: [], origins: [] }, serviceWorkers: "block" });
  await ctx.addInitScript(
    ({ session, pid, token }) => {
      localStorage.setItem("setimig.locale", "en");
      localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
      if (session) {
        localStorage.setItem("setimig_player_id", pid);
        localStorage.setItem("setimig_player_token", token);
        localStorage.setItem("setimig_player_name", "Edu");
        localStorage.setItem("setimig_onboarding_v1", "1");
        localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      }
      const w = window as unknown as { __cls: number };
      w.__cls = 0;
      try {
        new PerformanceObserver((l) => {
          for (const e of l.getEntries() as unknown as { value: number; hadRecentInput: boolean }[]) if (!e.hadRecentInput) w.__cls += e.value;
        }).observe({ type: "layout-shift", buffered: true });
      } catch {
        /* sense API */
      }
    },
    { session: !!opts.session, pid: PID, token: TOKEN }
  );
  await ctx.routeWebSocket(/socket\.io/, () => {});
  await ctx.route(/\/socket\.io\//, (r) => r.abort());
  await ctx.route(/\/api\//, async (route) => {
    const p = new URL(route.request().url()).pathname;
    if (p === "/api/auth/providers") return route.fulfill({ json: { email: true, google: true, passkey: true, rpId: "sevenhalf.club" } });
    if (p === "/api/player-session" && !route.request().headers()["authorization"]) return route.fulfill({ status: 401, json: { error: "auth_required" } });
    if (p === "/api/player-session") return route.fulfill({ json: { playerId: PID, playerToken: TOKEN } });
    if (p === "/api/balance") return route.fulfill({ json: { chips: 1000, freeClaim: { available: false, nextAt: null } } });
    if (p === "/api/auth/me") return route.fulfill({ json: { playerId: PID, emails: ["edu@example.com"], google: false, passkeys: 0, verified: true } });
    return route.fulfill({ status: 404, json: { error: "no", code: "NOT_FOUND" } });
  });
  return { ctx, page: await ctx.newPage() };
}


const SHOTS = process.env.INTRO_SHOTS_DIR;
declare global { interface Window { __introRender?: (t: number) => void } }

for (const vp of [{ width: 390, height: 844 }, { width: 1280, height: 800 }]) {
  test(`intro literal a ${vp.width}×${vp.height}: seqüència, ventall i cap retall`, async ({ browser }) => {
    const { ctx, page } = await open(browser, vp);
    await page.goto("/login");
    await expect(page.getByTestId("home-intro")).toBeVisible();
    await expect(page.getByTestId("home-intro-back")).toHaveCount(vp.height > vp.width ? 9 : 13);
    await expect(page.getByTestId("home-intro")).not.toContainText("18+");
    await page.waitForFunction(() => typeof window.__introRender === "function");
    for (const t of [0, 1.2, 2.4, 4, 6.2, 7.8, 9.5]) {
      await page.evaluate((t) => window.__introRender!(t), t);
      if (SHOTS) await page.screenshot({ path: `${SHOTS}/app-${vp.width}-t${t}.png` });
      const boxes = await page.evaluate(() =>
        ["home-intro-7", "home-intro-rei", "home-intro-wordmark"].map((id) => {
          const e = document.querySelector<HTMLElement>(`[data-testid='${id}']`)!;
          const r = e.getBoundingClientRect();
          return { id, o: Number(getComputedStyle(e).opacity), l: r.left, t: r.top, r: r.right, b: r.bottom };
        })
      );
      for (const b of boxes) {
        if (b.o < 0.05) continue;
        expect(b.l, `${b.id} @${t}`).toBeGreaterThanOrEqual(-1);
        expect(b.t, `${b.id} @${t}`).toBeGreaterThanOrEqual(-1);
        expect(b.r, `${b.id} @${t}`).toBeLessThanOrEqual(vp.width + 1);
        expect(b.b, `${b.id} @${t}`).toBeLessThanOrEqual(vp.height + 1);
      }
      if (t === 4) expect(Number(await page.getByTestId("home-intro-back").nth(0).evaluate((e) => getComputedStyle(e).opacity))).toBeGreaterThan(0.9);
      if (t === 7.8) expect(Number(await page.getByTestId("home-intro-wordmark").evaluate((e) => getComputedStyle(e).opacity))).toBeGreaterThan(0.9);
    }
    expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(vp.width);
    await ctx.close();
  });
}

// v180: sense tocar (un toc ara salta l'intro; ho cobreix intro-primer.spec.ts).
test("intro literal acaba sola al destí (~9 s) i el SW té versió", async ({ browser }) => {
  const { ctx, page } = await open(browser, { width: 390, height: 844 });
  await page.goto("/login");
  await expect(page.getByTestId("home-intro")).toBeVisible();
  await page.keyboard.press("Tab");
  await page.keyboard.press("Escape");
  await page.waitForTimeout(5000);
  await expect(page.getByTestId("home-intro")).toBeVisible();
  await expect(page.getByTestId("launch-intro")).toHaveCount(0, { timeout: 8000 });
  await expect(page.getByTestId("login-page")).toBeVisible();
  const sw = await (await page.request.get("/sw.js")).text();
  expect(sw).toMatch(/"setimig-shell-v\d+"/);
  await ctx.close();
});

test("moviment reduït: fotograma quiet i curt", async ({ browser }) => {
  const { ctx, page } = await open(browser, { width: 390, height: 844 }, { reduce: true });
  await page.goto("/login");
  await expect(page.getByTestId("home-intro-wordmark")).toBeVisible();
  await expect(page.getByTestId("launch-intro")).toHaveCount(0, { timeout: 4000 });
  await ctx.close();
});

// Comprovacions de splash/manifest heretades d'arrencada-v162 (la intro antiga del logo ja no existeix).
const DARK = [14, 15, 12];

test("splash natives d'iOS: totes existeixen, són fosques i noves (v163); manifest #0E0F0C", async ({ page, request }) => {
  const html = await (await request.get("/")).text();
  const hrefs = [...html.matchAll(/rel="apple-touch-startup-image" href="([^"]+)"/g)].map((m) => m[1]);
  expect(hrefs.length).toBeGreaterThanOrEqual(20);
  for (const h of hrefs) expect(h, "noms nous (la cache d'iOS no reutilitza les antigues)").toMatch(/\/splash\/apple-splash-v180-\d+-\d+\.png$/);
  await page.goto("/offline.html").catch(() => {});
  const res = await page.evaluate(async (list) => {
    const out: { h: string; ok: boolean; corner: number[]; top: number[] }[] = [];
    for (const h of list) {
      const img = new Image();
      img.src = h;
      const ok = await img.decode().then(() => true, () => false);
      const c = document.createElement("canvas");
      c.width = img.naturalWidth || 1;
      c.height = img.naturalHeight || 1;
      const g = c.getContext("2d")!;
      if (ok) g.drawImage(img, 0, 0);
      const px = (x: number, y: number) => [...g.getImageData(x, y, 1, 1).data].slice(0, 3);
      out.push({ h, ok, corner: px(2, 2), top: px(Math.floor(c.width / 2), Math.floor(c.height * 0.05)) });
    }
    return out;
  }, hrefs);
  for (const r of res) {
    expect(r.ok, `${r.h} existeix`).toBe(true);
    for (const p of [r.corner, r.top]) for (let i = 0; i < 3; i++) expect(Math.abs(p[i] - DARK[i]), `${r.h} fosca`).toBeLessThanOrEqual(3);
  }
  const mf = await (await request.get("/site.webmanifest")).json();
  expect(mf.background_color.toUpperCase()).toBe("#0E0F0C");
  expect(mf.theme_color.toUpperCase()).toBe("#0E0F0C");
  expect(html).toContain('<meta name="theme-color" content="#0E0F0C"');
  const sw = await (await request.get("/sw.js")).text();
  expect(sw).toMatch(/"setimig-shell-v\d+"/);
  expect(sw).toContain('"/brand/logo-splash-v163.png"');
});

test("asset de la splash: cap píxel opac a les vores (el fum no es talla en recte)", async ({ page }) => {
  await page.goto("/offline.html").catch(() => {});
  const edge = await page.evaluate(async () => {
    const img = new Image();
    img.src = "/brand/logo-splash-v163.png";
    await img.decode();
    const c = document.createElement("canvas");
    c.width = img.naturalWidth;
    c.height = img.naturalHeight;
    const g = c.getContext("2d")!;
    g.drawImage(img, 0, 0);
    const d = g.getImageData(0, 0, c.width, c.height).data;
    let max = 0;
    for (let y = 0; y < c.height; y++)
      for (let x = 0; x < c.width; x++) if (x < 3 || y < 3 || x >= c.width - 3 || y >= c.height - 3) max = Math.max(max, d[(y * c.width + x) * 4 + 3]);
    return max;
  });
  expect(edge).toBeLessThanOrEqual(8);
});

/* v174: la apple-touch-startup-image ha de ser exactament el fotograma 0 de la intro (cap salt en passar a l'app).
   A 390×844 (iPhone 14/15, 1170×2532 @3x) es fixa t=0 amb __introRender(0), es fa captura i es compara el color
   mitjà i el píxel més allunyat amb la splash corresponent, reduïdes totes dues a la mateixa graella. */
test("splash d'iOS = fotograma 0 de la intro (390×844)", async ({ browser }) => {
  const { ctx, page } = await open(browser, { width: 390, height: 844 });
  await page.goto("/login");
  await expect(page.getByTestId("home-intro")).toBeVisible();
  await page.waitForFunction(() => typeof window.__introRender === "function");
  await page.evaluate(() => window.__introRender!(0));
  await page.waitForTimeout(100);
  const href = await page.locator('link[rel=apple-touch-startup-image][media*="device-width: 390px"][media*="portrait"]').first().getAttribute("href");
  expect(href).toBeTruthy();
  const shot = (await page.screenshot()).toString("base64");
  const stats = await page.evaluate(async ({ shot, href }) => {
    const load = (src: string) => new Promise<HTMLImageElement>((ok, ko) => { const i = new Image(); i.onload = () => ok(i); i.onerror = ko; i.src = src; });
    const grid = async (src: string) => {
      const img = await load(src);
      const c = document.createElement("canvas");
      c.width = 39; c.height = 84;
      const g = c.getContext("2d")!;
      g.drawImage(img, 0, 0, 39, 84);
      return g.getImageData(0, 0, 39, 84).data;
    };
    const a = await grid(`data:image/png;base64,${shot}`);
    const b = await grid(href!);
    let max = 0; const avgA = [0, 0, 0], avgB = [0, 0, 0];
    for (let i = 0; i < a.length; i += 4) for (let k = 0; k < 3; k++) {
      max = Math.max(max, Math.abs(a[i + k] - b[i + k])); avgA[k] += a[i + k]; avgB[k] += b[i + k];
    }
    const n = a.length / 4;
    return { max, avgDiff: Math.max(...avgA.map((v, k) => Math.abs(v - avgB[k]) / n)) };
  }, { shot, href });
  console.log(`[splash-fotograma0] ${href} ${JSON.stringify(stats)}`);
  expect(stats.avgDiff, "color mitjà").toBeLessThanOrEqual(3);
  expect(stats.max, "cap píxel diferent (cartes, aura, logo)").toBeLessThanOrEqual(12);
  await ctx.close();
});

/* v174: la intro (contenidor, fons i llenç de partícules) omple tota la pantalla, també després de redimensionar
   (a l'iPhone quedava una franja grisa a baix). Colors de html/body/theme-color = color de les startup images. */
test("intro a pantalla completa a 390×844, també després de redimensionar", async ({ browser }) => {
  const { ctx, page } = await open(browser, { width: 390, height: 844 });
  await page.goto("/login");
  await expect(page.getByTestId("home-intro")).toBeVisible();
  await page.waitForFunction(() => typeof window.__introRender === "function");
  const check = async (w: number, h: number) => {
    await page.waitForTimeout(300);
    const m = await page.evaluate(() => {
      const b = (s: string) => { const r = document.querySelector(s)!.getBoundingClientRect(); return { l: r.left, t: r.top, w: r.width, h: r.height }; };
      const fx = document.querySelector<HTMLCanvasElement>(".hil-fx")!;
      return { root: b("[data-testid=home-intro]"), fx: b(".hil-fx"), fxPx: { w: fx.width, h: fx.height }, dpr: Math.min(2, devicePixelRatio || 1),
        html: getComputedStyle(document.documentElement).backgroundColor, body: getComputedStyle(document.body).backgroundColor,
        theme: document.querySelector('meta[name="theme-color"]')!.getAttribute("content") };
    });
    for (const k of ["root", "fx"] as const) {
      expect(m[k].l, `${k} esquerra`).toBeLessThanOrEqual(0.5);
      expect(m[k].t, `${k} dalt`).toBeLessThanOrEqual(0.5);
      expect(m[k].w, `${k} ample`).toBeGreaterThanOrEqual(w - 0.5);
      expect(m[k].h, `${k} alt`).toBeGreaterThanOrEqual(h - 0.5);
    }
    expect(Math.abs(m.fxPx.h - h * m.dpr), "llenç redimensionat (alt)").toBeLessThanOrEqual(2);
    expect(Math.abs(m.fxPx.w - w * m.dpr), "llenç redimensionat (ample)").toBeLessThanOrEqual(2);
    expect(m.html).toBe("rgb(14, 15, 12)");
    expect(m.body).toBe("rgb(14, 15, 12)");
    expect(m.theme?.toUpperCase()).toBe("#0E0F0C");
  };
  await check(390, 844);
  await page.setViewportSize({ width: 390, height: 700 });
  await check(390, 700);
  await page.setViewportSize({ width: 390, height: 932 });
  await check(390, 932);
  await ctx.close();
});
