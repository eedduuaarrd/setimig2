import AxeBuilder from "@axe-core/playwright";
import { readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";
import { expect, test, type Page } from "@playwright/test";
import { startAiGameFromLobby } from "./helpers/aiLobby.ts";

/**
 * Animacions v1 · PR1 «rendiment» (animacions-v1.md §4 PR1, A10).
 * Durant unes quantes mans contra la IA: totes les transicions i animacions només toquen
 * transform/opacity, el CLS no empitjora respecte de main (línia base mesurada amb aquest mateix
 * escenari a origin/main, e2e/fixtures/animacions-v1-cls-main.json) i no hi ha scroll. Sense captures.
 */
const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844 },
  { tag: "375x667", width: 375, height: 667 },
  { tag: "360x740", width: 360, height: 740 },
] as const;
const HANDS = Number(process.env.ANIM1_HANDS ?? 4);
/** Línia base de main (mateix escenari, mateixes mides). ANIM1_BASELINE=0 només mesura (per regenerar-la a main). */
const BASELINE = JSON.parse(readFileSync(join("e2e", "fixtures", "animacions-v1-cls-main.json"), "utf8")) as {
  viewports: Record<string, { perHand: number; worst: number }>;
};
const CHECK_BASELINE = process.env.ANIM1_BASELINE !== "0";
/** Marge sobre main: soroll de la partida (cartes aleatòries) entre execucions. */
const TOLERANCE = { perHand: 0.01, worst: 0.01 };
const ALLOWED = new Set(["transform", "opacity", "translate", "scale", "rotate"]);
const KEYFRAME_META = new Set(["offset", "computedOffset", "easing", "composite"]);

type Probe = { props: Record<string, string[]>; cls: number; shifts: number; sources: Record<string, number>; worst?: number };

async function installProbe(page: Page) {
  await page.addInitScript(
    ({ meta }) => {
      const metaSet = new Set(meta);
      const w = window as unknown as { __anim: { props: Record<string, string[]>; cls: number; shifts: number; sources: Record<string, number> } };
      w.__anim = { props: {}, cls: 0, shifts: 0, sources: {} };
      const describe = (el: Element | null) => {
        if (!el) return "?";
        const id = el.getAttribute("data-testid");
        const cls = typeof el.className === "string" ? el.className.split(/\s+/).filter(Boolean).slice(0, 3).join(".") : "";
        return `${el.tagName.toLowerCase()}${id ? `[${id}]` : ""}${cls ? `.${cls}` : ""}`;
      };
      const note = (prop: string, where: string) => {
        const list = (w.__anim.props[prop] ??= []);
        if (list.length < 5 && !list.includes(where)) list.push(where);
      };
      document.addEventListener("transitionrun", (e) => note((e as TransitionEvent).propertyName, `transition ${describe(e.target as Element)}`), true);
      const scan = () => {
        for (const a of document.getAnimations()) {
          const target = (a.effect as KeyframeEffect | null)?.target ?? null;
          if (a instanceof CSSTransition) {
            note(a.transitionProperty, `transition ${describe(target)}`);
            continue;
          }
          const name = a instanceof CSSAnimation ? `@keyframes ${a.animationName}` : "waapi";
          const frames = (a.effect as KeyframeEffect | null)?.getKeyframes() ?? [];
          for (const f of frames) for (const k of Object.keys(f)) if (!metaSet.has(k)) note(k, `${name} ${describe(target)}`);
        }
      };
      document.addEventListener("animationstart", scan, true);
      setInterval(scan, 80);
      new PerformanceObserver((list) => {
        type Shift = { value: number; hadRecentInput: boolean; sources?: { node?: Node | null }[] };
        for (const entry of list.getEntries() as unknown as Shift[]) {
          if (entry.hadRecentInput) continue;
          w.__anim.cls += entry.value;
          w.__anim.shifts += 1;
          // Finestra de sessió de Chrome (CLS de Web Vitals): salts < 1 s, finestra ≤ 5 s.
          const t = (entry as unknown as { startTime: number }).startTime;
          const win = w.__anim as unknown as { winStart: number; winLast: number; winValue: number; worst: number };
          if (t - (win.winLast ?? -1e9) < 1000 && t - win.winStart < 5000) win.winValue += entry.value;
          else {
            win.winStart = t;
            win.winValue = entry.value;
          }
          win.winLast = t;
          win.worst = Math.max(win.worst ?? 0, win.winValue);
          for (const src of entry.sources ?? []) {
            const key = describe(src.node instanceof Element ? src.node : (src.node?.parentElement ?? null));
            w.__anim.sources[key] = (w.__anim.sources[key] ?? 0) + entry.value;
          }
          {
            const phase = document.querySelector("[data-game-phase]")?.getAttribute("data-game-phase") ?? "?";
            const s0 = (entry.sources ?? [])[0] as unknown as { node?: Node; previousRect?: DOMRectReadOnly; currentRect?: DOMRectReadOnly } | undefined;
            const el = s0?.node instanceof Element ? s0.node : (s0?.node?.parentElement ?? null);
            const r = (x?: DOMRectReadOnly) => (x ? `${Math.round(x.x)},${Math.round(x.y)} ${Math.round(x.width)}x${Math.round(x.height)}` : "");
            ((w.__anim as unknown as { log: string[] }).log ??= []).push(
              `${Math.round(performance.now())} ${phase} ${entry.value.toFixed(4)} ` + ((entry.sources ?? []) as unknown as { node?: Node; previousRect?: DOMRectReadOnly; currentRect?: DOMRectReadOnly }[]).map((s) => `${describe(s.node instanceof Element ? s.node : (s.node?.parentElement ?? null))} ${r(s.previousRect)} → ${r(s.currentRect)}`).join(" ;; ")
            );
          }
        }
      }).observe({ type: "layout-shift", buffered: true });
    },
    { meta: [...KEYFRAME_META] }
  );
}

async function seedLobby(page: Page, id: string) {
  await page.addInitScript(
    ({ pid, age }) => {
      if (sessionStorage.getItem("anim1_seeded") === "1") return;
      sessionStorage.setItem("anim1_seeded", "1");
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", "Anim");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_age_gate", age);
    },
    { pid: id, age: JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }) }
  );
}

async function scrollState(page: Page) {
  return page.evaluate(() => {
    const doc = document.scrollingElement ?? document.documentElement;
    const table = document.querySelector<HTMLElement>(".game-table-root");
    return {
      doc: doc.scrollHeight - doc.clientHeight,
      table: table ? table.scrollHeight - table.clientHeight : 0,
    };
  });
}

/** Espera curta que no falla si la pàgina ja s'ha tancat (fi de test o timeout). */
async function pause(page: Page, ms: number) {
  if (page.isClosed()) return;
  await page.waitForTimeout(ms).catch(() => undefined);
}

async function visible(page: Page, testId: string) {
  return page.getByTestId(testId).first().isVisible().catch(() => false);
}

function sourceFiles(dir: string): string[] {
  return readdirSync(dir).flatMap((name) => {
    const full = join(dir, name);
    return statSync(full).isDirectory() ? sourceFiles(full) : /\.(tsx?|css)$/.test(name) ? [full] : [];
  });
}

// El patró es construeix per parts: si el nom de la utilitat aparegués literal en aquest fitxer, Tailwind
// (detecció automàtica de fonts) la generaria al CSS final i lobby-v4-l2 la detectaria.
const FORBIDDEN_TRANSITION = new RegExp(["transition", "all"].join("-") + "|" + ["transition", "\\[width"].join("-"));

test("estàtic: cap transició de totes les propietats ni d'amplada a src (rg = 0)", () => {
  const hits = sourceFiles("src").flatMap((file) =>
    readFileSync(file, "utf8")
      .split("\n")
      .map((line, i) => (FORBIDDEN_TRANSITION.test(line) ? `${file}:${i + 1}` : null))
      .filter((x): x is string => x !== null)
  );
  expect(hits).toEqual([]);
});

for (const vp of VIEWPORTS) {
  test.describe(`animacions v1 · rendiment ${vp.tag}`, () => {
    test.use({ viewport: { width: vp.width, height: vp.height }, isMobile: true, hasTouch: true });
    test.setTimeout(200_000);

    test(`${HANDS} mans: només transform/opacity, CLS ≤ main, sense scroll (${vp.tag})`, async ({ page }) => {
      await installProbe(page);
      await seedLobby(page, `anim1-${vp.tag}`);
      await page.goto("/");
      await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 30_000 });
      await startAiGameFromLobby(page, 2);
      // Es mesura la partida: el selector previ (fora de la taula) no compta.
      await page.evaluate(() => {
        const a = (window as unknown as { __anim: Probe }).__anim;
        a.props = {};
        a.cls = 0;
        a.shifts = 0;
        a.sources = {};
        Object.assign(a, { worst: 0, winValue: 0, winStart: -1e9, winLast: -1e9, log: [] });
      });

      let hands = 0;
      let scrollWorst = { doc: 0, table: 0 };
      let axeChecked = false;
      // Pressupost de temps del bucle ben per sota del timeout del test: si s'acaba, el test falla per
      // «mans jugades» amb un missatge clar, no per timeout amb la pàgina tancada.
      const deadline = Date.now() + 150_000;
      while (hands < HANDS && Date.now() < deadline && !page.isClosed()) {
        const s = await scrollState(page).catch(() => ({ doc: 0, table: 0 }));
        scrollWorst = { doc: Math.max(scrollWorst.doc, s.doc), table: Math.max(scrollWorst.table, s.table) };
        const bankOffer = page.getByTestId("settlement-bank-offer").locator("button").first();
        if (await bankOffer.isVisible().catch(() => false)) {
          // Oferta de banca: es declina (o s'accepta si és obligatòria, l'únic botó).
          await bankOffer.click({ timeout: 2_000 }).catch(() => undefined);
          await expect(bankOffer).toBeHidden({ timeout: 5_000 }).catch(() => undefined);
          continue;
        }
        if ((await visible(page, "settlement-next-hand")) && (await page.getByTestId("settlement-next-hand").first().isEnabled().catch(() => false))) {
          hands += 1;
          if (!axeChecked) {
            const axe = await new AxeBuilder({ page }).analyze();
            expect(axe.violations.map((v) => `${v.id}: ${v.nodes.map((n) => n.target.join(" ")).join(" | ")}`)).toEqual([]);
            axeChecked = true;
          }
          await page.getByTestId("settlement-next-hand").first().click({ timeout: 2_000 }).catch(() => undefined);
          // Estat, no temps fix: s'espera que la taula surti de la liquidació.
          await expect(page.locator('[data-game-phase="settlement"]')).toHaveCount(0, { timeout: 10_000 }).catch(() => undefined);
          continue;
        }
        if (await visible(page, "match-revenge-button")) {
          await page.getByTestId("match-revenge-button").click({ timeout: 2_000 }).catch(() => undefined);
          continue;
        }
        if ((await visible(page, "bet-confirm")) && (await page.getByTestId("bet-confirm").isEnabled().catch(() => false))) {
          await page.getByTestId("bet-confirm").click({ timeout: 2_000 }).catch(() => undefined);
          await expect(page.locator('[data-game-phase="betting"]')).toHaveCount(0, { timeout: 8_000 }).catch(() => undefined);
          continue;
        }
        if ((await visible(page, "action-hit")) && (await page.getByTestId("action-hit").isEnabled().catch(() => false))) {
          // Taula gran (v147): sense total propi; es demana fins a 2 cartes i després es planta.
          const pts = String(await page.locator('[data-testid="local-hand-card"], .desktop-own-card').count());
          const btn = Number(pts) < 2 ? "action-hit" : "action-stand";
          await page.getByTestId(btn).click({ timeout: 2_000 }).catch(() => undefined);
          // Espera que el servidor respongui (el punt canvia o el botó es desactiva) en lloc d'un temps fix.
          await page
            .waitForFunction(
              (prev) => {
                const p = String(document.querySelectorAll('[data-testid="local-hand-card"], .desktop-own-card').length);
                const hit = document.querySelector<HTMLButtonElement>('[data-testid="action-hit"]');
                return p !== prev || !hit || hit.disabled;
              },
              pts,
              { timeout: 3_000 }
            )
            .catch(() => undefined);
          continue;
        }
        await pause(page, 150);
      }

      const probe = (await page.evaluate(() => (window as unknown as { __anim: Probe }).__anim)) as Probe;
      const bad = Object.entries(probe.props).filter(([k]) => !ALLOWED.has(k));
      console.log(
        `[animacions-v1] ${vp.tag}: mans=${hands} CLS total=${probe.cls.toFixed(4)} (${probe.shifts} desplaçaments, ${(probe.cls / Math.max(1, hands)).toFixed(4)}/mà) ` +
          `CLS Web Vitals=${(probe.worst ?? 0).toFixed(4)} ` +
          `propietats=${Object.keys(probe.props).sort().join(",")} scroll doc=${scrollWorst.doc} taula=${scrollWorst.table}`
      );
      const top = Object.entries(probe.sources).sort((a, b) => b[1] - a[1]).slice(0, 6);
      if (process.env.ANIM1_DEBUG) for (const l of (probe as unknown as { log?: string[] }).log ?? []) console.log(`[animacions-v1]   · ${l}`);
      for (const [el, v] of top) console.log(`[animacions-v1]   CLS ${v.toFixed(4)} ← ${el}`);
      for (const [k, where] of bad) console.log(`[animacions-v1]   ✗ ${k}: ${where.join(" | ")}`);
      expect(hands, "mans jugades").toBeGreaterThanOrEqual(HANDS);
      expect(bad.map(([k, where]) => `${k} ← ${where[0]}`), "només transform/opacity").toEqual([]);
      // CLS real: no pot empitjorar main (mateix escenari i mida, línia base mesurada a origin/main).
      const perHand = probe.cls / Math.max(1, hands);
      const base = BASELINE.viewports[vp.tag];
      if (CHECK_BASELINE) {
        expect(base, `línia base de main per a ${vp.tag}`).toBeTruthy();
        console.log(
          `[animacions-v1] ${vp.tag}: main ${base!.perHand.toFixed(4)}/mà, finestra ${base!.worst.toFixed(4)} → PR ${perHand.toFixed(4)}/mà, finestra ${(probe.worst ?? 0).toFixed(4)}`
        );
        expect(perHand, "CLS per mà ≤ main").toBeLessThanOrEqual(base!.perHand + TOLERANCE.perHand);
        expect(probe.worst ?? 0, "CLS Web Vitals (pitjor finestra) ≤ main").toBeLessThanOrEqual(base!.worst + TOLERANCE.worst);
      }
      expect(scrollWorst.doc, "document sense scroll").toBeLessThanOrEqual(0);
      expect(scrollWorst.table, "taula sense scroll").toBeLessThanOrEqual(0);
    });
  });
}
