import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * PC pantalla 2 (v174), amb la baralla fixa SETIMIG_TEST_DECK_SEED=3 (doblar + separar):
 * rivals ≥ 96 px, banca activa ≤ 140 px (i ≥ clamp(96px,14vh,140px)), full de liquidació min(28vw,420px),
 * i cap encavalcament entre pot/pot acumulat, mans separades, liquidació, barra de sessió, mà pròpia, seients i dock.
 * A 390×844 la liquidació no canvia. Captures només a /workspace/pc-pantalla-v174/ (mai al repo).
 */
const SEED = process.env.SETIMIG_TEST_DECK_SEED;
const OUT = "/workspace/pc-pantalla-v174";
const SIZES = [
  { tag: "1280x800", width: 1280, height: 800 },
  { tag: "1440x900", width: 1440, height: 900 },
  { tag: "1920x1080", width: 1920, height: 1080 },
  { tag: "390x844", width: 390, height: 844 },
] as const;

type B = { l: number; t: number; r: number; b: number };
const inter = (a: B, b: B) => Math.max(0, Math.min(a.r, b.r) - Math.max(a.l, b.l) - 1) * Math.max(0, Math.min(a.b, b.b) - Math.max(a.t, b.t) - 1);

async function startSolo(page: Page) {
  await seedE2eSession(page, e2ePoolId());
  await page.addInitScript(() => {
    if (sessionStorage.getItem("pcp2") === "1") return;
    sessionStorage.setItem("pcp2", "1");
    for (const k of ["setimig_onboarding_v1", "setimig_interactive_tutorial_v1", "setimig_table_tutorial_v1", "setimig_house_rules_enabled"]) localStorage.setItem(k, "1");
    localStorage.setItem("setimig.locale", "ca");
    localStorage.setItem("setimig_player_name", "Pantalla Dos");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
    sessionStorage.setItem("setimig_intro_launch_v1", "1");
  });
  // Banca activa: es mostreja a cada fotograma (la fase de banca és curta).
  await page.addInitScript(() => {
    (window as unknown as { __bankMax: number }).__bankMax = 0;
    const tick = () => {
      for (const c of document.querySelectorAll(".spanish-card-bank-turn-active, [data-seat-banker=true] .rival-cards-active .spanish-card, [data-seat-banker=true] .active-turn-hand-cards .spanish-card")) {
        const h = c.getBoundingClientRect().height;
        const w = window as unknown as { __bankMax: number };
        if (h > w.__bankMax) w.__bankMax = h;
      }
      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  });
  await page.goto("/");
  const skip = page.getByTestId("interactive-tutorial-skip");
  await expect(page.getByTestId("lobby-context").or(skip).first()).toBeVisible({ timeout: 45_000 });
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  if (await page.getByTestId("ai-bot-count-1").isVisible().catch(() => false)) await page.getByTestId("ai-bot-count-1").click();
  const cb = page.getByTestId("house-rules-toggle").locator("input");
  if (!(await cb.isChecked())) await cb.check({ force: true });
  await page.getByTestId("ai-bot-picker-start").click();
  await page.getByTestId("bet-confirm").filter({ visible: true }).first().click({ timeout: 30_000 });
}

async function peek(page: Page) {
  const g = page.getByTestId("peek-curl-grab").filter({ visible: true }).first();
  await expect(g).toBeVisible({ timeout: 20_000 });
  const b = (await g.boundingBox())!;
  const x = b.x + b.width / 2;
  const y0 = b.y + b.height * 0.95;
  await page.mouse.move(x, y0);
  await page.mouse.down();
  for (let i = 1; i <= 8; i++) await page.mouse.move(x, y0 - i * b.height * 0.08);
  await page.mouse.up();
  await page.waitForTimeout(700);
}

function measure(page: Page) {
  return page.evaluate(() => {
    const vis = (el: Element) => {
      const r = el.getBoundingClientRect();
      return r.width > 1 && r.height > 1 && getComputedStyle(el).visibility !== "hidden" && getComputedStyle(el).opacity !== "0" && !el.closest("[aria-hidden=true]");
    };
    const box = (el: Element) => { const r = el.getBoundingClientRect(); return { l: r.left, t: r.top, r: r.right, b: r.bottom }; };
    const all = (sel: string) => [...document.querySelectorAll(sel)].filter(vis);
    const union = (els: Element[]) => {
      if (!els.length) return null;
      const bs = els.map(box);
      return { l: Math.min(...bs.map((b) => b.l)), t: Math.min(...bs.map((b) => b.t)), r: Math.max(...bs.map((b) => b.r)), b: Math.max(...bs.map((b) => b.b)) };
    };
    const seatEls = all("[data-testid=game-seat-grid] [data-seat-player]");
    const rivalH = seatEls.flatMap((s) => [...s.querySelectorAll(".spanish-card")].filter(vis).map((c) => c.getBoundingClientRect().height));
    const bankActive = all(".spanish-card-bank-turn-active, [data-seat-banker=true] .rival-cards-active .spanish-card, [data-seat-banker=true] .active-turn-hand-cards .spanish-card").map((c) => c.getBoundingClientRect().height);
    const pot = document.querySelector("[data-testid=table-pot]");
    const potParts = pot ? [...pot.children].filter(vis).map(box) : [];
    const sheetCard = all(".settlement-card")[0];
    return {
      seats: seatEls.map(box),
      rivalMin: rivalH.length ? Math.min(...rivalH) : 0,
      bankMax: bankActive.length ? Math.max(...bankActive) : 0,
      own: union(all("[data-testid=local-player-seat] .spanish-card")),
      split: union(all(".desktop-split-row .spanish-card")),
      dock: all("[data-testid=action-dock]").map(box)[0] ?? null,
      session: all(".game-session-summary:not(.game-session-summary-placeholder)").map(box)[0] ?? null,
      potParts,
      sheet: sheetCard ? box(sheetCard) : null,
      sheetW: sheetCard ? sheetCard.getBoundingClientRect().width : 0,
      vw: innerWidth,
      vh: innerHeight,
    };
  });
}
type M = Awaited<ReturnType<typeof measure>>;

function noOverlaps(m: M, phase: string) {
  const named: [string, B | null][] = [
    ["mà pròpia", m.own], ["dock", m.dock], ["sessió", m.session], ["liquidació", m.sheet],
    ...m.potParts.map((p, i) => [`pot ${i}`, p] as [string, B]),
    ...m.seats.map((s, i) => [`seient ${i}`, s] as [string, B]),
  ];
  if (m.split) named.push(["mans separades", m.split]);
  for (let i = 0; i < named.length; i++)
    for (let j = i + 1; j < named.length; j++) {
      const [na, a] = named[i];
      const [nb, b] = named[j];
      if (!a || !b) continue;
      if ((na === "mans separades" && nb === "mà pròpia") || (na === "mà pròpia" && nb === "mans separades")) continue;
      if (na.startsWith("pot") && nb.startsWith("pot")) continue;
      expect(inter(a, b), `${phase}: ${na} / ${nb}`).toBe(0);
    }
}

for (const vp of SIZES) {
  const desktop = vp.width >= 1024;
  test.describe(`pc pantalla v174 @${vp.tag}`, () => {
    test.use({ viewport: { width: vp.width, height: vp.height }, isMobile: !desktop, hasTouch: !desktop });
    test("llavor 3: rivals, banca activa, mans separades i liquidació", async ({ page }) => {
      test.skip(SEED !== "3", "cal SETIMIG_TEST_DECK_SEED=3");
      test.setTimeout(180_000);
      await startSolo(page);
      await peek(page);
      const dbl = desktop ? page.getByRole("button", { name: /^doblar$/i }).filter({ visible: true }).first() : page.getByTestId("mobile-double-chip").filter({ visible: true }).first();
      await dbl.click({ timeout: 20_000 });
      await page.getByRole("button", { name: /separar|split/i }).filter({ visible: true }).first().click({ timeout: 20_000 });
      await page.waitForTimeout(2000);
      const r = Math.round;
      const log: Record<string, number> = {};
      if (desktop) {
        await expect(page.getByTestId("action-hit")).toBeVisible();
        await expect(page.getByTestId("action-stand")).toBeVisible();
        const m = await measure(page);
        await page.screenshot({ path: `${OUT}/${vp.tag}-separades.png` }).catch(() => {});
        log.rival = r(m.rivalMin);
        expect(m.rivalMin, "rivals ≥ 96 px").toBeGreaterThanOrEqual(95);
        expect(m.split, "mans separades").not.toBeNull();
        noOverlaps(m, "mans separades");
      }
      const sheet = page.getByTestId("settlement-sheet");
      let bankMax = 0;
      for (let i = 0; i < 400 && !(await sheet.isVisible().catch(() => false)); i++) {
        const stand = page.getByTestId("action-stand").filter({ visible: true }).first();
        if ((await stand.isVisible().catch(() => false)) && (await stand.isEnabled({ timeout: 300 }).catch(() => false)))
          await stand.click({ timeout: 1000 }).catch(() => {});
        if (desktop) {
          const m = await measure(page);
          if (m.bankMax > bankMax) bankMax = m.bankMax;
        }
        await page.waitForTimeout(200);
      }
      await expect(sheet).toBeVisible();
      await page.waitForTimeout(1200);
      bankMax = Math.max(bankMax, await page.evaluate(() => (window as unknown as { __bankMax: number }).__bankMax));
      const m = await measure(page);
      await page.screenshot({ path: `${OUT}/${vp.tag}-liquidacio.png` }).catch(() => {});
      log.sheetW = r(m.sheetW);
      if (desktop) {
        log.bank = r(bankMax);
        expect(bankMax, "banca activa mesurada").toBeGreaterThan(0);
        expect(bankMax, "banca activa ≤ 140 px").toBeLessThanOrEqual(140.5);
        expect(bankMax, "banca activa ≥ clamp(96px,14vh,140px)").toBeGreaterThanOrEqual(Math.min(140, Math.max(96, vp.height * 0.14)) - 1.5);
        expect(Math.abs(m.sheetW - Math.min(vp.width * 0.28, 420)), "full min(28vw,420px)").toBeLessThanOrEqual(2);
        noOverlaps(m, "liquidació");
      } else {
        // 390: sense canvis (max-w-md dins px-3, com a main).
        expect(Math.abs(m.sheetW - Math.min(vp.width - 24, 448)), "390 sense canvis: full").toBeLessThanOrEqual(6);
      }
      console.log(`[pc-pantalla-v174] ${vp.tag} ${JSON.stringify(log)}`);
    });
  });
}
