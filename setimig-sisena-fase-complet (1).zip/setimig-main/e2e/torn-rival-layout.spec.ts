import { expect, test, type Browser } from "@playwright/test";
import { threePlayerTurnSnapshot } from "./helpers/jugabilitatV1Fixtures.ts";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * v157 (Edu, 10:49): quan juga un altre, la meva carta gran NO es pot superposar a les cartes del rival,
 * al seu total ni a la capçalera; queda entre la zona central i els botons.
 */
const AGE_OK = () => JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" });
const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844, desktop: false },
  { tag: "1280x800", width: 1280, height: 800, desktop: true },
] as const;

async function openLocal(browser: Browser, vp: (typeof VIEWPORTS)[number]) {
  const ctx = await browser.newContext({
    viewport: { width: vp.width, height: vp.height },
    deviceScaleFactor: vp.desktop ? 1 : 2,
    locale: "en-US",
    colorScheme: "dark",
  });
  const page = await ctx.newPage();
  const pid = e2ePoolId();
  await seedE2eSession(page, pid);
  await page.addInitScript(
    ({ snap, pid, age }) => {
      if (sessionStorage.getItem("focus_seeded") === "1") return;
      sessionStorage.setItem("focus_seeded", "1");
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", "Edu");
      localStorage.setItem("setimig.locale", "en");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_house_rules_enabled", "1");
      localStorage.setItem("setimig_age_gate", age);
      localStorage.setItem("setimig_local_solo_snapshot", snap);
      sessionStorage.setItem("setimig_solo_rejoin", "1");
      sessionStorage.setItem("setimig_solo_local", "1");
    },
    { snap: ownFaceDown(threePlayerTurnSnapshot(pid, "Edu"), pid), pid, age: AGE_OK() }
  );
  await page.route("**/socket.io/**", (route) => route.abort());
  await page.goto("/");
  await expect(page.getByTestId("action-hit")).toBeEnabled({ timeout: 30_000 });
  await page.waitForTimeout(700);
  return { ctx, page };
}

/** Com al vídeo d'Edu: la meva carta és tapada (la peek), la del rival també. */
function ownFaceDown(snap: string, pid: string): string {
  const walk = (o: unknown): void => {
    if (!o || typeof o !== "object") return;
    if (Array.isArray(o)) return o.forEach(walk);
    const rec = o as Record<string, unknown>;
    if (typeof rec.playerId === "string" && rec.playerId === pid && Array.isArray(rec.handSlots)) {
      for (const slot of rec.handSlots as { cards?: { faceUp?: boolean }[] }[]) for (const c of slot.cards ?? []) c.faceUp = false;
    }
    Object.values(rec).forEach(walk);
  };
  const parsed = JSON.parse(snap);
  walk(parsed);
  return JSON.stringify(parsed);
}

type R = { x: number; y: number; w: number; h: number; sel: string };

for (const vp of VIEWPORTS) {
  test(`torn rival · ${vp.tag} · la meva carta no tapa les del rival, el total ni la capçalera`, async ({ browser }) => {
    const { ctx, page } = await openLocal(browser, vp);
    await page.getByTestId("action-stand").click();
    const stageSel = vp.desktop
      ? '[data-testid="active-turn-hand"][data-active-player="bot-jug-p"]'
      : '[data-testid="focus-stage"][data-focus-player="bot-jug-p"]';
    await expect(page.locator(stageSel)).toBeVisible({ timeout: 20_000 });
    await page.waitForTimeout(600);
    const data = await page.evaluate((stageSel) => {
      const rect = (el: Element, sel: string) => {
        const r = el.getBoundingClientRect();
        return { x: r.left, y: r.top, w: r.width, h: r.height, sel };
      };
      // Visible de debò: mida, visibilitat i opacitat efectiva (inclosos els avantpassats).
      const vis = (el: Element) => {
        const r = el.getBoundingClientRect();
        if (r.width <= 0 || r.height <= 0) return false;
        if (getComputedStyle(el).visibility === "hidden") return false;
        let op = 1;
        for (let n: Element | null = el; n; n = n.parentElement) op *= Number(getComputedStyle(n).opacity);
        return op > 0.05;
      };
      const stage = document.querySelector(stageSel)!;
      const rival = [...stage.querySelectorAll("[data-testid='focus-hand-card'], [data-testid='active-turn-card'], .spanish-card, [data-testid='focus-hand-points'], .active-turn-hand-score, [data-testid='focus-turn-label']")]
        .filter(vis).map((e) => rect(e, "rival:" + ((e as HTMLElement).dataset.testid ?? e.className.toString().slice(0, 30))));
      const header = [...document.querySelectorAll("[data-testid='app-header']")].filter(vis).map((e) => rect(e, "header"));
      const own = [...document.querySelectorAll(".spanish-card, [class*='peek'], [data-testid*='peek']")]
        .filter((e) => !e.closest("[data-testid='v2-seat-row'], [data-testid='desktop-rival-row'], [data-seat-player]"))
        .filter((e) => !stage.contains(e)).filter(vis).map((e) => rect(e, "own"));
      const dock = document.querySelector("[data-testid='action-dock']");
      return { rival, header, own, dock: dock && vis(dock) ? rect(dock, "dock") : null };
    }, stageSel);
    console.log(`[v157 ${vp.tag}]`, JSON.stringify(data));
    const hit = (a: R, b: R) => a.x < b.x + b.w - 1 && b.x < a.x + a.w - 1 && a.y < b.y + b.h - 1 && b.y < a.y + a.h - 1;
    expect(data.rival.length).toBeGreaterThan(0);
    // Al mòbil la meva carta es veu (petita) sota l'escenari; a l'escriptori queda a la fila.
    if (!vp.desktop) expect(data.own.length, "la meva carta es veu al mòbil").toBeGreaterThan(0);
    for (const o of data.own) {
      for (const r of [...data.rival, ...data.header]) {
        expect(hit(o, r), `carta pròpia ${JSON.stringify(o)} tapa ${r.sel} ${JSON.stringify(r)}`).toBe(false);
      }
      if (data.dock) expect(o.y + o.h, "carta pròpia per sobre del dock").toBeLessThanOrEqual(data.dock.y + 1);
    }
    await ctx.close();
  });
}
