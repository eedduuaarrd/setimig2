import AxeBuilder from "@axe-core/playwright";
import { expect, test, type BrowserContext, type Page, type Route } from "@playwright/test";

import { E2E_ACCOUNT_IDS, mintE2eToken } from "./helpers/e2eSession";

/** Servidor local: el baseURL del projecte (config pròpia o general); si no n'hi ha, SETIMIG_E2E_PORT/3298. */
let LOCAL = `http://127.0.0.1:${Number(process.env.SETIMIG_E2E_PORT ?? 3298)}`;
test.beforeAll(({}, testInfo) => {
  const base = testInfo.project.use.baseURL;
  if (base) LOCAL = new URL(base).origin;
});
const OLD = "https://setimig.supercbb.com";
const NEW = "https://sevenhalf.club";
const ID_OLD = "a".repeat(48);
const ID_LOCAL = "c".repeat(48);
const TRANSFER = "h1.e2ebody.e2esig";

type Api = (route: Route, url: URL) => Promise<void> | void;

/** Envia la petició al servidor local real (mateix camí), conservant mètode, capçaleres i cos. */
async function proxy(route: Route, url: URL) {
  const response = await route.fetch({ url: `${LOCAL}${url.pathname}${url.search}` });
  return route.fulfill({ response });
}

/** Serveix els dos dominis des del servidor local; /api/* el decideix cada test; la resta, bloquejat. */
async function simulateOrigins(context: BrowserContext, api: Api = proxy) {
  await context.route("**/*", async (route) => {
    try {
      await handle(route);
    } catch (error) {
      // Peticions que encara volaven quan la pàgina ja ha navegat o el test ha acabat.
      if (!/Test ended|Target page, context or browser has been closed|Route is already handled/i.test(String(error))) throw error;
    }
  });
  async function handle(route: Route) {
    const url = new URL(route.request().url());
    if (url.origin === LOCAL) return route.continue();
    if (url.origin !== OLD && url.origin !== NEW) return route.abort();
    if (url.pathname === "/__probe") {
      return route.fulfill({ status: 200, contentType: "text/html", body: "<!doctype html><title>probe</title>" });
    }
    if (url.pathname.startsWith("/socket.io")) return route.abort();
    if (url.pathname.startsWith("/api/")) return api(route, url);
    return proxy(route, url);
  }
}

test.afterEach(async ({ context }) => {
  await context.unrouteAll({ behavior: "ignoreErrors" });
});

function json(route: Route, status: number, body: unknown) {
  return route.fulfill({ status, contentType: "application/json", body: JSON.stringify(body) });
}

async function setStorage(page: Page, origin: string, values: Record<string, string>) {
  await page.goto(`${origin}/__probe`);
  await page.evaluate((v) => {
    localStorage.clear();
    for (const [k, val] of Object.entries(v)) localStorage.setItem(k, val);
  }, values);
}

async function readStorage(page: Page, origin: string): Promise<Record<string, string>> {
  await page.goto(`${origin}/__probe`);
  return page.evaluate(() => Object.fromEntries(Object.keys(localStorage).map((k) => [k, localStorage.getItem(k)!])));
}

async function appMounted(page: Page) {
  // main.tsx posa data-boot-handoff just abans de muntar l'arrel (després del traspàs i de l'idioma).
  await page.waitForFunction(() => document.documentElement.hasAttribute("data-boot-handoff"));
  await page.waitForFunction(() => (document.getElementById("root")?.children.length ?? 0) > 0);
}

async function expectTarget(page: Page, testId: string) {
  const box = await page.getByTestId(testId).boundingBox();
  expect(box, testId).not.toBeNull();
  expect(box!.height).toBeGreaterThanOrEqual(44);
}

test("manifest id, start_url and scope are relative", async ({ request }) => {
  const manifest = await (await request.get(`${LOCAL}/site.webmanifest`)).json();
  for (const key of ["id", "start_url", "scope"]) {
    expect(typeof manifest[key]).toBe("string");
    expect(manifest[key]).not.toMatch(/^[a-z]+:\/\//i);
  }
});

test("old domain with identity: mint, redirect keeping the invite path, exchange on the new domain", async ({ context, page }) => {
  const mintBodies: Record<string, unknown>[] = [];
  const mintAuth: (string | undefined)[] = [];
  const exchangeBodies: Record<string, unknown>[] = [];
  let clientState = "";
  await simulateOrigins(context, async (route, url) => {
    const req = route.request();
    if (url.pathname === "/api/handoff/mint") {
      expect(url.origin).toBe(OLD);
      const body = req.postDataJSON();
      mintBodies.push(body);
      mintAuth.push(req.headers().authorization);
      clientState = body.clientState;
      return json(route, 200, { transferToken: TRANSFER, expiresAt: Date.now() + 300_000, targetUrl: `${NEW}/#handoff=${TRANSFER}` });
    }
    if (url.pathname === "/api/handoff/exchange") {
      expect(url.origin).toBe(NEW);
      exchangeBodies.push(req.postDataJSON());
      return json(route, 200, { playerId: ID_OLD, playerToken: "new.e2e.tok", clientState });
    }
    if (url.pathname === "/api/player-session") return json(route, 200, { playerId: ID_OLD, playerToken: "old.e2e.tok" });
    return json(route, 503, { error: "e2e" });
  });

  const oldValues = {
    setimig_player_id: ID_OLD,
    setimig_player_token: "old.e2e.tok",
    setimig_analytics_sid: "sid-e2e",
    setimig_age_gate: "1",
    "setimig.locale": "es",
  };
  await setStorage(page, OLD, oldValues);
  await setStorage(page, NEW, {});

  await page.goto(`${OLD}/t/AB12CD`);
  await page.waitForURL((u) => u.origin === NEW && u.pathname === "/t/AB12CD" && u.hash === "", { timeout: 30_000 });
  await appMounted(page);

  expect(mintBodies).toHaveLength(1);
  expect(mintAuth[0]).toBe("Bearer old.e2e.tok");
  expect(mintBodies[0].playerId).toBeUndefined();
  expect(JSON.parse(String(mintBodies[0].clientState))).toEqual({ setimig_age_gate: "1", "setimig.locale": "es" });
  expect(exchangeBodies).toEqual([{ transferToken: TRANSFER }]);
  await expect.poll(() => page.evaluate(() => document.documentElement.lang)).toBe("es");
  expect(await page.evaluate(() => document.documentElement.dataset.bootHandoff)).toBe("migrated");

  const fresh = await readStorage(page, NEW);
  expect(fresh.setimig_player_id).toBe(ID_OLD);
  expect(fresh.setimig_player_token).toBe("new.e2e.tok");
  expect(fresh.setimig_age_gate).toBe("1");
  expect(fresh.setimig_analytics_sid).toBeUndefined();

  // El localStorage antic no s'esborra.
  const old = await readStorage(page, OLD);
  for (const [k, v] of Object.entries(oldValues)) expect(old[k]).toBe(v);
  expect(old.setimig_migrated_to).toBe("sevenhalf.club");
});

test("real server (#202): the same account arrives on the new domain", async ({ context, page, request }) => {
  // Des del #361, POST /api/player-session sense Bearer ni galeta respon 401: compte e2e amb token signat.
  const playerId = E2E_ACCOUNT_IDS[0];
  const session = { playerId, playerToken: mintE2eToken(playerId) };
  expect(session.playerId).toMatch(/^[a-zA-Z0-9_-]{8,64}$/);
  const paths: string[] = [];
  await simulateOrigins(context, (route, url) => {
    paths.push(`${url.origin}${url.pathname}`);
    return proxy(route, url);
  });
  await setStorage(page, OLD, {
    setimig_player_id: session.playerId,
    setimig_player_token: session.playerToken,
    setimig_age_gate: "1",
  });
  await setStorage(page, NEW, {});
  await page.goto(`${OLD}/`);
  await page.waitForURL((u) => u.origin === NEW && u.hash === "", { timeout: 30_000 });
  await appMounted(page);
  expect(paths).toContain(`${OLD}/api/handoff/mint`);
  expect(paths).toContain(`${NEW}/api/handoff/exchange`);
  const fresh = await readStorage(page, NEW);
  expect(fresh.setimig_player_id).toBe(session.playerId);
  expect(fresh.setimig_player_token).toContain(".");
  expect(fresh.setimig_age_gate).toBe("1");
  const balance = await request.get(`${LOCAL}/api/balance`, {
    headers: { Authorization: `Bearer ${fresh.setimig_player_token}` },
  });
  expect(balance.ok()).toBe(true);
});

test("old domain: mint error shows retry without redirecting, then retry moves the account", async ({ context, page }) => {
  let fail = true;
  await simulateOrigins(context, async (route, url) => {
    if (url.pathname === "/api/handoff/mint") {
      if (fail) return json(route, 500, { error: "e2e" });
      return json(route, 200, { transferToken: TRANSFER, expiresAt: Date.now() + 300_000, targetUrl: `${NEW}/#handoff=${TRANSFER}` });
    }
    if (url.pathname === "/api/handoff/exchange") return json(route, 200, { playerId: ID_OLD, playerToken: "new.e2e.tok" });
    return json(route, 503, {});
  });
  await setStorage(page, OLD, { setimig_player_id: ID_OLD });
  await page.goto(`${OLD}/`);
  const dialog = page.getByTestId("domain-handoff-error");
  await expect(dialog).toBeVisible();
  await expect(page.getByRole("dialog")).toHaveAccessibleName(/couldn't move your account/i);
  expect(new URL(page.url()).origin).toBe(OLD);
  await expectTarget(page, "domain-handoff-retry");
  await expectTarget(page, "domain-handoff-stay");
  await expect(page.getByTestId("domain-handoff-retry")).toBeFocused();
  const axe = await new AxeBuilder({ page }).include('[data-testid="domain-handoff-error"]').analyze();
  expect(axe.violations.map((v) => v.id)).toEqual([]);

  fail = false;
  await page.getByTestId("domain-handoff-retry").click();
  await page.waitForURL((u) => u.origin === NEW && u.hash === "", { timeout: 30_000 });
  await appMounted(page);
});

test("old domain without identity goes to #handoff=none; /migra does the same", async ({ context, page }) => {
  let mintCalls = 0;
  await simulateOrigins(context, async (route, url) => {
    if (url.pathname === "/api/handoff/mint") mintCalls += 1;
    return proxy(route, url);
  });
  await setStorage(page, OLD, {});
  await page.goto(`${OLD}/migra`);
  // Login obligatori (#263): sense identitat, el domini nou acaba a /login (sense ?next per a «/»).
  await page.waitForURL((u) => u.origin === NEW && (u.pathname === "/" || u.pathname === "/login") && !u.search, { timeout: 30_000 });
  await appMounted(page);
  expect(new URL(page.url()).hash).toBe("");
  expect(mintCalls).toBe(0);
});

test("new domain: 410 shows «Recover my account» linking to the old /migra", async ({ context, page }) => {
  await simulateOrigins(context, async (route, url) => {
    if (url.pathname === "/api/handoff/exchange") return json(route, 410, { code: "USED_OR_UNKNOWN" });
    return json(route, 503, {});
  });
  await setStorage(page, NEW, {});
  await page.goto(`${NEW}/#handoff=${TRANSFER}`);
  const notice = page.getByTestId("domain-handoff-recover");
  await expect(notice).toBeVisible();
  expect(new URL(page.url()).hash).toBe("");
  await expect(page.getByTestId("domain-handoff-recover-link")).toHaveAttribute("href", `${OLD}/migra`);
  await expect(page.getByTestId("domain-handoff-recover-link")).toHaveText("Recover my account");
  await expectTarget(page, "domain-handoff-recover-link");
});

test("new domain: ?from=setimig without identity pulls from /migra once, without loops", async ({ context, page }) => {
  const navigations: string[] = [];
  page.on("framenavigated", (frame) => {
    if (frame === page.mainFrame()) navigations.push(frame.url());
  });
  await simulateOrigins(context, (route) => json(route, 503, {}));
  await setStorage(page, NEW, {});
  await setStorage(page, OLD, {});
  navigations.length = 0;
  await page.goto(`${NEW}/?from=setimig`);
  await page.waitForURL((u) => u.origin === NEW && (u.pathname === "/" || u.pathname === "/login") && !u.search && !u.hash, { timeout: 30_000 });
  await appMounted(page);
  expect(navigations.some((u) => u.startsWith(`${OLD}/migra`))).toBe(true);
  const store = await readStorage(page, NEW);
  expect(store.setimig_handoff_pull_v1).toBeTruthy();

  navigations.length = 0;
  await page.goto(`${NEW}/?from=setimig`);
  await appMounted(page);
  expect(navigations.some((u) => u.startsWith(OLD))).toBe(false);
});

test("new domain: another local account with progress asks which one to keep (default: transferred)", async ({ context, page }) => {
  await simulateOrigins(context, async (route, url) => {
    if (url.pathname === "/api/handoff/exchange") {
      return json(route, 200, { playerId: ID_OLD, playerToken: "new.e2e.tok", replacedPlayerId: ID_LOCAL });
    }
    if (url.pathname === "/api/balance") return json(route, 200, { chips: 99_999 });
    if (url.pathname === "/api/stats") return json(route, 200, { handsPlayed: 12 });
    if (url.pathname === "/api/player-session") return json(route, 200, { playerId: ID_LOCAL, playerToken: "local.e2e.tok" });
    return json(route, 503, {});
  });
  await setStorage(page, NEW, { setimig_player_id: ID_LOCAL, setimig_player_token: "local.e2e.tok" });
  await page.goto(`${NEW}/#handoff=${TRANSFER}`);
  await expect(page.getByTestId("domain-handoff-choose")).toBeVisible();
  await expect(page.getByTestId("domain-handoff-keep-transferred")).toBeFocused();
  await expectTarget(page, "domain-handoff-keep-transferred");
  await expectTarget(page, "domain-handoff-keep-local");
  const axe = await new AxeBuilder({ page }).include('[data-testid="domain-handoff-choose"]').analyze();
  expect(axe.violations.map((v) => v.id)).toEqual([]);
  await page.getByTestId("domain-handoff-keep-local").click();
  await appMounted(page);
  const store = await readStorage(page, NEW);
  expect(store.setimig_player_id).toBe(ID_LOCAL);
  expect(JSON.parse(store.setimig_replaced_identity_v1).playerId).toBe(ID_OLD);
});

test("installed PWA: one-time reinstall notice after moving", async ({ context, page }) => {
  await simulateOrigins(context, (route) => json(route, 503, {}));
  await setStorage(page, NEW, {});
  await page.goto(`${NEW}/#handoff=none&pwa=1`);
  await expect(page.getByTestId("domain-handoff-reinstall")).toBeVisible();
  await page.goto(`${NEW}/__probe`);
  await page.goto(`${NEW}/#handoff=none&pwa=1`);
  await appMounted(page);
  await expect(page.getByTestId("domain-handoff-reinstall")).toHaveCount(0);
});
