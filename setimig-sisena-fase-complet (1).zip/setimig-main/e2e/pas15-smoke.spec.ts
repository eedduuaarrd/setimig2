import { expect, test } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";
import fs from "node:fs";
import path from "node:path";
import { startAiGameFromLobby } from "./helpers/aiLobby";

const VIEWPORTS = [
  { name: "360x740", width: 360, height: 740 },
  { name: "390x844", width: 390, height: 844 },
  { name: "1280x800", width: 1280, height: 800 },
] as const;

function screenshotDir(): string {
  const candidates = [
    "/cursor/stores/bc-9b0df142-722d-5c8c-bf32-7c74b1eccf10/media/pas15",
    "/cursor/stores/self/media/pas15",
    path.join(process.cwd(), "media/pas15"),
  ];
  for (const dir of candidates) {
    try {
      fs.mkdirSync(dir, { recursive: true });
      return dir;
    } catch {
      /* try next */
    }
  }
  return candidates[2];
}

async function enterName(page: import("@playwright/test").Page) {
  const input = page.getByPlaceholder("El teu nom");
  if (await input.isVisible().catch(() => false)) {
    await input.fill("Pas15Smoke");
    await page.getByRole("button", { name: "Entrar al lobby" }).click();
  }
}

test("PAS 15 — lobby axe clean", async ({ page }) => {
  await page.goto("/");
  await enterName(page);
  await expect(page.getByTestId("lobby-main")).toBeVisible();
  const axe = await new AxeBuilder({ page }).analyze();
  expect(axe.violations).toEqual([]);
});

for (const vp of VIEWPORTS) {
  test(`PAS 15 — smoke ${vp.name}`, async ({ page }) => {
    const OUT = screenshotDir();
    await page.setViewportSize({ width: vp.width, height: vp.height });
    await page.addInitScript(() => {
      localStorage.setItem("setimig_player_id", `pas15-${Date.now()}`);
      localStorage.setItem("setimig_player_name", "Pas15Smoke");
    });
    await page.goto("/");
    await enterName(page);
    await page.screenshot({ path: path.join(OUT, `${vp.name}-lobby.png`), fullPage: false });

    if (vp.width >= 1024) {
      await expect(page.getByTestId("app-header")).toBeVisible();
      return;
    }

    await startAiGameFromLobby(page, 3);
    await expect(page.getByTestId("game-seat-grid")).toBeVisible({ timeout: 60_000 });
    await page.screenshot({ path: path.join(OUT, `${vp.name}-table.png`), fullPage: false });

    const hub = page.locator(".seat-center-hub");
    if (await hub.isVisible().catch(() => false)) {
      const box = await hub.boundingBox();
      expect(box?.height ?? 0).toBeGreaterThan(0);
    }
  });
}
