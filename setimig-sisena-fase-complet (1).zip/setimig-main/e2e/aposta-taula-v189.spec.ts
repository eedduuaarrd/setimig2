import { expect, test, type Page } from "@playwright/test";
import { passAgeGateToLobby } from "./helpers/ageGateLobby";
import { createPrivateTable, readInviteCode } from "./helpers/tableFlow";
import { e2ePoolId } from "./helpers/e2eSession.ts";

/**
 * v189 · «El moment d'apostar ha de ser a la mateixa pantalla, i que vegis el que aposta l'altra gent» (Edu).
 * - Durant l'aposta la taula no canvia de vista: seients visibles amb el panell d'aposta obert.
 * - Cada seient mostra la seva aposta (pila + import) o un estat pendent; la meva també.
 * - L'aposta d'un rival apareix al seu seient en temps real (sala privada amb 3 navegadors).
 * - Res tallat ni encavalcat a 390×844, 390×667, 1024×700, 1280×720 i 1440×900.
 * Substitueix full-aposta-v175 i redisseny-apostar (pantalla d'aposta a part).
 */
const SIZES = [
  { width: 390, height: 844 },
  { width: 390, height: 667 },
  { width: 1024, height: 700 },
  { width: 1280, height: 720 },
  { width: 1440, height: 900 },
] as const;
const SHOTS = process.env.APOSTA_SHOTS_DIR || "";

type Box = { l: number; t: number; r: number; b: number };

async function layout(page: Page) {
  return page.evaluate(() => {
    const box = (el: Element): Box => {
      const r = el.getBoundingClientRect();
      return { l: r.left, t: r.top, r: r.right, b: r.bottom };
    };
    const vis = (el: Element) => {
      const r = el.getBoundingClientRect();
      const cs = getComputedStyle(el);
      return r.width > 1 && r.height > 1 && cs.visibility !== "hidden" && cs.display !== "none" && !el.closest("[aria-hidden=true]");
    };
    const all = (sel: string) => [...document.querySelectorAll(sel)].filter(vis);
    const panel = document.querySelector("[data-testid=bet-screen]");
    const seats = all("[data-seat-player], [data-testid=v2-seat], [data-testid=self-bet-seat], [data-testid=v2-pot]").map((e) => ({
      id: e.getAttribute("data-seat-player") || e.getAttribute("data-testid") || "",
      ...box(e),
    }));
    const chrome = all("[data-testid=game-top-bar], [data-testid=game-top-strip], [data-testid=game-top-icons]").map(box);
    const controls = all("[data-testid=bet-screen] button, [data-testid=bet-rail]").map(box);
    return {
      vw: innerWidth,
      vh: innerHeight,
      panel: panel && vis(panel) ? box(panel) : null,
      seats,
      chrome,
      controls,
      bets: all("[data-testid=seat-bet]").map((e) => e.getAttribute("data-state")),
    };
  });
}
const inter = (a: Box, b: Box) =>
  Math.max(0, Math.min(a.r, b.r) - Math.max(a.l, b.l)) * Math.max(0, Math.min(a.b, b.b) - Math.max(a.t, b.t));

async function seedSolo(page: Page) {
  await passAgeGateToLobby(page, "Aposta189");
  await page.getByTestId("lobby-context").click();
  await page.getByTestId("ai-bot-count-3").click();
  await page.getByTestId("ai-bot-picker-start").click();
}

async function skipTutorial(page: Page) {
  const sk = page.getByTestId("table-tutorial-skip");
  if (await sk.isVisible().catch(() => false)) await sk.click();
}

for (const vp of SIZES) {
  test(`aposta a la taula ${vp.width}×${vp.height}: seients visibles, apostes al seient, res encavalcat`, async ({ page }) => {
    test.setTimeout(120_000);
    await page.setViewportSize(vp);
    await seedSolo(page);
    await expect(page.getByTestId("bet-screen")).toBeVisible({ timeout: 30_000 });
    await skipTutorial(page);
    // Els bots aposten un a un: les seves apostes ja són als seients mentre el meu panell és obert.
    const placedBet = page.locator('[data-testid=seat-bet][data-state=placed]').first();
    await expect(placedBet).toBeVisible({ timeout: 20_000 });
    const amount = Number(await placedBet.getAttribute("data-amount"));
    const faces = await placedBet.locator(".seat-bet-chip").evaluateAll((chips) => chips.map((chip) => Number((chip as HTMLElement).dataset.value)));
    expect(faces.length, "la pila del seient mostra fins a tres fitxes d'aposta").toBeGreaterThan(0);
    expect(faces.length).toBeLessThanOrEqual(3);
    expect(faces.reduce((sum, value) => sum + value, 0), "els valors de les fitxes coincideixen amb l'aposta").toBe(amount);
    // El meu seient: pendent fins que aposto.
    await expect(page.locator('[data-testid=seat-bet][data-state=pending]').first()).toBeVisible();
    await expect(page.getByTestId("bet-confirm")).toBeEnabled();
    // Cap canvi de vista: la fila de seients segueix a la taula.
    const L = await layout(page);
    expect(L.panel).not.toBeNull();
    const rivalSeats = L.seats.filter((s) => s.id !== "v2-pot");
    expect(rivalSeats.length).toBeGreaterThanOrEqual(3);
    const problems: string[] = [];
    for (const s of L.seats) {
      if (s.l < -1 || s.t < -1 || s.r > L.vw + 1 || s.b > L.vh + 1) problems.push(`${s.id} fora de pantalla`);
      if (inter(s, L.panel!) > 4) problems.push(`${s.id} sota el panell d'aposta`);
      for (const c of L.chrome) if (inter(s, c) > 4) problems.push(`${s.id} sota la barra superior`);
    }
    for (const c of L.controls) {
      if (c.l < -1 || c.r > L.vw + 1 || c.b > L.vh + 1) problems.push("control d'aposta tallat");
      if (c.b - c.t < 43.5 && c.r - c.l < 43.5) problems.push("control < 44 px");
    }
    expect(problems).toEqual([]);
    // L'avís de la primera mà no tapa el panell.
    const toast = page.getByTestId("app-toast");
    if (await toast.isVisible().catch(() => false)) {
      const tb = await toast.boundingBox();
      if (tb) expect(inter({ l: tb.x, t: tb.y, r: tb.x + tb.width, b: tb.y + tb.height }, L.panel!)).toBeLessThan(4);
    }
    if (SHOTS) await page.screenshot({ path: `${SHOTS}/after-${vp.width}x${vp.height}.png` });
  });
}

test("multijugador: l'aposta d'un rival apareix al seu seient en temps real, i la meva al meu", async ({ browser }) => {
  test.setTimeout(240_000);
  const ctxs = await Promise.all([0, 1, 2].map(() => browser.newContext({ viewport: { width: 390, height: 844 } })));
  const pages = await Promise.all(ctxs.map((c) => c.newPage()));
  const names = ["Amfitrio189", "Convidat189a", "Convidat189b"];
  await passAgeGateToLobby(pages[0], names[0], { playerId: e2ePoolId(), online: true });
  await createPrivateTable(pages[0]);
  const code = await readInviteCode(pages[0]);
  for (const i of [1, 2]) {
    await passAgeGateToLobby(pages[i], names[i], { playerId: e2ePoolId(), online: true });
    // L'enllaç d'invitació entra directament a la sala (sala d'espera o taula d'espera).
    await pages[i].goto(`/?t=${code}`);
    await expect(pages[i].locator("[data-testid=private-waiting-panel], [data-testid=game-top-bar]").first()).toBeVisible({ timeout: 30_000 });
  }
  await expect(pages[0].getByTestId("start-game-button")).toBeVisible({ timeout: 30_000 });
  await pages[0].getByTestId("start-game-button").click();

  // Qui no és banca té el panell d'aposta obert a la mateixa taula.
  const bettors: Page[] = [];
  await expect
    .poll(async () => {
      bettors.length = 0;
      for (const p of pages) if (await p.getByTestId("bet-screen").isVisible().catch(() => false)) bettors.push(p);
      return bettors.length;
    }, { timeout: 60_000 })
    .toBeGreaterThanOrEqual(2);
  const [a, b] = bettors;
  for (const p of pages) await skipTutorial(p);
  await expect(a.getByTestId("v2-seat-row")).toBeVisible();
  // Abans: tots dos pendents a la vista de B.
  await expect(b.locator('[data-testid=seat-bet][data-state=pending]')).toHaveCount(2);

  await a.getByTestId("bet-chip").first().click();
  await a.getByTestId("bet-confirm").click();
  // La meva aposta al meu seient (A), sense canviar de vista.
  await expect(a.locator('[data-testid=seat-bet][data-state=placed]')).toHaveCount(1, { timeout: 10_000 });
  await expect(a.getByTestId("v2-seat-row")).toBeVisible();
  // En temps real a B: el seient d'A passa a «placed»; B encara té el panell obert.
  await expect(b.locator('[data-testid=seat-bet][data-state=placed]')).toHaveCount(1, { timeout: 10_000 });
  await expect(b.getByTestId("bet-screen")).toBeVisible();
  await expect(b.locator('[data-testid=seat-bet][data-state=placed]')).toHaveAttribute("data-amount", /^\d+$/);
  await Promise.all(ctxs.map((c) => c.close()));
});
