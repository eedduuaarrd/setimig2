import { expect, test } from "@playwright/test";
import { startAiGameFromLobby } from "./helpers/aiLobby";
import fs from "node:fs";
import path from "node:path";

const MOBILE_VIEWPORTS = [
  { name: "390x844", width: 390, height: 844 },
  { name: "360x640", width: 360, height: 640 },
] as const;

const BOT_COUNTS = [1, 3, 5] as const;

function screenshotDir(): string {
  const candidates = [
    "/cursor/stores/self/media/pas9",
    "/cursor/stores/bc-9b0df142-722d-5c8c-bf32-7c74b1eccf10/media/pas9",
    path.join(process.cwd(), "media/pas9"),
  ];
  for (const dir of candidates) {
    try {
      fs.mkdirSync(dir, { recursive: true });
      return dir;
    } catch {
      /* try next */
    }
  }
  return candidates[candidates.length - 1];
}

async function enterName(page: import("@playwright/test").Page, name: string) {
  const input = page.getByPlaceholder("El teu nom");
  if (await input.isVisible().catch(() => false)) {
    await input.fill(name);
    await page.getByRole("button", { name: "Entrar al lobby" }).click();
  }
}

async function startAiGame(
  page: import("@playwright/test").Page,
  bots: (typeof BOT_COUNTS)[number],
  playerId: string,
  playerName: string
) {
  await page.addInitScript(
    ({ id, name }: { id: string; name: string }) => {
      localStorage.setItem("setimig_player_id", id);
      localStorage.setItem("setimig_player_name", name);
    },
    { id: playerId, name: playerName }
  );
  await page.goto("/");
  await enterName(page, playerName);
  await startAiGameFromLobby(page, bots);
  await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 45_000 });
}

async function playUntilResultOrTimeout(page: import("@playwright/test").Page, ms: number) {
  const deadline = Date.now() + ms;
  while (Date.now() < deadline) {
    const stand = page.getByRole("button", { name: "Plantar-se" });
    if (await stand.isVisible().catch(() => false)) {
      await stand.click();
    }
    const handResult = page.getByTestId("my-hand-result").or(page.getByTestId("seat-hand-result")).first();
    if (await handResult.isVisible().catch(() => false)) return true;
    if (await page.getByText(/Resultat|Liquidaci/i).first().isVisible().catch(() => false)) return true;
    await page.waitForTimeout(700);
  }
  return false;
}

async function assertNoPageScroll(page: import("@playwright/test").Page) {
  const metrics = await page.evaluate(() => ({
    doc: document.documentElement.scrollHeight,
    inner: window.innerHeight,
    body: document.body.scrollHeight,
  }));
  expect(metrics.doc).toBeLessThanOrEqual(metrics.inner + 2);
  expect(metrics.body).toBeLessThanOrEqual(metrics.inner + 2);
}

for (const vp of MOBILE_VIEWPORTS) {
  for (const orientation of ["portrait", "landscape"] as const) {
    test.describe(`PAS 9 ${vp.name} ${orientation}`, () => {
      test(`complete hand — ${vp.name} ${orientation}`, async ({ page }) => {
        test.setTimeout(180_000);
        const w = orientation === "portrait" ? vp.width : vp.height;
        const h = orientation === "portrait" ? vp.height : vp.width;
        await page.setViewportSize({ width: w, height: h });

        const label = `${vp.name}-${orientation}`.replace(/\W/g, "");
        await startAiGame(page, 3, `pas9${label}`.slice(0, 32), "Pas9Mob");

        const betBtn = page.getByTestId("bet-confirm");
        if (await betBtn.isVisible().catch(() => false)) {
          await betBtn.click();
        }

        await assertNoPageScroll(page);
        const finished = await playUntilResultOrTimeout(page, orientation === "landscape" ? 150_000 : 100_000);
        expect(finished).toBe(true);
        await expect(page.getByTestId("my-hand-result").or(page.getByTestId("seat-hand-result")).first()).toBeVisible({
          timeout: 20_000,
        });
      });
    });
  }
}

for (const bots of BOT_COUNTS) {
  test(`PAS 9 — IA amb ${bots} bot(s) @ 390x844`, async ({ page }) => {
    await page.setViewportSize({ width: 390, height: 844 });
    await startAiGame(page, bots, `pas9bots${bots}player01`, `Bot${bots}Test`);
    await expect(page.getByText("Partida en curs.")).toHaveCount(0);
    await expect(page.getByTestId("game-seat-grid")).toBeAttached({ timeout: 60_000 });
  });
}

test("PAS 9 — reload mid-hand resumes solo table", async ({ page }) => {
  test.setTimeout(120_000);
  const playerId = "pas9reloadmidhand01";
  await page.setViewportSize({ width: 390, height: 844 });
  await startAiGame(page, 1, playerId, "ReloadTest");

  const betBtn = page.getByTestId("bet-confirm");
  if (await betBtn.isVisible().catch(() => false)) {
    await betBtn.click();
  }
  await expect(page.getByTestId("game-seat-grid")).toBeAttached({ timeout: 60_000 });
  await page.waitForTimeout(1500);

  await page.reload();
  await enterName(page, "ReloadTest");
  await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 45_000 });
  await expect(page.getByTestId("game-seat-grid")).toBeAttached();
});

test("PAS 9 — offline banner when network drops", async ({ page, context }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/");
  await enterName(page, "OfflinePas9");
  await context.setOffline(true);
  await expect(page.getByText(/Sense connexió a internet/)).toBeVisible({ timeout: 10_000 });
  await context.setOffline(false);
});

test("PAS 9 — screenshots of key mobile UX", async ({ page }) => {
  test.setTimeout(180_000);
  const OUT = screenshotDir();
  await page.setViewportSize({ width: 390, height: 844 });
  await startAiGame(page, 3, "pas9screenshotplayer", "Pas9UX");

  await page.screenshot({ path: path.join(OUT, "01-in-game-lobby-done.png"), fullPage: false });

  const betBtn = page.getByTestId("bet-confirm");
  if (await betBtn.isVisible().catch(() => false)) {
    await betBtn.click();
  }
  await expect(page.getByTestId("turn-banner").first()).toBeVisible({ timeout: 60_000 });
  await page.waitForTimeout(600);
  await page.screenshot({ path: path.join(OUT, "02-turn-banner.png"), fullPage: false });

  await playUntilResultOrTimeout(page, 110_000);
  await expect(page.getByTestId("my-hand-result").or(page.getByTestId("seat-hand-result")).first()).toBeVisible({
    timeout: 30_000,
  });
  await page.screenshot({ path: path.join(OUT, "03-hand-result.png"), fullPage: false });

  const leaveBtn = page.getByRole("button", { name: /Sortir de la partida|Confirmar sortida/ });
  await leaveBtn.click();
  await leaveBtn.click();
  await expect(page.getByTestId("play-vs-ai-button")).toBeVisible({ timeout: 10_000 });
  await page.screenshot({ path: path.join(OUT, "04-leave-confirm-lobby.png"), fullPage: false });
});
