/**
 * Edu 28/10 15:20 (iPhone): «Seven Half Club» sota el logo; sense anell de focus a «Google» després d'un toc;
 * sense ratlla daurada a baix de l'intro; logo sense halo de fum.
 */
import { expect, test, type Browser } from "@playwright/test";

async function ctxFor(browser: Browser, hasTouch: boolean) {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch, isMobile: hasTouch, locale: "en-US", colorScheme: "dark", reducedMotion: "reduce" });
  await ctx.addInitScript(() => {
    localStorage.setItem("setimig.locale", "en");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
  });
  return ctx;
}

const focusState = (page: import("@playwright/test").Page) =>
  page.evaluate(() => {
    const e = document.activeElement as HTMLElement | null;
    return { inLogin: !!e?.closest("[data-testid='login-page']"), visible: !!e && e !== document.body && e.matches(":focus-visible") };
  });

test("toc durant l'intro: en acabar, cap control del login té focus ni anell", async ({ browser }) => {
  const ctx = await ctxFor(browser, true);
  const page = await ctx.newPage();
  await page.goto("/login");
  await expect(page.getByTestId("home-intro")).toBeVisible();
  await page.touchscreen.tap(195, 420);
  await expect(page.getByTestId("launch-intro")).toHaveCount(0, { timeout: 15_000 });
  const f = await focusState(page);
  expect(f.inLogin).toBe(false);
  expect(f.visible).toBe(false);
  await expect(page.getByTestId("login-slogan")).toHaveText("Seven Half Club");
  await ctx.close();
});

test("ratolí durant l'intro: en acabar, sense anell; amb teclat sí que hi va el focus visible", async ({ browser }) => {
  const ctx = await ctxFor(browser, false);
  const page = await ctx.newPage();
  await page.goto("/login");
  await expect(page.getByTestId("home-intro")).toBeVisible();
  await page.mouse.click(195, 420);
  await expect(page.getByTestId("launch-intro")).toHaveCount(0, { timeout: 15_000 });
  expect((await focusState(page)).visible).toBe(false);
  const p2 = await ctx.newPage();
  await p2.goto("/login");
  await expect(p2.getByTestId("home-intro")).toBeVisible();
  await p2.keyboard.press("Tab");
  await expect(p2.getByTestId("launch-intro")).toHaveCount(0, { timeout: 15_000 });
  const f = await focusState(p2);
  expect(f.inLogin).toBe(true);
  expect(f.visible).toBe(true);
  await ctx.close();
});

test("intro: cap ratlla daurada (vora, outline ni box-shadow) a baix", async ({ browser }) => {
  const ctx = await ctxFor(browser, true);
  const page = await ctx.newPage();
  await page.emulateMedia({ reducedMotion: "no-preference" });
  await page.goto("/login");
  await expect(page.getByTestId("home-intro")).toBeVisible();
  await page.waitForTimeout(300);
  const bad = await page.evaluate(() => {
    const out: string[] = [];
    for (const el of document.querySelectorAll<HTMLElement>("[data-testid='launch-intro'], [data-testid='launch-intro'] *")) {
      const cs = getComputedStyle(el);
      const r = el.getBoundingClientRect();
      if (r.width < innerWidth * 0.6) continue; // només barres a tota l'amplada
      if (parseFloat(cs.borderBottomWidth) > 0 && cs.borderBottomStyle !== "none") out.push(`${el.className} border`);
      if (cs.outlineStyle !== "none" && parseFloat(cs.outlineWidth) > 0) out.push(`${el.className} outline`);
      if (cs.boxShadow && cs.boxShadow !== "none") out.push(`${el.className} shadow`);
      if (r.height <= 6 && cs.backgroundColor !== "rgba(0, 0, 0, 0)") out.push(`${el.className} bar`);
    }
    return out;
  });
  expect(bad).toEqual([]);
  await ctx.close();
});

test("logo del /login: cap píxel de fum semitransparent (alpha 0 o opac)", async ({ page }) => {
  const res = await page.request.get("/brand/logo-net-cartes-512.webp");
  expect(res.ok()).toBe(true);
  await page.goto("/privacy");
  const semi = await page.evaluate(async () => {
    const img = new Image();
    img.src = "/brand/logo-net-cartes-512.webp";
    await img.decode();
    const c = document.createElement("canvas");
    c.width = c.height = 512;
    const g = c.getContext("2d")!;
    g.drawImage(img, 0, 0);
    const d = g.getImageData(0, 0, 512, 512).data;
    let n = 0;
    for (let i = 3; i < d.length; i += 4) if (d[i] > 8 && d[i] < 247) n++;
    return n / (512 * 512);
  });
  expect(semi).toBeLessThan(0.03);
});

for (const vp of [{ width: 390, height: 844 }, { width: 375, height: 667 }, { width: 1280, height: 800 }, { width: 1920, height: 1080 }]) {
  test(`splash d'arrencada dins la pantalla a ${vp.width}×${vp.height} (v167: intro literal)`, async ({ browser }) => {
    const ctx = await browser.newContext({ viewport: vp, locale: "en-US", colorScheme: "dark" });
    const page = await ctx.newPage();
    await page.goto("/login");
    // v174: la splash d'iOS és el fotograma 0 (fons pla); el logo superposat ja no es mostra.
    await expect(page.getByTestId("home-intro")).toBeVisible({ timeout: 10_000 });
    await expect(page.getByTestId("home-intro-splash")).toBeHidden();
    await expect(page.getByTestId("home-intro-back")).toHaveCount(vp.height > vp.width ? 9 : 13);
    await ctx.close();
  });
}
