import { expect, test } from "@playwright/test";

test.use({
  viewport: { width: 390, height: 844 },
  video: process.env.PW_VIDEO ? { mode: "on", size: { width: 390, height: 844 } } : "off",
});

test("the motion toggle can re-enable the peek hint when the OS prefers reduced motion", async ({ browser }, testInfo) => {
  const context = await browser.newContext({
    viewport: { width: 390, height: 844 },
    reducedMotion: "reduce",
    locale: "ca-ES",
    colorScheme: "dark",
  });
  const page = await context.newPage();
  await page.goto("/e2e/peek-flip-demo.html?showHint");

  const toggle = page.locator("button[aria-pressed]");
  const host = page.getByTestId("peek-curl-host");
  await expect(toggle).toHaveAttribute("aria-pressed", "true");
  await expect(page.getByTestId("peek-swipe-hint")).toHaveCount(0);
  await toggle.click();
  await expect(toggle).toHaveAttribute("aria-pressed", "false");
  await expect(page.getByTestId("peek-swipe-hint")).toBeVisible({ timeout: 5_000 });
  await expect(host).toHaveAttribute("data-peek-hint", "yes");
  await expect.poll(() => host.locator(".peek-curl-rest").evaluate((el) => getComputedStyle(el).animationName))
    .toBe("peek-hint-corner-lift");
  await page.screenshot({ path: testInfo.outputPath("reduced-motion-override.png"), fullPage: true });
  await context.close();
});

test("slow lift turns the real game card smoothly around its vertical axis", async ({ page }) => {
  await page.goto("/e2e/peek-flip-demo.html");
  const host = page.getByTestId("peek-curl-host");
  await expect(host).toBeVisible();
  await expect(host.locator(".spanish-card .card-back .baralla-dors")).toHaveCount(1);
  await expect(host.locator(".card-face .baralla-carta")).toHaveCount(0);

  const cardBox = (await host.boundingBox())!;
  const x = cardBox.x + cardBox.width / 2;
  const y0 = cardBox.y + cardBox.height * 0.92;
  const poses: Array<{ angle: number; opacity: number; lift: number }> = [];
  const turn = page.getByTestId("peek-curl-turn");
  await page.mouse.move(x, y0);
  await page.mouse.down();
  for (let i = 1; i <= 60; i += 1) {
    await page.mouse.move(x, y0 - cardBox.height * (i / 60));
    await page.waitForTimeout(30);
    const pose = await page.evaluate(() => {
      const layer = document.querySelector<HTMLElement>("[data-testid='peek-curl-turn']");
      return layer ? {
        angle: Number(layer.getAttribute("data-flip-angle-y")),
        opacity: Number(layer.style.opacity),
        lift: Number(layer.getAttribute("data-lift-px")),
      } : null;
    });
    if (pose) poses.push(pose);
  }
  await page.mouse.up();
  const angles = poses.map(({ angle }) => angle);
  await expect.poll(() => Math.max(...angles), { timeout: 2_000 }).toBeGreaterThan(175);
  expect(Math.min(...angles)).toBeLessThan(5);
  expect(angles.some((angle) => angle > 80 && angle < 100), "the live turn passes smoothly through edge-on").toBe(true);
  expect(poses.some(({ angle, opacity }) => angle > 40 && angle < 140 && opacity >= 0.99), "the rotating card stays fully opaque after the curl handoff").toBe(true);
  expect(poses.some(({ angle, lift }) => angle > 40 && angle < 140 && lift > cardBox.height * 0.1), "the card rises during the vertical-axis turn").toBe(true);
  expect(poses.some(({ angle, lift }) => angle > 175 && lift < 1), "the card returns to its baseline at the end of the turn").toBe(true);
  await expect(turn).toHaveAttribute("data-flip-axis", "y");
  await expect(turn.locator(".card-face .baralla-carta")).toHaveCount(1);
  await expect(page.locator(".spanish-card[data-face='up']").last()).toBeVisible({ timeout: 3_000 });
});
