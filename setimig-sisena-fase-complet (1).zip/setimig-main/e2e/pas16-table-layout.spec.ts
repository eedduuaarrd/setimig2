import { expect, test } from "@playwright/test";
import fs from "node:fs";
import path from "node:path";
import { startAiGameFromLobby } from "./helpers/aiLobby";
import { passAgeGateToLobby } from "./helpers/ageGateLobby";
import {
  assertHandNotCoveredByDock,
  assertLocalHandVisible,
  confirmBetIfShown,
  playUntilSettlement,
  settlementSurface,
  waitForHandSurface,
} from "./helpers/tableFlow";

type Vp = { name: string; width: number; height: number; bots: number; shot?: string };

const VIEWPORTS: Vp[] = [
  { name: "360", width: 360, height: 740, bots: 3, shot: "360-my-turn" },
  { name: "390", width: 390, height: 844, bots: 3, shot: "390-rival-turn" },
  { name: "844x390", width: 844, height: 390, bots: 3, shot: "844x390-landscape" },
  { name: "1024", width: 1024, height: 800, bots: 6, shot: "1024-6bots" },
  { name: "1280", width: 1280, height: 800, bots: 1, shot: "1280-result" },
];

function screenshotDir(): string {
  const candidates = [
    "/cursor/stores/self/media/pas16",
    path.join(process.cwd(), "media/pas16"),
  ];
  for (const dir of candidates) {
    try {
      fs.mkdirSync(dir, { recursive: true });
      return dir;
    } catch {
      /* try next */
    }
  }
  return candidates[candidates.length - 1];
}

for (const vp of VIEWPORTS) {
  test(`PAS 16 — layout ${vp.name} (${vp.bots} bots)`, async ({ page }) => {
    // Same bug as PAS 12 desktop: the seat grid and the local hand live inside
    // the mobileLayout branch, so a viewport >=1024px never mounts them.
    test.fixme(
      vp.width >= 1024,
      "A >=1024px GameView no munta ni la graella de seients ni la mà local."
    );
    test.setTimeout(240_000);
    const OUT = screenshotDir();
    await page.setViewportSize({ width: vp.width, height: vp.height });
    await passAgeGateToLobby(page, `Pas16-${vp.name}`, {
      playerId: `pas16${vp.name.replace(/\W/g, "")}${vp.bots}bot`.slice(0, 32),
      online: true,
    });

    await startAiGameFromLobby(page, vp.bots);
    await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 60_000 });
    await waitForHandSurface(page);
    await confirmBetIfShown(page);
    await assertLocalHandVisible(page);
    await assertHandNotCoveredByDock(page);

    if (vp.width < 1024) {
      await expect(page.locator("[data-seat-player]").first()).toBeVisible();
    } else {
      await expect(page.getByTestId("game-seat-grid")).toBeVisible();
      await expect(page.locator("[data-seat-player]")).toHaveCount(vp.bots);
    }

    if (vp.shot) {
      await page.screenshot({ path: path.join(OUT, `${vp.shot}.png`), fullPage: false });
    }

    if (vp.name === "1280") {
      await playUntilSettlement(page);
      await expect(settlementSurface(page).first()).toBeVisible();
      await page.screenshot({ path: path.join(OUT, "final-partida.png"), fullPage: false });
    }
  });
}

test("PAS 16 — 360 amb 1 bot", async ({ page }) => {
  test.setTimeout(180_000);
  await page.setViewportSize({ width: 360, height: 740 });
  await passAgeGateToLobby(page, "Pas16-360-1", { playerId: "pas163601botuser", online: true });
  await startAiGameFromLobby(page, 1);
  await waitForHandSurface(page);
  await confirmBetIfShown(page);
  await assertLocalHandVisible(page);
  await assertHandNotCoveredByDock(page);
});

test("PAS 16 — 360 amb 6 bots", async ({ page }) => {
  test.setTimeout(240_000);
  await page.setViewportSize({ width: 360, height: 740 });
  await passAgeGateToLobby(page, "Pas16-360-6", { playerId: "pas163606botuser", online: true });
  await startAiGameFromLobby(page, 6);
  await waitForHandSurface(page);
  await confirmBetIfShown(page);
  await assertLocalHandVisible(page);
  await assertHandNotCoveredByDock(page);
  await expect(page.locator("[data-seat-player]")).toHaveCount(6);
});
