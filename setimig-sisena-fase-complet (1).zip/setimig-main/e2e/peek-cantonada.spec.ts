import { expect, test, type Page } from "@playwright/test";
import fs from "node:fs";
import path from "node:path";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

const SHOTS = process.env.SETIMIG_ANIM_SHOTS || "/tmp/peek-cantonada-shots";

type Card = { suit: "hearts" | "diamonds" | "clubs" | "spades"; value: number; points: number };
const card = (value: number, suit: Card["suit"] = "spades"): Card => ({
  suit, value, points: value >= 10 ? 0.5 : value,
});

/** Vista solo congelada: torn propi amb 1 d'espases tapada (cara SpanishCard al peek). */
function frozenPeekView(pid: string, name: string) {
  const humanId = `local-human-${pid}`;
  return {
    id: `solo-peek-${pid}`,
    name: "Partida IA",
    pot: 100,
    minBet: 100,
    jackpot: 0,
    phase: "playing",
    turnPlayerIndex: 0,
    lastRound: null,
    centerDiscard: [],
    soloAi: true,
    soloHumanPlayerId: pid,
    soloBotCount: 1,
    houseRulesEnabled: false,
    practiceMode: true,
    matchProgress: { handNumber: 1, totalHands: 10 },
    matchEnded: false,
    matchResult: null,
    turnDeadlineAt: Date.now() + 120_000,
    viewerSeatToken: `${humanId}-token`,
    players: [
      {
        id: humanId,
        playerId: pid,
        seatToken: `${humanId}-token`,
        name,
        chips: 900,
        bet: 100,
        isBanker: false,
        isBot: false,
        status: "playing",
        handSlots: [{
          id: `${humanId}-hand`,
          bet: 100,
          status: "playing",
          doubled: false,
          canDouble: false,
          mort: false,
          blindPair: false,
          blindUntilBankEnd: false,
          mortOffered: false,
          cards: [{ id: `${humanId}-c0`, card: card(1, "spades"), faceUp: false }],
        }],
        activeSlotIndex: 0,
        lastRoyal7Payout: 0,
        royal7AsBankerStreak: 0,
      },
      {
        id: "bot-n-bank",
        playerId: "bot-n-bank",
        seatToken: "bot-n-bank-token",
        name: "Laia",
        chips: 5000,
        bet: 0,
        isBanker: true,
        isBot: true,
        status: "playing",
        handSlots: [{
          id: "bot-n-bank-hand",
          bet: 0,
          status: "playing",
          doubled: false,
          canDouble: false,
          mort: false,
          blindPair: false,
          blindUntilBankEnd: false,
          mortOffered: false,
          cards: [{ id: "bot-n-bank-c0", card: card(5, "clubs"), faceUp: false }],
        }],
        activeSlotIndex: 0,
        lastRoyal7Payout: 0,
        royal7AsBankerStreak: 0,
      },
    ],
  };
}

async function mountFrozenSolo(page: Page, pid: string, name: string) {
  const view = frozenPeekView(pid, name);
  await page.route(/\/api\/solo\/(session|view|action|leave)/, async (route) => {
    const req = route.request();
    if (req.method() === "POST" && req.url().includes("/leave")) {
      await route.fulfill({ status: 200, contentType: "application/json", body: JSON.stringify({ left: true }) });
      return;
    }
    await route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify({ view }),
    });
  });
  await page.routeWebSocket(/\/socket\.io/i, (socket) => socket.close());
  await page.route(/\/socket\.io/i, (route) => route.abort());

  await seedE2eSession(page, pid);
  await page.addInitScript(({ playerId, playerName }) => {
    localStorage.setItem("setimig_player_id", playerId);
    localStorage.setItem("setimig_player_name", playerName);
    localStorage.setItem("setimig_onboarding_v1", "1");
    localStorage.setItem("setimig_interactive_tutorial_v1", "1");
    localStorage.setItem("setimig_table_tutorial_v1", "1");
    localStorage.setItem(
      "setimig_age_gate",
      JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }),
    );
  }, { playerId: pid, playerName: name });

  await page.goto("/");
  await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 45_000 });
  const skip = page.getByTestId("interactive-tutorial-skip");
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible({ timeout: 15_000 });
  await page.getByTestId("ai-bot-count-1").click();
  await page.getByTestId("ai-bot-picker-start").click();
  await expect(page.getByTestId("peek-curl-grab").first()).toBeVisible({ timeout: 45_000 });
}

async function slowPartialPeek(page: Page) {
  const grab = page.getByTestId("peek-curl-grab").first();
  const host = page.getByTestId("peek-curl-host").first();
  await expect(grab).toBeVisible({ timeout: 10_000 });
  const hbox = (await host.boundingBox())!;
  const gb = (await grab.boundingBox())!;
  // page.evaluate: no torna a esperar el locator (evita detach a mig gest).
  const fire = (phase: "down" | "move" | "up", y: number) =>
    page.evaluate((a) => {
      const el = document.querySelector('[data-testid="peek-curl-grab"]') as HTMLElement | null;
      if (!el) throw new Error("peek-curl-grab missing");
      const type = a.phase === "down" ? "pointerdown" : a.phase === "move" ? "pointermove" : "pointerup";
      (a.phase === "down" ? el : window).dispatchEvent(new PointerEvent(type, {
        bubbles: true, cancelable: true, view: window, clientX: a.x, clientY: a.y,
        pointerId: 1, pointerType: "mouse", isPrimary: true, buttons: a.phase === "up" ? 0 : 1, button: 0,
      }));
    }, { phase, x: gb.x + gb.width / 2, y });
  const y0 = gb.y + Math.min(gb.height * 0.7, gb.height - 4);
  await fire("down", y0);
  for (let i = 1; i <= 12; i++) {
    await fire("move", y0 - hbox.height * 0.55 * (i / 12));
    await page.waitForTimeout(40);
  }
  await expect(host).toHaveAttribute("data-peeking", "yes");
  return { host, hbox, fire, y0 };
}

for (const vp of [
  { w: 390, h: 844, tag: "390" },
  { w: 1280, h: 800, tag: "1280" },
]) {
  test(`v160: curl — índex SpanishCard (sense badge HTML), no demana (${vp.tag})`, async ({ page }) => {
    fs.mkdirSync(SHOTS, { recursive: true });
    await page.setViewportSize({ width: vp.w, height: vp.h });
    const pid = e2ePoolId();
    await mountFrozenSolo(page, pid, `Peek${vp.tag}`);

    const count = () => page.locator('[data-testid="local-hand-card"], .desktop-own-hand > *').count();
    const before = await count();
    const { host, fire, y0, hbox } = await slowPartialPeek(page);

    await expect(page.getByTestId("peek-face-index")).toHaveCount(0);
    await expect(host).toHaveAttribute("data-index-in-view", "yes", { timeout: 2_000 });
    await expect(host).toHaveAttribute("data-peek-rank", "1");
    await expect(host).toHaveAttribute("data-peek-suit", "espases");

    const measure = await page.evaluate(() => {
      const hostEl = document.querySelector('[data-testid="peek-curl-host"]') as HTMLElement;
      const canvas = document.querySelector('[data-testid="peek-curl-canvas"]') as HTMLCanvasElement;
      const h = hostEl.getBoundingClientRect();
      const faceTop = parseFloat(hostEl.getAttribute("data-face-top") || "1");
      const faceRows = parseFloat(hostEl.getAttribute("data-face-rows") || "0");
      let dark = 0;
      let samples = 0;
      if (canvas) {
        const ctx = canvas.getContext("2d");
        if (ctx) {
          const dpr = canvas.width / Math.max(1, canvas.getBoundingClientRect().width);
          const cssH = canvas.getBoundingClientRect().height;
          const cardTopInCanvas = cssH - h.height;
          const x0 = Math.floor(h.width * 0.04 * dpr);
          const x1 = Math.floor(h.width * 0.28 * dpr);
          const y0 = Math.floor((cardTopInCanvas + h.height * 0.02) * dpr);
          const y1 = Math.floor((cardTopInCanvas + h.height * 0.28) * dpr);
          const w = Math.max(1, x1 - x0);
          const hh = Math.max(1, y1 - y0);
          try {
            const data = ctx.getImageData(x0, y0, w, hh).data;
            for (let i = 0; i < data.length; i += 16) {
              samples++;
              const r = data[i], g = data[i + 1], b = data[i + 2], a = data[i + 3];
              if (a < 180) continue;
              const luma = 0.2126 * r + 0.7152 * g + 0.0722 * b;
              if (luma < 140) dark++;
            }
          } catch { /* tainted */ }
        }
      }
      return {
        faceTop, faceRows,
        indexInRevealed: faceTop <= 0.08 && faceRows >= 0.3,
        dark, samples,
        canvasOpacity: canvas ? parseFloat(getComputedStyle(canvas).opacity) : 0,
      };
    });

    expect(measure.canvasOpacity, "el llenç del peek ha de ser visible").toBeGreaterThanOrEqual(0.99);
    expect(measure.indexInRevealed, `índex dins zona revelada top=${measure.faceTop} rows=${measure.faceRows}`).toBeTruthy();
    if (measure.samples > 20) {
      expect(measure.dark, "hi ha tinta de l'índex imprès (SpanishCard) a la cantonada").toBeGreaterThanOrEqual(4);
    }

    const shot = path.join(SHOTS, `after-peek-corner-${vp.tag}.png`);
    await host.screenshot({ path: shot });
    const zoomPath = path.join(SHOTS, `after-zoom-${vp.tag}.png`);
    const box = (await host.boundingBox())!;
    const zoomW = Math.min(box.width * 0.5, 160);
    const zoomH = Math.min(box.height * 0.45, 180);
    await page.screenshot({
      path: zoomPath,
      clip: {
        x: Math.max(0, box.x - 4),
        y: Math.max(0, box.y - 4),
        width: Math.min(vp.w - Math.max(0, box.x - 4), zoomW + 8),
        height: Math.min(vp.h - Math.max(0, box.y - 4), zoomH + 8),
      },
    });

    await fire("up", y0 - hbox.height * 0.55);
    await expect(host).toHaveAttribute("data-peeking", "no", { timeout: 3_000 });
    expect(await count(), "el peek lent no demana carta").toBeLessThanOrEqual(before);
  });
}
