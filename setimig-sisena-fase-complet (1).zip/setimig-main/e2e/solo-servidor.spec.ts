import { expect, test, type Page } from "@playwright/test";
import { passAgeGateToLobby } from "./helpers/ageGateLobby";

type WireView = {
  phase?: string;
  players?: {
    id?: string;
    isBot?: boolean;
    isBanker?: boolean;
    handSlots?: { cards?: { faceUp?: boolean; card?: unknown }[] }[];
  }[];
};

function hiddenCardLeak(view: WireView): string | null {
  const raw = JSON.stringify(view);
  if (raw.includes('"deck"')) return "deck";
  const reveal = view.phase === "settlement";
  const bankDone = view.phase === "banker" || view.phase === "settlement";
  for (const player of view.players ?? []) {
    for (const slot of player.handSlots ?? []) {
      for (const card of slot.cards ?? []) {
        if (!card.card) continue;
        if (player.isBanker && !bankDone && !reveal) return "banker";
        if (player.isBot && player.id !== undefined && !card.faceUp && !reveal) return "bot";
      }
    }
  }
  return null;
}

async function playSoloAt(page: Page, width: number, name: string) {
  const leaks: string[] = [];
  const auths: string[] = [];
  const phases = new Set<string>();
  page.on("pageerror", (error) => {
    if (/socket|websocket/i.test(error.message)) return;
    leaks.push(`pageerror:${error.message}`);
  });
  page.on("request", (request) => {
    if (!request.url().includes("/api/solo/")) return;
    auths.push(request.headers().authorization ?? "");
  });
  page.on("response", (response) => {
    if (!response.url().includes("/api/solo/") || !response.ok()) return;
    void response
      .json()
      .then((body: { view?: WireView }) => {
        const view = body?.view;
        if (!view) return;
        if (view.phase) phases.add(view.phase);
        const leak = hiddenCardLeak(view);
        if (leak) leaks.push(leak);
      })
      .catch(() => undefined);
  });

  await page.routeWebSocket(/\/socket\.io/i, (socket) => socket.close());
  await page.route(/\/socket\.io/i, (route) => route.abort());
  await page.setViewportSize({ width, height: width < 800 ? 844 : 800 });
  await passAgeGateToLobby(page, name);
  await page.waitForTimeout(1500);
  await expect(page.getByTestId("play-with-friends-button")).toHaveAttribute("aria-disabled", "true");
  const skip = page.getByTestId("interactive-tutorial-skip");
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  await page.getByTestId("ai-bot-count-2").click();
  await page.getByTestId("ai-bot-picker-start").click();
  await expect(page.getByTestId("ai-bot-picker")).toHaveCount(0);
  await expect(page.getByTestId("game-top-bar")).toBeVisible({ timeout: 45_000 });
  await expect(page.getByRole("button", { name: "Leave game" })).toBeVisible();
  await expect
    .poll(() => {
      const seen = [...phases].join(",") || "cap-vista";
      const auth = auths.some((value) => value.startsWith("Bearer ")) ? "bearer" : "sense-bearer";
      const ready = (phases.has("playing") || phases.has("betting") || phases.has("banker")) && auth === "bearer";
      return ready ? "ok" : `${seen}|${auth}|n=${auths.length}`;
    }, { timeout: 30_000 })
    .toBe("ok");
  expect(leaks, leaks.join("\n")).toEqual([]);
  await expect(page.getByTestId("action-dock")).toBeVisible();
}

test("solo al servidor, 390: la vista no porta cartes tapades", async ({ page }) => {
  await playSoloAt(page, 390, "Solo390");
});

test("solo al servidor, 1280: la vista no porta cartes tapades", async ({ page }) => {
  await playSoloAt(page, 1280, "Solo1280");
});
