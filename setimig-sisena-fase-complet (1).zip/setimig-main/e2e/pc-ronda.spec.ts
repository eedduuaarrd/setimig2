import fs from "node:fs";
import path from "node:path";
import { expect, test, type Browser, type BrowserContext, type Page } from "@playwright/test";
import { blockSocketIo, mockLoginSession } from "./helpers/loginSession.ts";
import { animSnapshot } from "./helpers/anim0109Fixtures.ts";

/**
 * Ronda PC (v142), només mesures (sense captures):
 * 1–2) taula a 1280/1440/1920: ample útil, cartes rivals més grans a ≥1440, espai vertical repartit, sense desbordar;
 * 3/5) Tab a login, lobby, perfil i taula: mai BODY, cada focus visible a la pantalla i amb anella;
 * 4) HIT actiu canvia amb el hover; 6) clic = aixecar (v171); es destapa amb Enter/Espai;
 * 390: les caixes clau de la taula són les de main (±1 px, e2e/fixtures/pc-ronda-390-main.json).
 */
const AGE = () => JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" });
const BASELINE = path.join("e2e", "fixtures", "pc-ronda-390-main.json");
const VPS = [
  { tag: "1280x800", width: 1280, height: 800 },
  { tag: "1440x900", width: 1440, height: 900 },
  { tag: "1920x1080", width: 1920, height: 1080 },
] as const;

type Vp = { width: number; height: number };

async function newCtx(browser: Browser, vp: Vp, mobile = false) {
  return browser.newContext({
    viewport: vp,
    deviceScaleFactor: mobile ? 3 : 1,
    isMobile: mobile,
    hasTouch: mobile,
    locale: "en-US",
    colorScheme: "dark",
    serviceWorkers: "block",
  });
}

async function seedSession(ctx: BrowserContext, page: Page, snap?: (pid: string) => string) {
  const pid = `pcronda-${Date.now()}-${Math.round(Math.random() * 1e6)}`;
  const token = `${pid}.token`;
  await page.addInitScript(
    ({ pid, token, age, snap }) => {
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_token", token);
      if (sessionStorage.getItem("pcronda_seeded")) return;
      sessionStorage.setItem("pcronda_seeded", "1");
      const kv: Record<string, string> = {
        setimig_player_name: "Edu",
        "setimig.locale": "en",
        setimig_onboarding_v1: "1",
        setimig_interactive_tutorial_v1: "1",
        setimig_table_tutorial_v1: "1",
        setimig_home_intro_v1: "1",
        setimig_house_rules_enabled: "1",
        setimig_your_turn_hint_v1: "1",
        setimig_age_gate: age,
      };
      for (const [k, v] of Object.entries(kv)) localStorage.setItem(k, v);
      if (snap) {
        localStorage.setItem("setimig_local_solo_snapshot", snap);
        sessionStorage.setItem("setimig_solo_rejoin", "1");
        sessionStorage.setItem("setimig_solo_local", "1");
      }
    },
    { pid, token, age: AGE(), snap: snap ? snap(pid) : null }
  );
  await mockLoginSession(ctx, pid, token);
  const j = (b: unknown) => ({ status: 200, contentType: "application/json", body: JSON.stringify(b) });
  await ctx.route("**/api/history**", (r) => r.fulfill(j({ hands: [], matches: [], nextBefore: null })));
  await ctx.route("**/api/stats**", (r) => r.fulfill(j({ handsPlayed: 3, winRatePercent: 33, averagePoints: 5, passCount: 1 })));
  await ctx.route("**/api/auth/passkeys", (r) => r.fulfill(j({ passkeys: [] })));
  await blockSocketIo(page);
}

/** El meu torn (HIT/STAND), amb la banca i dos rivals amb cartes; la meva primera carta és tapada i es pot destapar. */
const tableSnap = (pid: string) =>
  animSnapshot({
    playerId: pid,
    phase: "playing",
    seats: [
      { key: "bank", name: "Laia", bank: true, cards: [4], tapada: true },
      { key: "anna", name: "Anna", bet: 100, cards: [4, 2], status: "stood", slotStatus: "stood" },
      { key: "me", name: "Edu", human: true, bet: 100, cards: [6, 3], tapada: true },
      { key: "pol", name: "Pol", bet: 100, cards: [3] },
    ],
    turn: 1,
    draws: [5, 5, 5, 5],
    deadlineMs: 600_000,
  });

async function openTable(browser: Browser, vp: Vp, mobile = false) {
  const ctx = await newCtx(browser, vp, mobile);
  const page = await ctx.newPage();
  await seedSession(ctx, page, tableSnap);
  await page.goto("/");
  await expect(page.getByTestId("action-hit")).toBeVisible({ timeout: 30_000 });
  await expect(page.getByTestId("peek-curl-grab")).toBeVisible({ timeout: 15_000 });
  // Deixa acabar els vols d'entrada (≤ 1 s) abans de mesurar.
  await expect.poll(() => page.evaluate(() => document.getAnimations().filter((a) => a.playState === "running" && a.id).length), { timeout: 10_000 }).toBe(0);
  return { ctx, page };
}

/** Espera que acabin les entrades (animacions finites); les ambientals infinites no compten. */
async function settle(page: Page) {
  await expect
    .poll(
      () =>
        page.evaluate(
          () =>
            document.getAnimations().filter((a) => a.playState === "running" && Number.isFinite(Number(a.effect?.getComputedTiming().endTime))).length
        ),
      { timeout: 10_000 }
    )
    .toBe(0);
}

/** Recorre el Tab i, per a cada pas, retorna l'element enfocat i si és visible, a la pantalla i amb anella. */
async function tabWalk(page: Page, steps: number) {
  const out: Array<{ id: string; body: boolean; visible: boolean; ring: boolean }> = [];
  for (let i = 0; i < steps; i++) {
    await page.keyboard.press("Tab");
    out.push(
      await page.evaluate(() => {
        const e = document.activeElement as HTMLElement | null;
        if (!e || e === document.body || e === document.documentElement) return { id: "BODY", body: true, visible: false, ring: false };
        const r = e.getBoundingClientRect();
        const on = r.width > 1 && r.height > 1 && r.bottom > 0 && r.top < innerHeight && r.right > 0 && r.left < innerWidth;
        const cx = Math.min(innerWidth - 1, Math.max(0, r.left + r.width / 2));
        const cy = Math.min(innerHeight - 1, Math.max(0, r.top + r.height / 2));
        const hit = document.elementFromPoint(cx, cy);
        const top = !!hit && (hit === e || e.contains(hit) || hit.contains(e) || !!hit.closest("label")?.contains(e));
        const cs = getComputedStyle(e);
        const ring = (cs.outlineStyle !== "none" && parseFloat(cs.outlineWidth) > 0) || cs.boxShadow !== "none";
        const id = (e.dataset.testid || e.getAttribute("aria-label") || e.innerText || e.tagName).replace(/\s+/g, " ").slice(0, 24);
        const why = `{${cs.opacity},${cs.visibility}}` + (on ? (top ? "" : `<${hit?.tagName}.${String(hit?.className ?? "").slice(0, 40)}>`) : `@${Math.round(r.top)}`);
        return { id: id + why, body: false, visible: on && top && cs.visibility !== "hidden" && Number(cs.opacity) > 0.05, ring };
      })
    );
  }
  return out;
}

function assertWalk(walk: Awaited<ReturnType<typeof tabWalk>>, label: string) {
  const bad = walk.filter((w) => w.body || !w.visible || !w.ring);
  expect(bad, `${label}: ${walk.map((w) => `${w.id}${w.body ? "" : w.visible ? "" : "[OFF]"}${w.ring ? "" : "[NORING]"}`).join(" | ")}`).toEqual([]);
  // El recorregut torna a començar (no s'encalla) i passa per més d'un element.
  expect(new Set(walk.map((w) => w.id)).size, label).toBeGreaterThan(1);
}

async function tableBoxes(page: Page) {
  return page.evaluate(() => {
    const box = (sel: string) => {
      const el = document.querySelector(sel);
      if (!el) return null;
      const b = el.getBoundingClientRect();
      return { x: b.x, y: b.y, w: b.width, h: b.height, bottom: b.bottom };
    };
    const seats = [...document.querySelectorAll("[data-testid=game-seat-grid] [data-seat-player]")].map((e) => e.getBoundingClientRect());
    const stage = document.querySelector(".game-table-stage") as HTMLElement | null;
    return {
      root: box(".game-table-root"),
      ring: box("[data-testid=game-seat-grid]"),
      layer: box(".game-table-player-layer"),
      hit: box("[data-testid=action-hit]"),
      stand: box("[data-testid=action-stand]"),
      rival: box(".spanish-card-size-opponent"),
      overlap: (() => {
        const rivals = [...document.querySelectorAll("[data-testid=game-seat-grid] .spanish-card")].map((e) => e.getBoundingClientRect());
        const own = [...document.querySelectorAll("[data-testid=local-player-seat] .spanish-card, [data-testid=peek-curl-host]")].map((e) => e.getBoundingClientRect());
        const n: string[] = [];
        for (const a of rivals) for (const b of own) if (a.right > b.left + 1 && b.right > a.left + 1 && a.bottom > b.top + 1 && b.bottom > a.top + 1) n.push(`${[a.x, a.y, a.width, a.height].map(Math.round)} / ${[b.x, b.y, b.width, b.height].map(Math.round)}`);
        return n;
      })(),
      seatsTop: seats.length ? Math.min(...seats.map((s) => s.top)) : null,
      seatsBottom: seats.length ? Math.max(...seats.map((s) => s.bottom)) : null,
      overflowX: document.documentElement.scrollWidth - innerWidth,
      overflowY: document.documentElement.scrollHeight - innerHeight,
      stageOverflow: stage ? stage.scrollHeight - stage.clientHeight : 0,
    };
  });
}

for (const vp of VPS) {
  test(`1–2 · taula a escriptori: ample, cartes rivals i espai vertical (${vp.tag})`, async ({ browser }) => {
    const { ctx, page } = await openTable(browser, vp);
    const m = await tableBoxes(page);
    console.log(`[pc-ronda] ${vp.tag} ${JSON.stringify(m)}`);
    expect(m.overflowX).toBeLessThanOrEqual(0);
    expect(m.overflowY).toBeLessThanOrEqual(0);
    expect(m.stageOverflow).toBeLessThanOrEqual(1);
    expect(m.hit!.bottom).toBeLessThanOrEqual(vp.height);
    expect(m.root!.x + m.root!.w).toBeLessThanOrEqual(vp.width);
    // Les cartes rivals no trepitgen la mà pròpia.
    expect(m.overlap).toEqual([]);
    if (vp.width >= 1440) {
      expect(m.root!.w / vp.width).toBeGreaterThanOrEqual(0.9);
      // Rivals centrats a la seva banda: el buit de dalt i el de baix no difereixen més de 12 px.
      const top = m.seatsTop! - m.ring!.y;
      const bottom = m.ring!.bottom - m.seatsBottom!;
      expect(Math.abs(top - bottom)).toBeLessThanOrEqual(12);
    }
    if (vp.width >= 1920) expect(m.rival!.w).toBeGreaterThanOrEqual(80);
    else if (vp.width >= 1440) expect(m.rival!.w).toBeGreaterThan(60);
    else expect(m.rival!.w).toBeGreaterThanOrEqual(58); // QA v142: creixen de manera contínua des de 1024 (abans 53×74 a 1280)
    await ctx.close();
  });
}

for (const vp of [VPS[0], VPS[2]]) {
  test(`5 · Tab a la taula: mai BODY i sempre visible (${vp.tag})`, async ({ browser }) => {
    const { ctx, page } = await openTable(browser, vp);
    assertWalk(await tabWalk(page, 30), `taula ${vp.tag}`);
    await ctx.close();
  });

  test(`4 · HIT actiu canvia amb el hover, com STAND (${vp.tag})`, async ({ browser }) => {
    const { ctx, page } = await openTable(browser, vp);
    const style = (id: string) =>
      page.getByTestId(id).evaluate((e) => {
        const cs = getComputedStyle(e);
        return `${cs.backgroundColor}|${cs.borderTopColor}`;
      });
    await page.mouse.move(2, 2);
    const hit0 = await style("action-hit");
    const stand0 = await style("action-stand");
    await page.getByTestId("action-stand").hover();
    const stand1 = await style("action-stand");
    await page.getByTestId("action-hit").hover();
    const hit1 = await style("action-hit");
    console.log(`[pc-ronda] hover ${vp.tag} HIT ${hit0} → ${hit1} · STAND ${stand0} → ${stand1}`);
    expect(hit1).not.toBe(hit0);
    expect(await page.getByTestId("action-hit").isEnabled()).toBe(true);
    await ctx.close();
  });

  test(`6 · (v171) un clic de ratolí aixeca la carta tapada sense girar-la (${vp.tag})`, async ({ browser }) => {
    const { ctx, page } = await openTable(browser, vp);
    const grab = page.getByTestId("peek-curl-grab");
    const host = page.getByTestId("peek-curl-host");
    await expect(host).toHaveAttribute("data-can-reveal", "yes");
    await grab.click();
    await expect(host).toHaveAttribute("data-index-in-view", "yes", { timeout: 3_000 });
    await expect(grab).toHaveCount(1);
    await ctx.close();
  });

  test(`6 · la carta tapada es destapa amb Enter (${vp.tag})`, async ({ browser }) => {
    const { ctx, page } = await openTable(browser, vp);
    const grab = page.getByTestId("peek-curl-grab");
    await grab.focus();
    await page.keyboard.press("Enter");
    await expect(grab).toHaveCount(0, { timeout: 5_000 });
    await ctx.close();
  });

  test(`3/5 · Tab al lobby i al perfil: mai BODY i sempre visible (${vp.tag})`, async ({ browser }) => {
    const ctx = await newCtx(browser, vp);
    const page = await ctx.newPage();
    await seedSession(ctx, page);
    await page.goto("/");
    await expect(page.getByTestId("player-avatar")).toBeVisible({ timeout: 30_000 });
    await settle(page);
    assertWalk(await tabWalk(page, 24), `lobby ${vp.tag}`);
    await page.getByTestId("player-avatar").click();
    await expect(page.getByTestId("profile-logout")).toBeAttached({ timeout: 15_000 });
    await settle(page);
    await page.mouse.click(2, vp.height - 2);
    const walk = await tabWalk(page, 50);
    assertWalk(walk, `perfil ${vp.tag}`);
    for (const id of ["profile-avatar", "profile-delete-open", "profile-logout"]) expect(walk.some((w) => w.id.startsWith(id)), id).toBe(true);
    await ctx.close();
  });

  test(`5 · Tab al /login: mai BODY i sempre visible (${vp.tag})`, async ({ browser }) => {
    const ctx = await newCtx(browser, vp);
    await ctx.route("**/api/auth/providers", (r) =>
      r.fulfill({ status: 200, contentType: "application/json", body: JSON.stringify({ email: true, google: true, passkey: true, rpId: "sevenhalf.club" }) })
    );
    const page = await ctx.newPage();
    await page.addInitScript(() => sessionStorage.setItem("setimig_intro_launch_v1", "1"));
    await page.goto("/login");
    await expect(page.getByTestId("login-google")).toBeVisible({ timeout: 30_000 });
    await settle(page);
    assertWalk(await tabWalk(page, 16), `login ${vp.tag}`);
    await ctx.close();
  });
}

test("390 · la taula del mòbil no canvia (caixes clau = main ±1 px)", async ({ browser }) => {
  const { ctx, page } = await openTable(browser, { width: 390, height: 844 }, true);
  const boxes = await page.evaluate(() => {
    const out: Record<string, number[] | null> = {};
    for (const id of ["action-hit", "action-stand", "local-player-seat", "peek-curl-grab", "status-pill", "mobile-local-hand-fan"]) {
      const el = document.querySelector(`[data-testid='${id}']`);
      const b = el?.getBoundingClientRect();
      out[id] = b ? [b.x, b.y, b.width, b.height].map((n) => Math.round(n * 10) / 10) : null;
    }
    for (const sel of [".game-table-root", ".spanish-card-size-opponent", ".spanish-card-size-bank", ".spanish-card-size-player"]) {
      const b = document.querySelector(sel)?.getBoundingClientRect();
      out[sel] = b ? [b.x, b.y, b.width, b.height].map((n) => Math.round(n * 10) / 10) : null;
    }
    return out;
  });
  if (process.env.PC_RONDA_WRITE_BASELINE === "1") {
    fs.writeFileSync(BASELINE, JSON.stringify(boxes, null, 2) + "\n");
    await ctx.close();
    return;
  }
  const base = JSON.parse(fs.readFileSync(BASELINE, "utf8")) as Record<string, number[] | null>;
  for (const [k, v] of Object.entries(base)) {
    const now = boxes[k];
    if (v === null) {
      expect(now, k).toBeNull();
      continue;
    }
    expect(now, k).not.toBeNull();
    v.forEach((n, i) => expect(Math.abs(now![i] - n), `${k}[${i}] ${now} vs ${v}`).toBeLessThanOrEqual(1));
  }
  await ctx.close();
});
