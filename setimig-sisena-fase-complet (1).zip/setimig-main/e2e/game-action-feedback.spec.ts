import { expect, test } from "@playwright/test";
import { passAgeGateToLobby } from "./helpers/ageGateLobby";

test("game live region confirms a stand request immediately", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await passAgeGateToLobby(page, "ActionFeedbackTest");
  await page.getByTestId("lobby-context").click();
  await page.getByTestId("ai-bot-count-1").click();
  await page.getByRole("button", { name: "Començar" }).click();
  await page.getByTestId("bet-confirm").click({ timeout: 120_000 });

  const stand = page.getByRole("button", { name: /^Plantar/ });
  await expect(stand).toBeVisible({ timeout: 60_000 });
  await stand.click();
  await expect(page.getByTestId("game-live-region")).toContainText("Plantant-se…");
});
