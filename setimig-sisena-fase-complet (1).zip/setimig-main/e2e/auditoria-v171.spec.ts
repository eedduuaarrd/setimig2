import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * Auditoria client (v171), a 390×844 i 1280×800 (+ peek a 1024×538):
 * 1) primer «Jugar» destaca el mode pràctica, només un cop;
 * 2) fora del torn no hi ha Demanar/Plantar-se; al torn, sempre tots dos;
 * 3) escriptori: clic a la carta tapada l'aixeca fins a l'índex, sense girar-la ni demanar carta;
 * 4) /regles amb l'estil del lobby.
 * Captures només a /workspace/auditoria-v171/ (mai al repo).
 */
const SHOTS = process.env.AUDITORIA_SHOTS_DIR || "/workspace/auditoria-v171";
const SIZES = [
  { tag: "390x844", width: 390, height: 844, desktop: false },
  { tag: "1280x800", width: 1280, height: 800, desktop: true },
  { tag: "1024x538", width: 1024, height: 538, desktop: true },
] as const;

async function seed(page: Page, id: string) {
  await seedE2eSession(page, id);
  await page.addInitScript((pid) => {
    if (sessionStorage.getItem("__aud_seeded")) return;
    sessionStorage.setItem("__aud_seeded", "1");
    localStorage.setItem("setimig_player_id", pid);
    localStorage.setItem("setimig_player_name", "Auditoria");
    localStorage.setItem("setimig_onboarding_v1", "1");
    localStorage.setItem("setimig_interactive_tutorial_v1", "1");
    localStorage.setItem("setimig.locale", "ca");
    localStorage.removeItem("setimig.practiceHintSeen");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
  }, id);
}

for (const vp of SIZES) {
  test(`auditoria v171 · pràctica, botons, peek, regles (${vp.tag})`, async ({ page }) => {
    test.setTimeout(240_000);
    await page.setViewportSize({ width: vp.width, height: vp.height });
    await seed(page, e2ePoolId());

    // 4) /regles amb l'estil del lobby.
    if (vp.tag !== "1024x538") {
      await page.goto("/regles");
      const root = page.locator(".regles-v4");
      await expect(root).toBeVisible({ timeout: 30_000 });
      const st = await page.evaluate(() => {
        const r = document.querySelector(".regles-v4")!;
        const probe = document.createElement("div");
        probe.style.background = "var(--c-bg)";
        document.body.appendChild(probe);
        const bg = getComputedStyle(probe).backgroundColor;
        probe.remove();
        const card = document.querySelector(".regles-card")!;
        return {
          rootBg: getComputedStyle(r).backgroundColor,
          tokenBg: bg,
          h1Font: getComputedStyle(r.querySelector("h1")!).fontFamily,
          cardRadius: getComputedStyle(card).borderTopLeftRadius,
          cardBlur: getComputedStyle(card).backdropFilter,
        };
      });
      expect(st.rootBg).toBe(st.tokenBg);
      expect(st.h1Font).toContain("Cinzel");
      expect(st.cardRadius).toBe("2px");
      expect(st.cardBlur === "none" || st.cardBlur === "").toBe(true);
      await page.screenshot({ path: `${SHOTS}/regles-${vp.tag}.png` }).catch(() => {});
    }

    // 1) Primer «Jugar»: pràctica destacada.
    await page.goto("/");
    await page.getByTestId("lobby-context").click();
    await expect(page.getByTestId("practice-first-hint")).toBeVisible({ timeout: 30_000 });
    await expect(page.getByTestId("ai-practice-row")).toHaveAttribute("data-first", "yes");
    await page.screenshot({ path: `${SHOTS}/practica-${vp.tag}.png` }).catch(() => {});
    expect(await page.evaluate(() => localStorage.getItem("setimig.practiceHintSeen"))).toBe("1");
    await page.getByRole("button", { name: "Cancel·lar" }).click().catch(() => page.keyboard.press("Escape"));
    await page.getByTestId("lobby-context").click();
    await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
    await expect(page.getByTestId("practice-first-hint")).toHaveCount(0);
    await expect(page.getByTestId("ai-practice-row")).toHaveAttribute("data-first", "no");

    await page.getByTestId("ai-bot-count-3").click();
    await page.getByRole("button", { name: "Començar" }).click();
    await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 60_000 });

    let sawMyTurn = false;
    let sawOtherTurn = false;
    let peekDone = !vp.desktop;
    const deadline = Date.now() + 150_000;
    while (Date.now() < deadline && !(sawMyTurn && sawOtherTurn && peekDone)) {
      const betBtn = page.getByTestId("bet-confirm");
      if ((await betBtn.isVisible().catch(() => false)) && (await betBtn.isEnabled().catch(() => false))) {
        await betBtn.click({ timeout: 2_000 }).catch(() => {});
        await page.waitForTimeout(300);
        continue;
      }
      const s = await page.evaluate(() => ({
        row: !!document.querySelector("[data-testid=your-turn-row]"),
        hit: document.querySelectorAll("[data-testid=action-hit]").length,
        stand: document.querySelectorAll("[data-testid=action-stand]").length,
        phase: document.querySelector("[data-phase]")?.getAttribute("data-phase") ?? null,
        grab: !!document.querySelector("[data-testid=peek-curl-grab]"),
      }));
      if (s.row) {
        // 2) Al torn: tots dos sempre.
        expect(s.hit).toBe(1);
        expect(s.stand).toBe(1);
        sawMyTurn = true;
        if (!peekDone && s.grab) {
          // 3) Clic per mirar: s'aixeca, no es gira, no demana carta.
          const cardsBefore = await page.locator("[data-testid=focus-mine] .spanish-card-size-player").count();
          const host = page.getByTestId("peek-curl-host").first();
          await page.getByTestId("peek-curl-grab").first().click();
          await expect(host).toHaveAttribute("data-index-in-view", "yes", { timeout: 3_000 });
          await expect(host).toHaveAttribute("data-peeking", "yes");
          const faceTop = await host.getAttribute("data-peek-fold");
          console.log(`[auditoria] ${vp.tag} peek fold=${faceTop}`);
          await page.screenshot({ path: `${SHOTS}/peek-${vp.tag}.png` }).catch(() => {});
          await expect(page.getByTestId("peek-curl-grab").first()).toBeVisible();
          await page.waitForTimeout(2_200);
          await expect(host).toHaveAttribute("data-peeking", "no");
          expect(await page.locator("[data-testid=focus-mine] .spanish-card-size-player").count()).toBe(cardsBefore);
          await expect(page.getByTestId("action-hit")).toBeVisible();
          peekDone = true;
        }
        if (sawOtherTurn && peekDone) break;
        await page.getByTestId("action-stand").click({ timeout: 2_000 }).catch(() => {});
        await page.waitForTimeout(250);
        continue;
      }
      if (await page.getByRole("button", { name: "Sortir de la partida" }).isVisible().catch(() => false)) {
        // 2) Fora del torn: cap botó de Demanar/Plantar-se.
        expect(s.hit, "sense Demanar fora del torn").toBe(0);
        expect(s.stand, "sense Plantar-se fora del torn").toBe(0);
        sawOtherTurn = true;
      }
      await page.waitForTimeout(250);
    }
    expect(sawMyTurn, "s'ha vist el meu torn").toBe(true);
    expect(sawOtherTurn, "s'ha vist fora del torn").toBe(true);
    expect(peekDone, "clic de peek provat").toBe(true);
  });
}
