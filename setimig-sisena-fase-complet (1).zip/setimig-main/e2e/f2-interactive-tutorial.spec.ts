import AxeBuilder from "@axe-core/playwright";
import { expect, test, type Page } from "@playwright/test";

const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844 },
  { tag: "375x667", width: 375, height: 667 },
  { tag: "360x740", width: 360, height: 740 },
] as const;

async function seedLobbyWithoutTutorial(page: Page, playerId: string, playerName: string) {
  await page.addInitScript(
    ({ id, name }) => {
      localStorage.setItem("setimig_player_id", id);
      localStorage.setItem("setimig_player_name", name);
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem(
        "setimig_age_gate",
        JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
      );
    },
    { id: playerId, name: playerName }
  );
}

async function assertTutorialButtonsFit(page: Page) {
  for (const testId of ["interactive-tutorial-skip", "interactive-tutorial-next"]) {
    const btn = page.getByTestId(testId);
    await expect(btn).toBeVisible();
    const box = await btn.boundingBox();
    expect(box).not.toBeNull();
    const viewport = page.viewportSize()!;
    expect(box!.x).toBeGreaterThanOrEqual(-1);
    expect(box!.x + box!.width).toBeLessThanOrEqual(viewport.width + 1);
    expect(box!.width).toBeGreaterThan(0);
    expect(box!.height).toBeGreaterThanOrEqual(44);
  }
}

test.describe("Tutorial interactiu F2", () => {
  test("primera visita mostra el tutorial al lobby", async ({ page }) => {
    await page.setViewportSize({ width: 390, height: 844 });
    const id = `f2-tut-fresh-${Date.now()}`;
    await seedLobbyWithoutTutorial(page, id, "TutorialFresh");
    await page.goto("/");
    await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 60_000 });
    await expect(page.getByTestId("interactive-tutorial")).toBeVisible();
    await expect(page.getByTestId("interactive-tutorial-step-1")).toBeVisible();
  });

  test("Saltar el tanca i no torna en recarregar", async ({ page }) => {
    await page.setViewportSize({ width: 390, height: 844 });
    const id = `f2-tut-skip-${Date.now()}`;
    await seedLobbyWithoutTutorial(page, id, "TutorialSkip");
    await page.goto("/");
    await expect(page.getByTestId("interactive-tutorial")).toBeVisible();
    await page.getByTestId("interactive-tutorial-skip").click();
    await expect(page.getByTestId("interactive-tutorial")).toHaveCount(0);
    await page.reload();
    await expect(page.getByTestId("lobby-main")).toBeVisible();
    await expect(page.getByTestId("interactive-tutorial")).toHaveCount(0);
  });

  test("es completen els tres passos amb Següent / Fet", async ({ page }) => {
    await page.setViewportSize({ width: 390, height: 844 });
    const id = `f2-tut-steps-${Date.now()}`;
    await seedLobbyWithoutTutorial(page, id, "TutorialSteps");
    await page.goto("/");
    await expect(page.getByTestId("interactive-tutorial-step-1")).toBeVisible();
    await page.getByTestId("interactive-tutorial-next").click();
    await expect(page.getByTestId("interactive-tutorial-step-2")).toBeVisible();
    await page.getByTestId("interactive-tutorial-next").click();
    await expect(page.getByTestId("interactive-tutorial-step-3")).toBeVisible();
    await page.getByTestId("interactive-tutorial-next").click();
    await expect(page.getByTestId("interactive-tutorial")).toHaveCount(0);
    expect(
      await page.evaluate(() => localStorage.getItem("setimig_interactive_tutorial_v1"))
    ).toBe("1");
  });

  test("Escape salta el tutorial", async ({ page }) => {
    await page.setViewportSize({ width: 390, height: 844 });
    const id = `f2-tut-esc-${Date.now()}`;
    await seedLobbyWithoutTutorial(page, id, "TutorialEsc");
    await page.goto("/");
    await expect(page.getByTestId("interactive-tutorial")).toBeVisible();
    await page.keyboard.press("Escape");
    await expect(page.getByTestId("interactive-tutorial")).toHaveCount(0);
  });

  for (const vp of VIEWPORTS) {
    test(`botons sencers sense overflow ${vp.tag}`, async ({ page }) => {
      await page.setViewportSize({ width: vp.width, height: vp.height });
      const id = `f2-tut-fit-${vp.tag}-${Date.now()}`;
      await seedLobbyWithoutTutorial(page, id, "TutorialFit");
      await page.goto("/");
      await expect(page.getByTestId("interactive-tutorial")).toBeVisible();
      await assertTutorialButtonsFit(page);
    });

    test(`axe 0 violacions al tutorial ${vp.tag}`, async ({ page }) => {
      await page.setViewportSize({ width: vp.width, height: vp.height });
      const id = `f2-tut-axe-${vp.tag}-${Date.now()}`;
      await seedLobbyWithoutTutorial(page, id, "TutorialAxe");
      await page.emulateMedia({ reducedMotion: "reduce" });
      await page.goto("/");
      await expect(page.getByTestId("interactive-tutorial")).toBeVisible();
      await expect(page.getByTestId("interactive-tutorial-next")).toBeVisible();
      const results = await new AxeBuilder({ page })
        .include('[data-testid="interactive-tutorial"]')
        .withTags(["wcag2aa", "wcag21aa"])
        .analyze();
      expect(results.violations).toEqual([]);
    });
  }
});
