import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * v187: ordre liquidació — 1) revelació EN GRAN de totes les cartes tapades;
 * 2) només després el plafó Settlement; el compte enrere «Automàtic en X s» arrenca després.
 * Llavor: 3 (separar), 4 (Mort), i mà normal (peek+plantar amb llavor 3 sense separar).
 */
const SEED = process.env.SETIMIG_TEST_DECK_SEED;
const OUT = process.env.REVELA_OUT ?? "/workspace/setimig/v187_revelacio";

async function startSolo(page: Page) {
  await seedE2eSession(page, e2ePoolId());
  await page.addInitScript(() => {
    if (sessionStorage.getItem("qa_llavor") === "1") return;
    sessionStorage.setItem("qa_llavor", "1");
    for (const k of [
      "setimig_onboarding_v1",
      "setimig_interactive_tutorial_v1",
      "setimig_table_tutorial_v1",
      "setimig_house_rules_enabled",
    ])
      localStorage.setItem(k, "1");
    localStorage.setItem("setimig.locale", "ca");
    localStorage.setItem("setimig_player_name", "Test Llavor");
    localStorage.setItem(
      "setimig_age_gate",
      JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }),
    );
    sessionStorage.setItem("setimig_intro_launch_v1", "1");
  });
  await page.goto("/");
  const skip = page.getByTestId("interactive-tutorial-skip");
  await expect(page.getByTestId("lobby-context").or(skip).first()).toBeVisible({ timeout: 45_000 });
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  await page.getByTestId("ai-bot-count-1").click();
  const cb = page.getByTestId("house-rules-toggle").locator("input");
  if ((await cb.count()) && !(await cb.isChecked())) await cb.check({ force: true });
  await page.getByTestId("ai-bot-picker-start").click();
}

const confirmBet = (page: Page) =>
  page.getByTestId("bet-confirm").filter({ visible: true }).first().click({ timeout: 30_000 });

async function swipe(page: Page) {
  const grab = page.getByTestId("peek-curl-grab").filter({ visible: true }).first();
  await expect(grab).toBeVisible({ timeout: 30_000 });
  const b = (await grab.boundingBox())!;
  const x = b.x + b.width / 2,
    y0 = b.y + b.height * 0.95,
    y1 = b.y + b.height * 0.3;
  await page.mouse.move(x, y0);
  await page.mouse.down();
  for (let i = 1; i <= 8; i++) {
    await page.mouse.move(x, y0 + ((y1 - y0) * i) / 8);
    await page.waitForTimeout(40);
  }
  await page.mouse.up();
}

const visibleBtn = (page: Page, name: RegExp) =>
  page.getByRole("button", { name }).filter({ visible: true }).first();

async function playToSettlementReveal(page: Page, mode: "normal" | "split" | "mort") {
  await confirmBet(page);
  if (mode === "mort") {
    // Acceptar el Mort si surt
    for (let i = 0; i < 40; i++) {
      const accept = page.getByTestId("mort-accept").filter({ visible: true }).first();
      if (await accept.isVisible().catch(() => false)) {
        await accept.click();
        break;
      }
      const stand = page.getByTestId("action-stand").filter({ visible: true }).first();
      if (await stand.isVisible().catch(() => false)) break;
      await page.waitForTimeout(250);
    }
  } else {
    await swipe(page);
  }
  if (mode === "split") {
    const dbl = page
      .getByTestId("mobile-double-chip")
      .filter({ visible: true })
      .first()
      .or(visibleBtn(page, /^Doblar/));
    await dbl.first().click({ timeout: 15_000 });
    const split = page
      .getByTestId("mobile-split-button")
      .filter({ visible: true })
      .first()
      .or(visibleBtn(page, /^Separar/));
    await split.first().click({ timeout: 15_000 });
    await expect(page.getByTestId("own-split-hand").first()).toBeVisible({ timeout: 10_000 });
  }
  // Plantar fins a entrar a liquidació (revelació o full)
  const reveal = page.getByTestId("settlement-table-reveal");
  const sheet = page.getByTestId("settlement-sheet");
  for (let i = 0; i < 200; i++) {
    if (await reveal.isVisible().catch(() => false)) return;
    if (await sheet.isVisible().catch(() => false)) return;
    const st = page.getByTestId("action-stand").filter({ visible: true }).first();
    if (await st.isVisible({ timeout: 200 }).catch(() => false)) {
      await st.click({ timeout: 2_000 }).catch(() => {});
    }
    // Descartar ofertes de canvi si surten
    const decline = page.getByTestId("swap-decline").filter({ visible: true }).first();
    if (await decline.isVisible().catch(() => false)) await decline.click().catch(() => {});
    await page.waitForTimeout(300);
  }
  throw new Error("no ha arribat a liquidació");
}

async function assertRevealThenSheet(page: Page, label: string) {
  const reveal = page.getByTestId("settlement-table-reveal");
  const status = page.getByTestId("settlement-reveal-status");
  const sheet = page.getByTestId("settlement-sheet");
  const auto = page.getByTestId("settlement-auto-next-hand");

  // Pot ser que el test arribi just quan ja hi ha revelació, o (reduced/ràpid) molt curta.
  // Esperem revelació visible ABANS del plafó.
  if (await sheet.isVisible().catch(() => false)) {
    // Si el plafó ja és visible sense haver vist revelació, falla: ordre trencat.
    const hadReveal = await reveal.isVisible().catch(() => false);
    if (!hadReveal) {
      throw new Error(`${label}: el plafó Settlement ha sortit sense revelació de taula`);
    }
  }

  const big = page.getByTestId("settlement-big-reveal");
  const mort = page.getByTestId("mort-reveal");
  await expect(reveal.or(status).or(big).or(mort).first()).toBeVisible({ timeout: 60_000 });
  await expect(sheet).toBeHidden();
  await expect(auto).toHaveCount(0);

  // Durant la revelació no hi ha plafó; esperem que el plafó arribi després.
  await expect(sheet).toBeVisible({ timeout: 60_000 });
  // Quan el plafó surt, la marca de revelació ha de desaparèixer
  await expect(reveal).toHaveCount(0);
  // El compte enrere (si hi és) només després del plafó
  if (await auto.isVisible().catch(() => false)) {
    const text = (await auto.textContent()) ?? "";
    expect(text.length).toBeGreaterThan(0);
  }
  // El plafó es veu un temps llegible
  await page.waitForTimeout(800);
  await expect(sheet).toBeVisible();
  await page.screenshot({ path: `${OUT}/${label}.png` }).catch(() => {});
}

const SIZES = [
  { name: "390", width: 390, height: 844 },
  { name: "1280", width: 1280, height: 720 },
] as const;

for (const size of SIZES) {
  test.describe(`v187 revelació @${size.name}`, () => {
    test.use({ viewport: { width: size.width, height: size.height } });

    test(`mà normal (peek+plantar) · llavor ${SEED ?? "?"}`, async ({ page }, testInfo) => {
      test.skip(!SEED || SEED === "4", "cal llavor normal/split (p. ex. 3), no Mort");
      await startSolo(page);
      await playToSettlementReveal(page, "normal");
      await assertRevealThenSheet(page, `${size.name}-normal`);
      if (process.env.PW_VIDEO && size.name === "390") {
        // El vídeo el desa Playwright al test-results; es copia al final del job.
        testInfo.annotations.push({ type: "clip", description: "390-normal" });
      }
    });

    test(`Mort · llavor ${SEED ?? "?"}`, async ({ page }) => {
      test.skip(SEED !== "4", "cal SETIMIG_TEST_DECK_SEED=4");
      await startSolo(page);
      await playToSettlementReveal(page, "mort");
      await assertRevealThenSheet(page, `${size.name}-mort`);
    });

    test(`separar · llavor ${SEED ?? "?"}`, async ({ page }) => {
      test.skip(SEED !== "3", "cal SETIMIG_TEST_DECK_SEED=3");
      await startSolo(page);
      await playToSettlementReveal(page, "split");
      await assertRevealThenSheet(page, `${size.name}-split`);
    });
  });
}
