import { expect, test, type Page } from "@playwright/test";
import { passAgeGateToLobby } from "./helpers/ageGateLobby";
import { startAiGameFromLobby } from "./helpers/aiLobby";

async function startSoloTraditional(page: Page) {
  const errors: string[] = [];
  page.on("pageerror", (e) => errors.push(e.message));
  page.on("console", (msg) => {
    if (msg.type() === "error") errors.push(msg.text());
  });
  await passAgeGateToLobby(page, `Solo${Date.now()}`);
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  await page.getByTestId("ai-bot-count-2").click();
  await page.getByRole("button", { name: "Començar" }).click();
  await expect(page.getByText("Et toca apostar").first()).toBeVisible({ timeout: 30_000 });
  await expect(page.getByTestId("bet-confirm")).toBeVisible();
  expect(errors, errors.join("\n")).toEqual([]);
}

test.describe("iphone safearea solo COMENÇAR", () => {
  test("traditional — Juga ara → Començar", async ({ page }) => {
    await startSoloTraditional(page);
  });

  test("Regles de la casa — Juga ara → Començar", async ({ page }) => {
    const errors: string[] = [];
    page.on("pageerror", (e) => errors.push(e.message));
    page.on("console", (msg) => {
      if (msg.type() === "error") errors.push(msg.text());
    });
    await passAgeGateToLobby(page, `Regles${Date.now()}`);
    await page.getByTestId("lobby-context").click();
    await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
    await page.getByTestId("house-rules-toggle").click();
    await page.getByTestId("ai-bot-count-2").click();
    await page.getByRole("button", { name: "Començar" }).click();
    await expect(page.getByRole("button", { name: /Sortir/i })).toBeVisible({ timeout: 60_000 });
    expect(errors, errors.join("\n")).toEqual([]);
  });

  test("private table — host start", async ({ page }) => {
    const errors: string[] = [];
    page.on("pageerror", (e) => errors.push(e.message));
    page.on("console", (msg) => {
      if (msg.type() === "error") errors.push(msg.text());
    });
    await passAgeGateToLobby(page, `Priv${Date.now()}`);
    await page.getByTestId("play-with-friends-button").click();
    await page.getByTestId("create-private-table-inline").click();
    await expect(page.getByTestId("private-waiting-panel")).toBeVisible({ timeout: 60_000 });
    await page.getByTestId("fill-private-bots").click();
    await page.getByTestId("start-game-button").click();
    await expect(page.getByRole("button", { name: /Sortir/i })).toBeVisible({ timeout: 60_000 });
    expect(errors, errors.join("\n")).toEqual([]);
  });
});
