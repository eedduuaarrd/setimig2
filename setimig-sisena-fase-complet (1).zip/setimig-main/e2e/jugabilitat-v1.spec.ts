import AxeBuilder from "@axe-core/playwright";
import { expect, test, type Page } from "@playwright/test";
import { E2E_ACCOUNT_IDS, e2ePoolId, seedE2eLaunch } from "./helpers/e2eSession.ts";
import {
  playerBettingSnapshot,
  playerTurnSnapshot,
  viewerBankBettingSnapshot,
  viewerBankTurnSnapshot,
} from "./helpers/jugabilitatV1Fixtures.ts";
import { settlementSnapshotJson } from "./helpers/esteticaFormalFixtures.ts";

/** Jugabilitat v1 (jugabilitat-v1.md, ítems [CLIENT] 3–8 + nota d'estil). Només mesures, sense captures. */
const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844 },
  { tag: "375x667", width: 375, height: 667 },
  { tag: "360x740", width: 360, height: 740 },
] as const;

const DOUBLE_PUNCT = /…\.|\.\./;

async function seed(page: Page, snap: string, playerId: string, name: string, lastBet?: number) {
  playerId = E2E_ACCOUNT_IDS.includes(playerId) ? playerId : e2ePoolId();
  await seedE2eLaunch(page, playerId);
  await page.addInitScript(
    ({ snap, pid, pname, lastBet }) => {
      if (sessionStorage.getItem("jug_seeded") === "1") return;
      sessionStorage.setItem("jug_seeded", "1");
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", pname);
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_house_rules_enabled", "1");
      localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
      localStorage.setItem("setimig_local_solo_snapshot", snap);
      sessionStorage.setItem("setimig_solo_rejoin", "1");
      sessionStorage.setItem("setimig_solo_local", "1");
      if (lastBet) sessionStorage.setItem("setimig_last_bet_amount", String(lastBet));
    },
    { snap, pid: playerId, pname: name, lastBet: lastBet ?? 0 }
  );
  // Registra tots els textos del live region i del document per a l'ítem 7.
  await page.addInitScript(() => {
    const w = window as unknown as { __jugTexts: string[] };
    w.__jugTexts = [];
    const start = () => {
      new MutationObserver(() => {
        const live = document.querySelector("[data-testid=game-live-region]")?.textContent ?? "";
        if (live) w.__jugTexts.push(live);
      }).observe(document.body, { subtree: true, childList: true, characterData: true });
    };
    if (document.body) start();
    else document.addEventListener("DOMContentLoaded", start);
  });
  await page.route("**/socket.io/**", (route) => route.abort());
}

async function expectNoAxe(page: Page) {
  const results = await new AxeBuilder({ page }).analyze();
  expect(results.violations.map((v) => `${v.id}: ${v.nodes.map((n) => n.target.join(" ")).join(" | ")}`)).toEqual([]);
}

async function expectNoDoublePunct(page: Page) {
  const texts = await page.evaluate(() => [
    document.body.innerText,
    ...((window as unknown as { __jugTexts: string[] }).__jugTexts ?? []),
  ]);
  for (const text of texts) expect(text, "sense «….» ni «..»").not.toMatch(DOUBLE_PUNCT);
}

/** Clic a «Demanar carta» i ms fins que ha arribat la carta i el botó torna a estar actiu (mesurat dins la pàgina). */
async function clickAndMeasureUnlock(page: Page): Promise<number> {
  return page.evaluate(
    () =>
      new Promise<number>((resolve) => {
        // Taula gran (v147): sense total propi, compta les cartes de la mà.
        const pts = () => String(document.querySelectorAll("[data-testid=local-hand-card], .desktop-own-card").length);
        const before = pts();
        const t0 = performance.now();
        document.querySelector<HTMLButtonElement>("[data-testid=action-hit]")!.click();
        const tick = () => {
          const el = document.querySelector<HTMLButtonElement>("[data-testid=action-hit]");
          const elapsed = performance.now() - t0;
          if ((pts() !== before && el && !el.disabled) || elapsed > 3_000) return resolve(elapsed);
          setTimeout(tick, 10);
        };
        setTimeout(tick, 0);
      })
  );
}

/** Nota d'estil: on hi hagi l'avatar del torn, filet marfil ≤ 1 px i sense brillantor daurada. Retorna quants n'ha mesurat. */
async function expectIvoryTurnRing(page: Page): Promise<number> {
  const rings = await page.evaluate(() =>
    Array.from(document.querySelectorAll<HTMLElement>(".turn-spotlight-avatar"))
      .filter((el) => el.getBoundingClientRect().width > 0)
      .map((el) => {
        const cs = getComputedStyle(el);
        return { width: cs.borderTopWidth, color: cs.borderTopColor, shadow: cs.boxShadow };
      })
  );
  for (const ring of rings) {
    expect(parseFloat(ring.width)).toBeLessThanOrEqual(1);
    expect(ring.shadow).toBe("none");
    const [r, g, b] = (ring.color.match(/[\d.]+/g) ?? []).map(Number);
    expect(Math.min(r!, g!, b!), "marfil, no or").toBeGreaterThanOrEqual(220);
  }
  return rings.length;
}

async function allTexts(page: Page) {
  return page.evaluate(() => [
    document.body.innerText,
    document.querySelector("[data-testid=game-live-region]")?.textContent ?? "",
    ...((window as unknown as { __jugTexts: string[] }).__jugTexts ?? []),
  ].join("\n"));
}

for (const vp of VIEWPORTS) {
  test.describe(`jugabilitat v1 ${vp.tag}`, () => {
    test.use({ viewport: { width: vp.width, height: vp.height } });
    test.setTimeout(60_000);

    test(`ítems 3, 7, 8 i filet: torn propi (${vp.tag})`, async ({ page }) => {
      const pid = e2ePoolId();
      await seed(page, playerTurnSnapshot(pid, "Jugadora"), pid, "Jugadora");
      await page.goto("/");
      const hit = page.getByTestId("action-hit");
      await expect(hit).toBeEnabled({ timeout: 30_000 });
      const live = page.getByTestId("game-live-region");

      // Taula gran (v147): el lector de pantalla ja no anuncia el total propi («Tens 1 punt»).
      await page.waitForTimeout(1_000);
      await expect(live).not.toContainText("Tens");
      // Ítem 5: abans del torn de la banca no hi ha total de la banca.
      await expect(live).not.toContainText("La banca té");

      await expectIvoryTurnRing(page);

      // Ítem 3: del clic al botó de nou actiu ≤ 500 ms.
      const points = page.getByTestId("my-hand-points").first();
      const unlockMs = await clickAndMeasureUnlock(page);
      // Marge de 20 ms pel sondeig de 10 ms de clickAndMeasureUnlock.
      expect(unlockMs, `desbloqueig ${unlockMs} ms`).toBeLessThanOrEqual(520);
      await expect(points).toHaveCount(0);
      await expect(live).not.toContainText("Tens");

      // Doble toc ràpid: exactament 1 carta (1½ + ½ = 2).
      await page.evaluate(() => {
        const el = document.querySelector<HTMLButtonElement>("[data-testid=action-hit]")!;
        el.click();
        el.click();
      });
      await page.waitForTimeout(1_700);
      await expect(hit).toBeEnabled();
      await expect(page.getByTestId("local-hand-card")).toHaveCount(3);
      await expect(points).toHaveCount(0);
      await expect(live).not.toContainText("Tens");

      // Ítem 8 i ítem 7 sobre tot el que s'ha mostrat.
      const texts = await allTexts(page);
      expect(texts).not.toMatch(/\b1 punts\b/);
      expect(texts).not.toMatch(/\d,5 punts/);
      await expectNoDoublePunct(page);
      await expectNoAxe(page);
    });

    test(`ítem 8 · taula gran: no s'anuncia «Tens 6½ punts» (${vp.tag})`, async ({ page }) => {
      const pid = e2ePoolId();
      await seed(page, playerTurnSnapshot(pid, "Jugadora", [6, 10]), pid, "Jugadora");
      await page.goto("/");
      await expect(page.getByTestId("action-hit")).toBeEnabled({ timeout: 30_000 });
      await page.waitForTimeout(1_500);
      await expect(page.getByTestId("game-live-region")).not.toContainText("Tens");
      const texts = await allTexts(page);
      expect(texts).not.toMatch(/\d,5 punts/);
      await expectNoDoublePunct(page);
    });

    test(`ítem 4: avís de banca en començar la mà (${vp.tag})`, async ({ page }) => {
      const pid = e2ePoolId();
      await seed(page, viewerBankBettingSnapshot(pid, "Banquera"), pid, "Banquera");
      await page.goto("/");
      await expect(page.getByTestId("banker-wait-bets").or(page.getByText(/Mà 3/).first())).toBeVisible({ timeout: 30_000 });
      const t0 = Date.now();
      await page.waitForFunction(
        () =>
          /ets la banca/i.test(document.body.innerText) ||
          /ets la banca/i.test(document.querySelector("[data-testid=game-live-region]")?.textContent ?? ""),
        undefined,
        { timeout: 1_000 }
      );
      expect(Date.now() - t0).toBeLessThanOrEqual(1_000);
      await expectNoDoublePunct(page);
      await expectNoAxe(page);
    });

    test(`ítems 4 i 5: torn propi de banca (${vp.tag})`, async ({ page }) => {
      const pid = e2ePoolId();
      await seed(page, viewerBankTurnSnapshot(pid, "Banquera"), pid, "Banquera");
      await page.goto("/");
      const hit = page.getByTestId("action-hit");
      await expect(hit).toBeEnabled({ timeout: 30_000 });
      // «Et toca» visible mentre DEMANAR CARTA està actiu.
      await expect(page.getByText(/Et toca/).first()).toBeVisible();
      const live = page.getByTestId("game-live-region");
      await expect(live).toContainText(/ets la banca/i);
      console.log(`[jugabilitat-v1] filet marfil mesurat a ${await expectIvoryTurnRing(page)} avatar(s) de torn`);
      // Ítem 5: la banca diu el total de les cartes destapades.
      await expect(live).toHaveText(/La banca té .*· (\d+½?|½)\b/);
      await expect(live).toContainText("· 3½");
      await expectNoDoublePunct(page);
      await expectNoAxe(page);
    });

    test(`ítem 6: «Apostar» i «Repetir» mai amb el mateix import (${vp.tag})`, async ({ page }) => {
      const pid = e2ePoolId();
      await seed(page, playerBettingSnapshot(pid, "Apostadora"), pid, "Apostadora", 100);
      await page.goto("/");
      const confirm = page.getByTestId("bet-confirm");
      await expect(confirm).toBeVisible({ timeout: 30_000 });
      const amount = (s: string | null) => (s ?? "").replace(/\D/g, "");
      const repeat = page.getByTestId("bet-repeat");
      if (await repeat.isVisible()) {
        expect(amount(await repeat.textContent())).not.toBe(amount(await confirm.textContent()));
      }
      expect(amount(await confirm.textContent())).toBe("100");
      await expect(repeat).toHaveCount(0);
      await expectNoAxe(page);
      // 1 clic per apostar l'import per defecte.
      await confirm.click();
      await expect(confirm).toBeHidden({ timeout: 10_000 });
    });
  });
}

test.describe("jugabilitat v1 · «Següent» a la liquidació (settlement_next, #161)", () => {
  for (const vp of VIEWPORTS) {
    test(`«Següent» avança la mà sense esperar la finestra sencera (${vp.tag})`, async ({ page }) => {
      test.setTimeout(60_000);
      await page.setViewportSize({ width: vp.width, height: vp.height });
      const pid = e2ePoolId();
      const parsed = JSON.parse(settlementSnapshotJson(pid, "Seguent")) as { room: { settlementStartedAt?: number; lastRound?: { at?: number } } };
      parsed.room.settlementStartedAt = Date.now();
      if (parsed.room.lastRound) parsed.room.lastRound.at = Date.now();
      await seed(page, JSON.stringify(parsed), pid, "Seguent");
      await page.goto("/");
      const next = page.getByTestId("settlement-next-hand");
      await expect(next).toBeEnabled({ timeout: 30_000 });
      await expectNoAxe(page);
      const t0 = Date.now();
      await next.click();
      await expect(page.getByTestId("settlement-sheet")).toBeHidden({ timeout: 4_000 });
      await expect(page.getByTestId("bet-confirm").or(page.getByTestId("banker-wait-bets"))).toBeVisible({ timeout: 4_000 });
      const ms = Date.now() - t0;
      console.log(`[jugabilitat-v1] «Següent» → mà nova en ${ms} ms (${vp.tag})`);
      expect(ms).toBeLessThanOrEqual(4_000);
      await expectNoDoublePunct(page);
    });
  }
});
