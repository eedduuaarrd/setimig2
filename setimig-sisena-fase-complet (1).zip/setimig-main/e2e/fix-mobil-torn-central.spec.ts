import { expect, test, type Page } from "@playwright/test";
import { E2E_ACCOUNT_IDS, e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";
import {
  activeTurnCenterHandSnapshotJson,
  bettingTurnSnapshotJson,
} from "./helpers/fixMobilTornCentralFixtures.ts";

const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844 },
  { tag: "375x667", width: 375, height: 667 },
  { tag: "360x740", width: 360, height: 740 },
] as const;

async function seedLocalSolo(page: Page, snapshot: string, playerId: string, playerName: string) {
  playerId = E2E_ACCOUNT_IDS.includes(playerId) ? playerId : e2ePoolId();
  await seedE2eSession(page, playerId);
  await page.addInitScript(
    ({ snap, pid, pname }) => {
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", pname);
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_house_rules_enabled", "1");
      localStorage.setItem(
        "setimig_age_gate",
        JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
      );
      localStorage.setItem("setimig_local_solo_snapshot", snap);
      sessionStorage.setItem("setimig_solo_rejoin", "1");
      sessionStorage.setItem("setimig_solo_local", "1");
    },
    { snap: snapshot, pid: playerId, pname: playerName }
  );
}

async function assertNoHorizontalOverflow(page: Page) {
  const metrics = await page.evaluate(() => ({
    scrollWidth: document.documentElement.scrollWidth,
    innerWidth: window.innerWidth,
  }));
  expect(metrics.scrollWidth).toBeLessThanOrEqual(metrics.innerWidth + 1);
}

async function assertCenterHandHorizontal(page: Page) {
  const cards = page.locator("[data-testid=active-turn-hand] .active-turn-center-card");
  await expect(cards.first()).toBeVisible({ timeout: 30_000 });
  const count = await cards.count();
  expect(count).toBeGreaterThanOrEqual(2);
  const tops = await cards.evaluateAll((nodes) =>
    nodes.map((node) => node.getBoundingClientRect().top)
  );
  const minTop = Math.min(...tops);
  const maxTop = Math.max(...tops);
  expect(maxTop - minTop).toBeLessThan(20);
}

async function assertBetConfirmFullyVisible(page: Page) {
  const box = await page.getByTestId("bet-confirm").boundingBox();
  expect(box).not.toBeNull();
  if (!box) return;
  const vh = page.viewportSize()?.height ?? 844;
  const vw = page.viewportSize()?.width ?? 390;
  const bottom = box.y + box.height;
  const right = box.x + box.width;
  expect(box.y).toBeGreaterThanOrEqual(-1);
  expect(box.x).toBeGreaterThanOrEqual(-1);
  expect(bottom).toBeLessThanOrEqual(vh + 1);
  expect(right).toBeLessThanOrEqual(vw + 1);
  const clip = await page.evaluate(() => {
    const el = document.querySelector("[data-testid=bet-confirm]") as HTMLElement | null;
    if (!el) return { clipped: true };
    const rect = el.getBoundingClientRect();
    const parent = el.closest(".bet-submit-row") as HTMLElement | null;
    if (!parent) return { clipped: false };
    const pr = parent.getBoundingClientRect();
    return {
      clipped: rect.width + 2 < el.scrollWidth || rect.right > pr.right + 1 || rect.left < pr.left - 1,
    };
  });
  expect(clip.clipped).toBe(false);
}

async function assertSingleBettingPrompt(page: Page) {
  await expect(page.getByTestId("current-turn-prompt")).toBeVisible({ timeout: 30_000 });
  const visibleCount = await page.evaluate(() => {
    let count = 0;
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    while (walker.nextNode()) {
      const text = walker.currentNode.textContent?.trim();
      if (text !== "Et toca apostar") continue;
      const host = walker.currentNode.parentElement;
      if (!host || host.closest(".sr-only")) continue;
      const rect = host.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0) count += 1;
    }
    return count;
  });
  expect(visibleCount).toBe(1);
  await expect(page.locator('[data-testid="status-pill"]:visible')).toHaveCount(0);
}

for (const vp of VIEWPORTS) {
  test.describe(`fix mobil torn central ${vp.tag}`, () => {
    test.use({ viewport: { width: vp.width, height: vp.height } });

    test(`playing own turn: mà local al dock, sense duplicat al centre (${vp.tag})`, async ({ page }) => {
      const playerId = `fmtc-play-${vp.tag.replace(/x/g, "")}`;
      const snapshot = activeTurnCenterHandSnapshotJson(playerId, "FmtcPlay");
      await seedLocalSolo(page, snapshot, playerId, "FmtcPlay");
      await page.route("**/socket.io/**", (route) => route.abort());
      await page.goto("/");
      await expect(page.getByTestId("local-player-seat")).toBeVisible({ timeout: 30_000 });
      // Taula gran (v147): sense total propi durant la jugada.
      await expect(page.getByTestId("my-hand-points")).toHaveCount(0);
      await expect(page.getByTestId("active-turn-hand")).toHaveCount(0);
      await assertNoHorizontalOverflow(page);
    });

    test(`betting single prompt + no overflow (${vp.tag})`, async ({ page }) => {
      const playerId = `fmtc-bet-${vp.tag.replace(/x/g, "")}`;
      const snapshot = bettingTurnSnapshotJson(playerId, "FmtcBet");
      await seedLocalSolo(page, snapshot, playerId, "FmtcBet");
      await page.route("**/socket.io/**", (route) => route.abort());
      await page.goto("/");
      await assertSingleBettingPrompt(page);
      await assertBetConfirmFullyVisible(page);
      await assertNoHorizontalOverflow(page);
    });
  });
}
