import { expect, test, type Page } from "@playwright/test";
import { seedE2eSession } from "./helpers/e2eSession.ts";

const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844 },
  { tag: "375x667", width: 375, height: 667 },
  { tag: "360x740", width: 360, height: 740 },
] as const;

const MODE_CARD_TEST_IDS = ["play-vs-ai-button", "play-with-friends-button"] as const;

async function seedLobby(page: Page) {
  await seedE2eSession(page, "lobby-scroll-test");
  await page.addInitScript(() => {
    localStorage.setItem("setimig_player_id", "lobby-scroll-test");
    localStorage.setItem("setimig_player_name", "LobbyScroll");
    localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
    localStorage.setItem(
      "setimig_age_gate",
      JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
    );
  });
}

function overlapArea(
  a: { x: number; y: number; width: number; height: number },
  b: { x: number; y: number; width: number; height: number }
) {
  const x = Math.max(0, Math.min(a.x + a.width, b.x + b.width) - Math.max(a.x, b.x));
  const y = Math.max(0, Math.min(a.y + a.height, b.y + b.height) - Math.max(a.y, b.y));
  return x * y;
}

async function assertCardFullyVisible(page: Page, testId: string) {
  const target = page.getByTestId(testId);
  await target.scrollIntoViewIfNeeded();
  await expect(target).toBeVisible();

  const metrics = await page.evaluate((id) => {
    const el = document.querySelector(`[data-testid="${id}"]`) as HTMLElement | null;
    if (!el) return null;
    const rect = el.getBoundingClientRect();
    const fixedSelectors = [".app-bottom-nav", ".app-header"];
    const blockers = fixedSelectors
      .map((sel) => document.querySelector(sel))
      .filter(Boolean)
      .map((node) => {
        const r = (node as HTMLElement).getBoundingClientRect();
        return { x: r.x, y: r.y, width: r.width, height: r.height };
      });
    return {
      card: { x: rect.x, y: rect.y, width: rect.width, height: rect.height },
      blockers,
      innerHeight: window.innerHeight,
      innerWidth: window.innerWidth,
    };
  }, testId);

  expect(metrics).not.toBeNull();
  if (!metrics) return;

  const { card, blockers, innerHeight, innerWidth } = metrics;
  expect(card.y).toBeGreaterThanOrEqual(-1);
  expect(card.x).toBeGreaterThanOrEqual(-1);
  expect(card.x + card.width).toBeLessThanOrEqual(innerWidth + 1);
  expect(card.y + card.height).toBeLessThanOrEqual(innerHeight + 1);

  const cardArea = card.width * card.height;
  for (const blocker of blockers) {
    const covered = overlapArea(card, blocker);
    expect(covered / cardArea).toBeLessThan(0.08);
  }
}

for (const vp of VIEWPORTS) {
  test.describe(`lobby scroll targetes ${vp.tag}`, () => {
    test.use({ viewport: { width: vp.width, height: vp.height } });

    test(`targetes de mode sense tapar per chrome fix (${vp.tag})`, async ({ page }) => {
      await seedLobby(page);
      await page.goto("/");
      await expect(page.getByTestId("lobby-welcome")).toBeVisible({ timeout: 30_000 });

      for (const testId of MODE_CARD_TEST_IDS) {
        await assertCardFullyVisible(page, testId);
      }

      await page.getByTestId("legal-footer").scrollIntoViewIfNeeded();
      await expect(page.getByTestId("legal-footer")).toBeVisible();
      await assertCardFullyVisible(page, "play-with-friends-button");
    });
  });
}
