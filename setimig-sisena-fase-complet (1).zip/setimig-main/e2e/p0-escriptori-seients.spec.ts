import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * P0 escriptori (bugs del Provador, test.fixme a #190), només mesures:
 * 1) ≥1024 px: es munten la graella de seients (rivals) i la mà local, i es pot jugar una mà sencera.
 * 2) «Continuar la partida» en una solo en línia emet join_solo_room i torna a la taula.
 * 3) Mòbil: la graella buida no es munta ni reserva espai (abans ~36vh).
 */
const DESKTOP = [
  { tag: "1280x800", width: 1280, height: 800 },
  { tag: "1440x900", width: 1440, height: 900 },
] as const;
const MOBILE = [
  { tag: "390x844", width: 390, height: 844 },
  { tag: "375x667", width: 375, height: 667 },
] as const;

async function seed(page: Page, id: string) {
  await seedE2eSession(page, id);
  await page.addInitScript((pid) => {
    if (sessionStorage.getItem("__p0_seeded")) return;
    sessionStorage.setItem("__p0_seeded", "1");
    localStorage.setItem("setimig_player_id", pid);
    localStorage.setItem("setimig_player_name", "Escriptori");
    localStorage.setItem("setimig_onboarding_v1", "1");
    localStorage.setItem("setimig_interactive_tutorial_v1", "1");
    localStorage.setItem("setimig.locale", "ca");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
  }, id);
}

async function startGame(page: Page, bots: number, practice = false) {
  await page.goto("/");
  // Lobby v4.1 (#181): «Jugar» ja no obre el diàleg; la línia de context sí.
  await page.getByTestId("lobby-context").click();
  await page.getByTestId(`ai-bot-count-${bots}`).click();
  if (practice) await page.getByTestId("ai-practice-mode").check();
  await page.getByRole("button", { name: "Començar" }).click();
  await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 60_000 });
}

/** Element dins del viewport, sense scroll, i no tapat al seu centre. */
async function fullyInViewport(page: Page, testId: string) {
  return page.evaluate((id) => {
    const el = document.querySelector(`[data-testid='${id}']`) as HTMLElement | null;
    if (!el) return { ok: false, why: "absent" };
    const r = el.getBoundingClientRect();
    const inside = r.top >= 0 && r.left >= 0 && r.bottom <= innerHeight + 0.5 && r.right <= innerWidth + 0.5;
    const hit = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
    const top = !!hit && (el === hit || el.contains(hit));
    return { ok: inside && top && r.height >= 44, why: `rect=${Math.round(r.top)},${Math.round(r.bottom)} h=${Math.round(r.height)} top=${top}` };
  }, testId);
}

async function noOverflow(page: Page) {
  return page.evaluate(() => ({
    x: document.documentElement.scrollWidth - innerWidth,
    y: document.scrollingElement ? document.scrollingElement.scrollTop : 0,
  }));
}

for (const vp of DESKTOP) {
  test(`P0 escriptori · seients, mà i una mà sencera (${vp.tag})`, async ({ page }) => {
    await page.setViewportSize({ width: vp.width, height: vp.height });
    await seed(page, e2ePoolId());
    await startGame(page, 3);

    const grid = page.getByTestId("game-seat-grid");
    await expect(grid).toBeVisible({ timeout: 60_000 });
    await expect(page.getByTestId("local-player-seat")).toBeVisible();
    // Abans del primer torn tots tres bots són a l'anell.
    await expect.poll(async () => page.locator("[data-testid=game-seat-grid] [data-seat-player]").count(), { timeout: 30_000 }).toBeGreaterThanOrEqual(2);

    let bet = false;
    let stood = false;
    let handSeen = false;
    let settled = false;
    const deadline = Date.now() + 150_000;
    while (Date.now() < deadline && !settled) {
      const betBtn = page.getByTestId("bet-confirm");
      if (!bet && (await betBtn.isVisible().catch(() => false)) && (await betBtn.isEnabled().catch(() => false))) {
        const m = await fullyInViewport(page, "bet-confirm");
        expect(m.ok, `APOSTAR visible sense scroll: ${m.why}`).toBe(true);
        await betBtn.click({ timeout: 2_000 }).catch(() => {});
        bet = true;
        continue;
      }
      const stand = page.getByTestId("action-stand");
      const hit = page.getByTestId("action-hit");
      if ((await stand.isVisible().catch(() => false)) && (await stand.isEnabled().catch(() => false))) {
        await page.waitForTimeout(450);
        const handCards = await page.locator("[data-testid=local-player-seat] .spanish-card-size-player").count();
        expect(handCards, "mà local muntada a l'escriptori").toBeGreaterThanOrEqual(1);
        handSeen = true;
        for (const id of ["action-stand", "action-hit"]) {
          const m = await fullyInViewport(page, id);
          expect(m.ok, `${id} visible sense scroll: ${m.why}`).toBe(true);
        }
        expect(await hit.isVisible()).toBe(true);
        // La mà no es pinta a sobre del dock (ni parcialment) i els 3 rivals hi són (anell + rival en torn).
        const overlap = await page.evaluate(() => {
          const seat = document.querySelector("[data-testid=local-player-seat] .spanish-card-size-player")?.getBoundingClientRect();
          const dock = document.querySelector("[data-testid=action-dock]")?.getBoundingClientRect();
          if (!seat || !dock) return -1;
          return Math.max(0, Math.min(seat.bottom, dock.bottom) - Math.max(seat.top, dock.top));
        });
        expect(overlap, "mà sense solapar el dock").toBe(0);
        expect(await page.locator("[data-seat-player]").count(), "rivals visibles").toBe(3);
        const o = await noOverflow(page);
        expect(o.x, "sense desbordament horitzontal").toBeLessThanOrEqual(0);
        await stand.click({ timeout: 2_000 }).catch(() => {});
        stood = true;
        await page.waitForTimeout(300);
        continue;
      }
      if (
        (await page.getByTestId("settlement-next-hand").isVisible().catch(() => false)) ||
        (await page.getByTestId("settlement-sheet").isVisible().catch(() => false))
      ) {
        settled = true;
        break;
      }
      await page.waitForTimeout(150);
    }
    expect(bet, "aposta feta").toBe(true);
    expect(handSeen, "mà local vista al torn").toBe(true);
    expect(stood, "Plantar-se fet").toBe(true);
    expect(settled, "liquidació de la mà").toBe(true);
    const o = await noOverflow(page);
    expect(o.x).toBeLessThanOrEqual(0);
  });
}

for (const practice of [false, true]) {
test(`P0 escriptori · flux del Provador (${practice ? "pràctica" : "normal"}): 1 rival, apostar 100 → banca, rival, cartes i pot visibles (1280x800)`, async ({ page }) => {
  await page.setViewportSize({ width: 1280, height: 800 });
  await seed(page, e2ePoolId());
  await startGame(page, 1, practice);
  const visibleIn = async (sel: string) =>
    page.evaluate((q) => {
      return [...document.querySelectorAll(q)].some((el) => {
        const r = el.getBoundingClientRect();
        if (!(r.width > 4 && r.height > 4 && r.top >= 0 && r.bottom <= innerHeight + 0.5 && getComputedStyle(el).visibility !== "hidden")) return false;
        // Sense retallar ni tapar: la part de dalt (nom/etiqueta), el centre i la de baix són de l'element.
        return [r.top + 3, r.top + r.height / 2, r.bottom - 3].every((y) => {
          const hit = document.elementFromPoint(r.left + r.width / 2, y);
          // La zona transparent per mirar/destapar la carta (peek-curl, #256/#277) cobreix a propòsit la
          // part de baix de la mateixa carta: compta com a part de la carta, no com a tapada.
          if (hit?.classList.contains("peek-curl-grab") && hit.parentElement?.contains(el)) return true;
          // El contenidor de la fila de seients (z-10, flex-1) és transparent i a 1280 s'estén per sobre del pot:
          // si al punt només hi ha el contenidor buit (sense fons), el que es veu és l'element de sota.
          if (hit?.getAttribute("data-testid") === "game-seat-grid") {
            const cs = getComputedStyle(hit);
            if (cs.backgroundColor === "rgba(0, 0, 0, 0)" && cs.backgroundImage === "none") {
              // Per sobre només hi pot haver capes buides (sense fons): el primer element opac ha de ser l'element.
              const stack = document.elementsFromPoint(r.left + r.width / 2, y);
              const idx = stack.findIndex((h) => h === el || el.contains(h));
              if (idx < 0) return false;
              return stack.slice(0, idx).every((h) => {
                const s = getComputedStyle(h);
                return s.backgroundColor === "rgba(0, 0, 0, 0)" && s.backgroundImage === "none";
              });
            }
          }
          return !!hit && (hit === el || el.contains(hit));
        });
      });
    }, sel);
  let bet = false;
  let checked = false;
  const deadline = Date.now() + 150_000;
  while (Date.now() < deadline && !checked) {
    const betBtn = page.getByTestId("bet-confirm");
    if ((await betBtn.isVisible().catch(() => false)) && (await betBtn.isEnabled().catch(() => false))) {
      if (practice) {
        // Pràctica: sense compte enrere a l'aposta (cap «14s» a la pantalla).
        const timers = await page.evaluate(() => (document.body.innerText.match(/\b\d{1,2}\s?s\b/g) ?? []));
        expect(timers, "sense compte enrere en pràctica").toEqual([]);
      }
      // Aposta mínima (100): el primer preset.
      await page.locator("[data-testid=action-dock] button").filter({ hasText: /^100$/ }).first().click({ timeout: 1_000 }).catch(() => {});
      await betBtn.click({ timeout: 2_000 }).catch(() => {});
      bet = true;
      continue;
    }
    const stand = page.getByTestId("action-stand");
    if (bet && (await stand.isVisible().catch(() => false)) && (await stand.isEnabled().catch(() => false))) {
      await page.waitForTimeout(500);
      const seats = await page.evaluate(() =>
        [...document.querySelectorAll("[data-seat-player], [data-testid=table-pot], [data-testid=game-seat-grid]")].map((el) => {
          const r = el.getBoundingClientRect();
          return `${el.getAttribute("data-testid") ?? "seat"} banker=${el.getAttribute("data-seat-banker")} ${Math.round(r.left)},${Math.round(r.top)} ${Math.round(r.width)}x${Math.round(r.height)}`;
        })
      );
      console.log(`[prov] ${JSON.stringify(seats)}`);
      const cardHits = await page.evaluate(() =>
        [...document.querySelectorAll("[data-testid=local-player-seat] .spanish-card-size-player")].map((el) => {
          const r = el.getBoundingClientRect();
          const hits = [r.top + 3, r.top + r.height / 2, r.bottom - 3].map((y) => {
            const h = document.elementFromPoint(r.left + r.width / 2, y);
            return h ? `${h.tagName}.${String(h.className).slice(0, 40)}${el.contains(h) ? "(in)" : ""}` : "none";
          });
          return `${Math.round(r.left)},${Math.round(r.top)} ${Math.round(r.width)}x${Math.round(r.height)} ${hits.join(" | ")}`;
        })
      );
      console.log(`[prov] cards ${JSON.stringify(cardHits)}`);
      // He apostat, per tant la banca és el rival: ha de ser a la taula, igual que el pot i les meves cartes.
      expect(await visibleIn("[data-seat-banker=true]"), "banca visible").toBe(true);
      expect(await visibleIn("[data-seat-player]"), "rival visible").toBe(true);
      expect(await visibleIn("[data-testid=local-player-seat] .spanish-card-size-player"), "cartes pròpies visibles").toBe(true);
      expect(await visibleIn("[data-testid=table-pot]"), "pot visible").toBe(true);
      checked = true;
      break;
    }
    // Si em toca fer de banca, segueixo fins a una mà on aposto.
    const next = page.getByTestId("settlement-next-hand");
    if ((await next.isVisible().catch(() => false)) && (await next.isEnabled().catch(() => false))) {
      await next.click({ timeout: 2_000 }).catch(() => {});
      continue;
    }
    if (!bet && (await stand.isVisible().catch(() => false)) && (await stand.isEnabled().catch(() => false))) {
      await stand.click({ timeout: 2_000 }).catch(() => {});
      continue;
    }
    await page.waitForTimeout(150);
  }
  expect(bet, "aposta feta").toBe(true);
  expect(checked, "taula comprovada al meu torn").toBe(true);
});
}

for (const vp of MOBILE) {
  test(`P0 mòbil · sense graella buida (${vp.tag})`, async ({ page }) => {
    await page.setViewportSize({ width: vp.width, height: vp.height });
    await seed(page, e2ePoolId());
    await startGame(page, 3);
    await expect(page.getByTestId("local-player-seat").or(page.getByTestId("bet-confirm")).first()).toBeVisible({ timeout: 60_000 });
    await expect(page.locator("[data-testid=game-seat-grid]")).toHaveCount(0);
    // Cap element de la taula amb la reserva min-h 36vh (graella) entre la mesa i la mà.
    const reserved = await page.evaluate(() =>
      [...document.querySelectorAll(".game-seat-grid, .game-seat-ring")].map((el) => Math.round(el.getBoundingClientRect().height))
    );
    expect(reserved, "cap graella que reservi alçada").toEqual([]);
    // Arriba al torn i comprova que Plantar/Demanar són visibles i que la mà està a sobre del dock.
    const deadline = Date.now() + 120_000;
    let measured = false;
    while (Date.now() < deadline && !measured) {
      const betBtn = page.getByTestId("bet-confirm");
      if ((await betBtn.isVisible().catch(() => false)) && (await betBtn.isEnabled().catch(() => false))) {
        await betBtn.click({ timeout: 2_000 }).catch(() => {});
        continue;
      }
      const stand = page.getByTestId("action-stand");
      if ((await stand.isVisible().catch(() => false)) && (await stand.isEnabled().catch(() => false))) {
        await page.waitForTimeout(450);
        const gap = await page.evaluate(() => {
          const mesa = document.querySelector(".table-band-mesa")?.getBoundingClientRect();
          const hand = document.querySelector("[data-testid=local-hand-fan-slot]")?.getBoundingClientRect();
          return mesa && hand ? { mesaBottom: Math.round(mesa.bottom), handTop: Math.round(hand.top) } : null;
        });
        console.log(`[${vp.tag}] mesa→mà ${JSON.stringify(gap)}`);
        await expect(page.locator("[data-testid=game-seat-grid]")).toHaveCount(0);
        measured = true;
        await stand.click({ timeout: 2_000 }).catch(() => {});
        break;
      }
      await page.waitForTimeout(150);
    }
    expect(measured, "torn mesurat").toBe(true);
  });
}

// #192 (S1, a main): després de «Sortir» confirmat el lobby ja no ofereix «Continuar la partida» (ho comprova s1-sortir-continuar),
// així que aquest cas del #205 ja no es pot donar; es deixa com a referència.
test.skip("P1 · «Continuar la partida» en solo en línia emet join_solo_room i torna a la taula", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await seed(page, e2ePoolId());
  const sent: string[] = [];
  page.on("websocket", (ws) => {
    ws.on("framesent", (f) => {
      const payload = typeof f.payload === "string" ? f.payload : f.payload.toString();
      if (payload.includes("join_solo_room")) sent.push(payload);
    });
  });
  await startGame(page, 1);
  await expect(page.getByTestId("bet-confirm").or(page.getByTestId("action-stand")).or(page.getByTestId("status-pill")).first()).toBeVisible({ timeout: 60_000 });
  const joinsBefore = sent.length;
  expect(joinsBefore, "la partida s'ha creat amb join_solo_room").toBeGreaterThanOrEqual(1);

  const leave = page.getByRole("button", { name: "Sortir de la partida" });
  await leave.click();
  await page.getByRole("button", { name: "Confirmar sortida de la partida" }).click();
  const resume = page.getByTestId("resume-game-button");
  await expect(resume).toBeVisible({ timeout: 20_000 });
  await resume.click();
  await expect.poll(() => sent.length, { timeout: 10_000 }).toBeGreaterThan(joinsBefore);
  await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 60_000 });
});
