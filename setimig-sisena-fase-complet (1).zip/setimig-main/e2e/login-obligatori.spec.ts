/**
 * Login obligatori: sense sessió no hi ha lobby/FAQ/regles; /privacy i /terms queden oberts;
 * després del login es torna a ?next=.
 */
import { openLoginEmail, blockSocketIoCtx, mockLoginSession } from "./helpers/loginSession.ts";
import { expect, test, type Browser, type BrowserContext, type Page, type Route } from "@playwright/test";

const PID = "loginobl-player-01";
const TOKEN = "loginobl.token";
const AGE_OK = () => JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" });

function success(method: string) {
  return { playerId: PID, playerToken: TOKEN, method, created: false, linked: true, switchedAccount: false };
}

async function mockAuth(ctx: BrowserContext) {
  await ctx.route(/\/api\/(auth|player-session|account|profile|balance)/, async (route: Route) => {
    const req = route.request();
    const url = new URL(req.url());
    const key = `${req.method()} ${url.pathname}`;
    const defaults: Record<string, { status?: number; json: unknown }> = {
      "GET /api/auth/providers": { json: { email: true, google: true, passkey: true, rpId: "sevenhalf.club" } },
      "POST /api/auth/email/start": { status: 202, json: { ok: true, expiresInSec: 600 } },
      "POST /api/auth/email/verify": { json: success("email") },
      "GET /api/auth/me": { json: { playerId: PID, emails: ["edu@example.com"], google: false, passkeys: 0, verified: true } },
      "POST /api/player-session": { json: { playerId: PID, playerToken: TOKEN } },
      "GET /api/balance": { json: { chips: 1000, freeClaim: { available: false, nextAt: null } } },
    };
    // Com el servidor real: sense Bearer ni galeta, /api/player-session dona 401 (v200 hi prova a l'arrencada).
    if (key === "POST /api/player-session" && !req.headers()["authorization"]) {
      return route.fulfill({ status: 401, json: { error: "auth_required" } });
    }
    if (url.pathname.startsWith("/api/profile") && !defaults[key]) return route.fallback();
    const r = defaults[key];
    if (!r) return route.fulfill({ status: 404, json: { error: "no", code: "NOT_FOUND" } });
    await route.fulfill({ status: r.status ?? 200, json: r.json });
  });
}

async function newCtx(browser: Browser, opts: { session?: boolean; introSeen?: boolean } = {}) {
  const ctx = await browser.newContext({
    viewport: { width: 390, height: 844 },
    locale: "en-US",
    colorScheme: "dark",
  });
  await ctx.addInitScript(
    ({ session, introSeen, age, pid, token }) => {
      if (sessionStorage.getItem("loginobl_seeded") === "1") return;
      sessionStorage.setItem("loginobl_seeded", "1");
      localStorage.setItem("setimig.locale", "en");
      localStorage.setItem("setimig_age_gate", age);
      if (introSeen) localStorage.setItem("setimig_home_intro_v1", "1");
      if (session) {
        localStorage.setItem("setimig_player_id", pid);
        localStorage.setItem("setimig_player_token", token);
        localStorage.setItem("setimig_player_name", "Edu");
        localStorage.setItem("setimig_onboarding_v1", "1");
        localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      }
    },
    {
      session: !!opts.session,
      introSeen: opts.introSeen !== false,
      age: AGE_OK(),
      pid: PID,
      token: TOKEN,
    }
  );
  // Login obligatori (#263): el token sembrat no és d'un compte real; la resta de /api/* i el socket se simulen.
  if (opts.session) {
    await mockLoginSession(ctx, PID, TOKEN);
    await blockSocketIoCtx(ctx);
  }
  await mockAuth(ctx);
  return ctx;
}

test("anònim · /lobby → /login?next=/lobby", async ({ browser }) => {
  const ctx = await newCtx(browser);
  const page = await ctx.newPage();
  await page.goto("/lobby");
  await page.waitForURL((u) => u.pathname === "/login");
  expect(page.url()).toContain("next=");
  expect(new URL(page.url()).searchParams.get("next")).toBe("/lobby");
  await expect(page.getByTestId("login-page")).toBeVisible();
  await ctx.close();
});

test("anònim · / (intro ja vista) → /login", async ({ browser }) => {
  const ctx = await newCtx(browser, { introSeen: true });
  const page = await ctx.newPage();
  await page.goto("/");
  await page.waitForURL((u) => u.pathname === "/login", { timeout: 15_000 });
  await expect(page.getByTestId("login-page")).toBeVisible();
  await ctx.close();
});

test("anònim · FAQ /com-jugar → /login?next=…", async ({ browser }) => {
  const ctx = await newCtx(browser);
  const page = await ctx.newPage();
  await page.goto("/com-jugar");
  await page.waitForURL((u) => u.pathname === "/login");
  expect(new URL(page.url()).searchParams.get("next")).toBe("/com-jugar");
  await ctx.close();
});

test("anònim · /regles → /login?next=…", async ({ browser }) => {
  const ctx = await newCtx(browser);
  const page = await ctx.newPage();
  await page.goto("/regles");
  await page.waitForURL((u) => u.pathname === "/login");
  expect(new URL(page.url()).searchParams.get("next")).toMatch(/^\/regles/);
  await ctx.close();
});

test("públic · /privacy i /terms sense sessió", async ({ browser }) => {
  const ctx = await newCtx(browser);
  const page = await ctx.newPage();
  const privacy = await page.goto("/privacy");
  expect(privacy?.ok()).toBeTruthy();
  expect(page.url()).toContain("/privacy");
  await expect(page.locator("body")).toContainText(/privacy|privadesa|privacidad/i);
  const terms = await page.goto("/terms");
  expect(terms?.ok()).toBeTruthy();
  expect(page.url()).toContain("/terms");
  await expect(page.locator("body")).toContainText(/terms|condicions|condiciones|service/i);
  await ctx.close();
});

test("login · ?next= torna al destí després d'entrar", async ({ browser }) => {
  const ctx = await newCtx(browser);
  const page = await ctx.newPage();
  await page.goto("/login?next=%2Ft%2FABC123");
  await expect(page.getByTestId("login-page")).toBeVisible();
  await openLoginEmail(page);
  await page.getByTestId("login-email-input").fill("edu@example.com");
  await page.getByTestId("login-email-submit").click();
  await page.getByTestId("login-code-input").fill("123456");
  await page.getByTestId("login-code-submit").click();
  await page.waitForURL((u) => u.pathname === "/t/ABC123", { timeout: 15_000 });
  expect(await page.evaluate(() => localStorage.getItem("setimig_player_token"))).toBe(TOKEN);
  await ctx.close();
});

test("amb sessió · / obre el lobby (no redirigeix a login)", async ({ browser }) => {
  const ctx = await newCtx(browser, { session: true });
  const page = await ctx.newPage();
  await page.goto("/");
  await expect(page.getByTestId("login-page")).toHaveCount(0);
  // Capçalera del lobby / perfil
  await expect(page.locator("button.header-profile").first()).toBeVisible({ timeout: 30_000 });
  await ctx.close();
});

test("login · enllaços privacy/terms visibles", async ({ browser }) => {
  const ctx = await newCtx(browser);
  const page = await ctx.newPage();
  await page.goto("/login");
  await expect(page.getByTestId("login-link-privacy")).toBeVisible();
  await expect(page.getByTestId("login-link-terms")).toBeVisible();
  await ctx.close();
});

test("401 auth_required · neteja sessió i va a /login?next=", async ({ browser }) => {
  const ctx = await newCtx(browser, { session: true });
  await ctx.route("**/api/balance**", async (route) => {
    await route.fulfill({ status: 401, json: { error: "auth_required" } });
  });
  const page = await ctx.newPage();
  await page.goto("/t/DEEPLINK");
  await page.waitForURL((u) => u.pathname === "/login", { timeout: 20_000 });
  expect(new URL(page.url()).searchParams.get("next")).toBe("/t/DEEPLINK");
  const ls = await page.evaluate(() => ({
    id: localStorage.getItem("setimig_player_id"),
    token: localStorage.getItem("setimig_player_token"),
  }));
  expect(ls).toEqual({ id: null, token: null });
  await ctx.close();
});
