import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * v188: revelació EN GRAN al centre, un jugador rere l'altre (rivals → jo → banca),
 * després el plafó; toc omet; reduced motion escurça; compte enrere després.
 */
const SEED = process.env.SETIMIG_TEST_DECK_SEED;
const OUT = process.env.REVELA_OUT ?? "/workspace/setimig/v188_revelacio";
const BOTS = Number(process.env.REVELA_BOTS ?? "1");

async function startSolo(page: Page, bots: number, flagParam?: string) {
  await seedE2eSession(page, e2ePoolId());
  await page.addInitScript(() => {
    if (sessionStorage.getItem("qa_llavor") === "1") return;
    sessionStorage.setItem("qa_llavor", "1");
    for (const k of [
      "setimig_onboarding_v1",
      "setimig_interactive_tutorial_v1",
      "setimig_table_tutorial_v1",
      "setimig_house_rules_enabled",
    ])
      localStorage.setItem(k, "1");
    localStorage.setItem("setimig.locale", "ca");
    localStorage.setItem("setimig_player_name", "Test Llavor");
    localStorage.setItem(
      "setimig_age_gate",
      JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }),
    );
    sessionStorage.setItem("setimig_intro_launch_v1", "1");
  });
  await page.goto(flagParam ? `/?flag=${encodeURIComponent(flagParam)}` : "/");
  const skip = page.getByTestId("interactive-tutorial-skip");
  await expect(page.getByTestId("lobby-context").or(skip).first()).toBeVisible({ timeout: 45_000 });
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  const botBtn = page.getByTestId(`ai-bot-count-${bots}`);
  await expect(botBtn).toBeVisible();
  await botBtn.click();
  const cb = page.getByTestId("house-rules-toggle").locator("input");
  if ((await cb.count()) && !(await cb.isChecked())) await cb.check({ force: true });
  await page.getByTestId("ai-bot-picker-start").click();
}

const confirmBet = (page: Page) =>
  page.getByTestId("bet-confirm").filter({ visible: true }).first().click({ timeout: 30_000 });

async function swipe(page: Page) {
  const grab = page.getByTestId("peek-curl-grab").filter({ visible: true }).first();
  await expect(grab).toBeVisible({ timeout: 30_000 });
  const b = (await grab.boundingBox())!;
  const x = b.x + b.width / 2,
    y0 = b.y + b.height * 0.95,
    y1 = b.y + b.height * 0.3;
  await page.mouse.move(x, y0);
  await page.mouse.down();
  for (let i = 1; i <= 8; i++) {
    await page.mouse.move(x, y0 + ((y1 - y0) * i) / 8);
    await page.waitForTimeout(40);
  }
  await page.mouse.up();
}

async function playToReveal(page: Page, mode: "normal" | "mort") {
  await confirmBet(page);
  if (mode === "mort") {
    for (let i = 0; i < 40; i++) {
      const accept = page.getByTestId("mort-accept").filter({ visible: true }).first();
      if (await accept.isVisible().catch(() => false)) {
        await accept.click();
        break;
      }
      const stand = page.getByTestId("action-stand").filter({ visible: true }).first();
      if (await stand.isVisible().catch(() => false)) break;
      await page.waitForTimeout(250);
    }
  } else {
    await swipe(page).catch(() => {});
  }
  const reveal = page.getByTestId("settlement-table-reveal");
  const big = page.getByTestId("settlement-big-reveal");
  const mort = page.getByTestId("mort-reveal");
  const sheet = page.getByTestId("settlement-sheet");
  for (let i = 0; i < 220; i++) {
    if (await reveal.isVisible().catch(() => false)) return;
    if (await big.isVisible().catch(() => false)) return;
    if (await mort.isVisible().catch(() => false)) return;
    if (await sheet.isVisible().catch(() => false)) return;
    const st = page.getByTestId("action-stand").filter({ visible: true }).first();
    if (await st.isVisible({ timeout: 200 }).catch(() => false)) {
      await st.click({ timeout: 2_000 }).catch(() => {});
    }
    const decline = page.getByTestId("swap-decline").filter({ visible: true }).first();
    if (await decline.isVisible().catch(() => false)) await decline.click().catch(() => {});
    await page.waitForTimeout(300);
  }
  throw new Error("no ha arribat a la revelació/liquidació");
}

async function assertSequenceThenSheet(page: Page, label: string, expectPlayers: number) {
  const sheet = page.getByTestId("settlement-sheet");
  const auto = page.getByTestId("settlement-auto-next-hand");
  const revealRoot = page.getByTestId("settlement-table-reveal");

  await expect(revealRoot.or(page.getByTestId("settlement-big-reveal")).or(page.getByTestId("mort-reveal")).first()).toBeVisible({
    timeout: 90_000,
  });
  await expect(sheet).toBeHidden();
  await expect(auto).toHaveCount(0);

  await page.evaluate(() => {
    const w = window as unknown as {
      __revealStarts: Array<{ id: string; faceUp: string }>;
      __revealLastId: string | null;
      __revealObserver: MutationObserver;
    };
    const current = document.querySelector<HTMLElement>("[data-testid=settlement-big-reveal]");
    w.__revealStarts = [];
    w.__revealLastId = current?.dataset.revealPlayer ?? null;
    const sample = () => {
      const el = document.querySelector<HTMLElement>("[data-testid=settlement-big-reveal]");
      const id = el?.dataset.revealPlayer;
      if (!el || !id || id === w.__revealLastId) return;
      w.__revealLastId = id;
      w.__revealStarts.push({ id, faceUp: el.dataset.revealFaceUp ?? "" });
    };
    w.__revealObserver = new MutationObserver(sample);
    w.__revealObserver.observe(document.body, { subtree: true, childList: true, attributes: true, attributeFilter: ["data-reveal-player"] });
  });

  const seen = new Set<string>();
  const deadline = Date.now() + 60_000;
  while (Date.now() < deadline && !(await sheet.isVisible().catch(() => false))) {
    const big = page.getByTestId("settlement-big-reveal");
    if (await big.isVisible().catch(() => false)) {
      const id = await big.getAttribute("data-reveal-player");
      if (id) seen.add(id);
      // Etiqueta de focus / les meves cartes
      await expect(page.getByTestId("focus-turn-label").or(big).first()).toBeVisible();
    }
    const mort = page.getByTestId("mort-reveal");
    if (await mort.isVisible().catch(() => false)) seen.add("mort");
    await page.waitForTimeout(200);
  }

  await expect(sheet).toBeVisible({ timeout: 30_000 });
  await expect(page.getByTestId("settlement-big-reveal")).toHaveCount(0);
  await expect(revealRoot).toHaveCount(0);
  if (await auto.isVisible().catch(() => false)) {
    expect(((await auto.textContent()) ?? "").length).toBeGreaterThan(0);
  }
  expect(seen.size, `cal veure diversos passos de revelació (${label})`).toBeGreaterThanOrEqual(Math.min(2, expectPlayers));
  const starts = await page.evaluate(() => {
    const w = window as unknown as { __revealStarts: Array<{ id: string; faceUp: string }>; __revealObserver: MutationObserver };
    w.__revealObserver.disconnect();
    return w.__revealStarts;
  });
  expect(starts.length, `s'han observat passos nous de revelació (${label})`).toBeGreaterThan(0);
  for (const step of starts) expect(step.faceUp, `la mà ${step.id} comença tapada`).toBe("no");
  await page.screenshot({ path: `${OUT}/${label}.png` }).catch(() => {});
}

const SIZES = [
  { name: "390", width: 390, height: 844 },
  { name: "1280", width: 1280, height: 720 },
] as const;

for (const size of SIZES) {
  test.describe(`v188 revelació gran @${size.name}`, () => {
    test.use({ viewport: { width: size.width, height: size.height } });

    test(`3 rivals · seqüència al centre · llavor ${SEED ?? "rand"}`, async ({ page }) => {
      test.skip(SEED === "4", "Mort es prova a part");
      await startSolo(page, 3);
      await playToReveal(page, "normal");
      await assertSequenceThenSheet(page, `${size.name}-3rivals`, 4);
    });

    test(`Mort · llavor 4`, async ({ page }) => {
      test.skip(SEED !== "4", "cal SETIMIG_TEST_DECK_SEED=4");
      await startSolo(page, 1);
      await playToReveal(page, "mort");
      await assertSequenceThenSheet(page, `${size.name}-mort`, 2);
    });

    test(`toc omet la revelació`, async ({ page }) => {
      test.skip(SEED === "4", "skip en Mort separat");
      await startSolo(page, 3);
      await playToReveal(page, "normal");
      await expect(page.getByTestId("settlement-table-reveal")).toBeVisible({ timeout: 90_000 });
      await expect(page.getByTestId("settlement-sheet")).toBeHidden();
      const skip = page.getByTestId("settlement-reveal-skip");
      await expect(skip).toBeVisible({ timeout: 5_000 });
      await skip.click({ force: true });
      await expect(page.getByTestId("settlement-sheet")).toBeVisible({ timeout: 5_000 });
      await expect(page.getByTestId("settlement-big-reveal")).toHaveCount(0);
    });

    if (size.name === "390") {
      test("amb les animacions de fitxes apagades, la liquidació espera el final de la revelació", async ({ page }) => {
        test.skip(SEED === "4", "Mort es prova a part");
        await startSolo(page, 1, "none");
        await playToReveal(page, "normal");
        await expect(page.getByTestId("settlement-table-reveal")).toBeVisible({ timeout: 90_000 });
        await expect(page.getByTestId("settlement-big-reveal")).toBeVisible();
        await expect(page.getByTestId("fx-result-badge")).toHaveCount(0);
        await expect(page.locator("[data-fx-hand]")).toHaveCount(0);
        await expect(page.getByTestId("settlement-table-reveal")).toHaveCount(0, { timeout: 30_000 });
        await expect(page.getByTestId("fx-result-badge").first()).toBeAttached({ timeout: 10_000 });
      });
    }

    test(`reduced motion escurça`, async ({ page }) => {
      test.skip(SEED === "4", "reduced sense Mort");
      await page.emulateMedia({ reducedMotion: "reduce" });
      await startSolo(page, 1);
      const t0 = Date.now();
      await playToReveal(page, "normal");
      await expect(page.getByTestId("settlement-sheet")).toBeVisible({ timeout: 30_000 });
      const elapsed = Date.now() - t0;
      // Amb reduced, la revelació és curta; no cal un límit estricte del camí fins a liquidació
      // (bots + apostes), però el plafó no ha d'esperar 1,5 s × N.
      expect(elapsed).toBeLessThan(120_000);
      await page.screenshot({ path: `${OUT}/${size.name}-reduced.png` }).catch(() => {});
    });
  });
}
