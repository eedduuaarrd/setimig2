import { expect, test } from "@playwright/test";
import { seedAgeGateFresh } from "./helpers/uxA11yFixtures";

test("keyboard focus stays within the unaccepted age gate", async ({ page }) => {
  await seedAgeGateFresh(page, "KeyboardTest");
  await page.goto("/");

  const gate = page.getByTestId("age-gate");
  const name = page.getByTestId("age-gate-name");
  await expect(gate).toBeVisible();
  await expect(name).toBeFocused();

  for (let i = 0; i < 10; i++) {
    await page.keyboard.press("Tab");
    expect(await gate.evaluate((element) => element.contains(document.activeElement))).toBeTruthy();
  }

  for (let i = 0; i < 10; i++) {
    await page.keyboard.press("Shift+Tab");
    expect(await gate.evaluate((element) => element.contains(document.activeElement))).toBeTruthy();
  }

  await expect(gate).toBeVisible();
  await expect(page.getByTestId("age-gate-accept")).toBeVisible();
  expect(await page.evaluate(() => localStorage.getItem("setimig_age_gate"))).toBeNull();
});
