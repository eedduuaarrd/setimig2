import { expect, test, type Browser, type Page } from "@playwright/test";
import { threePlayerTurnSnapshot } from "./helpers/jugabilitatV1Fixtures.ts";
import { passAgeGateToLobby } from "./helpers/ageGateLobby.ts";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";
import { confirmBetIfShown } from "./helpers/tableFlow.ts";
import fs from "node:fs";
import path from "node:path";

/**
 * Focus del torn: qui té el torn (jo, un bot o la banca) és GRAN al centre (ventall, puntuació, barra);
 * la resta, petits a la fila de dalt. El meu torn: STAND/HIT. El torn d'un altre: cap botó, només «X is playing».
 * Transició ~400 ms (transform/opacity); amb moviment reduït, sense moviment. CLS < 0,1. Sense desbordament.
 * Captures opcionals: SETIMIG_FOCUS_SHOTS=<carpeta> desa focus-<mida>-3torns.png (3 torns seguits).
 */
const AGE_OK = () => JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" });
const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844, desktop: false },
  { tag: "1280x800", width: 1280, height: 800, desktop: true },
] as const;
const ME = (pid: string) => pid;

async function openLocal(browser: Browser, vp: { width: number; height: number; desktop: boolean }, reduce = false) {
  const ctx = await browser.newContext({
    viewport: { width: vp.width, height: vp.height },
    deviceScaleFactor: vp.desktop ? 1 : 2,
    locale: "en-US",
    colorScheme: "dark",
    reducedMotion: reduce ? "reduce" : "no-preference",
  });
  const page = await ctx.newPage();
  const pid = e2ePoolId();
  await seedE2eSession(page, pid);
  await page.addInitScript(
    ({ snap, pid, age }) => {
      if (sessionStorage.getItem("focus_seeded") === "1") return;
      sessionStorage.setItem("focus_seeded", "1");
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", "Edu");
      localStorage.setItem("setimig.locale", "en");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_house_rules_enabled", "1");
      localStorage.setItem("setimig_age_gate", age);
      localStorage.setItem("setimig_local_solo_snapshot", snap);
      sessionStorage.setItem("setimig_solo_rejoin", "1");
      sessionStorage.setItem("setimig_solo_local", "1");
    },
    { snap: threePlayerTurnSnapshot(pid, "Edu"), pid, age: AGE_OK() }
  );
  await page.addInitScript(() => {
    (window as unknown as { __cls: number }).__cls = 0;
    new PerformanceObserver((list) => {
      for (const e of list.getEntries() as unknown as { value: number; hadRecentInput: boolean }[]) {
        if (e.hadRecentInput) continue;
        const w = window as unknown as { __cls: number; __clsLog?: string[] };
        w.__cls += e.value;
        const src = (e as unknown as { sources?: { node?: Element }[] }).sources?.[0]?.node;
        (w.__clsLog ??= []).push(`${e.value.toFixed(3)}:${(src as HTMLElement | undefined)?.className?.toString().slice(0, 50) ?? src?.nodeName ?? "?"}@${Math.round(performance.now())}`);
      }
    }).observe({ type: "layout-shift", buffered: true });
  });
  await page.route("**/socket.io/**", (route) => route.abort());
  await page.goto("/");
  await expect(page.getByTestId("action-hit")).toBeEnabled({ timeout: 30_000 });
  await page.waitForTimeout(700);
  return { ctx, page, pid };
}

/** Selector de «qui és gran al centre» quan no és el meu torn. */
function stageFor(page: Page, desktop: boolean, id: string) {
  return desktop
    ? page.locator(`[data-testid="active-turn-hand"][data-active-player="${id}"]`)
    : page.locator(`[data-testid="focus-stage"][data-focus-player="${id}"]`);
}

async function noOverflow(page: Page) {
  const o = await page.evaluate(() => ({
    sw: document.documentElement.scrollWidth,
    w: window.innerWidth,
    out: [...document.querySelectorAll<HTMLElement>("[data-testid='focus-turn-label'], [data-seat-self='true'], [data-testid='desktop-self-seat']")]
      .map((el) => el.getBoundingClientRect())
      .filter((r) => r.width > 0 && (r.left < -1 || r.right > window.innerWidth + 1)).length,
  }));
  expect(o.sw, "sense desbordament horitzontal").toBeLessThanOrEqual(o.w + 1);
  expect(o.out).toBe(0);
}

async function assertOtherTurn(page: Page, desktop: boolean, id: string, nameRe: RegExp) {
  const stage = stageFor(page, desktop, id);
  await expect(stage).toBeVisible();
  // Quan juga un altre, STAND i HIT queden muntats però desactivats (anim 14-18: tremolor
  // de denegació en tocar-los); no es poden prémer ni rebre focus.
  for (const id of ["action-hit", "action-stand"]) {
    const b = page.getByTestId(id);
    if ((await b.count()) === 0) continue;
    await expect(b).toBeDisabled();
    expect(await b.evaluate((el) => { (el as HTMLElement).focus(); return document.activeElement === el; }), `${id} sense focus`).toBe(false);
  }
  const label = stage.getByTestId("focus-turn-label");
  await expect(label).toBeVisible();
  await expect(label).toHaveText(nameRe);
  // Jo, en petit a la fila de dalt (al lloc de qui juga); la meva mà gran queda amagada.
  if (desktop) {
    await expect(page.getByTestId("desktop-self-seat")).toBeVisible();
    // El seient de qui juga queda invisible a la fila (només en guarda el lloc).
    await expect(page.locator(`[data-testid="desktop-rival-row"] [data-seat-player="${id}"]`)).toBeHidden();
  } else {
    await expect(page.locator("[data-testid='v2-seat-row'] [data-seat-self='true']")).toBeVisible();
    await expect(page.locator(`[data-testid='v2-seat-row'] [data-seat-player="${id}"]`)).toHaveCount(0);
    await expect(page.getByTestId("local-player-seat")).toHaveAttribute("data-focus", "away");
    // Gran vs petit: les cartes del centre són molt més grans que les de la fila.
    const sizes = await page.evaluate(() => {
      const big = document.querySelector<HTMLElement>("[data-testid='focus-hand-card']")?.getBoundingClientRect().width ?? 0;
      const small = document.querySelector<HTMLElement>("[data-testid='v2-seat-row'] .v2-seat-card")?.getBoundingClientRect().width ?? 0;
      return { big, small };
    });
    expect(sizes.big).toBeGreaterThan(sizes.small * 2);
    // La puntuació i la barra (reservada) del focus hi són, sense duplicar testids de la meva mà.
    await expect(stage.getByTestId("focus-hand-points")).toBeVisible();
  }
  await noOverflow(page);
}

async function assertMyTurn(page: Page, desktop: boolean) {
  await expect(page.getByTestId("action-hit")).toBeVisible();
  await expect(page.getByTestId("action-stand")).toBeVisible();
  await expect(page.getByTestId("focus-turn-label")).toHaveCount(0);
  if (!desktop) {
    await expect(page.getByTestId("focus-stage")).toHaveCount(0);
    await expect(page.getByTestId("local-player-seat")).toHaveAttribute("data-focus", "mine");
    await expect(page.locator("[data-seat-self='true']")).toHaveCount(0);
  }
  for (const id of ["action-hit", "action-stand"]) {
    const b = await page.getByTestId(id).boundingBox();
    expect(b!.height).toBeGreaterThanOrEqual(44);
  }
  await noOverflow(page);
}

async function combine(page: Page, shots: Buffer[], out: string) {
  const ctx = await page.context().browser()!.newContext({ viewport: { width: 400, height: 400 } });
  const p = await ctx.newPage();
  const imgs = shots.map((b) => `<img src="data:image/png;base64,${b.toString("base64")}">`).join("");
  await p.setContent(
    `<html><body style="margin:0;background:#050505;display:flex;gap:16px;padding:16px;width:max-content">${imgs}</body></html>`
  );
  await p.locator("body").screenshot({ path: out });
  await ctx.close();
}

for (const vp of VIEWPORTS) {
  test(`focus del torn · ${vp.tag} · 3 torns seguits (jo → Pau → banca), gran al centre i petits a la fila`, async ({ browser }) => {
    const { ctx, page, pid } = await openLocal(browser, vp);
    const shots: Buffer[] = [];
    const shot = async () => shots.push(await page.screenshot());

    // Torn 1: el meu. STAND/HIT, la meva mà gran, sense etiqueta.
    await assertMyTurn(page, vp.desktop);
    expect(ME(pid)).toBeTruthy();
    await shot();
    await page.getByTestId("action-stand").click();

    // Torn 2: Pau (bot) gran al centre, jo petit a la fila.
    await expect(stageFor(page, vp.desktop, "bot-jug-p")).toBeVisible({ timeout: 20_000 });
    await page.waitForTimeout(450);
    if (await stageFor(page, vp.desktop, "bot-jug-p").count()) {
      await assertOtherTurn(page, vp.desktop, "bot-jug-p", /Pau's cards · playing now/);
      await shot();
    }

    // Torn 3: la banca (Laia) gran al centre.
    await expect(stageFor(page, vp.desktop, "bot-jug-bank")).toBeVisible({ timeout: 30_000 });
    await page.waitForTimeout(450);
    if (await stageFor(page, vp.desktop, "bot-jug-bank").count()) {
      await assertOtherTurn(page, vp.desktop, "bot-jug-bank", /Laia's cards · playing now/);
      await shot();
    }

    const { cls, log } = await page.evaluate(() => {
      const w = window as unknown as { __cls: number; __clsLog?: string[] };
      return { cls: w.__cls, log: (w.__clsLog ?? []).slice(-8).join(" | ") };
    });
    console.log(`[focus ${vp.tag}] CLS ${cls.toFixed(3)} ${log}`);
    expect(cls, `CLS ${cls.toFixed(3)} ${log}`).toBeLessThan(0.1);
    expect(shots.length).toBe(3);
    const dir = process.env.SETIMIG_FOCUS_SHOTS;
    if (dir) {
      fs.mkdirSync(dir, { recursive: true });
      await combine(page, shots, path.join(dir, `focus-${vp.tag}-3torns.png`));
    }
    await ctx.close();
  });
}

test("focus del torn · 390 · moviment reduït: sense moviment (ni transició ni animació)", async ({ browser }) => {
  const { ctx, page } = await openLocal(browser, VIEWPORTS[0], true);
  await page.getByTestId("action-stand").click();
  const stage = stageFor(page, false, "bot-jug-p");
  await expect(stage).toBeVisible({ timeout: 20_000 });
  const m = await page.evaluate(() => {
    const st = document.querySelector<HTMLElement>("[data-testid='focus-stage']")!;
    const mine = document.querySelector<HTMLElement>("[data-testid='focus-mine']")!;
    const self = document.querySelector<HTMLElement>("[data-seat-self='true']")!;
    return {
      stageAnim: getComputedStyle(st).animationName,
      mineTransform: getComputedStyle(mine).transform,
      mineAnim: getComputedStyle(mine).animationName,
      mineTransition: getComputedStyle(mine).transitionDuration,
      selfAnim: getComputedStyle(self).animationName,
    };
  });
  expect(m.stageAnim).toBe("none");
  expect(m.selfAnim).toBe("none");
  // v157: la meva mà queda petita sota l'escenari (pose estàtica), sense transició.
  expect(m.mineTransform).toMatch(/^matrix\(0\.5, 0, 0, 0\.5, 0, [\d.]+\)$/);
  // Sense moviment: com a molt un canvi d'opacitat curt (≤ 200 ms).
  expect(m.mineAnim).toBe("none");
  expect(
    m.mineTransition.split(",").every((d) => (d.trim().endsWith("ms") ? parseFloat(d) : parseFloat(d) * 1000) <= 200),
    m.mineTransition
  ).toBe(true);
  await ctx.close();
});

test("focus del torn · 390 · amb moviment: ~400 ms, només transform/opacity", async ({ browser }) => {
  const { ctx, page } = await openLocal(browser, VIEWPORTS[0]);
  await page.getByTestId("action-stand").click();
  await expect(stageFor(page, false, "bot-jug-p")).toBeVisible({ timeout: 20_000 });
  const m = await page.evaluate(() => {
    const st = document.querySelector<HTMLElement>("[data-testid='focus-stage']")!;
    const mine = document.querySelector<HTMLElement>("[data-testid='focus-mine']")!;
    const kf = [...document.styleSheets].flatMap((s) => {
      try {
        return [...s.cssRules];
      } catch {
        return [];
      }
    }).filter((r) => r instanceof CSSKeyframesRule && /^focus-/.test((r as CSSKeyframesRule).name)) as CSSKeyframesRule[];
    const props = new Set<string>();
    for (const k of kf) for (const f of [...k.cssRules] as CSSKeyframeRule[]) for (const p of [...f.style]) props.add(p);
    return {
      dur: getComputedStyle(st).animationDuration,
      ease: getComputedStyle(st).animationTimingFunction,
      mineProps: getComputedStyle(mine).transitionProperty,
      props: [...props],
    };
  });
  expect(m.dur).toBe("0.4s");
  expect(m.ease).toContain("cubic-bezier(0.33, 1, 0.68, 1)");
  expect(m.mineProps.split(",").map((s) => s.trim())).toEqual(["transform", "opacity"]);
  expect(m.props.every((p) => p === "opacity" || p === "transform")).toBe(true);
  await ctx.close();
});

for (const vp of VIEWPORTS) {
  test(`focus del torn · ${vp.tag} · taula privada amb 3 jugadors (servidor)`, async ({ browser }) => {
    const ctx = await browser.newContext({ viewport: { width: vp.width, height: vp.height }, locale: "en-US", colorScheme: "dark" });
    const page = await ctx.newPage();
    await page.addInitScript(() => {
      (window as unknown as { __cls: number }).__cls = 0;
      new PerformanceObserver((list) => {
        for (const e of list.getEntries() as unknown as { value: number; hadRecentInput: boolean }[]) {
          if (e.hadRecentInput) continue;
          // Privada: només la jugada (vestíbul, apostes i liquidació tenen les seves suites).
          if (!document.querySelector("[data-testid='action-hit'], [data-testid='focus-turn-label']")) continue;
        const w = window as unknown as { __cls: number; __clsLog?: string[] };
        w.__cls += e.value;
        const src = (e as unknown as { sources?: { node?: Element }[] }).sources?.[0]?.node;
        (w.__clsLog ??= []).push(`${e.value.toFixed(3)}:${(src as HTMLElement | undefined)?.className?.toString().slice(0, 50) ?? src?.nodeName ?? "?"}@${Math.round(performance.now())}`);
        }
      }).observe({ type: "layout-shift", buffered: true });
    });
    await passAgeGateToLobby(page, `Focus${Date.now() % 100000}`);
    await page.getByTestId("play-with-friends-button").click();
    await page.getByTestId("create-private-table-inline").click();
    await expect(page.getByTestId("private-waiting-panel")).toBeVisible({ timeout: 60_000 });
    await page.getByTestId("fill-private-bots").click();
    await page.getByTestId("start-game-button").click();

    let sawMine = false;
    let sawOther = false;
    let clsReset = false;
    // El CLS es mesura des de la primera jugada (el vestíbul i les apostes tenen les seves pròpies suites).
    const resetCls = async () => {
      if (clsReset) return;
      clsReset = true;
      await page.evaluate(() => {
        const w = window as unknown as { __cls: number; __clsLog?: string[] };
        w.__cls = 0;
        w.__clsLog = [];
      });
    };
    const deadline = Date.now() + 120_000;
    while (Date.now() < deadline && !(sawMine && sawOther)) {
      await confirmBetIfShown(page);
      const hit = page.getByTestId("action-hit");
      if ((await hit.isVisible().catch(() => false)) && (await hit.isEnabled().catch(() => false))) {
        await resetCls();
        await expect(page.getByTestId("focus-turn-label")).toHaveCount(0);
        sawMine = true;
        await page.getByTestId("action-stand").click().catch(() => {});
        await page.waitForTimeout(300);
        continue;
      }
      const label = page.getByTestId("focus-turn-label");
      if (await label.first().isVisible().catch(() => false)) {
        await resetCls();
        await expect(label.first()).toHaveText(/playing now|juga ara/);
        if (await page.getByTestId("action-hit").count()) await expect(page.getByTestId("action-hit")).toBeDisabled();
        if (vp.desktop) {
          await expect(page.getByTestId("desktop-self-seat")).toBeVisible();
          // Una sola etiqueta «… is playing» visible (la del centre); el panell d'espera del dock no la repeteix.
          // Carrera (flake a 1280): `isVisible()` de Playwright no mira l'opacitat, però `checkVisibility`
          // sí. Just quan apareix, la mà del torn (`.active-turn-hand.focus-stage-enter`) comença `focus-rise`
          // amb opacity 0 → 0 etiquetes. Esperem que acabin les animacions de l'etiqueta i dels seus ancestres abans de
          // comptar; si mentrestant el torn ha passat (etiqueta desmuntada), tornem a la volta següent.
          const visibleLabels = await page.evaluate(async () => {
            const lbl = document.querySelector<HTMLElement>("[data-testid='focus-turn-label']");
            if (!lbl) return -1;
            const anims: Animation[] = [];
            for (let el: Element | null = lbl; el; el = el.parentElement) anims.push(...el.getAnimations());
            await Promise.all(anims.filter((a) => (a.playState === "running" || a.pending) && Number.isFinite(Number(a.effect?.getComputedTiming().endTime))).map((a) => a.finished.catch(() => {})));
            if (!lbl.isConnected) return -1;
            return [...document.querySelectorAll<HTMLElement>("p, span")].filter(
              (el) =>
                /playing now|juga ara/.test(el.textContent ?? "") &&
                ![...el.children].some((c) => /playing now|juga ara/.test(c.textContent ?? "")) &&
                el.checkVisibility({ visibilityProperty: true, opacityProperty: true } as CheckVisibilityOptions)
            ).length;
          });
          if (visibleLabels === -1) {
            await page.waitForTimeout(250);
            continue;
          }
          expect(visibleLabels, "una sola etiqueta de qui juga a escriptori").toBe(1);
        } else await expect(page.locator("[data-seat-self='true']")).toBeVisible();
        await noOverflow(page);
        sawOther = true;
      }
      const next = page.getByTestId("settlement-next-hand");
      if (await next.isVisible().catch(() => false)) await next.click().catch(() => {});
      await page.waitForTimeout(250);
    }
    expect(sawMine, "he vist el meu torn").toBe(true);
    expect(sawOther, "he vist el torn d'un altre").toBe(true);
    const { cls, log } = await page.evaluate(() => {
      const w = window as unknown as { __cls: number; __clsLog?: string[] };
      return { cls: w.__cls, log: (w.__clsLog ?? []).slice(-8).join(" | ") };
    });
    expect(cls, `CLS ${cls.toFixed(3)} ${log}`).toBeLessThan(0.1);
    await ctx.close();
  });
}
