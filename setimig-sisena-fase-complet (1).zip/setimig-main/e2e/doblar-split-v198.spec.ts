import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * v198 · Regles de l'1/11 (doblar i split). Estat injectat (`__SETIMIG_TEST_PATCH_ME`) fins que el motor del Servidor hi sigui;
 * el client segueix canDouble / canSplit / canMort / swapOffer.
 */
test.use({ viewport: { width: 390, height: 844 } });

async function startSolo(page: Page) {
  await seedE2eSession(page, e2ePoolId());
  await page.addInitScript(() => {
    if (sessionStorage.getItem("qa_split") === "1") return;
    sessionStorage.setItem("qa_split", "1");
    for (const k of ["setimig_onboarding_v1", "setimig_interactive_tutorial_v1", "setimig_table_tutorial_v1", "setimig_house_rules_enabled"]) localStorage.setItem(k, "1");
    localStorage.setItem("setimig.locale", "ca");
    localStorage.setItem("setimig_player_name", "Test Split");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
    sessionStorage.setItem("setimig_intro_launch_v1", "1");
  });
  await page.goto("/");
  const skip = page.getByTestId("interactive-tutorial-skip");
  await expect(page.getByTestId("lobby-context").or(skip).first()).toBeVisible({ timeout: 45_000 });
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  if (await page.getByTestId("ai-bot-count-1").isVisible().catch(() => false)) await page.getByTestId("ai-bot-count-1").click();
  const cb = page.getByTestId("house-rules-toggle").locator("input");
  if (!(await cb.isChecked())) await cb.check({ force: true });
  await page.getByTestId("ai-bot-picker-start").click();
  await page.getByTestId("bet-confirm").filter({ visible: true }).first().click({ timeout: 30_000 });
  await expect(page.getByTestId("action-stand").filter({ visible: true }).first()).toBeVisible({ timeout: 30_000 });
}

const fig = (id: string, suit: string, value: number, faceUp = true) => ({ id, card: { suit, value, points: 0.5 }, faceUp });
const slot = (id: string, cards: unknown[], status = "playing") => ({
  id, bet: 100, cards, doubled: false, canDouble: false, mort: false, blindPair: false, blindUntilBankEnd: false, mortOffered: false, status,
});

async function patchMe(page: Page, patch: unknown) {
  await page.evaluate((p) => window.__SETIMIG_TEST_PATCH_ME?.(p as Record<string, unknown>), patch);
}


const num = (id: string, suit: string, value: number) => ({ id, card: { suit, value, points: value }, faceUp: true });
const dbl = (page: Page) => page.locator('[data-testid="mobile-double-chip"],[data-testid="action-double"]').filter({ visible: true });

test("Doblar: 1 carta sí; 2 cartes o mà de split no", async ({ page }) => {
  await startSolo(page);
  await patchMe(page, { handSlots: [slot("a", [num("a1", "hearts", 5)])], activeSlotIndex: 0, pendingChoices: { canDouble: true } });
  await expect(dbl(page).first()).toBeVisible();
  await patchMe(page, { handSlots: [slot("a", [num("a1", "hearts", 5), num("a2", "clubs", 1)])], activeSlotIndex: 0, pendingChoices: { canDouble: true } });
  await expect(dbl(page)).toHaveCount(0);
  await patchMe(page, { handSlots: [slot("s1", [fig("f1", "hearts", 10)]), slot("s2", [fig("f2", "clubs", 11)])], activeSlotIndex: 0, pendingChoices: { canDouble: true } });
  await expect(dbl(page)).toHaveCount(0);
});

test("Doblar després del canvi del 4: queda el ½ i el servidor ho ofereix", async ({ page }) => {
  await startSolo(page);
  await patchMe(page, { handSlots: [slot("w", [fig("w1", "hearts", 12)])], activeSlotIndex: 0, pendingChoices: { canDouble: true } });
  await expect(dbl(page).first()).toBeVisible();
});

test("Separar amb dues figures diferents (S+R)", async ({ page }) => {
  await startSolo(page);
  await patchMe(page, { handSlots: [slot("p", [fig("p1", "hearts", 10), fig("p2", "clubs", 12)])], activeSlotIndex: 0, pendingChoices: { canSplit: true } });
  const b = page.getByTestId("mobile-split-button");
  await expect(b).toBeVisible();
  expect((await b.boundingBox())!.height).toBeGreaterThanOrEqual(44);
});

for (const vp of [{ w: 390, h: 844 }, { w: 1280, h: 800 }]) {
  test.describe(`re-split sense límit ${vp.w}`, () => {
    test.use({ viewport: { width: vp.w, height: vp.h } });
    test(`5 mans sense retalls (${vp.w})`, async ({ page }) => {
      await startSolo(page);
      const hs = [0, 1, 2, 3, 4].map((i) => slot(`h${i}`, [fig(`c${i}a`, "hearts", 10 + (i % 3)), fig(`c${i}b`, "clubs", 12)], i < 3 ? "stood" : "playing"));
      await patchMe(page, { handSlots: hs, activeSlotIndex: 3, pendingChoices: { canSplit: true } });
      const hands = page.getByTestId("own-split-hand");
      await expect(hands).toHaveCount(5);
      await page.waitForTimeout(800);
      for (let i = 0; i < 5; i++) {
        const b = (await hands.nth(i).boundingBox())!;
        expect(b.x).toBeGreaterThanOrEqual(-0.5);
        expect(b.x + b.width).toBeLessThanOrEqual(vp.w + 0.5);
        expect(b.y + b.height).toBeLessThanOrEqual(vp.h + 0.5);
      }
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
    });
  });
}

test("després del canvi: surt el Mort (7) i la regla del 3 (3)", async ({ page }) => {
  await startSolo(page);
  await patchMe(page, { handSlots: [slot("m", [{ ...num("m7", "hearts", 7), faceUp: false }])], activeSlotIndex: 0, pendingChoices: { canMort: true, offerCardId: "m7" } });
  await page.getByTestId("local-hand-card").filter({ visible: true }).first().click().catch(() => {});
  await expect(page.getByTestId("mort-accept").or(page.getByTestId("mort-decline")).first()).toBeAttached({ timeout: 15_000 });
  await patchMe(page, { handSlots: [slot("t", [{ ...num("t3", "clubs", 3), faceUp: false }])], activeSlotIndex: 0, pendingChoices: { swapOffer: 3, offerCardId: "t3" } });
  await page.getByTestId("local-hand-card").filter({ visible: true }).first().click().catch(() => {});
  await expect(page.getByTestId("swap-offer")).toHaveAttribute("data-offer", "3", { timeout: 15_000 });
});
