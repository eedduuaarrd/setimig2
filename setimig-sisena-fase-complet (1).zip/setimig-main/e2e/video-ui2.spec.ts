import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, mintE2eToken } from "./helpers/e2eSession.ts";

/** Vídeo de l'Edu (ronda 2 · UI): −/+ i JUGA amb contrast AA, camps d'amics amb vora, imatge del pas 2, avís en tancar sessió. */

const AGE = () => JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" });
const VPS = [
  { w: 390, h: 844 },
  { w: 1280, h: 800 },
] as const;

async function seed(page: Page, opts: { tutorialDone?: boolean } = {}) {
  const pid = e2ePoolId();
  const token = mintE2eToken(pid);
  await page.addInitScript(
    ({ pid, token, age, tutorialDone }) => {
      localStorage.setItem("setimig_age_gate", age);
      localStorage.setItem("setimig_onboarding_v1", "1");
      if (tutorialDone) localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      else localStorage.removeItem("setimig_interactive_tutorial_v1");
      sessionStorage.setItem("setimig_intro_launch_v1", "1");
      localStorage.setItem("setimig.locale", "ca");
      if (sessionStorage.getItem("vui2_seeded") === "1") return;
      sessionStorage.setItem("vui2_seeded", "1");
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_token", token);
      localStorage.setItem("setimig_player_name", "Prova");
    },
    { pid, token, age: AGE(), tutorialDone: opts.tutorialDone !== false },
  );
}

/** Contrast entre un color (amb alfa, fos sobre el fons efectiu) i el fons efectiu de l'element. */
async function contrast(page: Page, testId: string, prop: string, pseudo: string | null = null): Promise<number> {
  return page.getByTestId(testId).first().evaluate(
    (el, { prop, pseudo }) => {
      const parse = (c: string) => {
        const m = c.match(/rgba?\(([^)]+)\)/);
        if (!m) return [0, 0, 0, 0];
        const p = m[1]!.split(/[ ,/]+/).filter(Boolean).map(Number);
        return [p[0]!, p[1]!, p[2]!, p[3] ?? 1];
      };
      const over = (top: number[], bot: number[]) => [0, 1, 2].map((i) => top[i]! * top[3]! + bot[i]! * (1 - top[3]!)).concat(1);
      const bgOf = (node: Element | null): number[] => {
        const stack: number[][] = [];
        for (let n = node; n; n = n.parentElement) {
          const c = parse(getComputedStyle(n).backgroundColor);
          if (c[3]! > 0) stack.push(c);
          if (c[3] === 1) break;
        }
        let bg = [11, 11, 11, 1];
        for (const c of stack.reverse()) bg = over(c, bg);
        return bg;
      };
      const lum = (c: number[]) => {
        const f = (v: number) => {
          v /= 255;
          return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
        };
        return 0.2126 * f(c[0]!) + 0.7152 * f(c[1]!) + 0.0722 * f(c[2]!);
      };
      const bg = bgOf(el.parentElement);
      const own = parse(getComputedStyle(el).backgroundColor);
      const surface = own[3]! > 0 ? over(own, bg) : bg;
      const fgRaw = parse((getComputedStyle(el, pseudo) as unknown as Record<string, string>)[prop]!);
      const fg = over(fgRaw, prop === "color" ? surface : bg);
      const target = prop === "color" ? surface : bg;
      const [a, b] = [lum(fg), lum(target)].sort((x, y) => y - x);
      return (a! + 0.05) / (b! + 0.05);
    },
    { prop, pseudo },
  );
}

for (const vp of VPS) {
  test(`${vp.w}: JUGA amb text AA i pes ≥700`, async ({ browser }) => {
    const ctx = await browser.newContext({ viewport: { width: vp.w, height: vp.h } });
    const page = await ctx.newPage();
    await seed(page);
    await page.goto("/");
    const play = page.getByTestId("play-vs-ai-button");
    await expect(play).toBeVisible({ timeout: 60_000 });
    expect(await contrast(page, "play-vs-ai-button", "color")).toBeGreaterThanOrEqual(4.5);
    const fw = await play.evaluate((el) => Number(getComputedStyle(el).fontWeight));
    expect(fw).toBeGreaterThanOrEqual(700);
    await ctx.close();
  });

  test(`${vp.w}: −/+ de l'aposta amb vora AA (≥3:1) i ≥44 px`, async ({ browser }) => {
    const ctx = await browser.newContext({ viewport: { width: vp.w, height: vp.h } });
    const page = await ctx.newPage();
    await seed(page);
    await page.goto("/");
    await page.getByTestId("lobby-context").click({ timeout: 60_000 });
    await page.getByTestId("ai-bot-count-2").click();
    await page.getByTestId("ai-bot-picker-start").click();
    await expect(page.getByTestId("bet-screen")).toBeVisible({ timeout: 30_000 });
    for (const id of ["bet-minus", "bet-plus"]) {
      const b = await page.getByTestId(id).boundingBox();
      expect(b!.width).toBeGreaterThanOrEqual(44);
      expect(b!.height).toBeGreaterThanOrEqual(44);
      expect(await contrast(page, id, "borderTopColor", "::before"), `${id} vora`).toBeGreaterThanOrEqual(3);
      expect(await contrast(page, id, "color"), `${id} icona`).toBeGreaterThanOrEqual(3);
    }
    await ctx.close();
  });

  test(`${vp.w}: amb amics, camps mín/màx amb vora visible i focus`, async ({ browser }) => {
    const ctx = await browser.newContext({ viewport: { width: vp.w, height: vp.h } });
    const page = await ctx.newPage();
    await seed(page);
    await page.goto("/");
    await page.getByTestId("play-with-friends-button").click({ timeout: 60_000 });
    for (const id of ["private-table-min-bet", "private-table-max-bet"]) {
      const f = page.getByTestId(id);
      await expect(f).toBeVisible();
      const bw = await f.evaluate((el) => parseFloat(getComputedStyle(el).borderTopWidth));
      expect(bw).toBeGreaterThanOrEqual(1);
      expect(await contrast(page, id, "borderTopColor"), `${id} vora`).toBeGreaterThanOrEqual(3);
      const before = await f.evaluate((el) => getComputedStyle(el).borderTopColor);
      await f.focus();
      const after = await f.evaluate((el) => getComputedStyle(el).borderTopColor);
      expect(after).not.toBe(before);
    }
    await expect(page.getByText("Inclou el Mort", { exact: false })).toBeVisible();
    await ctx.close();
  });

  test(`${vp.w}: tutorial pas 2 amb la imatge carregada entre «Demanar» i «Plantar-se»`, async ({ browser }) => {
    const ctx = await browser.newContext({ viewport: { width: vp.w, height: vp.h } });
    const page = await ctx.newPage();
    await seed(page, { tutorialDone: false });
    await page.goto("/");
    await expect(page.getByTestId("interactive-tutorial")).toBeVisible({ timeout: 60_000 });
    await page.getByTestId("interactive-tutorial-next").click();
    await expect(page.getByTestId("interactive-tutorial-step-2")).toBeVisible();
    const img = page.locator(".interactive-tutorial-illus--actions img").first();
    await expect(img).toBeVisible();
    await expect.poll(() => img.evaluate((el: HTMLImageElement) => el.complete && el.naturalWidth), { timeout: 15_000 }).toBeGreaterThan(0);
    await ctx.close();
  });

  test(`${vp.w}: tancar sessió mostra «Has tancat la sessió» a /login`, async ({ browser }) => {
    const ctx = await browser.newContext({ viewport: { width: vp.w, height: vp.h } });
    const page = await ctx.newPage();
    await seed(page);
    await page.goto("/");
    await page.locator("button.header-profile").first().click({ timeout: 60_000 });
    await expect(page.getByTestId("profile-panel")).toBeVisible({ timeout: 30_000 });
    expect(await contrast(page, "profile-delete-open", "color")).toBeGreaterThanOrEqual(4.5);
    const red = await page.getByTestId("profile-delete-open").evaluate((el) => {
      const m = getComputedStyle(el).color.match(/\d+/g)!.map(Number);
      return m[0]! > m[1]! + 60 && m[0]! > m[2]! + 60;
    });
    expect(red, "ESBORRAR COMPTE en vermell").toBe(true);
    const logout = page.getByTestId("profile-logout");
    await logout.scrollIntoViewIfNeeded();
    await logout.click();
    await page.waitForURL(/\/login/, { timeout: 15_000 });
    const toast = page.getByTestId("logout-toast");
    await expect(toast).toHaveText("Has tancat la sessió");
    await expect(page.locator(".logout-toast-region")).toHaveAttribute("aria-live", "polite");
    await expect(toast).toHaveCount(0, { timeout: 5_000 });
    await ctx.close();
  });
}
