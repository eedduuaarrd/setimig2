import { expect, test } from "@playwright/test";
import fs from "node:fs";
import path from "node:path";
import { startAiGameFromLobby } from "./helpers/aiLobby";
import { passAgeGateToLobby } from "./helpers/ageGateLobby";
import { confirmBetIfShown, localHand, playUntilSettlement, settlementSurface, waitForHandSurface } from "./helpers/tableFlow";

const MOBILE = { width: 390, height: 844 } as const;
const DESKTOP = { width: 1280, height: 720 } as const;

function screenshotDir(): string {
  const candidates = [
    "/cursor/stores/self/media/pas12",
    path.join(process.cwd(), "media/pas12"),
  ];
  for (const dir of candidates) {
    try {
      fs.mkdirSync(dir, { recursive: true });
      return dir;
    } catch {
      /* try next */
    }
  }
  return candidates[candidates.length - 1];
}

async function startAiGame(page: import("@playwright/test").Page, bots: number, playerId: string, playerName: string) {
  await passAgeGateToLobby(page, playerName, { playerId, online: true });
  await startAiGameFromLobby(page, bots);
  await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 45_000 });
  await waitForHandSurface(page);
}

async function assertNoPageScroll(page: import("@playwright/test").Page) {
  const metrics = await page.evaluate(() => ({
    doc: document.documentElement.scrollHeight,
    inner: window.innerHeight,
    body: document.body.scrollHeight,
  }));
  expect(metrics.doc).toBeLessThanOrEqual(metrics.inner + 2);
  expect(metrics.body).toBeLessThanOrEqual(metrics.inner + 2);
}

async function assertNoCriticalOverlap(page: import("@playwright/test").Page) {
  const overlaps = await page.evaluate(() => {
    const nodes = [
      document.querySelector("[data-seat-player]"),
      document.querySelector("[data-testid='status-pill']") ?? document.querySelector("[data-testid='match-hand-counter']"),
      document.querySelector("[data-testid='local-hand-fan-slot']") ??
        document.querySelector("[data-testid='local-player-seat'] .spanish-card-size-player"),
      document.querySelector("[data-testid='action-dock']"),
      document.querySelector("[data-testid='settlement-sheet']"),
    ].filter(Boolean) as HTMLElement[];

    const rects = nodes.map((el) => {
      const r = el.getBoundingClientRect();
      return { sel: el.dataset.testid ?? el.dataset.seatPlayer ?? el.className, ...r };
    });

    const hits: string[] = [];
    for (let i = 0; i < rects.length; i++) {
      for (let j = i + 1; j < rects.length; j++) {
        const a = rects[i];
        const b = rects[j];
        const overlap = a.left < b.right && a.right > b.left && a.top < b.bottom && a.bottom > b.top;
        if (overlap) {
          const area =
            (Math.min(a.right, b.right) - Math.max(a.left, b.left)) *
            (Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top));
          if (area > 120) hits.push(`${a.sel} x ${b.sel} (${Math.round(area)}px²)`);
        }
      }
    }
    return hits;
  });
  expect(overlaps, overlaps.join("; ")).toEqual([]);
}

test("PAS 12 — lobby IA + amics (sense taula pública)", async ({ page }) => {
  await page.setViewportSize(MOBILE);
  await passAgeGateToLobby(page, "Pas12Lobby", { playerId: "pas12lobbycheck01" });
  await expect(page.getByTestId("play-vs-ai-button")).toBeVisible();
  await expect(page.getByTestId("play-vs-ai-button")).toHaveText(/^Jugar$/i);
  await expect(page.getByTestId("play-with-friends-button")).toBeVisible();
  await expect(page.getByText("Taula pública")).toHaveCount(0);
});

test("PAS 12 — mobile 390 my turn layout", async ({ page }) => {
  test.setTimeout(120_000);
  await page.setViewportSize(MOBILE);
  await startAiGame(page, 3, "pas12myturn01xx", "Pas12Me");
  await expect(page.locator("[data-seat-player]").first()).toBeVisible({ timeout: 60_000 });
  await confirmBetIfShown(page);
  const card = page.locator(".game-table-mobile .spanish-card-size-player").first();
  await expect(card).toBeVisible({ timeout: 60_000 });
  await assertNoPageScroll(page);
  await assertNoCriticalOverlap(page);
  const box = await card.boundingBox();
  expect(box).not.toBeNull();
  expect(box!.width).toBeGreaterThanOrEqual(40);
  expect(box!.height).toBeGreaterThanOrEqual(60);
  await page.screenshot({ path: path.join(screenshotDir(), "01-mobile-my-turn.png"), fullPage: false });
});

test("PAS 12 — mobile 390 IA turn", async ({ page }) => {
  test.setTimeout(180_000);
  await page.setViewportSize(MOBILE);
  await startAiGame(page, 3, "pas12iaturn01xxx", "Pas12Ia");
  await confirmBetIfShown(page);
  await expect
    .poll(
      async () => {
        const stand = page.getByTestId("action-stand");
        if ((await stand.isVisible().catch(() => false)) && (await stand.isEnabled().catch(() => false))) {
          await stand.click({ timeout: 1_000 }).catch(() => undefined);
        }
        const rivalActive = await page.locator("[data-seat-active='true']").count();
        const bank = await page.getByText(/Torn de la banca|Juga la banca|Sorteig de banca/).first().isVisible().catch(() => false);
        return rivalActive > 0 || bank;
      },
      { timeout: 90_000, intervals: [300, 500, 800] }
    )
    .toBe(true);
  await assertNoPageScroll(page);
  await page.screenshot({ path: path.join(screenshotDir(), "02-mobile-ia-turn.png"), fullPage: false });
});

test("PAS 12 — mobile hand result", async ({ page }) => {
  test.setTimeout(180_000);
  await page.setViewportSize(MOBILE);
  await startAiGame(page, 1, "pas12result01xxx", "Pas12Res");
  await playUntilSettlement(page);
  await expect(settlementSurface(page).first()).toBeVisible();
  await page.screenshot({ path: path.join(screenshotDir(), "03-mobile-result.png"), fullPage: false });
});

test("PAS 12 — la graella buida de mòbil no ocupa la taula", async ({ page }) => {
  // Bug: with mobileLayout, game-seat-grid gets Tailwind's `hidden`, but
  // `.game-seat-grid { display: grid }` in index.css is unlayered and wins.
  // The empty grid stays visible and keeps min-h-[min(36vh,11rem)].
  test.fixme(true, "La classe hidden de game-seat-grid la guanya display:grid de index.css.");
  test.setTimeout(120_000);
  await page.setViewportSize(MOBILE);
  await startAiGame(page, 3, "pas12gridhidden1", "Pas12Grid");
  await expect(page.getByTestId("game-seat-grid")).toBeHidden();
});

test("PAS 12 — desktop table still renders seat grid", async ({ page }) => {
  // Bug: game-seat-grid and local-player-seat are rendered only inside
  // `{mobileLayout && (...)}` in GameView. At min-width 1024px that branch is
  // false, so the desktop ring and the local hand never mount. The
  // `!mobileLayout` seat map inside the same block is dead code.
  test.fixme(true, "A >=1024px GameView no munta ni la graella de seients ni la mà local.");
  test.setTimeout(120_000);
  await page.setViewportSize(DESKTOP);
  await startAiGame(page, 3, "pas12desk01xxxxx", "Pas12Pc");
  await expect(page.getByTestId("game-seat-grid")).toBeVisible({ timeout: 60_000 });
  await expect(page.locator("[data-seat-player]")).toHaveCount(3);
  await confirmBetIfShown(page);
  await expect(localHand(page).first()).toBeVisible({ timeout: 60_000 });
  await page.screenshot({ path: path.join(screenshotDir(), "04-pc-table.png"), fullPage: false });
});
