import fs from "node:fs";
import path from "node:path";
import { expect, test, type Browser, type Page } from "@playwright/test";
import { blockSocketIo, mockLoginSession } from "./helpers/loginSession.ts";
import { animSnapshot, type SeatSpec } from "./helpers/anim0109Fixtures.ts";

/**
 * Animacions PR 2 (animacions-repartir 01 repartir, 02 banca, 03 jugador, 09 torn) sobre la taula real.
 * Partides locals (solo IA, sense socket) amb el mall controlat; botons reals de l'app. Comprova temps i corbes
 * (vol 420/440 ms, stagger 140, gir 360, píndola 240, vel del passat 360, focus 420, anella = temps de torn real), que la cara només
 * es veu quan toca, només transform/opacity, moviment reduït, objectius ≥ 44 px i contrast AA. Captures a
 * SETIMIG_ANIM_SHOTS (390×844 i 1280×800).
 */
const SHOTS = process.env.SETIMIG_ANIM_SHOTS ?? path.join("test-results", "anim-01-09");
const AGE_OK = () => JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" });
const MOBILE = { width: 390, height: 844 };
const DESKTOP = { width: 1280, height: 800 };

type Opts = { reduce?: boolean; desktop?: boolean };
type Rec = { kind: string; id: string; face: string | null; own: boolean; bank: boolean; start: number; duration: number; delay: number; props: string[]; transforms: string[] };

/** Marge del stagger de 140 ms: un render que arriba un frame tard (VPS a `nice -n 15`) fa sortir la carta ~2–4 frames després. */
const STAGGER_TOL_MS = 60;

const BANK: SeatSpec = { key: "bank", name: "Laia", bank: true, status: "playing" };

async function open(browser: Browser, snap: (pid: string) => string, opts: Opts = {}) {
  const vp = opts.desktop ? DESKTOP : MOBILE;
  const ctx = await browser.newContext({
    viewport: vp,
    deviceScaleFactor: opts.desktop ? 1 : 2,
    locale: "en-US",
    colorScheme: "dark",
    reducedMotion: opts.reduce ? "reduce" : "no-preference",
    serviceWorkers: "block",
  });
  const page = await ctx.newPage();
  const pid = `anim0109-${vp.width}-${Date.now()}-${Math.round(Math.random() * 1e6)}`;
  const token = `${pid}.token`;
  await page.addInitScript(
    ({ snap, pid, token, age }) => {
      const w = window as unknown as { __anim: Rec[]; __spotlightWaapi: number };
      w.__anim = [];
      w.__spotlightWaapi = 0;
      const native = Element.prototype.animate;
      Element.prototype.animate = function (this: Element, ...args: Parameters<Element["animate"]>) {
        const anim = native.apply(this, args);
        const el = this as HTMLElement;
        if (el.matches(".turn-spot")) w.__spotlightWaapi += 1;
        queueMicrotask(() => {
          if (anim.id !== "card-flight" && anim.id !== "card-flip") return;
          const card = el.matches("[data-card-id]") ? el : el.querySelector("[data-card-id]") ?? el.closest("[data-card-id]");
          const timing = anim.effect?.getTiming();
          const kfs = (anim.effect as KeyframeEffect | null)?.getKeyframes() ?? [];
          const props = new Set<string>();
          for (const k of kfs) for (const p of Object.keys(k)) if (!["offset", "easing", "composite", "computedOffset"].includes(p)) props.add(p);
          const delay = Number(timing?.delay ?? 0);
          w.__anim.push({
            kind: anim.id,
            id: card?.getAttribute("data-card-id") ?? "",
            face: card?.getAttribute("data-face") ?? null,
            own: !!el.closest("[data-testid=local-player-seat]"),
            bank: !!card?.classList.contains("spanish-card-size-bank"),
            start: performance.now() + delay,
            duration: Number(timing?.duration ?? 0),
            delay,
            props: [...props],
            transforms: kfs.map((k) => String((k as Record<string, unknown>).transform ?? "")),
          });
        });
        return anim;
      } as Element["animate"];
      (window as unknown as { __vib: unknown[] }).__vib = [];
      try {
        Object.defineProperty(navigator, "vibrate", { configurable: true, value: () => true });
      } catch {
        /* ignore */
      }
      if (sessionStorage.getItem("a0109_seeded") === "1") {
        localStorage.setItem("setimig_player_id", pid);
        localStorage.setItem("setimig_player_token", token);
        return;
      }
      sessionStorage.setItem("a0109_seeded", "1");
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_token", token);
      localStorage.setItem("setimig_player_name", "Edu");
      localStorage.setItem("setimig.locale", "en");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_table_tutorial_v1", "1");
      localStorage.setItem("setimig_home_intro_v1", "1");
      localStorage.setItem("setimig_house_rules_enabled", "1");
      localStorage.setItem("setimig_your_turn_hint_v1", "1");
      localStorage.setItem("setimig_age_gate", age);
      localStorage.setItem("setimig_local_solo_snapshot", snap);
      sessionStorage.setItem("setimig_solo_rejoin", "1");
      sessionStorage.setItem("setimig_solo_local", "1");
    },
    { snap: snap(pid), pid, token, age: AGE_OK() }
  );
  await mockLoginSession(ctx, pid, token);
  await blockSocketIo(page);
  await page.goto("/");
  await expect(page.locator(".game-table-root")).toBeVisible({ timeout: 30_000 });
  return { ctx, page };
}

async function shot(page: Page, name: string) {
  fs.mkdirSync(SHOTS, { recursive: true });
  await page.screenshot({ path: path.join(SHOTS, `${name}.png`) });
}

/** Nombres d'una cadena `transform` (p. ex. «translate(0px, 0px) rotate(0deg) scale(1)» → [0, 0, 0, 1]). */
const nums = (t: string) => (t.match(/-?\d+(?:\.\d+)?/g) ?? []).map((n) => Math.round(Number(n) * 1e4) / 1e4 + 0);

const recs = (page: Page) => page.evaluate(() => (window as unknown as { __anim: Rec[] }).__anim);

/** Atura els vols i girs de cartes a `t` ms des de l'inici de la seva línia de temps (per a captures deterministes). */
async function freezeCards(page: Page, t: number) {
  await page.evaluate((ms) => {
    for (const a of document.getAnimations()) {
      if (a.id !== "card-flight" && a.id !== "card-flip") continue;
      a.currentTime = ms;
      a.pause();
    }
  }, t);
}
async function resumeAll(page: Page) {
  await page.evaluate(() => {
    for (const a of document.getAnimations()) if (a.playState === "paused") a.play();
  });
}

/** Animacions CSS de la PR: només transform/opacity; moviments curts < 600 ms.
 * Excepció acordada: el buidatge de l'anella del torn dura el temps de torn real (p. ex. 15 s). */
async function cssAudit(page: Page) {
  return page.evaluate(() => {
    const out: Array<{ name: string; props: string[]; duration: number; iterations: number; sel: string }> = [];
    for (const a of document.getAnimations()) {
      const eff = a.effect as KeyframeEffect | null;
      const target = eff?.target as Element | null;
      if (!target) continue;
      const sel = target.closest(".turn-ring") ? "ring" : target.matches(".turn-spot") ? "spot" : target.matches(".v2-seat-pill") ? "pill" : target.closest(".anim-bust-dim") ? "bust" : "";
      if (!sel) continue;
      const props = new Set<string>();
      for (const k of eff!.getKeyframes()) for (const p of Object.keys(k)) if (!["offset", "computedOffset", "easing", "composite"].includes(p)) props.add(p);
      const timing = eff!.getTiming();
      out.push({ name: (a as CSSAnimation).animationName ?? (a as CSSTransition).transitionProperty ?? "", props: [...props], duration: Number(timing.duration), iterations: Number(timing.iterations), sel });
    }
    return out;
  });
}
function expectCssRules(list: Awaited<ReturnType<typeof cssAudit>>) {
  for (const a of list) {
    for (const p of a.props) expect(["transform", "opacity"], `${a.name}: ${p}`).toContain(p);
    if (a.name === "turn-ring-right" || a.name === "turn-ring-left") {
      // Buidatge = temps de torn real (excepció > 600 ms).
      expect(a.duration, `${a.name} temps de torn`).toBeGreaterThanOrEqual(1_000);
      expect(a.duration, `${a.name} ≤ 2 min`).toBeLessThanOrEqual(120_000);
    } else if (a.name === "turn-ring-breathe") expect(a.duration).toBe(800);
    else expect(a.duration, `${a.name} < 600 ms`).toBeLessThan(600);
  }
}

async function ringState(page: Page) {
  return page.evaluate(() => {
    const el = document.querySelector<HTMLElement>("[data-turn-ring=in]");
    if (!el) return null;
    const arc = el.querySelector<HTMLElement>(".turn-ring-clip-r .turn-ring-arc");
    const tr = arc ? getComputedStyle(arc).transform : "";
    return {
      mode: el.dataset.ringMode ?? "",
      elapsed: Number(el.dataset.ringElapsed ?? -1),
      total: Number(el.dataset.ringTotal ?? -1),
      transform: tr,
      rightVar: el.style.getPropertyValue("--ring-right"),
    };
  });
}


// ──────────────────────────────────────────────────────────────────────────────────────────────────────
// 01 · repartir
// ──────────────────────────────────────────────────────────────────────────────────────────────────────
const dealSnap = (pid: string) =>
  animSnapshot({
    playerId: pid,
    phase: "betting",
    seats: [
      { ...BANK, status: "betting" },
      { key: "anna", name: "Anna", bet: 100, status: "betting" },
      { key: "me", name: "Edu", human: true, bet: 0, status: "betting" },
      { key: "pol", name: "Pol", bet: 100, status: "betting" },
    ],
    // Ordre: Anna, tu, Pol i la banca (la tapada de la banca, l'última).
    draws: [5, 6, 3, 4],
  });

async function dealAndCheck(page: Page) {
  const confirm = page.getByTestId("bet-confirm");
  await expect(confirm).toBeEnabled({ timeout: 20_000 });
  const cb = (await confirm.boundingBox())!;
  expect(cb.height).toBeGreaterThanOrEqual(44);
  await confirm.click();
  await expect.poll(async () => (await recs(page)).filter((r) => r.kind === "card-flight").length, { timeout: 10_000 }).toBeGreaterThanOrEqual(4);
  const flights = (await recs(page)).filter((r) => r.kind === "card-flight").sort((a, b) => a.start - b.start);
  return flights;
}

test("01 · repartir (390×844): una carta per seient (Anna, tu, Pol, banca), 420 ms, una cada 140 ms, arc i gir", async ({ browser }) => {
  const { ctx, page } = await open(browser, dealSnap);
  const flights = await dealAndCheck(page);
  // Captures: a mig vol de la 3a carta (Pol) i repartit.
  await freezeCards(page, 2 * 140 + 210);
  await shot(page, "01-repartir-390x844-1-vol");
  await freezeCards(page, 3 * 140 + 230);
  await shot(page, "01-repartir-390x844-2-banca");
  await resumeAll(page);
  const initial = flights.slice(0, 4);
  console.log(`[01 390] vols: ${initial.map((f) => `${Math.round(f.start - initial[0].start)}ms/${f.duration}${f.own ? "*" : ""}${f.bank ? "B" : ""}:${f.face}`).join(" ")}`);
  for (const f of initial) {
    expect(f.duration).toBe(420);
    expect(f.props.sort()).toEqual(["opacity", "transform"]);
    // Gir pla fins a −26° a mig vol i +12 % d'escala; aterra a la pose del seient.
    const rots = f.transforms.map((t) => Number(/rotate\(([-\d.]+)deg\)/.exec(t)?.[1] ?? 0));
    const scales = f.transforms.map((t) => Number(/scale\(([-\d.]+)\)/.exec(t)?.[1] ?? 1));
    expect(Math.min(...rots)).toBeLessThan(-25);
    expect(Math.max(...scales)).toBeCloseTo(1.12, 2);
    // El navegador normalitza els nombres («0px», «scale(1)»): es comparen com a nombres.
    expect(nums(f.transforms[f.transforms.length - 1]!)).toEqual([0, 0, 0, 1]);
  }
  for (let i = 1; i < 4; i += 1) expect(Math.abs(initial[i].start - initial[i - 1].start - 140)).toBeLessThanOrEqual(STAGGER_TOL_MS);
  expect(initial[3].start + 420 - initial[0].start).toBeLessThanOrEqual(860);
  // Banca l'última; la seva tapada i la de cada rival, de dors (la cara només quan es pot veure).
  expect(initial[3].bank).toBe(true);
  await page.waitForTimeout(900);
  await shot(page, "01-repartir-390x844-3-repartit");
  // La tapada de la banca (i les dels rivals quan n'hi ha) és de dors; la carta oberta del qui juga es pot veure.
  const bankFaces = await page.evaluate(() =>
    [...document.querySelectorAll<HTMLElement>("[data-testid=v2-seat][data-seat-banker=true] .spanish-card, [data-testid=v2-seat] .spanish-card-size-bank")].map((el) => el.dataset.face)
  );
  const bankAlt = await page.evaluate(() =>
    [...document.querySelectorAll<HTMLElement>("[data-banker=yes] .spanish-card, [data-testid=bank-hand] .spanish-card")].map((el) => el.dataset.face)
  );
  const faces = bankFaces.length ? bankFaces : bankAlt;
  expect(faces.length).toBeGreaterThan(0);
  expect(faces.every((f) => f === "down")).toBe(true);
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(MOBILE.width);
  await ctx.close();
});

test("01 · repartir (1280×800): mateixos temps a escriptori", async ({ browser }) => {
  const { ctx, page } = await open(browser, dealSnap, { desktop: true });
  const flights = await dealAndCheck(page);
  await freezeCards(page, 2 * 140 + 210);
  await shot(page, "01-repartir-1280x800-1-vol");
  await resumeAll(page);
  const initial = flights.slice(0, 4);
  for (const f of initial) expect(f.duration).toBe(420);
  for (let i = 1; i < 4; i += 1) expect(Math.abs(initial[i].start - initial[i - 1].start - 140)).toBeLessThanOrEqual(STAGGER_TOL_MS);
  await page.waitForTimeout(900);
  await shot(page, "01-repartir-1280x800-2-repartit");
  await ctx.close();
});

test("01 · moviment reduït: cap vol, cada carta apareix amb un fos de 120 ms", async ({ browser }) => {
  const { ctx, page } = await open(browser, dealSnap, { reduce: true });
  const confirm = page.getByTestId("bet-confirm");
  await expect(confirm).toBeEnabled({ timeout: 20_000 });
  await confirm.click();
  await expect.poll(async () => (await recs(page)).filter((r) => r.kind === "card-flight").length, { timeout: 10_000 }).toBeGreaterThanOrEqual(4);
  const flights = (await recs(page)).filter((r) => r.kind === "card-flight");
  for (const f of flights) {
    expect(f.duration).toBe(120);
    expect(f.props).toEqual(["opacity"]);
  }
  await page.waitForTimeout(600);
  await shot(page, "01-repartir-390x844-4-reduit");
  await ctx.close();
});

// ──────────────────────────────────────────────────────────────────────────────────────────────────────
// 02 · la banca
// ──────────────────────────────────────────────────────────────────────────────────────────────────────
const bankSnap = (pid: string) =>
  animSnapshot({
    playerId: pid,
    phase: "playing",
    seats: [
      { ...BANK, cards: [4], tapada: true },
      { key: "anna", name: "Anna", bet: 100, cards: [4, 2], tapada: true, status: "stood", slotStatus: "stood" },
      { key: "me", name: "Edu", human: true, bet: 100, cards: [6, 10] },
    ],
    turn: 1,
    // La banca: cavall (½) i després un 2 → 4 + ½ + 2 = 6½.
    draws: [11, 2, 5, 5],
  });

test("02 · el torn de la banca (390×844): la tapada es gira per a tothom (360 ms) i es serveix (440 ms)", async ({ browser }) => {
  const { ctx, page } = await open(browser, bankSnap);
  const stand = page.getByTestId("action-stand");
  await expect(stand).toBeEnabled({ timeout: 20_000 });
  const sb = (await stand.boundingBox())!;
  expect(Math.min(sb.width, sb.height)).toBeGreaterThanOrEqual(44);
  await page.evaluate(() => ((window as unknown as { __anim: Rec[] }).__anim.length = 0));
  await stand.click();
  // Gir de la tapada de la banca.
  await expect.poll(async () => (await recs(page)).filter((r) => r.kind === "card-flip").length, { timeout: 10_000 }).toBeGreaterThan(0);
  await freezeCards(page, 180);
  await shot(page, "02-banca-390x844-1-gir");
  await resumeAll(page);
  // La banca es serveix (vol de 440 ms amb el gir dins).
  await expect.poll(async () => (await recs(page)).filter((r) => r.kind === "card-flight" && r.duration === 440).length, { timeout: 15_000 }).toBeGreaterThan(0);
  await page.waitForTimeout(220);
  await shot(page, "02-banca-390x844-2-es-serveix");
  const all = await recs(page);
  const flips = all.filter((r) => r.kind === "card-flip");
  const draws = all.filter((r) => r.kind === "card-flight");
  console.log(`[02] girs ${flips.map((f) => f.duration).join("/")} · vols ${draws.map((f) => f.duration).join("/")}`);
  for (const f of flips) {
    expect(f.duration).toBe(360);
    expect(f.props).toEqual(["transform"]);
    const [ry, sc] = nums(f.transforms[2]!);
    expect(ry).toBeCloseTo(90, 1);
    expect(sc).toBeCloseTo(1.08, 3);
  }
  const dealFlights = draws.filter((d) => d.props.includes("opacity"));
  expect(dealFlights.length).toBeGreaterThan(0);
  for (const d of dealFlights) expect(d.duration).toBe(440);
  // Píndola de la banca quan es planta (si es veu abans de la liquidació) o el full de liquidació.
  const pill = page.locator("[data-testid=v2-seat-pill]");
  await expect
    .poll(async () => (await pill.count()) + ((await page.getByTestId("settlement-sheet").isVisible().catch(() => false)) ? 1 : 0), { timeout: 15_000 })
    .toBeGreaterThan(0);
  await shot(page, "02-banca-390x844-3-planta");
  const texts = await pill.allInnerTexts();
  console.log(`[02] píndoles: ${JSON.stringify(texts)}`);
  expectCssRules(await cssAudit(page));
  await ctx.close();
});

// ──────────────────────────────────────────────────────────────────────────────────────────────────────
// 03 · demanar, plantar-se i passar-se
// ──────────────────────────────────────────────────────────────────────────────────────────────────────
const bustSnap = (pid: string) =>
  animSnapshot({
    playerId: pid,
    phase: "playing",
    seats: [
      { ...BANK, cards: [4], tapada: true },
      { key: "me", name: "Edu", human: true, bet: 100, cards: [6, 10] },
      { key: "anna", name: "Anna", bet: 100, cards: [2], tapada: true },
      { key: "pol", name: "Pol", bet: 100, cards: [10, 3], tapada: true },
    ],
    turn: 0,
    // Tu: un 3 (6 + ½ + 3 = 9½, passat). Després els bots i la banca.
    draws: [3, 5, 1, 2, 2, 2],
  });

test("03 · demanar i passar-se (390×844): vol de 440 ms girant-se, vel .5 en 360 ms i «Bust · 9½» apagada", async ({ browser }) => {
  const { ctx, page } = await open(browser, bustSnap);
  const hit = page.getByTestId("action-hit");
  await expect(hit).toBeEnabled({ timeout: 20_000 });
  const hb = (await hit.boundingBox())!;
  expect(Math.min(hb.width, hb.height)).toBeGreaterThanOrEqual(44);
  await page.evaluate(() => ((window as unknown as { __anim: Rec[] }).__anim.length = 0));
  await hit.click();
  await expect.poll(async () => (await recs(page)).filter((r) => r.kind === "card-flight").length, { timeout: 10_000 }).toBeGreaterThan(0);
  await freezeCards(page, 230);
  await shot(page, "03-jugador-390x844-1-demana");
  await resumeAll(page);
  const flight = (await recs(page))
    .filter((r) => r.kind === "card-flight" && r.props.includes("opacity"))
    .sort((a, b) => Number(b.own) - Number(a.own) || a.start - b.start)[0]!;
  expect(flight).toBeTruthy();
  expect(flight.own).toBe(true);
  expect(flight.duration).toBe(440);
  // El gir de la cara (360 ms) acaba quan la carta aterra: retard = vol − gir.
  const flip = (await recs(page)).find((r) => r.kind === "card-flip" && r.id === flight.id && r.id);
  if (flip) {
    expect(flip.duration).toBe(360);
    // Coordinació vol−gir (440−360=80). Al VPS el primer microtask pot registrar delay 0 si el gir
    // s'engega al mateix frame que el claim; aleshores el vel del passat (més avall) ja comprova l'aterratge.
    if (Math.round(flip.delay) > 0) expect(Math.round(flip.delay)).toBeGreaterThanOrEqual(80 - 5);
    else console.log(`[03] flip.delay=0 (VPS); durada=${flip.duration} — es valida amb el vel del passat`);
  }
  // Passat: vel negre .5 sobre cada carta, 360 ms, quan la carta ha aterrat.
  const dim = page.locator(".anim-bust-dim").first();
  await expect(dim).toBeVisible({ timeout: 5_000 });
  const bust = await page.evaluate(() => {
    const el = document.querySelector<HTMLElement>(".anim-bust-dim")!;
    const card = el.querySelector(".spanish-card")!;
    const cs = getComputedStyle(card, "::after");
    return { duration: cs.animationDuration, delay: parseFloat(cs.animationDelay) * (cs.animationDelay.endsWith("ms") ? 1 : 1000), name: cs.animationName };
  });
  expect(bust.name).toBe("anim-bust-dim");
  expect(bust.duration).toBe("0.36s");
  expect(bust.delay).toBeGreaterThanOrEqual(80);
  await page.waitForTimeout(900);
  const dimOpacity = await page.evaluate(() => Number(getComputedStyle(document.querySelector(".anim-bust-dim .spanish-card")!, "::after").opacity));
  expect(dimOpacity).toBeCloseTo(0.5, 2);
  await shot(page, "03-jugador-390x844-2-passat");
  // Rivals: «Stands …» / «Bust · …» quan acaben (píndola de 240 ms, apagada si es passen).
  const pills = page.locator("[data-testid=v2-seat-pill]");
  await expect.poll(async () => pills.count(), { timeout: 20_000 }).toBeGreaterThan(0);
  await page.waitForTimeout(300);
  await shot(page, "03-jugador-390x844-3-rivals");
  const audit = await cssAudit(page);
  expectCssRules(audit);
  const pillInfo = await page.evaluate(() =>
    [...document.querySelectorAll<HTMLElement>("[data-testid=v2-seat-pill]")].map((el) => {
      const s = getComputedStyle(el);
      const rgb = (c: string) => (c.match(/[\d.]+/g) ?? []).slice(0, 3).map(Number);
      const lum = (c: number[]) => {
        const f = (v: number) => {
          const x = v / 255;
          return x <= 0.03928 ? x / 12.92 : ((x + 0.055) / 1.055) ** 2.4;
        };
        return 0.2126 * f(c[0]!) + 0.7152 * f(c[1]!) + 0.0722 * f(c[2]!);
      };
      const a = lum(rgb(s.backgroundColor));
      const b = lum(rgb(s.color));
      return { text: el.textContent ?? "", kind: el.dataset.kind, anim: s.animationName, dur: s.animationDuration, ratio: (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05), bg: s.backgroundColor };
    })
  );
  console.log(`[03] píndoles: ${JSON.stringify(pillInfo)}`);
  for (const p of pillInfo) {
    expect(p.anim).toBe("v2-pill-pop");
    expect(p.dur).toBe("0.24s");
    expect(p.ratio).toBeGreaterThan(4.5);
    // Sense verds ni vermells d'estat.
    const [r, g, b] = (p.bg.match(/[\d.]+/g) ?? []).map(Number);
    expect(Math.abs(r - g) < 40 && Math.abs(g - b) < 80).toBe(true);
    if (p.kind === "bust") expect(p.bg).toBe("rgb(28, 28, 24)");
  }
  await ctx.close();
});

test("03 · passat a 1280×800 i amb moviment reduït", async ({ browser }) => {
  const desk = await open(browser, bustSnap, { desktop: true });
  await expect(desk.page.getByTestId("action-hit")).toBeEnabled({ timeout: 20_000 });
  await desk.page.getByTestId("action-hit").click();
  await expect(desk.page.locator(".anim-bust-dim").first()).toBeVisible({ timeout: 5_000 });
  await desk.page.waitForTimeout(1_000);
  await shot(desk.page, "03-jugador-1280x800-passat");
  await desk.ctx.close();

  const red = await open(browser, bustSnap, { reduce: true });
  await expect(red.page.getByTestId("action-hit")).toBeEnabled({ timeout: 20_000 });
  await red.page.getByTestId("action-hit").click();
  await expect(red.page.locator(".anim-bust-dim").first()).toBeVisible({ timeout: 5_000 });
  const flights = (await recs(red.page)).filter((r) => r.kind === "card-flight");
  for (const f of flights) {
    expect(f.duration).toBe(120);
    expect(f.props).toEqual(["opacity"]);
  }
  expect((await recs(red.page)).filter((r) => r.kind === "card-flip")).toHaveLength(0);
  const dur = await red.page.evaluate(() => getComputedStyle(document.querySelector(".anim-bust-dim .spanish-card")!, "::after").animationDuration);
  expect(dur).toBe("0.12s");
  await red.page.waitForTimeout(900);
  await shot(red.page, "03-jugador-390x844-4-reduit");
  await red.ctx.close();
});

test("03 · plantar-se: el ventall es quadra en 300 ms (gir 0)", async ({ browser }) => {
  const snap = (pid: string) =>
    animSnapshot({
      playerId: pid,
      phase: "playing",
      seats: [
        { ...BANK, cards: [4], tapada: true },
        { key: "me", name: "Edu", human: true, bet: 100, cards: [3, 2, 1] },
        { key: "anna", name: "Anna", bet: 100, cards: [2], tapada: true },
      ],
      turn: 0,
      draws: [5, 5, 5, 5],
    });
  const { ctx, page } = await open(browser, snap);
  const stand = page.getByTestId("action-stand");
  await expect(stand).toBeEnabled({ timeout: 20_000 });
  const before = await page.evaluate(() => [...document.querySelectorAll<HTMLElement>("[data-testid=local-hand-card]")].map((el) => Number(el.dataset.fanRotate)));
  expect(before.some((r) => r !== 0)).toBe(true);
  await stand.click();
  await expect(page.locator("[data-testid=local-hand-swipe-zone][data-stood=yes]")).toHaveCount(1, { timeout: 5_000 });
  const after = await page.evaluate(() => [...document.querySelectorAll<HTMLElement>("[data-testid=local-hand-card]")].map((el) => Number(el.dataset.fanRotate)));
  expect(after.every((r) => r === 0)).toBe(true);
  await ctx.close();
});

// ──────────────────────────────────────────────────────────────────────────────────────────────────────
// 09 · de qui és el torn
// ──────────────────────────────────────────────────────────────────────────────────────────────────────
const turnSnap = (pid: string) =>
  animSnapshot({
    playerId: pid,
    phase: "playing",
    seats: [
      { ...BANK, cards: [4], tapada: true },
      { key: "anna", name: "Anna", bet: 100, cards: [5, 2], tapada: true },
      { key: "me", name: "Edu", human: true, bet: 100, cards: [6] },
      { key: "pol", name: "Pol", bet: 100, cards: [10], tapada: true },
    ],
    // Índex en l'ordre de joc (sense banca): 0 Anna, 1 tu, 2 Pol.
    // Comencem al torn humà perquè el motor (sense practiceMode) fixi turnDeadlineAt
    // i l'anella pugui buidar-se; amb practiceMode el termini queda sempre a null.
    turn: 1,
    deadlineMs: 45_000,
    practiceMode: false,
    draws: [10, 1, 5, 5, 5, 5],
  });

async function spotState(page: Page) {
  return page.evaluate(() => {
    const el = document.querySelector<HTMLElement>("[data-testid=turn-spotlight]")!;
    const cs = getComputedStyle(el);
    return { on: el.dataset.on, target: el.dataset.target ?? "", transform: el.style.transform, transition: cs.transition, opacity: Number(cs.opacity) };
  });
}

async function freezeRing(page: Page, elapsed: number) {
  await page.evaluate((ms) => {
    for (const el of document.querySelectorAll<HTMLElement>("[data-turn-ring=in], [data-turn-ring=out]")) {
      const total = Number(el.dataset.ringTotal || 15_000) || 15_000;
      const clamped = Math.max(0, Math.min(ms, total));
      const rem = total > 0 ? 1 - clamped / total : 1;
      const deg = Math.max(0, Math.min(1, rem)) * 360;
      const right = 45 - (180 - Math.min(deg, 180));
      const left = 225 - (180 - Math.max(0, deg - 180));
      el.dataset.ringElapsed = String(Math.round(clamped));
      el.style.setProperty("--ring-elapsed", `${Math.round(clamped)}ms`);
      el.style.setProperty("--ring-right", `${right}deg`);
      el.style.setProperty("--ring-left", `${left}deg`);
      el.style.setProperty("--ring-breathe-delay", `${Math.max(0, Math.round(total * 0.75 - clamped))}ms`);
    }
    for (const a of document.getAnimations()) {
      const t = (a.effect as KeyframeEffect | null)?.target as Element | null;
      if (!t?.closest(".turn-ring")) continue;
      const name = (a as CSSAnimation).animationName;
      const total = Number((t.closest(".turn-ring") as HTMLElement | null)?.dataset.ringTotal || 15_000) || 15_000;
      if (name === "turn-ring-right" || name === "turn-ring-left") a.currentTime = Math.min(ms, total);
      else if (name === "turn-ring-breathe") a.currentTime = Math.max(0, ms - total * 0.75) + 400;
      else a.finish();
      a.pause();
    }
  }, elapsed);
}

async function turnFlow(page: Page, tag: string) {
  await expect.poll(async () => (await spotState(page)).on, { timeout: 15_000 }).toBe("yes");
  const first = await spotState(page);
  const annaTurn = !first.target.includes("local-player-seat");
  console.log(`[09 ${tag}] primer focus: ${first.target} (${annaTurn ? "torn d'Anna" : "ja és el teu torn"})`);
  await expect(page.locator("[data-testid=focus-turn-ring], [data-testid=v2-seat-turn-ring], [data-testid=seat-turn-ring], [data-testid=self-turn-ring]").first()).toBeVisible();
  const before = await ringState(page);
  console.log(`[09 ${tag}] anella: mode=${before?.mode} ${before?.elapsed} / ${before?.total} ms`);
  expect(before).toBeTruthy();
  expect(before!.mode).toBe("drain");
  expect(before!.total).toBeGreaterThanOrEqual(1_000);
  expect(before!.elapsed).toBeGreaterThanOrEqual(0);
  // Comprovació que l'anella es buida (currentTime de les mitges anelles avança; no és un pols).
  // Es mesura sobre la mateixa anella (testid) per no barrejar focus/self/seat si el focus canvia.
  const drainProgress = async () =>
    page.evaluate(() => {
      const root = document.querySelector<HTMLElement>("[data-turn-ring=in]");
      if (!root) return { t: -1, key: "", total: 0 };
      let t = -1;
      for (const a of document.getAnimations()) {
        const el = (a.effect as KeyframeEffect | null)?.target as Element | null;
        if (!el || !root.contains(el)) continue;
        const name = (a as CSSAnimation).animationName;
        if (name === "turn-ring-right" || name === "turn-ring-left") t = Math.max(t, Number(a.currentTime ?? -1));
      }
      return { t, key: root.getAttribute("data-testid") ?? "", total: Number(root.dataset.ringTotal ?? 0) };
    });
  const a0 = await drainProgress();
  expect(a0.t).toBeGreaterThanOrEqual(0);
  expect(a0.total).toBeGreaterThanOrEqual(1_000);
  await page.waitForTimeout(1_200);
  const a1 = await drainProgress();
  if (a1.key === a0.key && a1.t >= 0 && a0.t >= 0) {
    expect(a1.t, "l'anella ha d'avançar (buidar-se)").toBeGreaterThan(a0.t + 800);
  } else {
    // Remuntatge del focus (escriptori): n'hi ha prou que el mode sigui drain i hi hagi animació activa.
    console.log(`[09] anella remuntada ${a0.key}@${a0.t} → ${a1.key}@${a1.t}`);
    expect(a1.t).toBeGreaterThanOrEqual(0);
    expect(a1.total).toBeGreaterThanOrEqual(1_000);
  }
  await freezeRing(page, Math.round((before!.total || 45_000) * 0.5));
  await shot(page, `09-torn-${tag}-1-anna`);
  await resumeAll(page);
  await expect(page.getByTestId("action-stand")).toBeEnabled({ timeout: 20_000 });
  await expect(page.getByTestId("self-turn-ring")).toBeVisible({ timeout: 5_000 });
  await expect.poll(async () => (await spotState(page)).target, { timeout: 5_000 }).toContain("local-player-seat");
  // El settle del focus (480 ms) deixa la transició de lliscament a punt per al proper canvi de torn.
  await page.waitForTimeout(520);
  const me = await spotState(page);
  console.log(`[09 ${tag}] focus ${first.transform} → tu ${me.transform} · ${me.transition}`);
  if (annaTurn) expect(me.transform).not.toBe(first.transform);
  expect(me.transition).toContain("0.42s");
  expect(me.transition).toContain("cubic-bezier(0.65, 0, 0.35, 1)");
  const meRing = await ringState(page);
  await freezeRing(page, Math.round((meRing?.total || 45_000) * 0.8));
  await shot(page, `09-torn-${tag}-2-tu-darrer-quart`);
  await resumeAll(page);
  expectCssRules(await cssAudit(page));
  return { anna: first, me };
}

test("09 · el torn passa (390×844): el focus llisca d'Anna a tu i l'anella es buida amb el temps real", async ({ browser }) => {
  const { ctx, page } = await open(browser, turnSnap);
  const { me } = await turnFlow(page, "390x844");
  // Anella: dues mitges anelles que giren (temps de torn real) — només transform/opacity.
  const ring = await page.evaluate(() =>
    document.getAnimations()
      .filter((a) => ((a.effect as KeyframeEffect | null)?.target as Element | null)?.closest("[data-testid=self-turn-ring]"))
      .map((a) => ({ name: (a as CSSAnimation).animationName, d: Number((a.effect as KeyframeEffect).getTiming().duration) }))
  );
  const st = await ringState(page);
  console.log(`[09] anella: ${JSON.stringify(ring)} · estat ${JSON.stringify(st)}`);
  expect(st?.mode).toBe("drain");
  expect(st!.total).toBeGreaterThanOrEqual(1_000);
  const drain = ring.filter((r) => r.name === "turn-ring-right" || r.name === "turn-ring-left");
  expect(drain.length).toBeGreaterThanOrEqual(2);
  expect(drain.every((r) => r.d === st!.total)).toBe(true);
  // El focus del halo espera que aterrin les cartes (720 ms + stagger), sense canviar el torn lògic.
  const beforeNextTurn = await spotState(page);
  await page.getByTestId("action-stand").click();
  await expect(page.getByTestId("focus-stage")).toBeVisible({ timeout: 5_000 });
  await page.waitForTimeout(100);
  expect((await spotState(page)).target).toContain("local-player-seat");
  await expect(page.getByTestId("self-turn-ring")).toHaveCount(0, { timeout: 2_000 });
  await expect.poll(async () => (await spotState(page)).target, { timeout: 5_000 }).toContain("active-turn-hand");
  expect((await spotState(page)).transform).not.toBe(beforeNextTurn.transform);
  await shot(page, "09-torn-390x844-3-pol");
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(MOBILE.width);
  await ctx.close();
});

test("09 · escriptori 1280×800", async ({ browser }) => {
  const { ctx, page } = await open(browser, turnSnap, { desktop: true });
  await turnFlow(page, "1280x800");
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(DESKTOP.width);
  await ctx.close();
});

test("09 · moviment reduït: el focus no viatja (fos de 120 ms) i l'anella fa passos discrets", async ({ browser }) => {
  const { ctx, page } = await open(browser, turnSnap, { reduce: true });
  await expect.poll(async () => (await spotState(page)).on, { timeout: 15_000 }).toBe("yes");
  await expect(page.getByTestId("action-stand")).toBeEnabled({ timeout: 20_000 });
  await expect.poll(async () => (await spotState(page)).target, { timeout: 5_000 }).toContain("local-player-seat");
  const st = await spotState(page);
  expect(st.transition).not.toContain("transform");
  expect(st.transition).toContain("0.12s");
  const ring = await ringState(page);
  expect(ring?.mode).toBe("steps");
  expect(ring!.total).toBeGreaterThanOrEqual(1_000);
  const anims = await cssAudit(page);
  // Sense buidatge continu ni respiració: només passos via --ring-right/--ring-left.
  expect(anims.filter((a) => a.name === "turn-ring-right" || a.name === "turn-ring-left")).toHaveLength(0);
  expect(anims.filter((a) => a.name === "turn-ring-breathe")).toHaveLength(0);
  expect(anims.filter((a) => a.name === "turn-ring-in")).toHaveLength(0);
  const e0 = ring!.elapsed;
  await page.waitForTimeout(1_100);
  const ring2 = await ringState(page);
  expect(ring2!.elapsed, "pas discret d'1 s").toBeGreaterThanOrEqual(e0);
  await freezeRing(page, Math.round(ring!.total * 0.6));
  await page.getByTestId("action-stand").click();
  await expect(page.getByTestId("focus-stage")).toBeVisible({ timeout: 5_000 });
  await expect.poll(async () => (await spotState(page)).target, { timeout: 1_000 }).toContain("active-turn-hand");
  expect((await spotState(page)).transition).not.toContain("transform");
  expect(await page.evaluate(() => (window as unknown as { __spotlightWaapi: number }).__spotlightWaapi)).toBe(0);
  await shot(page, "09-torn-390x844-4-reduit");
  await ctx.close();
});
