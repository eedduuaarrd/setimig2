import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";
import { playingTurnSnapshotJson } from "./helpers/mobileDockLayoutFixtures.ts";
import { rivalTurnSnapshotJson } from "./helpers/iphoneDetallsFixtures.ts";

const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844 },
  { tag: "375x667", width: 375, height: 667 },
  { tag: "360x740", width: 360, height: 740 },
] as const;

async function seedLocalSolo(page: Page, snapshot: string, playerId: string, playerName: string) {
  await seedE2eSession(page, playerId);
  await page.addInitScript(
    ({ snap, pid, pname }) => {
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", pname);
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_house_rules_enabled", "1");
      localStorage.setItem(
        "setimig_age_gate",
        JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
      );
      localStorage.setItem("setimig_local_solo_snapshot", snap);
      sessionStorage.setItem("setimig_solo_rejoin", "1");
      sessionStorage.setItem("setimig_solo_local", "1");
    },
    { snap: snapshot, pid: playerId, pname: playerName }
  );
}

async function assertDockHandCardsNotClipped(page: Page) {
  // The last dealt card slides in from the table centre; measure once the deal
  // animation has settled instead of mid-flight (was flaky on the VPS gate).
  let result: { ok: boolean; [k: string]: unknown } = { ok: false };
  await expect
    .poll(async () => {
      result = await measureDockHandCards(page);
      return result.ok;
    }, { timeout: 5_000, intervals: [100, 250, 500] })
    .toBe(true)
    .catch(() => undefined);
  expect(result.ok, JSON.stringify(result)).toBe(true);
}

async function measureDockHandCards(page: Page) {
  return page.evaluate(() => {
    const dock = document.querySelector('[data-testid="action-dock"]') as HTMLElement | null;
    const fanSlot = document.querySelector('[data-testid="local-hand-fan-slot"]') as HTMLElement | null;
    if (!dock || !fanSlot) return { ok: false, reason: "missing-container" };
    const dr = dock.getBoundingClientRect();
    const fr = fanSlot.getBoundingClientRect();
    const outer = {
      x: Math.min(dr.left, fr.left),
      y: Math.min(dr.top, fr.top),
      width: Math.max(dr.right, fr.right) - Math.min(dr.left, fr.left),
      height: Math.max(dr.bottom, fr.bottom) - Math.min(dr.top, fr.top),
    };
    const cards = Array.from(document.querySelectorAll('[data-testid="local-hand-card"]'));
    for (let i = 0; i < cards.length; i++) {
      const r = cards[i]!.getBoundingClientRect();
      const inner = { x: r.x, y: r.y, width: r.width, height: r.height, top: r.top, left: r.left, right: r.right, bottom: r.bottom };
      const tol = 2; // el ventall gira les cartes ~1,5 px per sobre del contenidor
      if (
        inner.top < outer.y - tol ||
        inner.left < outer.x - tol ||
        inner.right > outer.x + outer.width + tol ||
        inner.bottom > outer.y + outer.height + tol
      ) {
        return { ok: false, reason: `card-${i}`, outer, inner };
      }
    }
    return { ok: true, count: cards.length };
  });
}

async function assertNoCenterActiveTurnHand(page: Page) {
  await expect(page.getByTestId("active-turn-hand")).toHaveCount(0);
  const centerCard = await page.evaluate(() => {
    const mesa = document.querySelector(".table-center-mesa");
    if (!mesa) return false;
    return !!mesa.querySelector(".active-turn-center-card, .active-turn-hand");
  });
  expect(centerCard).toBe(false);
}

for (const vp of VIEWPORTS) {
  test.describe(`iphone detalls PWA ${vp.tag}`, () => {
    test.use({ viewport: { width: vp.width, height: vp.height } });

    test(`dock: cartes senceres dins el contenidor (${vp.tag})`, async ({ page }) => {
      const playerId = e2ePoolId();
      const snapshot = playingTurnSnapshotJson(playerId, "IphDock", 4, false);
      await seedLocalSolo(page, snapshot, playerId, "IphDock");
      await page.route("**/socket.io/**", (route) => route.abort());
      await page.goto("/");
      await expect(page.getByTestId("local-hand-card").first()).toBeVisible({ timeout: 30_000 });
      await assertDockHandCardsNotClipped(page);
    });

    test(`torn rival: sense mà gran al centre (${vp.tag})`, async ({ page }) => {
      const playerId = e2ePoolId();
      const snapshot = rivalTurnSnapshotJson(playerId, "IphRival");
      await seedLocalSolo(page, snapshot, playerId, "IphRival");
      await page.route("**/socket.io/**", (route) => route.abort());
      await page.goto("/");
      // Lobby/taula v2: el comptador només surt si queda temps; esperem el seient actiu.
      await expect(page.locator(".game-table-root")).toBeVisible({ timeout: 30_000 });
      await assertNoCenterActiveTurnHand(page);
      // Torn rival: qui juga surt de la fila i es ressalta al centre (focus-stage amb «Juga …»), amb compte enrere.
      const stage = page.locator('[data-testid="focus-stage"][data-focus-player]');
      await expect(stage, "seient actiu del rival ressaltat").toBeVisible({ timeout: 5_000 });
      await expect(stage.getByTestId("focus-turn-label")).toHaveText(/Jordi/);
      await expect(page.locator('[data-seat-self="true"][data-seat-active="true"]'), "jo no sóc l'actiu").toHaveCount(0);
      await expect(page.getByTestId("turn-countdown").first(), "compte enrere del torn rival").toHaveText(/^\s*[1-9]\d*s\s*$/);
    });
  });
}
