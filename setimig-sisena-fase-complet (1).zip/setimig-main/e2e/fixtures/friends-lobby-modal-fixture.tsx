import React from "react";
import { createRoot } from "react-dom/client";
import { FriendsLobbyModal } from "../../src/App";
import "../../src/index.css";

createRoot(document.getElementById("root")!).render(
  <FriendsLobbyModal
    open
    onClose={() => {}}
    onCreatePrivateTable={() => {}}
    onJoinPrivateByCode={() => {}}
    pendingInviteCode=""
  />
);
