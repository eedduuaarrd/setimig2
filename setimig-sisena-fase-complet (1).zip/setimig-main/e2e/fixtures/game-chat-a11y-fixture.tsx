import React from "react";
import { createRoot } from "react-dom/client";
import GameView from "../../src/GameView";
import type { RoomView } from "../../src/gameTypes";
import "../../src/index.css";

const room: RoomView = {
  id: "chat-a11y-fixture",
  name: "Chat accessibility fixture",
  players: [],
  pot: 0,
  phase: "waiting",
  turnIndex: 0,
  minBet: 1,
  jackpot: 0,
  lastRound: null,
  soloAi: false,
};

createRoot(document.getElementById("root")!).render(
  <main className="min-h-screen bg-background p-4">
    <GameView
      room={room}
      viewerId="fixture-player"
      emitGame={() => {}}
      messages={[]}
      onLeave={() => {}}
      immersive
      connected={new URLSearchParams(window.location.search).get("connected") !== "false"}
    />
  </main>
);
