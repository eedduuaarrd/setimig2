import React, { useState } from "react";
import { createRoot } from "react-dom/client";
import { FreeChipsModal } from "../../src/components/FreeChipsClaim";
import "../../src/index.css";

function FreeChipsModalFixture() {
  const [open, setOpen] = useState(false);
  return (
    <main className="min-h-screen bg-background p-8">
      <button
        type="button"
        data-testid="open-free-chips"
        onClick={() => setOpen(true)}
        className="btn-primary-solid min-h-[48px] rounded-xl px-5"
      >
        Obre les fitxes
      </button>
      <FreeChipsModal
        open={open}
        onClose={() => setOpen(false)}
        balance={1_000}
        freeClaim={{ claimable: true, nextClaimAt: null, secondsUntilClaim: 0, amount: 10_000 }}
        claiming={false}
        claimPulse={false}
        onClaim={() => {}}
      />
    </main>
  );
}

createRoot(document.getElementById("root")!).render(<FreeChipsModalFixture />);
