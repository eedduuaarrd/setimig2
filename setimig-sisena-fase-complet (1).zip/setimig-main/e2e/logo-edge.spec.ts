/**
 * Logo sense requadre (Edu 28/10, iPhone real v137): el logo del /login no pot mostrar cap vora
 * sobre el fons verd fosc amb vinyeta. Captura en memòria (no es desa) i mostreig de píxels en un
 * anell just a fora i just a dins de la caixa del logo: el salt de color a la vora ha de ser petit
 * (≈ com el del fons veí) i no hi pot haver cap rectangle gairebé negre.
 */
import { expect, test, type Page } from "@playwright/test";

const MAX_STEP = 8; // salt màxim de luminància (0–255) creuant la vora, per sobre del salt del fons veí
const NEAR_BLACK = 14; // luminància que considerem «gairebé negre»

async function edgeStats(page: Page, testId: string) {
  const box = await page.getByTestId(testId).boundingBox();
  if (!box) throw new Error("sense caixa");
  const png = (await page.screenshot({ animations: "disabled" })).toString("base64");
  return page.evaluate(
    async ({ png, box }) => {
      const img = new Image();
      img.src = `data:image/png;base64,${png}`;
      await img.decode();
      const c = document.createElement("canvas");
      c.width = img.width;
      c.height = img.height;
      const g = c.getContext("2d")!;
      g.drawImage(img, 0, 0);
      const k = img.width / innerWidth;
      const luma = (x: number, y: number) => {
        const d = g.getImageData(Math.round(x * k), Math.round(y * k), 1, 1).data;
        return 0.2126 * d[0] + 0.7152 * d[1] + 0.0722 * d[2];
      };
      // Punts a l'anell (només els 10 % externs dels costats, on el logo és transparent).
      const pts: Array<[number, number, number, number]> = []; // x,y dins i desplaçament normal
      for (let i = 0; i <= 20; i++) {
        const t = i / 20;
        const x = box.x + t * box.width;
        const y = box.y + t * box.height;
        pts.push([x, box.y + 2, 0, -1], [x, box.y + box.height - 2, 0, 1], [box.x + 2, y, -1, 0], [box.x + box.width - 2, y, 1, 0]);
      }
      let maxStep = 0;
      let maxBgStep = 0;
      let minInside = 255;
      for (const [x, y, nx, ny] of pts) {
        const inside = luma(x, y);
        const out1 = luma(x + nx * 6, y + ny * 6);
        const out2 = luma(x + nx * 12, y + ny * 12);
        maxStep = Math.max(maxStep, Math.abs(inside - out1));
        maxBgStep = Math.max(maxBgStep, Math.abs(out1 - out2));
        minInside = Math.min(minInside, inside);
      }
      let minOutside = 255;
      for (const [x, y, nx, ny] of pts) minOutside = Math.min(minOutside, luma(x + nx * 6, y + ny * 6));
      return { maxStep, maxBgStep, minInside, minOutside };
    },
    { png, box }
  );
}

test("el logo del /login no té requadre sobre el fons real", async ({ browser }) => {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 3, isMobile: true, hasTouch: true, colorScheme: "dark", reducedMotion: "reduce", locale: "ca-ES" });
  await ctx.addInitScript(() => {
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
  });
  await ctx.route(/\/socket\.io\//, (r) => r.abort());
  await ctx.route(/\/api\/auth\/providers/, (r) => r.fulfill({ json: { email: true, google: true, passkey: true, rpId: "sevenhalf.club" } }));
  const page = await ctx.newPage();
  await page.goto("/login");
  const logo = page.getByTestId("login-logo");
  await expect(logo).toBeVisible({ timeout: 20_000 });
  await expect(page.getByTestId("home-intro")).toHaveCount(0, { timeout: 15_000 });
  await expect.poll(() => logo.evaluate((i: HTMLImageElement) => i.complete && i.naturalWidth > 0)).toBe(true);
  await page.waitForTimeout(400);
  const s = await edgeStats(page, "login-logo");
  console.log(`logo-edge /login: salt vora=${s.maxStep.toFixed(1)} salt fons=${s.maxBgStep.toFixed(1)} min dins=${s.minInside.toFixed(1)} min fora=${s.minOutside.toFixed(1)}`);
  expect(s.maxStep).toBeLessThanOrEqual(s.maxBgStep + MAX_STEP);
  // Cap rectangle gairebé negre: la vora interior no pot ser més fosca que el fons de fora.
  expect(s.minInside).toBeGreaterThanOrEqual(Math.min(NEAR_BLACK, s.minOutside - 4));
  await ctx.close();
});
