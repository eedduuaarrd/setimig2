/**
 * L'idioma per defecte de l'app és l'anglès i ja no es dedueix del navegador. Les suites antigues
 * comproven textos en català: aquest storageState desa la preferència `setimig.locale=ca` (com si
 * l'usuari l'hagués triada al selector) per a tots els orígens locals que fan servir els configs.
 */
const STORAGE_KEY = "setimig.locale";

export function catalanStorageState() {
  const origins = new Set<string>();
  const ports = [process.env.SETIMIG_E2E_PORT, process.env.E2E_PORT, process.env.PORT, "3177", "3000", "4173"].filter(Boolean) as string[];
  for (const port of ports) {
    origins.add(`http://127.0.0.1:${port}`);
    origins.add(`http://localhost:${port}`);
  }
  if (process.env.APP_URL) {
    try {
      origins.add(new URL(process.env.APP_URL).origin);
    } catch {
      /* APP_URL no vàlida: s'ignora */
    }
  }
  return {
    cookies: [],
    origins: [...origins].map((origin) => ({ origin, localStorage: [{ name: STORAGE_KEY, value: "ca" }] })),
  };
}
