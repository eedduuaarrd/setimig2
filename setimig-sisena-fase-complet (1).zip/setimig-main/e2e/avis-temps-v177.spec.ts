import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * v177: l'avís «Plantat per temps» va a baix (sobre el dock), sense filet lateral i mai damunt
 * la fila de seients; el gir complet només amb un lliscament molt ràpid fins a dalt i mai reparteix carta.
 * Cal SETIMIG_TEST_DECK_SEED=3 o 217 (docs/baralla-de-prova.md).
 */
const SEED = process.env.SETIMIG_TEST_DECK_SEED;
const SIZES = [
  { name: "390", width: 390, height: 844 },
  { name: "1280", width: 1280, height: 800 },
] as const;
type Box = { x: number; y: number; width: number; height: number };
const overlap = (a: Box, b: Box) =>
  a.x < b.x + b.width - 1 && b.x < a.x + a.width - 1 && a.y < b.y + b.height - 1 && b.y < a.y + a.height - 1;

async function startSolo(page: Page, confirm = true) {
  await seedE2eSession(page, e2ePoolId());
  await page.addInitScript(() => {
    if (sessionStorage.getItem("qa_llavor") === "1") return;
    sessionStorage.setItem("qa_llavor", "1");
    for (const k of ["setimig_onboarding_v1", "setimig_interactive_tutorial_v1", "setimig_table_tutorial_v1", "setimig_house_rules_enabled"]) localStorage.setItem(k, "1");
    localStorage.setItem("setimig.locale", "ca");
    localStorage.setItem("setimig_player_name", "Test Llavor");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
    sessionStorage.setItem("setimig_intro_launch_v1", "1");
  });
  await page.goto("/");
  const skip = page.getByTestId("interactive-tutorial-skip");
  await expect(page.getByTestId("lobby-context").or(skip).first()).toBeVisible({ timeout: 45_000 });
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  if (await page.getByTestId("ai-bot-count-1").isVisible().catch(() => false)) await page.getByTestId("ai-bot-count-1").click();
  const cb = page.getByTestId("house-rules-toggle").locator("input");
  if ((await cb.count()) && !(await cb.isChecked())) await cb.check({ force: true });
  await page.getByTestId("ai-bot-picker-start").click();
  if (confirm) await page.getByTestId("bet-confirm").filter({ visible: true }).first().click({ timeout: 30_000 });
}

const host = (page: Page) => page.getByTestId("peek-curl-host").filter({ visible: true }).first();
const grab = (page: Page) => page.getByTestId("peek-curl-grab").filter({ visible: true }).first();
/** Cartes de la mà pròpia: germanes de la carta tapada (per `data-card-id`). */
const handCount = (page: Page, id: string) =>
  page.evaluate((id) => {
    const c = document.querySelector(`[data-card-id="${id}"]`)?.closest("[data-card-flight], div")?.parentElement?.parentElement;
    return new Set([...(c?.querySelectorAll("[data-card-id]") ?? [])].map((e) => e.getAttribute("data-card-id"))).size;
  }, id);

/** Lliscament: `steps` moviments des de baix de la carta fins a `toY`. */
async function swipe(page: Page, steps: number, stepDelay: number, toTop: boolean) {
  await expect(grab(page)).toBeVisible({ timeout: 30_000 });
  const b = (await grab(page).boundingBox())!;
  const x = b.x + b.width / 2, y0 = b.y + b.height * 0.95;
  const y1 = toTop ? 4 : b.y + b.height * 0.3;
  await page.mouse.move(x, y0);
  await page.mouse.down();
  for (let i = 1; i <= steps; i++) {
    await page.mouse.move(x, y0 + ((y1 - y0) * i) / steps);
    if (stepDelay) await page.waitForTimeout(stepDelay);
  }
  await page.mouse.up();
}

/** Lliscament molt ràpid fins a dalt, dins la pàgina (~30 ms), perquè la velocitat no depengui de la màquina. */
async function fastFlick(page: Page) {
  const b = (await grab(page).boundingBox())!;
  await page.evaluate(async ({ x, y0 }) => {
    const target = document.elementFromPoint(x, y0)!;
    const ev = (type: string, y: number) =>
      new PointerEvent(type, { bubbles: true, cancelable: true, composed: true, pointerId: 7, pointerType: "touch", isPrimary: true, clientX: x, clientY: y, buttons: type === "pointerup" ? 0 : 1 });
    target.dispatchEvent(ev("pointerdown", y0));
    for (let i = 1; i <= 6; i++) {
      await new Promise((r) => setTimeout(r, 5));
      const y = y0 - ((y0 - 2) * i) / 6;
      (document.elementFromPoint(x, Math.max(1, y)) ?? window).dispatchEvent(ev("pointermove", Math.max(1, y)));
      window.dispatchEvent(ev("pointermove", Math.max(1, y)));
    }
    window.dispatchEvent(ev("pointerup", 2));
  }, { x: b.x + b.width / 2, y0: b.y + b.height * 0.95 });
}

for (const size of SIZES) {
  const mobile = size.width < 600;
  test.describe(`Avís per temps + gir v177 @${size.name}`, () => {
    test.use({ viewport: { width: size.width, height: size.height }, isMobile: mobile, hasTouch: mobile });

    test("aixecar lent no gira; lliscament ràpid gira sense repartir", async ({ page }) => {
      // 217 comença amb un 7: el peek obre l'oferta del Mort (sense «Destapar carta»).
      test.skip(SEED !== "3", "cal SETIMIG_TEST_DECK_SEED=3");
      await startSolo(page);
      await expect(grab(page)).toBeVisible({ timeout: 30_000 });
      const id = (await host(page).locator("[data-card-id]").first().getAttribute("data-card-id"))!;
      const before = await handCount(page, id);
      // Lent i curt: només s'ensenya, no es gira.
      await swipe(page, 12, 60, false);
      await page.waitForTimeout(900);
      await expect(host(page)).toBeVisible();
      await expect(page.locator('[data-testid="reveal-card-action"]').filter({ visible: true })).toHaveCount(1);
      // Molt ràpid fins a dalt: gir complet.
      await expect(page.locator(`[data-card-id="${id}"]`).first()).toHaveAttribute("data-face", "down");
      await page.waitForTimeout(1500);
      await fastFlick(page);
      await expect(page.locator(`[data-card-id="${id}"][data-face="up"]`)).toHaveCount(1, { timeout: 5_000 });
      await page.waitForTimeout(800);
      expect(await handCount(page, id), "cap carta repartida").toBe(before);
      // El número es veu: punts propis no es mostren, però la carta girada té índex visible.
      const idx = await page.evaluate((id) =>
        [...document.querySelectorAll(".spanish-card")].some((e) => {
          const r = e.getBoundingClientRect();
          return e.getAttribute("data-card-id") === id && r.height > 40 && r.top >= 0 && r.bottom <= innerHeight && r.left >= 0 && r.right <= innerWidth && e.querySelector("img, svg, [class*=rank], [class*=index]") !== null;
        }), id,
      );
      expect(idx, "número visible").toBe(true);
    });

    test("«Plantat per temps» a baix, sense filet i fora dels seients", async ({ page }) => {
      test.setTimeout(240_000);
      test.skip(!SEED, "cal SETIMIG_TEST_DECK_SEED (3 o 217)");
      await startSolo(page);
      await expect(grab(page)).toBeVisible({ timeout: 30_000 });
      const toast = page.getByTestId("app-toast").filter({ hasText: /Plantat per temps/ });
      await expect(toast).toBeVisible({ timeout: 150_000 });
      await page.waitForTimeout(400);
      const r = await toast.evaluate((e) => {
        const b = e.getBoundingClientRect();
        const cs = getComputedStyle(e);
        const seats = [...document.querySelectorAll('[data-testid="v2-seat"], .v2-seat-name')].map((s) => s.getBoundingClientRect()).filter((s) => s.height > 0).map((s) => ({ x: s.x, y: s.y, width: s.width, height: s.height }));
        return { box: { x: b.x, y: b.y, width: b.width, height: b.height }, bl: parseFloat(cs.borderLeftWidth), vw: innerWidth, vh: innerHeight, seats };
      });
      expect(r.bl, "sense filet lateral").toBeLessThanOrEqual(1);
      expect(r.box.x).toBeGreaterThanOrEqual(0);
      expect(r.box.y).toBeGreaterThanOrEqual(0);
      expect(r.box.x + r.box.width).toBeLessThanOrEqual(r.vw);
      expect(r.box.y + r.box.height).toBeLessThanOrEqual(r.vh);
      expect(r.box.y, "a la meitat de baix").toBeGreaterThan(r.vh / 2);
      for (const s of r.seats) expect(overlap(r.box, s), "avís sobre un seient").toBe(false);
    });
  });
}

test.describe("Full d'aposta v177 @390x844", () => {
  test.use({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  test("shows seven fixed denominations without a MAX chip and keeps one title", async ({ page }) => {
    test.skip(!SEED, "cal SETIMIG_TEST_DECK_SEED (3 o 217)");
    await startSolo(page, false);
    const sheet = page.getByTestId("bet-screen").filter({ visible: true }).first();
    await expect(sheet).toBeVisible({ timeout: 30_000 });
    const chips = sheet.getByTestId("bet-chip");
    await expect(chips).toHaveCount(7);
    await expect(chips).toHaveText(["50", "100", "500", "1k", "5k", "25k", "100k"]);
    await expect(sheet.locator('[data-testid="bet-chip"].is-max')).toHaveCount(0);
    const hundred = sheet.locator('[data-testid="bet-chip"][data-denomination="100"]');
    await expect(hundred).toBeEnabled();
    await hundred.click();

    const cta = sheet.getByTestId("bet-confirm");
    expect((await cta.innerText()).replace(/\D/g, "")).toBe("100");
    await cta.click();
    await page.waitForTimeout(600);
    await expect(page.getByTestId("bet-not-enough")).toHaveCount(0);
    // Un sol títol a dalt: el comptador de mans no es pinta sota l'encapçalament.
    const counters = await page.locator('[data-testid="match-progress-bar"]').evaluateAll((els) =>
      els.filter((e) => getComputedStyle(e).visibility === "visible" && e.getBoundingClientRect().height > 0).length);
    // (Si el full ja ha marxat, el comptador torna a ser visible: només es comprova mentre el full hi és.)
    if (await sheet.isVisible().catch(() => false)) expect(counters).toBe(0);
  });
  test("un sol títol mentre s'aposta", async ({ page }) => {
    test.skip(!SEED, "cal SETIMIG_TEST_DECK_SEED (3 o 217)");
    await startSolo(page, false);
    const sheet = page.getByTestId("bet-screen").filter({ visible: true }).first();
    await expect(sheet).toBeVisible({ timeout: 30_000 });
    const title = (await sheet.locator(".bet-screen-eyebrow").boundingBox())!;
    const others = await page.evaluate(() =>
      [...document.querySelectorAll('[data-testid="match-hand-counter"]')].filter((e) => getComputedStyle(e).visibility === "visible").map((e) => e.getBoundingClientRect()).filter((b) => b.height > 0).map((b) => ({ x: b.x, y: b.y, width: b.width, height: b.height })));
    for (const o of others) expect(overlap(title, o), "títols solapats").toBe(false);
    expect(others.length).toBe(0);
  });
});

test.describe("Temps del torn v177 @390x844", () => {
  test.use({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  test("barra sota la capçalera, segons que baixen, sense anella ni solapaments", async ({ page }) => {
    // 217: l'oferta del Mort té el seu propi compte enrere i el del torn torna a començar.
    test.skip(SEED !== "3", "cal SETIMIG_TEST_DECK_SEED=3");
    await startSolo(page);
    await expect(grab(page)).toBeVisible({ timeout: 30_000 });
    await expect(page.getByTestId("self-turn-ring")).toHaveCount(0);
    const secs = page.getByTestId("turn-timer-seconds");
    if (!(await secs.isVisible({ timeout: 3000 }).catch(() => false))) await swipe(page, 8, 40, false);
    await expect(secs).toBeVisible({ timeout: 10_000 });
    const a = Number((await secs.innerText()).split(":")[1]);
    await page.waitForTimeout(2200);
    const b = Number((await secs.innerText()).split(":")[1]);
    expect(a).toBeGreaterThan(0);
    expect(b).toBeLessThan(a);
    await expect(page.getByTestId("self-turn-ring")).toHaveCount(0);
    const bar = (await page.getByTestId("turn-timer-bar").boundingBox())!;
    const sb = (await secs.boundingBox())!;
    const others: Box[] = [];
    for (const l of [page.getByTestId("match-hand-counter"), page.locator('[data-testid="v2-seat"], .spanish-card, [data-testid^="action-"]')])
      for (const e of await l.filter({ visible: true }).all()) { const bb = await e.boundingBox(); if (bb) others.push(bb); }
    for (const o of others) {
      expect(overlap(sb, o), "els segons tapen alguna cosa").toBe(false);
      expect(overlap({ ...bar, y: bar.y + bar.height - 4, height: 4 }, o), `la barra tapa ${JSON.stringify(o)} bar ${JSON.stringify(bar)}`).toBe(false);
    }
  });
});

test.describe("Doblar v177 @390x844", () => {
  test.use({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  test("Doblar ×2 és una fila pròpia, dobla l'aposta i reparteix una sola carta", async ({ page }) => {
    test.skip(SEED !== "3", "cal SETIMIG_TEST_DECK_SEED=3 (doblar)");
    await startSolo(page);
    await expect(grab(page)).toBeVisible({ timeout: 30_000 });
    await swipe(page, 8, 40, false);
    const dbl = page.getByTestId("mobile-double-chip").filter({ visible: true }).first();
    await expect(dbl).toBeVisible({ timeout: 15_000 });
    const txt = await dbl.innerText();
    expect(txt).toMatch(/×2/);
    const db = (await dbl.boundingBox())!;
    expect(db.height).toBeGreaterThanOrEqual(44);
    // Stand i Hit alineats a la mateixa fila; Doblar no hi és enmig.
    const sb = (await page.getByTestId("action-stand").filter({ visible: true }).first().boundingBox())!;
    const hb = (await page.getByTestId("action-hit").filter({ visible: true }).first().boundingBox())!;
    expect(Math.abs(sb.y - hb.y)).toBeLessThanOrEqual(2);
    expect(overlap(db, sb) || overlap(db, hb)).toBe(false);
    expect(db.y + db.height).toBeLessThanOrEqual(Math.min(sb.y, hb.y) + 1);
    const cardsBefore = await page.locator('[data-card-id]').evaluateAll((es) => new Set(es.map((e) => e.getAttribute("data-card-id"))).size);
    await dbl.click();
    await expect(page.getByTestId("mobile-double-chip")).toHaveCount(0, { timeout: 10_000 });
    await page.waitForTimeout(1500);
    const cardsAfter = await page.locator('[data-card-id]').evaluateAll((es) => new Set(es.map((e) => e.getAttribute("data-card-id"))).size);
    expect(cardsAfter - cardsBefore, "una sola carta").toBe(1);
    // L'aposta doblada es mostra (import del botó).
    const amount = txt.replace(/[^\d]/g, "").replace(/^2/, "");
    await expect(page.locator("body")).toContainText(new RegExp(amount.replace(/(\d)(?=(\d{3})+$)/g, "$1[.,]?")));
  });
  test("el consell no tapa la línia d'aposta", async ({ page }) => {
    test.skip(!SEED, "cal SETIMIG_TEST_DECK_SEED (3 o 217)");
    await startSolo(page);
    await expect(grab(page)).toBeVisible({ timeout: 30_000 });
    await page.waitForTimeout(800);
    const hint = page.locator(".first-hand-hint-pill, [data-testid='first-hand-hint-compact']").filter({ visible: true });
    if (!(await hint.count())) return;
    const hb = (await hint.first().boundingBox())!;
    for (const e of await page.locator(".spanish-card, .v2-seat-foot, [data-testid='my-hand-points'], [data-testid='player-hero-panel'] .num").filter({ visible: true }).all()) {
      const bb = await e.boundingBox();
      if (bb) expect(overlap(hb, bb), "el consell tapa contingut").toBe(false);
    }
  });
});

test.describe("Mort v177 @390x844", () => {
  test.use({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  test("acceptar el Mort gira el 7 cara amunt al client propi", async ({ page }) => {
    test.skip(SEED !== "217", "cal SETIMIG_TEST_DECK_SEED=217 (Mort)");
    await startSolo(page);
    await expect(grab(page)).toBeVisible({ timeout: 30_000 });
    const id = (await host(page).locator("[data-card-id]").first().getAttribute("data-card-id"))!;
    await swipe(page, 8, 40, false);
    await page.getByTestId("mort-accept").click({ timeout: 20_000 });
    await expect(page.locator(`[data-card-id="${id}"][data-face="up"]`).first()).toBeVisible({ timeout: 8_000 });
    // Vista dels rivals: bloquejat al servidor (applyMort no posa faceUp al 7).
  });
});
