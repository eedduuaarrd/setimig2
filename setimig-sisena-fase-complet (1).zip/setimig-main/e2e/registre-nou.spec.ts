import { expect, test, type BrowserContext, type Route } from "@playwright/test";
import { blockSocketIoCtx, openLoginEmail } from "./helpers/loginSession.ts";

/**
 * Registre complet d'un compte nou per correu (P1 QA 28/10, prod 5f02611): correu → codi → 18+ → nom → lobby.
 * /api/auth/email/* simula el contracte REAL de server/auth/emailLogin.ts + authRoutes.ts:
 *  - start desa ageConfirmed al repte; verify CONSUMEIX el repte i, si el compte és nou i no hi ha 18+, respon 403
 *    AGE_CONFIRMATION_REQUIRED; el codi ja no serveix (EXPIRED_OR_USED);
 *  - 3 start per correu i 15 min: el 4t respon 202 però no envia res (límit silenciós).
 * També: Tab després de «Terms» no va mai a enllaços fora de pantalla, i a 1920×1080 el /login queda centrat.
 */
const PID = "registre-nou-01";
const TOKEN = "registre.nou.token";

async function seed(ctx: BrowserContext) {
  await ctx.addInitScript(() => {
    sessionStorage.setItem("setimig_intro_launch_v1", "1");
  });
}

async function mockServer(ctx: BrowserContext) {
  const state = { sends: 0, mails: 0, challenge: null as null | { code: string; age: boolean }, created: false, name: "" };
  await ctx.route("**/api/**", async (route: Route) => {
    const req = route.request();
    const path = new URL(req.url()).pathname.replace(/\/$/, "");
    const body = (req.postDataJSON?.() ?? {}) as Record<string, unknown>;
    const json = (status: number, j: unknown) => route.fulfill({ status, contentType: "application/json", body: JSON.stringify(j) });
    const key = `${req.method()} ${path}`;
    if (key === "GET /api/auth/providers") return json(200, { email: true, google: true, passkey: false, rpId: "sevenhalf.club" });
    if (key === "POST /api/auth/email/start") {
      state.sends += 1;
      if (state.sends <= 3) {
        state.mails += 1;
        state.challenge = { code: String(100000 + state.mails), age: body.ageConfirmed === true };
      }
      return json(202, { ok: true, expiresInSec: 600 });
    }
    if (key === "POST /api/auth/email/verify") {
      const c = state.challenge;
      if (!c) return json(400, { code: "EXPIRED_OR_USED" });
      if (body.code !== c.code) return json(400, { code: "INVALID_CODE" });
      state.challenge = null; // consumit, com verifyEmailLogin
      if (!c.age && body.ageConfirmed !== true) return json(403, { code: "AGE_CONFIRMATION_REQUIRED" });
      state.created = true;
      return json(200, { playerId: PID, playerToken: TOKEN, method: "email", created: true, linked: true, switchedAccount: false });
    }
    if (path === "/api/health") return route.continue();
    if (!state.created) return json(401, { code: "auth_required" });
    if (key === "PUT /api/profile") {
      state.name = String(body.displayName ?? "");
      return json(200, { displayName: state.name, avatarDataUrl: null });
    }
    if (key === "GET /api/profile") return json(200, { displayName: state.name || "Jugador", avatarDataUrl: null });
    if (key === "GET /api/auth/me") return json(200, { playerId: PID, emails: ["nou@example.com"], google: false, passkeys: 0, verified: true });
    // Com el servidor real: sense Bearer ni galeta, 401.
    if (key === "POST /api/player-session" && !route.request().headers()["authorization"]) return json(401, { error: "auth_required" });
    if (key === "POST /api/player-session") return json(200, { playerId: PID, playerToken: TOKEN });
    if (key === "GET /api/balance") return json(200, { chips: 1000, freeClaim: { available: false, nextAt: null } });
    return json(200, { ok: true });
  });
  return state;
}

test("compte nou per correu: codi → 18+ → nom → lobby, sense tornar a la pantalla inicial", async ({ browser }) => {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, locale: "ca-ES", colorScheme: "dark" });
  await seed(ctx);
  await blockSocketIoCtx(ctx);
  const state = await mockServer(ctx);
  const page = await ctx.newPage();
  await page.goto("/login");
  await openLoginEmail(page);
  await page.getByTestId("login-email-input").fill("nou@example.com");
  await page.getByTestId("login-email-submit").click();
  await page.getByTestId("login-code-input").fill(state.challenge!.code);
  await page.getByTestId("login-code-submit").click();

  // Compte nou: 18+ al mateix pas del codi (abans tornava a «Crea un compte» amb el correu buit).
  await expect(page.getByTestId("login-code-step")).toBeVisible();
  await expect(page.getByTestId("login-email-form")).toHaveCount(0);
  await expect(page.getByTestId("login-code-submit")).toBeDisabled();
  await page.getByTestId("login-age-checkbox").check();
  await page.getByTestId("login-code-submit").click();

  // El codi ja s'havia consumit: n'arriba un de nou amb 18+ sense reescriure el correu.
  await expect.poll(() => state.mails).toBe(2);
  await expect(page.getByTestId("login-code-input")).toHaveValue("");
  await page.getByTestId("login-code-input").fill(state.challenge!.code);
  await page.getByTestId("login-code-submit").click();

  await page.getByTestId("login-name-input").fill("Nova");
  await page.getByTestId("login-name-submit").click();
  await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 20_000 });
  expect(state.name).toBe("Nova");
  expect(state.sends).toBeLessThanOrEqual(2); // dins del límit de 3 per correu
  await ctx.close();
});

test("Tab després de «Terms» no va a enllaços fora de pantalla", async ({ browser }) => {
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 }, locale: "ca-ES" });
  await seed(ctx);
  await blockSocketIoCtx(ctx);
  await mockServer(ctx);
  const page = await ctx.newPage();
  await page.goto("/login");
  await page.getByTestId("login-link-terms").focus();
  for (let i = 0; i < 6; i++) {
    await page.keyboard.press("Tab");
    const info = await page.evaluate(() => {
      const el = document.activeElement as HTMLElement | null;
      if (!el || el === document.body) return { body: true, visible: true };
      const r = el.getBoundingClientRect();
      const visible = r.width >= 2 && r.height >= 2 && r.right > 0 && r.bottom > 0 && r.left < innerWidth && r.top < innerHeight && !el.closest(".seo-links");
      return { body: false, visible, tag: el.tagName, text: el.textContent?.slice(0, 40) };
    });
    expect(info.visible, JSON.stringify(info)).toBe(true);
  }
  await expect(page.locator(".seo-links a")).toHaveCount(11); // es queden al DOM per als cercadors
  await ctx.close();
});

test("1920×1080: logo i botons junts i centrats", async ({ browser }) => {
  const ctx = await browser.newContext({ viewport: { width: 1920, height: 1080 }, locale: "ca-ES" });
  await seed(ctx);
  await blockSocketIoCtx(ctx);
  await mockServer(ctx);
  const page = await ctx.newPage();
  await page.goto("/login");
  await expect(page.getByTestId("login-google")).toBeVisible();
  const m = await page.evaluate(() => {
    const logo = document.querySelector('[data-testid="login-logo"]')!.getBoundingClientRect();
    const btn = document.querySelector('[data-testid="login-google"]')!.getBoundingClientRect();
    const main = document.querySelector(".login-v2-main")!.getBoundingClientRect();
    const actions = document.querySelector(".login-v2-actions")!.getBoundingClientRect();
    const top = logo.top;
    const bottom = actions.bottom;
    return { gap: btn.top - logo.bottom, offCentre: (top + bottom) / 2 - (main.top + main.bottom) / 2 };
  });
  console.log("desktop1920", JSON.stringify(m));
  expect(m.gap).toBeLessThanOrEqual(120);
  expect(Math.abs(m.offCentre)).toBeLessThanOrEqual(40);
  await ctx.close();
});
