import { expect, test, type Page } from "@playwright/test";
import { passAgeGateToLobby } from "./helpers/ageGateLobby";
import { createPrivateTable, readInviteCode } from "./helpers/tableFlow";
import { e2ePoolId } from "./helpers/e2eSession.ts";

/**
 * QA v193 (repetició de la QA a la v192, prod 31-10):
 * 1) El xat es tanca sol en començar les apostes i el meu torn, i mai tapa el panell d'aposta ni Plantar-me/Demanar carta.
 *    HIT/STAND funcionen a les mans 2 i 3 (el bloqueig d'acció es reinicia a cada mà/torn).
 * 2) «Aquesta mà ets la banca» és petit, no tapa noms ni POT, i marxa sol als ~2 s.
 * 3) A 1024 la liquidació deixa veure les mans; cap «Es planta» solt.
 * 4) A 1280, cap «Es planta» duplicat ni píndola de resultat damunt de POT/JACKPOT.
 * 5) A 390, el dors gran de la meva carta no tapa el nom de la banca.
 */
type Box = { x: number; y: number; width: number; height: number };
const inter = (a: Box, b: Box) =>
  Math.max(0, Math.min(a.x + a.width, b.x + b.width) - Math.max(a.x, b.x)) * Math.max(0, Math.min(a.y + a.height, b.y + b.height) - Math.max(a.y, b.y));
const visible = (page: Page, id: string) => page.getByTestId(id).filter({ visible: true }).first();

async function skipTutorial(page: Page) {
  for (const id of ["table-tutorial-skip", "interactive-tutorial-skip"]) {
    const sk = page.getByTestId(id);
    if (await sk.isVisible().catch(() => false)) await sk.click().catch(() => {});
  }
}

async function chatIsOpen(page: Page) {
  return (await page.getByTestId("table-chat-sheet").getAttribute("aria-hidden")) !== "true";
}

async function openChat(page: Page) {
  if (await chatIsOpen(page)) return;
  const fab = page.locator('button.fixed[data-testid="table-chat-toggle"]');
  if (await fab.isVisible().catch(() => false)) await fab.click();
  else {
    await page.getByTestId("table-tools-menu").locator("button").first().click();
    await visible(page, "table-chat-toggle").click();
  }
  await expect.poll(() => chatIsOpen(page)).toBe(true);
}

/** El xat obert no pot tapar cap control d'acció visible (aposta o torn). */
async function chatClearsActions(page: Page) {
  const sheet = await page.getByTestId("table-chat-sheet").boundingBox();
  if (!sheet) return [];
  const bad: string[] = [];
  for (const id of ["action-hit", "action-stand", "bet-confirm", "bet-screen"]) {
    const el = visible(page, id);
    if (!(await el.isVisible().catch(() => false))) continue;
    const b = await el.boundingBox();
    if (b && inter(sheet, b) > 4) bad.push(id);
  }
  return bad;
}

async function twoPlayerTable(browser: import("@playwright/test").Browser, vp: { width: number; height: number }) {
  const ctxs = await Promise.all([0, 1].map(() => browser.newContext({ viewport: vp })));
  const pages = await Promise.all(ctxs.map((c) => c.newPage()));
  await passAgeGateToLobby(pages[0], "Amfitrio193", { playerId: e2ePoolId(), online: true });
  await createPrivateTable(pages[0]);
  const code = await readInviteCode(pages[0]);
  await passAgeGateToLobby(pages[1], "Convidat193", { playerId: e2ePoolId(), online: true });
  await pages[1].goto(`/?t=${code}`);
  await expect(pages[1].locator("[data-testid=private-waiting-panel], [data-testid=game-top-bar]").first()).toBeVisible({ timeout: 30_000 });
  await expect(pages[0].getByTestId("start-game-button")).toBeVisible({ timeout: 30_000 });
  await pages[0].getByTestId("start-game-button").click();
  return { ctxs, pages };
}

async function findRoles(pages: Page[]) {
  let player: Page | null = null;
  await expect
    .poll(async () => {
      for (const p of pages) if (await p.getByTestId("bet-screen").isVisible().catch(() => false)) player = p;
      return player != null;
    }, { timeout: 60_000 })
    .toBe(true);
  return { player: player!, bank: pages.find((p) => p !== player)! };
}

test("1024 multijugador: xat tancat a l'aposta i al torn, HIT/STAND a les mans 1-3, liquidació amb mans visibles, banca", async ({ browser }) => {
  test.setTimeout(300_000);
  const vp = { width: 1024, height: 768 };
  const { ctxs, pages } = await twoPlayerTable(browser, vp);
  let { player, bank } = await findRoles(pages);
  for (const p of pages) await skipTutorial(p);

  // 2) Avís de banca: petit, sense tapar noms ni POT, i fora als ~2 s.
  const banner = bank.getByTestId("bank-hand-banner");
  if (await banner.isVisible().catch(() => false)) {
    const bb = (await banner.boundingBox())!;
    for (const loc of [bank.locator(".v2-seat-name").filter({ visible: true }), bank.getByTestId("table-pot").filter({ visible: true })]) {
      for (const b of await loc.all()) {
        const r = await b.boundingBox();
        if (r) expect(inter(bb, r), "l'avís de banca tapa un nom o el POT").toBeLessThan(4);
      }
    }
    expect(bb.height).toBeLessThan(48);
  }
  await expect(banner).toHaveCount(0, { timeout: 3_200 });

  for (let hand = 1; hand <= 3; hand++) {
    if (hand > 1) ({ player, bank } = await findRoles(pages));
    await expect(visible(player, "bet-confirm")).toBeVisible({ timeout: 60_000 });
    expect(await chatIsOpen(player), `mà ${hand}: el xat es tanca en començar les apostes`).toBe(false);
    await openChat(player);
    expect(await chatClearsActions(player), `mà ${hand}: xat sobre l'aposta`).toEqual([]);
    await skipTutorial(player);
    await visible(player, "bet-chip").click().catch(() => {});
    await visible(player, "bet-confirm").click();
    await expect(visible(player, "action-hit")).toBeEnabled({ timeout: 30_000 });
    expect(await chatIsOpen(player), `mà ${hand}: el xat es tanca en començar el meu torn`).toBe(false);
    await openChat(player);
    expect(await chatClearsActions(player), `mà ${hand}: xat sobre Plantar-me/Demanar carta`).toEqual([]);
    // Demano carta (si no em passo) i em planto: els clics han d'arribar (sense «force»).
    await visible(player, "action-hit").click({ timeout: 5_000 });
    await player.waitForTimeout(400);
    const stand = visible(player, "action-stand");
    if (await stand.isVisible().catch(() => false)) {
      await expect(stand).toBeEnabled({ timeout: 8_000 }).catch(() => {});
      if (await stand.isEnabled().catch(() => false)) await stand.click({ timeout: 5_000 });
    }
    // El torn passa: els botons desapareixen o queden desactivats.
    await expect.poll(async () => visible(player, "action-stand").isEnabled().catch(() => false), { timeout: 15_000 }).toBe(false);
    // La banca juga (es planta quan li toca) i arriba la liquidació.
    const end = Date.now() + 60_000;
    while (Date.now() < end && !(await visible(player, "settlement-next-hand").isVisible().catch(() => false))) {
      const bs = visible(bank, "action-stand");
      if (await bs.isEnabled().catch(() => false)) await bs.click({ timeout: 3_000 }).catch(() => {});
      await player.waitForTimeout(300);
    }
    await expect(visible(player, "settlement-next-hand")).toBeVisible({ timeout: 30_000 });
    // 3) La liquidació deixa veure les mans i no hi ha cap «Es planta» solt.
    await player.waitForTimeout(600);
    const card = await player.locator(".v176-settle-card").first().boundingBox();
    if (card) {
      for (const sel of ["[data-testid=v2-seat]", "[data-testid=focus-mine]", ".desktop-hand-panel"]) {
        for (const el of await player.locator(sel).filter({ visible: true }).all()) {
          const r = await el.boundingBox();
          if (r && r.width > 2) expect(inter(card, r) / (r.width * r.height), `${sel} tapat per la liquidació`).toBeLessThan(0.25);
        }
      }
    }
    await expect(player.getByTestId("settled-hand-chip").filter({ hasText: /^Es planta$/ })).toHaveCount(0);
    if (hand < 3) {
      for (const p of pages) {
        const no = p.getByRole("button", { name: /no, gràcies/i }).filter({ visible: true }).first();
        if (await no.isVisible().catch(() => false)) await no.click().catch(() => {});
      }
      for (const p of pages) await visible(p, "settlement-next-hand").click({ timeout: 3_000 }).catch(() => {});
    }
  }
  await Promise.all(ctxs.map((c) => c.close()));
});

test("1280 banca: sense «Es planta» duplicat ni píndola damunt de POT/JACKPOT", async ({ browser }) => {
  test.setTimeout(240_000);
  const { ctxs, pages } = await twoPlayerTable(browser, { width: 1280, height: 720 });
  const { player, bank } = await findRoles(pages);
  for (const p of pages) await skipTutorial(p);
  await visible(player, "bet-confirm").click();
  await expect(visible(player, "action-stand")).toBeEnabled({ timeout: 30_000 });
  await visible(player, "action-stand").click();
  const end = Date.now() + 60_000;
  while (Date.now() < end && !(await visible(bank, "settlement-next-hand").isVisible().catch(() => false))) {
    const bs = visible(bank, "action-stand");
    if (await bs.isEnabled().catch(() => false)) await bs.click({ timeout: 3_000 }).catch(() => {});
    await bank.waitForTimeout(300);
  }
  await expect(visible(bank, "settlement-next-hand")).toBeVisible({ timeout: 30_000 });
  await bank.waitForTimeout(2_500);
  const stands = await bank.getByText(/^Es planta$/).filter({ visible: true }).count();
  expect(stands, "«Es planta» duplicat").toBeLessThanOrEqual(1);
  const pot = await bank.getByTestId("table-pot").filter({ visible: true }).first().boundingBox();
  if (pot) {
    for (const b of await bank.getByTestId("fx-result-badge").all()) {
      const r = await b.boundingBox();
      if (r) expect(inter(r, pot), "píndola sobre POT/JACKPOT").toBeLessThan(4);
    }
  }
  await Promise.all(ctxs.map((c) => c.close()));
});

for (const vp of [{ width: 390, height: 844 }, { width: 1280, height: 720 }]) {
  test(`${vp.width}: el xat obert al meu torn no tapa els botons; a 390 el dors no tapa el nom de la banca`, async ({ browser }) => {
    test.setTimeout(240_000);
    const { ctxs, pages } = await twoPlayerTable(browser, vp);
    const { player } = await findRoles(pages);
    for (const p of pages) await skipTutorial(p);
    await visible(player, "bet-confirm").click();
    await expect(visible(player, "action-hit")).toBeEnabled({ timeout: 30_000 });
    expect(await chatIsOpen(player)).toBe(false);
    if (vp.width === 390) {
      // 5) El nom de la banca queda per sobre de qualsevol carta.
      await player.waitForTimeout(1_200);
      const names = player.locator("[data-seat-banker=true] .v2-seat-name").filter({ visible: true });
      for (const n of await names.all()) {
        const covered = await n.evaluate((el) => {
          const r = el.getBoundingClientRect();
          const top = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
          return !!top && top !== el && !el.contains(top);
        });
        expect(covered, "nom de la banca tapat").toBe(false);
      }
    }
    await openChat(player);
    expect(await chatClearsActions(player)).toEqual([]);
    await visible(player, "action-stand").click({ timeout: 5_000 });
    await Promise.all(ctxs.map((c) => c.close()));
  });
}
