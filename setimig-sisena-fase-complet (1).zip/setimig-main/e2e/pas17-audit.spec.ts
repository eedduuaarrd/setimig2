import { expect, test } from "@playwright/test";
import { e2ePoolId, seedE2eLaunch } from "./helpers/e2eSession.ts";
import fs from "node:fs";
import path from "node:path";
import { splitTurnSnapshotJson } from "./helpers/uxA11yFixtures";

function screenshotDir(): string {
  const candidates = [
    "/cursor/stores/self/media/pas17",
    "/cursor/stores/bc-9b0df142-722d-5c8c-bf32-7c74b1eccf10/media/pas17",
    path.join(process.cwd(), "media/pas17"),
  ];
  for (const dir of candidates) {
    try {
      fs.mkdirSync(dir, { recursive: true });
      return dir;
    } catch {
      /* try next */
    }
  }
  return candidates[candidates.length - 1];
}

async function enterLobby(page: import("@playwright/test").Page) {
  const pid = e2ePoolId();
  await seedE2eLaunch(page, pid, { locale: "ca" });
  await page.addInitScript((pid) => {
    localStorage.setItem("setimig_player_id", pid);
    localStorage.setItem("setimig_player_name", "Pas17Audit");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
  }, pid);
  await page.goto("/");
  const input = page.getByPlaceholder("El teu nom");
  if (await input.isVisible().catch(() => false)) {
    await input.fill("Pas17Audit");
    await page.getByRole("button", { name: "Entrar al lobby" }).click();
  }
  await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 30_000 });
}

test("PAS 17 — bot picker aria-pressed + manifest/robots", async ({ page }) => {
  const OUT = screenshotDir();
  await enterLobby(page);
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  const three = page.getByTestId("ai-bot-count-3");
  await three.click();
  await expect(three).toHaveAttribute("aria-pressed", "true");
  await page.screenshot({ path: path.join(OUT, "bot-picker-aria.png"), fullPage: false });

  const robots = await page.request.get("/robots.txt");
  expect(robots.ok()).toBeTruthy();
  const robotsBody = await robots.text();
  expect(robotsBody).toMatch(/User-agent:\s*\*/);
  expect(robotsBody).toMatch(/Allow:\s*\//);

  const manifest = await page.request.get("/site.webmanifest");
  expect(manifest.ok()).toBeTruthy();
  const json = (await manifest.json()) as { lang?: string; id?: string };
  expect(json.lang).toBe("ca");
  expect(json.id).toBeTruthy();
});

test("PAS 17 — mobile Split is visible, accessible, and creates a second hand", async ({ page }, testInfo) => {
  const playerId = e2ePoolId();
  await seedE2eLaunch(page, playerId, { locale: "ca" });
  await page.setViewportSize({ width: 320, height: 568 });
  await page.addInitScript(
    ({ snapshot, pid }) => {
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", "SplitTest");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_house_rules_enabled", "1");
      localStorage.setItem("setimig_probability_indicators", "1");
      localStorage.setItem(
        "setimig_age_gate",
        JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
      );
      localStorage.setItem("setimig_local_solo_snapshot", snapshot);
      sessionStorage.setItem("setimig_solo_rejoin", "1");
      sessionStorage.setItem("setimig_solo_local", "1");
    },
    { snapshot: splitTurnSnapshotJson(playerId, "SplitTest"), pid: playerId }
  );
  await page.route("**/socket.io/**", (route) => route.abort());
  page.routeWebSocket("**/socket.io/**", (webSocket) => webSocket.close());
  await page.goto("/");

  const split = page.getByTestId("mobile-split-button");
  await expect(split).toBeVisible({ timeout: 30_000 });
  await expect(split).toHaveAccessibleName("Separar la parella del mateix rang en dues mans");
  // Taula gran (v147): sense percentatge de risc (delatava els punts propis).
  await expect(page.getByTestId("hit-bust-risk")).toHaveCount(0);
  const actions = [
    page.getByRole("button", { name: "Plantar-se" }),
    split,
    page.getByRole("button", { name: "Carta" }),
  ];
  const boxes = await Promise.all(actions.map((action) => action.boundingBox()));
  for (const bounds of boxes) {
    expect(bounds).not.toBeNull();
    expect(bounds!.width).toBeGreaterThanOrEqual(44);
    expect(bounds!.height).toBeGreaterThanOrEqual(44);
    expect(bounds!.x).toBeGreaterThanOrEqual(0);
    expect(bounds!.y).toBeGreaterThanOrEqual(0);
    expect(bounds!.x + bounds!.width).toBeLessThanOrEqual(320);
    expect(bounds!.y + bounds!.height).toBeLessThanOrEqual(568);
  }
  for (let i = 0; i < boxes.length; i += 1) {
    for (let j = i + 1; j < boxes.length; j += 1) {
      const a = boxes[i]!;
      const b = boxes[j]!;
      expect(a.x + a.width).toBeLessThanOrEqual(b.x);
    }
  }
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(320);
  await page.screenshot({ path: testInfo.outputPath("mobile-split-320x568.png"), fullPage: false });

  await split.click();
  await expect(page.getByTestId("local-player-seat")).toContainText("Mà 2");
  await expect(split).toHaveCount(0);
});

test("PAS 17 — friends modal CTA visible", async ({ page }) => {
  const OUT = screenshotDir();
  await enterLobby(page);
  await page.getByTestId("play-with-friends-button").click();
  const cta = page.getByTestId("create-private-table-inline");
  await expect(cta).toBeVisible();
  await expect(cta).toHaveClass(/jeweled-action/);
  await page.screenshot({ path: path.join(OUT, "friends-cta.png"), fullPage: false });
});
