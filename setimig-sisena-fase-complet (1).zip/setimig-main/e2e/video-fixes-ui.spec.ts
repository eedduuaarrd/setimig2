import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, mintE2eToken } from "./helpers/e2eSession.ts";

const AGE = () => JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" });

/** Com seedE2eLaunch, però només a la primera càrrega: després de «Tancar sessió» no torna a posar el token. */
async function seedOnce(page: Page, locale: string): Promise<string> {
  const pid = e2ePoolId();
  const token = mintE2eToken(pid);
  await page.addInitScript(
    ({ pid, token, locale, age }) => {
      localStorage.setItem("setimig_age_gate", age);
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      sessionStorage.setItem("setimig_intro_launch_v1", "1");
      localStorage.setItem("setimig.locale", locale);
      if (sessionStorage.getItem("vui_seeded") === "1") return;
      sessionStorage.setItem("vui_seeded", "1");
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_token", token);
      localStorage.setItem("setimig_player_name", "Prova");
    },
    { pid, token, locale, age: AGE() },
  );
  return token;
}

/** Vídeo de l'Edu (iPhone, abans de v151): perfil, perfils d'aposta i tancar sessió. */
const VPS = [
  { w: 375, h: 812 },
  { w: 390, h: 844 },
  { w: 1280, h: 800 },
] as const;

async function openProfile(page: Page) {
  await page.goto("/");
  await page.locator("button.header-profile").first().click({ timeout: 60_000 });
  await expect(page.getByTestId("profile-panel")).toBeVisible({ timeout: 30_000 });
}

for (const vp of VPS) {
  test(`perfil ${vp.w}: capçalera sencera i sense text solt de la foto`, async ({ browser }) => {
    const ctx = await browser.newContext({ viewport: { width: vp.w, height: vp.h }, locale: "en-US" });
    const page = await ctx.newPage();
    await seedOnce(page, "en");
    await openProfile(page);
    const title = page.getByTestId("app-header-title");
    if (await title.isVisible()) {
      const m = await title.evaluate((el) => ({ sw: el.scrollWidth, cw: el.clientWidth }));
      expect(m.sw, "«SEVEN HALF CLUB» sense el·lipsi").toBeLessThanOrEqual(m.cw);
    }
    await expect(page.getByText("resize it automatically", { exact: false })).toHaveCount(0);
    const o = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
    expect(o.sw).toBeLessThanOrEqual(o.cw);
    await ctx.close();
  });
}

test("amb amics: perfils d'aposta tots en català i amb xifres catalanes", async ({ browser }) => {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 } });
  const page = await ctx.newPage();
  await seedOnce(page, "ca");
  await page.goto("/");
  await page.getByTestId("play-with-friends-button").click();
  const opts = await page.getByTestId("private-table-bet-profile").locator("option").allTextContents();
  expect(opts).toEqual(["Manual (mín / màx)", "Baix (50–500)", "Mitjà (100–1.000)", "Alt (250–2.500)", "VIP (500–10.000)"]);
  await ctx.close();
});

for (const vp of [VPS[1], VPS[2]]) {
  test(`tancar sessió ${vp.w}: /login, estat esborrat (idioma i intro es queden) i /api/auth/me → 401`, async ({ browser }) => {
    const ctx = await browser.newContext({ viewport: { width: vp.w, height: vp.h } });
    const page = await ctx.newPage();
    const token = await seedOnce(page, "ca");
    await openProfile(page);
    await page.evaluate(() => localStorage.setItem("setimig_last_bet_amount", "300"));
    const logout = page.getByTestId("profile-logout");
    await logout.scrollIntoViewIfNeeded();
    const resP = page.waitForResponse((r) => r.url().endsWith("/api/auth/logout"), { timeout: 10_000 }).catch(() => null);
    await logout.click();
    const res = await resP;
    console.log("[vui] logout status", res ? res.status() : "cap resposta");
    await page.waitForURL((u) => u.pathname === "/login");
    await expect(page.getByTestId("login-page")).toBeVisible();
    const st = await page.evaluate(() => ({
      id: localStorage.getItem("setimig_player_id"),
      token: localStorage.getItem("setimig_player_token"),
      bet: localStorage.getItem("setimig_last_bet_amount"),
      locale: localStorage.getItem("setimig.locale"),
    }));
    expect(st).toEqual({ id: null, token: null, bet: null, locale: "ca" });
    await expect(page.getByTestId("play-with-friends-button")).toHaveCount(0);
    const me = await page.evaluate(async () => (await fetch("/api/auth/me", { credentials: "include" })).status);
    expect(me, "sense sessió després de sortir").toBe(401);
    const meOld = await page.evaluate(
      async (t) => (await fetch("/api/auth/me", { headers: { Authorization: `Bearer ${t}` } })).status,
      token,
    );
    expect(meOld, "el token d'abans de tancar sessió queda revocat").toBe(401);
    await ctx.close();
  });
}
