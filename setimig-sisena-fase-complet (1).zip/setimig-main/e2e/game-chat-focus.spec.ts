import { expect, test } from "@playwright/test";

test("disconnected table announces reconnect status after the debounce", async ({ page }) => {
  await page.goto("/e2e/fixtures/game-chat-a11y.html?connected=false");

  const overlay = page.getByTestId("reconnect-overlay");
  await expect(overlay).toBeVisible({ timeout: 3_000 });
  await expect(overlay).toHaveAttribute("data-phase", "reconnecting");
  await expect(page.getByRole("status")).toContainText(/Reconnectant|Reconnecting/);
  await page.screenshot({ path: "test-results/reconnect-overlay.png" });
});

test("closed desktop chat controls are skipped by keyboard navigation and reachable when opened", async ({ page }) => {
  await page.setViewportSize({ width: 1280, height: 900 });
  await page.goto("/e2e/fixtures/game-chat-a11y.html");

  const toggle = page.locator('button.fixed[data-testid="table-chat-toggle"]');
  const panel = page.getByTestId("table-chat-sheet");
  const close = panel.locator('button[aria-label="Tancar xat"]');
  const input = panel.locator('input[aria-label="Escriu un missatge al xat"]');

  await expect(toggle).toBeVisible();

  await toggle.focus();
  await page.keyboard.press("Tab");
  await expect(close).not.toBeFocused();
  await expect(input).not.toBeFocused();
  await expect(panel).toHaveAttribute("aria-hidden", "true");
  await expect(panel).toHaveAttribute("inert", "");

  await toggle.click();
  await expect(panel).not.toHaveAttribute("aria-hidden", "true");
  await expect(panel).not.toHaveAttribute("inert");

  await expect(panel).toHaveCSS("opacity", "1");
  await page.keyboard.press("Tab");
  await expect(close).toBeFocused();
  await page.keyboard.press("Tab");
  await expect(input).toBeFocused();
});
