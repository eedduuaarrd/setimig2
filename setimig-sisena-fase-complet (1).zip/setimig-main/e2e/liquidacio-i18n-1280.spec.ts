import { expect, test, type Browser, type Page } from "@playwright/test";
import { threePlayerTurnSnapshot } from "./helpers/jugabilitatV1Fixtures.ts";
import fs from "node:fs";
import path from "node:path";

/**
 * Mà acabada (liquidació):
 * 1) Amb la interfície en anglès (i en castellà), el resum no mostra cap text català del motor
 *    («Banca guanya», «Empat — banca», «banca passada»…), sinó la traducció.
 * 2) El panell de liquidació no tapa la mà del jugador (com al vídeo v2): a 1280 i a 390.
 * Captures opcionals: SETIMIG_LIQ_SHOTS=<carpeta> desa liquidacio-<mida>.png.
 */
const AGE_OK = () => JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" });
const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844, desktop: false },
  { tag: "1280x800", width: 1280, height: 800, desktop: true },
] as const;
const CATALAN = /Banca guanya|Empat — banca|Empat a 7½|banca passada|Mort — perd|Sense canvi|7 i Mig natural|ha fet set i mig|Liquidació(?!n)|\bPassat\b|\bEmpat\b|\bfitxes\b/;

async function openFinishedHand(browser: Browser, vp: (typeof VIEWPORTS)[number], locale: "en" | "es", hits = 0) {
  const ctx = await browser.newContext({
    viewport: { width: vp.width, height: vp.height },
    deviceScaleFactor: vp.desktop ? 1 : 2,
    locale: locale === "en" ? "en-US" : "es-ES",
    colorScheme: "dark",
    reducedMotion: "no-preference",
  });
  const page = await ctx.newPage();
  const pid = `liq-${vp.width}-${Date.now()}`;
  await page.addInitScript(
    ({ snap, pid, age, locale }) => {
      if (sessionStorage.getItem("liq_seeded") === "1") return;
      sessionStorage.setItem("liq_seeded", "1");
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", "Edu");
      localStorage.setItem("setimig.locale", locale);
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_age_gate", age);
      localStorage.setItem("setimig_local_solo_snapshot", snap);
      sessionStorage.setItem("setimig_solo_rejoin", "1");
      sessionStorage.setItem("setimig_solo_local", "1");
    },
    { snap: threePlayerTurnSnapshot(pid, "Edu"), pid, age: AGE_OK(), locale }
  );
  await page.addInitScript(() => {
    (window as unknown as { __cls: number }).__cls = 0;
    (window as unknown as { __clsSettle: number }).__clsSettle = 0;
    new PerformanceObserver((list) => {
      for (const e of list.getEntries() as unknown as { value: number; hadRecentInput: boolean; startTime: number }[]) {
        if (e.hadRecentInput) continue;
        const w = window as unknown as { __cls: number; __clsLog?: string[] };
        w.__cls += e.value;
        const src = (e as unknown as { sources?: { node?: Element }[] }).sources?.map((x) => (x.node as HTMLElement | undefined)?.className?.toString().slice(0, 40) ?? x.node?.nodeName ?? "?").join("+");
        (w.__clsLog ??= []).push(`${e.value.toFixed(3)}:${src}@${Math.round(e.startTime)}`);
        // CLS de la liquidació: des que la taula entra a la fase «settlement».
        if (document.querySelector("[data-game-phase='settlement']")) (w as unknown as { __clsSettle: number }).__clsSettle = ((w as unknown as { __clsSettle?: number }).__clsSettle ?? 0) + e.value;
      }
    }).observe({ type: "layout-shift", buffered: true });
  });
  await page.route("**/socket.io/**", (route) => route.abort());
  await page.goto("/");
  await expect(page.getByTestId("action-stand")).toBeEnabled({ timeout: 30_000 });
  await page.waitForTimeout(600);
  for (let i = 0; i < hits; i += 1) {
    await page.getByTestId("action-hit").click();
    await expect(page.getByTestId("action-hit")).toBeEnabled({ timeout: 15_000 });
    await page.waitForTimeout(500);
  }
  await page.getByTestId("action-stand").click();
  await expect(page.getByTestId("settlement-sheet")).toBeVisible({ timeout: 60_000 });
  // Vídeo v2 (f21): «Next hand» ja hi és, en gris i desactivat, fins al temps mínim.
  const next = page.getByTestId("settlement-next-hand");
  const early = { disabled: await next.isDisabled(), text: (await next.innerText()).trim(), h: (await next.boundingBox())?.height ?? 0 };
  // Deixa acabar l'entrada del panell (≤ 400 ms) abans de mesurar.
  await page.waitForTimeout(900);
  return { ctx, page, early };
}

/** Percentatge de l'àrea de les cartes de la meva mà que tapa la targeta de liquidació. */
async function handCoverage(page: Page) {
  return page.evaluate(() => {
    const card = document.querySelector<HTMLElement>(".settlement-card")!.getBoundingClientRect();
    const roots = document.querySelectorAll<HTMLElement>(
      "[data-testid='local-hand-fan-slot'], [data-testid='local-player-seat'], [data-testid='desktop-self-seat'], .player-hero-panel"
    );
    const seen = new Set<Element>();
    const rects: DOMRect[] = [];
    for (const root of roots) {
      for (const el of root.querySelectorAll<HTMLElement>(".spanish-card, [class*='spanish-card-size'], [data-testid='hand-card'], img")) {
        if (seen.has(el)) continue;
        seen.add(el);
        const r = el.getBoundingClientRect();
        if (r.width > 20 && r.height > 20 && el.checkVisibility({ opacityProperty: true, visibilityProperty: true } as CheckVisibilityOptions)) rects.push(r);
      }
    }
    let total = 0;
    let covered = 0;
    for (const r of rects) {
      total += r.width * r.height;
      const w = Math.max(0, Math.min(r.right, card.right) - Math.max(r.left, card.left));
      const h = Math.max(0, Math.min(r.bottom, card.bottom) - Math.max(r.top, card.top));
      covered += w * h;
    }
    return {
      n: rects.length,
      pct: total ? Math.round((100 * covered) / total) : -1,
      card: [card.left, card.top, card.width, card.height].map(Math.round),
      hand: rects.slice(0, 3).map((r) => [r.left, r.top, r.width, r.height].map(Math.round)),
    };
  });
}

for (const vp of VIEWPORTS) {
  test(`liquidació · ${vp.tag} · en anglès: resum traduït i la mà visible`, async ({ browser }) => {
    const { ctx, page, early } = await openFinishedHand(browser, vp, "en", 2);
    console.log(`[liq ${vp.tag}] next-hand al principi ${JSON.stringify(early)}`);
    expect(early.disabled, "«Next hand» desactivat al principi").toBe(true);
    expect(early.text).toMatch(/^Next hand/);
    expect(early.h).toBeGreaterThanOrEqual(44);
    const sheet = page.getByTestId("settlement-sheet");
    const text = await sheet.innerText();
    console.log(`[liq ${vp.tag}] ${JSON.stringify(text.replace(/\s+/g, " ").slice(0, 300))}`);
    expect(text, "sense català al resum").not.toMatch(CATALAN);
    await expect(sheet.getByTestId("settlement-results")).toContainText(/Bank wins|You win|You lose|Tie|Bust/);

    const cov = await handCoverage(page);
    console.log(`[liq ${vp.tag}] cobertura ${JSON.stringify(cov)}`);
    expect(cov.n, "hi ha cartes de la meva mà").toBeGreaterThan(0);
    expect(cov.pct, "el panell no tapa la mà").toBeLessThanOrEqual(10);

    // Mà acabada com al vídeo: xip del resultat i cartes apilades.
    const chip = page.getByTestId("settled-hand-chip").first();
    await expect(chip).toBeVisible();
    await expect(chip).toHaveText(/^Stands \d/);
    const stack = await page.evaluate(() => {
      const cards = [...document.querySelectorAll<HTMLElement>("[data-testid='local-hand-card'], .desktop-own-hand > *")].filter((e) => e.getBoundingClientRect().width > 20);
      const xs = cards.map((c) => c.getBoundingClientRect().left);
      const w = cards[0]?.getBoundingClientRect().width ?? 0;
      return { n: cards.length, maxStep: xs.length > 1 ? Math.max(...xs.slice(1).map((x, i) => x - xs[i]!)) : 0, w };
    });
    console.log(`[liq ${vp.tag}] pila ${JSON.stringify(stack)}`);
    expect(stack.n).toBeGreaterThanOrEqual(2);
    expect(stack.maxStep, "cartes apilades").toBeLessThan(stack.w * 0.4);
    // Retoc f21 (b): xip a dalt a l'esquerra DINS del panell de la mà; a 390 el full no tapa la puntuació gran;
    // a 1280 la banca té el seu xip i la barra superior fa 56 px (f9/f21). Res retallat ni fora de pantalla.
    const geo = await page.evaluate((desktop) => {
      const rect = (el: Element | null) => (el ? el.getBoundingClientRect() : null);
      const chipEl = document.querySelector("[data-testid='settled-hand-chip']");
      const panelEl = desktop ? chipEl?.closest(".desktop-hand-panel") ?? null : chipEl?.closest("[data-testid='player-hero-panel']") ?? null;
      const clipped = (el: Element | null) => {
        if (!el) return "absent";
        const r = el.getBoundingClientRect();
        if (r.left < 0 || r.top < 0 || r.right > window.innerWidth + 0.5 || r.bottom > window.innerHeight + 0.5) return "fora de pantalla";
        for (let p = el.parentElement; p; p = p.parentElement) {
          const cs = getComputedStyle(p);
          if (!/(hidden|clip|auto|scroll)/.test(cs.overflowX + cs.overflowY)) continue;
          const q = p.getBoundingClientRect();
          if (r.left < q.left - 0.5 || r.top < q.top - 0.5 || r.right > q.right + 0.5 || r.bottom > q.bottom + 0.5) return `retallat per ${p.className.toString().slice(0, 40)}`;
        }
        return "ok";
      };
      const score = document.querySelector(desktop ? "[data-testid='my-hand-points']" : "[data-testid='player-hero-panel'] [data-testid='my-hand-points']");
      const bankChip = document.querySelector("[data-testid='banker-settled-chip']");
      const bar = rect(document.querySelector("[data-testid='game-top-bar']"));
      const r4 = (r: DOMRect | null) => (r ? [r.left, r.top, r.width, r.height].map(Math.round) : null);
      return {
        chip: r4(rect(chipEl)), panel: r4(rect(panelEl)), score: r4(rect(score)), sheet: r4(rect(document.querySelector(".settlement-card"))),
        bankChip: r4(rect(bankChip)), bankChipText: bankChip?.textContent ?? null, barH: bar ? Math.round(bar.height) : -1,
        clip: { chip: clipped(chipEl), score: clipped(score), bankChip: desktop ? clipped(bankChip) : "n/a", next: clipped(document.querySelector("[data-testid='settlement-next-hand']")) },
      };
    }, vp.desktop);
    console.log(`[liq ${vp.tag}] f21b ${JSON.stringify(geo)}`);
    expect(geo.panel, "xip dins d'un panell").not.toBeNull();
    const [cx, cy, cw, ch] = geo.chip!;
    const [px, py, pw, ph] = geo.panel!;
    expect(cx - px, "xip a l'esquerra del panell").toBeGreaterThanOrEqual(0);
    expect(cx - px, "xip a l'esquerra del panell").toBeLessThanOrEqual(24);
    expect(cy - py, "xip a dalt del panell").toBeGreaterThanOrEqual(0);
    expect(cy - py, "xip a dalt del panell").toBeLessThanOrEqual(24);
    expect(cx + cw).toBeLessThanOrEqual(px + pw);
    expect(cy + ch).toBeLessThanOrEqual(py + ph);
    for (const [k, v] of Object.entries(geo.clip)) expect(v, `${k} sense retallar`).toMatch(/^(ok|n\/a)$/);
    if (!vp.desktop) {
      const [, sy, , sh] = geo.score!;
      expect(sy + sh, "el full no tapa la puntuació gran").toBeLessThanOrEqual(geo.sheet![1]);
    } else {
      expect(geo.bankChip, "xip de la banca").not.toBeNull();
      expect(geo.bankChipText ?? "").toMatch(/^(Stands|Bust|Dead)/);
      expect(geo.barH, "barra superior de 56 px").toBeGreaterThanOrEqual(52);
      expect(geo.barH, "barra superior de 56 px").toBeLessThanOrEqual(60);
    }

    const next = page.getByTestId("settlement-next-hand");
    await expect(next).toBeEnabled({ timeout: 15_000 });
    expect((await next.boundingBox())!.height).toBeGreaterThanOrEqual(44);
    const sw = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    expect(sw, "sense desbordament horitzontal").toBeLessThanOrEqual(1);
    const { cls, total, log } = await page.evaluate(() => {
      const w = window as unknown as { __cls: number; __clsLog?: string[] };
      return { cls: (w as unknown as { __clsSettle: number }).__clsSettle, total: w.__cls, log: (w.__clsLog ?? []).slice(-10).join(" | ") };
    });
    console.log(`[liq ${vp.tag}] CLS liquidació ${cls.toFixed(3)} (sessió ${total.toFixed(3)}) ${log}`);
    expect(cls, `CLS de la liquidació ${cls.toFixed(3)} ${log}`).toBeLessThan(0.05);

    const dir = process.env.SETIMIG_LIQ_SHOTS;
    if (dir) {
      fs.mkdirSync(dir, { recursive: true });
      await page.screenshot({ path: path.join(dir, `liquidacio-${vp.tag}.png`) });
    }
    await ctx.close();
  });
}

for (const vp of VIEWPORTS) {
  test(`lobby · ${vp.tag} · CLS en carregar < 0,05`, async ({ browser }) => {
    const ctx = await browser.newContext({ viewport: { width: vp.width, height: vp.height }, deviceScaleFactor: vp.desktop ? 1 : 2, locale: "en-US", colorScheme: "dark" });
    const page = await ctx.newPage();
    await page.addInitScript(({ age, pid }) => {
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", "Edu");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_age_gate", age);
      (window as unknown as { __cls: number }).__cls = 0;
      new PerformanceObserver((list) => {
        for (const e of list.getEntries() as unknown as { value: number; hadRecentInput: boolean }[]) {
          if (!e.hadRecentInput) (window as unknown as { __cls: number }).__cls += e.value;
        }
      }).observe({ type: "layout-shift", buffered: true });
    }, { age: AGE_OK(), pid: `lobby-cls-${vp.width}-${Date.now()}` });
    await page.goto("/");
    await expect(page.getByTestId("play-vs-ai-button")).toBeVisible({ timeout: 30_000 });
    // El socket es connecta i la nota «Connectant…» desapareix: deixem passar uns segons.
    await page.waitForTimeout(4000);
    const cls = await page.evaluate(() => (window as unknown as { __cls: number }).__cls);
    console.log(`[liq lobby ${vp.tag}] CLS ${cls.toFixed(4)}`);
    expect(cls, "CLS del lobby").toBeLessThan(0.05);
    const sw = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
    expect(sw, "lobby sense desbordament horitzontal").toBeLessThanOrEqual(1);
    await ctx.close();
  });

  test(`lobby → taula (represa) · ${vp.tag} · CLS en carregar < 0,05`, async ({ browser }) => {
    // Mateixa entrada que la liquidació: el lobby es veu un instant i la taula el substitueix (abans 0,066 a 390).
    const ctx = await browser.newContext({ viewport: { width: vp.width, height: vp.height }, deviceScaleFactor: vp.desktop ? 1 : 2, locale: "en-US", colorScheme: "dark" });
    const page = await ctx.newPage();
    const pid = `lobby-rejoin-${vp.width}-${Date.now()}`;
    await page.addInitScript(({ snap, pid, age }) => {
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", "Edu");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_age_gate", age);
      localStorage.setItem("setimig_local_solo_snapshot", snap);
      sessionStorage.setItem("setimig_solo_rejoin", "1");
      sessionStorage.setItem("setimig_solo_local", "1");
      const w = window as unknown as { __cls: number; __clsLog: string[] };
      w.__cls = 0;
      w.__clsLog = [];
      new PerformanceObserver((list) => {
        for (const e of list.getEntries() as unknown as { value: number; hadRecentInput: boolean; startTime: number; sources?: { node?: Element }[] }[]) {
          if (e.hadRecentInput) continue;
          w.__cls += e.value;
          w.__clsLog.push(`${e.value.toFixed(3)}:${e.sources?.map((x) => (x.node as HTMLElement | undefined)?.className?.toString().slice(0, 30) ?? "?").join("+")}@${Math.round(e.startTime)}`);
        }
      }).observe({ type: "layout-shift", buffered: true });
    }, { snap: threePlayerTurnSnapshot(pid, "Edu"), pid, age: AGE_OK() });
    await page.goto("/");
    await expect(page.getByTestId("action-stand")).toBeVisible({ timeout: 30_000 });
    await page.waitForTimeout(1500);
    const { cls, log } = await page.evaluate(() => {
      const w = window as unknown as { __cls: number; __clsLog: string[] };
      return { cls: w.__cls, log: w.__clsLog.join(" | ") };
    });
    console.log(`[liq lobby-represa ${vp.tag}] CLS ${cls.toFixed(4)} ${log}`);
    expect(cls, `CLS lobby → taula ${log}`).toBeLessThan(0.05);
    await ctx.close();
  });
}

test("liquidació · 390 · en castellà: resum traduït", async ({ browser }) => {
  const { ctx, page } = await openFinishedHand(browser, VIEWPORTS[0], "es");
  const text = await page.getByTestId("settlement-sheet").innerText();
  console.log(`[liq es] ${JSON.stringify(text.replace(/\s+/g, " ").slice(0, 300))}`);
  expect(text).not.toMatch(CATALAN);
  await expect(page.getByTestId("settlement-results")).toContainText(/Gana la banca|Ganas|Pierdes|Empate|Te has pasado/);
  await ctx.close();
});
