import { expect, test, type Page } from "@playwright/test";
import { ca } from "../src/i18n/locales/ca.ts";
import { en } from "../src/i18n/locales/en.ts";

/**
 * Idioma principal: anglès (ordre d'Edu, 2026-10-26). Només mesures, sense captures.
 * - Context nou, sense res desat i amb el navegador en català: tot en anglès, <html lang="en">,
 *   cap clau i18n visible i cap text del diccionari català, a l'inici, al lobby, al selector de bots i a la partida.
 * - Context amb la preferència «ca» desada: es manté el català.
 */
function leaves(node: unknown, prefix = "", out = new Map<string, string[]>()): Map<string, string[]> {
  for (const [k, v] of Object.entries(node as Record<string, unknown>)) {
    const key = prefix ? `${prefix}.${k}` : k;
    if (typeof v === "string") out.set(key, [v]);
    else if (v && typeof v === "object" && typeof (v as { other?: unknown }).other === "string") out.set(key, Object.values(v as Record<string, string>));
    else leaves(v, key, out);
  }
  return out;
}
const EN = leaves(en);
const CA = leaves(ca);
const KEYS = [...EN.keys()].filter((k) => k.includes("."));
/** Frases catalanes distintives (≥ 2 paraules, sense variables) que no existeixen en anglès. */
const CA_PHRASES = [...CA.entries()]
  .flatMap(([key, vs]) => vs.filter((v) => !EN.get(key)?.includes(v)))
  .map((v) => v.replace(/\*\*/g, "").trim())
  .filter((v) => !v.includes("{") && /\p{L}+\s+\p{L}+/u.test(v) && v.length >= 10);
const CA_WORDS = /\b(fitxes|juga|començar|plantar-se|aposta|partida|banca|taula|demanant|carregant|amb|teva|regles)\b/iu;

async function pageTexts(page: Page): Promise<string[]> {
  return page.evaluate(() => {
    const out: string[] = [];
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    for (let n = walker.nextNode(); n; n = walker.nextNode()) {
      const p = n.parentElement;
      if (!p || p.closest("script, style, noscript, .seo-links, option")) continue;
      const text = (n.textContent ?? "").trim().replace(/\s+/g, " ");
      if (text) out.push(text);
    }
    for (const el of document.querySelectorAll("[aria-label], [title], [placeholder], img[alt]")) {
      if (el.closest(".seo-links")) continue;
      for (const attr of ["aria-label", "title", "placeholder", "alt"]) {
        const v = el.getAttribute(attr)?.trim();
        if (v) out.push(v);
      }
    }
    return out;
  });
}

async function expectEnglish(page: Page, where: string) {
  await expect(page.locator("html")).toHaveAttribute("lang", "en");
  const texts = await pageTexts(page);
  expect(texts.length, `${where}: hi ha text`).toBeGreaterThan(0);
  const joined = texts.join("\n");
  const keys = KEYS.filter((k) => texts.some((t) => t === k || t.includes(` ${k} `) || t.startsWith(`${k} `)));
  const phrases = CA_PHRASES.filter((p) => joined.includes(p));
  const words = texts.filter((t) => CA_WORDS.test(t));
  console.log(`[${where}] textos=${texts.length} claus=${keys.length} frases_ca=${phrases.length} paraules_ca=${words.length}`);
  expect(keys, `${where}: claus i18n visibles`).toEqual([]);
  expect(phrases, `${where}: frases en català`).toEqual([]);
  expect(words, `${where}: paraules en català`).toEqual([]);
}

test.describe("context nou sense preferència (navegador en català)", () => {
  test.use({ locale: "ca-ES" });

  test("l'app surt en anglès a l'inici, al lobby, al selector i a la partida de pràctica", async ({ page }) => {
    await page.goto("/");
    await expect(page.locator("html")).toHaveAttribute("lang", "en");
    expect(await page.evaluate(() => localStorage.getItem("setimig.locale"))).toBeNull();
    const nameInput = page.getByTestId("age-gate-name");
    await expect(nameInput.or(page.getByTestId("lobby-main"))).toBeVisible({ timeout: 60_000 });
    await expect(page.getByTestId("language-select").first()).toHaveValue("en");
    await expectEnglish(page, "inici");

    if (await nameInput.isVisible().catch(() => false)) {
      await nameInput.fill("Ivy");
      await page.getByTestId("age-gate-accept").click();
    }
    await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 60_000 });
    const skip = page.getByTestId("interactive-tutorial-skip");
    if (await skip.isVisible().catch(() => false)) {
      await expectEnglish(page, "tutorial");
      await skip.click();
    }
    await expectEnglish(page, "lobby");

    // Lobby v4.1 (#181): «Jugar» ja no obre el diàleg; la línia de context sí.
    await page.getByTestId("lobby-context").click();
    const picker = page.getByTestId("ai-bot-picker");
    await expect(picker).toBeVisible();
    await expectEnglish(page, "selector de bots");
    await page.getByTestId("ai-bot-count-2").click();
    await picker.getByRole("button", { name: en.common.start, exact: true }).click();
    await expect(page.getByTestId("game-screen-heading")).toBeAttached({ timeout: 60_000 });
    await page.waitForTimeout(1_500);
    await expectEnglish(page, "partida · aposta");

    const bet = page.getByTestId("bet-confirm");
    if (await bet.isVisible().catch(() => false)) {
      await bet.click({ timeout: 5_000 }).catch(() => {});
      const action = page.getByTestId("action-stand").or(page.getByTestId("settlement-next-hand"));
      await action.first().waitFor({ state: "visible", timeout: 60_000 }).catch(() => {});
      await page.waitForTimeout(800);
      await expectEnglish(page, "partida · torn");
    }
  });

  test("el manifest és en anglès i conserva id/start_url/scope", async ({ request }) => {
    const res = await request.get("/site.webmanifest");
    expect(res.ok()).toBe(true);
    const manifest = await res.json();
    expect(manifest.lang).toBe("en");
    expect(manifest.name).toBe("Seven Half Club");
    expect(manifest.description).toMatch(/card game/i);
    expect(manifest.id).toBe("/?source=pwa");
    expect(manifest.start_url).toBe("/?source=pwa");
    expect(manifest.scope).toBe("/");
  });

  test("triar català al selector es desa i es manté en recarregar", async ({ page }) => {
    await page.goto("/");
    const select = page.getByTestId("language-select").first();
    await expect(select).toBeVisible({ timeout: 60_000 });
    await select.selectOption("ca");
    await expect(page.locator("html")).toHaveAttribute("lang", "ca");
    expect(await page.evaluate(() => localStorage.getItem("setimig.locale"))).toBe("ca");
    await page.reload();
    await expect(page.locator("html")).toHaveAttribute("lang", "ca");
    await expect(page.getByTestId("language-select").first()).toHaveValue("ca");
  });
});

test.describe("context amb preferència «ca» desada (navegador en anglès)", () => {
  test.use({ locale: "en-US" });

  test("conserva el català", async ({ page }) => {
    await page.addInitScript(() => {
      localStorage.setItem("setimig.locale", "ca");
      localStorage.setItem("setimig_player_id", `e2e-ca-${Date.now()}`);
      localStorage.setItem("setimig_player_name", "Pere");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
    });
    await page.goto("/");
    await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 60_000 });
    await expect(page.locator("html")).toHaveAttribute("lang", "ca");
    await expect(page.getByTestId("play-vs-ai-button")).toBeVisible();
    const texts = (await pageTexts(page)).join("\n");
    const caHits = CA_PHRASES.filter((p) => texts.includes(p)).length;
    console.log(`[ca desat] frases_ca=${caHits}`);
    expect(caHits).toBeGreaterThan(0);
  });
});
