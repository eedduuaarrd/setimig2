import { expect, test } from "@playwright/test";
import { startAiGameFromLobby } from "./helpers/aiLobby";
import fs from "node:fs";
import path from "node:path";

const VIEWPORTS = [
  { name: "360x640", width: 360, height: 640 },
  { name: "390x844", width: 390, height: 844 },
  { name: "430x932", width: 430, height: 932 },
  { name: "1280x720", width: 1280, height: 720 },
] as const;

function screenshotDir(): string {
  const candidates = [
    "/cursor/stores/bc-9b0df142-722d-5c8c-bf32-7c74b1eccf10/media/pas7",
    path.join(process.cwd(), "media/pas7"),
  ];
  for (const dir of candidates) {
    try {
      fs.mkdirSync(dir, { recursive: true });
      return dir;
    } catch {
      /* try next */
    }
  }
  return candidates[1];
}

async function enterName(page: import("@playwright/test").Page, name: string) {
  const input = page.getByPlaceholder("El teu nom");
  if (await input.isVisible().catch(() => false)) {
    await input.fill(name);
    await page.getByRole("button", { name: "Entrar al lobby" }).click();
  }
}

async function startFiveBotHand(page: import("@playwright/test").Page, label: string) {
  const playerId = `pas7viewport${label.replace(/\W/g, "").slice(0, 24)}`;
  await page.addInitScript((id: string) => {
    localStorage.setItem("setimig_player_id", id);
    localStorage.setItem("setimig_player_name", "Pas7Viewport");
  }, playerId);
  await page.goto("/");
  await enterName(page, "Pas7Viewport");
  await startAiGameFromLobby(page, 5);
  await expect(page.getByRole("button", { name: "Sortir" })).toBeVisible({ timeout: 45_000 });
  await expect(page.getByTestId("game-seat-grid")).toBeAttached({ timeout: 60_000 });
  await expect(page.getByRole("button", { name: "Sortir" })).toBeVisible();
  const betBtn = page.getByTestId("bet-confirm");
  if (await betBtn.isVisible().catch(() => false)) {
    await betBtn.click();
  }
  await page.waitForTimeout(2500);
}

async function assertNoPageScroll(page: import("@playwright/test").Page) {
  const metrics = await page.evaluate(() => ({
    doc: document.documentElement.scrollHeight,
    inner: window.innerHeight,
    body: document.body.scrollHeight,
  }));
  expect(metrics.doc).toBeLessThanOrEqual(metrics.inner + 2);
  expect(metrics.body).toBeLessThanOrEqual(metrics.inner + 2);
}

for (const vp of VIEWPORTS) {
  test.describe(`PAS 7 viewport ${vp.name}`, () => {
    test(`portrait — no scroll, screenshot (${vp.name})`, async ({ page }) => {
      const OUT = screenshotDir();
      await page.setViewportSize({ width: vp.width, height: vp.height });
      await startFiveBotHand(page, `${vp.name}-portrait`);
      await assertNoPageScroll(page);
      await page.screenshot({ path: path.join(OUT, `${vp.name}-portrait.png`), fullPage: false });
    });

    test(`landscape — no scroll, screenshot (${vp.name})`, async ({ page }) => {
      const OUT = screenshotDir();
      await page.setViewportSize({ width: vp.height, height: vp.width });
      await startFiveBotHand(page, `${vp.name}-landscape`);
      await assertNoPageScroll(page);
      await page.screenshot({ path: path.join(OUT, `${vp.name}-landscape.png`), fullPage: false });
    });
  });
}
