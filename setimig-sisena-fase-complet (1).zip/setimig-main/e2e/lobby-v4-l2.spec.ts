import AxeBuilder from "@axe-core/playwright";
import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eLaunch } from "./helpers/e2eSession.ts";

/** Lobby v4 · PR-L2 (lobby-v4.md §2.5, §2.7 criteris 1–3, 5 i 6 + axe; el mode clar §2.6 està desactivat: tot fosc). Només mesures calculades, sense captures. */
const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844 },
  { tag: "375x667", width: 375, height: 667 },
  { tag: "360x740", width: 360, height: 740 },
] as const;

async function seedLobby(page: Page, _label: string) {
  // Sessió real (login obligatori): compte e2e del pool + intro ja vista.
  const id = e2ePoolId();
  await seedE2eLaunch(page, id);
  await page.addInitScript(
    ({ pid, age }) => {
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", "LobbyL2");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_home_intro_v1", "1");
      localStorage.setItem("setimig_age_gate", age);
      // En muntar-se el lobby, captura totes les seves animacions (abans que acabin).
      const w = window as unknown as { __lobbyAnims?: unknown[]; __lobbyMountAt?: number };
      const mo = new MutationObserver(() => {
        const shell = document.querySelector(".lobby-shell");
        if (!shell || w.__lobbyMountAt) return;
        w.__lobbyMountAt = performance.now();
        w.__lobbyAnims = document.getAnimations().map((a) => {
          const effect = a.effect as KeyframeEffect | null;
          const target = effect?.target as Element | null;
          const timing = effect?.getComputedTiming();
          const props = new Set<string>();
          for (const kf of effect?.getKeyframes() ?? []) for (const k of Object.keys(kf)) props.add(k);
          return {
            name: (a as CSSAnimation).animationName ?? a.constructor.name,
            inLobby: !!target && shell.contains(target),
            target: target ? `${target.tagName.toLowerCase()}.${String(target.getAttribute("class") ?? "").split(" ").slice(0, 2).join(".")}` : "",
            duration: Number(timing?.duration ?? 0),
            delay: Number(timing?.delay ?? 0),
            endTime: Number(timing?.endTime ?? 0),
            iterations: timing?.iterations === Infinity ? "Infinity" : Number(timing?.iterations ?? 1),
            props: Array.from(props),
          };
        });
      });
      mo.observe(document, { childList: true, subtree: true });
    },
    { pid: id, age: JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }) }
  );
}

async function openLobby(page: Page) {
  await page.goto("/");
  await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 60_000 });
}

/** Espera que no quedi cap animació viva al lobby i torna el temps des del muntatge. */
async function motionReport(page: Page) {
  return page.evaluate(async () => {
    const w = window as unknown as { __lobbyAnims?: Array<Record<string, unknown>>; __lobbyMountAt?: number };
    const shell = document.querySelector(".lobby-shell") as HTMLElement;
    const running = () =>
      document.getAnimations().filter((a) => {
        const t = (a.effect as KeyframeEffect | null)?.target as Element | null;
        return !!t && shell.contains(t) && a.playState === "running";
      }).length;
    const t0 = performance.now();
    while (running() > 0 && performance.now() - t0 < 3000) await new Promise((r) => requestAnimationFrame(r));
    const settledAt = performance.now();
    const docInfinite = document.getAnimations().filter((a) => (a.effect as KeyframeEffect | null)?.getComputedTiming().iterations === Infinity).length;
    // Cap regla de full d'estil amb transition: all (o transition-property: all).
    const allRules: string[] = [];
    for (const sheet of Array.from(document.styleSheets)) {
      let rules: CSSRuleList;
      try {
        rules = sheet.cssRules;
      } catch {
        continue;
      }
      const walk = (list: CSSRuleList) => {
        for (const r of Array.from(list)) {
          if ("cssRules" in r && (r as CSSGroupingRule).cssRules) walk((r as CSSGroupingRule).cssRules);
          if (/transition(-property)?\s*:\s*all\b/.test(r.cssText)) allRules.push(r.cssText.slice(0, 80));
        }
      };
      walk(rules);
    }
    const allComputed = Array.from(document.querySelectorAll("*"))
      .filter((el) => {
        const cs = getComputedStyle(el);
        return cs.transitionProperty.split(",").some((p) => p.trim() === "all") && cs.transitionDuration.split(",").some((d) => parseFloat(d) > 0);
      })
      .map((el) => `${el.tagName.toLowerCase()}.${String(el.getAttribute("class") ?? "").slice(0, 40)}`);
    return {
      anims: (w.__lobbyAnims ?? []).filter((a) => a.inLobby),
      settledMs: Math.round(settledAt - (w.__lobbyMountAt ?? settledAt)),
      docInfinite,
      allRules,
      allComputed,
      intro: shell.getAttribute("data-intro"),
    };
  });
}

/** Criteris 1 (sense scroll) i 4 (objectius ≥ 44) de PR-L1. */
async function l1Basics(page: Page) {
  return page.evaluate(() => {
    const shell = document.querySelector(".lobby-shell") as HTMLElement;
    const main = document.querySelector("main") as HTMLElement;
    const small = Array.from(main.querySelectorAll("button, a, summary"))
      .map((el) => ({ el, r: el.getBoundingClientRect() }))
      .filter(({ r }) => r.width > 0 && r.height > 0 && (r.width < 44 || r.height < 44))
      .map(({ el, r }) => `${el.textContent?.trim().slice(0, 20)} ${Math.round(r.width)}x${Math.round(r.height)}`);
    return {
      shellScroll: shell.scrollHeight,
      shellClient: shell.clientHeight,
      docScroll: document.documentElement.scrollHeight,
      innerHeight: window.innerHeight,
      small,
    };
  });
}

const axeViolations = async (page: Page) =>
  (await new AxeBuilder({ page }).analyze()).violations.map((v) => `${v.id}: ${v.nodes.map((n) => n.target.join(" ")).join(" | ")}`);

for (const vp of VIEWPORTS) {
  test.describe(`lobby v4 L2 ${vp.tag}`, () => {
    test.use({ viewport: { width: vp.width, height: vp.height } });

    test(`criteris 1–2: animacions ≤ 600 ms, només transform/opacity, un cop per sessió (${vp.tag})`, async ({ page }) => {
      await seedLobby(page, `lobby-l2-m-${vp.tag}`);
      await openLobby(page);
      const m = await motionReport(page);
      console.log(`[lobby-v4-l2] motion ${vp.tag} ${JSON.stringify(m)}`);
      expect(m.intro).toBe("true");
      const names = m.anims.map((a) => a.name);
      expect(names).toEqual(expect.arrayContaining(["lobby-v4-symbol-in", "lobby-v4-rise"]));
      const logo = page.locator('[data-testid="lobby-hero-symbol"]');
      await expect(logo).toHaveAttribute("src", /\/brand\/logo-splash-v163/);
      const logoBox = await logo.boundingBox();
      expect(logoBox?.height ?? 0).toBeGreaterThanOrEqual(160);
      // v163: logo més gran (cartes a min(45vw, 30vh) + halo).
      expect(logoBox?.height ?? 0).toBeLessThanOrEqual(vp.height * 0.5);
      for (const a of m.anims) {
        expect(a.iterations).not.toBe("Infinity");
        expect(a.endTime as number).toBeLessThanOrEqual(600);
        expect((a.props as string[]).filter((p) => !["transform", "opacity", "offset", "easing", "composite", "computedOffset"].includes(p))).toEqual([]);
      }
      const sym = m.anims.find((a) => a.name === "lobby-v4-symbol-in");
      expect(sym?.duration).toBe(320);
      const rise = m.anims.filter((a) => a.name === "lobby-v4-rise").map((a) => [a.delay, a.duration]);
      expect(rise).toEqual([[160, 240], [220, 240], [280, 240]]);
      expect(m.settledMs).toBeLessThanOrEqual(700);
      expect(m.docInfinite).toBe(0);
      expect(m.allRules).toEqual([]);
      expect(m.allComputed).toEqual([]);

      // L1 un sol cop per sessió: en recarregar la pestanya, el símbol ja no s'anima.
      await page.reload();
      await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 60_000 });
      const again = await motionReport(page);
      expect(again.intro).toBeNull();
      expect(again.anims.map((a) => a.name)).not.toContain("lobby-v4-symbol-in");

      // L3 premut: scale .98 en 90 ms.
      const press = await page.evaluate(() => {
        const cta = document.querySelector('[data-testid="play-vs-ai-button"]') as HTMLElement;
        const cs = getComputedStyle(cta);
        return { prop: cs.transitionProperty, dur: cs.transitionDuration };
      });
      expect(press).toEqual({ prop: "transform", dur: "0.09s" });
      const cta = page.getByTestId("play-vs-ai-button");
      const box = await cta.boundingBox();
      await page.mouse.move(box!.x + box!.width / 2, box!.y + box!.height / 2);
      await page.mouse.down();
      await page.waitForTimeout(150);
      const pressed = await cta.evaluate((el) => getComputedStyle(el).transform);
      await page.mouse.up();
      console.log(`[lobby-v4-l2] press ${vp.tag} ${pressed}`);
      expect(pressed).toBe("matrix(0.98, 0, 0, 0.98, 0, 0)");
    });

    test(`criteris 3 i 5: reduced-motion només opacity ≤ 120 ms (${vp.tag})`, async ({ page }) => {
      await page.emulateMedia({ reducedMotion: "reduce" });
      await seedLobby(page, `lobby-l2-r-${vp.tag}`);
      await openLobby(page);
      const m = await motionReport(page);
      console.log(`[lobby-v4-l2] reduced ${vp.tag} ${JSON.stringify(m.anims)} settled ${m.settledMs}`);
      expect(m.anims.length).toBeGreaterThan(0);
      for (const a of m.anims) {
        expect(a.props as string[]).not.toContain("transform");
        expect(a.endTime as number).toBeLessThanOrEqual(120);
      }
      const b = await l1Basics(page);
      console.log(`[lobby-v4-l2] reduced L1 ${vp.tag} ${JSON.stringify(b)}`);
      expect(b.shellScroll).toBeLessThanOrEqual(b.shellClient);
      expect(b.docScroll).toBeLessThanOrEqual(b.innerHeight);
      expect(b.small).toEqual([]);
      expect(await axeViolations(page)).toEqual([]);
    });

    test(`el mode clar del sistema no s'activa: tot es queda fosc (${vp.tag})`, async ({ page }) => {
      await page.emulateMedia({ colorScheme: "light" });
      await seedLobby(page, `lobby-l2-l-${vp.tag}`);
      await openLobby(page);
      await motionReport(page);
      const c = await page.evaluate(() => {
        const cta = getComputedStyle(document.querySelector('[data-testid="play-vs-ai-button"]')!);
        return {
          light: matchMedia("(prefers-color-scheme: light)").matches,
          bodyBg: getComputedStyle(document.body).backgroundColor,
          ctaBg: cta.backgroundColor,
          ctaColor: cta.color,
        };
      });
      console.log(`[lobby-v4-l2] os-light ${vp.tag} ${JSON.stringify(c)}`);
      expect(c.light).toBe(true);
      expect(c.bodyBg).toBe("rgb(11, 11, 11)");
      expect(c.ctaBg).toBe("rgb(245, 242, 235)");
      expect(c.ctaColor).toBe("rgb(11, 11, 11)");
      const b = await l1Basics(page);
      expect(b.shellScroll).toBeLessThanOrEqual(b.shellClient);
      expect(b.docScroll).toBeLessThanOrEqual(b.innerHeight);
      expect(b.small).toEqual([]);
      expect(await axeViolations(page)).toEqual([]);
    });

    test(`criteri 6: «Jugar» → taula, primer frame ≤ 200 ms (L4 no bloqueja) (${vp.tag})`, async ({ page }) => {
      await seedLobby(page, `lobby-l2-n-${vp.tag}`);
      await openLobby(page);
      await motionReport(page);
      // Lobby v4.1 C5: «Jugar» ja no obre el diàleg; la línia de context sí.
      await page.getByTestId("lobby-context").click();
      await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
      await page.getByTestId("ai-bot-count-1").click();
      const start = page.getByRole("button", { name: "Començar" });
      await start.evaluate((btn) => {
        const w = window as unknown as { __nav?: { click?: number; stage?: number; root?: number; lobbyGone?: number } };
        w.__nav = {};
        btn.addEventListener("click", () => (w.__nav!.click = performance.now()), { capture: true, once: true });
        const tick = () => {
          const nav = w.__nav!;
          const now = performance.now();
          const stage = document.querySelector('[data-testid="table-stage"]') as HTMLElement | null;
          if (nav.click && stage && nav.stage === undefined && Number(getComputedStyle(stage).opacity) > 0) nav.stage = now - nav.click;
          if (nav.click && nav.root === undefined && document.querySelector(".game-table-root")) nav.root = now - nav.click;
          if (nav.click && nav.lobbyGone === undefined && !document.querySelector(".lobby-shell")) nav.lobbyGone = now - nav.click;
          if (nav.root === undefined || nav.lobbyGone === undefined) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
      });
      await start.click();
      await expect(page.locator(".game-table-root")).toBeVisible({ timeout: 20_000 });
      await expect.poll(() => page.evaluate(() => (window as unknown as { __nav: { lobbyGone?: number } }).__nav.lobbyGone)).not.toBeUndefined();
      const nav = await page.evaluate(() => (window as unknown as { __nav: Record<string, number> }).__nav);
      console.log(`[lobby-v4-l2] nav ${vp.tag} ${JSON.stringify(nav)}`);
      // Sense fade de table-stage, el primer frame és el de .game-table-root.
      expect(nav.stage ?? nav.root).toBeLessThanOrEqual(200);
      expect(nav.lobbyGone).toBeLessThanOrEqual(400);
    });

    test(`axe 0 en fosc (${vp.tag})`, async ({ page }) => {
      await seedLobby(page, `lobby-l2-a-${vp.tag}`);
      await openLobby(page);
      await motionReport(page);
      expect(await axeViolations(page)).toEqual([]);
    });
  });
}
