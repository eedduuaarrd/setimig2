import { expect, test, type Browser, type Page } from "@playwright/test";
import { barallaSnapshot } from "./helpers/jugabilitatV1Fixtures.ts";

/**
 * Baralla E «Renaixement gravat» + revers L2b (cartes-final/nota-app-pwa.md).
 * - Cares i reversos nous a la taula (mà pròpia, banca tapada, banca destapada, mà acabada) i al tutorial («Guia»).
 * - Cada src és un recurs de /baralla/ amb hash, i el hash coincideix amb el contingut (sha256, 8 caràcters).
 * - 280 si la carta fa ≤ 100 px, 520 si en fa més. A ≥ 72 px el pal de l'índex fa ≥ 13 px; per sota, la placa de
 *   baix s'amaga. La mà pròpia mai baixa de 72 px.
 * - Sense desbordament a 390 i 1280. Precache del SW ≤ ~400 KB i SW v112.
 * Captures opcionals: SETIMIG_BARALLA_SHOTS=<directori> → baralla-<vp>-{ma,banca-tapada,banca-destapada,acabada}.png
 */
const AGE_OK = () => JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" });
const SHOTS = process.env.SETIMIG_BARALLA_SHOTS;
const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844, dsf: 2 },
  { tag: "1280x800", width: 1280, height: 800, dsf: 1 },
] as const;
type Vp = (typeof VIEWPORTS)[number];

async function openTable(browser: Browser, vp: Vp, opts: { viewerBank?: boolean } = {}) {
  const ctx = await browser.newContext({ viewport: { width: vp.width, height: vp.height }, deviceScaleFactor: vp.dsf, locale: "en-US", colorScheme: "dark" });
  const page = await ctx.newPage();
  const pid = `baralla-${vp.width}-${opts.viewerBank ? "b" : "p"}-${Date.now()}`;
  await page.addInitScript(
    ({ snap, pid, age }) => {
      if (sessionStorage.getItem("bx_seeded") === "1") return;
      sessionStorage.setItem("bx_seeded", "1");
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", "Edu");
      localStorage.setItem("setimig.locale", "en");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_house_rules_enabled", "1");
      localStorage.setItem("setimig_age_gate", age);
      localStorage.setItem("setimig_local_solo_snapshot", snap);
      sessionStorage.setItem("setimig_solo_rejoin", "1");
      sessionStorage.setItem("setimig_solo_local", "1");
    },
    { snap: barallaSnapshot(pid, "Edu", opts), pid, age: AGE_OK() }
  );
  await page.route("**/socket.io/**", (route) => route.abort());
  await page.goto("/");
  return { ctx, page };
}

type CardProbe = {
  face: string;
  id: string | null;
  w: number;
  tier: string | null;
  mini: boolean;
  srcs: string[];
  loaded: boolean;
  indexSuitPx: number;
  glyphPx: number;
  bottomPlate: boolean;
  oldArt: boolean;
};

async function probeCards(page: Page, selector = ".spanish-card") {
  // Les imatges i el sprite han d'haver carregat abans de mesurar.
  await page.waitForFunction(
    (sel) => [...document.querySelectorAll<HTMLImageElement>(`${sel} img`)].every((i) => i.complete && i.naturalWidth > 0),
    selector,
    { timeout: 20_000 }
  );
  return page.evaluate((sel) => {
    const out: CardProbe[] = [];
    for (const c of document.querySelectorAll<HTMLElement>(sel)) {
      const r = c.getBoundingClientRect();
      if (r.width === 0 || getComputedStyle(c).visibility === "hidden") continue;
      const up = c.dataset.face === "up";
      const layer = c.querySelector<HTMLElement>(up ? ".card-face .baralla-carta" : ".card-back .baralla-carta");
      const imgs = layer ? [...layer.querySelectorAll<HTMLImageElement>("img")] : [];
      const suit = layer?.querySelector<SVGUseElement>("svg.marc > use[href^='#bx-p-']");
      const plate = layer?.querySelector<SVGGElement>(".placa-baix");
      out.push({
        face: c.dataset.face ?? "",
        id: layer?.dataset.barallaId ?? null,
        // Amplada CSS sense la rotació del ventall.
        w: c.offsetWidth,
        tier: layer?.dataset.tier ?? null,
        mini: c.hasAttribute("data-baralla-mini"),
        srcs: imgs.map((i) => new URL(i.currentSrc || i.src).pathname),
        loaded: imgs.length > 0 && imgs.every((i) => i.complete && i.naturalWidth > 0),
        // Caixa del pal de l'índex (46,8 de 250 unitats): la «~13 px a 72 px» de la nota. glyphPx: el traç dibuixat.
        indexSuitPx: suit ? Math.round(((Number(suit.getAttribute("width")) / 250) * c.offsetWidth) * 10) / 10 : 0,
        glyphPx: suit ? Math.round(suit.getBoundingClientRect().width * 10) / 10 : 0,
        bottomPlate: plate ? getComputedStyle(plate).display !== "none" : false,
        oldArt: !!c.querySelector(".spanish-card-back-art, .spanish-figure, .suit-pip"),
      });
    }
    return out;
  }, selector);
}

function expectNewDeck(cards: CardProbe[]) {
  expect(cards.length).toBeGreaterThan(0);
  for (const c of cards) {
    expect(c.oldArt, "sense l'art antic").toBe(false);
    expect(c.loaded, `imatges carregades ${JSON.stringify(c)}`).toBe(true);
    for (const s of c.srcs) expect(s).toMatch(/^\/baralla\/(cares\/)?[\w-]+\.[0-9a-f]{8}\.(avif|webp)$/);
    if (c.face === "up") {
      expect(c.id).toMatch(/^([1-7]|S|C|R)-(oros|copes|espases|bastos)$/);
      expect(c.tier).toBe(c.w > 100 ? "520" : "280");
      // Chromium llegeix AVIF: la il·lustració, els pips i el paper surten de l'AVIF.
      for (const s of c.srcs) expect(s).toMatch(/\.avif$/);
      for (const s of c.srcs.filter((x) => x.includes("/cares/"))) expect(s).toContain(`-${c.tier}.`);
      if (c.w >= 72) {
        expect(c.mini).toBe(false);
        expect(c.bottomPlate).toBe(true);
        expect(c.indexSuitPx, `pal de l'índex a ${c.w} px`).toBeGreaterThanOrEqual(13);
        expect(c.glyphPx, `traç del pal de l'índex a ${c.w} px`).toBeGreaterThanOrEqual(7);
      } else {
        expect(c.mini, `carta de ${c.w} px: placa de baix amagada`).toBe(true);
        expect(c.bottomPlate).toBe(false);
      }
    } else {
      expect(c.srcs.length).toBe(1);
      expect(c.srcs[0]).toMatch(/^\/baralla\/dors-(2x|3x)\.[0-9a-f]{8}\.webp$/);
    }
  }
}

/** El hash del nom = els 8 primers caràcters del sha256 del contingut. */
async function expectHashesMatch(page: Page, paths: string[]) {
  const bad = await page.evaluate(async (list) => {
    const wrong: string[] = [];
    for (const p of list) {
      const buf = await (await fetch(p)).arrayBuffer();
      const hex = [...new Uint8Array(await crypto.subtle.digest("SHA-256", buf))].map((b) => b.toString(16).padStart(2, "0")).join("");
      if (!p.includes(`.${hex.slice(0, 8)}.`)) wrong.push(p);
    }
    return wrong;
  }, [...new Set(paths)]);
  expect(bad).toEqual([]);
}

async function expectNoOverflow(page: Page) {
  const m = await page.evaluate(() => ({ vw: innerWidth, vh: innerHeight, sw: document.documentElement.scrollWidth, sh: document.documentElement.scrollHeight }));
  expect(m.sw).toBeLessThanOrEqual(m.vw);
  expect(m.sh).toBeLessThanOrEqual(m.vh);
}

async function shot(page: Page, name: string, clip?: { x: number; y: number; width: number; height: number }) {
  if (SHOTS) await page.screenshot({ path: `${SHOTS}/${name}.png`, clip });
}

for (const vp of VIEWPORTS) {
  test(`baralla E + L2b · ${vp.tag} · mà, banca tapada i mà acabada`, async ({ browser }) => {
    const { ctx, page } = await openTable(browser, vp);
    await expect(page.getByTestId("action-hit")).toBeEnabled({ timeout: 30_000 });
    await page.waitForTimeout(1200);

    const all = await probeCards(page);
    console.log(`[baralla ${vp.tag} mà] ${JSON.stringify(all.map(({ srcs: _s, ...r }) => r))}`);
    expectNewDeck(all);
    // Les úniques cartes destapades són les meves (la banca és tapada).
    const mine = all.filter((c) => c.face === "up");
    expect(mine.map((c) => c.id).sort()).toEqual(["6-oros", "R-copes"]);
    for (const c of mine) expect(c.w, "la mà pròpia no baixa de 72 px").toBeGreaterThanOrEqual(72);
    const backs = all.filter((c) => c.face === "down");
    expect(backs.length, "la banca té cartes tapades").toBeGreaterThanOrEqual(2);
    await expectHashesMatch(page, all.flatMap((c) => c.srcs));
    expect(await page.locator("#baralla-sprite").count()).toBe(1);
    await expectNoOverflow(page);
    await shot(page, `baralla-${vp.tag}-ma`);

    // Banca tapada: retall al voltant de les cartes tapades (i la captura sencera de la taula a «-ma»).
    const box = await page.evaluate(() => {
      const rs = [...document.querySelectorAll<HTMLElement>(".spanish-card[data-face='down']")].map((c) => c.getBoundingClientRect()).filter((r) => r.width > 0);
      const x0 = Math.min(...rs.map((r) => r.left)), y0 = Math.min(...rs.map((r) => r.top));
      const x1 = Math.max(...rs.map((r) => r.right)), y1 = Math.max(...rs.map((r) => r.bottom));
      const pad = 48;
      const x = Math.max(0, x0 - pad), y = Math.max(0, y0 - pad);
      return { x, y, width: Math.min(innerWidth, x1 + pad) - x, height: Math.min(innerHeight, y1 + pad) - y };
    });
    await shot(page, `baralla-${vp.tag}-banca-tapada`, box);

    // Mà acabada: em planto, la banca juga i es destapa tot.
    await page.getByTestId("action-stand").click();
    await expect(page.getByTestId("settlement-next-hand")).toBeVisible({ timeout: 60_000 });
    await page.waitForTimeout(1500);
    const done = await probeCards(page);
    console.log(`[baralla ${vp.tag} acabada] ${JSON.stringify(done.map(({ srcs: _s, ...r }) => r))}`);
    expectNewDeck(done);
    expect(done.filter((c) => c.face === "up").length).toBeGreaterThanOrEqual(4);
    await expectNoOverflow(page);
    await shot(page, `baralla-${vp.tag}-acabada`);
    await ctx.close();
  });

  test(`baralla E + L2b · ${vp.tag} · banca destapada`, async ({ browser }) => {
    const { ctx, page } = await openTable(browser, vp, { viewerBank: true });
    await expect(page.locator(".spanish-card[data-face='up']").first()).toBeVisible({ timeout: 30_000 });
    await page.waitForTimeout(1200);
    const all = await probeCards(page);
    console.log(`[baralla ${vp.tag} banca] ${JSON.stringify(all.map(({ srcs: _s, ...r }) => r))}`);
    expectNewDeck(all);
    const ids = all.filter((c) => c.face === "up").map((c) => c.id);
    for (const id of ["1-espases", "C-oros", "5-copes"]) expect(ids).toContain(id);
    // Pips del 5 de copes: cinc imatges de pip-copes, posicionades per cards.json.
    const pips = await page.locator("[data-baralla-id='5-copes'] img.pip").first().locator("xpath=ancestor::div[@data-pips]").getAttribute("data-pips");
    expect(pips).toBe("5");
    await expectNoOverflow(page);
    await shot(page, `baralla-${vp.tag}-banca-destapada`);
    await ctx.close();
  });
}

test("baralla E · tutorial («Guia»): tres cartes reals a 72 px", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.addInitScript(
    ({ age }) => {
      localStorage.setItem("setimig_player_id", `baralla-tut-${Date.now()}`);
      localStorage.setItem("setimig_player_name", "Edu");
      localStorage.setItem("setimig.locale", "en");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_age_gate", age);
    },
    { age: AGE_OK() }
  );
  await page.route("**/socket.io/**", (route) => route.abort());
  await page.goto("/");
  await expect(page.getByTestId("interactive-tutorial-step-1")).toBeVisible({ timeout: 60_000 });
  const cards = await probeCards(page, "[data-testid='interactive-tutorial'] .spanish-card");
  expect(cards.map((c) => c.id)).toEqual(["7-oros", "S-copes", "R-espases"]);
  for (const c of cards) expect(Math.round(c.w)).toBe(72);
  expectNewDeck(cards);
  await expectNoOverflow(page);
});

test("baralla E · SW: precache de la baralla ≤ 400 KB i amb hash", async ({ request }) => {
  const sw = await (await request.get("/sw.js")).text();
  expect(sw).toMatch(/"setimig-shell-v\d+"/);
  const block = sw.match(/const BARALLA_PRECACHE = (\[[\s\S]*?\]);/);
  expect(block).not.toBeNull();
  const list = JSON.parse(block![1]) as string[];
  expect(list.length).toBe(27);
  let bytes = 0;
  for (const p of list) {
    expect(p).toMatch(/^\/baralla\/.*\.[0-9a-f]{8}\.(avif|webp)$/);
    // Les cares 520 no van al precache (només els pips 520).
    expect(p).not.toMatch(/^\/baralla\/cares\/(?!pip-)[\w-]+-520\./);
    const res = await request.get(p);
    expect(res.ok()).toBe(true);
    bytes += (await res.body()).length;
  }
  console.log(`[baralla precache] ${list.length} fitxers, ${bytes} bytes`);
  expect(bytes).toBeLessThanOrEqual(400_000);
});
