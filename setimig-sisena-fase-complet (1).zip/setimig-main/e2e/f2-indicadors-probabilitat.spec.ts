import AxeBuilder from "@axe-core/playwright";
import { E2E_ACCOUNT_IDS, e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";
import { expect, test, type Page } from "@playwright/test";
import { safeHalfHandSnapshotJson } from "./helpers/f2ProbabilityFixtures.ts";

const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844 },
  { tag: "375x667", width: 375, height: 667 },
  { tag: "360x740", width: 360, height: 740 },
] as const;

async function seedLocalSolo(
  page: Page,
  snapshot: string,
  playerId: string,
  playerName: string,
  probabilityOn: boolean
) {
  playerId = E2E_ACCOUNT_IDS.includes(playerId) ? playerId : e2ePoolId();
  await seedE2eSession(page, playerId);
  await page.addInitScript(
    ({ snap, pid, pname, probOn }) => {
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", pname);
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_house_rules_enabled", "1");
      localStorage.setItem("setimig_probability_indicators", probOn ? "1" : "0");
      localStorage.setItem(
        "setimig_age_gate",
        JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
      );
      localStorage.setItem("setimig_local_solo_snapshot", snap);
      sessionStorage.setItem("setimig_solo_rejoin", "1");
      sessionStorage.setItem("setimig_solo_local", "1");
    },
    { snap: snapshot, pid: playerId, pname: playerName, probOn: probabilityOn }
  );
}

async function assertNoHorizontalOverflow(page: Page) {
  const metrics = await page.evaluate(() => ({
    scrollWidth: document.documentElement.scrollWidth,
    innerWidth: window.innerWidth,
  }));
  expect(metrics.scrollWidth).toBeLessThanOrEqual(metrics.innerWidth + 1);
}

async function assertActionButtonsFit(page: Page) {
  const hit = page.getByTestId("action-hit");
  const stand = page.getByTestId("action-stand");
  await expect(hit).toBeVisible({ timeout: 30_000 });
  await expect(stand).toBeVisible();
  const hitBox = await hit.boundingBox();
  const standBox = await stand.boundingBox();
  expect(hitBox).not.toBeNull();
  expect(standBox).not.toBeNull();
  expect(hitBox!.width).toBeGreaterThan(100);
  expect(standBox!.width).toBeGreaterThan(100);
  const vw = page.viewportSize()?.width ?? 390;
  const vh = page.viewportSize()?.height ?? 844;
  const dock = page.getByTestId("action-dock");
  const dockBox = await dock.boundingBox();
  expect(dockBox).not.toBeNull();
  expect(dockBox!.x + dockBox!.width).toBeLessThanOrEqual(vw + 1);
  expect(dockBox!.y + dockBox!.height).toBeLessThanOrEqual(vh + 1);
}

for (const vp of VIEWPORTS) {
  test.describe(`F2 indicadors probabilitat ${vp.tag}`, () => {
    test.use({ viewport: { width: vp.width, height: vp.height } });

    test("desactivats per defecte no mostren el percentatge", async ({ page }) => {
      const playerId = `f2-off-${vp.tag}`;
      await seedLocalSolo(
        page,
        safeHalfHandSnapshotJson(playerId, "ProbOff"),
        playerId,
        "ProbOff",
        false
      );
      await page.route("**/socket.io/**", (route) => route.abort());
      await page.goto("/");
      await expect(page.getByTestId("action-hit")).toBeVisible({ timeout: 30_000 });
      await expect(page.getByTestId("hit-bust-risk")).toHaveCount(0);
      await expect(page.getByTestId("hit-safe-card")).toHaveCount(0);
      await assertActionButtonsFit(page);
      await assertNoHorizontalOverflow(page);
    });

    test("taula gran: ni activats mostren el percentatge ni «carta segura»", async ({ page }) => {
      const playerId = `f2-on-${vp.tag}`;
      await seedLocalSolo(
        page,
        safeHalfHandSnapshotJson(playerId, "ProbOn"),
        playerId,
        "ProbOn",
        true
      );
      await page.route("**/socket.io/**", (route) => route.abort());
      await page.goto("/");
      await expect(page.getByTestId("action-hit")).toBeVisible({ timeout: 30_000 });
      await page.waitForTimeout(500);
      await expect(page.getByTestId("hit-bust-risk")).toHaveCount(0);
      await expect(page.getByTestId("hit-safe-card")).toHaveCount(0);
      await expect(page.getByTestId("hit-bust-risk-bar")).toHaveCount(0);
      expect(await page.getByTestId("action-hit").innerText()).not.toMatch(/%/);
      await assertActionButtonsFit(page);
      await assertNoHorizontalOverflow(page);

      const results = await new AxeBuilder({ page }).include('[data-testid="action-dock"]').analyze();
      expect(results.violations).toEqual([]);
    });
  });
}

test("es poden activar des del menú de taula", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  const playerId = "f2-menu-toggle";
  await seedLocalSolo(
    page,
    safeHalfHandSnapshotJson(playerId, "MenuToggle"),
    playerId,
    "MenuToggle",
    false
  );
  await page.route("**/socket.io/**", (route) => route.abort());
  await page.goto("/");
  await expect(page.getByTestId("action-hit")).toBeVisible({ timeout: 30_000 });
  await expect(page.getByTestId("hit-bust-risk")).toHaveCount(0);
  await page.getByTestId("table-tools-menu").getByRole("button", { name: /menú de taula/i }).click();
  await page.getByTestId("probability-indicators-toggle").click();
  // Taula gran (v147): l'opció ja no mostra cap percentatge (delatava els punts propis).
  await page.waitForTimeout(500);
  await expect(page.getByTestId("hit-bust-risk")).toHaveCount(0);
  await expect(page.getByTestId("hit-safe-card")).toHaveCount(0);
});
