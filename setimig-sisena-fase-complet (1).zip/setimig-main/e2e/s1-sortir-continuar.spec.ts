import AxeBuilder from "@axe-core/playwright";
import { expect, test, type Page } from "@playwright/test";

/**
 * S1 (millores-nit): després de «Sortir» confirmat, el lobby no ha d'oferir «Continuar la partida».
 * El cas real era just després d'una revenja (fase `betting`); aquí s'hi arriba acabant una mà i
 * passant a la següent, que deixa el client exactament a la mateixa fase. Només mesures, sense captures.
 */
async function seedLobby(page: Page, id: string) {
  await page.addInitScript((pid) => {
    localStorage.setItem("setimig_player_id", pid);
    localStorage.setItem("setimig_player_name", "SortirS1");
    localStorage.setItem("setimig_onboarding_v1", "1");
    localStorage.setItem("setimig_interactive_tutorial_v1", "1");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
    localStorage.removeItem("setimig_private_rejoin_code");
  }, id);
}

async function startPracticeVsAi(page: Page) {
  await page.goto("/");
  await page.getByTestId("lobby-context").click();
  await page.getByTestId("ai-bot-count-1").click();
  await page.getByTestId("ai-practice-mode").check();
  await page.getByRole("button", { name: "Començar" }).click();
  await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 45_000 });
}

/** Juga fins que surt el full de liquidació (aposta i es planta). */
async function finishOneHand(page: Page) {
  const sheet = page.getByTestId("settlement-sheet");
  const deadline = Date.now() + 60_000;
  while (Date.now() < deadline && !(await sheet.isVisible().catch(() => false))) {
    for (const id of ["action-stand", "bet-confirm"]) {
      const button = page.getByTestId(id);
      if ((await button.isVisible().catch(() => false)) && (await button.isEnabled().catch(() => false))) {
        await button.click({ timeout: 2_000 }).catch(() => {});
        break;
      }
    }
    await page.waitForTimeout(200);
  }
  await expect(sheet).toBeVisible();
}

async function confirmLeave(page: Page) {
  const leave = page.getByRole("button", { name: /Sortir de la partida|Confirmar sortida/ });
  await leave.click();
  if (await leave.isVisible().catch(() => false)) await leave.click();
  await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 15_000 });
}

test("S1: mà acabada + mà nova (fase d'apostes) → Sortir confirmat → sense «Continuar la partida»", async ({ page }) => {
  const received: string[] = [];
  page.on("websocket", (ws) => ws.on("framereceived", (f) => received.push(String(f.payload))));
  await seedLobby(page, `s1sortir-${Date.now()}`);
  await startPracticeVsAi(page);
  await finishOneHand(page);
  await page.getByTestId("settlement-next-hand").click();
  await expect(page.getByTestId("settlement-sheet")).toHaveCount(0, { timeout: 10_000 });

  const t0 = Date.now();
  await confirmLeave(page);
  const leaveMs = Date.now() - t0;
  console.log(`[S1] Sortir → lobby ${leaveMs} ms`);
  await page.waitForTimeout(1_500);
  await expect(page.getByTestId("resume-game-button")).toHaveCount(0);
  expect(await page.evaluate(() => sessionStorage.getItem("setimig_solo_rejoin"))).toBeNull();
  // Servidor amb #184: confirma que la sessió no es pot reprendre.
  expect(received.some((p) => p.includes("room_left") && p.includes('"resumable":false'))).toBe(true);

  // Tornar a carregar el lobby tampoc no la fa reaparèixer.
  await page.reload({ waitUntil: "domcontentloaded" });
  await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 20_000 });
  await page.waitForTimeout(2_500);
  await expect(page.getByTestId("resume-game-button")).toHaveCount(0);

  const axe = await new AxeBuilder({ page }).analyze();
  expect(axe.violations.map((v) => v.id)).toEqual([]);
});

test("S1: recàrrega a mitja mà sense Sortir → la partida es pot reprendre", async ({ page }) => {
  await seedLobby(page, `s1reload-${Date.now()}`);

  await startPracticeVsAi(page);
  await page.reload({ waitUntil: "domcontentloaded" });
  // L'indicador de connexió desapareix en connectar-se.
  await expect(page.getByTestId("connection-indicator")).toHaveCount(0, { timeout: 30_000 });
  const leave = page.getByRole("button", { name: "Sortir de la partida" });
  const resume = page.getByTestId("resume-game-button");
  // O bé es reincorpora sola a la taula (camí habitual), o bé el lobby ofereix «Continuar la partida»
  // i `resume_status` (solo: true) no l'amaga.
  const rejoined = await leave.waitFor({ state: "visible", timeout: 20_000 }).then(() => true, () => false);
  if (!rejoined) {
    await expect(resume).toBeVisible();
    await resume.click();
    await expect(leave).toBeVisible({ timeout: 45_000 });
  }
  expect(await page.evaluate(() => sessionStorage.getItem("setimig_solo_rejoin"))).toBe("1");
});
