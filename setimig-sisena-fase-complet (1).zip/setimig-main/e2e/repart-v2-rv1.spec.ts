import fs from "fs";
import path from "path";
import AxeBuilder from "@axe-core/playwright";
import { expect, test, type Page } from "@playwright/test";

/**
 * Repart v2 · RV1 (repart-v2.md §8, criteris 1–5): carta de 2 cares, flip 3D monòton i revelació escalonada.
 * Partides reals contra el servidor (IA, pràctica). Només mesures: cap captura.
 */

type FaceEvent = { id: string; from: string | null; to: string | null; t: number; phase: string; bank: boolean };
type FlipEvent = {
  id: string;
  animId: string;
  duration: number;
  delay: number;
  props: string[];
  start: number;
  phase: string;
  mid: string | null;
};
type RemovedUp = { id: string; t: number; phase: string; stillInDom: boolean };
type OpacityCheck = { id: string; opacity: number };
type Shift = { t: number; v: number };
type Probe = {
  faces: FaceEvent[];
  flips: FlipEvent[];
  removedUp: RemovedUp[];
  opacity: OpacityCheck[];
  shifts: Shift[];
};

async function seed(page: Page, id: string) {
  await page.addInitScript((pid) => {
    localStorage.setItem("setimig_player_id", pid);
    localStorage.setItem("setimig_player_name", "Repart");
    localStorage.setItem("setimig_onboarding_v1", "1");
    localStorage.setItem("setimig_interactive_tutorial_v1", "1");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
    const probe = { faces: [], flips: [], removedUp: [], opacity: [], shifts: [] } as unknown as {
      faces: unknown[];
      flips: unknown[];
      removedUp: unknown[];
      opacity: unknown[];
      shifts: unknown[];
    };
    (window as unknown as { __rv1: typeof probe }).__rv1 = probe;
    const phase = () => document.querySelector("[data-game-phase]")?.getAttribute("data-game-phase") ?? "";
    const effectiveOpacity = (el: Element | null) => {
      let o = 1;
      for (let n = el; n && n !== document.body; n = n.parentElement) o *= Number(getComputedStyle(n).opacity);
      return o;
    };

    // Criteri 2: cada flip és una animació WAAPI; en desem durada, keyframes i transform a mig gir.
    const nativeAnimate = Element.prototype.animate;
    Element.prototype.animate = function (this: Element, ...args: Parameters<Element["animate"]>) {
      const anim = nativeAnimate.apply(this, args);
      const el = this;
      if (el instanceof HTMLElement && el.classList.contains("card-flipper")) {
        queueMicrotask(() => {
          const card = el.closest("[data-card-id]");
          const timing = anim.effect?.getTiming();
          const keyframes = (anim.effect as KeyframeEffect | null)?.getKeyframes() ?? [];
          const props = new Set<string>();
          for (const k of keyframes) for (const p of Object.keys(k)) if (!["offset", "easing", "composite", "computedOffset"].includes(p)) props.add(p);
          const delay = Number(timing?.delay ?? 0);
          const rec = {
            id: card?.getAttribute("data-card-id") ?? "",
            animId: anim.id,
            duration: Number(timing?.duration ?? 0),
            delay,
            props: [...props],
            start: performance.now() + delay,
            phase: phase(),
            mid: null as string | null,
          };
          probe.flips.push(rec);
          window.setTimeout(() => {
            rec.mid = getComputedStyle(el).transform;
          }, delay + 170); // mig gir de 360 ms (animacions 02/03)
        });
      }
      return anim;
    } as Element["animate"];

    // Criteri 3: data-face mai up→down; cap carta destapada es desmunta a mitja mà; opacitat 1 després de destapar.
    const observer = new MutationObserver((records) => {
      const t = performance.now();
      for (const r of records) {
        if (r.type === "attributes" && r.attributeName === "data-face") {
          const el = r.target as HTMLElement;
          const id = el.getAttribute("data-card-id") ?? "";
          const to = el.getAttribute("data-face");
          probe.faces.push({ id, from: r.oldValue, to, t, phase: phase(), bank: el.classList.contains("spanish-card-size-bank") });
          if (r.oldValue === "down" && to === "up") {
            window.setTimeout(() => {
              if (el.isConnected) probe.opacity.push({ id, opacity: effectiveOpacity(el) });
            }, 700);
          }
        }
        if (r.type === "childList") {
          r.removedNodes.forEach((node) => {
            if (!(node instanceof HTMLElement)) return;
            const ups = [
              ...(node.matches("[data-face='up'][data-card-id]") ? [node] : []),
              ...node.querySelectorAll<HTMLElement>("[data-face='up'][data-card-id]"),
            ];
            for (const up of ups) {
              const id = up.getAttribute("data-card-id") ?? "";
              probe.removedUp.push({ id, t, phase: phase(), stillInDom: !!document.querySelector(`[data-card-id="${CSS.escape(id)}"]`) });
            }
          });
        }
      }
    });
    const startObserving = () =>
      observer.observe(document.documentElement, {
        subtree: true,
        childList: true,
        attributes: true,
        attributeFilter: ["data-face"],
        attributeOldValue: true,
      });
    if (document.documentElement) startObserving();
    else document.addEventListener("DOMContentLoaded", startObserving);

    new PerformanceObserver((list) => {
      for (const e of list.getEntries() as unknown as { startTime: number; value: number; hadRecentInput: boolean }[]) {
        if (!e.hadRecentInput) probe.shifts.push({ t: e.startTime, v: e.value });
      }
    }).observe({ type: "layout-shift", buffered: true });
  }, id);
}

/** CLS segons Chrome: la pitjor finestra de sessió (buit < 1 s, finestra ≤ 5 s). */
function maxSessionWindow(shifts: Shift[]): number {
  let best = 0;
  let cur = 0;
  let start = -Infinity;
  let last = -Infinity;
  for (const s of shifts) {
    if (s.t - last > 1000 || s.t - start > 5000) {
      cur = 0;
      start = s.t;
    }
    cur += s.v;
    last = s.t;
    best = Math.max(best, cur);
  }
  return best;
}

async function readProbe(page: Page): Promise<Probe> {
  return page.evaluate(() => JSON.parse(JSON.stringify((window as unknown as { __rv1: unknown }).__rv1)));
}

async function startPractice(page: Page, bots: number) {
  await page.goto("/");
  // Lobby v4.1 (#181): «Jugar» ja no obre el diàleg; la línia de context sí.
  await page.getByTestId("lobby-context").click();
  await page.getByTestId(`ai-bot-count-${bots}`).click();
  await page.getByTestId("ai-practice-mode").check();
  await page.getByRole("button", { name: "Començar" }).click();
}

/** Juga plantant-se sempre; surt quan `done()` és cert o s'acaba el temps. */
async function playUntil(page: Page, done: () => Promise<boolean>, budgetMs: number) {
  const deadline = Date.now() + budgetMs;
  while (Date.now() < deadline && !(await done())) {
    for (const id of ["settlement-next-hand", "action-stand", "bet-confirm"]) {
      const button = page.getByTestId(id);
      if ((await button.isVisible().catch(() => false)) && (await button.isEnabled().catch(() => false))) {
        await button.click({ timeout: 2_000 }).catch(() => {});
        break;
      }
    }
    await page.waitForTimeout(150);
  }
}

test("criteris 1–3 i CLS: 10 mans, flip 3D de 360 ms (animacions 02/03), mai up→down, cap carta destapada es desmunta", async ({ page }) => {
  test.setTimeout(140_000);
  await page.setViewportSize({ width: 390, height: 844 });
  await seed(page, `rv1-10-${Date.now()}`);
  await startPractice(page, 1);

  // Criteri 1: estructura de 2 cares a la primera mà.
  const firstCard = page.locator(".spanish-card[data-card-id]").first();
  const betConfirm = page.getByTestId("bet-confirm");
  await expect(betConfirm).toBeEnabled({ timeout: 15_000 });
  await betConfirm.click();
  await expect(firstCard).toBeVisible({ timeout: 15_000 });
  await page.waitForTimeout(700);
  const structure = await page.evaluate(() =>
    [...document.querySelectorAll<HTMLElement>(".spanish-card[data-card-id]")].map((card) => {
      const flipper = card.querySelector<HTMLElement>(":scope > .card-flipper");
      const faces = flipper ? [...flipper.children].map((c) => getComputedStyle(c).backfaceVisibility) : [];
      return {
        perspective: getComputedStyle(card).perspective,
        flipperPerspective: flipper ? getComputedStyle(flipper).perspective : "missing",
        faces,
      };
    })
  );
  expect(structure.length).toBeGreaterThan(0);
  for (const s of structure) {
    expect(s.faces).toEqual(["hidden", "hidden"]);
    expect(s.perspective).not.toBe("none");
    expect(s.flipperPerspective).toBe("none");
  }

  // Entrada acabada: axe sobre la taula.
  const axe = await new AxeBuilder({ page }).analyze();
  expect(axe.violations.map((v) => v.id)).toEqual([]);

  const revenge = page.getByTestId("match-revenge-button");
  await playUntil(page, () => revenge.isVisible().catch(() => false), 120_000);
  await expect(revenge).toBeVisible();
  await page.waitForTimeout(800);
  const probe = await readProbe(page);

  // Criteri 2 (animacions 02/03): durada 360 ±10, keyframes només transform/opacity, matrix3d a mig gir.
  const flips = probe.flips.filter((f) => f.animId === "card-flip");
  expect(flips.length).toBeGreaterThan(10);
  for (const f of flips) {
    expect(Math.abs(f.duration - 360)).toBeLessThanOrEqual(10);
    expect(f.props.every((p) => p === "transform" || p === "opacity")).toBe(true);
  }
  const mids = flips.map((f) => f.mid).filter((m): m is string => !!m);
  expect(mids.length).toBeGreaterThan(0);
  expect(mids.filter((m) => m.startsWith("matrix3d(")).length / mids.length).toBeGreaterThan(0.8);

  // Criteri 3.
  const upToDown = probe.faces.filter((f) => f.from === "up" && f.to === "down");
  expect(upToDown).toEqual([]);
  const midHandUnmounts = probe.removedUp.filter(
    (r) => ["playing", "banker", "settlement"].includes(r.phase) && !r.stillInDom
  );
  expect(midHandUnmounts).toEqual([]);
  expect(probe.opacity.filter((o) => o.opacity < 1)).toEqual([]);

  // Criteri 4 (part 1): la banca només es destapa al seu torn o a la liquidació.
  const bankReveals = probe.faces.filter((f) => f.bank && f.from === "down" && f.to === "up");
  expect(bankReveals.filter((f) => !["banker", "settlement"].includes(f.phase))).toEqual([]);

  // CLS no pitjor que main: main 1cac568 mesura 0,035–0,038 (pitjor finestra, regressio-cls-revenja a 390 i 360);
  // marge de 0,012 per soroll de la partida real. Abans del límit general de 0,1.
  const cls = maxSessionWindow(probe.shifts);
  console.log(
    `[rv1] flips ${flips.length} · revelacions ${probe.faces.filter((f) => f.from === "down" && f.to === "up").length} · banca ${bankReveals.length} · CLS ${cls.toFixed(4)}`
  );
  expect(cls).toBeLessThanOrEqual(0.05);
});

test("criteri 4: revelació de liquidació escalonada 80 ±15 ms (3 bots)", async ({ page }) => {
  test.setTimeout(100_000);
  await page.setViewportSize({ width: 390, height: 844 });
  await seed(page, `rv1-rev-${Date.now()}`);
  await startPractice(page, 3);

  const staggered = async () => {
    const probe = await readProbe(page);
    const revealIds = new Set(probe.faces.filter((f) => f.from === "down" && f.to === "up" && f.phase === "settlement").map((f) => f.id));
    const reveals = probe.flips.filter((f) => f.phase === "settlement" && revealIds.has(f.id));
    return reveals.length >= 2;
  };
  await playUntil(page, staggered, 80_000);
  await page.waitForTimeout(800);
  const probe = await readProbe(page);
  const revealIds = new Set(probe.faces.filter((f) => f.from === "down" && f.to === "up" && f.phase === "settlement").map((f) => f.id));
  const starts = probe.flips
    .filter((f) => f.phase === "settlement" && revealIds.has(f.id))
    .map((f) => f.start)
    .sort((a, b) => a - b);
  expect(starts.length).toBeGreaterThanOrEqual(2);
  // Grups de la mateixa liquidació (separats < 700 ms); dins de cada grup, 80 ±15 ms entre inicis.
  const gaps: number[] = [];
  for (let i = 1; i < starts.length; i += 1) {
    const gap = starts[i] - starts[i - 1];
    if (gap < 700) gaps.push(gap);
  }
  console.log(`[rv1] inicis de revelació a la liquidació: ${gaps.map((g) => g.toFixed(1)).join(", ")} ms`);
  expect(gaps.length).toBeGreaterThan(0);
  for (const g of gaps) expect(Math.abs(g - 80)).toBeLessThanOrEqual(15);
  const bankReveals = probe.faces.filter((f) => f.bank && f.from === "down" && f.to === "up");
  expect(bankReveals.filter((f) => !["banker", "settlement"].includes(f.phase))).toEqual([]);
});

test("criteri 5: no queda cap rastre de .card-deal-animate ni de card-deal-from-table a src", () => {
  const hits: string[] = [];
  const walk = (dir: string) => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(full);
      else if (/\.(tsx?|css)$/.test(entry.name) && /card-deal-animate|card-deal-from-table/.test(fs.readFileSync(full, "utf8"))) hits.push(full);
    }
  };
  walk(path.join(process.cwd(), "src"));
  expect(hits).toEqual([]);
});
