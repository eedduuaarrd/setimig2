import { expect, type Page } from "@playwright/test";

async function dismissInteractiveTutorialIfOpen(page: Page) {
  const skip = page.getByTestId("interactive-tutorial-skip");
  if (await skip.isVisible().catch(() => false)) {
    await skip.click();
    await expect(page.getByTestId("interactive-tutorial")).toHaveCount(0);
  }
}

/** Lobby v4.1 (C5): «Jugar» comença directament; la línia de context obre la configuració. */
export async function startAiGameFromLobby(page: Page, bots: number) {
  await dismissInteractiveTutorialIfOpen(page);
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  await page.getByTestId(`ai-bot-count-${bots}`).click();
  await page.getByTestId("ai-bot-picker").getByRole("button", { name: "Començar" }).click();
  await expect(page.getByTestId("ai-bot-picker")).toHaveCount(0);
}
