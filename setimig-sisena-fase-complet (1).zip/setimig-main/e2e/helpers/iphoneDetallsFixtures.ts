const card = (suit: "hearts" | "clubs" | "spades" | "diamonds", value: number, points: number) => ({
  suit,
  value,
  points,
});

const handSlot = (cards: Array<{ id: string; card: ReturnType<typeof card>; faceUp: boolean }>) => ({
  id: "hand-slot",
  bet: 100,
  cards,
  doubled: false,
  canDouble: false,
  mort: false,
  blindPair: false,
  blindUntilBankEnd: false,
  mortOffered: false,
  status: "playing",
});

/** Playing phase: rival bot (Jordi) has the turn; human waits. */
export function rivalTurnSnapshotJson(playerId: string, playerName: string): string {
  return JSON.stringify({
    version: 1,
    playerId,
    playerName,
    botCount: 2,
    difficulty: "normal",
    room: {
      id: "local-iphone-rival-turn",
      name: "Partida IA",
      players: [
        {
          id: `local-human-${playerId}`,
          playerId,
          seatToken: "rival-human-token",
          name: playerName,
          chips: 900,
          bet: 100,
          isBanker: false,
          isBot: false,
          status: "playing",
          handSlots: [
            handSlot([
              { id: "h1", card: card("hearts", 4, 4), faceUp: true },
              { id: "h2", card: card("clubs", 3, 3), faceUp: true },
            ]),
          ],
          activeSlotIndex: 0,
          lastRoyal7Payout: 0,
          royal7AsBankerStreak: 0,
        },
        {
          id: "bot-rival-jordi",
          playerId: "bot-rival-jordi",
          seatToken: "rival-bot-token",
          name: "Jordi",
          chips: 1200,
          bet: 100,
          isBanker: false,
          isBot: true,
          status: "playing",
          handSlots: [
            handSlot([
              { id: "r1", card: card("spades", 10, 0.5), faceUp: false },
              { id: "r2", card: card("diamonds", 5, 5), faceUp: true },
            ]),
          ],
          activeSlotIndex: 0,
          lastRoyal7Payout: 0,
          royal7AsBankerStreak: 0,
        },
        {
          id: "bot-bank-laia",
          playerId: "bot-bank-laia",
          seatToken: "rival-bank-token",
          name: "Laia",
          chips: 5000,
          bet: 0,
          isBanker: true,
          isBot: true,
          status: "playing",
          handSlots: [
            handSlot([{ id: "b1", card: card("hearts", 6, 6), faceUp: false }]),
          ],
          activeSlotIndex: 0,
          lastRoyal7Payout: 0,
          royal7AsBankerStreak: 0,
        },
      ],
      deck: [],
      pot: 200,
      phase: "playing",
      minBet: 100,
      jackpot: 0,
      lastRound: null,
      centerDiscard: [],
      turnPlayerIndex: 1,
      soloAi: true,
      soloHumanPlayerId: playerId,
      soloBotCount: 2,
      sessionStats: [[playerId, { handsPlayed: 1, handsWon: 0, netCf: 0, winStreak: 0, lastOutcome: null }]],
      matchEnded: false,
      matchResult: null,
      houseRulesEnabled: true,
      turnDeadlineAt: Date.now() + 60_000,
    },
  });
}
