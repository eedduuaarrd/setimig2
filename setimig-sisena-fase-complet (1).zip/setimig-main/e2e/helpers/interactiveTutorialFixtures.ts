/** Keep in sync with src/lib/interactiveTutorial.ts */
export const LS_INTERACTIVE_TUTORIAL = "setimig_interactive_tutorial_v1";

export function markInteractiveTutorialSeenSnippet(): string {
  return `localStorage.setItem("${LS_INTERACTIVE_TUTORIAL}", "1");`;
}
