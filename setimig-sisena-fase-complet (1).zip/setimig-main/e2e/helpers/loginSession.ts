/**
 * Sessió e2e del login obligatori (mateix contracte que e2e/login-obligatori.spec.ts).
 * - mockAuth ampliat: qualsevol /api/* (excepte health) evita 401 auth_required.
 * - blockSocketIo: el WS de socket.io no passa per page.route i el servidor
 *   respondria auth_required → handleUnauthorizedSession → /login.
 */
import type { BrowserContext, Page, Route } from "@playwright/test";
import { expect } from "@playwright/test";

export async function mockLoginSession(ctx: BrowserContext, playerId: string, playerToken: string): Promise<void> {
  await ctx.route("**/api/**", async (route: Route) => {
    const req = route.request();
    const url = new URL(req.url());
    const path = url.pathname.replace(/\/$/, "") || "/";
    if (path === "/api/health") return route.continue();

    const key = `${req.method()} ${path}`;
    const defaults: Record<string, { status?: number; json: unknown }> = {
      "GET /api/auth/providers": { json: { email: true, google: true, passkey: true, rpId: "sevenhalf.club" } },
      "POST /api/auth/email/start": { status: 202, json: { ok: true, expiresInSec: 600 } },
      "POST /api/auth/email/verify": {
        json: { playerId, playerToken, method: "email", created: false, linked: true, switchedAccount: false },
      },
      "GET /api/auth/me": { json: { playerId, emails: ["edu@example.com"], google: false, passkeys: 0, verified: true } },
      "POST /api/player-session": { json: { playerId, playerToken } },
      "GET /api/balance": { json: { chips: 1000, freeClaim: { available: false, nextAt: null } } },
      "GET /api/profile": { json: { displayName: "Edu", avatarDataUrl: null } },
      "PUT /api/profile": { json: { displayName: "Edu", avatarDataUrl: null } },
      "POST /api/events": { json: { ok: true } },
    };
    // Com el servidor real: sense Bearer (ni galeta de prova) /api/player-session dona 401.
    if (key === "POST /api/player-session" && !req.headers()["authorization"]) {
      return route.fulfill({ status: 401, contentType: "application/json", body: '{"error":"auth_required"}' });
    }
    const r = defaults[key] ?? { json: { ok: true } };
    await route.fulfill({
      status: r.status ?? 200,
      contentType: "application/json",
      body: JSON.stringify(r.json),
    });
  });
}

/** Impedeix el handshake real de socket.io (WS no el captura page.route). */
export async function blockSocketIo(page: Page): Promise<void> {
  await page.addInitScript(() => {
    const Orig = window.WebSocket;
    const Blocked = function (this: WebSocket, url: string | URL, protocols?: string | string[]) {
      const u = String(url);
      if (u.includes("socket.io")) {
        // Port tancat: connect_error de xarxa, no auth_required.
        return protocols !== undefined ? new Orig("ws://127.0.0.1:9", protocols) : new Orig("ws://127.0.0.1:9");
      }
      return protocols !== undefined ? new Orig(url, protocols) : new Orig(url);
    } as unknown as typeof WebSocket;
    Blocked.prototype = Orig.prototype;
    Object.assign(Blocked, Orig);
    window.WebSocket = Blocked;
  });
  await page.route("**/socket.io/**", (route) => route.abort());
}

/** Com `blockSocketIo`, però per a tot el context (totes les pàgines). */
export async function blockSocketIoCtx(ctx: BrowserContext): Promise<void> {
  await ctx.addInitScript(() => {
    const Orig = window.WebSocket;
    const Blocked = function (this: WebSocket, url: string | URL, protocols?: string | string[]) {
      const u = String(url);
      if (u.includes("socket.io")) return protocols !== undefined ? new Orig("ws://127.0.0.1:9", protocols) : new Orig("ws://127.0.0.1:9");
      return protocols !== undefined ? new Orig(url, protocols) : new Orig(url);
    } as unknown as typeof WebSocket;
    Blocked.prototype = Orig.prototype;
    Object.assign(Blocked, Orig);
    window.WebSocket = Blocked;
  });
  await ctx.route("**/socket.io/**", (route) => route.abort());
}

/** /login redissenyat: el formulari del correu s'obre amb «Continua amb correu» (si no hi és ja obert). */
export async function openLoginEmail(page: Page): Promise<void> {
  const cont = page.getByTestId("login-email-continue");
  const input = page.getByTestId("login-email-input");
  await cont.or(input).first().waitFor();
  // El botó pot sortir abans que l'app acabi de muntar (proveïdors, idioma): si el clic es perd
  // en un re-render, es torna a prémer fins que surt el camp, en comptes d'esperar-lo 15 s.
  await expect(async () => {
    if (!(await input.isVisible()) && (await cont.isVisible())) await cont.click({ timeout: 2_000 });
    await expect(input).toBeVisible({ timeout: 2_000 });
  }).toPass({ timeout: 20_000 });
}
