/** Snapshots for the peek-curl (gest lliscar) e2e. */
type Card = { suit: "hearts" | "diamonds" | "clubs" | "spades"; value: number; points: number };
const card = (value: number, suit: Card["suit"] = "hearts"): Card => ({
  suit,
  value,
  points: value >= 10 ? 0.5 : value,
});

function slot(
  id: string,
  cards: { card: Card; faceUp: boolean }[],
  bet: number,
  opts?: { blindUntilBankEnd?: boolean; blindPair?: boolean; status?: string },
) {
  return {
    id,
    bet,
    cards: cards.map((c, i) => ({ id: `${id}-c${i}`, card: c.card, faceUp: c.faceUp })),
    doubled: false,
    canDouble: false,
    mort: false,
    blindPair: opts?.blindPair ?? false,
    blindUntilBankEnd: opts?.blindUntilBankEnd ?? false,
    mortOffered: false,
    status: opts?.status ?? "playing",
  };
}

function seat(o: {
  id: string;
  playerId: string;
  name: string;
  isBanker: boolean;
  isBot: boolean;
  bet: number;
  status: string;
  hand: { card: Card; faceUp: boolean }[];
  chips?: number;
  blindUntilBankEnd?: boolean;
  blindPair?: boolean;
}) {
  return {
    id: o.id,
    playerId: o.playerId,
    seatToken: `${o.id}-token`,
    name: o.name,
    chips: o.chips ?? (o.isBanker ? 5000 : 900),
    bet: o.bet,
    isBanker: o.isBanker,
    isBot: o.isBot,
    status: o.status,
    handSlots: [
      slot(`${o.id}-hand`, o.hand, o.bet, {
        blindUntilBankEnd: o.blindUntilBankEnd,
        blindPair: o.blindPair,
        status: o.status === "stood" ? "stood" : "playing",
      }),
    ],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
  };
}

export type GestMode = "house" | "normal";

function snapshot(
  playerId: string,
  playerName: string,
  room: Record<string, unknown>,
  mode: GestMode = "house",
): string {
  return JSON.stringify({
    version: 1,
    playerId,
    playerName,
    botCount: 1,
    difficulty: "normal",
    room: {
      // Must start with local-solo- so App treats it as offline IA (localSoloRef).
      id: `local-solo-${playerId}`,
      name: mode === "house" ? "Partida IA (casa)" : "Partida IA",
      pot: 100,
      minBet: 100,
      jackpot: 0,
      lastRound: null,
      centerDiscard: [],
      soloAi: true,
      soloHumanPlayerId: playerId,
      soloBotCount: 1,
      sessionStats: [[playerId, { handsPlayed: 2, handsWon: 0, netCf: 0, winStreak: 0, lastOutcome: null }]],
      matchProgress: { handNumber: 3, totalHands: 10 },
      matchEnded: false,
      matchResult: null,
      /** house = regles de la casa; normal = Tradicional (sense doblar/mort/split). */
      houseRulesEnabled: mode === "house",
      turnDeadlineAt: Date.now() + 120_000,
      ...room,
    },
  });
}

const FIGURES = Array.from({ length: 12 }, (_, i) =>
  card(10 + (i % 3), (["hearts", "diamonds", "clubs", "spades"] as const)[i % 4]),
);

/** Own turn with one face-down card (peek + reveal allowed). */
export function gestPeekTurnSnapshot(playerId: string, name: string, mode: GestMode = "house"): string {
  return snapshot(playerId, name, {
    phase: "playing",
    turnPlayerIndex: 0,
    deck: FIGURES,
    players: [
      seat({
        id: `local-human-${playerId}`,
        playerId,
        name,
        isBanker: false,
        isBot: false,
        bet: 100,
        status: "playing",
        hand: [{ card: card(5, "diamonds"), faceUp: false }],
      }),
      seat({
        id: "bot-gest-bank",
        playerId: "bot-gest-bank",
        name: "Laia",
        isBanker: true,
        isBot: true,
        bet: 0,
        status: "playing",
        hand: [{ card: card(3, "clubs"), faceUp: false }],
      }),
    ],
  }, mode);
}

/** Own turn but 3 i Mort style lock: peek-only (never reveals). Card data kept for local peek. */
export function gestPeekLockedSnapshot(playerId: string, name: string, mode: GestMode = "house"): string {
  return snapshot(playerId, name, {
    phase: "playing",
    turnPlayerIndex: 0,
    deck: FIGURES,
    players: [
      seat({
        id: `local-human-${playerId}`,
        playerId,
        name,
        isBanker: false,
        isBot: false,
        bet: 100,
        status: "playing",
        hand: [
          { card: card(3, "hearts"), faceUp: false },
          { card: card(3, "spades"), faceUp: false },
        ],
        blindUntilBankEnd: true,
        blindPair: true,
      }),
      seat({
        id: "bot-gest-bank",
        playerId: "bot-gest-bank",
        name: "Laia",
        isBanker: true,
        isBot: true,
        bet: 0,
        status: "playing",
        hand: [{ card: card(4, "clubs"), faceUp: false }],
      }),
    ],
  }, mode);
}

/** Banker's turn while we still hold a face-down card: peek-only (outside our turn). */
export function gestPeekOutsideTurnSnapshot(playerId: string, name: string, mode: GestMode = "house"): string {
  return snapshot(playerId, name, {
    phase: "banker",
    turnPlayerIndex: 1,
    deck: FIGURES,
    players: [
      seat({
        id: `local-human-${playerId}`,
        playerId,
        name,
        isBanker: false,
        isBot: false,
        bet: 100,
        status: "stood",
        hand: [
          { card: card(6, "diamonds"), faceUp: false },
          { card: card(11, "hearts"), faceUp: true },
        ],
      }),
      seat({
        id: "bot-gest-bank",
        playerId: "bot-gest-bank",
        name: "Laia",
        isBanker: true,
        isBot: true,
        bet: 0,
        status: "playing",
        hand: [{ card: card(2, "clubs"), faceUp: true }],
        chips: 5000,
      }),
    ],
  }, mode);
}
