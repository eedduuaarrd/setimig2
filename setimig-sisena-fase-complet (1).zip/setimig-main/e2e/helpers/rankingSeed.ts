import { createHash } from "node:crypto";
import fs from "node:fs";
import path from "node:path";

/**
 * Dades del rànquing per a l'e2e. Només escriu al directori temporal de e2eServerEnv
 * (mai a data/ del repo). El hash d'esborrat és el de server/deletedAccounts.ts.
 */
function deletedHash(playerId: string): string {
  return createHash("sha256").update(`setimig-deleted-account:${playerId}`).digest("hex");
}

export const RANKING_VIEWER_ID = "rkviewer01";
export const RANKING_VIEWER_NAME = "Nora";
export const RANKING_VIEWER_RANK = 53;

const HIDDEN = [
  { id: "bot:taula01xx", name: null, chips: 999_999 },
  { id: "bot-taula0001", name: "Bot Visible", chips: 888_888 },
  { id: "xx-e2e-visible", name: "Id Marcat", chips: 777_777 },
  { id: "rkdeleted01", name: "Esborrat Visible", chips: 555_555, deleted: true },
] as const;

export const RANKING_HIDDEN_NAMES = HIDDEN.map((row) => row.name).filter((name): name is string => !!name);

export function seedChipRankingFixture(dataDir: string): void {
  const accounts: Record<string, { chips: number; lastClaimAt: null }> = {};
  const profiles = path.join(dataDir, "profiles");
  fs.mkdirSync(profiles, { recursive: true });

  const people: { id: string; name: string; chips: number }[] = [
    { id: "rkpodi0001", name: "Aina", chips: 50_000 },
    { id: "rkpodi0002", name: "Biel", chips: 40_000 },
    { id: "rkpodi0003", name: "Clara", chips: 30_000 },
  ];
  for (let i = 0; i < 49; i += 1) {
    people.push({ id: `rkfila${String(i).padStart(4, "0")}`, name: `Pila ${String(i).padStart(2, "0")}`, chips: 20_000 - i * 10 });
  }
  people.push({ id: RANKING_VIEWER_ID, name: RANKING_VIEWER_NAME, chips: 10 });

  const writeProfile = (id: string, name: string) => {
    fs.writeFileSync(
      path.join(profiles, `${id}.json`),
      JSON.stringify({ displayName: name, avatarDataUrl: null, updatedAt: 1 }),
    );
  };

  for (const person of people) {
    accounts[person.id] = { chips: person.chips, lastClaimAt: null };
    writeProfile(person.id, person.name);
  }
  for (const hidden of HIDDEN) {
    accounts[hidden.id] = { chips: hidden.chips, lastClaimAt: null };
    if (hidden.name && !hidden.id.includes(":")) writeProfile(hidden.id, hidden.name);
  }

  fs.writeFileSync(
    path.join(dataDir, "balances.json"),
    JSON.stringify({ accounts, processedSessions: [] }),
  );
  const deleted = HIDDEN.find((row) => "deleted" in row && row.deleted);
  fs.writeFileSync(
    path.join(dataDir, "deleted-accounts.json"),
    JSON.stringify({ version: 1, players: { [deletedHash(deleted!.id)]: Date.now() } }),
  );
}
