import type { Page } from "@playwright/test";

/** Jugabilitat v2: mesures de color calculades al navegador (sense captures). */

export type ColorHit = { el: string; prop: string; value: string; text: string };

/** Paleta v3: negre, superfícies, marfil (i blanc/negre purs), amb qualsevol alfa. */
const V3_BASES: [number, number, number][] = [
  [11, 11, 11],
  [22, 22, 22],
  [31, 31, 31],
  [245, 242, 235],
  [255, 255, 255],
  [0, 0, 0],
];

/**
 * Taula v2 · retoc 3: excepció explícita a l'ítem 3 (sense groc). L'únic or és #D4AF6A i només a la barra «Bust»,
 * a l'anella del toc de STAND/HIT, a la píndola «Stands 7½», al CTA, a l'esclat del 7½ i (retoc 4) a la puntuació 7½.
 * Qualsevol altre groc/or, o aquests elements amb un altre to, continua fallant.
 */
export const V2_GOLD_EXCEPTIONS = [
  ".hero-bust-fill",
  ".v2-ripple",
  '.v2-seat-pill[data-kind="seven"]',
  ".v2-cta",
  ".v2-burst-ray",
  // Retoc 4: la puntuació 7½ en or amb resplendor (com al vídeo).
  '.hero-score[data-seven="yes"]',
  '.hero-score[data-seven="yes"] *',
  // Animació 09: l'anella del temps del torn (#D4AF6A, vídeo de referència 09-torn).
  ".turn-ring-arc",
  // Taula gran (#277/#284): franja d'import assequible del rail d'aposta, or tènue.
  ".bet-rail-afford",
  // Animacions 12/13: zona «a prop» del total (6–7½) i anella daurada del teu torn (vídeos de referència).
  '.live-total-tones[data-zone="near"]',
  ".your-turn-ring",
].join(", ");

type ScanOptions = {
  mode: "palette" | "yellow" | "accent-border";
  bases?: [number, number, number][];
  scope?: string;
  /** Selectors on es permet exactament l'or #D4AF6A (mode "yellow"). */
  allowGold?: string;
};

/** Recorre els elements visibles i torna els colors calculats (color, fons, vores) fora de la regla. */
export async function scanColors(page: Page, opts: ScanOptions): Promise<string[]> {
  const hits = await scanColorHits(page, opts);
  return [...new Set(hits.map((h) => `${h.el} ${h.prop.replace(/-(top|right|bottom|left)-/, "-")}=${h.value}${h.text ? ` «${h.text.split("\n")[0]}»` : ""}`))];
}

export async function scanColorHits(page: Page, opts: ScanOptions): Promise<ColorHit[]> {
  return page.evaluate(
    ({ mode, bases, scope, allowGold }) => {
      const toSrgb = (x: number) => {
        const v = x <= 0.0031308 ? 12.92 * x : 1.055 * Math.pow(x, 1 / 2.4) - 0.055;
        return Math.round(Math.max(0, Math.min(1, v)) * 255);
      };
      const fromOklab = (L: number, A: number, B: number) => {
        const l = (L + 0.3963377774 * A + 0.2158037573 * B) ** 3;
        const m = (L - 0.1055613458 * A - 0.0638541728 * B) ** 3;
        const s = (L - 0.0894841775 * A - 1.291485548 * B) ** 3;
        return [
          toSrgb(4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s),
          toSrgb(-1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s),
          toSrgb(-0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s),
        ];
      };
      const parse = (c: string): { r: number; g: number; b: number; a: number } | null => {
        const m = c.match(/^(rgba?|oklab|oklch|color)\((.*)\)$/);
        if (!m) return null;
        const parts = m[2].replace(/^srgb\s+/, "").split(/[\s,/]+/).filter(Boolean);
        const num = (v: string | undefined, pct = 1) => (v === undefined ? NaN : v.endsWith("%") ? (parseFloat(v) / 100) * pct : parseFloat(v));
        const alpha = parts.length > 3 ? num(parts[3]) : 1;
        if (m[1] === "rgb" || m[1] === "rgba") return { r: num(parts[0]), g: num(parts[1]), b: num(parts[2]), a: alpha };
        if (m[1] === "color") return { r: Math.round(num(parts[0]) * 255), g: Math.round(num(parts[1]) * 255), b: Math.round(num(parts[2]) * 255), a: alpha };
        if (m[1] === "oklab") {
          const [r, g, b] = fromOklab(num(parts[0]), num(parts[1], 0.4), num(parts[2], 0.4));
          return { r, g, b, a: alpha };
        }
        const L = num(parts[0]);
        const C = num(parts[1], 0.4);
        const h = (num(parts[2]) * Math.PI) / 180;
        const [r, g, b] = fromOklab(L, C * Math.cos(h), C * Math.sin(h));
        return { r, g, b, a: alpha };
      };
      const near = (c: { r: number; g: number; b: number }, base: number[]) =>
        Math.abs(c.r - base[0]) <= 3 && Math.abs(c.g - base[1]) <= 3 && Math.abs(c.b - base[2]) <= 3;
      const yellow = (c: { r: number; g: number; b: number }) => c.r > 200 && c.g >= 150 && c.g <= 210 && c.b < 120;
      const root = scope ? document.querySelector(scope) : document.body;
      if (!root) return [{ el: "scope", prop: "missing", value: scope ?? "", text: "" }];
      const hits: { el: string; prop: string; value: string; text: string }[] = [];
      for (const el of [root, ...Array.from(root.querySelectorAll<HTMLElement>("*"))] as HTMLElement[]) {
        const rect = el.getBoundingClientRect();
        if (!rect.width || !rect.height) continue;
        const cs = getComputedStyle(el);
        if (cs.visibility === "hidden" || Number(cs.opacity) === 0) continue;
        const props: [string, string][] = [
          ["color", cs.color],
          ["background-color", cs.backgroundColor],
        ];
        for (const side of ["Top", "Right", "Bottom", "Left"] as const) {
          if (parseFloat(cs[`border${side}Width`]) > 0 && cs[`border${side}Style`] !== "none") props.push([`border-${side.toLowerCase()}-color`, cs[`border${side}Color`]]);
        }
        for (const [prop, value] of props) {
          const c = parse(value);
          if (!c || c.a <= 0.01) continue;
          let bad = false;
          if (mode === "palette") bad = !bases.some((base) => near(c, base));
          else if (mode === "yellow")
            bad = yellow(c) && !(allowGold && el.matches(allowGold) && near(c, [212, 175, 106]));
          else bad = prop.startsWith("border") && near(c, [200, 169, 107]);
          if (!bad) continue;
          hits.push({
            el: `${el.tagName.toLowerCase()}${el.dataset.testid ? `[${el.dataset.testid}]` : ""}.${String(el.className).slice(0, 50)}`,
            prop,
            value,
            text: (el.innerText ?? "").trim().slice(0, 24),
          });
        }
      }
      return hits;
    },
    { mode: opts.mode, bases: opts.bases ?? V3_BASES, scope: opts.scope ?? "", allowGold: opts.allowGold ?? "" }
  );
}

/** Scroll del document i dels contenidors desplaçables visibles. */
export async function scrollMetrics(page: Page) {
  return page.evaluate(() => {
    const lobby = document.querySelector<HTMLElement>("[data-testid=lobby-main]");
    return {
      docScroll: document.documentElement.scrollHeight,
      innerHeight: window.innerHeight,
      lobbyScroll: lobby ? lobby.scrollHeight : 0,
      lobbyClient: lobby ? lobby.clientHeight : 0,
    };
  });
}
