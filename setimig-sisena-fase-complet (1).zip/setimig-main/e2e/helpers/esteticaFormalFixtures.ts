const card = (suit: "hearts" | "clubs" | "spades", value: number, points: number) => ({
  suit,
  value,
  points,
});

const tableCard = (id: string, suit: "hearts" | "clubs" | "spades", value: number, points: number) => ({
  id,
  card: card(suit, value, points),
  faceUp: true,
});

function fanCards(prefix: string, specs: { suit: "hearts" | "clubs" | "spades"; value: number; points: number }[]) {
  return specs.map((spec, index) => tableCard(`${prefix}-${index}`, spec.suit, spec.value, spec.points));
}

/** Local solo snapshot in settlement with visible cards (no rival reveal wait). */
export function settlementSnapshotJson(playerId: string, playerName: string): string {
  return JSON.stringify({
    version: 1,
    playerId,
    playerName,
    botCount: 1,
    difficulty: "normal",
    room: {
      id: "local-estetica-settlement",
      name: "Partida IA",
      players: [
        {
          id: `local-human-${playerId}`,
          playerId,
          seatToken: "est-human-token",
          name: playerName,
          chips: 2200,
          bet: 200,
          isBanker: false,
          isBot: false,
          status: "done",
          handSlots: [
            {
              id: "human-hand",
              bet: 200,
              cards: [
                { id: "h1", card: card("hearts", 7, 7), faceUp: true },
                { id: "h2", card: card("clubs", 4, 4), faceUp: true },
              ],
              doubled: false,
              canDouble: false,
              mort: false,
              blindPair: false,
              blindUntilBankEnd: false,
              mortOffered: false,
              status: "done",
            },
          ],
          activeSlotIndex: 0,
          lastRoyal7Payout: 0,
          royal7AsBankerStreak: 0,
        },
        {
          id: "bot-est-bank",
          playerId: "bot-est-bank",
          seatToken: "est-bank-token",
          name: "Laia",
          chips: 4800,
          bet: 0,
          isBanker: true,
          isBot: true,
          status: "done",
          handSlots: [
            {
              id: "bank-hand",
              bet: 0,
              cards: [{ id: "b1", card: card("spades", 6, 6), faceUp: true }],
              doubled: false,
              canDouble: false,
              mort: false,
              blindPair: false,
              blindUntilBankEnd: false,
              mortOffered: false,
              status: "done",
            },
          ],
          activeSlotIndex: 0,
          lastRoyal7Payout: 0,
          royal7AsBankerStreak: 0,
        },
      ],
      deck: [],
      pot: 0,
      phase: "settlement",
      minBet: 100,
      jackpot: 0,
      lastRound: {
        title: "Liquidació",
        at: Date.now(),
        results: [
          {
            name: playerName,
            outcome: "win",
            chipDelta: 200,
            detail: "Tu 7 · Banca 6",
            handPoints: 7,
          },
          {
            name: "Laia",
            outcome: "lose",
            chipDelta: -200,
            detail: "Banca 6",
            handPoints: 6,
          },
        ],
        highlights: [],
      },
      centerDiscard: [],
      turnPlayerIndex: 0,
      soloAi: true,
      soloHumanPlayerId: playerId,
      soloBotCount: 1,
      sessionStats: [[playerId, { handsPlayed: 1, handsWon: 1, netCf: 200, winStreak: 1, lastOutcome: "win" }]],
      matchEnded: false,
      matchResult: null,
      houseRulesEnabled: true,
      settlementStartedAt: Date.now(),
    },
  });
}

/** Settlement with dense rival row: bank fan (5), wide opponent fan, 7½ badge rival. */
export function settlementLayoutSnapshotJson(playerId: string, playerName: string): string {
  const figure = { suit: "hearts" as const, value: 12, points: 0.5 };
  const bankFan = fanCards(
    "bank",
    [
      figure,
      { suit: "clubs", value: 12, points: 0.5 },
      { suit: "spades", value: 12, points: 0.5 },
      { suit: "hearts", value: 12, points: 0.5 },
      { suit: "clubs", value: 12, points: 0.5 },
    ]
  );
  const sevenHalfFan = fanCards("7m", [
    { suit: "hearts", value: 7, points: 7 },
    figure,
  ]);
  const halfFan = fanCards("half", [figure]);

  return JSON.stringify({
    version: 1,
    playerId,
    playerName,
    botCount: 2,
    difficulty: "normal",
    room: {
      id: `local-solo-${playerId}`,
      name: "Partida IA",
      players: [
        {
          id: `local-human-${playerId}`,
          playerId,
          seatToken: "est-human-token",
          name: playerName,
          chips: 2200,
          bet: 200,
          isBanker: false,
          isBot: false,
          status: "done",
          handSlots: [
            {
              id: "human-hand",
              bet: 200,
              cards: halfFan,
              doubled: false,
              canDouble: false,
              mort: false,
              blindPair: false,
              blindUntilBankEnd: false,
              mortOffered: false,
              status: "done",
            },
          ],
          activeSlotIndex: 0,
          lastRoyal7Payout: 0,
          royal7AsBankerStreak: 0,
        },
        {
          id: "bot-est-bank",
          playerId: "bot-est-bank",
          seatToken: "est-bank-token",
          name: "Laia",
          chips: 4800,
          bet: 0,
          isBanker: true,
          isBot: true,
          status: "done",
          handSlots: [
            {
              id: "bank-hand",
              bet: 0,
              cards: bankFan,
              doubled: false,
              canDouble: false,
              mort: false,
              blindPair: false,
              blindUntilBankEnd: false,
              mortOffered: false,
              status: "done",
            },
          ],
          activeSlotIndex: 0,
          lastRoyal7Payout: 0,
          royal7AsBankerStreak: 0,
        },
        {
          id: "bot-est-7m",
          playerId: "bot-est-7m",
          seatToken: "est-7m-token",
          name: "Jordi",
          chips: 3900,
          bet: 200,
          isBanker: false,
          isBot: true,
          status: "done",
          handSlots: [
            {
              id: "7m-hand",
              bet: 200,
              cards: sevenHalfFan,
              doubled: false,
              canDouble: false,
              mort: false,
              blindPair: false,
              blindUntilBankEnd: false,
              mortOffered: false,
              status: "done",
            },
          ],
          activeSlotIndex: 0,
          lastRoyal7Payout: 0,
          royal7AsBankerStreak: 0,
        },
      ],
      deck: [],
      pot: 0,
      phase: "settlement",
      minBet: 100,
      jackpot: 0,
      lastRound: {
        title: "Liquidació",
        at: Date.now(),
        results: [
          { name: playerName, outcome: "lose", chipDelta: -200, detail: "Tu ½ · Banca 2½", handPoints: 0.5 },
          { name: "Laia", outcome: "win", chipDelta: 200, detail: "Banca 2½", handPoints: 2.5 },
          { name: "Jordi", outcome: "win", chipDelta: 200, detail: "7½", handPoints: 7.5 },
        ],
        highlights: [],
      },
      centerDiscard: [],
      turnPlayerIndex: 0,
      soloAi: true,
      soloHumanPlayerId: playerId,
      soloBotCount: 2,
      sessionStats: [[playerId, { handsPlayed: 1, handsWon: 0, netCf: -200, winStreak: 0, lastOutcome: "lose" }]],
      matchEnded: false,
      matchResult: null,
      houseRulesEnabled: true,
      settlementStartedAt: Date.now(),
    },
  });
}
