/** Jugabilitat v1: snapshots de partida local (solo IA) per mesurar els ítems [CLIENT]. */
type Card = { suit: "hearts" | "diamonds" | "clubs" | "spades"; value: number; points: number };
const card = (value: number, suit: Card["suit"] = "hearts"): Card => ({ suit, value, points: value >= 10 ? 0.5 : value });

function slot(id: string, cards: Card[], faceUp: boolean, bet: number, status = "playing") {
  return {
    id,
    bet,
    cards: cards.map((c, i) => ({ id: `${id}-c${i}`, card: c, faceUp })),
    doubled: false,
    canDouble: false,
    mort: false,
    blindPair: false,
    blindUntilBankEnd: false,
    mortOffered: false,
    status,
  };
}

function seat(o: { id: string; playerId: string; name: string; isBanker: boolean; isBot: boolean; bet: number; status: string; cards: Card[]; faceUp: boolean; chips?: number }) {
  return {
    id: o.id,
    playerId: o.playerId,
    seatToken: `${o.id}-token`,
    name: o.name,
    chips: o.chips ?? (o.isBanker ? 5000 : 900),
    bet: o.bet,
    isBanker: o.isBanker,
    isBot: o.isBot,
    status: o.status,
    handSlots: o.cards.length || o.status !== "betting" ? [slot(`${o.id}-hand`, o.cards, o.faceUp, o.bet, o.status === "stood" ? "stood" : "playing")] : [],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
  };
}

function snapshot(playerId: string, playerName: string, room: Record<string, unknown>): string {
  return JSON.stringify({
    version: 1,
    playerId,
    playerName,
    botCount: 1,
    difficulty: "normal",
    room: {
      id: `local-jug-${playerId}`,
      name: "Partida IA",
      pot: 100,
      minBet: 100,
      jackpot: 0,
      lastRound: null,
      centerDiscard: [],
      soloAi: true,
      soloHumanPlayerId: playerId,
      soloBotCount: 1,
      sessionStats: [[playerId, { handsPlayed: 2, handsWon: 0, netCf: 0, winStreak: 0, lastOutcome: null }]],
      matchProgress: { handNumber: 3, totalHands: 10 },
      matchEnded: false,
      matchResult: null,
      houseRulesEnabled: true,
      turnDeadlineAt: Date.now() + 60_000,
      ...room,
    },
  });
}

const FIGURES = Array.from({ length: 12 }, (_, i) => card(10 + (i % 3), (["hearts", "diamonds", "clubs", "spades"] as const)[i % 4]));

/** Torn propi (jugador): 1 punt a la mà; el mall només dona figures (½). */
export function playerTurnSnapshot(playerId: string, name: string, cards: number[] = [1]): string {
  return snapshot(playerId, name, {
    phase: "playing",
    turnPlayerIndex: 0,
    deck: FIGURES,
    players: [
      seat({ id: `local-human-${playerId}`, playerId, name, isBanker: false, isBot: false, bet: 100, status: "playing", cards: cards.map((v) => card(v)), faceUp: true }),
      seat({ id: "bot-jug-bank", playerId: "bot-jug-bank", name: "Laia", isBanker: true, isBot: true, bet: 0, status: "playing", cards: [card(3, "clubs")], faceUp: false }),
    ],
  });
}

/** Fase d'apostes amb el visor com a banca (el bot ha d'apostar). */
export function viewerBankBettingSnapshot(playerId: string, name: string): string {
  return snapshot(playerId, name, {
    phase: "betting",
    turnPlayerIndex: 0,
    pot: 0,
    deck: FIGURES,
    players: [
      seat({ id: `local-human-${playerId}`, playerId, name, isBanker: true, isBot: false, bet: 0, status: "playing", cards: [], faceUp: true, chips: 5000 }),
      seat({ id: "bot-jug-p", playerId: "bot-jug-p", name: "Pau", isBanker: false, isBot: true, bet: 0, status: "betting", cards: [], faceUp: false }),
    ],
  });
}

/** Torn de la banca amb el visor com a banca: 3 + ½ destapades. */
export function viewerBankTurnSnapshot(playerId: string, name: string): string {
  return snapshot(playerId, name, {
    phase: "banker",
    turnPlayerIndex: 0,
    deck: FIGURES,
    players: [
      seat({ id: `local-human-${playerId}`, playerId, name, isBanker: true, isBot: false, bet: 0, status: "playing", cards: [card(3, "clubs"), card(11, "diamonds")], faceUp: true, chips: 5000 }),
      seat({ id: "bot-jug-p", playerId: "bot-jug-p", name: "Pau", isBanker: false, isBot: true, bet: 100, status: "stood", cards: [card(5, "spades")], faceUp: false }),
    ],
  });
}

/** Fase d'apostes del visor (jugador). */
export function playerBettingSnapshot(playerId: string, name: string): string {
  return snapshot(playerId, name, {
    phase: "betting",
    turnPlayerIndex: 0,
    pot: 0,
    deck: FIGURES,
    players: [
      seat({ id: `local-human-${playerId}`, playerId, name, isBanker: false, isBot: false, bet: 0, status: "betting", cards: [], faceUp: true }),
      seat({ id: "bot-jug-bank", playerId: "bot-jug-bank", name: "Laia", isBanker: true, isBot: true, bet: 0, status: "playing", cards: [], faceUp: false }),
    ],
  });
}

/**
 * Focus del torn: 3 jugadors (jo, el bot Pau i la banca Laia). Comença el meu torn; després juga Pau i
 * finalment la banca. Serveix per veure 3 torns seguits (gran al centre / petits a la fila).
 */
export function threePlayerTurnSnapshot(playerId: string, name: string): string {
  return snapshot(playerId, name, {
    phase: "playing",
    turnPlayerIndex: 0,
    pot: 200,
    deck: FIGURES,
    soloBotCount: 2,
    players: [
      seat({ id: `local-human-${playerId}`, playerId, name, isBanker: false, isBot: false, bet: 100, status: "playing", cards: [card(4)], faceUp: true }),
      seat({ id: "bot-jug-p", playerId: "bot-jug-p", name: "Pau", isBanker: false, isBot: true, bet: 100, status: "playing", cards: [card(5, "spades")], faceUp: false }),
      seat({ id: "bot-jug-bank", playerId: "bot-jug-bank", name: "Laia", isBanker: true, isBot: true, bet: 0, status: "playing", cards: [card(3, "clubs")], faceUp: false }),
    ],
  });
}

/**
 * Baralla E + revers L2b: mà pròpia mixta (6 d'oros + rei de copes, destapades) i la banca amb dues cartes
 * tapades (3 de bastos + cavall d'espases). `viewerBank`: el visor és la banca, amb 1 d'espases, cavall d'oros
 * i 5 de copes destapats, i Pau plantat amb una carta tapada.
 */
export function barallaSnapshot(playerId: string, name: string, opts: { viewerBank?: boolean } = {}): string {
  if (opts.viewerBank) {
    return snapshot(playerId, name, {
      phase: "banker",
      turnPlayerIndex: 0,
      deck: FIGURES,
      players: [
        seat({ id: `local-human-${playerId}`, playerId, name, isBanker: true, isBot: false, bet: 0, status: "playing", cards: [card(1, "spades"), card(11, "diamonds"), card(5, "hearts")], faceUp: true, chips: 5000 }),
        seat({ id: "bot-jug-p", playerId: "bot-jug-p", name: "Pau", isBanker: false, isBot: true, bet: 100, status: "stood", cards: [card(6, "clubs")], faceUp: false }),
      ],
    });
  }
  return snapshot(playerId, name, {
    phase: "playing",
    turnPlayerIndex: 0,
    deck: FIGURES,
    players: [
      seat({ id: `local-human-${playerId}`, playerId, name, isBanker: false, isBot: false, bet: 100, status: "playing", cards: [card(6, "diamonds"), card(12, "hearts")], faceUp: true }),
      seat({ id: "bot-jug-bank", playerId: "bot-jug-bank", name: "Laia", isBanker: true, isBot: true, bet: 0, status: "playing", cards: [card(3, "clubs"), card(11, "spades")], faceUp: false }),
    ],
  });
}
