/**
 * Sessió real per als e2e amb servidor (login obligatori #262/#263/#270).
 *
 * El servidor de proves arrenca amb PLAYER_TOKEN_SECRET=playwright-e2e-test-secret i amb les
 * dades en un directori temporal (e2eServerEnv). Abans d'arrencar, e2eServerEnv hi escriu un
 * identities.json amb els comptes de E2E_ACCOUNT_IDS (correu verificat fictici), així que
 * un token signat aquí per a un d'aquests ids passa requireLogin i el gate del socket.
 * Cap /api queda simulada (per a specs amb mocks, vegeu loginSession.ts).
 */
import { createHmac } from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import type { BrowserContext, Page } from "@playwright/test";

export const E2E_TOKEN_SECRET = "playwright-e2e-test-secret";

/** Ids genèrics per a specs que abans feien servir ids aleatoris (Date.now, Math.random). */
const POOL_SIZE = 2000;
const POOL = Array.from({ length: POOL_SIZE }, (_, i) => `e2e-acct-${i}`);
let poolNext = Math.floor(Math.random() * POOL_SIZE);
/** Un compte e2e del pool (ja registrat al servidor de proves), diferent a cada crida. */
export function e2ePoolId(): string {
  poolNext = (poolNext + 1) % POOL_SIZE;
  return POOL[poolNext];
}

/** Comptes coneguts pel servidor de proves. Un id nou s'ha d'afegir aquí. */
export const E2E_ACCOUNT_IDS: readonly string[] = [
  ...POOL,
  "gest-player-1",
  "gest-ovf-1",
  "lobby-scroll-test",
  "est-axe-lobby",
  "est-axe-settlement",
  "rkviewer01",
  "nomclaraqa01",
  "saldosort01",
  "saldosort02",
];

/** Token amb el mateix format que server/playerToken.ts (body.sig en base64url). */
export function mintE2eToken(playerId: string, ttlMs = 1000 * 60 * 60 * 24): string {
  const body = Buffer.from(JSON.stringify({ playerId, exp: Date.now() + ttlMs }), "utf8").toString("base64url");
  const sig = createHmac("sha256", E2E_TOKEN_SECRET).update(body).digest().toString("base64url");
  return `${body}.${sig}`;
}

/** Escriu identities.json (si no hi és) amb tots els comptes e2e. Només al directori temporal. */
export function seedE2eIdentities(dataDir: string): void {
  const file = path.join(dataDir, "identities.json");
  if (fs.existsSync(file)) return;
  const now = Date.now();
  const emails: Record<string, string> = {};
  const players: Record<string, { createdVia: "email"; createdAt: number; emails: string[] }> = {};
  for (const id of E2E_ACCOUNT_IDS) {
    const email = `${id}@e2e.invalid`;
    emails[email] = id;
    players[id] = { createdVia: "email", createdAt: now, emails: [email] };
  }
  fs.mkdirSync(dataDir, { recursive: true });
  fs.writeFileSync(file, JSON.stringify({ version: 1, emails, google: {}, passkeys: {}, players, log: [] }));
}

/**
 * Desa una sessió vàlida (setimig_player_id + setimig_player_token) abans de carregar l'app.
 * Crida-ho abans de l'addInitScript propi de l'spec (que pot tornar a posar el mateix id).
 */
export async function seedE2eSession(target: Page | BrowserContext, playerId: string): Promise<string> {
  if (!E2E_ACCOUNT_IDS.includes(playerId)) {
    throw new Error(`seedE2eSession: ${playerId} no és a E2E_ACCOUNT_IDS (e2e/helpers/e2eSession.ts)`);
  }
  const token = mintE2eToken(playerId);
  await target.addInitScript(
    ({ pid, token }) => {
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_token", token);
    },
    { pid: playerId, token },
  );
  return token;
}

/**
 * Sessió + intro ja vista (#279/#281: intro no saltable) + idioma opcional.
 * L'intro es marca a sessionStorage (SS_INTRO_LAUNCH a src/lib/introLaunch.ts).
 */
export async function seedE2eLaunch(
  target: Page | BrowserContext,
  playerId: string,
  opts: { locale?: string } = {},
): Promise<string> {
  const token = await seedE2eSession(target, playerId);
  await target.addInitScript(
    ({ locale }) => {
      sessionStorage.setItem("setimig_intro_launch_v1", "1");
      if (locale) localStorage.setItem("setimig.locale", locale);
    },
    { locale: opts.locale ?? null },
  );
  return token;
}
