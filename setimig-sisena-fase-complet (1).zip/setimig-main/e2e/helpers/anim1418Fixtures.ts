/** Animacions PR 4 (14 aposta, 16 figures, 17 espera, 18 error): snapshots solo IA. */
type Suit = "hearts" | "diamonds" | "clubs" | "spades";
type Card = { suit: Suit; value: number; points: number };
export const card = (value: number, suit: Suit = "hearts"): Card => ({
  suit,
  value,
  points: value >= 10 ? 0.5 : value,
});

const SUITS: Suit[] = ["spades", "clubs", "diamonds", "hearts"];
const FILLER = Array.from({ length: 14 }, (_, i) => card(10 + (i % 3), SUITS[i % 4]));

function seat(o: {
  key: string;
  name: string;
  playerId: string;
  bank?: boolean;
  human?: boolean;
  bet?: number;
  chips?: number;
  status?: string;
  cards?: number[];
  faceUp?: boolean;
}) {
  const id = o.human ? `local-human-${o.playerId}` : `bot-anim-${o.key}`;
  const slotId = `${o.key}-hand`;
  const cards = o.cards ?? [];
  return {
    id,
    playerId: o.human ? o.playerId : id,
    seatToken: `${o.key}-token`,
    name: o.name,
    chips: o.chips ?? (o.bank ? 5000 : 900),
    bet: o.bet ?? 0,
    isBanker: !!o.bank,
    isBot: !o.human,
    status: o.status ?? (o.bet ? "playing" : "betting"),
    handSlots: cards.length
      ? [
          {
            id: slotId,
            bet: o.bet ?? 0,
            cards: cards.map((v, i) => ({
              id: `${slotId}-c${i}`,
              card: card(v, SUITS[(i + 1) % 4]),
              faceUp: o.faceUp !== false,
            })),
            doubled: false,
            canDouble: false,
            mort: false,
            blindPair: false,
            blindUntilBankEnd: false,
            mortOffered: false,
            status: "playing",
          },
        ]
      : [],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
  };
}

export function bettingSnapshot(playerId: string, opts: { chips?: number; minBet?: number; maxBet?: number } = {}): string {
  const minBet = opts.minBet ?? 10;
  const maxBet = opts.maxBet ?? 100;
  const chips = opts.chips ?? 60;
  return JSON.stringify({
    version: 1,
    playerId,
    playerName: "Edu",
    botCount: 1,
    difficulty: "normal",
    room: {
      id: `local-anim1418-bet-${playerId}`,
      name: "Partida IA",
      pot: 0,
      minBet,
      tableMaxBet: maxBet,
      jackpot: 0,
      lastRound: null,
      centerDiscard: [],
      soloAi: true,
      practiceMode: true,
      soloHumanPlayerId: playerId,
      soloBotCount: 1,
      sessionStats: [[playerId, { handsPlayed: 1, handsWon: 0, netCf: 0, winStreak: 0, lastOutcome: null }]],
      matchProgress: { handNumber: 2, totalHands: 10 },
      matchEnded: false,
      matchResult: null,
      houseRulesEnabled: false,
      turnDeadlineAt: Date.now() + 60_000,
      bettingDeadlineAt: Date.now() + 60_000,
      phase: "betting",
      turnPlayerIndex: 0,
      deck: [...FILLER],
      players: [
        seat({ key: "you", name: "Edu", playerId, human: true, chips, status: "betting", bet: 0 }),
        seat({ key: "bank", name: "Laia", playerId: "bot-bank", bank: true, chips: 5000, status: "waiting", bet: 0 }),
      ],
    },
  });
}

/** El teu torn amb figures a la mà (sota + 4 + cavall = 5). */
export function faceCardsSnapshot(playerId: string): string {
  return JSON.stringify({
    version: 1,
    playerId,
    playerName: "Edu",
    botCount: 1,
    difficulty: "normal",
    room: {
      id: `local-anim1418-face-${playerId}`,
      name: "Partida IA",
      pot: 100,
      minBet: 100,
      jackpot: 0,
      lastRound: null,
      centerDiscard: [],
      soloAi: true,
      practiceMode: true,
      soloHumanPlayerId: playerId,
      soloBotCount: 1,
      sessionStats: [[playerId, { handsPlayed: 2, handsWon: 0, netCf: 0, winStreak: 0, lastOutcome: null }]],
      matchProgress: { handNumber: 3, totalHands: 10 },
      matchEnded: false,
      matchResult: null,
      houseRulesEnabled: false,
      turnDeadlineAt: Date.now() + 60_000,
      phase: "playing",
      turnPlayerIndex: 0,
      deck: [...FILLER],
      players: [
        seat({
          key: "you",
          name: "Edu",
          playerId,
          human: true,
          bet: 100,
          chips: 800,
          status: "playing",
          cards: [10, 4, 11],
          faceUp: true,
        }),
        seat({
          key: "bank",
          name: "Laia",
          playerId: "bot-bank",
          bank: true,
          chips: 5000,
          status: "waiting",
          cards: [3],
          faceUp: false,
        }),
      ],
    },
  });
}

/** Torn d'un rival (Anna): botons Hit/Stand desactivats per a tu. */
export function rivalTurnSnapshot(playerId: string): string {
  return JSON.stringify({
    version: 1,
    playerId,
    playerName: "Edu",
    botCount: 2,
    difficulty: "normal",
    room: {
      id: `local-anim1418-err-${playerId}`,
      name: "Partida IA",
      pot: 300,
      minBet: 100,
      jackpot: 0,
      lastRound: null,
      centerDiscard: [],
      soloAi: true,
      practiceMode: true,
      soloHumanPlayerId: playerId,
      soloBotCount: 2,
      sessionStats: [[playerId, { handsPlayed: 2, handsWon: 0, netCf: 0, winStreak: 0, lastOutcome: null }]],
      matchProgress: { handNumber: 3, totalHands: 10 },
      matchEnded: false,
      matchResult: null,
      houseRulesEnabled: false,
      turnDeadlineAt: Date.now() + 60_000,
      phase: "playing",
      turnPlayerIndex: 0,
      deck: [...FILLER],
      players: [
        seat({
          key: "anna",
          name: "Anna",
          playerId: "bot-anna",
          bet: 100,
          chips: 800,
          status: "playing",
          cards: [5, 2],
          faceUp: true,
        }),
        seat({
          key: "you",
          name: "Edu",
          playerId,
          human: true,
          bet: 100,
          chips: 800,
          status: "playing",
          cards: [6],
          faceUp: true,
        }),
        seat({
          key: "bank",
          name: "Laia",
          playerId: "bot-bank",
          bank: true,
          chips: 5000,
          status: "waiting",
          cards: [4],
          faceUp: false,
        }),
      ],
    },
  });
}
