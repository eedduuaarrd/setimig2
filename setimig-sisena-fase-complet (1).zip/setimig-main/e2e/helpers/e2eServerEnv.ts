import os from "os";
import path from "path";
import { E2E_TOKEN_SECRET, seedE2eIdentities } from "./e2eSession";

/**
 * Entorn del servidor de proves Playwright: dades (saldos, perfils, estadístiques, amics,
 * taules privades) en un directori temporal propi, mai a `data/` del repo. Així els tests
 * E2E no poden moure saldos reals encara que s'executin dins del checkout de producció.
 */
export function e2eServerEnv(extra: Record<string, string> = {}): Record<string, string> {
  const dir =
    process.env.SETIMIG_E2E_DATA_DIR || path.join(os.tmpdir(), `setimig-e2e-data-${process.pid}`);
  process.env.SETIMIG_E2E_DATA_DIR = dir;
  // Login obligatori: comptes e2e registrats abans que el servidor llegeixi identities.json.
  seedE2eIdentities(dir);
  return {
    BALANCE_DATA_DIR: dir,
    PROFILE_DATA_DIR: path.join(dir, "profiles"),
    FRIENDS_DATA_DIR: dir,
    PLAYER_TOKEN_SECRET: E2E_TOKEN_SECRET,
    ...extra,
  };
}
