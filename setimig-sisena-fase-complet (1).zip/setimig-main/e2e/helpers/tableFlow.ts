import { expect, type Page } from "@playwright/test";
import { openFriendsLobby } from "./friendsLobby";

/** Signals that a hand has left the private waiting room. */
export function handSurface(page: Page) {
  return page
    .getByTestId("bet-confirm")
    .or(page.getByTestId("action-stand"))
    .or(page.getByTestId("match-hand-counter"))
    .or(page.getByTestId("status-pill"))
    .or(page.getByText("Sorteig de banca"));
}

export function settlementSurface(page: Page) {
  return page
    .getByTestId("settlement-sheet")
    .or(page.getByTestId("my-hand-result"))
    .or(page.getByTestId("seat-hand-result"));
}

/** The visible local hand, not the padded seat wrapper that reserves dock space. */
export function localHand(page: Page) {
  return page
    .getByTestId("local-hand-fan-slot")
    .or(page.getByTestId("local-player-seat").locator(".spanish-card-size-player").first());
}

export async function waitForHandSurface(page: Page, timeout = 60_000) {
  await expect(handSurface(page).first()).toBeVisible({ timeout });
}

export async function confirmBetIfShown(page: Page) {
  const bet = page.getByTestId("bet-confirm");
  if (await bet.isVisible().catch(() => false)) {
    await bet.click({ timeout: 10_000 });
    await expect(bet).toBeHidden({ timeout: 20_000 });
  }
}

/**
 * Plays the human actions that are legal until the single per-hand settlement is on screen.
 * Bots act on their own (about 1.2–1.5s each); the poll follows state instead of sleeping.
 */
export async function playUntilSettlement(page: Page, timeout = 150_000) {
  await expect
    .poll(
      async () => {
        const bet = page.getByTestId("bet-confirm");
        if ((await bet.isVisible().catch(() => false)) && (await bet.isEnabled().catch(() => false))) {
          // A short action timeout so a covered control cannot stall the poll past the test deadline.
          await bet.click({ timeout: 1_000 }).catch(() => undefined);
        }
        const stand = page.getByTestId("action-stand");
        if ((await stand.isVisible().catch(() => false)) && (await stand.isEnabled().catch(() => false))) {
          await stand.click({ timeout: 1_000 }).catch(() => undefined);
        }
        return settlementSurface(page).first().isVisible().catch(() => false);
      },
      { timeout, intervals: [200, 350, 500] }
    )
    .toBe(true);
  await expect(settlementSurface(page).first()).toBeVisible();
}

/** Leave is armed: the first tap asks for confirmation, the second returns to the lobby. */
export async function leaveGameToLobby(page: Page) {
  const leave = page.getByRole("button", { name: "Sortir de la partida" });
  await expect(leave).toBeVisible();
  await leave.click();
  const confirm = page.getByRole("button", { name: "Confirmar sortida de la partida" });
  await expect(confirm).toBeVisible();
  await confirm.click();
  await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 20_000 });
}

export async function createPrivateTable(page: Page) {
  await openFriendsLobby(page);
  const create = page.getByTestId("create-private-table-inline");
  await expect(create).toBeEnabled();
  await create.click();
  await expect(page.getByTestId("private-waiting-panel")).toBeVisible({ timeout: 30_000 });
}

export async function readInviteCode(page: Page) {
  const text = (await page.getByTestId("private-invite-code").innerText()).trim();
  const code = text.replace(/^codi\s+/i, "").trim();
  expect(code).toMatch(/^[A-Z0-9]{4,8}$/);
  return code;
}

/** On narrow viewports the chat toggle lives inside the table tools menu. */
export async function openTableChat(page: Page) {
  const direct = page.getByTestId("table-chat-toggle");
  if (!(await direct.isVisible().catch(() => false))) {
    await page.getByRole("button", { name: "Obrir menú de taula" }).click();
  }
  await expect(direct).toBeVisible();
  await direct.click();
  await expect(page.getByTestId("table-chat-sheet")).toBeVisible();
}

export async function assertLocalHandVisible(page: Page) {
  const hand = localHand(page).first();
  await expect(hand).toBeVisible({ timeout: 90_000 });
  const box = await hand.boundingBox();
  expect(box?.height ?? 0).toBeGreaterThan(24);
  expect(box?.width ?? 0).toBeGreaterThan(24);
}

/** The hand itself must stay clear of the action dock; the seat's dock-reserve padding is not the hand. */
export async function assertHandNotCoveredByDock(page: Page) {
  const covered = await page.evaluate(() => {
    const hand =
      (document.querySelector("[data-testid='local-hand-fan-slot']") as HTMLElement | null) ??
      (document.querySelector("[data-testid='local-player-seat'] .spanish-card-size-player") as HTMLElement | null);
    const dock = document.querySelector("[data-testid='action-dock']") as HTMLElement | null;
    if (!hand || !dock) return false;
    const a = hand.getBoundingClientRect();
    const b = dock.getBoundingClientRect();
    const overlap = a.left < b.right && a.right > b.left && a.top < b.bottom && a.bottom > b.top;
    if (!overlap) return false;
    const area =
      (Math.min(a.right, b.right) - Math.max(a.left, b.left)) *
      (Math.min(a.bottom, b.bottom) - Math.max(a.top, b.top));
    const handArea = a.width * a.height;
    return handArea > 0 && area / handArea > 0.55;
  });
  expect(covered).toBe(false);
}
