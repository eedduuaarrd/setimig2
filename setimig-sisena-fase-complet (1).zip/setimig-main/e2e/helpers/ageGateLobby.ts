import { expect, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./e2eSession.ts";

export type LobbyEntryOptions = {
  /** Stable id; must be in E2E_ACCOUNT_IDS (e2eSession.ts). A pool account is used when omitted. */
  playerId?: string;
  /** Path including query, e.g. `/?t=AB12CD`. Defaults to `/`. */
  path?: string;
  /**
   * Wait until «Amb amics» is available. That control stays aria-disabled until the
   * socket is connected; the header no longer renders a «connected» indicator.
   */
  online?: boolean;
};

export async function passAgeGateToLobby(page: Page, name = "E2ePlayer", options: LobbyEntryOptions = {}) {
  const id = options.playerId ?? e2ePoolId();
  // Login obligatori (#262): sessió real abans de carregar l'app.
  await seedE2eSession(page, id);
  await page.addInitScript(
    ({ playerId, playerName }: { playerId: string; playerName: string }) => {
      localStorage.setItem("setimig_player_id", playerId);
      localStorage.setItem("setimig_player_name", playerName);
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      // The app saves setimig_private_rejoin_code on join and strips ?t= from the URL.
      // This script runs on every navigation, including reload; clearing the code then
      // drops the seat the server is still holding.
      if (!sessionStorage.getItem("e2e_lobby_seeded")) {
        localStorage.removeItem("setimig_private_rejoin_code");
        sessionStorage.setItem("e2e_lobby_seeded", "1");
      }
      localStorage.setItem(
        "setimig_age_gate",
        JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
      );
    },
    { playerId: id, playerName: name }
  );
  await page.goto(options.path ?? "/");
  const nameInput = page.getByTestId("age-gate-name");
  if (await nameInput.isVisible().catch(() => false)) {
    await nameInput.fill(name);
    await page.getByTestId("age-gate-accept").click();
  }
  await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 60_000 });
  if (options.online) {
    await expect(page.getByTestId("play-with-friends-button")).not.toHaveAttribute("aria-disabled", "true", {
      timeout: 30_000,
    });
  }
}
