import type { Page } from "@playwright/test";

export async function seedAgeGateFresh(page: Page, name = "A11yTest") {
  const id = `a11y-${Date.now()}`;
  await page.addInitScript(
    ({ playerId, playerName }) => {
      localStorage.setItem("setimig_player_id", playerId);
      localStorage.setItem("setimig_player_name", playerName);
      localStorage.removeItem("setimig_age_gate");
      localStorage.removeItem("setimig_onboarding_v1");
    },
    { playerId: id, playerName: name }
  );
}

export async function seedLobby(page: Page, name = "A11yTest") {
  const id = `a11y-${Date.now()}`;
  await page.addInitScript(
    ({ playerId, playerName }) => {
      localStorage.setItem("setimig_player_id", playerId);
      localStorage.setItem("setimig_player_name", playerName);
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem(
        "setimig_age_gate",
        JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
      );
    },
    { playerId: id, playerName: name }
  );
}

export function splitTurnSnapshotJson(playerId: string, playerName: string) {
  const card = (suit: "hearts" | "spades") => ({ suit, value: 10, points: 0.5 });
  return JSON.stringify({
    version: 1,
    playerId,
    playerName,
    botCount: 1,
    difficulty: "normal",
    room: {
      id: "local-a11y-split",
      name: "Partida IA",
      players: [
        {
          id: `local-human-${playerId}`,
          playerId,
          seatToken: "split-human-token",
          name: playerName,
          chips: 900,
          bet: 100,
          isBanker: false,
          isBot: false,
          status: "playing",
          handSlots: [
            {
              id: "split-hand-1",
              bet: 100,
              cards: [
                { id: "figure-hearts", card: card("hearts"), faceUp: true },
                { id: "figure-spades", card: card("spades"), faceUp: true },
              ],
              doubled: false,
              canDouble: false,
              mort: false,
              blindPair: false,
              blindUntilBankEnd: false,
              mortOffered: false,
              status: "playing",
            },
          ],
          activeSlotIndex: 0,
          lastRoyal7Payout: 0,
          royal7AsBankerStreak: 0,
        },
        {
          id: "bot-a11y-bank",
          playerId: "bot-a11y-bank",
          seatToken: "split-bank-token",
          name: "Laia",
          chips: 5000,
          bet: 0,
          isBanker: true,
          isBot: true,
          status: "playing",
          handSlots: [
            {
              id: "bank-hand",
              bet: 0,
              cards: [{ id: "bank-card", card: card("hearts"), faceUp: false }],
              doubled: false,
              canDouble: false,
              mort: false,
              blindPair: false,
              blindUntilBankEnd: false,
              mortOffered: false,
              status: "playing",
            },
          ],
          activeSlotIndex: 0,
          lastRoyal7Payout: 0,
          royal7AsBankerStreak: 0,
        },
      ],
      deck: [],
      pot: 100,
      phase: "playing",
      minBet: 100,
      jackpot: 0,
      lastRound: null,
      centerDiscard: [],
      turnPlayerIndex: 0,
      soloAi: true,
      soloHumanPlayerId: playerId,
      soloBotCount: 1,
      sessionStats: [[playerId, { handsPlayed: 1, handsWon: 0, netCf: 0, winStreak: 0, lastOutcome: null }]],
      matchEnded: false,
      matchResult: null,
      houseRulesEnabled: true,
      turnDeadlineAt: Date.now() + 60_000,
    },
  });
}

export function matchEndSnapshotJson(playerId: string, playerName: string) {
  return JSON.stringify({
    version: 1,
    playerId,
    playerName,
    botCount: 1,
    difficulty: "normal",
    room: {
      id: "local-a11y-match",
      name: "Partida IA",
      players: [
        {
          id: playerId,
          name: playerName,
          chips: 4200,
          bet: 0,
          isBanker: false,
          isBot: false,
          status: "waiting",
          handSlots: [{ id: "s0", cards: [] }],
          activeSlotIndex: 0,
        },
        {
          id: "bot-a11y-1",
          name: "Laia",
          chips: 3800,
          bet: 0,
          isBanker: true,
          isBot: true,
          status: "waiting",
          handSlots: [{ id: "b0", cards: [] }],
          activeSlotIndex: 0,
        },
      ],
      deck: [],
      pot: 0,
      phase: "playing",
      minBet: 100,
      jackpot: 0,
      lastRound: null,
      centerDiscard: [],
      turnPlayerIndex: 0,
      soloAi: true,
      soloHumanPlayerId: playerId,
      soloBotCount: 1,
      sessionStats: [
        [
          playerId,
          {
            handsPlayed: 10,
            handsWon: 6,
            netCf: 200,
            winStreak: 2,
            bestHandWin: 150,
          },
        ],
      ],
      matchEnded: true,
      matchResult: {
        viewerOutcome: "win",
        winnerName: playerName,
        ranking: [
          { name: playerName, chips: 4200, eliminated: false, isHuman: true },
          { name: "Laia", chips: 3800, eliminated: false, isHuman: false },
        ],
      },
      phaseB: { handsTotal: 10, handsCompleted: 10, chipPool: 8000 },
    },
  });
}
