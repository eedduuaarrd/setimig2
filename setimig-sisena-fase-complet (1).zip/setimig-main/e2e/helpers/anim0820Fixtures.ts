/** Animacions PR 5 (08 banca, 11 inici, 19 assoliment, 20 tutorial): snapshots solo IA. */
type Suit = "hearts" | "diamonds" | "clubs" | "spades";
type Card = { suit: Suit; value: number; points: number };
export const card = (value: number, suit: Suit = "hearts"): Card => ({
  suit,
  value,
  points: value >= 10 ? 0.5 : value,
});

const SUITS: Suit[] = ["spades", "clubs", "diamonds", "hearts"];
const FILLER = Array.from({ length: 14 }, (_, i) => card(10 + (i % 3), SUITS[i % 4]));

function seat(o: {
  key: string;
  name: string;
  playerId: string;
  bank?: boolean;
  human?: boolean;
  bet?: number;
  chips?: number;
  status?: string;
  cards?: number[];
  faceUp?: boolean | boolean[];
}) {
  const id = o.human ? `local-human-${o.playerId}` : `bot-anim-${o.key}`;
  const slotId = `${o.key}-hand`;
  const cards = o.cards ?? [];
  return {
    id,
    playerId: o.human ? o.playerId : id,
    seatToken: `${o.key}-token`,
    name: o.name,
    chips: o.chips ?? (o.bank ? 5000 : 900),
    bet: o.bet ?? 0,
    isBanker: !!o.bank,
    isBot: !o.human,
    status: o.status ?? (o.bet ? "playing" : "betting"),
    handSlots: cards.length
      ? [
          {
            id: slotId,
            bet: o.bet ?? 0,
            cards: cards.map((v, i) => ({
              id: `${slotId}-c${i}`,
              card: card(v, SUITS[(i + 1) % 4]),
              faceUp: Array.isArray(o.faceUp) ? !!o.faceUp[i] : o.faceUp !== false,
            })),
            doubled: false,
            canDouble: false,
            mort: false,
            status: o.status ?? "playing",
          },
        ]
      : [],
    activeSlotIndex: 0,
    lastAction: null,
    pendingChoices: null,
  };
}

/** El teu torn amb carta tapada (tutorial 20) i banca a Laia. */
export function playingFaceDownSnapshot(playerId: string): string {
  return JSON.stringify({
    version: 1,
    playerId,
    playerName: "Edu",
    botCount: 2,
    difficulty: "normal",
    room: {
      id: `local-anim0820-play-${playerId}`,
      name: "Partida IA",
      pot: 200,
      minBet: 100,
      jackpot: 0,
      lastRound: null,
      centerDiscard: [],
      soloAi: true,
      practiceMode: true,
      soloHumanPlayerId: playerId,
      soloBotCount: 2,
      sessionStats: [[playerId, { handsPlayed: 1, handsWon: 0, netCf: 0, winStreak: 0, lastOutcome: null }]],
      matchProgress: { handNumber: 1, totalHands: 10 },
      matchEnded: false,
      matchResult: null,
      houseRulesEnabled: false,
      turnDeadlineAt: Date.now() + 60_000,
      phase: "playing",
      turnPlayerIndex: 0,
      deck: [...FILLER],
      players: [
        seat({
          key: "you",
          name: "Edu",
          playerId,
          human: true,
          bet: 100,
          chips: 800,
          status: "playing",
          cards: [6, 3],
          faceUp: [false, true],
        }),
        seat({
          key: "anna",
          name: "Anna",
          playerId: "bot-anna",
          bet: 100,
          chips: 800,
          status: "standing",
          cards: [5, 2],
          faceUp: true,
        }),
        seat({
          key: "bank",
          name: "Laia",
          playerId: "bot-bank",
          bank: true,
          chips: 5000,
          status: "waiting",
          cards: [4],
          faceUp: false,
        }),
      ],
    },
  });
}

/** Liquidació: no decides Hit/Stand (toast 19). */
export function settlementSnapshot(playerId: string): string {
  return JSON.stringify({
    version: 1,
    playerId,
    playerName: "Edu",
    botCount: 1,
    difficulty: "normal",
    room: {
      id: `local-anim0820-settle-${playerId}`,
      name: "Partida IA",
      pot: 0,
      minBet: 100,
      jackpot: 0,
      lastRound: {
        title: "Hand over",
        results: [],
        highlights: [],
      },
      centerDiscard: [],
      soloAi: true,
      practiceMode: true,
      soloHumanPlayerId: playerId,
      soloBotCount: 1,
      sessionStats: [[playerId, { handsPlayed: 2, handsWon: 1, netCf: 100, winStreak: 1, lastOutcome: "win" }]],
      matchProgress: { handNumber: 2, totalHands: 10 },
      matchEnded: false,
      matchResult: null,
      houseRulesEnabled: false,
      turnDeadlineAt: null,
      phase: "settlement",
      turnPlayerIndex: 0,
      deck: [...FILLER],
      players: [
        seat({
          key: "you",
          name: "Edu",
          playerId,
          human: true,
          bet: 100,
          chips: 900,
          status: "standing",
          cards: [7, 10],
          faceUp: true,
        }),
        seat({
          key: "bank",
          name: "Laia",
          playerId: "bot-bank",
          bank: true,
          chips: 5000,
          status: "standing",
          cards: [5, 2],
          faceUp: true,
        }),
      ],
    },
  });
}
