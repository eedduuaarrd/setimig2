/**
 * Animacions PR 3 (04 recollir, 06 fitxes, 07 7½, 10 guanya-perd): partides locals (solo IA, sense socket) amb el mall
 * controlat. El motor fa `deck.pop()`, així que `draws` són les cartes que sortiran, en ordre.
 * Ordre de joc (shared/gameEngine.ts · nonBankersInPlayOrder): els seients que segueixen la banca, i la banca l'última.
 */
type Suit = "hearts" | "diamonds" | "clubs" | "spades";
type Card = { suit: Suit; value: number; points: number };
export const card = (value: number, suit: Suit = "hearts"): Card => ({ suit, value, points: value >= 10 ? 0.5 : value });

export type SeatSpec = {
  key: string;
  name: string;
  bank?: boolean;
  human?: boolean;
  bet?: number;
  status?: string;
  /** Valors de les cartes (10, 11, 12 = sota, cavall, rei = ½). */
  cards?: number[];
  /** Primera carta tapada (la «tapada»). */
  tapada?: boolean;
  slotStatus?: string;
};

const SUITS: Suit[] = ["spades", "clubs", "diamonds", "hearts"];
const FILLER = Array.from({ length: 16 }, (_, i) => card(10 + (i % 3), SUITS[i % 4]));

function seat(s: SeatSpec, playerId: string) {
  const id = s.human ? `local-human-${playerId}` : `bot-anim-${s.key}`;
  const slotId = `${s.key}-hand`;
  const cards = s.cards ?? [];
  return {
    id,
    playerId: s.human ? playerId : id,
    seatToken: `${s.key}-token`,
    name: s.name,
    chips: s.bank ? 5000 : 900,
    bet: s.bet ?? 0,
    isBanker: !!s.bank,
    isBot: !s.human,
    status: s.status ?? "playing",
    handSlots: cards.length
      ? [
          {
            id: slotId,
            bet: s.bet ?? 0,
            cards: cards.map((v, i) => ({ id: `${slotId}-c${i}`, card: card(v, SUITS[(i + s.key.length) % 4]), faceUp: !(s.tapada && i === 0) })),
            doubled: false,
            canDouble: false,
            mort: false,
            blindPair: false,
            blindUntilBankEnd: false,
            mortOffered: false,
            status: s.slotStatus ?? "playing",
          },
        ]
      : [],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
  };
}

export function animSnapshot(o: {
  playerId: string;
  phase: "betting" | "playing" | "banker";
  seats: SeatSpec[];
  /** Índex dins de l'ordre de joc (sense la banca). */
  turn?: number;
  draws?: number[];
  deadlineMs?: number;
}): string {
  const deck = [...FILLER, ...(o.draws ?? []).map((v, i) => card(v, SUITS[(i + 1) % 4])).reverse()];
  const name = o.seats.find((s) => s.human)?.name ?? "Edu";
  return JSON.stringify({
    version: 1,
    playerId: o.playerId,
    playerName: name,
    botCount: o.seats.filter((s) => !s.human && !s.bank).length || 1,
    difficulty: "normal",
    room: {
      id: `local-anim0410-${o.playerId}`,
      name: "Partida IA",
      pot: 300,
      minBet: 100,
      jackpot: 0,
      lastRound: null,
      centerDiscard: [],
      soloAi: true,
      practiceMode: true,
      soloHumanPlayerId: o.playerId,
      soloBotCount: o.seats.filter((s) => !s.human && !s.bank).length || 1,
      sessionStats: [[o.playerId, { handsPlayed: 2, handsWon: 0, netCf: 0, winStreak: 0, lastOutcome: null }]],
      matchProgress: { handNumber: 3, totalHands: 10 },
      matchEnded: false,
      matchResult: null,
      houseRulesEnabled: true,
      turnDeadlineAt: Date.now() + (o.deadlineMs ?? 60_000),
      bettingDeadlineAt: o.phase === "betting" ? Date.now() + 60_000 : null,
      phase: o.phase,
      turnPlayerIndex: o.turn ?? 0,
      deck,
      players: o.seats.map((s) => seat(s, o.playerId)),
    },
  });
}
