import { expect, type Page } from "@playwright/test";

export async function openFriendsLobby(page: Page) {
  await page.getByTestId("play-with-friends-button").click();
  await expect(page.getByTestId("friends-table-section")).toBeVisible();
}
