import fs from "fs/promises";

/** Esborra el directori de dades del servidor E2E (creat per e2eServerEnv) en acabar la tanda. */
export default async function globalTeardown(): Promise<void> {
  const dir = process.env.SETIMIG_E2E_DATA_DIR;
  if (!dir || !dir.includes("setimig-e2e-data-")) return;
  await fs.rm(dir, { recursive: true, force: true, maxRetries: 10, retryDelay: 50 }).catch(() => undefined);
}
