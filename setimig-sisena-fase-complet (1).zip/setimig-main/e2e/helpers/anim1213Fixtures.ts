/** Animacions 12 (total) i 13 (el teu torn): partida local (solo IA) amb el mall controlat (el motor fa deck.pop()). */
type Card = { suit: "hearts" | "diamonds" | "clubs" | "spades"; value: number; points: number };
export const card = (value: number, suit: Card["suit"] = "hearts"): Card => ({ suit, value, points: value >= 10 ? 0.5 : value });

function seat(o: { id: string; playerId: string; name: string; isBanker: boolean; isBot: boolean; bet: number; cards: Card[]; faceUp: boolean }) {
  const slotId = `${o.id}-hand`;
  return {
    id: o.id,
    playerId: o.playerId,
    seatToken: `${o.id}-token`,
    name: o.name,
    chips: o.isBanker ? 5000 : 900,
    bet: o.bet,
    isBanker: o.isBanker,
    isBot: o.isBot,
    status: "playing",
    handSlots: [
      {
        id: slotId,
        bet: o.bet,
        cards: o.cards.map((c, i) => ({ id: `${slotId}-c${i}`, card: c, faceUp: o.faceUp })),
        doubled: false,
        canDouble: false,
        mort: false,
        blindPair: false,
        blindUntilBankEnd: false,
        mortOffered: false,
        status: "playing",
      },
    ],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
  };
}

const FILLER = Array.from({ length: 12 }, (_, i) => card(10 + (i % 3), (["hearts", "diamonds", "clubs", "spades"] as const)[i % 4]));

/**
 * El teu torn amb `cards` a la mà. `draws`: les cartes que trauràs en ordre (la primera surt al primer «Hit»).
 */
export function myTurnSnapshot(playerId: string, name: string, cards: number[], draws: number[] = []): string {
  const deck = [...FILLER, ...draws.map((v, i) => card(v, (["spades", "clubs", "diamonds", "hearts"] as const)[i % 4])).reverse()];
  return JSON.stringify({
    version: 1,
    playerId,
    playerName: name,
    botCount: 1,
    difficulty: "normal",
    room: {
      id: `local-anim-${playerId}`,
      name: "Partida IA",
      pot: 100,
      minBet: 100,
      jackpot: 0,
      lastRound: null,
      centerDiscard: [],
      soloAi: true,
      soloHumanPlayerId: playerId,
      soloBotCount: 1,
      sessionStats: [[playerId, { handsPlayed: 2, handsWon: 0, netCf: 0, winStreak: 0, lastOutcome: null }]],
      matchProgress: { handNumber: 3, totalHands: 10 },
      matchEnded: false,
      matchResult: null,
      houseRulesEnabled: true,
      turnDeadlineAt: Date.now() + 60_000,
      phase: "playing",
      turnPlayerIndex: 0,
      deck,
      players: [
        seat({ id: `local-human-${playerId}`, playerId, name, isBanker: false, isBot: false, bet: 100, cards: cards.map((v) => card(v)), faceUp: true }),
        seat({ id: "bot-anim-bank", playerId: "bot-anim-bank", name: "Laia", isBanker: true, isBot: true, bet: 0, cards: [card(3, "clubs")], faceUp: false }),
      ],
    },
  });
}
