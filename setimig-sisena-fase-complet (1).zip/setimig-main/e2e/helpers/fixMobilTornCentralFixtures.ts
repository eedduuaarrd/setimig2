import { splitTurnSnapshotJson } from "./uxA11yFixtures.ts";

const card = (suit: "hearts" | "clubs" | "spades", value: number, points: number) => ({
  suit,
  value,
  points,
});

/** Playing phase with enough cards to render the centre active-turn hand on mobile. */
export function activeTurnCenterHandSnapshotJson(playerId: string, playerName: string): string {
  const base = JSON.parse(splitTurnSnapshotJson(playerId, playerName)) as {
    room: Record<string, unknown>;
    playerId: string;
    playerName: string;
    version: number;
    botCount: number;
    difficulty: string;
  };
  const human = (base.room.players as Array<Record<string, unknown>>)[0]!;
  const slot = (human.handSlots as Array<Record<string, unknown>>)[0]!;
  slot.cards = [
    { id: "c1", card: card("hearts", 2, 2), faceUp: false },
    { id: "c2", card: card("clubs", 4, 4), faceUp: true },
    { id: "c3", card: card("spades", 10, 0.5), faceUp: true },
    { id: "c4", card: card("hearts", 3, 3), faceUp: true },
  ];
  return JSON.stringify(base);
}

/** Betting phase: local human must place a bet; centre mesa shows the turn prompt. */
export function bettingTurnSnapshotJson(playerId: string, playerName: string): string {
  return JSON.stringify({
    version: 1,
    playerId,
    playerName,
    botCount: 1,
    difficulty: "normal",
    room: {
      id: "local-fix-mobil-bet",
      name: "Partida IA",
      players: [
        {
          id: `local-human-${playerId}`,
          playerId,
          seatToken: "bet-human-token",
          name: playerName,
          chips: 900,
          bet: 0,
          isBanker: false,
          isBot: false,
          status: "betting",
          handSlots: [],
          activeSlotIndex: 0,
          lastRoyal7Payout: 0,
          royal7AsBankerStreak: 0,
        },
        {
          id: "bot-fix-mobil-bank",
          playerId: "bot-fix-mobil-bank",
          seatToken: "bet-bank-token",
          name: "Laia",
          chips: 5000,
          bet: 0,
          isBanker: true,
          isBot: true,
          status: "betting",
          handSlots: [],
          activeSlotIndex: 0,
          lastRoyal7Payout: 0,
          royal7AsBankerStreak: 0,
        },
      ],
      deck: [],
      pot: 400,
      phase: "betting",
      minBet: 100,
      jackpot: 0,
      lastRound: null,
      centerDiscard: [],
      turnPlayerIndex: 0,
      soloAi: true,
      soloHumanPlayerId: playerId,
      soloBotCount: 1,
      sessionStats: [[playerId, { handsPlayed: 0, handsWon: 0, netCf: 0, winStreak: 0, lastOutcome: null }]],
      matchEnded: false,
      matchResult: null,
      houseRulesEnabled: true,
      turnDeadlineAt: Date.now() + 60_000,
    },
  });
}
