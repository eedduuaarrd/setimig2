import { splitTurnSnapshotJson } from "./uxA11yFixtures.ts";

const card = (suit: "hearts" | "clubs" | "spades", value: number, points: number) => ({
  suit,
  value,
  points,
});

function basePlayingSnapshot(playerId: string, playerName: string, practiceMode: boolean) {
  const base = JSON.parse(splitTurnSnapshotJson(playerId, playerName)) as {
    room: Record<string, unknown>;
    playerId: string;
    playerName: string;
    version: number;
    botCount: number;
    difficulty: string;
  };
  base.room.practiceMode = practiceMode;
  return base;
}

export function playingTurnSnapshotJson(
  playerId: string,
  playerName: string,
  cardCount: number,
  practiceMode = false
): string {
  const base = basePlayingSnapshot(playerId, playerName, practiceMode);
  const human = (base.room.players as Array<Record<string, unknown>>)[0]!;
  const slot = (human.handSlots as Array<Record<string, unknown>>)[0]!;
  const deck = [
    { id: "c1", card: card("hearts", 2, 2), faceUp: false },
    { id: "c2", card: card("clubs", 4, 4), faceUp: true },
    { id: "c3", card: card("spades", 10, 0.5), faceUp: true },
    { id: "c4", card: card("hearts", 3, 3), faceUp: true },
    { id: "c5", card: card("spades", 5, 5), faceUp: true },
  ];
  slot.cards = deck.slice(0, Math.max(2, Math.min(5, cardCount)));
  return JSON.stringify(base);
}
