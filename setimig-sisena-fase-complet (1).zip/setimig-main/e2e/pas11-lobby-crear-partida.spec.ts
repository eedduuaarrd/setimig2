import { expect, test } from "@playwright/test";
import fs from "node:fs";
import path from "node:path";
import { startAiGameFromLobby } from "./helpers/aiLobby";
import { passAgeGateToLobby } from "./helpers/ageGateLobby";
import { openFriendsLobby } from "./helpers/friendsLobby";
import { handSurface, leaveGameToLobby, waitForHandSurface } from "./helpers/tableFlow";

const VIEWPORTS = [
  { name: "mobile-390x844", width: 390, height: 844 },
  { name: "pc-1280x800", width: 1280, height: 800 },
] as const;

function screenshotDir(): string {
  const candidates = [
    "/cursor/stores/self/media/pas11",
    path.join(process.cwd(), "media/pas11"),
  ];
  for (const dir of candidates) {
    try {
      fs.mkdirSync(dir, { recursive: true });
      return dir;
    } catch {
      /* try next */
    }
  }
  return candidates[candidates.length - 1];
}

async function assertHeaderLayoutMobile(page: import("@playwright/test").Page) {
  await expect(page.getByTestId("app-header")).toBeVisible();
  // Lobby v4.1 (C1): al lobby la capçalera no porta la marca, només saldo i perfil.
  await expect(page.getByTestId("app-header-title")).toHaveCount(0);
  await expect(page.getByText("Joc de cartes en directe")).toBeHidden();
  await expect(page.getByTestId("connection-indicator").getByText("Connectat")).toBeHidden();
  await expect(page.getByTestId("connection-indicator").getByText("Desconnectat")).toBeHidden();

  const layout = await page.evaluate(() => {
    const header = document.querySelector('[data-testid="app-header"]');
    const row = header?.querySelector(":scope > div");
    const actions = document.querySelector('[data-testid="app-header-actions"]') as HTMLElement | null;
    // Lobby v4.1 (C1): sense marca, el primer fill de la fila ja és el bloc d'accions.
    const first = row?.children[0] as HTMLElement | undefined;
    const brand = first && first !== actions ? first : undefined;
    const title = document.querySelector('[data-testid="app-header-title"]') as HTMLElement | null;

    const blocks: HTMLElement[] = [];
    if (brand) blocks.push(brand);
    if (actions) {
      for (const child of actions.children) blocks.push(child as HTMLElement);
    }

    const visible = blocks.filter((el) => {
      const style = getComputedStyle(el);
      const rect = el.getBoundingClientRect();
      return style.visibility !== "hidden" && style.display !== "none" && rect.width > 0 && rect.height > 0;
    });

    const rects = visible.map((el) => el.getBoundingClientRect());
    for (let i = 0; i < rects.length; i++) {
      for (let j = i + 1; j < rects.length; j++) {
        const a = rects[i];
        const b = rects[j];
        const overlap =
          a.right > b.left + 1 && b.right > a.left + 1 && a.bottom > b.top + 1 && b.bottom > a.top + 1;
        if (overlap) return { ok: false, reason: "overlap", i, j };
      }
    }

    const titleStyle = title ? getComputedStyle(title) : null;
    const titleRect = title?.getBoundingClientRect();
    const lineHeight = titleStyle ? parseFloat(titleStyle.lineHeight) : 0;
    const singleLineTitle = titleRect ? titleRect.height <= lineHeight * 1.35 : !title;

    const headerEl = header as HTMLElement;
    const overflows = headerEl.scrollWidth > window.innerWidth + 2;

    return { ok: !overflows && singleLineTitle, overflows, singleLineTitle };
  });

  expect(layout.ok).toBe(true);
}

for (const vp of VIEWPORTS) {
  test(`PAS 11 lobby Crear partida ${vp.name}`, async ({ page }) => {
    const out = screenshotDir();
    await page.setViewportSize({ width: vp.width, height: vp.height });
    await passAgeGateToLobby(page, `Pas11-${vp.name}`, {
      playerId: `pas11crear${vp.width}x`,
      online: true,
    });

    await expect(page.getByTestId("play-vs-ai-button")).toHaveText(/^Jugar$/i);
    await page.getByTestId("play-with-friends-button").click();
    const createBtn = page.getByTestId("create-private-table-inline");
    await expect(createBtn).toBeVisible();
    await expect(createBtn).toHaveText(/Crear taula privada/i);

    await page.screenshot({
      path: path.join(out, `${vp.name}-lobby-crear-partida.png`),
      fullPage: false,
    });

    await createBtn.click();
    await expect(page.getByTestId("private-waiting-panel")).toBeVisible({ timeout: 30_000 });
  });
}

// Lobby v4.1 (C1): al lobby no hi ha barra inferior; la partida privada es crea des de «Amb amics».
test("PAS 11 — lobby sense barra inferior; «Amb amics» porta a Crear partida", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await passAgeGateToLobby(page, "Pas11BottomBar", { playerId: "pas11bottombar01" });

  await expect(page.getByTestId("lobby-bottom-bar")).toHaveCount(0);
  await expect(page.getByRole("button", { name: "Saldo", exact: true })).toHaveCount(0);
  await openFriendsLobby(page);
  const create = page.getByTestId("create-private-table-inline");
  await expect(create).toBeVisible();
  await expect(create).toHaveText(/Crear/i);
});

test("PAS 11 — IA bot picker mobile bottom sheet", async ({ page }) => {
  const out = screenshotDir();
  await page.setViewportSize({ width: 390, height: 844 });
  await passAgeGateToLobby(page, "Pas11AiMobile", { playerId: "pas11aimobile001", online: true });

  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  await page.getByTestId("ai-bot-count-4").click();
  await page.screenshot({ path: path.join(out, "ai-bot-picker-mobile-390.png"), fullPage: false });
  await page.getByRole("button", { name: "Cancel·lar" }).click();
  await expect(page.getByTestId("ai-bot-picker")).toHaveCount(0);
  await startAiGameFromLobby(page, 3);
  await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 45_000 });
});

test("PAS 11 — friends modal from Amb amics", async ({ page }) => {
  const out = screenshotDir();
  await page.setViewportSize({ width: 390, height: 844 });
  await passAgeGateToLobby(page, "Pas11Friends", { playerId: "pas11friends0001", online: true });
  await openFriendsLobby(page);
  await page.screenshot({ path: path.join(out, "friends-modal-mobile-390.png"), fullPage: false });
});

test("PAS 11 — table creator selects and sees the inclusive bet range", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await passAgeGateToLobby(page, "BetLimitHost", { playerId: "pas11betlimith01", online: true });
  await openFriendsLobby(page);
  await page.getByTestId("private-table-min-bet").fill("600");
  await page.getByTestId("private-table-max-bet").fill("550");
  await expect(page.getByTestId("create-private-table-inline")).toBeDisabled();
  await expect(page.getByRole("alert")).toContainText("igual o superior");
  await page.getByTestId("private-table-min-bet").fill("200");
  await page.getByTestId("private-table-max-bet").fill("1000001");
  await expect(page.getByTestId("create-private-table-inline")).toBeDisabled();
  await expect(page.getByRole("alert")).toContainText("1.000.000");
  await page.getByTestId("private-table-max-bet").fill("550");
  await expect(page.getByTestId("create-private-table-inline")).toBeEnabled();
  await page.getByTestId("create-private-table-inline").click();
  await expect(page.getByTestId("private-waiting-panel")).toBeVisible({ timeout: 30_000 });
  await expect(page.getByTestId("private-table-bet-limits")).toContainText("200–550 fitxes");
  await expect(page.getByTestId("private-table-bet-limits")).toContainText("inclosos els dos límits");
});

test("PAS 11 — free chips popup from header balance", async ({ page }) => {
  const out = screenshotDir();
  await page.setViewportSize({ width: 390, height: 844 });
  await passAgeGateToLobby(page, "Pas11FreeChips", { playerId: "pas11freechips01", online: true });
  await page.getByTestId("header-balance-chip").click();
  await expect(page.getByTestId("free-chips-modal")).toBeVisible();
  await page.screenshot({ path: path.join(out, "free-chips-modal-390.png"), fullPage: false });
  const claimBtn = page.getByTestId("claim-free-chips-button");
  if (await claimBtn.isEnabled()) {
    await claimBtn.click();
    await expect(page.getByTestId("free-chips-balance")).toBeVisible();
  }
});

// S1 (millores-nit, servidor #184): «Sortir» confirmat tanca la sessió solo, així que el lobby
// ja no ofereix «Continuar la partida». Reprendre després d'una recàrrega sense sortir: test següent.
test("PAS 11 — leave IA mid-game closes the session (no resume)", async ({ page }) => {
  test.setTimeout(120_000);
  await page.setViewportSize({ width: 390, height: 844 });
  await passAgeGateToLobby(page, "Pas11RejoinLeave", { playerId: "pas11rejoinleave1", online: true });
  await startAiGameFromLobby(page, 1);
  await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 45_000 });
  await waitForHandSurface(page);
  await leaveGameToLobby(page);
  await page.waitForTimeout(1_500);
  await expect(page.getByTestId("resume-game-button")).toHaveCount(0);
});

test("PAS 11 — reload resumes IA game", async ({ page }) => {
  test.setTimeout(150_000);
  await page.setViewportSize({ width: 390, height: 844 });
  await passAgeGateToLobby(page, "Pas11RejoinReload", { playerId: "pas11reloadresume01", online: true });
  await startAiGameFromLobby(page, 1);
  await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 60_000 });
  await waitForHandSurface(page);
  await page.reload({ waitUntil: "domcontentloaded" });
  // Connect rejoins the online solo (attemptSoloRejoinOnConnect). The lobby
  // resume control is only the exiting tree under the loading screen (S1: after
  // a confirmed «Sortir» there is no resume at all, see the test above).
  const leaveBtn = page.getByRole("button", { name: "Sortir de la partida" });
  await expect(leaveBtn).toBeVisible({ timeout: 60_000 });
  await expect(handSurface(page).first()).toBeVisible({ timeout: 60_000 });
});

for (const width of [360, 390] as const) {
  test(`PAS 11 — mobile header no overlap at ${width}px`, async ({ page }) => {
    const out = screenshotDir();
    await page.setViewportSize({ width, height: 844 });
    await passAgeGateToLobby(page, `Pas11Header${width}`, {
      playerId: `pas11header${width}x`,
      online: true,
    });
    await assertHeaderLayoutMobile(page);
    await page.getByTestId("app-header").screenshot({
      path: path.join(out, `header-${width}px-fixed.png`),
    });
  });
}
