/**
 * v199 · QA login 1/11: P1 (sense xarxa no tanca la sessió), P2 (correu erroni → altres opcions → correu bo
 * mostra el pas del codi) i P3 (límit amb compte enrere, reenviament confirmat, focus, Tab, error net,
 * idioma del navegador, tutorial que no torna).
 */
import { blockSocketIoCtx, mockLoginSession, openLoginEmail } from "./helpers/loginSession.ts";
import { expect, test, type Browser, type BrowserContext } from "@playwright/test";

const PID = "loginv199-player01";
const TOKEN = "loginv199.token";
const AGE_OK = () => JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" });

async function newCtx(
  browser: Browser,
  opts: { session?: boolean; locale?: string; storedLocale?: string | null; width?: number; tutorialDone?: boolean } = {}
): Promise<BrowserContext> {
  const ctx = await browser.newContext({
    viewport: { width: opts.width ?? 390, height: 844 },
    locale: opts.locale ?? "en-US",
    colorScheme: "dark",
    storageState: { cookies: [], origins: [] },
  });
  await ctx.addInitScript(
    ({ session, age, pid, token, storedLocale, tutorialDone }) => {
      if (sessionStorage.getItem("v199_seeded") === "1") return;
      sessionStorage.setItem("v199_seeded", "1");
      if (storedLocale) localStorage.setItem("setimig.locale", storedLocale);
      localStorage.setItem("setimig_age_gate", age);
      localStorage.setItem("setimig_home_intro_v1", "1");
      if (session) {
        localStorage.setItem("setimig_player_id", pid);
        localStorage.setItem("setimig_player_token", token);
        localStorage.setItem("setimig_player_name", "Edu");
        localStorage.setItem("setimig_onboarding_v1", "1");
        if (tutorialDone) localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      }
    },
    {
      session: !!opts.session,
      age: AGE_OK(),
      pid: PID,
      token: TOKEN,
      storedLocale: opts.storedLocale === undefined ? "en" : opts.storedLocale,
      tutorialDone: opts.tutorialDone !== false,
    }
  );
  await mockLoginSession(ctx, PID, TOKEN);
  await blockSocketIoCtx(ctx);
  return ctx;
}

const lobby = (page: import("@playwright/test").Page) => page.locator("button.header-profile").first();

test("P1 · sense xarxa en obrir: es manté el token, no va a /login i es recupera en tornar la xarxa", async ({ browser }) => {
  const ctx = await newCtx(browser, { session: true });
  let down = true;
  await ctx.route("**/api/**", async (route) => {
    const path = new URL(route.request().url()).pathname;
    if (path === "/api/health") return route.continue();
    if (down) return route.abort("internetdisconnected");
    return route.fallback();
  });
  const page = await ctx.newPage();
  await page.goto("/");
  await page.waitForTimeout(2500);
  expect(new URL(page.url()).pathname).not.toBe("/login");
  await expect(page.getByTestId("login-page")).toHaveCount(0);
  expect(await page.evaluate(() => localStorage.getItem("setimig_player_token"))).toBe(TOKEN);

  // Recàrrega encara sense xarxa: igual.
  await page.reload();
  await page.waitForTimeout(1500);
  await expect(page.getByTestId("login-page")).toHaveCount(0);
  expect(await page.evaluate(() => localStorage.getItem("setimig_player_token"))).toBe(TOKEN);

  // Torna la xarxa: l'esdeveniment online renova la sessió sense passar pel login.
  down = false;
  const renewed = page.waitForRequest((r) => r.url().includes("/api/player-session"), { timeout: 10_000 });
  await page.evaluate(() => window.dispatchEvent(new Event("online")));
  await renewed;
  await page.reload();
  await expect(lobby(page)).toBeVisible({ timeout: 30_000 });
  await expect(page.getByTestId("login-page")).toHaveCount(0);
  await ctx.close();
});

test("P1 · 5xx a la renovació: es manté el token", async ({ browser }) => {
  const ctx = await newCtx(browser, { session: true });
  await ctx.route("**/api/player-session", (route) => route.fulfill({ status: 503, json: { error: "down" } }));
  const page = await ctx.newPage();
  await page.goto("/");
  await expect(lobby(page)).toBeVisible({ timeout: 30_000 });
  expect(await page.evaluate(() => localStorage.getItem("setimig_player_token"))).toBe(TOKEN);
  await ctx.close();
});

test("P1 · 401 real a la renovació: esborra el token i va a /login", async ({ browser }) => {
  const ctx = await newCtx(browser, { session: true });
  await ctx.route("**/api/player-session", (route) => route.fulfill({ status: 401, json: { error: "auth_required" } }));
  await ctx.route("**/api/balance**", (route) => route.fulfill({ status: 401, json: { error: "auth_required" } }));
  const page = await ctx.newPage();
  await page.goto("/");
  await page.waitForURL((u) => u.pathname === "/login", { timeout: 20_000 });
  expect(await page.evaluate(() => localStorage.getItem("setimig_player_token"))).toBeNull();
  await ctx.close();
});

test("P2 · 1280: correu erroni → Other options → Continue with email → correu bo mostra el pas del codi", async ({ browser }) => {
  const ctx = await newCtx(browser, { width: 1280 });
  const sent: string[] = [];
  await ctx.route("**/api/auth/email/start", async (route) => {
    const body = route.request().postDataJSON() as { email: string };
    sent.push(body.email);
    if (body.email === "a@b") return route.fulfill({ status: 400, json: { error: "x", code: "BAD_EMAIL" } });
    return route.fulfill({ status: 202, json: { ok: true, expiresInSec: 600 } });
  });
  const page = await ctx.newPage();
  await page.goto("/login");
  await openLoginEmail(page);
  await page.getByTestId("login-email-input").fill("a@b");
  await page.getByTestId("login-email-submit").click();
  await expect(page.getByTestId("login-error")).toBeVisible();
  await page.getByTestId("login-email-back").click();
  await page.getByTestId("login-email-continue").click();
  await page.getByTestId("login-email-input").fill("edu@example.com");
  await page.getByTestId("login-email-submit").click();
  await expect(page.getByTestId("login-code-step")).toBeVisible();
  await expect(page.getByTestId("login-code-step")).toContainText("edu@example.com");
  await page.waitForTimeout(1500);
  await expect(page.getByTestId("login-code-step")).toBeVisible();
  expect(sent).toEqual(["a@b", "edu@example.com"]);
  // P3 · focus al camp del codi
  await expect(page.getByTestId("login-code-input")).toBeFocused();
  await ctx.close();
});

test("P3 · reenviar: confirmació; al límit es manté al pas del codi amb compte enrere", async ({ browser }) => {
  const ctx = await newCtx(browser);
  let n = 0;
  await ctx.route("**/api/auth/email/start", async (route) => {
    n += 1;
    if (n >= 3) return route.fulfill({ status: 429, headers: { "Retry-After": "125" }, json: { error: "x", code: "RATE_LIMIT", retryAfter: 125 } });
    return route.fulfill({ status: 202, json: { ok: true, expiresInSec: 600 } });
  });
  const page = await ctx.newPage();
  await page.goto("/login");
  await openLoginEmail(page);
  await page.getByTestId("login-email-input").fill("edu@example.com");
  await page.getByTestId("login-email-submit").click();
  await expect(page.getByTestId("login-code-input")).toBeFocused();
  await page.getByTestId("login-resend").click();
  await expect(page.getByTestId("login-resent")).toBeVisible();
  await page.getByTestId("login-resend").click();
  await expect(page.getByTestId("login-code-step")).toBeVisible();
  await expect(page.getByTestId("login-error")).toContainText(/2 min \d s/);
  await expect(page.getByTestId("login-resend")).toBeDisabled();
  await expect(page.getByTestId("login-code-step")).toContainText("edu@example.com");
  await ctx.close();
});

test("P3 · límit des del correu: es manté el correu escrit", async ({ browser }) => {
  const ctx = await newCtx(browser);
  await ctx.route("**/api/auth/email/start", (route) =>
    route.fulfill({ status: 429, json: { error: "x", code: "RATE_LIMIT", retryAfter: 60 } })
  );
  const page = await ctx.newPage();
  await page.goto("/login");
  await openLoginEmail(page);
  await page.getByTestId("login-email-input").fill("edu@example.com");
  await page.getByTestId("login-email-submit").click();
  await expect(page.getByTestId("login-error")).toContainText(/(1 min|\d+ s)/);
  await expect(page.getByTestId("login-email-input")).toHaveValue("edu@example.com");
  await expect(page.getByTestId("login-email-submit")).toBeDisabled();
  await ctx.close();
});

test("P3 · l'error antic desapareix en tornar a escriure («  hola  »)", async ({ browser }) => {
  const ctx = await newCtx(browser);
  await ctx.route("**/api/auth/email/start", (route) => route.fulfill({ status: 400, json: { error: "x", code: "BAD_EMAIL" } }));
  const page = await ctx.newPage();
  await page.goto("/login");
  await openLoginEmail(page);
  await page.getByTestId("login-email-input").fill("a@b");
  await page.getByTestId("login-email-submit").click();
  await expect(page.getByTestId("login-error")).toBeVisible();
  await page.getByTestId("login-email-input").fill("  hola  ");
  await expect(page.getByTestId("login-error")).toHaveCount(0);
  await ctx.close();
});

test("P3 · el primer Tab no va a enllaços amagats", async ({ browser }) => {
  const ctx = await newCtx(browser, { width: 1280 });
  const page = await ctx.newPage();
  await page.goto("/login");
  await expect(page.getByTestId("login-page")).toBeVisible();
  await page.evaluate(() => (document.activeElement as HTMLElement | null)?.blur());
  await page.keyboard.press("Tab");
  const info = await page.evaluate(() => {
    const el = document.activeElement as HTMLElement | null;
    if (!el || el === document.body) return { ok: false, what: "body" };
    const r = el.getBoundingClientRect();
    return { ok: r.width > 2 && r.height > 2 && !el.closest(".seo-links"), what: el.outerHTML.slice(0, 80) };
  });
  expect(info.ok, info.what).toBe(true);
  await ctx.close();
});

test("P3 · idioma del navegador (ca-ES) a la pantalla de login sense preferència desada", async ({ browser }) => {
  const ctx = await newCtx(browser, { locale: "ca-ES", storedLocale: null });
  const page = await ctx.newPage();
  await page.goto("/login");
  await expect(page.getByTestId("login-page")).toBeVisible();
  await expect.poll(() => page.evaluate(() => document.documentElement.lang)).toBe("ca");
  // No es desa com a preferència (només l'elecció explícita es desa).
  expect(await page.evaluate(() => localStorage.getItem("setimig.locale"))).toBeNull();
  await ctx.close();
});

test("P3 · el tutorial no torna en reobrir amb el mateix estat", async ({ browser }) => {
  const ctx = await newCtx(browser, { session: true, tutorialDone: false });
  const page = await ctx.newPage();
  await page.goto("/");
  await expect(page.getByTestId("interactive-tutorial-backdrop")).toBeVisible({ timeout: 30_000 });
  const state = await ctx.storageState();
  await ctx.close();

  const ctx2 = await browser.newContext({ viewport: { width: 390, height: 844 }, locale: "en-US", storageState: state });
  await mockLoginSession(ctx2, PID, TOKEN);
  await blockSocketIoCtx(ctx2);
  const page2 = await ctx2.newPage();
  await page2.goto("/");
  await expect(lobby(page2)).toBeVisible({ timeout: 30_000 });
  await page2.waitForTimeout(1500);
  await expect(page2.getByTestId("interactive-tutorial-backdrop")).toHaveCount(0);
  await ctx2.close();
});
