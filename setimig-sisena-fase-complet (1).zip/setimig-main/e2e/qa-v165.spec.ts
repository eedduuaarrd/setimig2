import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * QA e2e v164 → v165 (bugs 1–3):
 * 1) mai es mostren els punts propis (botó «Demanar» sense «Tens 7½», cap «Perfecte»).
 * 2) a 1280 el seient del rival/banca no encavalca la mà pròpia.
 * 3) la carta pròpia tapada no té la cara al DOM (rang, pal, imatge) abans d'aixecar-la.
 */
async function seed(page: Page, id: string) {
  await seedE2eSession(page, id);
  await page.addInitScript((pid) => {
    if (sessionStorage.getItem("__qa165")) return;
    sessionStorage.setItem("__qa165", "1");
    localStorage.setItem("setimig_player_id", pid);
    localStorage.setItem("setimig_player_name", "QA165");
    localStorage.setItem("setimig_onboarding_v1", "1");
    localStorage.setItem("setimig_interactive_tutorial_v1", "1");
    localStorage.setItem("setimig.locale", "ca");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
  }, id);
}

async function startSolo(page: Page) {
  await page.goto("/");
  await page.getByTestId("lobby-context").click();
  await page.getByTestId("ai-bot-count-1").click();
  await page.getByRole("button", { name: "Començar" }).click();
  await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 60_000 });
}

/** Aposta si cal i espera el meu torn (Demanar visible i actiu). Torna false si no arriba. */
async function reachMyTurn(page: Page): Promise<boolean> {
  const deadline = Date.now() + 120_000;
  while (Date.now() < deadline) {
    const bet = page.getByTestId("bet-confirm");
    if ((await bet.isVisible().catch(() => false)) && (await bet.isEnabled().catch(() => false))) {
      await bet.click({ timeout: 2_000 }).catch(() => {});
      continue;
    }
    const next = page.getByTestId("settlement-next-hand");
    if (await next.isVisible().catch(() => false)) {
      await next.click({ timeout: 2_000 }).catch(() => {});
      continue;
    }
    const hit = page.getByTestId("action-hit");
    if ((await hit.isVisible().catch(() => false)) && (await hit.isEnabled().catch(() => false))) return true;
    await page.waitForTimeout(250);
  }
  return false;
}

/** Atributs/imatges de cara dins de les meves cartes tapades. */
async function faceDownLeaks(page: Page) {
  return page.evaluate(() => {
    const leaks: string[] = [];
    const seat = document.querySelector("[data-testid=local-player-seat]");
    seat?.querySelectorAll('.spanish-card[data-face="down"]').forEach((cardEl) => {
      const host = cardEl.closest("[data-testid=peek-curl-host]") ?? cardEl;
      for (const a of ["data-peek-rank", "data-peek-suit"]) if (host.getAttribute(a)) leaks.push(`${a}=${host.getAttribute(a)}`);
      host.querySelectorAll("[data-baralla-id]").forEach((e) => leaks.push(`baralla-id=${e.getAttribute("data-baralla-id")}`));
      host.querySelectorAll("img").forEach((img) => {
        const src = img.getAttribute("src") ?? "";
        if (/\/cares\//.test(src)) leaks.push(`src=${src}`);
      });
      host.querySelectorAll("use").forEach((u) => {
        const href = u.getAttribute("href") ?? "";
        if (/#bx-(p|r)-/.test(href)) leaks.push(`href=${href}`);
      });
    });
    return leaks;
  });
}

for (const vp of [
  { tag: "390", width: 390, height: 844 },
  { tag: "1280", width: 1280, height: 800 },
]) {
  test(`QA v165 · cara tapada fora del DOM i cap punt propi (${vp.tag})`, async ({ page }) => {
    await page.setViewportSize({ width: vp.width, height: vp.height });
    await seed(page, e2ePoolId());
    await startSolo(page);
    expect(await reachMyTurn(page), "arriba el meu torn").toBe(true);
    await page.waitForTimeout(600);
    expect(await page.locator('[data-testid=local-player-seat] .spanish-card[data-face="down"]').count()).toBeGreaterThan(0);
    expect(await faceDownLeaks(page), "cap dada de la cara abans del peek").toEqual([]);
    // «Demanar» sempre és «Demanar» (mai «Tens 7½») i cap punt propi a la taula.
    await expect(page.getByTestId("action-hit")).toHaveText(/Demanar/i);
    await expect(page.getByTestId("my-hand-points")).toHaveCount(0);
    await expect(page.getByTestId("fx-seven-number")).toHaveCount(0);
  });
}

test("QA v165 · 1280: el seient del rival/banca no encavalca la meva mà", async ({ page }) => {
  await page.setViewportSize({ width: 1280, height: 800 });
  await seed(page, e2ePoolId());
  await startSolo(page);
  expect(await reachMyTurn(page)).toBe(true);
  await page.waitForTimeout(600);
  const measure = () => page.evaluate(() => {
    const me = document.querySelector("[data-testid=local-player-seat]")!.getBoundingClientRect();
    const seats = [...document.querySelectorAll("[data-testid=game-seat-grid] [data-seat-player]")]
      .filter((e) => (e as HTMLElement).offsetParent && getComputedStyle(e).visibility !== "hidden")
      .map((e) => e.getBoundingClientRect().bottom);
    return { meTop: me.top, rivalBottom: seats.length ? Math.max(...seats) : null };
  });
  for (const step of ["torn", "després de demanar"]) {
    const m = await measure();
    expect(m.rivalBottom, "hi ha seient rival").not.toBeNull();
    expect(m.rivalBottom!, `${step}: rival.bottom ${m.rivalBottom} ≤ me.top ${m.meTop}`).toBeLessThanOrEqual(m.meTop + 0.5);
    if (step === "torn") {
      await page.getByTestId("action-hit").click();
      await page.waitForTimeout(1_200);
    }
  }
});
