import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/** Normes de la casa (PR #282): oferta «Jugar/Canviar» del 3 i el 4, i revelació del Mort. Només mesures. */
type Card = { suit: "hearts" | "diamonds" | "clubs" | "spades"; value: number; points: number };
const card = (value: number, suit: Card["suit"] = "hearts"): Card => ({ suit, value, points: value >= 10 ? 0.5 : value });
const FIGURES = Array.from({ length: 12 }, (_, i) => card(10 + (i % 3), (["hearts", "diamonds", "clubs", "spades"] as const)[i % 4]));

function slot(id: string, cards: { c: Card; up: boolean }[], bet: number, status: string, extra: Record<string, unknown> = {}) {
  return {
    id, bet, status, doubled: false, canDouble: false, mort: false, blindPair: false, blindUntilBankEnd: false, mortOffered: false,
    cards: cards.map((x, i) => ({ id: `${id}-c${i}`, card: x.c, faceUp: x.up })),
    ...extra,
  };
}
function seat(id: string, name: string, isBanker: boolean, isBot: boolean, bet: number, status: string, hand: ReturnType<typeof slot>) {
  return {
    id, playerId: id.startsWith("local-human-") ? id.slice(12) : id, seatToken: `${id}-token`, name,
    chips: isBanker ? 5000 : 900, bet, isBanker, isBot, status, handSlots: [hand], activeSlotIndex: 0, lastRoyal7Payout: 0, royal7AsBankerStreak: 0,
  };
}
function snapshot(pid: string, room: Record<string, unknown>): string {
  return JSON.stringify({
    version: 1, playerId: pid, playerName: "Edu", botCount: 1, difficulty: "normal",
    room: {
      id: `local-normes-${pid}`, name: "Partida IA", pot: 100, minBet: 100, jackpot: 0, lastRound: null, centerDiscard: [],
      soloAi: true, soloHumanPlayerId: pid, soloBotCount: 1,
      sessionStats: [[pid, { handsPlayed: 2, handsWon: 0, netCf: 0, winStreak: 0, lastOutcome: null }]],
      matchProgress: { handNumber: 3, totalHands: 10 }, matchEnded: false, matchResult: null, houseRulesEnabled: true,
      turnDeadlineAt: Date.now() + 60_000, deck: FIGURES, ...room,
    },
  });
}
const human = (pid: string) => `local-human-${pid}`;
function swapSnap(pid: string, offer: 3 | 4) {
  return snapshot(pid, {
    phase: "playing", turnPlayerIndex: 0,
    players: [
      seat(human(pid), "Edu", false, false, 100, "playing", slot(`${human(pid)}-hand`, [{ c: card(offer), up: false }], 100, "playing", { swapOffered: offer })),
      seat("bot-n-bank", "Laia", true, true, 0, "playing", slot("bot-n-bank-hand", [{ c: card(5, "clubs"), up: false }], 0, "playing")),
    ],
  });
}
function mortOfferSnap(pid: string) {
  return snapshot(pid, {
    phase: "playing", turnPlayerIndex: 0,
    players: [
      seat(human(pid), "Edu", false, false, 100, "playing", slot(`${human(pid)}-hand`, [{ c: card(7, "clubs"), up: false }], 100, "playing", { mortOffered: true })),
      seat("bot-n-bank", "Laia", true, true, 0, "playing", slot("bot-n-bank-hand", [{ c: card(5, "clubs"), up: false }], 0, "playing")),
    ],
  });
}
function mortSnap(pid: string) {
  return snapshot(pid, {
    phase: "banker", turnPlayerIndex: 1,
    roundStartChips: [[pid, 1000], ["bot-n-bank", 5000]],
    players: [
      seat(human(pid), "Edu", false, false, 100, "stood",
        slot(`${human(pid)}-hand`, [{ c: card(7, "spades"), up: true }, { c: card(11, "clubs"), up: false }], 100, "stood", { mort: true, blindUntilBankEnd: true })),
      seat("bot-n-bank", "Laia", true, true, 0, "playing", slot("bot-n-bank-hand", [{ c: card(5, "clubs"), up: true }, { c: card(1, "diamonds"), up: true }], 0, "playing")),
    ],
  });
}

async function seed(page: Page, snap: string, pid: string) {
  await seedE2eSession(page, pid);
  await page.addInitScript(({ snap, pid }) => {
    if (sessionStorage.getItem("normes_seeded") === "1") return;
    sessionStorage.setItem("normes_seeded", "1");
    localStorage.setItem("setimig_player_id", pid);
    localStorage.setItem("setimig_player_name", "Edu");
    localStorage.setItem("setimig_onboarding_v1", "1");
    localStorage.setItem("setimig_interactive_tutorial_v1", "1");
    localStorage.setItem("setimig_table_tutorial_v1", "1");
    localStorage.setItem("setimig_house_rules_enabled", "1");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
    localStorage.setItem("setimig_local_solo_snapshot", snap);
    sessionStorage.setItem("setimig_solo_rejoin", "1");
    sessionStorage.setItem("setimig_solo_local", "1");
  }, { snap, pid });
  await page.route("**/socket.io/**", (route) => route.abort());
}

/** Aixeca la carta pròpia a poc a poc (peek, sense girar-la) i la deixa anar. Retorna la mesura a mig peek. */
async function peekOwn(page: Page) {
  const grab = page.getByTestId("peek-curl-grab").first();
  await expect(grab).toBeVisible({ timeout: 45_000 });
  await expect(page.getByTestId("home-intro")).toHaveCount(0, { timeout: 15_000 });
  const host = page.getByTestId("peek-curl-host").first();
  const hb = (await host.boundingBox())!;
  const gb = (await grab.boundingBox())!;
  const fire = (phase: "down" | "move" | "up", y: number) =>
    grab.evaluate((el, a) => {
      const type = a.phase === "down" ? "pointerdown" : a.phase === "move" ? "pointermove" : "pointerup";
      (a.phase === "down" ? el : window).dispatchEvent(new PointerEvent(type, {
        bubbles: true, cancelable: true, view: window, clientX: a.x, clientY: a.y,
        pointerId: 1, pointerType: "mouse", isPrimary: true, buttons: a.phase === "up" ? 0 : 1, button: 0,
      }));
    }, { phase, x: gb.x + gb.width / 2, y });
  const y0 = gb.y + Math.min(gb.height * 0.7, gb.height - 4);
  await fire("down", y0);
  // Lent: ~500 ms per recórrer el 80 % de la carta (només peek, no gira).
  for (let i = 1; i <= 12; i++) {
    await fire("move", y0 - (hb.height * 0.8 * i) / 12);
    await page.waitForTimeout(40);
  }
  const mid = await cardFit(page);
  await fire("up", y0 - hb.height * 0.8);
  return mid;
}

/** Caixa de la carta pròpia i del llenç del peek: dins del viewport i no retallades per cap avantpassat. */
async function cardFit(page: Page) {
  return page.evaluate(() => {
    const host = document.querySelector('[data-testid="peek-curl-host"]') as HTMLElement | null;
    const canvas = host?.querySelector("canvas") as HTMLElement | null;
    const target = host ?? (document.querySelector(".desktop-own-card, [data-testid=own-card]") as HTMLElement | null);
    if (!target) return null;
    const r = target.getBoundingClientRect();
    const cr = canvas?.getBoundingClientRect();
    let clipped = 0;
    let el = target.parentElement;
    while (el && el !== document.body) {
      const cs = getComputedStyle(el);
      const clips = cs.overflow !== "visible" || cs.overflowY !== "visible" || cs.clipPath !== "none";
      if (clips) {
        const a = el.getBoundingClientRect();
        const cut = Math.max(0, a.top - r.top) + Math.max(0, r.bottom - a.bottom) + Math.max(0, a.left - r.left) + Math.max(0, r.right - a.right);
        clipped = Math.max(clipped, cut);
      }
      el = el.parentElement;
    }
    return {
      top: r.top, bottom: r.bottom, left: r.left, right: r.right, h: r.height,
      canvasTop: cr?.top ?? null, canvasH: cr?.height ?? null,
      vw: innerWidth, vh: innerHeight, clipped,
      fold: host?.getAttribute("data-peek-fold") ?? null,
    };
  });
}

async function noOverflow(page: Page) {
  const o = await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  expect(o).toBeLessThanOrEqual(1);
}

for (const offer of [3, 4] as const) {
  for (const choice of ["play", "swap"] as const) {
    test(`oferta del ${offer}: ${choice} funciona i la mà continua (390)`, async ({ page }) => {
      await page.setViewportSize({ width: 390, height: 844 });
      const pid = e2ePoolId();
      await seed(page, swapSnap(pid, offer), pid);
      await page.goto("/");
      const panel = page.getByTestId("swap-offer");
      await peekOwn(page);
      await expect(panel).toBeVisible({ timeout: 10_000 });
      await expect(panel).toHaveAttribute("data-offer", String(offer));
      // Mentre hi ha l'oferta no hi ha cap «Carta» ni «Plantar-se» actius.
      await expect(page.locator("[data-testid=action-hit]:not([disabled])")).toHaveCount(0);
      await expect(page.locator("[data-testid=action-stand]:not([disabled])")).toHaveCount(0);
      for (const id of ["swap-play", "swap-swap"]) {
        const b = await page.getByTestId(id).boundingBox();
        expect(b!.height).toBeGreaterThanOrEqual(44);
      }
      await noOverflow(page);
      await page.getByTestId(choice === "play" ? "swap-play" : "swap-swap").click();
      await expect(panel).toBeHidden();
      if (offer === 3 && choice === "swap") {
        // 3 canviat (#287): el torn s'acaba; ja no queda cap «Carta» activa.
        await expect(page.locator("[data-testid=action-hit]:not([disabled])")).toHaveCount(0);
      } else {
        await expect(page.locator("[data-testid=action-hit]:not([disabled])").first()).toBeVisible();
      }
    });
  }
}

for (const vp of [{ w: 390, h: 844 }, { w: 375, h: 667 }, { w: 1280, h: 800 }]) {
  test(`Mort: cap pista abans del peek, oferta sense número després, carta sencera (${vp.w}x${vp.h})`, async ({ page }) => {
    await page.setViewportSize({ width: vp.w, height: vp.h });
    const pid = e2ePoolId();
    await seed(page, mortOfferSnap(pid), pid);
    await page.goto("/");
    await expect(page.getByTestId("peek-curl-grab").first()).toBeVisible({ timeout: 45_000 });
    await expect(page.getByTestId("home-intro")).toHaveCount(0, { timeout: 15_000 });
    await page.waitForTimeout(800);
    await expect(page.getByTestId("mort-flow-hint")).toHaveCount(0);
    await expect(page.getByTestId("mort-countdown")).toHaveCount(0);
    const before = await page.evaluate(() => document.body.innerText);
    expect(before).not.toMatch(/Tens un 7|You hold a|Vols jugar el Mort|Vols canviar/);
    const rest = (await cardFit(page))!;
    expect(rest.top).toBeGreaterThanOrEqual(0);
    expect(rest.bottom).toBeLessThanOrEqual(rest.vh + 0.5);
    expect(rest.clipped).toBeLessThanOrEqual(1);
    const mid = (await peekOwn(page))!;
    // A mig peek el llenç cobreix la carta sencera (també per dalt): l'índex de la cantonada és visible.
    expect(mid.canvasTop!).toBeLessThanOrEqual(mid.top + 0.5);
    expect(mid.canvasTop!).toBeGreaterThanOrEqual(-0.5);
    expect(mid.clipped).toBeLessThanOrEqual(1);
    // Plec a dalt de tot (≤ 3 % de l'alçada): la cara és sencera, amb l'índex i el número de dalt.
    expect(Number(mid.fold)).toBeLessThanOrEqual(0.03);
    const hint = page.getByTestId("mort-flow-hint");
    await expect(hint).toBeVisible({ timeout: 10_000 });
    expect(await hint.locator("p").first().innerText()).not.toMatch(/\d/);
    await hint.scrollIntoViewIfNeeded();
    await expect(hint.locator("button").first()).toBeInViewport();
    await noOverflow(page);
  });
}

test("oferta: el teclat arriba als botons Jugar/Canviar", async ({ page }) => {
  await page.setViewportSize({ width: 1280, height: 800 });
  const pid = e2ePoolId();
  await seed(page, swapSnap(pid, 4), pid);
  await page.goto("/");
  await peekOwn(page);
  await expect(page.getByTestId("swap-offer")).toBeVisible({ timeout: 10_000 });
  await noOverflow(page);
  await page.getByTestId("swap-play").focus();
  await expect(page.getByTestId("swap-play")).toBeFocused();
  await page.keyboard.press("Enter");
  await expect(page.getByTestId("swap-offer")).toBeHidden();
});

for (const vp of [{ w: 375, h: 667 }, { w: 390, h: 844 }, { w: 1280, h: 800 }]) {
  test(`revelació del Mort a la liquidació: < 4 s, text >= 18 px, sense desbordar (${vp.w})`, async ({ page }) => {
    await page.setViewportSize({ width: vp.w, height: vp.h });
    const pid = e2ePoolId();
    await seed(page, mortSnap(pid), pid);
    await page.goto("/");
    const reveal = page.getByTestId("special-reveal");
    await expect(reveal).toBeVisible({ timeout: 45_000 });
    const t0 = Date.now();
    await expect(reveal).toHaveAttribute("data-special", "mort");
    const fs = await page.getByTestId("special-reveal-text").evaluate((el) => parseFloat(getComputedStyle(el).fontSize));
    expect(fs).toBeGreaterThanOrEqual(18);
    const pe = await reveal.evaluate((el) => getComputedStyle(el).pointerEvents);
    expect(pe).toBe("none");
    const box = await page.getByTestId("special-reveal-text").boundingBox();
    expect(box!.x).toBeGreaterThanOrEqual(0);
    expect(box!.x + box!.width).toBeLessThanOrEqual(vp.w + 1);
    await noOverflow(page);
    await expect(reveal).toHaveAttribute("data-stage", "result", { timeout: 3_000 });
    await expect(reveal).toBeHidden({ timeout: 4_000 });
    // L'app tanca als 3,8 s (SPECIAL_REVEAL_MS.total); el marge cobreix el sondeig de Playwright en una màquina carregada.
    expect(Date.now() - t0).toBeLessThan(4_600);
  });
}

test("revelació amb reduced motion: flip curt, sense suspens", async ({ page }) => {
  await page.emulateMedia({ reducedMotion: "reduce" });
  await page.setViewportSize({ width: 390, height: 844 });
  const pid = e2ePoolId();
  await seed(page, mortSnap(pid), pid);
  await page.goto("/");
  const reveal = page.getByTestId("special-reveal");
  await expect(reveal).toBeVisible({ timeout: 45_000 });
  const t0 = Date.now();
  await expect(reveal).toHaveAttribute("data-stage", "result");
  await expect(reveal).not.toHaveAttribute("data-stage", "suspense");
  const anim = await page.locator(".special-reveal__card").evaluate((el) => {
    const s = getComputedStyle(el);
    return { name: s.animationName, dur: parseFloat(s.animationDuration) };
  });
  // El CSS global de reduced motion pot anul·lar l'animació: llavors el flip és instantani.
  expect(["sr-flip", "none"]).toContain(anim.name);
  expect(anim.dur).toBeLessThanOrEqual(0.4);
  await expect(reveal).toBeHidden({ timeout: 2_500 });
  expect(Date.now() - t0).toBeLessThan(2_500);
});

/** v154 (vídeo Edu després de v153): punts 1–3. */
for (const vp of [{ w: 390, h: 844 }, { w: 1280, h: 800 }]) {
  test(`v154: oferta del Mort només quan el peek acaba; carta sencera; mai els meus punts (${vp.w})`, async ({ page }) => {
    await page.setViewportSize({ width: vp.w, height: vp.h });
    const pid = e2ePoolId();
    await seed(page, mortOfferSnap(pid), pid);
    await page.goto("/");
    const grab = page.getByTestId("peek-curl-grab").first();
    await expect(grab).toBeVisible({ timeout: 45_000 });
    await expect(page.getByTestId("home-intro")).toHaveCount(0, { timeout: 15_000 });
    const host = page.getByTestId("peek-curl-host").first();
    const hb = (await host.boundingBox())!;
    const gb = (await grab.boundingBox())!;
    const fire = (phase: "down" | "move" | "up", y: number) =>
      grab.evaluate((el, a) => {
        const type = a.phase === "down" ? "pointerdown" : a.phase === "move" ? "pointermove" : "pointerup";
        (a.phase === "down" ? el : window).dispatchEvent(new PointerEvent(type, {
          bubbles: true, cancelable: true, view: window, clientX: a.x, clientY: a.y,
          pointerId: 1, pointerType: "mouse", isPrimary: true, buttons: a.phase === "up" ? 0 : 1, button: 0,
        }));
      }, { phase, x: gb.x + gb.width / 2, y });
    const y0 = gb.y + Math.min(gb.height * 0.7, gb.height - 4);
    await fire("down", y0);
    for (let i = 1; i <= 12; i++) {
      await fire("move", y0 - (hb.height * 0.8 * i) / 12);
      await page.waitForTimeout(40);
    }
    // 1) A mig peek (carta aixecada) encara no hi ha cap oferta.
    await page.waitForTimeout(300);
    await expect(page.getByTestId("mort-flow-hint")).toHaveCount(0);
    await fire("up", y0 - hb.height * 0.8);
    await expect(page.getByTestId("mort-flow-hint")).toBeVisible({ timeout: 10_000 });
    // 2) La carta pròpia continua visible i sencera (mai opacitat 0 sense peek en curs).
    await expect(host).toHaveAttribute("data-peeking", "no", { timeout: 3_000 });
    const op = await host.locator(".spanish-card, [data-testid='spanish-card']").first().evaluate((el) => getComputedStyle(el).opacity).catch(() => "1");
    expect(Number(op)).toBeGreaterThan(0.5);
    // 3) Cap total dels meus punts a la taula.
    await expect(page.getByTestId("my-hand-points")).toHaveCount(0);
    await expect(page.locator('[data-testid="local-player-seat"] .hero-score')).toHaveCount(0);
    await expect(page.locator('.v2-seat[data-seat-self="true"] .v2-seat-points')).toHaveCount(0);
  });
}

/** v154 (Edu): cap gest sobre les cartes demana carta; només el botó «Demanar». */
function plainTurnSnap(pid: string) {
  return snapshot(pid, {
    phase: "playing", turnPlayerIndex: 0,
    players: [
      seat(human(pid), "Edu", false, false, 100, "playing", slot(`${human(pid)}-hand`, [{ c: card(2, "cups" as Card["suit"]), up: false }], 100, "playing")),
      seat("bot-n-bank", "Laia", true, true, 0, "playing", slot("bot-n-bank-hand", [{ c: card(5, "clubs"), up: false }], 0, "playing")),
    ],
  });
}
for (const vp of [{ w: 390, h: 844 }, { w: 1280, h: 800 }]) {
  test(`v154: peek, lliscar, tocar o girar la carta no demana; només el botó (${vp.w})`, async ({ page }) => {
    await page.setViewportSize({ width: vp.w, height: vp.h });
    const pid = e2ePoolId();
    await seed(page, plainTurnSnap(pid), pid);
    await page.goto("/");
    const count = () => page.locator('[data-testid="local-hand-card"], .desktop-own-hand > *').count();
    await expect(page.getByTestId("peek-curl-grab").first()).toBeVisible({ timeout: 45_000 });
    await expect(page.getByTestId("home-intro")).toHaveCount(0, { timeout: 15_000 });
    const before = await count();
    // Peek lent i deixar anar.
    await peekOwn(page);
    await page.waitForTimeout(600);
    // Lliscar ràpid cap amunt sobre la mà i tocar la carta.
    const host = page.getByTestId("peek-curl-host").first();
    const hb = (await host.boundingBox())!;
    await page.mouse.move(hb.x + hb.width / 2, hb.y + hb.height * 0.9);
    await page.mouse.down();
    await page.mouse.move(hb.x + hb.width / 2, hb.y - hb.height * 1.5, { steps: 3 });
    await page.mouse.up();
    await page.waitForTimeout(600);
    if (await host.count()) await host.click({ force: true, timeout: 3_000 }).catch(() => {});
    await page.waitForTimeout(1_200);
    expect(await count(), "cap gest no ha demanat carta").toBeLessThanOrEqual(before);
    await expect(page.getByTestId("swipe-hit-toggle")).toHaveCount(0);
    // Només el botó demana.
    const btn = page.getByTestId("action-hit");
    await btn.scrollIntoViewIfNeeded();
    await btn.click();
    await expect.poll(count, { timeout: 10_000 }).toBeGreaterThan(before);
  });
}
