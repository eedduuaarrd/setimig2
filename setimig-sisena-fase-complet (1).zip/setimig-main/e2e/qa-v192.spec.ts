import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * QA v192 (prod 31-10): bloqueig de Plantar-me/Demanar carta fins al canvi de torn, botons sense salt de línia
 * a 360/390 en 5 idiomes, bombolla del xat lluny de «Següent mà» a 1280, cap panell d'ajustos ni avís STAND
 * a l'aposta de la mà 2, avís de banca sense tapar la mà. Partida solo amb bots.
 */
async function startSolo(page: Page, locale = "ca") {
  await seedE2eSession(page, e2ePoolId());
  await page.addInitScript((loc) => {
    if (sessionStorage.getItem("v192_init") !== "1") {
      sessionStorage.setItem("v192_init", "1");
      for (const k of ["setimig_onboarding_v1", "setimig_interactive_tutorial_v1", "setimig_table_tutorial_v1"]) localStorage.setItem(k, "1");
      localStorage.setItem("setimig.locale", loc);
      localStorage.setItem("setimig_player_name", "Test QA");
      localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
      sessionStorage.setItem("setimig_intro_launch_v1", "1");
    }
  }, locale);
  await page.goto("/");
  const skip = page.getByTestId("interactive-tutorial-skip");
  await expect(page.getByTestId("lobby-context").or(skip).first()).toBeVisible({ timeout: 45_000 });
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  await page.getByTestId("ai-bot-count-3").click();
  await page.getByTestId("ai-bot-picker-start").click();
}

const visible = (page: Page, id: string) => page.getByTestId(id).filter({ visible: true }).first();

/** Juga (aposta i passa a la següent mà) fins que `stop` torna cert; no es planta si `stand` és fals. */
async function playUntil(page: Page, stop: () => Promise<boolean>, opts: { stand?: boolean; ms?: number } = {}) {
  const end = Date.now() + (opts.ms ?? 90_000);
  while (Date.now() < end) {
    if (await stop()) return true;
    const ids = ["bet-confirm", "settlement-next-hand", ...(opts.stand === false ? [] : ["action-stand"])];
    for (const id of ids) {
      const b = visible(page, id);
      if (await b.isVisible().catch(() => false)) await b.click({ timeout: 2_000 }).catch(() => {});
    }
    const grab = visible(page, "peek-curl-grab");
    if (await grab.isVisible().catch(() => false)) {
      const b = await grab.boundingBox().catch(() => null);
      if (b) {
        const x = b.x + b.width / 2, y0 = b.y + b.height * 0.95, y1 = b.y + b.height * 0.3;
        await page.mouse.move(x, y0);
        await page.mouse.down();
        for (let i = 1; i <= 8; i++) {
          await page.mouse.move(x, y0 + ((y1 - y0) * i) / 8);
          await page.waitForTimeout(40);
        }
        await page.mouse.up();
      }
    }
    await page.waitForTimeout(200);
  }
  return false;
}

async function myTurn(page: Page) {
  return playUntil(page, async () => visible(page, "action-stand").isEnabled().catch(() => false), { stand: false });
}

test.describe("qa v192 · 390", () => {
  test.use({ viewport: { width: 390, height: 844 } });

  test("plantar-se: els botons no es reactiven abans del canvi de torn", async ({ page }) => {
    test.setTimeout(150_000);
    await startSolo(page);
    expect(await myTurn(page), "arriba el meu torn").toBe(true);
    await visible(page, "action-stand").click();
    const t0 = Date.now();
    let reenabled = -1;
    while (Date.now() - t0 < 3_000) {
      for (const id of ["action-stand", "action-hit"]) {
        const b = page.getByTestId(id).filter({ visible: true }).first();
        if ((await b.count()) && (await b.isEnabled().catch(() => false))) {
          // Només és un error si encara és el mateix torn (cap altre jugador al centre).
          reenabled = Date.now() - t0;
        }
      }
      if (reenabled >= 0) break;
      await page.waitForTimeout(100);
    }
    expect(reenabled, "cap botó actiu després de plantar-se").toBe(-1);
  });

  test("mà 2: sense panell d'ajustos ni avís STAND durant l'aposta", async ({ page }) => {
    test.setTimeout(200_000);
    await startSolo(page);
    // Acaba la mà 1 i espera l'aposta de la mà 2.
    const ok = await playUntil(
      page,
      async () => (await page.getByText(/Mà 2\//).first().isVisible().catch(() => false)) && (await visible(page, "bet-confirm").isVisible().catch(() => false)),
      { ms: 150_000 }
    );
    expect(ok, "aposta de la mà 2").toBe(true);
    await page.waitForTimeout(400);
    await expect(page.getByText("Ajustos de partida").filter({ visible: true })).toHaveCount(0);
    await expect(page.getByTestId("private-waiting-panel")).toHaveCount(0);
    await expect(page.getByTestId("action-pop")).toHaveCount(0);
  });
});

for (const locale of ["ca", "es", "en", "it", "pt-BR"]) {
  for (const width of [360, 390]) {
    test(`botons de torn en una línia · ${locale} · ${width}`, async ({ page }) => {
      test.setTimeout(150_000);
      await page.setViewportSize({ width, height: 800 });
      await startSolo(page, locale);
      expect(await myTurn(page)).toBe(true);
      for (const id of ["action-stand", "action-hit"]) {
        const b = visible(page, id);
        if (!(await b.isVisible().catch(() => false))) continue;
        const m = await b.evaluate((el) => {
          const rects: DOMRect[] = [];
          const walker = document.createTreeWalker(el, NodeFilter.SHOW_TEXT);
          for (let n = walker.nextNode(); n; n = walker.nextNode()) {
            if (!n.textContent?.trim()) continue;
            const r = document.createRange();
            r.selectNodeContents(n);
            rects.push(...[...r.getClientRects()].filter((x) => x.width > 0));
          }
          const tops = new Set(rects.map((r) => Math.round(r.top)));
          const tr = { left: Math.min(...rects.map((r) => r.left)), right: Math.max(...rects.map((r) => r.right)) };
          const br = el.getBoundingClientRect();
          return { text: el.textContent, tl: tr.left, trr: tr.right, bl: br.left, brr: br.right, lines: tops.size, clipped: tr.left < br.left - 1 || tr.right > br.right + 1, h: br.height, w: br.width, overflow: el.scrollWidth > el.clientWidth + 1 };
        });
        expect(m.lines, `${id} una línia`).toBeLessThanOrEqual(1);
        expect(m.clipped || m.overflow, `${id} sense tallar ${JSON.stringify(m)}`).toBe(false);
        expect(m.h).toBeGreaterThanOrEqual(44);
      }
    });
  }
}

test.describe("qa v192 · 1280", () => {
  test.use({ viewport: { width: 1280, height: 720 } });

  test("la bombolla del xat no tapa «Següent mà»", async ({ page }) => {
    test.setTimeout(150_000);
    await startSolo(page);
    const ok = await playUntil(page, async () => visible(page, "settlement-next-hand").isVisible().catch(() => false), { ms: 120_000 });
    if (!ok) console.log("testids", await page.evaluate(() => [...document.querySelectorAll("[data-testid]")].filter((e) => (e as HTMLElement).offsetParent).map((e) => e.getAttribute("data-testid")).join(",")));
    expect(ok).toBe(true);
    const chat = page.getByTestId("table-chat-toggle");
    if (!(await chat.isVisible().catch(() => false))) return;
    const a = (await chat.boundingBox())!;
    const b = (await visible(page, "settlement-next-hand").boundingBox())!;
    const overlap = a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y + b.height && a.y + a.height > b.y;
    expect(overlap, "xat sobre Següent mà").toBe(false);
  });
});

test("avís de taula (mòbil) a dalt: no tapa la meva mà", async ({ page }) => {
  test.setTimeout(150_000);
  await page.setViewportSize({ width: 390, height: 844 });
  await startSolo(page);
  expect(await myTurn(page)).toBe(true);
  // Qualsevol toast de taula ha de quedar per sobre de la mà pròpia (el de «ets la banca» inclòs).
  const hand = page.getByTestId("focus-mine");
  const toast = page.getByTestId("app-toast");
  if ((await toast.count()) && (await hand.count())) {
    const t = (await toast.boundingBox())!;
    const h = (await hand.boundingBox())!;
    expect(t.y + t.height <= h.y || t.y >= h.y + h.height).toBe(true);
  }
});
