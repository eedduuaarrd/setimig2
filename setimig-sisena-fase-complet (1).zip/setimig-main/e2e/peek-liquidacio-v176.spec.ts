import { expect, test, type Locator, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * v176 (Edu, 21:43): el peek no es retalla mai i la liquidació és neta (sense punts propis,
 * píndoles sense solapar, «Bank wins» una sola vegada, «Next hand» daurat i actiu, sense franja).
 * Cal SETIMIG_TEST_DECK_SEED=3 (doblar + separar) o SETIMIG_TEST_DECK_SEED=217 (Mort contra 7½).
 */
const SEED = process.env.SETIMIG_TEST_DECK_SEED;
const OUT = "/workspace/peek-liq-v176";
const SIZES = [
  { name: "390", width: 390, height: 844 },
  { name: "1280", width: 1280, height: 800 },
] as const;
const POINTS = /\d|½/;

async function startSolo(page: Page) {
  const pid = e2ePoolId();
  await seedE2eSession(page, pid);
  await page.addInitScript(() => {
    if (sessionStorage.getItem("qa_llavor") === "1") return;
    sessionStorage.setItem("qa_llavor", "1");
    for (const k of ["setimig_onboarding_v1", "setimig_interactive_tutorial_v1", "setimig_table_tutorial_v1", "setimig_house_rules_enabled"]) localStorage.setItem(k, "1");
    localStorage.setItem("setimig.locale", "ca");
    localStorage.setItem("setimig_player_name", "Test Llavor");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
    sessionStorage.setItem("setimig_intro_launch_v1", "1");
  });
  await page.goto("/");
  const skip = page.getByTestId("interactive-tutorial-skip");
  await expect(page.getByTestId("lobby-context").or(skip).first()).toBeVisible({ timeout: 45_000 });
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  if (await page.getByTestId("ai-bot-count-1").isVisible().catch(() => false)) await page.getByTestId("ai-bot-count-1").click();
  const cb = page.getByTestId("house-rules-toggle").locator("input");
  if (!(await cb.isChecked())) await cb.check({ force: true });
  await page.getByTestId("ai-bot-picker-start").click();
  await page.getByTestId("bet-confirm").filter({ visible: true }).first().click({ timeout: 30_000 });
}

async function peek(page: Page) {
  const g = page.getByTestId("peek-curl-grab").filter({ visible: true }).first();
  await expect(g).toBeVisible({ timeout: 20_000 });
  const b = (await g.boundingBox())!;
  const x = b.x + b.width / 2;
  const y0 = b.y + b.height * 0.95;
  await page.mouse.move(x, y0);
  await page.mouse.down();
  for (let i = 1; i <= 8; i++) await page.mouse.move(x, y0 - i * b.height * 0.08);
  await page.mouse.up();
  await page.waitForTimeout(700);
}

async function toSettlement(page: Page, doStand = true) {
  const sheet = page.getByTestId("settlement-sheet");
  for (let i = 0; i < 300 && !(await sheet.isVisible().catch(() => false)); i++) {
    if (!doStand) { await page.waitForTimeout(300); continue; }
    const stand = page.getByTestId("action-stand").filter({ visible: true }).first();
    // #317: «Plantar-se» només existeix al torn propi. isEnabled()/click() sobre un locator buit
    // esperen actionTimeout (15 s) i la liquidació (més curta) passa sense que el bucle la vegi.
    if ((await stand.isVisible().catch(() => false)) && (await stand.isEnabled({ timeout: 500 }).catch(() => false)))
      await stand.click({ timeout: 1000 }).catch(() => {});
    await page.waitForTimeout(300);
  }
  await expect(sheet).toBeVisible();
  await page.waitForTimeout(1200);
}




type Box = { x: number; y: number; width: number; height: number };
const overlap = (a: Box, b: Box) =>
  a.x < b.x + b.width - 1 && b.x < a.x + a.width - 1 && a.y < b.y + b.height - 1 && b.y < a.y + a.height - 1;

function lum(c: string) {
  const m = c.match(/\d+(\.\d+)?/g)!.slice(0, 3).map(Number).map((v) => {
    const s = v / 255;
    return s <= 0.03928 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * m[0] + 0.7152 * m[1] + 0.0722 * m[2];
}

/** Aixecada lenta: la carta es veu sencera, cap ancestre la retalla, no gira ni reparteix. */
async function slowLiftChecks(page: Page, size: { width: number; height: number }) {
  const g = page.getByTestId("peek-curl-grab").filter({ visible: true }).first();
  await expect(g).toBeVisible({ timeout: 20_000 });
  const cardsBefore = await page.locator('[data-testid="local-player-seat"] .spanish-card, .peek-curl-host').count();
  const b = (await g.boundingBox())!;
  const x = b.x + b.width / 2;
  const y0 = b.y + b.height * 0.95;
  await page.mouse.move(x, y0);
  await page.mouse.down();
  for (let i = 1; i <= 14; i++) {
    await page.mouse.move(x + i, y0 - i * b.height * 0.05);
    await page.waitForTimeout(40);
  }
  await page.waitForTimeout(200);
  const info = await page.evaluate(() => {
    const host = document.querySelector('.peek-curl-host[data-peeking="yes"]') ?? document.querySelector(".peek-curl-host");
    const canvas = host?.querySelector("canvas") as HTMLCanvasElement | null;
    if (!host || !canvas) return null;
    const hr = host.getBoundingClientRect();
    const cr = canvas.getBoundingClientRect();
    const clippers: string[] = [];
    for (let el = host.parentElement; el && el !== document.body; el = el.parentElement) {
      const cs = getComputedStyle(el);
      const clips = cs.overflowX !== "visible" || cs.overflowY !== "visible" || cs.clipPath !== "none";
      if (!clips) continue;
      const r = el.getBoundingClientRect();
      // Retalla de veritat si la carta (o la seva solapa per dalt) surt del requadre de l'ancestre.
      if (hr.left < r.left - 0.5 || hr.right > r.right + 0.5 || cr.top < r.top - 0.5 || hr.bottom > r.bottom + 0.5)
        clippers.push(`${el.className || el.tagName} ${cs.overflowX}/${cs.overflowY}/${cs.clipPath}`);
    }
    return {
      host: { l: hr.left, r: hr.right, t: hr.top, b: hr.bottom },
      canvas: { l: cr.left, r: cr.right, t: cr.top },
      clippers,
      fold: host.getAttribute("data-peek-fold"),
      vw: innerWidth,
      vh: innerHeight,
    };
  });
  expect(info, "peek host").not.toBeNull();
  expect(info!.clippers, "cap ancestre retalla la carta aixecada").toEqual([]);
  expect(info!.host.l).toBeGreaterThanOrEqual(0);
  expect(info!.host.r).toBeLessThanOrEqual(size.width);
  expect(info!.canvas.t).toBeGreaterThanOrEqual(0);
  // El llenç és més ample que la carta: la perspectiva no retalla l'índex per l'esquerra.
  expect(info!.canvas.l).toBeLessThan(info!.host.l);
  expect(info!.canvas.r).toBeGreaterThan(info!.host.r);
  await page.mouse.up();
  await page.waitForTimeout(1200);
  // Lent: no gira i no afegeix cap carta.
  await expect(page.getByTestId("peek-curl-grab").filter({ visible: true }).first()).toBeVisible();
  const cardsAfter = await page.locator('[data-testid="local-player-seat"] .spanish-card, .peek-curl-host').count();
  expect(cardsAfter).toBe(cardsBefore);
}

async function settlementChecks(page: Page) {
  const sheet = page.getByTestId("settlement-sheet");
  const card = page.locator(".settlement-card");
  const vh = page.viewportSize()!.height;
  const cb = (await card.boundingBox())!;
  const mobile = page.viewportSize()!.width < 600;
  if (mobile) expect(Math.abs(cb.y + cb.height - vh), "el full arriba a baix (sense franja)").toBeLessThanOrEqual(1);
  // Sense punts propis: ni al full (fila pròpia/resultat) ni al meu seient.
  const own = await page.locator('[data-testid="settlement-result-row"][data-self="true"] div').first().innerText().catch(() => "");
  expect(own.replace("Test Llavor", "")).not.toMatch(/\d|½/);
  const res = await page.getByTestId("my-hand-result").innerText().catch(() => "");
  // El resultat gran són fitxes (−100), mai punts: cap «½» ni «· 7».
  expect(res).not.toMatch(/½|·\s*\d/);
  for (const el of await page.locator('.v2-seat[data-seat-self="true"] .v2-seat-foot').all()) {
    if (await el.isVisible()) expect(await el.innerText()).not.toMatch(/½|·\s*\d/);
  }
  // «Bank wins» / «Guanya la banca» una sola vegada dins el full.
  const txt = await sheet.innerText();
  for (const re of [/Guanya la banca/gi, /Bank wins/gi]) expect((txt.match(re) ?? []).length).toBeLessThanOrEqual(1);
  // Píndoles dels rivals: cap solapament amb una píndola visible del seient.
  const badges = await page.getByTestId("fx-result-badge").all();
  const pills: Box[] = [];
  for (const p of await page.locator(".v2-seat-pill, .v2-seat-points").all()) {
    if (!(await p.isVisible())) continue;
    const vis = await p.evaluate((e) => getComputedStyle(e).visibility === "visible");
    const bb = await p.boundingBox();
    if (vis && bb) pills.push(bb);
  }
  for (const bdg of badges) {
    const bb = await bdg.boundingBox();
    if (!bb) continue;
    for (const p of pills) expect(overlap(bb, p), `píndola «${await bdg.innerText()}» solapada`).toBe(false);
  }
  // «Next hand»: actiu, daurat i amb contrast AA.
  const next = page.getByTestId("settlement-next-hand");
  await expect(next).toBeEnabled();
  const [fg, bg] = await next.evaluate((e) => [getComputedStyle(e).color, getComputedStyle(e).backgroundColor]);
  const L1 = lum(fg), L2 = lum(bg);
  expect((Math.max(L1, L2) + 0.05) / (Math.min(L1, L2) + 0.05)).toBeGreaterThanOrEqual(4.5);
  expect((await next.boundingBox())!.height).toBeGreaterThanOrEqual(44);
}

for (const size of SIZES) {
  const mobile = size.width < 600;
  test.describe(`Peek + liquidació v176 @${size.name}`, () => {
    test.use({ viewport: { width: size.width, height: size.height }, isMobile: mobile, hasTouch: mobile });

    test("peek lent sense retall i liquidació neta", async ({ page }) => {
      test.skip(!SEED, "cal SETIMIG_TEST_DECK_SEED (3 o 217)");
      await startSolo(page);
      await slowLiftChecks(page, size);
      await toSettlement(page);
      await page.screenshot({ path: `${OUT}/${SEED}-${size.name}.png` }).catch(() => {});
      await settlementChecks(page);
    });
  });
}

/** Edu 22:13: torn d'un rival (2 cartes) a 390×844 i 390×700. */
for (const h of [844, 700]) {
  test.describe(`Torn del rival v176 @390x${h}`, () => {
    test.use({ viewport: { width: 390, height: h }, isMobile: true, hasTouch: true });
    test("etiqueta sota el total, píndoles visibles, sense franja", async ({ page }) => {
      test.skip(!SEED, "cal SETIMIG_TEST_DECK_SEED (3 o 217)");
      await startSolo(page);
      const stage = page.getByTestId("focus-stage");
      for (let i = 0; i < 200 && !(await stage.isVisible().catch(() => false)); i++) {
        const stand = page.getByTestId("action-stand").filter({ visible: true }).first();
        if ((await stand.isVisible().catch(() => false)) && (await stand.isEnabled({ timeout: 500 }).catch(() => false)))
          await stand.click({ timeout: 1000 }).catch(() => {});
        await page.waitForTimeout(150);
      }
      await expect(stage).toBeVisible();
      await page.waitForTimeout(700);
      await page.screenshot({ path: `${OUT}/rival-${SEED}-390x${h}.png` }).catch(() => {});
      const r = await page.evaluate(() => {
        const box = (e: Element | null) => (e ? e.getBoundingClientRect() : null);
        const stage = document.querySelector('[data-testid="focus-stage"]')!;
        const label = box(stage.querySelector('[data-testid="focus-turn-label"]'));
        const score = box(stage.querySelector(".hero-score"));
        const cards = [...stage.querySelectorAll(".spanish-card, .playing-card")].map((e) => e.getBoundingClientRect()).filter((b) => b.height > 0);
        const seats = [...document.querySelectorAll('[data-testid="v2-seat"]')].filter((e) => !stage.contains(e)).map((e) => e.getBoundingClientRect()).filter((b) => b.height > 0);
        const pills = [...document.querySelectorAll('[data-testid="v2-seat-pill"]')].filter((e) => !stage.contains(e)).map((e) => e.getBoundingClientRect()).filter((b) => b.height > 0);
        // Element més alt al punt de cada píndola: ha de ser la píndola (o un fill).
        const pillsCovered = [...document.querySelectorAll('[data-testid="v2-seat-pill"]')].filter((e) => !stage.contains(e) && e.getBoundingClientRect().height > 0).filter((e) => {
          const b = e.getBoundingClientRect();
          const top = document.elementFromPoint(b.left + b.width / 2, b.top + b.height / 2);
          // Els avisos transitoris (toast) no compten; sí les cartes grans.
          return !!top && !e.contains(top) && !top.contains(e) && !!top.closest('[data-testid="focus-stage"] .spanish-card, [data-testid="focus-stage"] .playing-card, [data-testid="focus-stage"] .hero-score');
        }).map((e) => e.textContent);
        // Franja inferior: cap caixa visible amb fons/vora a la part de baix sense contingut.
        const bottomEls = document.elementsFromPoint(innerWidth / 2, innerHeight - 30).filter((e) => {
          const cs = getComputedStyle(e);
          const filled = cs.borderTopWidth !== "0px" && cs.borderTopStyle !== "none" || (cs.backgroundColor !== "rgba(0, 0, 0, 0)" && cs.backgroundColor !== "transparent");
          return filled && e !== document.body && e !== document.documentElement && !(e as HTMLElement).id?.startsWith("root") && (e.textContent ?? "").trim() === "" && e.getBoundingClientRect().width > innerWidth * 0.6 && e.getBoundingClientRect().height < innerHeight * 0.5;
        }).map((e) => `${e.tagName}.${(e as HTMLElement).className}`);
        return { label, score, cards, seats, pills, pillsCovered, bottomEls };
      });
      expect(r.label && r.score, "etiqueta i total").toBeTruthy();
      expect(r.label!.top, "etiqueta sota el total gran").toBeGreaterThanOrEqual(r.score!.bottom - 1);
      const ov = (a: DOMRect | { left: number; right: number; top: number; bottom: number }, b: typeof a) => a.left < b.right - 1 && b.left < a.right - 1 && a.top < b.bottom - 1 && b.top < a.bottom - 1;
      for (const c of [...r.cards, ...r.seats]) expect(ov(r.label!, c), "etiqueta sobre cartes/seients").toBe(false);
      const seatsBottom = Math.max(0, ...r.seats.map((s) => s.bottom), ...r.pills.map((s) => s.bottom));
      for (const c of r.cards) expect(c.top, "cartes grans sota la fila de seients").toBeGreaterThanOrEqual(seatsBottom - 1);
      // El text «○ 100 1.900» sota la meva carta reduïda es llegeix (≥ 12 px renderitzats).
      for (const el of await page.locator('[data-testid="focus-mine"] :is(.own-bet-amount, .own-bet-balance)').all()) {
        if (!(await el.isVisible())) continue;
        expect((await el.boundingBox())!.height, "text sota la meva carta llegible").toBeGreaterThanOrEqual(12);
      }
      expect(r.pillsCovered, "píndoles tapades").toEqual([]);
      expect(r.bottomEls, "franja/caixa buida a baix").toEqual([]);
    });
  });
}
