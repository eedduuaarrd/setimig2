import { expect, test, type Page } from "@playwright/test";
import { seedE2eSession } from "./helpers/e2eSession.ts";
import { gestPeekTurnSnapshot } from "./helpers/gestLliscarFixtures.ts";

const PID = "gest-ovf-1";
const PNAME = "Edu";

async function seed(page: Page, snap: string) {
  await seedE2eSession(page, PID);
  await page.addInitScript(
    ({ snap, pid, pname }) => {
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", pname);
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_house_rules_enabled", "1");
      localStorage.setItem(
        "setimig_age_gate",
        JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }),
      );
      localStorage.setItem("setimig_local_solo_snapshot", snap);
      sessionStorage.setItem("setimig_solo_rejoin", "1");
      sessionStorage.setItem("setimig_solo_local", "1");
    },
    { snap, pid: PID, pname: PNAME },
  );
  await page.route("**/socket.io/**", (route) => route.abort());
}

async function dragPartial(page: Page) {
  const grab = page.getByTestId("peek-curl-grab").first();
  const host = page.getByTestId("peek-curl-host").first();
  await expect(grab).toBeVisible({ timeout: 45_000 });
  const box = await grab.boundingBox();
  const hostBox = await host.boundingBox();
  if (!box || !hostBox) throw new Error("no box");
  const x = box.x + box.width / 2;
  const localY = Math.min(box.height * 0.7, box.height - 4);
  const startY = box.y + localY;
  const endY = startY - hostBox.height * 0.55;
  await grab.evaluate(
    (el, args) => {
      const target = el as HTMLElement;
      const fire = (type: string, clientX: number, clientY: number, buttons: number, on: EventTarget = target) => {
        on.dispatchEvent(
          new PointerEvent(type, {
            bubbles: true,
            cancelable: true,
            view: window,
            clientX,
            clientY,
            pointerId: 1,
            pointerType: "mouse",
            isPrimary: true,
            buttons,
            button: 0,
          }),
        );
      };
      fire("pointerdown", args.x, args.startY, 1);
      for (let i = 1; i <= 20; i++) {
        const y = args.startY + (args.endY - args.startY) * (i / 20);
        fire("pointermove", args.x, y, 1, window);
      }
    },
    { x, startY, endY },
  );
  await expect(host).toHaveAttribute("data-peeking", "yes", { timeout: 1_500 });
  await expect(page.locator("html")).toHaveAttribute("data-peek-curl-active", "yes", { timeout: 1_000 });
}

async function measureClip(page: Page) {
  return page.evaluate(() => {
    const host = document.querySelector<HTMLElement>("[data-testid=peek-curl-host]");
    const canvas = document.querySelector<HTMLElement>("[data-testid=peek-curl-canvas]");
    if (!host || !canvas) return { ok: false as const, clipProblem: true };
    const cr = canvas.getBoundingClientRect();
    let clipProblem = false;
    let clipBy: string | null = null;
    let el: HTMLElement | null = host.parentElement;
    while (el && el !== document.body) {
      const cs = getComputedStyle(el);
      const r = el.getBoundingClientRect();
      const clips =
        cs.overflow === "hidden" ||
        cs.overflow === "clip" ||
        cs.overflowY === "hidden" ||
        cs.overflowY === "clip";
      if (clips && (cr.top < r.top - 1 || cr.bottom > r.bottom + 1 || cr.left < r.left - 1 || cr.right > r.right + 1)) {
        clipProblem = true;
        clipBy = el.className?.toString?.().slice(0, 80) ?? el.tagName;
        break;
      }
      el = el.parentElement;
    }
    return { ok: true as const, clipProblem, clipBy, canvasTop: cr.top };
  });
}

for (const vp of [
  { tag: "390x844", width: 390, height: 844 },
  { tag: "1280x800", width: 1280, height: 800 },
] as const) {
  test(`no overflow/clip at ${vp.tag} during partial peek`, async ({ page }) => {
    await page.setViewportSize({ width: vp.width, height: vp.height });
    await seed(page, gestPeekTurnSnapshot(PID, PNAME));
    await page.goto("/");
    await dragPartial(page);
    const m = await measureClip(page);
    const v = await page.evaluate(() => {
      const c = document.querySelector<HTMLElement>("[data-testid=peek-curl-canvas]")!.getBoundingClientRect();
      return { sw: document.documentElement.scrollWidth, iw: innerWidth, ih: innerHeight, r: [c.left, c.top, c.right, c.bottom] };
    });
    await page.mouse.up();
    expect(v.sw, JSON.stringify(v)).toBeLessThanOrEqual(v.iw);
    expect(v.r[0]).toBeGreaterThanOrEqual(0);
    expect(v.r[1]).toBeGreaterThanOrEqual(0);
    expect(v.r[2]).toBeLessThanOrEqual(v.iw);
    expect(v.r[3]).toBeLessThanOrEqual(v.ih);
    expect(m.ok, JSON.stringify(m)).toBeTruthy();
    expect(m.clipProblem, JSON.stringify(m)).toBeFalsy();
  });
}
