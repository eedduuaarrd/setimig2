import AxeBuilder from "@axe-core/playwright";
import { expect, test, type Page } from "@playwright/test";
import { E2E_ACCOUNT_IDS, e2ePoolId, seedE2eLaunch } from "./helpers/e2eSession.ts";
import { activeTurnCenterHandSnapshotJson } from "./helpers/fixMobilTornCentralFixtures.ts";
import {
  settlementLayoutSnapshotJson,
  settlementSnapshotJson,
} from "./helpers/esteticaFormalFixtures.ts";

const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844 },
  { tag: "375x667", width: 375, height: 667 },
  { tag: "360x740", width: 360, height: 740 },
] as const;

const LAYOUT_HIERARCHY_VIEWPORTS = VIEWPORTS.filter(
  (vp) => vp.tag === "375x667" || vp.tag === "360x740"
);

async function assertNoVerticalPageScroll(page: Page) {
  const metrics = await page.evaluate(() => ({
    scrollHeight: document.documentElement.scrollHeight,
    innerHeight: window.innerHeight,
  }));
  expect(metrics.scrollHeight).toBeLessThanOrEqual(metrics.innerHeight + 1);
}

async function assertDockWithinViewport(page: Page) {
  const dock = page.getByTestId("action-dock");
  await expect(dock).toBeVisible();
  const box = await dock.boundingBox();
  expect(box).not.toBeNull();
  const viewport = page.viewportSize();
  expect(viewport).not.toBeNull();
  expect(box!.y + box!.height).toBeLessThanOrEqual(viewport!.height + 1);
}

async function seedLocalSolo(page: Page, snapshot: string, playerId: string, playerName: string) {
  playerId = E2E_ACCOUNT_IDS.includes(playerId) ? playerId : e2ePoolId();
  await seedE2eLaunch(page, playerId);
  await page.addInitScript(
    ({ snap, pid, pname }) => {
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", pname);
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_house_rules_enabled", "1");
      localStorage.setItem(
        "setimig_age_gate",
        JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
      );
      const parsed = JSON.parse(snap) as {
        room?: { settlementStartedAt?: number; lastRound?: { at?: number } };
      };
      const now = Date.now();
      if (parsed.room) {
        parsed.room.settlementStartedAt = now;
        if (parsed.room.lastRound) parsed.room.lastRound.at = now;
      }
      localStorage.setItem("setimig_local_solo_snapshot", JSON.stringify(parsed));
      sessionStorage.setItem("setimig_solo_rejoin", "1");
      sessionStorage.setItem("setimig_solo_local", "1");
    },
    { snap: snapshot, pid: playerId, pname: playerName }
  );
}

async function assertRivalCardsInsideSeats(page: Page) {
  const issues = await page.evaluate(() => {
    const out: string[] = [];
    const seats = Array.from(document.querySelectorAll(".rival-strip-seat"));
    seats.forEach((seat) => {
      const seatRect = seat.getBoundingClientRect();
      const fan = seat.querySelector(".seat-hand-fan-computed") as HTMLElement | null;
      if (fan) {
        const fanRect = fan.getBoundingClientRect();
        if (fanRect.width > seatRect.width + 2 || fanRect.right > seatRect.right + 2 || fanRect.left < seatRect.left - 2) {
          out.push(`${seat.getAttribute("data-seat-player") ?? "seat"} fan overflow`);
        }
      }
      seat.querySelectorAll(".rival-strip-fan-card").forEach((cardEl, index) => {
        const r = cardEl.getBoundingClientRect();
        if (r.width < 1 || r.height < 1) return;
        if (r.bottom > seatRect.bottom + 2) {
          out.push(`${seat.getAttribute("data-seat-player") ?? "seat"} card ${index} bottom`);
        }
      });
    });
    for (let i = 0; i < seats.length - 1; i++) {
      const a = seats[i]!.getBoundingClientRect();
      const b = seats[i + 1]!.getBoundingClientRect();
      if (a.right > b.left + 2) {
        out.push(`seats ${i}-${i + 1} overlap`);
      }
    }
    return out;
  });
  expect(issues).toEqual([]);
}

async function assertBankFanHasFiveCards(page: Page) {
  const bankSeat = page.locator('.rival-strip-seat[data-seat-banker="true"]').first();
  await expect(bankSeat.locator(".rival-strip-fan-card")).toHaveCount(5);
}

async function assertNoZeroHalfLabel(page: Page) {
  const zeroHalfVisible = await page.evaluate(() => {
    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
    while (walker.nextNode()) {
      const text = walker.currentNode.textContent ?? "";
      if (!text.includes("0½")) continue;
      const host = walker.currentNode.parentElement;
      if (!host || host.closest(".sr-only")) continue;
      const rect = host.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0) return true;
    }
    return false;
  });
  expect(zeroHalfVisible).toBe(false);
}

for (const vp of VIEWPORTS) {
  test.describe(`estètica formal liquidació ${vp.tag}`, () => {
    test.use({ viewport: { width: vp.width, height: vp.height } });

    test(`modal únic de liquidació (${vp.tag})`, async ({ page }) => {
      const playerId = e2ePoolId();
      const playerName = "EstFormal";
      await seedLocalSolo(page, settlementSnapshotJson(playerId, playerName), playerId, playerName);
      await page.route("**/socket.io/**", (route) => route.abort());
      await page.goto("/");

      const sheet = page.getByTestId("settlement-sheet");
      await expect(sheet).toBeVisible({ timeout: 30_000 });
      await expect(page.getByTestId("my-hand-result")).toBeVisible();
      await expect(page.getByTestId("settlement-next-hand")).toContainText("Següent mà");

      const duplicateCountdown = await page.getByText(/Automàtic en \d+ s|Mà següent comença automàticament/i).count();
      expect(duplicateCountdown).toBeLessThanOrEqual(1);

      await expect(page.getByTestId("celebracio-7mig")).toHaveCount(0);
      await expect(page.getByTestId("chips-fly")).toHaveCount(0);

      await expect(page.getByTestId("settlement-sheet").getByText(/Automàtic en \d+ s/)).toHaveCount(1);
    });

    test(`liquidació: seients, banca i ½ (${vp.tag})`, async ({ page }) => {
      const playerId = e2ePoolId();
      await seedLocalSolo(page, settlementLayoutSnapshotJson(playerId, "EstLayout"), playerId, "EstLayout");
      await page.route("**/socket.io/**", (route) => route.abort());
      await page.goto("/");

      await expect(page.getByTestId("settlement-sheet")).toBeVisible({ timeout: 30_000 });
      // seat-sevenhalf-badge: ara només és un toast transitori al seient, no es comprova a la liquidació.

      await assertRivalCardsInsideSeats(page);
      await assertBankFanHasFiveCards(page);
      await assertNoZeroHalfLabel(page);
      await expect(page.getByTestId("my-hand-points")).toContainText("½");
    });

    test(`jugada: mà local única al dock (${vp.tag})`, async ({ page }) => {
      const playerId = e2ePoolId();
      await seedLocalSolo(
        page,
        activeTurnCenterHandSnapshotJson(playerId, "EstHand"),
        playerId,
        "EstHand"
      );
      await page.route("**/socket.io/**", (route) => route.abort());
      await page.goto("/");

      await expect(page.getByTestId("local-player-seat")).toBeVisible({ timeout: 30_000 });
      // Taula gran (v147): sense total propi durant la jugada.
      await expect(page.getByTestId("my-hand-points")).toHaveCount(0);
      await expect(page.getByTestId("active-turn-hand")).toHaveCount(0);
    });
  });
}

for (const vp of LAYOUT_HIERARCHY_VIEWPORTS) {
  test.describe(`estètica formal jerarquia §5 ${vp.tag}`, () => {
    test.use({ viewport: { width: vp.width, height: vp.height } });

    test(`jugada sense scroll vertical (${vp.tag})`, async ({ page }) => {
      const playerId = e2ePoolId();
      await seedLocalSolo(
        page,
        activeTurnCenterHandSnapshotJson(playerId, "EstScroll"),
        playerId,
        "EstScroll"
      );
      await page.route("**/socket.io/**", (route) => route.abort());
      await page.goto("/");

      await expect(page.getByTestId("local-player-seat")).toBeVisible({ timeout: 30_000 });
      await expect(page.getByTestId("action-dock")).toBeVisible();
      await assertNoVerticalPageScroll(page);
      await assertDockWithinViewport(page);
    });
  });
}

test.describe("estètica formal — contrast (axe)", () => {
  test("lobby sense violacions de contrast AA", async ({ page }) => {
    await seedE2eLaunch(page, "est-axe-lobby");
    await page.addInitScript(() => {
      localStorage.setItem("setimig_player_id", "est-axe-lobby");
      localStorage.setItem("setimig_player_name", "EstAxeLobby");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem(
        "setimig_age_gate",
        JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
      );
    });
    await page.goto("/");
    await expect(page.getByTestId("lobby-welcome")).toBeVisible({ timeout: 30_000 });
    // L'entrada del lobby fa un fade: axe ha de mesurar el color final, no el de mig fade.
    await page.waitForFunction(() => document.getAnimations().every((a) => a.playState !== "running"), undefined, { timeout: 8_000 }).catch(() => {});
    await page.waitForTimeout(300);
    const axe = await new AxeBuilder({ page }).withTags(["wcag2aa", "wcag21aa"]).analyze();
    const contrast = axe.violations.filter((v) => v.id === "color-contrast");
    expect(contrast).toEqual([]);
  });

  test("liquidació sense violacions de contrast AA", async ({ page }) => {
    const playerId = "est-axe-settlement";
    await seedLocalSolo(page, settlementSnapshotJson(playerId, "EstAxe"), playerId, "EstAxe");
    await page.route("**/socket.io/**", (route) => route.abort());
    await page.goto("/");
    await expect(page.getByTestId("settlement-sheet")).toBeVisible({ timeout: 30_000 });
    const axe = await new AxeBuilder({ page }).withTags(["wcag2aa", "wcag21aa"]).analyze();
    const contrast = axe.violations.filter((v) => v.id === "color-contrast");
    expect(contrast).toEqual([]);
  });
});
