import fs from "node:fs";
import path from "node:path";
import { expect, test, type Browser, type Page } from "@playwright/test";
import { bettingSnapshot, faceCardsSnapshot, rivalTurnSnapshot } from "./helpers/anim1418Fixtures.ts";
import { openFriendsLobby } from "./helpers/friendsLobby.ts";

/**
 * PR 4 d'animacions: 14 (aposta), 16 (figures), 17 (espera/reconnexió), 18 (error).
 * Captures a SETIMIG_ANIM_SHOTS · 390×844, 1280×800 i moviment reduït.
 */
const SHOTS = process.env.SETIMIG_ANIM_SHOTS ?? path.join("test-results", "anim-14-18");
const AGE_OK = () => JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" });
const MOBILE = { width: 390, height: 844 };
const DESKTOP = { width: 1280, height: 800 };

type Kind = "bet" | "face" | "rival";
type Opts = { reduce?: boolean; desktop?: boolean; freeze?: boolean };

function snapFor(kind: Kind, pid: string): string {
  if (kind === "bet") return bettingSnapshot(pid);
  if (kind === "face") return faceCardsSnapshot(pid);
  return rivalTurnSnapshot(pid);
}

async function openSolo(browser: Browser, kind: Kind, opts: Opts = {}) {
  const vp = opts.desktop ? DESKTOP : MOBILE;
  const ctx = await browser.newContext({
    viewport: vp,
    deviceScaleFactor: opts.desktop ? 1 : 2,
    locale: "en-US",
    colorScheme: "dark",
    reducedMotion: opts.reduce ? "reduce" : "no-preference",
  });
  const page = await ctx.newPage();
  const pid = `anim1418-${kind}-${vp.width}-${Date.now()}`;
  await page.addInitScript(
    ({ snap, pid, age, freeze }) => {
      (window as unknown as { __vib: unknown[]; __SETIMIG_FREEZE_BOTS?: boolean }).__vib = [];
      if (freeze) {
        (window as unknown as { __SETIMIG_FREEZE_BOTS?: boolean }).__SETIMIG_FREEZE_BOTS = true;
      }
      try {
        Object.defineProperty(navigator, "vibrate", {
          configurable: true,
          value: (p: unknown) => {
            (window as unknown as { __vib: unknown[] }).__vib.push(p);
            return true;
          },
        });
      } catch {
        /* ignore */
      }
      if (sessionStorage.getItem("a1418_seeded") === "1") return;
      sessionStorage.setItem("a1418_seeded", "1");
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", "Edu");
      localStorage.setItem("setimig.locale", "en");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_house_rules_enabled", "0");
      localStorage.setItem("setimig_age_gate", age);
      localStorage.setItem("setimig_local_solo_snapshot", snap);
      sessionStorage.setItem("setimig_solo_rejoin", "1");
      sessionStorage.setItem("setimig_solo_local", "1");
    },
    { snap: snapFor(kind, pid), pid, age: AGE_OK(), freeze: !!opts.freeze }
  );
  await page.route("**/socket.io/**", (route) => route.abort());
  await page.goto("/");
  return { ctx, page, vp };
}

async function shot(page: Page, name: string) {
  fs.mkdirSync(SHOTS, { recursive: true });
  await page.screenshot({ path: path.join(SHOTS, `${name}.png`) });
}

test("14 · aposta (390×844): rail, límits reals, denegació amb saldo 60", async ({ browser }) => {
  const { ctx, page } = await openSolo(browser, "bet");
  await expect(page.getByTestId("bet-screen")).toBeVisible({ timeout: 30_000 });
  await expect(page.getByTestId("bet-rail")).toBeVisible();
  await expect(page.getByTestId("bet-balance")).toContainText("60");
  // Sostre de taula 100 al rail (no el saldo)
  await expect(page.getByTestId("bet-range")).toHaveAttribute("data-max", "100");
  const track = page.getByTestId("bet-rail-track");
  const box = await track.boundingBox();
  expect(box).toBeTruthy();
  // Arrossega cap al MAX (goma) → 100 > saldo 60
  await page.mouse.move(box!.x + box!.width - 4, box!.y + box!.height / 2);
  await page.mouse.down();
  await page.mouse.move(box!.x + box!.width + 40, box!.y + box!.height / 2, { steps: 8 });
  await page.mouse.up();
  await expect(page.getByTestId("bet-limit-pill")).toBeVisible({ timeout: 2_000 });
  await expect(page.getByTestId("bet-amount-display")).toHaveText(/^100$/);
  await shot(page, "14-aposta-390x844-1-max");
  await page.getByTestId("bet-confirm").click();
  await expect(page.getByTestId("bet-not-enough")).toBeVisible({ timeout: 3_000 });
  await shot(page, "14-aposta-390x844-2-not-enough");
  await ctx.close();
});

test("16 · figures (390×844): toc a sota/cavall → bombolla ½", async ({ browser }) => {
  const { ctx, page } = await openSolo(browser, "face");
  await expect(page.getByTestId("action-hit")).toBeEnabled({ timeout: 30_000 });
  const face = page.getByRole("button", { name: /Face card worth half a point/i }).first();
  await expect(face).toBeVisible({ timeout: 10_000 });
  await face.click({ force: true });
  await face.dispatchEvent("click");
  await expect(page.getByTestId("face-hint-bubble")).toBeVisible({ timeout: 3_000 });
  await expect(page.getByTestId("face-hint-bubble")).toContainText("½");
  await shot(page, "16-figures-390x844-1-bubble");
  await ctx.close();
});

test("18 · error (390×844): Hit desactivat tremola i missatge", async ({ browser }) => {
  const { ctx, page } = await openSolo(browser, "rival", { freeze: true });
  // Dock visible amb ActionErrorCue; bots congelats via __SETIMIG_FREEZE_BOTS.
  await expect(page.getByTestId("action-error-cue")).toBeVisible({ timeout: 30_000 });
  await page.getByTestId("action-hit").dispatchEvent("pointerdown", { button: 0 });
  await expect(page.getByTestId("action-error-msg")).toBeVisible({ timeout: 2_000 });
  await expect(page.getByTestId("action-error-msg")).toContainText(/Not your turn|Anna/i);
  await shot(page, "18-error-390x844-1-shake");
  const vib = await page.evaluate(() => (window as unknown as { __vib: unknown[] }).__vib);
  expect(vib.length).toBeGreaterThan(0);
  await ctx.close();
});

test("17 · espera: Reconnecting després d'1 s (solo) i seients oberts (privada)", async ({ browser }) => {
  // Reconnect debounce: partida solo (overlay ja no es salta)
  const solo = await openSolo(browser, "face");
  await expect(solo.page.getByTestId("action-hit")).toBeEnabled({ timeout: 30_000 });
  await solo.ctx.setOffline(true);
  await expect(solo.page.getByTestId("reconnect-overlay")).toHaveCount(0, { timeout: 500 });
  await expect(solo.page.getByTestId("reconnect-overlay")).toBeVisible({ timeout: 2_500 });
  await expect(solo.page.getByTestId("reconnect-panel")).toContainText(/Reconnecting/i);
  await shot(solo.page, "17-espera-390x844-2-reconnecting");
  await solo.ctx.setOffline(false);
  await expect(solo.page.getByTestId("reconnect-panel")).toContainText(/Back online|online/i, { timeout: 3_000 });
  await shot(solo.page, "17-espera-390x844-3-back-online");
  await solo.ctx.close();

  // Seients oberts en taula privada
  const ctx = await browser.newContext({ viewport: MOBILE, deviceScaleFactor: 2, locale: "en-US", colorScheme: "dark" });
  const page = await ctx.newPage();
  await page.addInitScript((age) => {
    localStorage.setItem("setimig_player_name", "Edu");
    localStorage.setItem("setimig.locale", "en");
    localStorage.setItem("setimig_onboarding_v1", "1");
    localStorage.setItem("setimig_interactive_tutorial_v1", "1");
    localStorage.setItem("setimig_age_gate", age);
  }, AGE_OK());
  await page.goto("/");
  await openFriendsLobby(page);
  const create = page.getByTestId("create-private-table-inline");
  await expect(create).toBeVisible({ timeout: 15_000 });
  if (await create.isEnabled()) {
    await create.click();
    await expect(page.getByTestId("private-waiting-panel")).toBeVisible({ timeout: 30_000 });
    await expect(page.getByTestId("open-seat").first()).toBeVisible({ timeout: 10_000 });
    await shot(page, "17-espera-390x844-1-open-seats");
  } else {
    // Sense socket (CI/VPS aïllat): el debounce de reconnexió ja s'ha comprovat amunt.
    test.info().annotations.push({ type: "note", description: "create-private disabled; open seats skipped" });
  }
  await ctx.close();
});

test("14+16+18 · escriptori 1280×800", async ({ browser }) => {
  const bet = await openSolo(browser, "bet", { desktop: true });
  await expect(bet.page.getByTestId("bet-rail")).toBeVisible({ timeout: 30_000 });
  await shot(bet.page, "14-aposta-1280x800-1-rail");
  await bet.ctx.close();

  const face = await openSolo(browser, "face", { desktop: true });
  await expect(face.page.getByTestId("action-hit")).toBeEnabled({ timeout: 30_000 });
  await face.page.getByRole("button", { name: /Face card worth half a point/i }).first().click({ force: true });
  await expect(face.page.getByTestId("face-hint-bubble")).toBeVisible({ timeout: 2_000 });
  await shot(face.page, "16-figures-1280x800-1-bubble");
  await face.ctx.close();

  const err = await openSolo(browser, "rival", { desktop: true, freeze: true });
  await expect(err.page.getByTestId("action-error-cue")).toBeVisible({ timeout: 30_000 });
  await err.page.getByTestId("action-hit").dispatchEvent("pointerdown");
  await expect(err.page.getByTestId("action-error-msg")).toBeVisible({ timeout: 2_000 });
  await shot(err.page, "18-error-1280x800-1-msg");
  await err.ctx.close();
});

test("14+16+18 · moviment reduït (390×844)", async ({ browser }) => {
  const bet = await openSolo(browser, "bet", { reduce: true });
  await expect(bet.page.getByTestId("bet-rail")).toBeVisible({ timeout: 30_000 });
  const track = bet.page.getByTestId("bet-rail-track");
  const box = await track.boundingBox();
  expect(box).toBeTruthy();
  await bet.page.mouse.click(box!.x + box!.width - 2, box!.y + box!.height / 2);
  await expect(bet.page.getByTestId("bet-amount-display")).toHaveText(/^100$/);
  await bet.page.getByTestId("bet-confirm").click();
  await expect(bet.page.getByTestId("bet-not-enough")).toBeVisible({ timeout: 2_000 });
  await shot(bet.page, "14-aposta-390x844-reduced");
  await bet.ctx.close();

  const face = await openSolo(browser, "face", { reduce: true });
  await expect(face.page.getByTestId("action-hit")).toBeEnabled({ timeout: 30_000 });
  const faceBtn = face.page.getByRole("button", { name: /Face card worth half a point/i }).first();
  await faceBtn.click({ force: true });
  await faceBtn.dispatchEvent("click");
  await expect(face.page.getByTestId("face-hint-bubble")).toBeVisible({ timeout: 3_000 });
  await expect(faceBtn).toHaveClass(/is-outlined/);
  await shot(face.page, "16-figures-390x844-reduced");
  await face.ctx.close();

  const err = await openSolo(browser, "rival", { reduce: true, freeze: true });
  await expect(err.page.getByTestId("action-error-cue")).toBeVisible({ timeout: 30_000 });
  await err.page.getByTestId("action-hit").dispatchEvent("pointerdown");
  await expect(err.page.getByTestId("action-error-msg")).toBeVisible({ timeout: 2_000 });
  await shot(err.page, "18-error-390x844-reduced");
  await err.ctx.close();
});
