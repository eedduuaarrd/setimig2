import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * v179 · animacions: pista de peek, fastReveal (curl) i cinematografia del Mort.
 * Llavors: 4 (Mort èxit 7½), 206 (Mort falla 7+5=12). La 217 fa 7½ (èxit de fórmula).
 * Cal NODE_ENV=test perquè el servidor respecti SETIMIG_TEST_DECK_SEED.
 */
const SEED = process.env.SETIMIG_TEST_DECK_SEED;

async function startSolo(page: Page) {
  await seedE2eSession(page, e2ePoolId());
  await page.addInitScript(() => {
    if (sessionStorage.getItem("qa_llavor") === "1") return;
    sessionStorage.setItem("qa_llavor", "1");
    for (const k of [
      "setimig_onboarding_v1",
      "setimig_interactive_tutorial_v1",
      "setimig_table_tutorial_v1",
      "setimig_house_rules_enabled",
    ])
      localStorage.setItem(k, "1");
    localStorage.setItem("setimig.locale", "ca");
    localStorage.setItem("setimig_player_name", "Test Llavor");
    localStorage.setItem(
      "setimig_age_gate",
      JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }),
    );
    sessionStorage.setItem("setimig_intro_launch_v1", "1");
  });
  await page.goto("/");
  const skip = page.getByTestId("interactive-tutorial-skip");
  await expect(page.getByTestId("lobby-context").or(skip).first()).toBeVisible({ timeout: 45_000 });
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  if (await page.getByTestId("ai-bot-count-1").isVisible().catch(() => false)) {
    await page.getByTestId("ai-bot-count-1").click();
  }
  const cb = page.getByTestId("house-rules-toggle").locator("input");
  if ((await cb.count()) && !(await cb.isChecked())) await cb.check({ force: true });
  await page.getByTestId("ai-bot-picker-start").click();
  await page.getByTestId("bet-confirm").filter({ visible: true }).first().click({ timeout: 30_000 });
}

const host = (page: Page) => page.getByTestId("peek-curl-host").filter({ visible: true }).first();
const grab = (page: Page) => page.getByTestId("peek-curl-grab").filter({ visible: true }).first();

async function fastFlick(page: Page) {
  const b = (await grab(page).boundingBox())!;
  await page.evaluate(async ({ x, y0 }) => {
    const target = document.elementFromPoint(x, y0)!;
    const ev = (type: string, y: number) =>
      new PointerEvent(type, {
        bubbles: true,
        cancelable: true,
        composed: true,
        pointerId: 7,
        pointerType: "touch",
        isPrimary: true,
        clientX: x,
        clientY: y,
        buttons: type === "pointerup" ? 0 : 1,
      });
    target.dispatchEvent(ev("pointerdown", y0));
    for (let i = 1; i <= 6; i++) {
      await new Promise((r) => setTimeout(r, 5));
      const y = y0 - ((y0 - 2) * i) / 6;
      (document.elementFromPoint(x, Math.max(1, y)) ?? window).dispatchEvent(
        ev("pointermove", Math.max(1, y)),
      );
      window.dispatchEvent(ev("pointermove", Math.max(1, y)));
    }
    window.dispatchEvent(ev("pointerup", 2));
  }, { x: b.x + b.width / 2, y0: b.y + b.height * 0.95 });
}

async function softPeek(page: Page) {
  const b = (await grab(page).boundingBox())!;
  const x = b.x + b.width / 2;
  const y0 = b.y + b.height * 0.95;
  // Puja prou (travel ≥ 0,3 de l'alçada de la carta) perquè markCardPeeked dispari l'oferta.
  const y1 = Math.max(4, b.y - b.height * 0.8);
  await page.mouse.move(x, y0);
  await page.mouse.down();
  for (let i = 1; i <= 12; i++) {
    await page.mouse.move(x, y0 + ((y1 - y0) * i) / 12);
    await page.waitForTimeout(25);
  }
  await page.mouse.up();
  await page.waitForTimeout(200);
}

test.describe("v179 pista peek @390", () => {
  test.use({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });

  test("la pista surt, desapareix en peek i mai mostra la cara", async ({ page }) => {
    test.skip(!SEED, "cal SETIMIG_TEST_DECK_SEED");
    await startSolo(page);
    await expect(grab(page)).toBeVisible({ timeout: 30_000 });
    // Després de 1,5 s d'inactivitat
    await expect(page.getByTestId("peek-swipe-hint")).toBeVisible({ timeout: 5_000 });
    // La solapa de la pista no porta <img> de cara (només ombra)
    const faceImgs = page.locator('[data-testid="peek-swipe-hint"] img');
    await expect(faceImgs).toHaveCount(0);
    await softPeek(page);
    await expect(page.getByTestId("peek-swipe-hint")).toHaveCount(0, { timeout: 3_000 });
  });

  test("reduced motion: sense pista", async ({ page }) => {
    test.skip(!SEED, "cal SETIMIG_TEST_DECK_SEED");
    await page.emulateMedia({ reducedMotion: "reduce" });
    await startSolo(page);
    await expect(grab(page)).toBeVisible({ timeout: 30_000 });
    await page.waitForTimeout(2000);
    await expect(page.getByTestId("peek-swipe-hint")).toHaveCount(0);
  });
});

test.describe("v179 fastReveal @390", () => {
  test.use({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });

  test("botó Destapar carta fa curl i deixa la carta cara amunt", async ({ page }) => {
    test.skip(SEED !== "3", "cal SETIMIG_TEST_DECK_SEED=3 (carta normal destapable)");
    await startSolo(page);
    await expect(grab(page)).toBeVisible({ timeout: 30_000 });
    const id = await host(page).locator("[data-card-id]").first().getAttribute("data-card-id");
    expect(id).toBeTruthy();
    // Peek curt perquè l'oferta no bloquegi; a seed 3 no hi ha Mort
    await softPeek(page);
    const btn = page.getByTestId("reveal-card-action").filter({ visible: true }).first();
    await expect(btn).toBeVisible({ timeout: 15_000 });
    await btn.click();
    await expect(host(page)).toHaveAttribute("data-fast-reveal", /lift|roll|slide|done/, { timeout: 2_000 });
    // Ha de ser curl (canvas), no un gir Y rígid de SpanishCard.
    const canvas = page.getByTestId("peek-curl-canvas").filter({ visible: true }).first();
    await expect(canvas).toBeVisible({ timeout: 1_500 });
    await expect(page.locator(`[data-card-id="${id}"][data-face="up"]`).first()).toBeVisible({
      timeout: 8_000,
    });
  });

  test("lliscament ràpid fins amunt acaba cara amunt amb curl", async ({ page }) => {
    test.skip(SEED !== "3", "cal SETIMIG_TEST_DECK_SEED=3");
    await startSolo(page);
    await expect(grab(page)).toBeVisible({ timeout: 30_000 });
    const id = await host(page).locator("[data-card-id]").first().getAttribute("data-card-id");
    await fastFlick(page);
    await expect(page.locator(`[data-card-id="${id}"][data-face="up"]`).first()).toBeVisible({
      timeout: 8_000,
    });
  });
});

test.describe("v179 Mort @390", () => {
  test.use({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });

  test("seed 4: acceptar Mort → cinematografia d'èxit", async ({ page }) => {
    test.skip(SEED !== "4", "cal SETIMIG_TEST_DECK_SEED=4 (Mort 7½)");
    await startSolo(page);
    await expect(grab(page)).toBeVisible({ timeout: 30_000 });
    await softPeek(page);
    await page.getByTestId("mort-accept").click({ timeout: 20_000 });
    // Espera liquidació (banca juga sola)
    const reveal = page.getByTestId("mort-reveal");
    await expect(reveal).toBeVisible({ timeout: 90_000 });
    await expect(reveal).toHaveAttribute("data-win", "yes", { timeout: 8_000 });
    await expect(page.getByTestId("mort-reveal-headline")).toContainText(/FUNCIONAT|WORKED|FUNCIONADO|FUNZIONATO|FUNCIONOU/i, {
      timeout: 8_000,
    });
  });

  test("seed 206: acceptar Mort → cinematografia de fracàs", async ({ page }) => {
    test.skip(SEED !== "206", "cal SETIMIG_TEST_DECK_SEED=206 (Mort 7+5=12)");
    await startSolo(page);
    await expect(grab(page)).toBeVisible({ timeout: 30_000 });
    await softPeek(page);
    await page.getByTestId("mort-accept").click({ timeout: 20_000 });
    const reveal = page.getByTestId("mort-reveal");
    await expect(reveal).toBeVisible({ timeout: 90_000 });
    await expect(reveal).toHaveAttribute("data-win", "no", { timeout: 8_000 });
    await expect(page.getByTestId("mort-reveal-headline")).toContainText(/PASSAT|BUSTED|PASADO|SBALLATO|ESTOUROU/i, {
      timeout: 8_000,
    });
  });

  test("reduced motion: Mort sense buildup llarg", async ({ page }) => {
    test.skip(SEED !== "4", "cal SETIMIG_TEST_DECK_SEED=4");
    await page.emulateMedia({ reducedMotion: "reduce" });
    await startSolo(page);
    await expect(grab(page)).toBeVisible({ timeout: 30_000 });
    await softPeek(page);
    await page.getByTestId("mort-accept").click({ timeout: 20_000 });
    const reveal = page.getByTestId("mort-reveal");
    await expect(reveal).toBeVisible({ timeout: 90_000 });
    await expect(reveal).toHaveAttribute("data-phase", "result");
    await expect(reveal).toHaveClass(/mort-reveal--reduced/);
  });
});
