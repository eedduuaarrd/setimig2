import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * v185 (Qualitat, liquidació v183): res no tapa el plafó de liquidació (toasts, píndoles, ofertes),
 * la fila de la banca sempre es veu i el plafó no es talla a 1024×700, 1280×720, 390×844 ni 390×667.
 * Cal SETIMIG_TEST_DECK_SEED (docs/baralla-de-prova.md): 3 (doblar + separar), 4 (Mort que guanya),
 * 13 (canvi del 3). Cada cas s'omet amb una altra llavor.
 */
const SEED = process.env.SETIMIG_TEST_DECK_SEED;
const OUT = process.env.LIQ_OUT ?? "/workspace/setimig/qa-liquidacio-v183/v185";
type Box = { x: number; y: number; width: number; height: number };
const overlap = (a: Box, b: Box) =>
  a.x < b.x + b.width - 1 && b.x < a.x + a.width - 1 && a.y < b.y + b.height - 1 && b.y < a.y + a.height - 1;

async function startSolo(page: Page) {
  await seedE2eSession(page, e2ePoolId());
  await page.addInitScript(() => {
    if (sessionStorage.getItem("qa_llavor") === "1") return;
    sessionStorage.setItem("qa_llavor", "1");
    for (const k of ["setimig_onboarding_v1", "setimig_interactive_tutorial_v1", "setimig_table_tutorial_v1", "setimig_house_rules_enabled"]) localStorage.setItem(k, "1");
    localStorage.setItem("setimig.locale", "ca");
    localStorage.setItem("setimig_player_name", "Test Llavor");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
    sessionStorage.setItem("setimig_intro_launch_v1", "1");
  });
  await page.goto("/");
  const skip = page.getByTestId("interactive-tutorial-skip");
  await expect(page.getByTestId("lobby-context").or(skip).first()).toBeVisible({ timeout: 45_000 });
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  await page.getByTestId("ai-bot-count-1").click();
  const cb = page.getByTestId("house-rules-toggle").locator("input");
  if ((await cb.count()) && !(await cb.isChecked())) await cb.check({ force: true });
  await page.getByTestId("ai-bot-picker-start").click();
}
const confirmBet = (page: Page) => page.getByTestId("bet-confirm").filter({ visible: true }).first().click({ timeout: 30_000 });

async function swipe(page: Page) {
  const grab = page.getByTestId("peek-curl-grab").filter({ visible: true }).first();
  await expect(grab).toBeVisible({ timeout: 30_000 });
  const b = (await grab.boundingBox())!;
  const x = b.x + b.width / 2, y0 = b.y + b.height * 0.95, y1 = b.y + b.height * 0.3;
  await page.mouse.move(x, y0);
  await page.mouse.down();
  for (let i = 1; i <= 8; i++) { await page.mouse.move(x, y0 + ((y1 - y0) * i) / 8); await page.waitForTimeout(40); }
  await page.mouse.up();
}
const visibleBtn = (page: Page, name: RegExp) => page.getByRole("button", { name }).filter({ visible: true }).first();

async function untilSettlement(page: Page) {
  const sheet = page.getByTestId("settlement-sheet");
  for (let i = 0; i < 150 && !(await sheet.isVisible().catch(() => false)); i++) {
    const st = page.getByTestId("action-stand").filter({ visible: true }).first();
    if (await st.isVisible({ timeout: 300 }).catch(() => false)) await st.click({ timeout: 2_000 }).catch(() => {});
    await page.waitForTimeout(400);
  }
  await expect(sheet).toBeVisible();
}

/** Doblar i separar (llavor 3): dues figures, separar, plantar les dues mans. */
async function doubleAndSplit(page: Page) {
  await swipe(page);
  const dbl = page.getByTestId("mobile-double-chip").filter({ visible: true }).first().or(visibleBtn(page, /^Doblar/));
  await dbl.first().click({ timeout: 15_000 });
  const split = page.getByTestId("mobile-split-button").filter({ visible: true }).first().or(visibleBtn(page, /^Separar/));
  await split.first().click({ timeout: 15_000 });
  await expect(page.getByTestId("own-split-hand").first()).toBeVisible({ timeout: 10_000 });
}

/** Regla general: plafó dins la pantalla, sense retall, amb la fila de la banca i sense res a sobre. */
async function settlementClean(page: Page, label: string) {
  await page.waitForTimeout(1600); // entrades (toast, +/−, píndoles) ja en pantalla
  await page.screenshot({ path: `${OUT}/${label}.png` }).catch(() => {});
  // Les capes d'efectes (píndoles, +/−) no reben clics: per al test de solapament, tothom rep el punt.
  await page.addStyleTag({ content: "*{pointer-events:auto!important}" });
  const res = await page.evaluate(() => {
    const card = document.querySelector(".settlement-card") as HTMLElement | null;
    if (!card) return null;
    const r = card.getBoundingClientRect();
    const covers: string[] = [];
    for (let i = 1; i < 8; i++) for (let j = 1; j < 10; j++) {
      const x = r.left + (r.width * i) / 8, y = r.top + (r.height * j) / 10;
      if (x < 0 || y < 0 || x >= innerWidth || y >= innerHeight) continue;
      const el = document.elementFromPoint(x, y);
      if (el && !card.contains(el)) covers.push(`${(el as HTMLElement).dataset.testid ?? ""}.${String((el as HTMLElement).className).slice(0, 60)} «${(el.textContent ?? "").trim().slice(0, 30)}»`);
    }
    const rows = [...card.querySelectorAll<HTMLElement>('[data-testid="settlement-result-row"]')];
    const bank = rows.find((e) => e.dataset.bank === "true");
    const br = bank?.getBoundingClientRect();
    const parts = [...card.querySelectorAll<HTMLElement>('[data-testid="my-hand-result"],[data-testid="settlement-hand-row"],[data-testid="settlement-result-row"],[data-testid="settlement-new-balance"],[data-testid="settlement-bank-offer"],[data-testid="settlement-next-hand"]')]
      .filter((e) => e.getClientRects().length)
      .map((e) => { const b = e.getBoundingClientRect(); return { id: `${e.dataset.testid} «${(e.textContent ?? "").trim().slice(0, 24)}»`, x: b.left, y: b.top, width: b.width, height: b.height }; });
    return {
      card: { x: r.left, y: r.top, width: r.width, height: r.height },
      vw: innerWidth, vh: innerHeight,
      clipped: card.scrollHeight > card.clientHeight + 1,
      covers: [...new Set(covers)],
      bank: br ? { x: br.left, y: br.top, width: br.width, height: br.height } : null,
      parts,
    };
  });
  expect(res, "plafó de liquidació").not.toBeNull();
  const { card, vw, vh } = res!;
  expect(card.x, "dins la pantalla (esquerra)").toBeGreaterThanOrEqual(-0.5);
  expect(card.y, "dins la pantalla (dalt)").toBeGreaterThanOrEqual(-0.5);
  expect(card.x + card.width, "dins la pantalla (dreta)").toBeLessThanOrEqual(vw + 0.5);
  expect(card.y + card.height, "dins la pantalla (baix)").toBeLessThanOrEqual(vh + 0.5);
  expect(res!.clipped, "el plafó no es talla (sense desplaçament intern)").toBe(false);
  expect(res!.covers, "res no tapa el plafó").toEqual([]);
  expect(res!.bank, "fila de la banca").not.toBeNull();
  const b = res!.bank!;
  expect(b.y >= card.y - 0.5 && b.y + b.height <= card.y + card.height + 0.5, "fila de la banca dins el plafó").toBe(true);
  expect(b.y + b.height, "fila de la banca dins la pantalla").toBeLessThanOrEqual(vh + 0.5);
  const parts = res!.parts;
  for (let i = 0; i < parts.length; i++) for (let k = i + 1; k < parts.length; k++)
    expect(overlap(parts[i], parts[k]), `${parts[i].id} no se solapa amb ${parts[k].id}`).toBe(false);
}

const SPLIT_SIZES = [
  { name: "1024x700", width: 1024, height: 700 },
  { name: "1280x720", width: 1280, height: 720 },
  { name: "390x844", width: 390, height: 844 },
  { name: "390x667", width: 390, height: 667 },
] as const;

for (const size of SPLIT_SIZES) {
  const mobile = size.width < 600;
  test.describe(`Liquidació v185 @${size.name}`, () => {
    test.use({ viewport: { width: size.width, height: size.height }, isMobile: mobile, hasTouch: mobile });

    // Casos 3 i 5: separar. La píndola de la banca no tapa la Mà 1, «Es planta» no tapa «MÀ 1 · DOBLADA».
    test("separar: plafó net, fila de la banca i «Es planta» fora de l'etiqueta de la mà", async ({ page }) => {
      test.skip(SEED !== "3", "cal SETIMIG_TEST_DECK_SEED=3");
      test.setTimeout(180_000);
      await startSolo(page);
      await confirmBet(page);
      await doubleAndSplit(page);
      await untilSettlement(page);
      await settlementClean(page, `separar-${size.name}`);
      const labels = page.getByTestId("split-hand-label");
      const chips = page.getByTestId("settled-hand-chip");
      for (const l of await labels.all()) {
        if (!(await l.isVisible())) continue;
        const lb = (await l.boundingBox())!;
        for (const c of await chips.all()) {
          const cb = await c.boundingBox();
          if (cb && (await c.isVisible())) expect(overlap(lb, cb), `«${await c.innerText()}» no tapa «${await l.innerText()}»`).toBe(false);
        }
      }
    });
  });
}

for (const size of [{ name: "1024x700", width: 1024, height: 700 }, { name: "390x844", width: 390, height: 844 }] as const) {
  const mobile = size.width < 600;
  test.describe(`Canvi del 3 v185 @${size.name}`, () => {
    test.use({ viewport: { width: size.width, height: size.height }, isMobile: mobile, hasTouch: mobile });
    // Cas 2: toast, animació +/− i «Perd · 6» no tapen l'import; «Tens …» no cau sobre la banca.
    test("canviar el 3: res sobre l'import ni sobre la fila de la banca", async ({ page }) => {
      test.skip(SEED !== "13", "cal SETIMIG_TEST_DECK_SEED=13");
      test.setTimeout(180_000);
      await startSolo(page);
      await confirmBet(page);
      await swipe(page);
      await page.getByTestId("swap-swap").filter({ visible: true }).first().click({ timeout: 20_000 });
      await untilSettlement(page);
      await settlementClean(page, `canvi3-${size.name}`);
    });
  });
}

test.describe("Oferta de banca v185 @1280x720", () => {
  test.use({ viewport: { width: 1280, height: 720 } });
  // Cas 4: «Vols ser banca?» va dins el plafó, sota la fila de la banca, sense tapar-la.
  test("«Vols ser banca?» no tapa la fila de la banca", async ({ page }) => {
    test.skip(SEED !== "13", "cal SETIMIG_TEST_DECK_SEED=13");
    test.setTimeout(180_000);
    await startSolo(page);
    await confirmBet(page);
    await swipe(page);
    await page.getByTestId("swap-swap").filter({ visible: true }).first().click({ timeout: 20_000 });
    await untilSettlement(page);
    await page.evaluate(() => (window as unknown as { __SETIMIG_TEST_PATCH_ME?: (p: unknown) => void }).__SETIMIG_TEST_PATCH_ME?.({ pendingBankChoice: { mandatory: false } }));
    await expect(page.getByTestId("settlement-bank-offer")).toBeVisible();
    await settlementClean(page, "oferta-banca-1280x720");
  });
});

for (const size of [{ name: "390x844", width: 390, height: 844 }, { name: "1280x720", width: 1280, height: 720 }] as const) {
  const mobile = size.width < 600;
  test.describe(`Mort guanyat v185 @${size.name}`, () => {
    test.use({ viewport: { width: size.width, height: size.height }, isMobile: mobile, hasTouch: mobile });
    // Casos 1 i 6: acceptar el Mort i guanyar mostra la liquidació, amb «Guanyes» i sense punts propis.
    test("acceptar el Mort i guanyar: surt la liquidació amb «Guanyes»", async ({ page }) => {
      test.skip(SEED !== "4", "cal SETIMIG_TEST_DECK_SEED=4");
      test.setTimeout(180_000);
      await startSolo(page);
      await confirmBet(page);
      await swipe(page);
      await page.getByTestId("mort-accept").click({ timeout: 20_000 });
      // El full surt després del suspens del Mort encara que el servidor ja hagi tancat la liquidació (5 s a solo).
      await expect(page.getByTestId("settlement-sheet")).toBeVisible({ timeout: 12_000 });
      const result = page.getByTestId("my-hand-result");
      await expect(result).toBeVisible();
      await expect(page.getByTestId("settlement-outcome-line")).toHaveText("Guanyes");
      expect(await result.innerText()).not.toMatch(/½|·\s*\d/);
      await settlementClean(page, `mort-guanyat-${size.name}`);
    });
  });
}

test.describe("Saldo de la pantalla d'aposta v185 @390x844", () => {
  test.use({ viewport: { width: 390, height: 844 }, isMobile: true, hasTouch: true });
  // Cas 7: «Saldo 2.200» amb el format de l'idioma (com «Tens 2.200»), mai «2,200» en català.
  test("el saldo segueix el format de l'idioma", async ({ page }) => {
    test.skip(!SEED, "cal SETIMIG_TEST_DECK_SEED");
    await startSolo(page);
    const bal = page.getByTestId("bet-balance").filter({ visible: true }).first();
    await expect(bal).toBeVisible({ timeout: 30_000 });
    const num = (await bal.locator("strong").innerText()).trim();
    const n = Number(num.replace(/\D/g, ""));
    expect(n).toBeGreaterThan(999);
    expect(num).toBe(new Intl.NumberFormat("ca").format(n));
    expect(num).not.toContain(",");
  });
});
