import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * PC pantalla (v173): a escriptori (≥1024 px) la taula aprofita la pantalla.
 * Al meu torn: carta pròpia ≥ clamp(160px,26vh,280px), rivals ≥ 96 px (v174), dock min(90vw,880px), tapet min(96vw,1600px),
 * cap requadre a la carta pròpia, cap encavalcament, Demanar i Plantar-se visibles. A 390×844 res no canvia.
 * Captures només a /workspace/pc-pantalla-v173/ (mai al repo).
 */
const SIZES = [
  { tag: "1280x800", width: 1280, height: 800 },
  { tag: "1440x900", width: 1440, height: 900 },
  { tag: "1920x1080", width: 1920, height: 1080 },
  { tag: "390x844", width: 390, height: 844 },
] as const;
const SHOTS = process.env.PC_SHOTS_DIR || "/workspace/pc-pantalla-v173";
/** Mesurat a main (8414dce, v172) a 390×844 abans del canvi. */
const MOBILE_BASELINE: Record<string, number> = { ownCardH: 359, feltW: 382, dockW: 380, seatW: 380, seatT: 160, dockT: 633 };

async function seed(page: Page, id: string) {
  await seedE2eSession(page, id);
  await page.addInitScript((pid) => {
    if (sessionStorage.getItem("__pcp_seeded")) return;
    sessionStorage.setItem("__pcp_seeded", "1");
    localStorage.setItem("setimig_player_id", pid);
    localStorage.setItem("setimig_player_name", "Pantalla");
    localStorage.setItem("setimig_onboarding_v1", "1");
    localStorage.setItem("setimig_interactive_tutorial_v1", "1");
    localStorage.setItem("setimig.locale", "ca");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
  }, id);
}

type Box = { l: number; t: number; r: number; b: number };
const inter = (a: Box, b: Box) => Math.max(0, Math.min(a.r, b.r) - Math.max(a.l, b.l)) * Math.max(0, Math.min(a.b, b.b) - Math.max(a.t, b.t));

async function measure(page: Page) {
  return page.evaluate(() => {
    const box = (el: Element) => {
      const r = el.getBoundingClientRect();
      return { l: r.left, t: r.top, r: r.right, b: r.bottom };
    };
    const vis = (el: Element) => {
      const r = el.getBoundingClientRect();
      return r.width > 1 && r.height > 1 && getComputedStyle(el).visibility !== "hidden" && !el.closest("[aria-hidden=true]");
    };
    const seatEls = [...document.querySelectorAll("[data-testid=game-seat-grid] [data-seat-player]")].filter(vis);
    const seats = seatEls.map(box);
    const rivalCardH = Math.min(
      ...seatEls.flatMap((s) => [...s.querySelectorAll(".spanish-card")].filter(vis).map((c) => c.getBoundingClientRect().height)),
      9999
    );
    const ownCards = [...document.querySelectorAll("[data-testid=focus-mine] .spanish-card")].filter(vis).map(box);
    const own = ownCards.length
      ? { l: Math.min(...ownCards.map((c) => c.l)), t: Math.min(...ownCards.map((c) => c.t)), r: Math.max(...ownCards.map((c) => c.r)), b: Math.max(...ownCards.map((c) => c.b)) }
      : null;
    const framed = [...document.querySelectorAll("[data-testid=local-player-seat], [data-testid=local-player-seat] .desktop-hand-panel")].some((el) => {
      const cs = getComputedStyle(el);
      return ["Top", "Right", "Bottom", "Left"].some((s) => parseFloat(cs.getPropertyValue(`border-${s.toLowerCase()}-width`)) > 0 && cs.getPropertyValue(`border-${s.toLowerCase()}-style`) !== "none" && !/rgba\(.*,\s*0\)$/.test(cs.getPropertyValue(`border-${s.toLowerCase()}-color`)))
        || (cs.outlineStyle !== "none" && parseFloat(cs.outlineWidth) > 0);
    });
    const dockEl = document.querySelector("[data-testid=action-dock]");
    const felt = document.querySelector(".game-table-root");
    const seat = document.querySelector("[data-testid=local-player-seat]");
    const buttons = [...document.querySelectorAll("[data-testid=action-dock] button")].filter(vis).map(box);
    return {
      seats,
      rivalCardH: rivalCardH === 9999 ? 0 : rivalCardH,
      own,
      ownCardH: ownCards.length ? ownCards[0].b - ownCards[0].t : 0,
      framed,
      dock: dockEl ? box(dockEl) : null,
      buttons,
      feltW: felt ? felt.getBoundingClientRect().width : 0,
      seatBox: seat ? box(seat) : null,
      vw: innerWidth,
      vh: innerHeight,
    };
  });
}

for (const vp of SIZES) {
  const desktop = vp.width >= 1024;
  test(`pc pantalla v173 · ${vp.tag}`, async ({ page }) => {
    test.setTimeout(200_000);
    await page.setViewportSize({ width: vp.width, height: vp.height });
    await seed(page, e2ePoolId());
    await page.goto("/");
    await page.getByTestId("lobby-context").click();
    await page.getByTestId("ai-bot-count-3").click();
    await page.getByRole("button", { name: "Començar" }).click();
    await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 60_000 });

    let measured = false;
    const deadline = Date.now() + 150_000;
    while (Date.now() < deadline && !measured) {
      const betBtn = page.getByTestId("bet-confirm");
      if ((await betBtn.isVisible({ timeout: 300 }).catch(() => false)) && (await betBtn.isEnabled().catch(() => false))) {
        await betBtn.click({ timeout: 2_000 }).catch(() => {});
        await page.waitForTimeout(300);
        continue;
      }
      const stand = page.getByTestId("action-stand");
      if ((await stand.isVisible({ timeout: 300 }).catch(() => false)) && (await stand.isEnabled().catch(() => false))) {
        await page.waitForTimeout(900);
        await expect(page.getByTestId("action-hit")).toBeVisible();
        await expect(stand).toBeVisible();
        const m = await measure(page);
        await page.screenshot({ path: `${SHOTS}/${vp.tag}.png` }).catch(() => {});
        const r = (n: number) => Math.round(n);
        const sizes = {
          ownCardH: r(m.ownCardH), rivalCardH: r(m.rivalCardH), feltW: r(m.feltW),
          dockW: m.dock ? r(m.dock.r - m.dock.l) : 0,
          seatW: m.seatBox ? r(m.seatBox.r - m.seatBox.l) : 0,
          seatT: m.seatBox ? r(m.seatBox.t) : 0,
          dockT: m.dock ? r(m.dock.t) : 0,
        };
        console.log(`[pc-pantalla-v173] ${vp.tag} ${JSON.stringify(sizes)}`);
        expect(m.own, "mà pròpia").not.toBeNull();
        if (desktop) {
          // v184: a ≥821 px d'alt la carta pròpia és clamp(128px, 100vh − 780px, 280px) perquè els seients no quedin
          // v186: chrome d'una fila; ≥821 → clamp(128, 100vh-640, 280); ≤820 → clamp(128, 100vh-560, 210).
          const ownMin = vp.height >= 821 ? Math.min(280, Math.max(128, vp.height - 640)) : Math.min(210, Math.max(128, vp.height - 560));
          expect(m.ownCardH, "carta pròpia").toBeGreaterThanOrEqual(ownMin - 2);
          expect(m.rivalCardH, "cartes rivals").toBeGreaterThanOrEqual(95);
          expect(Math.abs(sizes.dockW - Math.min(vp.width * 0.9, 880)), "dock").toBeLessThanOrEqual(24);
          expect(Math.abs(sizes.feltW - Math.min(vp.width * 0.96, 1600)), "tapet").toBeLessThanOrEqual(24);
          expect(sizes.seatW, "zona pròpia no fixada a 672").toBeGreaterThan(680);
          expect(m.framed, "sense requadre a la carta pròpia").toBe(false);
          const own = m.own!;
          for (let i = 0; i < m.seats.length; i++) expect(inter(m.seats[i], own), `seient ${i}/mà pròpia`).toBe(0);
          if (m.dock) expect(inter(m.dock, own), "dock/mà pròpia").toBe(0);
          for (const b of m.buttons) for (let i = 0; i < m.seats.length; i++) expect(inter(b, m.seats[i]), `botó/seient ${i}`).toBe(0);
          expect(own.b <= m.vh + 0.5 && own.t >= 0, "mà pròpia sense retallar").toBe(true);
        } else if (!process.env.PC_RECORD_BASELINE) {
          for (const [k, v] of Object.entries(MOBILE_BASELINE)) {
            expect(Math.abs((sizes as Record<string, number>)[k] - v), `390 sense canvis: ${k}`).toBeLessThanOrEqual(2);
          }
        }
        measured = true;
      }
      await page.waitForTimeout(150);
    }
    expect(measured, "torn propi mesurat").toBe(true);
  });
}
