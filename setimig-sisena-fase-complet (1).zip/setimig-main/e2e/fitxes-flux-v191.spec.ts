import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * v191 · fitxes flux_var1 (flag «fitxes», encès per defecte): les fitxes volen dels seients al pot durant
 * l'aposta i la banca paga (pila al guanyador amb «+N») o s'emporta les fitxes. Capa sense punter, sense
 * desbordament; amb moviment reduït, sense vols (només fosa). Partida solo amb 3 bots.
 * V191_CLIPS=1 grava vídeo a /workspace/setimig/v191_fitxes/.
 */
type Obs = { chips: number; values: string[]; deltas: string[]; overflowX: number; outside: number; pe: string[]; flights: number; layerFlag: string };

async function startSolo(page: Page, opts: { reduced?: boolean; query?: string } = {}) {
  if (opts.reduced) await page.emulateMedia({ reducedMotion: "reduce" });
  await seedE2eSession(page, e2ePoolId());
  await page.addInitScript(() => {
    if (sessionStorage.getItem("v191_init") !== "1") {
      sessionStorage.setItem("v191_init", "1");
      for (const k of ["setimig_onboarding_v1", "setimig_interactive_tutorial_v1", "setimig_table_tutorial_v1"]) localStorage.setItem(k, "1");
      localStorage.setItem("setimig.locale", "ca");
      localStorage.setItem("setimig_player_name", "Test Fitxes");
      localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
      sessionStorage.setItem("setimig_intro_launch_v1", "1");
    }
    const o: Obs = { chips: 0, values: [], deltas: [], overflowX: 0, outside: 0, pe: [], flights: 0, layerFlag: "" };
    (window as unknown as { __v191: Obs }).__v191 = o;
    const mo = new MutationObserver((muts) => {
      o.overflowX = Math.max(o.overflowX, document.documentElement.scrollWidth - innerWidth);
      const layer = document.querySelector<HTMLElement>('[data-testid="table-fx-layer"]');
      if (layer) o.layerFlag = layer.dataset.fitxes ?? "";
      for (const m of muts)
        m.addedNodes.forEach((n) => {
          if (!(n instanceof HTMLElement)) return;
          if (n.dataset.testid === "fx-flow-chip") {
            o.chips++;
            o.values.push(n.textContent ?? "");
            o.pe.push(getComputedStyle(n.parentElement!).pointerEvents);
            setTimeout(() => {
              const r = n.getBoundingClientRect();
              if (n.isConnected && (r.left < -2 || r.right > innerWidth + 2 || r.top < -2 || r.bottom > innerHeight + 2)) o.outside++;
              if (n.getAnimations().some((a) => /translate\([^)]*px/.test(JSON.stringify((a.effect as KeyframeEffect).getKeyframes())) && (a.effect as KeyframeEffect).getKeyframes().length > 2)) o.flights++;
            }, 60);
          }
          if (n.dataset.testid === "fx-chip-delta" && n.dataset.flow) setTimeout(() => o.deltas.push(n.textContent ?? ""), 2_500);
        });
    });
    const start = () => mo.observe(document.body, { childList: true, subtree: true });
    if (document.body) start();
    else document.addEventListener("DOMContentLoaded", start);
  });
  await page.goto(`/${opts.query ?? ""}`);
  const skip = page.getByTestId("interactive-tutorial-skip");
  await expect(page.getByTestId("lobby-context").or(skip).first()).toBeVisible({ timeout: 45_000 });
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  await page.getByTestId("ai-bot-count-3").click();
  await page.getByTestId("ai-bot-picker-start").click();
}

const obs = (page: Page) => page.evaluate(() => (window as unknown as { __v191: Obs }).__v191);

async function playUntil(page: Page, done: (o: Obs) => boolean, ms = 100_000) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    const o = await obs(page);
    if (done(o)) return o;
    for (const id of ["bet-confirm", "action-stand", "settlement-next-hand"]) {
      const b = page.getByTestId(id).filter({ visible: true }).first();
      if (await b.isVisible().catch(() => false)) await b.click({ timeout: 2_000 }).catch(() => {});
    }
    await page.waitForTimeout(250);
  }
  return obs(page);
}

if (process.env.V191_CLIPS) test.use({ video: { mode: "on", size: { width: 390, height: 844 } } });

test("clip 390: guanya i perd (V191_CLIPS=1)", async ({ page }) => {
  test.skip(!process.env.V191_CLIPS, "només per gravar");
  test.setTimeout(240_000);
  await page.setViewportSize({ width: 390, height: 844 });
  await startSolo(page);
  const o = await playUntil(page, (x) => x.deltas.some((d) => d.startsWith("+")) && x.deltas.some((d) => d.startsWith("−")), 200_000);
  await page.waitForTimeout(3_000);
  console.log("deltes", o.deltas.join(" "));
});

for (const vp of [{ width: 390, height: 844 }, { width: 1280, height: 720 }]) {
  test.describe(`v191 fitxes ${vp.width}×${vp.height}`, () => {
    test.use({ viewport: vp });

    test("per defecte: fitxes al pot i pagament, sense retallar", async ({ page }) => {
      await startSolo(page);
      const o = await playUntil(page, (x) => x.chips >= 4 && x.deltas.length >= 1);
      expect(o.layerFlag).toBe("on");
      expect(o.chips, "fitxes a la taula").toBeGreaterThanOrEqual(4);
      expect(o.values.every((v) => /\d/.test(v)), "valor imprès").toBe(true);
      expect(o.deltas.some((d) => /^[+−]/.test(d)), "+N / −N").toBe(true);
      expect(o.flights, "vols corbats").toBeGreaterThan(0);
      expect(o.pe.every((p) => p === "none"), "capa sense punter").toBe(true);
      expect(o.overflowX).toBeLessThanOrEqual(0);
      expect(o.outside, "cap fitxa fora de pantalla").toBe(0);
    });

    test("moviment reduït: sense vols", async ({ page }) => {
      await startSolo(page, { reduced: true });
      const o = await playUntil(page, (x) => x.chips >= 4);
      expect(o.chips).toBeGreaterThanOrEqual(4);
      expect(o.flights, "cap vol amb moviment reduït").toBe(0);
      expect(o.overflowX).toBeLessThanOrEqual(0);
    });
  });
}

test("?flag=none apaga les fitxes", async ({ page }) => {
  await startSolo(page, { query: "?flag=none" });
  const o = await playUntil(page, (x) => x.layerFlag !== "", 40_000);
  await page.waitForTimeout(6_000);
  const o2 = await obs(page);
  expect(o.layerFlag).toBe("off");
  expect(o2.chips).toBe(0);
});
