import { expect, test } from "@playwright/test";
import { startAiGameFromLobby } from "./helpers/aiLobby";

const MOBILE = { width: 390, height: 844 } as const;

async function enterLobby(page: import("@playwright/test").Page, name: string, playerId: string) {
  await page.addInitScript(
    ({ id, n }: { id: string; n: string }) => {
      localStorage.setItem("setimig_player_id", id);
      localStorage.setItem("setimig_player_name", n);
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem(
        "setimig_age_gate",
        JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
      );
    },
    { id: playerId, n: name }
  );
  await page.goto("/");
  const input = page.getByPlaceholder("El teu nom");
  if (await input.isVisible().catch(() => false)) {
    await input.fill(name);
    await page.getByRole("button", { name: "Entrar al lobby" }).click();
  }
  await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 30_000 });
}

test("PAS 13 — offline reload restores local IA hand", async ({ page, context }) => {
  test.setTimeout(180_000);
  await page.setViewportSize(MOBILE);
  await enterLobby(page, "Pas13Reload", "pas13reload01");
  await startAiGameFromLobby(page, 2);
  await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 45_000 });

  const betBtn = page.getByTestId("bet-confirm");
  if (await betBtn.isVisible().catch(() => false)) {
    await betBtn.click();
  }

  await expect(page.getByTestId("status-pill").first()).toBeVisible({ timeout: 30_000 });
  const phaseBefore = await page.getByTestId("status-pill").first().innerText();

  await context.setOffline(true);
  await page.reload({ waitUntil: "domcontentloaded" });
  await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 45_000 });
  await expect(page.getByTestId("status-pill").first()).toBeVisible();
  const phaseAfter = await page.getByTestId("status-pill").first().innerText();
  expect(phaseAfter.length).toBeGreaterThan(0);
  expect(phaseAfter).toBe(phaseBefore);
});
