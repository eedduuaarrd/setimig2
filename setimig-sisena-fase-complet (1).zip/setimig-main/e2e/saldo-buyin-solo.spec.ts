import { expect, test, type Page, type WebSocketRoute } from "@playwright/test";

/**
 * #209 (client): amb saldo 0 el servidor respon INSUFFICIENT_BALANCE en seure a una solo normal.
 * El client no mostra el toast genèric: ofereix «Jugar en pràctica», que entra en mode pràctica.
 *
 * El servidor de main encara no té #209, així que el test simula el saldo 0 (/api/balance) i la
 * resposta del servidor (game_error) interceptant el WebSocket de socket.io. La sala de pràctica
 * la crea el servidor real.
 */

const MOBILE = { width: 390, height: 844 } as const;

async function enterLobby(page: Page, name: string, playerId: string) {
  await page.addInitScript(
    ({ id, n }: { id: string; n: string }) => {
      localStorage.setItem("setimig.locale", "en");
      localStorage.setItem("setimig_player_id", id);
      localStorage.setItem("setimig_player_name", n);
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem(
        "setimig_age_gate",
        JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
      );
    },
    { id: playerId, n: name }
  );
  await page.goto("/");
  await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 30_000 });
}

test("saldo 0: INSUFFICIENT_BALANCE ofereix la pràctica i hi entra", async ({ page }) => {
  test.setTimeout(120_000);
  await page.setViewportSize(MOBILE);

  await page.route("**/api/balance**", (route) =>
    route.fulfill({
      status: 200,
      contentType: "application/json",
      body: JSON.stringify({
        chips: 0,
        freeClaim: { claimable: false, nextClaimAt: Date.now() + 3_600_000, secondsUntilClaim: 3_600, amount: 500 },
      }),
    })
  );

  const joins: string[] = [];
  await page.routeWebSocket(/\/socket\.io\//, (ws: WebSocketRoute) => {
    const server = ws.connectToServer();
    ws.onMessage((message) => {
      const text = typeof message === "string" ? message : "";
      if (text.startsWith("42") && text.includes('"join_solo_room"')) {
        joins.push(text);
        if (!text.includes('"practiceMode":true')) {
          ws.send(
            `42${JSON.stringify([
              "game_error",
              {
                message: "Saldo insuficient (simulat)",
                code: "INSUFFICIENT_BALANCE",
                required: 0,
                balance: 0,
              },
            ])}`
          );
          return;
        }
      }
      server.send(message);
    });
  });

  await enterLobby(page, "BuyIn", "buyinzero0001");
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  await page.getByTestId("ai-bot-count-1").click();
  await page.getByTestId("ai-bot-picker-start").click();

  const dialog = page.getByTestId("no-balance-dialog");
  await expect(dialog).toBeVisible({ timeout: 15_000 });
  await expect(dialog.getByRole("heading", { name: "Your balance is 0" })).toBeVisible();
  await expect(page.getByText("Saldo insuficient (simulat)")).toHaveCount(0);
  const practice = page.getByTestId("no-balance-practice");
  await expect(practice).toHaveText("Play in practice mode");
  await expect(practice).toBeFocused();
  const box = await practice.boundingBox();
  expect(box?.height ?? 0).toBeGreaterThanOrEqual(44);
  expect(joins).toHaveLength(1);
  // #210: «Començar» és una partida nova explícita.
  expect(joins[0]).toContain('"intent":"new"');

  await practice.click();
  await expect(dialog).toHaveCount(0);
  await expect.poll(() => joins.length, { timeout: 10_000 }).toBe(2);
  expect(joins[1]).toContain('"practiceMode":true');

  // A la taula de pràctica: fitxes de pràctica i cap avís de compra d'entrada.
  await expect(page.getByTestId("bet-balance")).toContainText("Practice chips", { timeout: 30_000 });
  await expect(page.getByText(/Buy-in of/)).toHaveCount(0);
});

test("saldo 0: «Close» tanca l'oferta i es queda al lobby", async ({ page }) => {
  test.setTimeout(90_000);
  await page.setViewportSize(MOBILE);
  await page.routeWebSocket(/\/socket\.io\//, (ws: WebSocketRoute) => {
    const server = ws.connectToServer();
    ws.onMessage((message) => {
      const text = typeof message === "string" ? message : "";
      if (text.startsWith("42") && text.includes('"join_solo_room"')) {
        ws.send(`42${JSON.stringify(["game_error", { message: "x", code: "INSUFFICIENT_BALANCE", required: 0, balance: 0 }])}`);
        return;
      }
      server.send(message);
    });
  });
  await enterLobby(page, "BuyInClose", "buyinzero0002");
  await page.getByTestId("lobby-context").click();
  await page.getByTestId("ai-bot-count-1").click();
  await page.getByTestId("ai-bot-picker-start").click();
  await expect(page.getByTestId("no-balance-dialog")).toBeVisible({ timeout: 15_000 });
  await page.getByTestId("no-balance-close").click();
  await expect(page.getByTestId("no-balance-dialog")).toHaveCount(0);
  await expect(page.getByTestId("lobby-main")).toBeVisible();
});

test("#210 SOLO_ACTIVE_ELSEWHERE: avís clar en lloc del toast genèric", async ({ page }) => {
  test.setTimeout(90_000);
  await page.setViewportSize(MOBILE);
  const serverMessage = "Ja tens aquesta partida oberta en un altre dispositiu o pestanya.";
  await page.routeWebSocket(/\/socket\.io\//, (ws: WebSocketRoute) => {
    const server = ws.connectToServer();
    ws.onMessage((message) => {
      const text = typeof message === "string" ? message : "";
      if (text.startsWith("42") && text.includes('"join_solo_room"')) {
        ws.send(`42${JSON.stringify(["game_error", { message: serverMessage, code: "SOLO_ACTIVE_ELSEWHERE" }])}`);
        return;
      }
      server.send(message);
    });
  });
  await enterLobby(page, "Elsewhere", "buyinelse0001");
  await page.getByTestId("lobby-context").click();
  await page.getByTestId("ai-bot-count-1").click();
  await page.getByTestId("ai-bot-picker-start").click();
  const dialog = page.getByTestId("solo-elsewhere-dialog");
  await expect(dialog).toBeVisible({ timeout: 15_000 });
  // Client en anglès: el missatge del servidor (en català) es mostra amb el text d'i18n.
  await expect(dialog).toContainText("This game is already open in another tab or device.");
  await expect(page.getByTestId("no-balance-practice")).toHaveCount(0);
  await page.getByTestId("solo-elsewhere-close").click();
  await expect(dialog).toHaveCount(0);
  await expect(page.getByTestId("lobby-main")).toBeVisible();
});
