/**
 * v200 · Reprova login QA 1/11: m-08 (sense token però amb galeta → POST /api/player-session recupera la
 * sessió abans de /login), d-09 (compte enrere «13 min 19 s», no «13:19») i m-04/m-09 (idioma del navegador
 * a tota l'app si no n'hi ha cap de desat, sense desar-lo).
 */
import { blockSocketIoCtx, mockLoginSession, openLoginEmail } from "./helpers/loginSession.ts";
import { expect, test, type Browser, type BrowserContext } from "@playwright/test";

const PID = "loginv200-player01";
const TOKEN = "loginv200.token";
const AGE_OK = () => JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" });

async function newCtx(
  browser: Browser,
  opts: { session?: boolean; locale?: string; storedLocale?: string | null } = {}
): Promise<BrowserContext> {
  const ctx = await browser.newContext({
    viewport: { width: 390, height: 844 },
    locale: opts.locale ?? "en-US",
    colorScheme: "dark",
    storageState: { cookies: [], origins: [] },
  });
  await ctx.addInitScript(
    ({ session, age, pid, token, storedLocale }) => {
      if (sessionStorage.getItem("v200_seeded") === "1") return;
      sessionStorage.setItem("v200_seeded", "1");
      if (storedLocale) localStorage.setItem("setimig.locale", storedLocale);
      localStorage.setItem("setimig_age_gate", age);
      localStorage.setItem("setimig_home_intro_v1", "1");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_player_name", "Edu");
      if (session) {
        localStorage.setItem("setimig_player_id", pid);
        localStorage.setItem("setimig_player_token", token);
      }
    },
    { session: !!opts.session, age: AGE_OK(), pid: PID, token: TOKEN, storedLocale: opts.storedLocale === undefined ? "en" : opts.storedLocale }
  );
  await mockLoginSession(ctx, PID, TOKEN);
  await blockSocketIoCtx(ctx);
  return ctx;
}

const lobby = (page: import("@playwright/test").Page) => page.locator("button.header-profile").first();

test("m-08 · sense token però amb galeta vàlida: recupera la sessió i no va a /login", async ({ browser }) => {
  const ctx = await newCtx(browser);
  const calls: (string | undefined)[] = [];
  await ctx.route("**/api/player-session", (route) => {
    calls.push(route.request().headers()["authorization"]);
    // La galeta HttpOnly la valida el servidor; aquí simulem que és vàlida.
    return route.fulfill({ json: { playerId: PID, playerToken: TOKEN } });
  });
  const page = await ctx.newPage();
  await page.goto("/");
  await expect(lobby(page)).toBeVisible({ timeout: 30_000 });
  expect(new URL(page.url()).pathname).not.toBe("/login");
  expect(calls[0]).toBeUndefined();
  expect(await page.evaluate(() => localStorage.getItem("setimig_player_token"))).toBe(TOKEN);
  expect(await page.evaluate(() => localStorage.getItem("setimig_player_id"))).toBe(PID);
  await ctx.close();
});

test("m-08 · sense token i sense galeta (401): va a /login com sempre", async ({ browser }) => {
  const ctx = await newCtx(browser);
  const page = await ctx.newPage();
  await page.goto("/");
  await expect(page.getByTestId("login-page")).toBeVisible({ timeout: 30_000 });
  expect(new URL(page.url()).pathname).toBe("/login");
  expect(await page.evaluate(() => localStorage.getItem("setimig_player_token"))).toBeNull();
  await ctx.close();
});

for (const [retryAfter, re] of [
  [799, /13 min 1\d s/],
  [45, /4\d s/],
] as const) {
  test(`d-09 · límit ${retryAfter}s: «${re.source}», sense format de rellotge`, async ({ browser }) => {
    const ctx = await newCtx(browser, { storedLocale: "ca" });
    await ctx.route("**/api/auth/email/start", (route) =>
      route.fulfill({ status: 429, json: { error: "x", code: "RATE_LIMIT", retryAfter } })
    );
    const page = await ctx.newPage();
    await page.goto("/login");
    await openLoginEmail(page);
    await page.getByTestId("login-email-input").fill("edu@example.com");
    await page.getByTestId("login-email-submit").click();
    const err = page.getByTestId("login-error");
    await expect(err).toContainText(re);
    await expect(err).toContainText("d'aquí a");
    expect(await err.textContent()).not.toMatch(/\d:\d\d/);
    await ctx.close();
  });
}

test("m-04/m-09 · ca-ES sense preferència: el lobby surt en català i no es desa", async ({ browser }) => {
  const ctx = await newCtx(browser, { session: true, locale: "ca-ES", storedLocale: null });
  const page = await ctx.newPage();
  await page.goto("/");
  await expect(lobby(page)).toBeVisible({ timeout: 30_000 });
  await expect.poll(() => page.evaluate(() => document.documentElement.lang)).toBe("ca");
  expect(await page.evaluate(() => localStorage.getItem("setimig.locale"))).toBeNull();
  await ctx.close();
});

test("m-04/m-09 · la preferència desada guanya al navegador", async ({ browser }) => {
  const ctx = await newCtx(browser, { session: true, locale: "ca-ES", storedLocale: "en" });
  const page = await ctx.newPage();
  await page.goto("/");
  await expect(lobby(page)).toBeVisible({ timeout: 30_000 });
  await expect.poll(() => page.evaluate(() => document.documentElement.lang)).toBe("en");
  await ctx.close();
});
