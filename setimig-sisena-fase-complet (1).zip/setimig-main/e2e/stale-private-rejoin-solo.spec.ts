import { expect, test } from "@playwright/test";
import { startAiGameFromLobby } from "./helpers/aiLobby";

const MOBILE = { width: 390, height: 844 } as const;
const STALE_CODE = "STAL";

async function enterLobby(page: import("@playwright/test").Page, name: string, playerId: string) {
  await page.addInitScript(
    ({ id, n }: { id: string; n: string }) => {
      localStorage.setItem("setimig_player_id", id);
      localStorage.setItem("setimig_player_name", n);
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem(
        "setimig_age_gate",
        JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
      );
    },
    { id: playerId, n: name }
  );
  await page.goto("/");
  const input = page.getByPlaceholder("El teu nom");
  if (await input.isVisible().catch(() => false)) {
    await input.fill(name);
    await page.getByRole("button", { name: "Entrar al lobby" }).click();
  }
  await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 30_000 });
}

/** Mobile hides TableStatusPill during betting/turn; any of these means we are still in-table. */
function inTableSurface(page: import("@playwright/test").Page) {
  return page
    .getByTestId("status-pill")
    .or(page.getByTestId("bet-confirm"))
    .or(page.getByRole("button", { name: /Plantar-me|Demanar carta/i }));
}

test("stale private rejoin code during solo reconnect does not toast or drop table", async ({
  page,
  context,
}) => {
  test.setTimeout(180_000);
  await page.setViewportSize(MOBILE);
  await enterLobby(page, "StalePriv", "stalepriv01");
  await startAiGameFromLobby(page, 2);
  await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 45_000 });
  await expect(inTableSurface(page).first()).toBeVisible({ timeout: 30_000 });

  await page.evaluate((code) => {
    localStorage.setItem("setimig_private_rejoin_code", code);
    const seats = { [code]: "stale-seat-token-abcdefghij" };
    localStorage.setItem("setimig_private_seats", JSON.stringify(seats));
  }, STALE_CODE);

  await context.setOffline(true);
  await page.waitForTimeout(1_500);
  await context.setOffline(false);

  await expect(page.getByText("Taula no trobada.")).toHaveCount(0);
  await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 15_000 });
  await expect(inTableSurface(page).first()).toBeVisible();
});
