import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * v184 · Captura de l'Edu (PC): la franja de dalt («Sessió: N mans · fitxes · Nova sessió» + «Accions · Historial»)
 * tapava la part superior dels seients dels rivals i de la banca. Després de la primera mà (quan la barra de sessió
 * ja hi és) es mesura: cap seient (rivals + banca) no talla la franja ni queda tapat per cap capa de dalt;
 * sense desbordament horitzontal; 390 px segueix sense desbordar.
 */
const SIZES = [
  { tag: "1024x700", width: 1024, height: 700, desktop: true },
  { tag: "1024x600", width: 1024, height: 600, desktop: true },
  { tag: "1280x700", width: 1280, height: 700, desktop: true },
  { tag: "1280x800", width: 1280, height: 800, desktop: true },
  { tag: "1440x900", width: 1440, height: 900, desktop: true },
  { tag: "1920x1080", width: 1920, height: 1080, desktop: true },
  { tag: "1024x538", width: 1024, height: 538, desktop: true },
  { tag: "390x844", width: 390, height: 844, desktop: false },
] as const;
const SHOTS = process.env.FRANJA_SHOTS_DIR || "/workspace/franja-seients";

async function seed(page: Page, id: string) {
  await seedE2eSession(page, id);
  await page.addInitScript((pid) => {
    if (sessionStorage.getItem("__fs_seeded")) return;
    sessionStorage.setItem("__fs_seeded", "1");
    localStorage.setItem("setimig_player_id", pid);
    localStorage.setItem("setimig_player_name", "Franja");
    localStorage.setItem("setimig_onboarding_v1", "1");
    localStorage.setItem("setimig_interactive_tutorial_v1", "1");
    localStorage.setItem("setimig.locale", "ca");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
  }, id);
}

type Box = { l: number; t: number; r: number; b: number };
const inter = (a: Box, b: Box) => Math.max(0, Math.min(a.r, b.r) - Math.max(a.l, b.l)) * Math.max(0, Math.min(a.b, b.b) - Math.max(a.t, b.t));

async function measure(page: Page) {
  return page.evaluate(() => {
    const box = (el: Element) => {
      const r = el.getBoundingClientRect();
      return { l: r.left, t: r.top, r: r.right, b: r.bottom };
    };
    const vis = (el: Element) => {
      const r = el.getBoundingClientRect();
      const cs = getComputedStyle(el);
      return r.width > 1 && r.height > 1 && cs.visibility !== "hidden" && cs.display !== "none" && !el.closest("[aria-hidden=true]");
    };
    const seatEls = [...document.querySelectorAll("[data-seat-player]")].filter(vis);
    const union = (el: Element) => {
      const u = box(el);
      el.querySelectorAll("*").forEach((c) => {
        const r = c.getBoundingClientRect();
        if (r.width < 1 || r.height < 1) return;
        const cs = getComputedStyle(c);
        if (cs.visibility === "hidden" || cs.position === "fixed") return;
        u.l = Math.min(u.l, r.left); u.t = Math.min(u.t, r.top); u.r = Math.max(u.r, r.right); u.b = Math.max(u.b, r.bottom);
      });
      return u;
    };
    const seats = seatEls.map(union);
    const bars = [
      ...document.querySelectorAll(".game-session-summary:not(.game-session-summary-placeholder), .game-activity-disclosure summary"),
    ]
      .filter(vis)
      .map(box);
    // Què hi ha realment a sobre de la part de dalt de cada seient (capes opaques que el tapen).
    const covered: string[] = [];
    seatEls.forEach((el, i) => {
      const r = union(el);
      for (const fx of [0.25, 0.5, 0.75]) {
        const x = r.l + (r.r - r.l) * fx;
        const y = r.t + 4;
        if (y < 0 || y > innerHeight) continue;
        const hit = document.elementFromPoint(x, y);
        const top = hit?.closest(".game-session-summary, .game-activity-disclosure, header, [data-testid=game-top-strip]");
        if (hit && top && !top.contains(el)) covered.push(`${i}@${Math.round(x)},${Math.round(y)}:${hit.tagName}.${String((hit as HTMLElement).className).slice(0, 80)}`);
      }
    });
    // Retall: algun avantpassat amb overflow que comença per sota del cim del seient (la capçalera el talla).
    const clipped: string[] = [];
    seatEls.forEach((el, i) => {
      const u = union(el);
      for (let a = el.parentElement; a && a !== document.body; a = a.parentElement) {
        const cs = getComputedStyle(a);
        if (cs.overflowY === "visible" && cs.overflowX === "visible" && cs.clipPath === "none" && cs.maskImage === "none") continue;
        const r = a.getBoundingClientRect();
        if (r.top > u.t + 1) clipped.push(`${i}:${String(a.className).split(" ")[0]} dèficit=${Math.round(r.top - u.t)}`);
      }
    });
    return { seats, bars, covered, clipped, vw: innerWidth, vh: innerHeight, scrollX: document.documentElement.scrollWidth - innerWidth };
  });
}

for (const vp of SIZES) {
  test(`franja de dalt no tapa els seients (${vp.tag})`, async ({ page }) => {
    test.setTimeout(240_000);
    await page.setViewportSize({ width: vp.width, height: vp.height });
    await seed(page, e2ePoolId());
    await page.goto("/");
    await page.getByTestId("lobby-context").click();
    await page.getByTestId("ai-bot-count-3").click();
    await page.getByRole("button", { name: "Començar" }).click();
    await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 60_000 });

    // Es mesura durant tota la primera mà (torns dels rivals, el meu torn i la banca) fins a la mà següent.
    let measured = false;
    let stood = false;
    let samples = 0;
    const problems = new Set<string>();
    const deadline = Date.now() + 200_000;
    while (Date.now() < deadline && !measured) {
      const betBtn = page.getByTestId("bet-confirm");
      const stand = page.getByTestId("action-stand");
      const canBet = (await betBtn.isVisible().catch(() => false)) && (await betBtn.isEnabled().catch(() => false));
      const canStand = (await stand.isVisible().catch(() => false)) && (await stand.isEnabled().catch(() => false));
      if (canBet && stood) {
        measured = true;
        break;
      }
      if (canBet) { await betBtn.click({ timeout: 2_000 }).catch(() => {}); await page.waitForTimeout(400); continue; }
      const m = await measure(page).catch(() => null);
      if (m) {
        samples++;
        if (m.scrollX > 0) problems.add(`desbordament ${m.scrollX}`);
        if (vp.desktop) {
          m.seats.forEach((s, i) => {
            if (s.t < 0 || s.l < 0 || s.r > m.vw + 0.5) problems.add(`seient ${i} fora ${JSON.stringify(s)}`);
            m.bars.forEach((b) => { if (inter(s, b) > 0) problems.add(`seient ${i} × franja`); });
          });
          m.clipped.forEach((c) => problems.add(`retall ${c}`));
          m.covered.forEach((c) => problems.add(`tapat ${c}`));
        }
      }
      if (canStand) {
        await page.waitForTimeout(500);
        await page.screenshot({ path: `${SHOTS}/${vp.tag}-torn.png` }).catch(() => {});
        await stand.click({ timeout: 2_000 }).catch(() => {});
        stood = true;
      } else if (samples % 8 === 3) {
        await page.screenshot({ path: `${SHOTS}/${vp.tag}-rival.png` }).catch(() => {});
      }
      await page.waitForTimeout(250);
    }
    console.log(`[franja] ${vp.tag} mostres=${samples} ${JSON.stringify([...problems].slice(0, 12))}`);
    expect(samples, "mostres durant la mà").toBeGreaterThan(5);
    expect([...problems], "la franja de dalt no tapa ni retalla cap seient").toEqual([]);
    expect(measured, "mà sencera mesurada").toBe(true);
  });
}
