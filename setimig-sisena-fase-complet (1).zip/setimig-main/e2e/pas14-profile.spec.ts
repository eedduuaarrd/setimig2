import { expect, test } from "@playwright/test";
import fs from "node:fs";
import path from "node:path";

const MOBILE = { width: 390, height: 844 } as const;

function screenshotDir(): string {
  const candidates = [
    "/cursor/stores/self/media/pas14",
    "/cursor/stores/bc-9b0df142-722d-5c8c-bf32-7c74b1eccf10/media/pas14",
    path.join(process.cwd(), "media/pas14"),
  ];
  for (const dir of candidates) {
    try {
      fs.mkdirSync(dir, { recursive: true });
      return dir;
    } catch {
      /* try next */
    }
  }
  return candidates[candidates.length - 1];
}

async function enterLobby(page: import("@playwright/test").Page, name: string, playerId: string) {
  await page.addInitScript(
    ({ id, n }: { id: string; n: string }) => {
      localStorage.setItem("setimig_player_id", id);
      localStorage.setItem("setimig_player_name", n);
    },
    { id: playerId, n: name }
  );
  await page.goto("/");
  const input = page.getByPlaceholder("El teu nom");
  if (await input.isVisible().catch(() => false)) {
    await input.fill(name);
    await page.getByRole("button", { name: "Entrar al lobby" }).click();
  }
  await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 30_000 });
}

test("PAS 14 — perfil mostra nom i avatar", async ({ page }) => {
  await page.setViewportSize(MOBILE);
  await enterLobby(page, "Pas14Start", "pas14profile01");
  await page.getByRole("button", { name: /^Obrir perfil de/ }).click();
  await expect(page.getByTestId("profile-panel")).toBeVisible();
  await expect(page.getByTestId("profile-display-name")).toHaveText("Pas14Start");
  await page.screenshot({ path: path.join(screenshotDir(), "mobile-profile.png"), fullPage: false });
});

test("PAS 14 — editar nom de perfil", async ({ page }) => {
  await page.setViewportSize(MOBILE);
  await enterLobby(page, "Pas14Start", "pas14profile02");
  await page.getByRole("button", { name: /^Obrir perfil de/ }).click();
  await page.getByTestId("profile-edit-name").click();
  await page.getByTestId("profile-name-input").fill("Pas14Edit");
  await page.getByRole("button", { name: "Desar" }).click();
  await expect(page.getByTestId("profile-display-name")).toHaveText("Pas14Edit");
  await page.screenshot({ path: path.join(screenshotDir(), "mobile-profile-edit-name.png"), fullPage: false });
});
