import fs from "node:fs";
import path from "node:path";
import { expect, test, type Browser, type Page } from "@playwright/test";
import { myTurnSnapshot } from "./helpers/anim1213Fixtures.ts";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * PR 1 d'animacions: 12 (total en viu) i 13 (el teu torn), referència `animacions-repartir/12-total` i `13-el-teu-torn`.
 * Partida local seeded (sense socket), mall controlat. Comprova: comptatge de ½ en ½ quan la carta aterra, zones
 * ivori/or/rosa, «Bust», anelles i pista del primer cop sobre els botons reals, vibració, moviment reduït,
 * només transform/opacity, cada moviment < 600 ms, objectius ≥ 44 px i contrast AA. Captures a SETIMIG_ANIM_SHOTS.
 */
const SHOTS = process.env.SETIMIG_ANIM_SHOTS ?? path.join("test-results", "anim-12-13");
const AGE_OK = () => JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" });
const MOBILE = { width: 390, height: 844 };
const DESKTOP = { width: 1280, height: 800 };

type Opts = { reduce?: boolean; hintSeen?: boolean; desktop?: boolean };

async function open(browser: Browser, cards: number[], draws: number[], opts: Opts = {}) {
  const vp = opts.desktop ? DESKTOP : MOBILE;
  const ctx = await browser.newContext({
    viewport: vp,
    deviceScaleFactor: opts.desktop ? 1 : 2,
    locale: "en-US",
    colorScheme: "dark",
    reducedMotion: opts.reduce ? "reduce" : "no-preference",
  });
  const page = await ctx.newPage();
  const pid = e2ePoolId();
  await seedE2eSession(page, pid);
  await page.addInitScript(
    ({ snap, pid, age, hintSeen }) => {
      (window as unknown as { __vib: unknown[] }).__vib = [];
      try {
        Object.defineProperty(navigator, "vibrate", {
          configurable: true,
          value: (p: unknown) => {
            (window as unknown as { __vib: unknown[] }).__vib.push(p);
            return true;
          },
        });
      } catch {
        /* ignore */
      }
      // Valors mostrats pel total (per comprovar el comptatge de ½ en ½).
      (window as unknown as { __vals: Array<{ v: string; t: number }> }).__vals = [];
      new MutationObserver(() => {
        const el = document.querySelector<HTMLElement>("[data-testid='my-hand-points'][data-live-total='yes']");
        const v = el?.dataset.value;
        const arr = (window as unknown as { __vals: Array<{ v: string; t: number }> }).__vals;
        if (v && arr[arr.length - 1]?.v !== v) arr.push({ v, t: performance.now() });
      }).observe(document, { subtree: true, attributes: true, childList: true, attributeFilter: ["data-value"] });
      if (sessionStorage.getItem("a1213_seeded") === "1") return;
      sessionStorage.setItem("a1213_seeded", "1");
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", "Edu");
      localStorage.setItem("setimig.locale", "en");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_house_rules_enabled", "1");
      localStorage.setItem("setimig_age_gate", age);
      if (hintSeen) localStorage.setItem("setimig_your_turn_hint_v1", "1");
      localStorage.setItem("setimig_local_solo_snapshot", snap);
      sessionStorage.setItem("setimig_solo_rejoin", "1");
      sessionStorage.setItem("setimig_solo_local", "1");
    },
    { snap: myTurnSnapshot(pid, "Edu", cards, draws), pid, age: AGE_OK(), hintSeen: Boolean(opts.hintSeen) }
  );
  await page.route("**/socket.io/**", (route) => route.abort());
  await page.goto("/");
  await expect(page.getByTestId("action-hit")).toBeEnabled({ timeout: 30_000 });
  return { ctx, page };
}


async function shot(page: Page, name: string) {
  fs.mkdirSync(SHOTS, { recursive: true });
  await page.screenshot({ path: path.join(SHOTS, `${name}.png`) });
}

/** Atura les animacions del torn a `ms` des del seu inici (per fer captures deterministes); `resume` les reprèn. */
async function freezeTurnAt(page: Page, ms: number) {
  await page.evaluate((t) => {
    for (const a of document.getAnimations()) {
      const target = (a.effect as KeyframeEffect | null)?.target as Element | null;
      if (!target?.closest(".your-turn-overlay, .your-turn-row")) continue;
      a.currentTime = t;
      a.pause();
    }
  }, ms);
}
async function resumeTurn(page: Page) {
  await page.evaluate(() => {
    for (const a of document.getAnimations()) {
      if (a.playState !== "paused") continue;
      // play() d'una animació ja acabada la tornaria a començar: aquestes, directament al final.
      const end = Number(a.effect?.getComputedTiming().endTime ?? 0);
      if (Number(a.currentTime ?? 0) >= end) a.finish();
      else a.play();
    }
  });
}

/** Totes les animacions (CSS) de la PR: només transform/opacity i cada moviment < 600 ms. */
async function motionAudit(page: Page) {
  return page.evaluate(() => {
    const out: Array<{ name: string; props: string[]; duration: number; iterations: number }> = [];
    for (const a of document.getAnimations()) {
      const eff = a.effect as KeyframeEffect | null;
      const target = eff?.target as Element | null;
      if (!target || !target.closest(".live-total-value, .your-turn-row, .your-turn-overlay, .hero-score-bust")) continue;
      const props = new Set<string>();
      for (const k of eff!.getKeyframes()) for (const p of Object.keys(k)) if (!["offset", "computedOffset", "easing", "composite"].includes(p)) props.add(p);
      const timing = eff!.getTiming();
      out.push({ name: (a as CSSAnimation).animationName ?? "", props: [...props], duration: Number(timing.duration), iterations: Number(timing.iterations) });
    }
    return out;
  });
}

function expectMotionRules(list: Awaited<ReturnType<typeof motionAudit>>) {
  for (const a of list) {
    for (const p of a.props) expect(["transform", "opacity"], `${a.name}: ${p}`).toContain(p);
    // L'anella repeteix un cicle de 1500 ms, però el moviment visible és 520 ms (34,67 % del cicle).
    const visible = a.name === "your-turn-ring" ? a.duration * 0.3467 : a.duration;
    expect(visible, `${a.name} < 600 ms`).toBeLessThan(600);
  }
}


/** Taula gran (v147): mai es mostra el total propi durant la jugada (abans: total en viu de ½ en ½). */
async function expectNoOwnTotal(page: Page) {
  await expect(page.getByTestId("my-hand-points")).toHaveCount(0);
  await expect(page.locator(".live-total-value, .hero-score-value")).toHaveCount(0);
  expect(await page.getByTestId("action-hit").innerText()).not.toMatch(/%/);
}

test("12 · sense total propi durant la jugada (390×844), tampoc en demanar cartes", async ({ browser }) => {
  const { ctx, page } = await open(browser, [3], [10, 2, 1], { hintSeen: true });
  await expectNoOwnTotal(page);
  for (let i = 0; i < 3; i += 1) {
    await page.getByTestId("action-hit").click();
    await expect(page.getByTestId("action-hit")).toBeEnabled({ timeout: 5_000 });
    await expectNoOwnTotal(page);
  }
  expect(await page.evaluate(() => (window as unknown as { __vals: unknown[] }).__vals)).toEqual([]);
  await ctx.close();
});

test("12 · moviment reduït: tampoc hi ha total propi", async ({ browser }) => {
  const { ctx, page } = await open(browser, [6], [1], { reduce: true, hintSeen: true });
  await expectNoOwnTotal(page);
  await page.getByTestId("action-hit").click();
  await expect(page.getByTestId("action-hit")).toBeEnabled({ timeout: 5_000 });
  await expectNoOwnTotal(page);
  await ctx.close();
});

test("13 · el teu torn (390×844): botons reals vius, 2 anelles, vibració i pista del primer cop", async ({ browser }) => {
  const { ctx, page } = await open(browser, [4], [10, 10, 10]);
  const row = page.getByTestId("your-turn-row");
  await expect(row).toBeVisible();
  await expect(page.getByTestId("your-turn-ring")).toHaveCount(2);
  const audit = await motionAudit(page);
  // Captures deterministes: pols expandint-se (≈ 20 % del primer) i pista ja a dalt.
  await freezeTurnAt(page, 100 + 0.2 * 520);
  await shot(page, "13-torn-390x844-1-anella");
  await freezeTurnAt(page, 900);
  await shot(page, "13-torn-390x844-2-pista");
  await resumeTurn(page);
  expectMotionRules(audit);
  const ring = audit.find((a) => a.name === "your-turn-ring");
  expect(ring?.iterations).toBe(3);
  await expect(page.getByTestId("your-turn-hint")).toBeVisible();
  await expect(page.getByTestId("your-turn-hint")).toContainText("Hit: one more card.");
  await expect(page.getByTestId("your-turn-hint")).toContainText("Closest to 7½ wins.");
  // La pista queda per sobre dels botons i dins de la pantalla.
  const hb = (await page.getByTestId("your-turn-hint").boundingBox())!;
  const sb = (await page.getByTestId("action-stand").boundingBox())!;
  expect(hb.y + hb.height).toBeLessThanOrEqual(sb.y);
  expect(hb.x).toBeGreaterThanOrEqual(0);
  expect(hb.x + hb.width).toBeLessThanOrEqual(MOBILE.width);
  expect(await page.evaluate(() => (window as unknown as { __vib: unknown[] }).__vib)).toEqual([12]);
  // Objectius ≥ 44 px i anelles sense desbordar la pantalla.
  for (const id of ["action-hit", "action-stand"]) {
    const b = (await page.getByTestId(id).boundingBox())!;
    expect(b.height).toBeGreaterThanOrEqual(44);
    expect(b.width).toBeGreaterThanOrEqual(44);
  }
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(MOBILE.width);
  // La pista marxa sola (≈ 3,3 s) i no torna.
  await expect(page.getByTestId("your-turn-hint")).toHaveCount(0, { timeout: 5_000 });
  await shot(page, "13-torn-390x844-3-a-punt");
  // Primera acció: les anelles s'aturen.
  await page.getByTestId("action-hit").click();
  await expect(page.getByTestId("your-turn-ring")).toHaveCount(0);
  await ctx.close();
});

test("13 · pista només el primer cop; tocar on sigui la tanca", async ({ browser }) => {
  const seen = await open(browser, [4], [10], { hintSeen: true });
  await expect(seen.page.getByTestId("your-turn-ring")).toHaveCount(2);
  await seen.page.waitForTimeout(700);
  await expect(seen.page.getByTestId("your-turn-hint")).toHaveCount(0);
  await seen.ctx.close();
  const first = await open(browser, [4], [10]);
  await expect(first.page.getByTestId("your-turn-hint")).toBeVisible();
  await first.page.mouse.click(195, 200);
  await expect(first.page.getByTestId("your-turn-hint")).toHaveCount(0);
  expect(await first.page.evaluate(() => localStorage.getItem("setimig_your_turn_hint_v1"))).toBe("1");
  await first.ctx.close();
});

test("13 · moviment reduït: contorn daurat quiet, pista només amb fos", async ({ browser }) => {
  const { ctx, page } = await open(browser, [4], [10], { reduce: true });
  await expect(page.getByTestId("your-turn-ring")).toHaveCount(2);
  await page.waitForTimeout(500);
  const audit = await motionAudit(page);
  expect(audit.filter((a) => a.name === "your-turn-ring")).toHaveLength(0);
  for (const a of audit) expect(a.props, a.name).toEqual(["opacity"]);
  const ringOpacity = await page.evaluate(() => Number(getComputedStyle(document.querySelector("[data-testid='your-turn-ring']")!).opacity));
  expect(ringOpacity).toBeGreaterThan(0.5);
  expect(await page.evaluate(() => (window as unknown as { __vib: unknown[] }).__vib)).toEqual([12]);
  await shot(page, "13-torn-390x844-4-reduit");
  await ctx.close();
});

test("12 + 13 · escriptori 1280×800: sense total propi i anelles als botons reals", async ({ browser }) => {
  const { ctx, page } = await open(browser, [3], [10, 2, 1], { desktop: true, hintSeen: true });
  await expect(page.getByTestId("your-turn-ring")).toHaveCount(2);
  expectMotionRules(await motionAudit(page));
  for (let i = 0; i < 3; i += 1) {
    await page.getByTestId("action-hit").click();
    await expect(page.getByTestId("action-hit")).toBeEnabled({ timeout: 5_000 });
    await expectNoOwnTotal(page);
  }
  await expect(page.getByText(/^Points$/)).toHaveCount(0);
  expect(await page.evaluate(() => document.documentElement.scrollWidth)).toBeLessThanOrEqual(DESKTOP.width);
  await ctx.close();
});
