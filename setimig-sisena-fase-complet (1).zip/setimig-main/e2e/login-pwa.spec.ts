import AxeBuilder from "@axe-core/playwright";
import { openLoginEmail, blockSocketIoCtx, mockLoginSession } from "./helpers/loginSession.ts";
import { expect, test, type BrowserContext, type Page, type Route } from "@playwright/test";
import fs from "node:fs";
import path from "node:path";

/**
 * Pàgina d'inici de sessió (docs/auth-contracte.md, #237): Google, codi/enllaç per correu i passkeys (Face ID / Touch ID),
 * i «Add a passkey» al perfil. Totes les respostes de /api/auth/* són simulades (page.route): els camins feliços
 * no depenen de Google, del correu ni d'un autenticador real. WebAuthn: navigator.credentials simulat (una IP no pot ser rpId).
 * Captures opcionals: SETIMIG_LOGIN_SHOTS=<carpeta> desa login-*.png a 390x844 i 1280x800.
 */
const SHOTS = process.env.SETIMIG_LOGIN_SHOTS;
const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844 },
  { tag: "1280x800", width: 1280, height: 800 },
] as const;
const IPHONE_UA =
  "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1";
const PID = "loginpwa-player-01";
const NEW_PID = "loginpwa-player-02";
const TOKEN = "loginpwa.token";
const AGE_OK = () => JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" });

type Calls = Record<string, Array<Record<string, unknown>>>;

function success(method: string, extra: Record<string, unknown> = {}) {
  return { playerId: PID, playerToken: TOKEN, method, created: false, linked: true, switchedAccount: false, ...extra };
}

async function shot(page: Page, name: string, tag: string) {
  if (!SHOTS) return;
  fs.mkdirSync(SHOTS, { recursive: true });
  await page.waitForTimeout(250);
  await page.screenshot({ path: path.join(SHOTS, `login-${name}-${tag}.png`) });
}

/** Simula /api/auth/* i desa el cos de cada crida. `handlers` pot sobreescriure qualsevol ruta. */
async function mockAuth(ctx: BrowserContext, handlers: Record<string, (body: Record<string, unknown>) => { status?: number; json: unknown }> = {}) {
  const calls: Calls = {};
  let passkeys: Array<{ id: string; name: string }> = [];
  const defaults: Record<string, (body: Record<string, unknown>) => { status?: number; json: unknown }> = {
    "GET /api/auth/providers": () => ({ json: { email: true, google: true, passkey: true, rpId: "sevenhalf.club" } }),
    "POST /api/auth/email/start": () => ({ status: 202, json: { ok: true, expiresInSec: 600 } }),
    "POST /api/auth/email/verify": () => ({ json: success("email") }),
    "POST /api/auth/google/start": () => ({ json: { url: "/login/google#code=gcode123" } }),
    "POST /api/auth/exchange": () => ({ json: success("google") }),
    "POST /api/auth/passkey/login/options": () => ({ json: { challengeId: "ch1", options: { challenge: "AAECAw", rpId: "sevenhalf.club", userVerification: "preferred" } } }),
    "POST /api/auth/passkey/login/verify": () => ({ json: success("passkey") }),
    "GET /api/auth/me": () => ({ json: { playerId: PID, emails: ["edu@example.com"], google: false, passkeys: passkeys.length, verified: true } }),
    "GET /api/auth/passkeys": () => ({ json: { passkeys } }),
    "POST /api/auth/passkey/register/options": () => ({
      json: {
        challenge: "AAECAw",
        rp: { id: "sevenhalf.club", name: "Seven Half Club" },
        user: { id: "AQID", name: "edu", displayName: "Edu" },
        pubKeyCredParams: [{ type: "public-key", alg: -7 }],
        excludeCredentials: [],
        authenticatorSelection: { residentKey: "required", userVerification: "preferred" },
      },
    }),
    "POST /api/auth/passkey/register/verify": (body) => {
      const pk = { id: "pk1", name: String(body.name ?? "Passkey"), createdAt: Date.now(), lastUsedAt: null };
      passkeys = [...passkeys, pk];
      return { json: { ok: true, passkey: pk } };
    },
    "POST /api/player-session": () => ({ json: { playerId: PID, playerToken: TOKEN } }),
    "POST /api/auth/logout": () => ({ json: { ok: true } }),
    "POST /api/account/delete": () => ({ json: { ok: true, deleted: true } }),
    "PUT /api/profile": (body) => ({ json: { displayName: body.displayName, avatarDataUrl: null } }),
  };
  await ctx.route(/\/api\/(auth|player-session|account|profile)/, async (route: Route) => {
    const req = route.request();
    const url = new URL(req.url());
    const key = `${req.method()} ${url.pathname}`;
    let body: Record<string, unknown> = {};
    try {
      body = (req.postDataJSON() as Record<string, unknown>) ?? {};
    } catch {
      body = {};
    }
    // GET /api/profile i la resta de /api/profile*: el servidor real (només se simulen les escriptures).
    if (url.pathname.startsWith("/api/profile") && !handlers[key] && !defaults[key]) return route.fallback();
    (calls[key] ??= []).push({ ...body, __auth: req.headers()["authorization"] ?? null });
    // Com el servidor real: sense Bearer ni galeta, /api/player-session dona 401.
    if (key === "POST /api/player-session" && !handlers[key] && !req.headers()["authorization"]) {
      return route.fulfill({ status: 401, json: { error: "auth_required" } });
    }
    const h = handlers[key] ?? defaults[key];
    if (!h) return route.fulfill({ status: 404, json: { error: "no", code: "NOT_FOUND" } });
    const r = h(body);
    await route.fulfill({ status: r.status ?? 200, json: r.json });
  });
  return calls;
}

/** WebAuthn simulat: un autenticador de plataforma que sempre diu sí. */
async function stubWebAuthn(ctx: BrowserContext) {
  await ctx.addInitScript(() => {
    const buf = (n: number[]) => new Uint8Array(n).buffer;
    const w = window as unknown as Record<string, unknown>;
    const PKC = (w.PublicKeyCredential as Record<string, unknown> | undefined) ?? (function PublicKeyCredential() {} as unknown as Record<string, unknown>);
    PKC.isUserVerifyingPlatformAuthenticatorAvailable = async () => true;
    PKC.isConditionalMediationAvailable = async () => false;
    // Aquest dispositiu ja té Face ID activat: el botó surt i no es torna a proposar (e2e/login-passkey.spec.ts cobreix la proposta).
    localStorage.setItem("setimig_passkey_device", "1");
    localStorage.setItem("setimig_passkey_prompt", JSON.stringify({ "loginpwa-player-01": "registered", "loginpwa-player-02": "registered" }));
    w.PublicKeyCredential = PKC;
    const cred = (kind: "create" | "get") => ({
      id: "Y3JlZDE",
      rawId: buf([99, 114, 101, 100, 49]),
      type: "public-key",
      authenticatorAttachment: "platform",
      getClientExtensionResults: () => ({}),
      response:
        kind === "create"
          ? { clientDataJSON: buf([1, 2, 3]), attestationObject: buf([4, 5, 6]), getTransports: () => ["internal", "hybrid"] }
          : { clientDataJSON: buf([1, 2, 3]), authenticatorData: buf([7, 8]), signature: buf([9]), userHandle: buf([1, 2, 3]) },
    });
    const seen: Record<string, unknown> = {};
    w.__webauthnSeen = seen;
    Object.defineProperty(navigator.credentials, "create", {
      configurable: true,
      value: async (o: { publicKey: { challenge: ArrayBuffer; user: { id: ArrayBuffer } } }) => {
        seen.createChallenge = o.publicKey.challenge.byteLength;
        seen.createUserId = o.publicKey.user.id.byteLength;
        return cred("create");
      },
    });
    Object.defineProperty(navigator.credentials, "get", {
      configurable: true,
      value: async (o: { publicKey: { challenge: ArrayBuffer } }) => {
        seen.getChallenge = o.publicKey.challenge.byteLength;
        return cred("get");
      },
    });
  });
}

async function newCtx(browser: import("@playwright/test").Browser, vp: { width: number; height: number }, opts: { ios?: boolean; age?: boolean; session?: boolean; locale?: string } = {}) {
  const ctx = await browser.newContext({
    viewport: { width: vp.width, height: vp.height },
    locale: "en-US",
    colorScheme: "dark",
    ...(opts.ios ? { userAgent: IPHONE_UA, isMobile: true, hasTouch: true, deviceScaleFactor: 2 } : {}),
  });
  await ctx.addInitScript(
    ({ age, session, ios, pid, token, locale }) => {
      if (sessionStorage.getItem("login_seeded") === "1") return;
      sessionStorage.setItem("login_seeded", "1");
      // Intro d'arrencada ja vista en aquesta pestanya (la cobreix e2e/intro-primer.spec.ts).
      sessionStorage.setItem("setimig_intro_launch_v1", "1");
      localStorage.setItem("setimig.locale", locale);
      if (age) localStorage.setItem("setimig_age_gate", age);
      if (session) {
        localStorage.setItem("setimig_player_id", pid);
        localStorage.setItem("setimig_player_token", token);
        localStorage.setItem("setimig_player_name", "Edu");
        localStorage.setItem("setimig_onboarding_v1", "1");
        localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      }
      if (ios) Object.defineProperty(Navigator.prototype, "standalone", { configurable: true, get: () => true });
    },
    { age: opts.age === false ? null : AGE_OK(), session: !!opts.session, ios: !!opts.ios, pid: PID, token: TOKEN, locale: opts.locale ?? "en" }
  );
  // Login obligatori (#263): el token sembrat no és d'un compte real al servidor de proves, així que
  // la resta de /api/* i el socket se simulen com a sessió de compte (mockAuth, registrat després, té prioritat).
  if (opts.session) {
    await mockLoginSession(ctx, PID, TOKEN);
    // Rutes no simulades: 404 (la UI ho tolera) en comptes del {ok:true} genèric, que trenca vistes del perfil.
    await ctx.route("**/api/**", async (route) => {
      const p = new URL(route.request().url()).pathname.replace(/\/$/, "");
      if (/^\/api\/(health|auth|player-session|balance|profile|events)(\/|$)/.test(p)) return route.fallback();
      return route.fulfill({ status: 404, json: { error: "no", code: "NOT_FOUND" } });
    });
    await blockSocketIoCtx(ctx);
  }
  if (opts.ios) {
    await ctx.addInitScript(() => {
      Object.defineProperty(Navigator.prototype, "standalone", { configurable: true, get: () => true });
    });
  }
  return ctx;
}

async function noOverflow(page: Page) {
  const o = await page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
  expect(o.sw, "sense desbordament horitzontal").toBeLessThanOrEqual(o.cw);
}

/** Res retallat: cap control/text visible surt del viewport ni queda tallat pel seu contenidor. */
async function clipped(page: Page) {
  return page.evaluate(() => {
    const vw = document.documentElement.clientWidth;
    const out: string[] = [];
    for (const el of Array.from(document.querySelectorAll<HTMLElement>('[data-testid="login-page"] :is(button,a,input,label,p,h1,img)'))) {
      const r = el.getBoundingClientRect();
      if (!r.width || !r.height || getComputedStyle(el).visibility === "hidden" || el.classList.contains("sr-only")) continue;
      const id = el.dataset.testid ?? el.tagName + ":" + (el.textContent ?? "").trim().slice(0, 16);
      if (r.left < -0.5 || r.right > vw + 0.5) out.push(`fora:${id}`);
      if (el.scrollWidth > el.clientWidth + 1 && getComputedStyle(el).overflowX !== "visible") out.push(`tallat:${id}`);
    }
    return out;
  });
}

async function axeClean(page: Page) {
  const v = (await new AxeBuilder({ page }).analyze()).violations.map((x) => `${x.id}: ${x.nodes.map((n) => n.target.join(" ")).join(" | ")}`);
  expect(v, v.join("\n")).toEqual([]);
}

async function smallTargets(page: Page) {
  return page.evaluate(() =>
    [...document.querySelectorAll<HTMLElement>("[data-testid='login-page'] button, [data-testid='login-page'] a, [data-testid='login-page'] input, [data-testid='profile-account-section'] button, [data-testid='profile-account-section'] a")]
      .filter((el) => el.offsetParent !== null && !(el instanceof HTMLInputElement && el.type === "checkbox"))
      .map((el) => ({ t: el.dataset.testid ?? el.textContent?.trim().slice(0, 20), h: Math.round(el.getBoundingClientRect().height) }))
      .filter((x) => x.h < 44)
  );
}

for (const vp of VIEWPORTS) {
  test.describe(`login PWA · ${vp.tag}`, () => {
    test(`pàgina principal: tres mètodes, sense desbordament, objectius ≥ 44 px, axe (${vp.tag})`, async ({ browser }) => {
      const ctx = await newCtx(browser, vp);
      await stubWebAuthn(ctx);
      await mockAuth(ctx);
      const page = await ctx.newPage();
      await page.goto("/login");
      await expect(page.getByTestId("login-page")).toBeVisible();
      await expect(page.getByTestId("login-google")).toBeVisible();
      await expect(page.getByTestId("login-passkey")).toBeVisible();
      await expect(page.getByTestId("login-email-continue")).toBeVisible();
      // Vista principal neta: sense formulari al primer paint, sense capçalera ni toggle de crear compte.
      await expect(page.getByTestId("login-email-input")).toHaveCount(0);
      await expect(page.getByTestId("login-mode-toggle")).toHaveCount(0);
      await expect(page.getByTestId("login-slogan")).toBeVisible();
      await expect(page.getByTestId("login-legal-age")).toBeVisible();
      await noOverflow(page);
      expect(await smallTargets(page)).toEqual([]);
      expect(await clipped(page)).toEqual([]);
      // Logo a mida final (v199: ~227 px a 390, ~311 px a 1280) i posició estable: no es mou en obrir el correu.
      const logo = page.getByTestId("login-logo");
      await expect(logo).toBeVisible();
      const b0 = await logo.boundingBox();
      const logoPx = vp.width >= 1000 ? 311 : 227;
      expect(Math.abs(b0!.width - logoPx)).toBeLessThanOrEqual(8);
      expect(Math.abs(b0!.height - b0!.width)).toBeLessThanOrEqual(2);
      await axeClean(page);
      await shot(page, "principal", vp.tag);
      await page.getByTestId("login-email-continue").click();
      await expect(page.getByTestId("login-email-input")).toBeVisible();
      await page.waitForTimeout(300);
      const b1 = await logo.boundingBox();
      expect(Math.abs(b1!.y - b0!.y)).toBeLessThanOrEqual(1);
      await noOverflow(page);
      expect(await smallTargets(page)).toEqual([]);
      expect(await clipped(page)).toEqual([]);
      await ctx.close();
    });

    test(`correu: codi de 6 xifres, camí feliç (${vp.tag})`, async ({ browser }) => {
      const ctx = await newCtx(browser, vp);
      const calls = await mockAuth(ctx);
      const page = await ctx.newPage();
      await page.goto("/login");
      await openLoginEmail(page);
      await page.getByTestId("login-email-input").fill("edu@example.com");
      await page.getByTestId("login-email-submit").click();
      await expect(page.getByTestId("login-code-step")).toBeVisible();
      // P2 · sempre l'idioma de la UI com a `locale`.
      expect(calls["POST /api/auth/email/start"][0]).toMatchObject({ email: "edu@example.com", ageConfirmed: true, locale: "en" });
      // El correu ja no porta enllaç màgic: sempre primer el codi (camp abans de la pista) i cap menció d'enllaç.
      await expect(page.getByTestId("login-code-step")).toHaveAttribute("data-code-first", "true");
      const hintY = (await page.getByTestId("login-link-hint").boundingBox())!.y;
      const inputY = (await page.getByTestId("login-code-input").boundingBox())!.y;
      expect(inputY).toBeLessThan(hintY);
      await expect(page.getByTestId("login-link-hint")).not.toContainText(/link/i);
      await noOverflow(page);
      await axeClean(page);
      await shot(page, "codi", vp.tag);
      await page.getByTestId("login-code-input").fill("123456");
      await page.getByTestId("login-code-submit").click();
      await page.waitForURL((u) => u.pathname === "/");
      expect(calls["POST /api/auth/email/verify"][0]).toMatchObject({ email: "edu@example.com", code: "123456" });
      expect(await page.evaluate(() => localStorage.getItem("setimig_player_id"))).toBe(PID);
      await ctx.close();
    });

    test(`compte nou: cal el pas 18+ (${vp.tag})`, async ({ browser }) => {
      const ctx = await newCtx(browser, vp, { age: false });
      const calls = await mockAuth(ctx, {
        "POST /api/auth/email/verify": (body) =>
          body.ageConfirmed === true
            ? { json: success("email", { playerId: NEW_PID, created: true, linked: false }) }
            : { status: 403, json: { error: "Cal confirmar l'edat.", code: "AGE_CONFIRMATION_REQUIRED" } },
      });
      const page = await ctx.newPage();
      await page.goto("/login");
      // Sense el pas 18+ fet, entrar amb un correu sense compte → el servidor demana l'edat → pas «Crea el compte».
      await openLoginEmail(page);
      await page.getByTestId("login-email-input").fill("nou@example.com");
      await page.getByTestId("login-email-submit").click();
      expect(calls["POST /api/auth/email/start"][0]).toMatchObject({ ageConfirmed: false });
      await page.getByTestId("login-code-input").fill("654321");
      await page.getByTestId("login-code-submit").click();
      await expect(page.getByTestId("login-page")).toHaveAttribute("data-mode", "signup");
      // 18+ al mateix pas del codi (P1 28/10: abans tornava a la pantalla inicial i calia un altre codi).
      await expect(page.getByTestId("login-code-step")).toBeVisible();
      await expect(page.getByTestId("login-signup-age")).toBeVisible();
      await expect(page.getByTestId("login-code-submit")).toBeDisabled();
      await expect(page.getByTestId("login-passkey")).toHaveCount(0);
      await noOverflow(page);
      await axeClean(page);
      await shot(page, "alta-18", vp.tag);
      await page.getByTestId("login-age-checkbox").check();
      await page.getByTestId("login-code-submit").click();
      // created:true → pas del nom abans d'entrar.
      await page.getByTestId("login-name-input").fill("Nova");
      await page.getByTestId("login-name-submit").click();
      await page.waitForURL((u) => u.pathname === "/");
      expect(calls["POST /api/auth/email/verify"][1]).toMatchObject({ code: "654321", ageConfirmed: true });
      expect(await page.evaluate(() => !!localStorage.getItem("setimig_age_gate"))).toBe(true);
      await ctx.close();
    });

    test(`perfil: «Add a passkey» (${vp.tag})`, async ({ browser }) => {
      const ctx = await newCtx(browser, vp, { session: true });
      await stubWebAuthn(ctx);
      const calls = await mockAuth(ctx);
      const page = await ctx.newPage();
      await page.goto("/");
      await page.locator("button.header-profile").first().click();
      const section = page.getByTestId("profile-account-section");
      await expect(section).toBeVisible({ timeout: 30_000 });
      await section.scrollIntoViewIfNeeded();
      await expect(page.getByTestId("profile-add-passkey")).toBeVisible();
      await page.getByTestId("profile-add-passkey").click();
      await expect(page.getByTestId("profile-passkey-item")).toHaveCount(1);
      await expect(page.getByTestId("profile-passkey-message")).toHaveText("Passkey added.");
      const reg = calls["POST /api/auth/passkey/register/verify"][0] as { __auth: string; name: string; response: { id: string; rawId: string; response: Record<string, unknown> } };
      expect(reg.__auth).toBe(`Bearer ${TOKEN}`);
      expect(reg.response.rawId).toBe("Y3JlZDE");
      expect(reg.response.response).toMatchObject({ clientDataJSON: "AQID", attestationObject: "BAUG", transports: ["internal", "hybrid"] });
      expect(await page.evaluate(() => (window as unknown as { __webauthnSeen: Record<string, number> }).__webauthnSeen)).toMatchObject({ createChallenge: 4, createUserId: 3 });
      await noOverflow(page);
      expect(await smallTargets(page)).toEqual([]);
      const v = (await new AxeBuilder({ page }).include("[data-testid='profile-account-section']").analyze()).violations.map((x) => x.id);
      expect(v).toEqual([]);
      await section.scrollIntoViewIfNeeded();
      await shot(page, "perfil-passkey", vp.tag);
      await ctx.close();
    });
  });
}

test("Google: camí feliç (inici → /login/google#code → bescanvi)", async ({ browser }) => {
  const ctx = await newCtx(browser, VIEWPORTS[0]);
  const calls = await mockAuth(ctx);
  const page = await ctx.newPage();
  await page.goto("/login");
  await page.getByTestId("login-google").click();
  await page.waitForURL((u) => u.pathname === "/");
  expect(calls["POST /api/auth/google/start"][0]).toMatchObject({ ageConfirmed: true });
  expect(calls["POST /api/auth/exchange"][0]).toMatchObject({ code: "gcode123" });
  expect(await page.evaluate(() => localStorage.getItem("setimig_player_id"))).toBe(PID);
  await ctx.close();
});

test("Google: #error=AGE_CONFIRMATION_REQUIRED porta al pas 18+ i neteja el hash", async ({ browser }) => {
  const ctx = await newCtx(browser, VIEWPORTS[0], { age: false });
  await mockAuth(ctx);
  const page = await ctx.newPage();
  await page.goto("/login/google#error=AGE_CONFIRMATION_REQUIRED");
  await expect(page.getByTestId("login-signup-age")).toBeVisible();
  expect(await page.evaluate(() => location.hash)).toBe("");
  await ctx.close();
});

test("Enllaç màgic: /login/correu#t=… verifica amb POST i neteja el hash", async ({ browser }) => {
  const ctx = await newCtx(browser, VIEWPORTS[0]);
  const calls = await mockAuth(ctx, { "POST /api/auth/email/verify": () => ({ json: success("email", { switchedAccount: true }) }) });
  const page = await ctx.newPage();
  await page.goto("/login/correu#t=linktok42");
  await expect(page.getByTestId("login-switched")).toBeVisible();
  expect(calls["POST /api/auth/email/verify"][0]).toMatchObject({ linkToken: "linktok42" });
  expect(await page.evaluate(() => location.hash)).toBe("");
  await ctx.close();
});

test("Passkey: entrar amb Face ID / Touch ID, camí feliç", async ({ browser }) => {
  const ctx = await newCtx(browser, VIEWPORTS[0]);
  await stubWebAuthn(ctx);
  const calls = await mockAuth(ctx);
  const page = await ctx.newPage();
  await page.goto("/login");
  await page.getByTestId("login-passkey").click();
  await page.waitForURL((u) => u.pathname === "/");
  const v = calls["POST /api/auth/passkey/login/verify"][0] as { challengeId: string; response: { response: Record<string, unknown> } };
  expect(v.challengeId).toBe("ch1");
  expect(v.response.response).toMatchObject({ clientDataJSON: "AQID", authenticatorData: "Bwg", signature: "CQ", userHandle: "AQID" });
  expect(await page.evaluate(() => localStorage.getItem("setimig_player_token"))).toBe(TOKEN);
  await ctx.close();
});

for (const vp of VIEWPORTS) {
  test(`PWA d'iOS (standalone): primer el codi, després la pista (${vp.tag})`, async ({ browser }) => {
    const ctx = await newCtx(browser, vp, { ios: true });
    await mockAuth(ctx);
    const page = await ctx.newPage();
    await page.goto("/login");
    await openLoginEmail(page);
    await page.getByTestId("login-email-input").fill("edu@example.com");
    await page.getByTestId("login-email-submit").click();
    const step = page.getByTestId("login-code-step");
    await expect(step).toHaveAttribute("data-code-first", "true");
    const inputY = (await page.getByTestId("login-code-input").boundingBox())!.y;
    const hintY = (await page.getByTestId("login-link-hint").boundingBox())!.y;
    expect(inputY).toBeLessThan(hintY);
    await expect(page.getByTestId("login-link-hint")).toContainText("6-digit code");
    await noOverflow(page);
    await ctx.close();
  });
}

// ---- P2 del Provador i contracte #245 (docs/auth-contracte.md §1 i §4) ----

const P2_VP = VIEWPORTS[0];

async function p2shot(page: Page, name: string) {
  if (!SHOTS) return;
  fs.mkdirSync(SHOTS, { recursive: true });
  await page.waitForTimeout(250);
  await page.screenshot({ path: path.join(SHOTS, `login-p2-${name}-${P2_VP.tag}.png`) });
}

async function openProfile(page: Page) {
  await page.goto("/");
  await page.locator("button.header-profile").first().click();
  const section = page.getByTestId("profile-account-section");
  await expect(section).toBeVisible({ timeout: 30_000 });
  return section;
}

test("P2 · sortir amb un compte verificat: torna a /login i no crea cap jugador anònim", async ({ browser }) => {
  const ctx = await newCtx(browser, P2_VP, { session: true });
  const calls = await mockAuth(ctx);
  const page = await ctx.newPage();
  await openProfile(page);
  const before = (calls["POST /api/player-session"] ?? []).length;
  const logout = page.getByTestId("profile-logout");
  await logout.scrollIntoViewIfNeeded();
  await logout.click();
  await page.waitForURL((u) => u.pathname === "/login");
  await expect(page.getByTestId("login-page")).toBeVisible();
  await page.waitForTimeout(800);
  const ls = await page.evaluate(() => ({
    id: localStorage.getItem("setimig_player_id"),
    token: localStorage.getItem("setimig_player_token"),
    name: localStorage.getItem("setimig_player_name"),
  }));
  expect(ls).toEqual({ id: null, token: null, name: null });
  expect(calls["POST /api/auth/logout"]?.length).toBe(1);
  expect(calls["POST /api/auth/logout"][0].__auth).toBe(`Bearer ${TOKEN}`);
  expect((calls["POST /api/player-session"] ?? []).length).toBe(before);
  await noOverflow(page);
  await p2shot(page, "sortir");
  await ctx.close();
});

test("P2 · sortir (login obligatori): sempre esborra la sessió i torna a /login", async ({ browser }) => {
  const ctx = await newCtx(browser, P2_VP, { session: true });
  await mockAuth(ctx, {
    "GET /api/auth/me": () => ({ json: { playerId: PID, emails: [], google: false, passkeys: 0, verified: false } }),
    "POST /api/auth/logout": () => ({ status: 500, json: { error: "x" } }),
  });
  const page = await ctx.newPage();
  await openProfile(page);
  const logout = page.getByTestId("profile-logout");
  await logout.scrollIntoViewIfNeeded();
  await logout.click();
  await page.waitForURL((u) => u.pathname === "/login");
  const ls = await page.evaluate(() => ({
    id: localStorage.getItem("setimig_player_id"),
    token: localStorage.getItem("setimig_player_token"),
  }));
  expect(ls).toEqual({ id: null, token: null });
  await ctx.close();
});

test("P2 · compte nou per correu (created:true): pas del nom en comptes de «Jugador»", async ({ browser }) => {
  const ctx = await newCtx(browser, P2_VP);
  const calls = await mockAuth(ctx, {
    "POST /api/auth/email/verify": () => ({ json: success("email", { playerId: NEW_PID, created: true, linked: false }) }),
  });
  const page = await ctx.newPage();
  await page.goto("/login");
  await openLoginEmail(page);
  await page.getByTestId("login-email-input").fill("nova@example.com");
  await page.getByTestId("login-email-submit").click();
  await page.getByTestId("login-code-input").fill("222333");
  await page.getByTestId("login-code-submit").click();
  await expect(page.getByTestId("login-name-step")).toBeVisible();
  await expect(page.getByTestId("login-title")).toHaveText("Choose your name");
  await expect(page.getByTestId("login-name-submit")).toBeDisabled();
  await page.getByTestId("login-name-input").fill("Marta");
  await noOverflow(page);
  expect(await smallTargets(page)).toEqual([]);
  await axeClean(page);
  await p2shot(page, "nom");
  await page.getByTestId("login-name-submit").click();
  await page.waitForURL((u) => u.pathname === "/");
  const put = calls["PUT /api/profile"][0] as { playerId: string; displayName: string; __auth: string };
  expect(put).toMatchObject({ playerId: NEW_PID, displayName: "Marta", __auth: `Bearer ${TOKEN}` });
  expect(await page.evaluate(() => localStorage.getItem("setimig_player_name"))).toBe("Marta");
  await ctx.close();
});

test("P2 · el correu s'envia amb l'idioma de la UI (locale: ca)", async ({ browser }) => {
  const ctx = await newCtx(browser, P2_VP, { locale: "ca" });
  const calls = await mockAuth(ctx);
  const page = await ctx.newPage();
  await page.goto("/login");
  await openLoginEmail(page);
  await page.getByTestId("login-email-input").fill("edu@example.com");
  await page.getByTestId("login-email-submit").click();
  await expect(page.getByTestId("login-code-step")).toBeVisible();
  expect(calls["POST /api/auth/email/start"][0]).toMatchObject({ email: "edu@example.com", locale: "ca" });
  await ctx.close();
});

test("P2 · /login/correu sense #t=: camp de 6 xifres primer i camp de correu, i entra amb el codi", async ({ browser }) => {
  const ctx = await newCtx(browser, P2_VP);
  const calls = await mockAuth(ctx);
  const page = await ctx.newPage();
  await page.goto("/login/correu");
  const step = page.getByTestId("login-code-step");
  await expect(step).toBeVisible();
  await expect(step).toHaveAttribute("data-email-field", "true");
  await expect(step).toHaveAttribute("data-code-first", "true");
  const codeY = (await page.getByTestId("login-code-input").boundingBox())!.y;
  const emailY = (await page.getByTestId("login-code-email-input").boundingBox())!.y;
  expect(codeY).toBeLessThan(emailY);
  await expect(page.getByTestId("login-code-submit")).toBeDisabled();
  await page.getByTestId("login-code-input").fill("445566");
  await page.getByTestId("login-code-email-input").fill("edu@example.com");
  await noOverflow(page);
  expect(await smallTargets(page)).toEqual([]);
  await axeClean(page);
  await p2shot(page, "codi");
  // Cap verificació per enllaç: sense #t= no es crida res fins a «Sign in».
  expect(calls["POST /api/auth/email/verify"]).toBeUndefined();
  await page.getByTestId("login-code-submit").click();
  await page.waitForURL((u) => u.pathname === "/");
  expect(calls["POST /api/auth/email/verify"][0]).toMatchObject({ email: "edu@example.com", code: "445566" });
  await ctx.close();
});

test("P2 · perfil: «Delete account» amb confirmació escrita, Bearer i neteja de la sessió", async ({ browser }) => {
  const ctx = await newCtx(browser, P2_VP, { session: true });
  const calls = await mockAuth(ctx);
  const page = await ctx.newPage();
  await openProfile(page);
  const open = page.getByTestId("profile-delete-open");
  await open.scrollIntoViewIfNeeded();
  await open.click();
  const confirm = page.getByTestId("profile-delete-confirm");
  await expect(confirm).toBeDisabled();
  await page.getByTestId("profile-delete-input").fill("delet");
  await expect(confirm).toBeDisabled();
  await page.getByTestId("profile-delete-input").fill("DELETE");
  await expect(confirm).toBeEnabled();
  await page.getByTestId("profile-delete-account").scrollIntoViewIfNeeded();
  await noOverflow(page);
  expect(await smallTargets(page)).toEqual([]);
  const v = (await new AxeBuilder({ page }).include("[data-testid='profile-account-section']").analyze()).violations.map((x) => x.id);
  expect(v).toEqual([]);
  await p2shot(page, "esborrar");
  await page.evaluate(() => {
    // Instantània just abans de la navegació: el client ha d'haver esborrat l'id i el token.
    const w = window as unknown as { __lsAtUnload?: unknown };
    window.addEventListener("pagehide", () => {
      w.__lsAtUnload = [localStorage.getItem("setimig_player_id"), localStorage.getItem("setimig_player_token")];
      sessionStorage.setItem("ls_at_unload", JSON.stringify(w.__lsAtUnload));
    });
  });
  // L'esborrat recarrega «/» (el perfil ja és a «/»): s'espera la càrrega nova, no només l'URL.
  await Promise.all([page.waitForEvent("load"), confirm.click()]);
  await expect.poll(() => page.evaluate(() => sessionStorage.getItem("ls_at_unload"))).not.toBeNull();
  expect(JSON.parse((await page.evaluate(() => sessionStorage.getItem("ls_at_unload"))) ?? "null")).toEqual([null, null]);
  const del = calls["POST /api/account/delete"][0] as { confirm: string; __auth: string };
  expect(del).toMatchObject({ confirm: "DELETE_MY_ACCOUNT", __auth: `Bearer ${TOKEN}` });
  const ls = await page.evaluate(() => ({ id: localStorage.getItem("setimig_player_id"), token: localStorage.getItem("setimig_player_token") }));
  expect(ls.id).not.toBe(PID);
  expect(ls.token).not.toBe(TOKEN);
  await ctx.close();
});

for (const [status, code, text] of [
  [401, "AUTH_REQUIRED", "Your session is no longer valid"],
  [400, "CONFIRMATION_REQUIRED", "Type DELETE and try again"],
  [403, "BAD_ORIGIN", "blocked for security"],
] as const) {
  test(`P2 · «Delete account»: error ${status} ${code} amb missatge clar i sense esborrar la sessió`, async ({ browser }) => {
    const ctx = await newCtx(browser, P2_VP, { session: true });
    await mockAuth(ctx, { "POST /api/account/delete": () => ({ status, json: { error: "x", code } }) });
    const page = await ctx.newPage();
    await openProfile(page);
    const open = page.getByTestId("profile-delete-open");
    await open.scrollIntoViewIfNeeded();
    await open.click();
    await page.getByTestId("profile-delete-input").fill("DELETE");
    await page.getByTestId("profile-delete-confirm").click();
    await expect(page.getByTestId("profile-delete-error")).toContainText(text);
    expect(await page.evaluate(() => localStorage.getItem("setimig_player_token"))).toBe(TOKEN);
    await ctx.close();
  });
}
