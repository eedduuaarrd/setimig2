import AxeBuilder from "@axe-core/playwright";
import { E2E_ACCOUNT_IDS, e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";
import { expect, test, type Page } from "@playwright/test";

/**
 * Taula v2 · bloc 1 + retoc 1 (vídeo v2): mà del jugador gran i centrada, puntuació serif enorme,
 * barra «Bust probability» i STAND/HIT 50/50 a baix. Partida real contra bots, només mòbil.
 * Mesures: botons visibles sense scroll, 2 cartes ≈ 55 % de l'amplada (±5 %), puntuació ≈ 96 px a 390,
 * cap desbordament ni retall, cap verd ni vermell a la UI del bloc, axe sense serious/critical.
 * Amb SETIMIG_V2_SHOT=<ruta> desa una captura a 390×844 (per al costat a costat amb el vídeo).
 */
const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844 },
  { tag: "375x667", width: 375, height: 667 },
  { tag: "360x740", width: 360, height: 740 },
] as const;

async function seed(page: Page, id: string) {
  id = E2E_ACCOUNT_IDS.includes(id) ? id : e2ePoolId();
  await seedE2eSession(page, id);
  await page.addInitScript((pid) => {
    localStorage.setItem("setimig_player_id", pid);
    localStorage.setItem("setimig_player_name", "Edu");
    localStorage.setItem("setimig.locale", "en");
    localStorage.setItem("setimig_onboarding_v1", "1");
    localStorage.setItem("setimig_interactive_tutorial_v1", "1");
    localStorage.setItem("setimig_table_tutorial_v1", "1");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
  }, id);
}

/** Arriba al primer torn propi amb exactament 2 cartes (apostant si cal). */
async function reachTwoCardTurn(page: Page): Promise<boolean> {
  const deadline = Date.now() + 150_000;
  while (Date.now() < deadline) {
    const bet = page.getByTestId("bet-confirm");
    if ((await bet.isVisible().catch(() => false)) && (await bet.isEnabled().catch(() => false))) {
      await bet.click({ timeout: 2_000 }).catch(() => {});
      await page.waitForTimeout(400);
      continue;
    }
    const stand = page.getByTestId("action-stand");
    if ((await stand.isVisible().catch(() => false)) && (await stand.isEnabled().catch(() => false))) {
      const cards = await page.getByTestId("local-hand-card").count();
      if (cards === 2) {
        await page.waitForTimeout(700); // repartiment + flip + escala del panell (≤ 400 ms)
        if ((await stand.isEnabled().catch(() => false)) && (await page.getByTestId("local-hand-card").count()) === 2) return true;
      } else if (cards === 1) {
        // Al 7½ es reparteix 1 carta: en demanem una altra (amb 1 carta mai no es passa).
        await page.getByTestId("action-hit").click({ timeout: 2_000 }).catch(() => {});
        // Espera que arribi la 2a carta abans de tornar a mirar: si no, es podia demanar dues vegades (3 cartes).
        await expect
          .poll(() => page.getByTestId("local-hand-card").count(), { timeout: 8_000 })
          .toBeGreaterThanOrEqual(2)
          .catch(() => {});
      } else {
        await stand.click({ timeout: 2_000 }).catch(() => {});
      }
    }
    const next = page.getByTestId("settlement-next-hand");
    if (await next.isVisible().catch(() => false)) await next.click({ timeout: 2_000 }).catch(() => {});
    await page.waitForTimeout(300);
  }
  return false;
}

type Metrics = {
  vw: number;
  vh: number;
  scrollW: number;
  scrollH: number;
  docScrollTop: number;
  stand: DOMRect;
  hit: DOMRect;
  fanPct: number;
  cardW: number;
  cardPct: number;
  cardCount: number;
  cardRects: string;
  cardsOutsidePanel: string[];
  stripVisible: boolean;
  historyBtn: DOMRect | null;
  standFont: string;
  hitBg: string;
  sevenHalf: boolean;
  hitEnabled: boolean;
  hitBgImage: string;
  scoreFont: number;
  scoreFamily: string;
  scoreColor: string;
  panel: DOMRect;
  panelBg: string;
  bar: DOMRect | null;
  barLabel: string;
  pct: string;
  clipped: string[];
  greenRed: string[];
  smallText: string[];
};

async function measure(page: Page): Promise<Metrics> {
  return page.evaluate(() => {
    const q = (id: string) => document.querySelector(`[data-testid="${id}"]`) as HTMLElement | null;
    const r = (el: Element | null) => (el ? (el.getBoundingClientRect().toJSON() as DOMRect) : (null as unknown as DOMRect));
    const cardEls = [...document.querySelectorAll('[data-testid="local-hand-card"]')] as HTMLElement[];
    const cards = cardEls.map((c) => c.getBoundingClientRect());
    const left = Math.min(...cards.map((c) => c.left));
    const right = Math.max(...cards.map((c) => c.right));
    const panel = q("player-hero-panel")!;
    const pr = panel.getBoundingClientRect();
    const cardsOutsidePanel = cards
      .filter((c) => c.left < pr.left - 0.5 || c.right > pr.right + 0.5 || c.top < pr.top - 0.5)
      .map((c) => `${Math.round(c.left)}-${Math.round(c.right)}`);
    const strip = q("recent-action-timeline-disclosure");
    const historyBtn = q("v2-history-button");
    // Taula gran (v147): ja no hi ha puntuació gran durant la jugada.
    const score = panel.querySelector(".hero-score-value") as HTMLElement | null;
    const block = [panel, q("action-stand")!, q("action-hit")!];
    const clipped: string[] = [];
    for (const el of score ? [...block, score] : block) {
      const b = el.getBoundingClientRect();
      if (b.left < -0.5 || b.right > innerWidth + 0.5 || b.top < -0.5 || b.bottom > innerHeight + 0.5) {
        clipped.push(`${el.dataset.testid ?? el.className}@${Math.round(b.left)},${Math.round(b.top)},${Math.round(b.right)},${Math.round(b.bottom)}`);
      }
    }
    // Cap verd ni vermell: colors de text, fons i vores dels elements del bloc (les cartes són art i queden fora).
    const greenRed: string[] = [];
    const isGreenOrRed = (c: string) => {
      const m = c.match(/rgba?\(([\d.]+),\s*([\d.]+),\s*([\d.]+)(?:,\s*([\d.]+))?/);
      if (!m) return false;
      const [R, G, B, A] = [+m[1], +m[2], +m[3], m[4] == null ? 1 : +m[4]];
      if (A < 0.05) return false;
      const max = Math.max(R, G, B);
      const min = Math.min(R, G, B);
      if (max - min < 40) return false; // gris / neutre
      const green = G === max && G - Math.max(R, B) > 30;
      const red = R === max && R - G > 60 && R - B > 60 && !(G > 120 && R > 180); // or/daurat no compta
      return green || red;
    };
    const scope = [...block.flatMap((el) => [el, ...el.querySelectorAll("*")])].filter(
      (el) => !el.closest('[data-testid="local-hand-card"]')
    );
    for (const el of scope) {
      const s = getComputedStyle(el);
      for (const c of [s.color, s.backgroundColor, s.borderTopColor]) {
        if (isGreenOrRed(c)) greenRed.push(`${(el as HTMLElement).className || el.tagName}:${c}`);
      }
    }
    const smallText = scope
      .filter((el) => [...el.childNodes].some((n) => n.nodeType === 3 && (n.textContent ?? "").trim()))
      .filter((el) => parseFloat(getComputedStyle(el).fontSize) < 12)
      .map((el) => `${(el.textContent ?? "").trim().slice(0, 20)}@${getComputedStyle(el).fontSize}`);
    const bar = q("hit-bust-risk-bar");
    return {
      vw: innerWidth,
      vh: innerHeight,
      scrollW: document.documentElement.scrollWidth,
      scrollH: document.documentElement.scrollHeight,
      docScrollTop: document.scrollingElement?.scrollTop ?? 0,
      stand: r(q("action-stand")),
      hit: r(q("action-hit")),
      fanPct: ((right - left) / innerWidth) * 100,
      cardW: cardEls[0]?.offsetWidth ?? 0,
      cardPct: ((cardEls[0]?.offsetWidth ?? 0) / innerWidth) * 100,
      cardCount: cardEls.length,
      cardRects: cards.map((c) => `${Math.round(c.left)}..${Math.round(c.right)}`).join(" ") + ` panel ${Math.round(pr.left)}..${Math.round(pr.right)} slot ${Math.round(document.querySelector('[data-testid="local-hand-fan-slot"]')!.getBoundingClientRect().width)} fan ${Math.round(document.querySelector('[data-testid="local-hand-swipe-zone"]')!.getBoundingClientRect().width)} styles ${cardEls.map((c) => c.style.marginLeft + "/" + c.style.transform).join(",")}`,
      cardsOutsidePanel,
      stripVisible: !!strip && strip.getBoundingClientRect().height > 0,
      historyBtn: historyBtn ? (historyBtn.getBoundingClientRect().toJSON() as DOMRect) : null,
      standFont: getComputedStyle(q("action-stand")!).fontFamily,
      hitEnabled: !(q("action-hit") as HTMLButtonElement | null)?.disabled,
      hitBgImage: getComputedStyle(q("action-hit")!).backgroundImage,
      hitBg: getComputedStyle(q("action-hit")!).backgroundColor,
      sevenHalf: /^7½$/.test((q("my-hand-points")?.textContent ?? "").trim()),
      scoreFont: score ? parseFloat(getComputedStyle(score).fontSize) : 0,
      scoreFamily: score ? getComputedStyle(score).fontFamily : "",
      scoreColor: score ? getComputedStyle(score).color : "",
      panel: r(panel),
      panelBg: getComputedStyle(panel).backgroundColor,
      bar: bar ? r(bar) : null,
      barLabel: (panel.querySelector(".hero-bust-label")?.textContent ?? "").trim(),
      pct: (q("hit-bust-risk")?.textContent ?? "").trim(),
      clipped,
      greenRed,
      smallText,
    };
  });
}

/** Mesura quan el repartiment (vol + flip) i el recol·locament del ventall (spring) ja han acabat. */
async function settledMeasure(page: Page): Promise<Metrics> {
  let prev = await measure(page);
  const deadline = Date.now() + 5_000;
  while (Date.now() < deadline) {
    await page.waitForTimeout(200);
    const next = await measure(page);
    if (Math.abs(next.fanPct - prev.fanPct) < 0.2 && next.cardCount === prev.cardCount) return next;
    prev = next;
  }
  return prev;
}

for (const vp of VIEWPORTS) {
  test(`taula v2 · bloc 1 · ${vp.tag}`, async ({ page }) => {
    await page.setViewportSize({ width: vp.width, height: vp.height });
    await seed(page, `v2b1-${vp.width}-${Date.now()}`);
    await page.goto("/");
    // Lobby v4.1 (#181): «Jugar» ja no obre el diàleg; la línia de context sí.
    await page.getByTestId("lobby-context").click();
    await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
    await page.getByTestId("ai-bot-count-2").click();
    await page.getByTestId("ai-bot-picker").getByRole("button", { name: /^(Start|Començar)$/ }).click();

    const reached = await reachTwoCardTurn(page);
    if (!reached) await page.screenshot({ path: `out/fail-${vp.tag}.png` }).catch(() => {});
    expect(reached, "arriba a un torn propi amb 2 cartes").toBe(true);
    const m = await settledMeasure(page);
    const shot = process.env.SETIMIG_V2_SHOT;
    if (shot && vp.width === 390) await page.screenshot({ path: shot });
    console.log(`[${vp.tag}] ${JSON.stringify({ ...m, stand: undefined, hit: undefined, panel: undefined, bar: undefined })}`);
    console.log(
      `[${vp.tag}] stand=${JSON.stringify(m.stand)} hit=${JSON.stringify(m.hit)} panel=${JSON.stringify(m.panel)} bar=${JSON.stringify(m.bar)}`
    );

    // Botons: sencers dins de la pantalla, sense scroll, ~56 px, iguals, STAND a l'esquerra.
    expect(m.stand.bottom).toBeLessThanOrEqual(vp.height);
    expect(m.hit.bottom).toBeLessThanOrEqual(vp.height);
    expect(m.stand.top).toBeGreaterThanOrEqual(0);
    expect(m.stand.height).toBeGreaterThanOrEqual(52);
    expect(m.stand.height).toBeLessThanOrEqual(60);
    expect(Math.abs(m.stand.width - m.hit.width)).toBeLessThanOrEqual(2);
    expect(m.stand.left).toBeLessThan(m.hit.left);
    expect(m.docScrollTop).toBe(0);
    expect(m.scrollW, "sense desbordament horitzontal").toBeLessThanOrEqual(vp.width);
    expect(m.scrollH, "sense scroll vertical").toBeLessThanOrEqual(vp.height);

    // Retoc 1: cada carta ≈ 45–50 % de l'amplada a 390 (a pantalles baixes l'alçada mana); mai fora del panell.
    if (vp.width === 390) {
      // Retoc (Orquestrador): parella ≈ 70 % de l'amplada (±4), cada carta ≈ 40 %.
      // Taula gran (v147): al teu torn les cartes creixen (abans ≈ 40 % / parella ≈ 70 %); el ventall cap al panell.
      expect(m.cardPct).toBeGreaterThanOrEqual(48);
      expect(m.cardPct).toBeLessThanOrEqual(60);
      expect(m.fanPct).toBeLessThanOrEqual(86);
    } else {
      expect(m.cardPct).toBeGreaterThanOrEqual(25);
    }
    expect(m.fanPct, "2 cartes encavalcades").toBeLessThan(m.cardPct * 2);
    expect(m.cardsOutsidePanel, "cartes dins del panell").toEqual([]);

    // Retoc 1: STAND/HIT en serif. Retoc 3: HIT ivori pla (sense degradat), STAND fosc amb vora ivori.
    expect(m.standFont).toMatch(/Cormorant Garamond/);
    if (m.hitEnabled) {
      expect(m.hitBgImage).toBe("none");
      expect(m.hitBg).toBe("rgb(245, 242, 235)");
    }

    // Retoc 1: sense la tira «Actions · … · History»; una icona ≥ 44 px obre el mateix historial.
    expect(m.stripVisible).toBe(false);
    expect(m.historyBtn).not.toBeNull();
    expect(m.historyBtn!.width).toBeGreaterThanOrEqual(44);
    expect(m.historyBtn!.height).toBeGreaterThanOrEqual(44);

    // Taula gran (v147): cap puntuació pròpia durant la jugada (abans: Fraunces ≈ 96 px).
    expect(m.scoreFont).toBe(0);
    expect(m.sevenHalf).toBe(false);

    // Panell #161616 i barra a sota de la puntuació, dins del panell.
    // Retoc 4: sense panell, la mà sura sobre el fons.
    expect(m.panelBg).toBe("rgba(0, 0, 0, 0)");
    // Amb 7½ no es pot demanar: la barra queda amagada (espai reservat); si no, visible per defecte.
    const sevenHalf = m.sevenHalf;
    expect(m.cardCount, "mesura amb exactament 2 cartes").toBe(2);
    // La barra es mostra quan es pot demanar (torn propi, sense 7½); és el mateix criteri que el botó HIT.
    // Taula gran (v147): sense barra ni percentatge de risc (delataven els punts).
    void sevenHalf;
    expect(m.bar).toBeNull();
    expect(m.pct).toBe("");
    expect(m.barLabel).toBe("");
    // Panell i botons no es trepitgen.
    expect(m.panel.bottom).toBeLessThanOrEqual(m.stand.top);

    expect(m.clipped, "res retallat").toEqual([]);
    expect(m.greenRed, "cap verd ni vermell").toEqual([]);
    expect(m.smallText, "res < 12 px").toEqual([]);

    // Bloc 3: capa de bokeh fixa darrere de tot, sense capturar clics; un sol canvas que s'anima
    // (excepte al nivell més baix: pantalla petita i màquina modesta, on és estàtic).
    const bokeh = page.getByTestId("table-bokeh");
    await expect(bokeh).toHaveCount(1);
    await expect.poll(() => bokeh.getAttribute("data-particles").then(Number), { timeout: 5_000 }).toBeGreaterThanOrEqual(10);
    const bk = await page.evaluate(async () => {
      const layer = document.querySelector<HTMLElement>("[data-testid='table-bokeh']")!;
      const cs = getComputedStyle(layer);
      const hit = document.querySelector<HTMLElement>("[data-testid='action-hit']")!.getBoundingClientRect();
      const top = document.elementFromPoint(hit.left + hit.width / 2, hit.top + hit.height / 2);
      const canvases = Array.from(layer.querySelectorAll("canvas"));
      // El canvas es pinta un cop; el moviment és una animació CSS (compositor) a la capa de pols.
      const animated = canvases.filter((c) => c.getAnimations().some((a) => a.playState === "running")).length;
      return {
        position: cs.position,
        pointerEvents: cs.pointerEvents,
        zIndex: cs.zIndex,
        hitOnTop: !!top?.closest("[data-testid='action-hit']"),
        particles: Number(layer.dataset.particles),
        staticReason: layer.dataset.staticReason ?? null,
        canvases: canvases.length,
        moving: animated > 0,
        animated,
      };
    });
    console.log(`[${vp.tag}] bokeh=${JSON.stringify(bk)}`);
    expect(bk.position).toBe("fixed");
    expect(bk.pointerEvents).toBe("none");
    expect(bk.zIndex).toBe("-1");
    expect(bk.hitOnTop, "el bokeh no intercepta clics").toBe(true);
    // Retoc 3: 1 canvas de bokeh + 3 grups de pols (centelleig desfasat).
    expect(bk.canvases).toBe(4);
    expect(bk.particles).toBeLessThanOrEqual(60);
    if (bk.staticReason === "low-end") expect(bk.moving, "estàtic al nivell baix").toBe(false);
    else expect(bk.animated, "3 grups que centellegen (compositor)").toBe(3);

    const historyButton = page.getByTestId("v2-history-button");
    await expect(historyButton).toHaveAttribute("aria-label", /.+/);
    await historyButton.click();
    await expect(page.getByTestId("v2-history-panel")).toBeVisible();
    await expect(page.getByTestId("recent-action-timeline")).toBeVisible();
    await historyButton.click();
    await expect(page.getByTestId("v2-history-panel")).toHaveCount(0);

    const axe = await new AxeBuilder({ page }).analyze();
    const serious = axe.violations.filter((v) => v.impact === "serious" || v.impact === "critical");
    expect(serious.map((v) => `${v.id}: ${v.nodes.map((n) => n.target.join(" ")).join(", ")}`)).toEqual([]);

    // 3+ cartes: si encara es pot demanar, demanem i comprovem que tot cap (sense scroll ni cartes fora).
    const hit = page.getByTestId("action-hit");
    if ((await hit.isEnabled().catch(() => false)) && (await page.getByTestId("my-hand-points").count()) === 0) {
      await hit.click();
      await page.waitForTimeout(1_200);
      if ((await page.getByTestId("local-hand-card").count()) >= 3 && (await page.getByTestId("action-stand").isVisible().catch(() => false))) {
        const m3 = await settledMeasure(page);
        console.log(`[${vp.tag}] 3+ cartes: ${m3.cardCount} cartes, carta ${m3.cardPct.toFixed(1)} %, ventall ${m3.fanPct.toFixed(1)} %, fora ${JSON.stringify(m3.cardsOutsidePanel)}, scrollH ${m3.scrollH}`);
        expect(m3.cardsOutsidePanel).toEqual([]);
        expect(m3.scrollH).toBeLessThanOrEqual(vp.height);
        expect(m3.scrollW).toBeLessThanOrEqual(vp.width);
        expect(m3.clipped).toEqual([]);
      }
    }

    // Bloc 3: captura del torn de la banca (per comparar amb el f21 del vídeo), només si es demana.
    const bankerShot = process.env.SETIMIG_V2_SHOT_BANKER;
    if (bankerShot && vp.width === 390) {
      const st = page.getByTestId("action-stand");
      if ((await st.isVisible().catch(() => false)) && (await st.isEnabled().catch(() => false))) await st.click();
      await expect
        .poll(() => page.locator(".game-table-root").getAttribute("data-game-phase"), { timeout: 20_000 })
        .toMatch(/banker|settlement/)
        .catch(() => {});
      await page.waitForTimeout(900);
      await page.screenshot({ path: bankerShot });
    }
  });
}

/** Bloc 3: amb moviment reduït (sistema o app) el bokeh és estàtic: cap animació. */
for (const mode of ["sistema", "app"] as const) {
  test(`taula v2 · bloc 3 · bokeh estàtic amb moviment reduït (${mode})`, async ({ browser }) => {
    const ctx = await browser.newContext({
      viewport: { width: 390, height: 844 },
      locale: "en-US",
      colorScheme: "dark",
      reducedMotion: mode === "sistema" ? "reduce" : "no-preference",
    });
    const page = await ctx.newPage();
    await seed(page, `v2b3-rm-${mode}-${Date.now()}`);
    if (mode === "app") await page.addInitScript(() => localStorage.setItem("setimig_reduce_motion", "1"));
    await page.goto("/");
    // Lobby v4.1 (#181): «Jugar» ja no obre el diàleg; la línia de context sí.
    await page.getByTestId("lobby-context").click();
    await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
    await page.getByTestId("ai-bot-count-2").click();
    await page.getByTestId("ai-bot-picker").getByRole("button", { name: /^(Start|Començar)$/ }).click();
    const bokeh = page.getByTestId("table-bokeh");
    await expect(bokeh).toHaveCount(1, { timeout: 30_000 });
    await expect(bokeh).toHaveAttribute("data-static", "true");
    await expect(bokeh).toHaveAttribute("data-static-reason", "reduced-motion");
    await expect.poll(() => bokeh.getAttribute("data-particles").then(Number), { timeout: 5_000 }).toBeGreaterThanOrEqual(10);
    const anims = await page.evaluate(() =>
      // Només animacions CSS: la regla global de moviment reduït de l'app permet un fos d'opacitat de 120 ms (transició).
      Array.from(document.querySelectorAll<HTMLElement>("[data-testid='table-bokeh'] *")).reduce(
        (n, c) => n + c.getAnimations().filter((x) => "animationName" in x).length,
        0
      )
    );
    expect(anims, "fons estàtic: cap animació").toBe(0);
    await ctx.close();
  });
}

/** Escriptori 1280×800: només captura (el muntatge de seients ≥ 1024 px depèn del P0 grok/p0-escriptori-seients). */
test("taula v2 · bloc 1 · captura 1280x800", async ({ browser }) => {
  const shot = process.env.SETIMIG_V2_SHOT_DESKTOP;
  test.skip(!shot, "només per a captures");
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 1, isMobile: false, hasTouch: false, locale: "en-US", colorScheme: "dark" });
  const page = await ctx.newPage();
  await seed(page, `v2b1-1280-${Date.now()}`);
  await page.goto("/");
  // Lobby v4.1 (#181): «Jugar» ja no obre el diàleg; la línia de context sí.
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  await page.getByTestId("ai-bot-count-2").click();
  await page.getByTestId("ai-bot-picker").getByRole("button", { name: /^(Start|Començar)$/ }).click();
  // Bloc 3: a escriptori el bokeh queda dins de la taula i no tapa res.
  await expect(page.getByTestId("table-bokeh")).toHaveCount(1, { timeout: 30_000 });
  const dk = await page.evaluate(() => {
    const l = document.querySelector<HTMLElement>("[data-testid='table-bokeh']")!;
    return { position: getComputedStyle(l).position, pe: getComputedStyle(l).pointerEvents };
  });
  expect(dk).toEqual({ position: "absolute", pe: "none" });
  const deadline = Date.now() + 90_000;
  while (Date.now() < deadline) {
    const bet = page.getByTestId("bet-confirm");
    if ((await bet.isVisible().catch(() => false)) && (await bet.isEnabled().catch(() => false))) {
      await bet.click({ timeout: 2_000 }).catch(() => {});
    } else if (await page.getByTestId("action-stand").isVisible().catch(() => false)) {
      await page.waitForTimeout(900);
      break;
    }
    await page.waitForTimeout(400);
  }
  await page.screenshot({ path: shot! });
  await ctx.close();
});
