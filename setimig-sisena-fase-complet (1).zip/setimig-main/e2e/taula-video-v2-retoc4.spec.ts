import { expect, test, type Browser, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";
import { playerTurnSnapshot } from "./helpers/jugabilitatV1Fixtures.ts";
import { V2_GOLD_EXCEPTIONS } from "./helpers/jugabilitatV2Probes.ts";

/**
 * Taula v2 · retoc 4 (vídeo v2, f13): ventall de 2 cartes a ±4°, la mà sense panell (sura sobre el fons), pals grans
 * a les cartes de número, aposta/saldo molt discrets però AA, més pols al mòbil, 7½ en or #D4AF6A amb resplendor
 * estàtica (també amb moviment reduït) i, a 1280, seients/BANK/History/POT sense or.
 * Partida local seeded (sense socket). Captura opcional: SETIMIG_V2_SHOT_R4_DESKTOP (1280, seients sense or).
 */
const AGE_OK = () => JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" });
const GOLD = "rgb(212, 175, 106)";
const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844 },
  { tag: "375x667", width: 375, height: 667 },
  { tag: "360x740", width: 360, height: 740 },
] as const;

async function openTurn(browser: Browser, vp: { width: number; height: number }, cards: number[], opts: { reduce?: boolean; desktop?: boolean } = {}) {
  const ctx = await browser.newContext({
    viewport: { width: vp.width, height: vp.height },
    deviceScaleFactor: opts.desktop ? 1 : 2,
    locale: "en-US",
    colorScheme: "dark",
    reducedMotion: opts.reduce ? "reduce" : "no-preference",
  });
  const page = await ctx.newPage();
  const pid = e2ePoolId();
  await seedE2eSession(page, pid);
  await page.addInitScript(
    ({ snap, pid, age }) => {
      if (sessionStorage.getItem("r4_seeded") === "1") return;
      sessionStorage.setItem("r4_seeded", "1");
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", "Edu");
      localStorage.setItem("setimig.locale", "en");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_table_tutorial_v1", "1");
      localStorage.setItem("setimig_house_rules_enabled", "1");
      localStorage.setItem("setimig_age_gate", age);
      localStorage.setItem("setimig_local_solo_snapshot", snap);
      sessionStorage.setItem("setimig_solo_rejoin", "1");
      sessionStorage.setItem("setimig_solo_local", "1");
    },
    { snap: playerTurnSnapshot(pid, "Edu", cards), pid, age: AGE_OK() }
  );
  await page.route("**/socket.io/**", (route) => route.abort());
  await page.goto("/");
  await expect(page.getByTestId("action-hit")).toBeEnabled({ timeout: 30_000 });
  await page.waitForTimeout(900);
  return { ctx, page };
}

function contrastJs() {
  return `(() => {
    const lum = (c) => { const f = (v) => { const x = v / 255; return x <= 0.03928 ? x / 12.92 : ((x + 0.055) / 1.055) ** 2.4; }; return 0.2126 * f(c[0]) + 0.7152 * f(c[1]) + 0.0722 * f(c[2]); };
    window.__ratio = (fg, bg) => { const a = fg[3] ?? 1; const m = [0, 1, 2].map((i) => fg[i] * a + bg[i] * (1 - a)); const [L1, L2] = [lum(m), lum(bg)]; return (Math.max(L1, L2) + 0.05) / (Math.min(L1, L2) + 0.05); };
  })()`;
}

for (const vp of VIEWPORTS) {
  test(`taula v2 · retoc 4 · ${vp.tag} · ventall ±4°, sense panell, pals grans, aposta discreta, sense desbordament`, async ({ browser }) => {
    const { ctx, page } = await openTurn(browser, vp, [4, 3]);
    await page.evaluate(contrastJs());
    const m = await page.evaluate(() => {
      const rgba = (c: string) => (c.match(/[\d.]+/g) ?? []).map(Number);
      const panel = document.querySelector<HTMLElement>(".player-hero-panel")!;
      const pcs = getComputedStyle(panel);
      const cards = [...document.querySelectorAll<HTMLElement>("[data-testid='local-hand-card']")];
      const rot = cards.map((c) => Number(c.closest<HTMLElement>("[data-fan-rotate]")?.dataset.fanRotate ?? NaN));
      const angle = cards.map((c) => {
        const el = c.closest<HTMLElement>("[data-fan-rotate]")!;
        const t = getComputedStyle(el).transform;
        const mm = t.match(/matrix\(([^,]+), ([^,]+)/);
        return mm ? Math.round((Math.atan2(Number(mm[2]), Number(mm[1])) * 180) / Math.PI * 10) / 10 : 0;
      });
      const cardRects = cards.map((c) => c.getBoundingClientRect());
      const pips = cards.map((c) => {
        // Baralla E: els pips són imatges posicionades per cards.json dins de .spanish-pips.
        const g = c.querySelector<HTMLElement>(".spanish-pips");
        const first = g?.querySelector<HTMLImageElement>("img.pip");
        return { n: Number(g?.dataset.pips ?? 0), pipPct: first ? (first.getBoundingClientRect().width / c.getBoundingClientRect().width) * 100 : 0 };
      });
      const row = document.querySelector<HTMLElement>("[data-testid='own-bet-row']");
      const nums = row ? [...row.querySelectorAll<HTMLElement>(".own-bet-amount, .own-bet-balance")] : [];
      const ratio = (window as unknown as { __ratio: (a: number[], b: number[]) => number }).__ratio;
      return {
        vw: innerWidth,
        vh: innerHeight,
        scrollW: document.documentElement.scrollWidth,
        scrollH: document.documentElement.scrollHeight,
        panel: {
          bg: pcs.backgroundColor,
          borderAlpha: rgba(pcs.borderTopColor)[3] ?? 1,
          borderW: parseFloat(pcs.borderTopWidth),
          shadow: pcs.boxShadow,
          before: getComputedStyle(panel, "::before").opacity,
          after: getComputedStyle(panel, "::after").opacity,
        },
        rot,
        angle,
        outside: cardRects.filter((r) => r.left < -0.5 || r.right > innerWidth + 0.5 || r.top < -0.5 || r.bottom > innerHeight + 0.5).length,
        cardW: cardRects.map((r) => Math.round(r.width)),
        pips,
        bet: nums.map((el) => {
          const cs = getComputedStyle(el);
          return { text: (el.textContent ?? "").trim(), size: cs.fontSize, numeric: cs.fontVariantNumeric, color: cs.color, ratio: ratio(rgba(cs.color), [14, 15, 12]) };
        }),
        particles: Number(document.querySelector<HTMLElement>("[data-testid='table-bokeh']")?.dataset.particles ?? 0),
      };
    });
    console.log(`[r4 ${vp.tag}] ${JSON.stringify(m)}`);
    // Ventall: 2 cartes a −4° / +4° (data i transform calculat).
    expect(m.rot).toEqual([-4, 4]);
    for (const [i, a] of m.angle.entries()) expect(Math.abs(a - m.rot[i]!), `angle carta ${i}`).toBeLessThanOrEqual(0.6);
    // Sense panell: ni fons, ni filet, ni ombra, ni capes de torn.
    expect(m.panel.bg).toBe("rgba(0, 0, 0, 0)");
    expect(m.panel.borderW === 0 || m.panel.borderAlpha === 0, "sense filet").toBe(true);
    expect(m.panel.shadow).toBe("none");
    expect(m.panel.before).toBe("0");
    expect(m.panel.after).toBe("0");
    // Res desborda.
    expect(m.scrollW).toBeLessThanOrEqual(m.vw);
    expect(m.scrollH).toBeLessThanOrEqual(m.vh);
    expect(m.outside, "cartes dins de la pantalla").toBe(0);
    // Pals grans: 4 i 3 pips, cada un ≥ 17 % de l'amplada de la carta.
    expect(m.pips.map((p) => p.n)).toEqual([4, 3]);
    for (const p of m.pips) expect(p.pipPct).toBeGreaterThanOrEqual(17);
    // Aposta i saldo: 12 px, tabulars, discrets però AA sobre el fons nit.
    expect(m.bet.length).toBe(2);
    for (const b of m.bet) {
      expect(b.size).toBe("12px");
      expect(b.numeric).toMatch(/tabular-nums/);
      expect(b.ratio, `contrast «${b.text}»`).toBeGreaterThanOrEqual(4.5);
      expect(b.ratio, `discret «${b.text}»`).toBeLessThanOrEqual(9);
    }
    if (vp.width === 390) expect(m.particles, "més pols a 390").toBeGreaterThanOrEqual(40);
    await ctx.close();
  });
}

for (const reduce of [false, true]) {
  test(`taula v2 · retoc 4 · taula gran: el 7½ propi no es mostra durant la jugada${reduce ? " (moviment reduït)" : ""}`, async ({ browser }) => {
    const { ctx, page } = await openTurn(browser, { width: 390, height: 844 }, [7], { reduce });
    await page.getByTestId("action-hit").click();
    await expect(page.getByTestId("local-hand-card")).toHaveCount(2, { timeout: 5_000 });
    await page.waitForTimeout(700);
    await expect(page.getByTestId("my-hand-points")).toHaveCount(0);
    await expect(page.locator(".hero-score")).toHaveCount(0);
    await ctx.close();
  });
}

test("taula v2 · retoc 4 · 1280 · seients, BANK, History i POT sense or", async ({ browser }) => {
  const { ctx, page } = await openTurn(browser, { width: 1280, height: 800 }, [1], { desktop: true });
  const golds = await page.evaluate((allowed) => {
    const out: string[] = [];
    const gold = (c: string) => {
      const m = (c.match(/[\d.]+/g) ?? []).map(Number);
      if (m.length < 3 || (m[3] ?? 1) < 0.05) return false;
      const [r, g, b] = [m[0]! / 255, m[1]! / 255, m[2]! / 255];
      const max = Math.max(r, g, b);
      const min = Math.min(r, g, b);
      const l = (max + min) / 2;
      const d = max - min;
      if (d < 0.08) return false;
      const sat = d / (1 - Math.abs(2 * l - 1));
      let h = 0;
      if (max === r) h = 60 * (((g - b) / d) % 6);
      else if (max === g) h = 60 * ((b - r) / d + 2);
      else h = 60 * ((r - g) / d + 4);
      if (h < 0) h += 360;
      return h >= 28 && h <= 62 && sat >= 0.25 && l >= 0.2 && l <= 0.88;
    };
    for (const el of document.querySelectorAll<HTMLElement>(".game-table-root *")) {
      if (el.closest(".spanish-card, svg, [data-testid='table-bokeh']") || el.matches(allowed)) continue;
      const r = el.getBoundingClientRect();
      if (!r.width || !r.height) continue;
      const cs = getComputedStyle(el);
      if (cs.visibility === "hidden" || Number(cs.opacity) === 0) continue;
      const hasText = [...el.childNodes].some((n) => n.nodeType === 3 && (n.textContent ?? "").trim());
      const paints = [cs.backgroundColor, ...(hasText ? [cs.color] : [])];
      if (parseFloat(cs.borderTopWidth) > 0 && cs.borderTopStyle !== "none") paints.push(cs.borderTopColor);
      for (const p of paints) if (gold(p)) out.push(`${el.tagName.toLowerCase()}.${String(el.className).slice(0, 50)} «${(el.textContent ?? "").trim().slice(0, 16)}» ${p}`);
    }
    return [...new Set(out)];
  }, V2_GOLD_EXCEPTIONS);
  console.log(`[r4 1280] or: ${JSON.stringify(golds)}`);
  const shot = process.env.SETIMIG_V2_SHOT_R4_DESKTOP;
  if (shot) await page.screenshot({ path: shot });
  expect(golds, "cap or a la taula d'escriptori").toEqual([]);
  // BANK: insígnia ivori amb contrast AA.
  const bank = await page.evaluate(() => {
    const seat = document.querySelector<HTMLElement>("[data-seat-banker='true']");
    const badge = seat ? [...seat.querySelectorAll<HTMLElement>("span")].find((s) => /^bank$/i.test((s.textContent ?? "").trim())) : null;
    return badge ? { color: getComputedStyle(badge).color, bg: getComputedStyle(badge).backgroundColor } : null;
  });
  console.log(`[r4 1280] BANK ${JSON.stringify(bank)}`);
  await ctx.close();
});
