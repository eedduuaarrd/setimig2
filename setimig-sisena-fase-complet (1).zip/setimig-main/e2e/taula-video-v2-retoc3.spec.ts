import AxeBuilder from "@axe-core/playwright";
import { expect, test, type Browser, type Page } from "@playwright/test";
import { E2E_ACCOUNT_IDS, e2ePoolId, seedE2eLaunch } from "./helpers/e2eSession.ts";
import { playerTurnSnapshot } from "./helpers/jugabilitatV1Fixtures.ts";
import { V2_GOLD_EXCEPTIONS, scanColors } from "./helpers/jugabilitatV2Probes.ts";

/**
 * Taula v2 · retoc 3 (kit v2-spec): STAND/HIT ivori (or només en tocar), un sol or #D4AF6A (barra «Bust», anella,
 * «Stands 7½», CTA), xifres en Cormorant 600 lining/tabular i Fraunces només a la puntuació gran, esclat daurat
 * al 7½ (una vegada, res amb moviment reduït), centelleig del bokeh per grups (CSS) i el subtítol de HIT a 1280.
 * Partida local seeded (sense socket): 7 a la mà i el mall només dona figures (½) → HIT porta a 7½.
 * Captures opcionals: SETIMIG_V2_SHOT_BURST (enmig de l'esclat).
 */
const AGE_OK = () => JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" });
const GOLD = "rgb(212, 175, 106)";
const IVORY = "rgb(245, 242, 235)";
const INK = "rgb(20, 19, 15)";
const SURFACE = "rgb(15, 16, 13)";

async function seedTurn(page: Page, pid: string, cards: number[], opts: { appReduce?: boolean } = {}) {
  pid = E2E_ACCOUNT_IDS.includes(pid) ? pid : e2ePoolId();
  await seedE2eLaunch(page, pid);
  await page.addInitScript(
    ({ snap, pid, age, appReduce }) => {
      if (sessionStorage.getItem("r3_seeded") === "1") return;
      sessionStorage.setItem("r3_seeded", "1");
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", "Edu");
      localStorage.setItem("setimig.locale", "en");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_table_tutorial_v1", "1");
      localStorage.setItem("setimig_house_rules_enabled", "1");
      localStorage.setItem("setimig_age_gate", age);
      localStorage.setItem("setimig_local_solo_snapshot", snap);
      if (appReduce) localStorage.setItem("setimig_reduce_motion", "1");
      sessionStorage.setItem("setimig_solo_rejoin", "1");
      sessionStorage.setItem("setimig_solo_local", "1");
    },
    { snap: playerTurnSnapshot(pid, "Edu", cards), pid, age: AGE_OK(), appReduce: !!opts.appReduce }
  );
  await page.route("**/socket.io/**", (route) => route.abort());
  await page.goto("/");
  await expect(page.getByTestId("action-hit")).toBeEnabled({ timeout: 30_000 });
  await page.waitForTimeout(700);
}

/** Contrast WCAG del text (amb alfa, compost sobre el fons) contra el fons opac. */
async function contrastOf(page: Page, textSel: string, bgSel: string) {
  return page.evaluate(
    ({ textSel, bgSel }) => {
      const rgba = (c: string) => {
        const m = c.match(/[\d.]+/g)!.map(Number);
        return { r: m[0]!, g: m[1]!, b: m[2]!, a: m[3] ?? 1 };
      };
      const lum = (c: { r: number; g: number; b: number }) => {
        const f = (v: number) => {
          const x = v / 255;
          return x <= 0.03928 ? x / 12.92 : ((x + 0.055) / 1.055) ** 2.4;
        };
        return 0.2126 * f(c.r) + 0.7152 * f(c.g) + 0.0722 * f(c.b);
      };
      const t = document.querySelector<HTMLElement>(textSel)!;
      const b = document.querySelector<HTMLElement>(bgSel)!;
      const bg = rgba(getComputedStyle(b).backgroundColor);
      const fg = rgba(getComputedStyle(t).color);
      // Opacitat efectiva del text (ell i els avantpassats fins al botó).
      let op = 1;
      for (let el: HTMLElement | null = t; el && el !== b.parentElement; el = el.parentElement) op *= Number(getComputedStyle(el).opacity);
      const a = fg.a * op;
      const mix = { r: fg.r * a + bg.r * (1 - a), g: fg.g * a + bg.g * (1 - a), b: fg.b * a + bg.b * (1 - a) };
      const [L1, L2] = [lum(mix), lum(bg)];
      return { ratio: (Math.max(L1, L2) + 0.05) / (Math.min(L1, L2) + 0.05), opacity: op, fg: getComputedStyle(t).color, bg: getComputedStyle(b).backgroundColor, text: (t.textContent ?? "").trim() };
    },
    { textSel, bgSel }
  );
}

async function buttonStyles(page: Page) {
  return page.evaluate(() => {
    const s = (id: string) => {
      const el = document.querySelector<HTMLElement>(`[data-testid="${id}"]`)!;
      const cs = getComputedStyle(el);
      return { bg: cs.backgroundColor, bgImage: cs.backgroundImage, color: cs.color, border: `${cs.borderTopWidth} ${cs.borderTopStyle} ${cs.borderTopColor}`, radius: cs.borderTopLeftRadius };
    };
    return { hit: s("action-hit"), stand: s("action-stand") };
  });
}

test("taula v2 · retoc 3 · 390×844 · botons ivori, un sol or, xifres i esclat del 7½", async ({ page }) => {
  await page.addInitScript(() => {
    (window as unknown as { __cls: number }).__cls = 0;
    new PerformanceObserver((l) => {
      for (const e of l.getEntries() as (PerformanceEntry & { value: number; hadRecentInput: boolean })[])
        if (!e.hadRecentInput) (window as unknown as { __cls: number }).__cls += e.value;
    }).observe({ type: "layout-shift", buffered: true });
  });
  await seedTurn(page, e2ePoolId(), [7]);

  // 1) Botons: HIT ivori #F5F2EB amb tinta #14130F; STAND #0F100D amb vora ivori de 2 px; radi 6 px.
  const b = await buttonStyles(page);
  console.log(`[r3 390] botons ${JSON.stringify(b)}`);
  expect(b.hit.bg).toBe(IVORY);
  expect(b.hit.bgImage).toBe("none");
  expect(b.hit.color).toBe(INK);
  expect(b.hit.radius).toBe("6px");
  expect(b.stand.bg).toBe(SURFACE);
  expect(b.stand.border).toBe(`2px solid ${IVORY}`);
  expect(b.stand.color).toBe(IVORY);
  expect(b.stand.radius).toBe("6px");
  const cHit = await contrastOf(page, "[data-testid=action-hit]", "[data-testid=action-hit]");
  const cStand = await contrastOf(page, "[data-testid=action-stand]", "[data-testid=action-stand]");
  console.log(`[r3 390] contrast HIT ${cHit.ratio.toFixed(2)} STAND ${cStand.ratio.toFixed(2)}`);
  expect(cHit.ratio).toBeGreaterThanOrEqual(7);
  expect(cStand.ratio).toBeGreaterThanOrEqual(7);

  // 2) Taula gran (v147): ja no hi ha barra «Bust» (delatava els punts); cap altre groc/or.
  await expect(page.locator(".hero-bust-track, .hero-bust-fill")).toHaveCount(0);
  expect(await scanColors(page, { mode: "yellow", scope: ".game-table-root", allowGold: V2_GOLD_EXCEPTIONS }), "cap or fora de les excepcions").toEqual([]);
  const golds = await page.evaluate(() =>
    [...document.querySelectorAll<HTMLElement>(".game-table-root *")]
      .filter((el) => {
        const cs = getComputedStyle(el);
        return [cs.color, cs.backgroundColor, cs.borderTopColor].some((c) => /^rgba?\(212, 175, 55\b|^rgba?\(196, 163, 107\b|^rgba?\(200, 169, 107\b/.test(c));
      })
      .map((el) => String(el.className).slice(0, 40))
  );
  expect(golds, "cap #D4AF37, #C4A36B ni #C8A96B a la taula").toEqual([]);

  // 3) Xifres: Cormorant 600 lining + tabular; Fraunces només a la puntuació gran (subconjunt autoallotjat, petit).
  const fonts = await page.evaluate(async () => {
    await document.fonts.ready;
    const f = (sel: string) => {
      const el = document.querySelector<HTMLElement>(sel);
      if (!el) return null;
      const cs = getComputedStyle(el);
      return { family: cs.fontFamily, weight: cs.fontWeight, numeric: cs.fontVariantNumeric };
    };
    const fr = performance.getEntriesByType("resource").find((e) => /fraunces-500-score.*\.woff2/.test(e.name)) as PerformanceResourceTiming | undefined;
    // Vite inclou els fitxers < 4 KB com a data: URL dins del CSS: llavors el pes és el del base64 descodificat.
    let inlinedBytes = -1;
    for (const sheet of [...document.styleSheets]) {
      let rules: CSSRule[] = [];
      try {
        rules = [...sheet.cssRules];
      } catch {
        continue;
      }
      for (const r of rules) {
        if (r instanceof CSSFontFaceRule && /Fraunces Score/.test(r.style.getPropertyValue("font-family"))) {
          const m = r.style.getPropertyValue("src").match(/base64,([A-Za-z0-9+/=]+)/);
          if (m) inlinedBytes = Math.round((m[1]!.length * 3) / 4);
        }
      }
    }
    const frauncesUsers = [...document.querySelectorAll<HTMLElement>("body *")].filter((el) => /Fraunces/.test(getComputedStyle(el).fontFamily)).map((el) => el.className.toString().slice(0, 30));
    return {
      score: f(".hero-score"),
      pct: f(".hero-bust-pct"),
      bet: f(".v2-seat-bet"),
      pot: f(".v2-pot-amount"),
      frauncesLoaded: document.fonts.check('500 96px "Fraunces Score"', "7½"),
      frauncesBytes: fr ? fr.encodedBodySize || fr.transferSize : inlinedBytes,
      frauncesUsers,
    };
  });
  console.log(`[r3 390] fonts ${JSON.stringify(fonts)}`);
  // Taula gran (v147): sense puntuació gran durant la jugada; Fraunces només hi podria ser a la puntuació (liquidació).
  expect(fonts.score).toBeFalsy();
  expect(fonts.pct).toBeFalsy();
  for (const c of fonts.frauncesUsers) expect(c, "Fraunces només a la puntuació gran").toMatch(/^hero-score/);
  for (const k of ["pct", "bet", "pot"] as const) {
    const v = fonts[k];
    if (!v) continue;
    expect(v.family, k).toMatch(/Cormorant Garamond/);
    expect(v.weight, k).toBe("600");
    expect(v.numeric, k).toMatch(/lining-nums/);
    expect(v.numeric, k).toMatch(/tabular-nums/);
  }

  // 4) Toc: escala .94 + anella daurada (≤ 400 ms) i, a STAND, tint daurat (opacitat). Sense clicar (pointerdown).
  const press = await page.evaluate(async () => {
    const btn = document.querySelector<HTMLButtonElement>("[data-testid=action-stand]")!;
    btn.dispatchEvent(new PointerEvent("pointerdown", { bubbles: true, pointerType: "touch", isPrimary: true }));
    await new Promise((r) => requestAnimationFrame(() => r(null)));
    const ripple = btn.querySelector<HTMLElement>(".v2-ripple")!;
    const pressedNow = btn.classList.contains("v2-pressed");
    const anims = btn.getAnimations({ subtree: true }).map((a) => ({
      name: (a as CSSAnimation).animationName ?? "transition",
      dur: Number((a.effect?.getTiming().duration as number) ?? 0),
    }));
    const rippleBorder = getComputedStyle(ripple).borderTopColor;
    const tint = getComputedStyle(btn, "::after").backgroundColor;
    // L'escala .94 entra amb una transició de 100 ms: es llegeix quan ja ha acabat (el toc dura 450 ms).
    await new Promise((r) => setTimeout(r, 180));
    return {
      pressed: pressedNow,
      transform: getComputedStyle(btn).transform,
      rippleBorder,
      tint,
      anims,
    };
  });
  console.log(`[r3 390] toc ${JSON.stringify(press)}`);
  expect(press.pressed).toBe(true);
  expect(press.transform).toMatch(/^matrix\(0\.94, 0, 0, 0\.94/);
  expect(press.rippleBorder).toBe(GOLD);
  expect(press.tint).toBe("rgba(212, 175, 106, 0.4)");
  expect(press.anims.map((a) => a.name)).toEqual(expect.arrayContaining(["v2-ripple", "v2-tint"]));
  // Retoc 4: anella 480 ms i tint 700 ms com al kit (excepció aprovada); la resta ≤ 400 ms.
  const limit: Record<string, number> = { "v2-ripple": 480, "v2-tint": 700 };
  for (const a of press.anims) expect(a.dur, a.name).toBeLessThanOrEqual(limit[a.name] ?? 400);
  await page.waitForTimeout(800);

  // 5) Esclat daurat al 7½: HIT (7 + ½) → raigs #D4AF6A, transform/opacity ≤ 400 ms, sense CLS ni clics, una vegada.
  const clsBefore = await page.evaluate(() => (window as unknown as { __cls: number }).__cls);
  await page.getByTestId("action-hit").click();
  const burst = page.getByTestId("v2-seven-burst");
  await expect(burst).toHaveCount(1, { timeout: 5_000 });
  const bm = await page.evaluate(() => {
    const el = document.querySelector<HTMLElement>("[data-testid=v2-seven-burst]")!;
    const rays = [...el.querySelectorAll<HTMLElement>(".v2-burst-ray")];
    const anims = el.getAnimations({ subtree: true });
    const props = new Set<string>();
    for (const a of anims) for (const k of (a.effect as KeyframeEffect).getKeyframes()) for (const p of Object.keys(k)) if (!["offset", "easing", "composite", "computedOffset"].includes(p)) props.add(p);
    return {
      rays: rays.length,
      color: getComputedStyle(rays[0]!).backgroundColor,
      pe: getComputedStyle(el).pointerEvents,
      position: getComputedStyle(el).position,
      maxDur: Math.max(...anims.map((a) => Number(a.effect?.getTiming().duration ?? 0))),
      props: [...props].sort(),
      score: (document.querySelector("[data-testid=my-hand-points]")?.textContent ?? "").trim(),
    };
  });
  console.log(`[r3 390] esclat ${JSON.stringify(bm)}`);
  expect(bm.score, "taula gran: cap total propi").toBe("");
  expect(bm.rays).toBeGreaterThanOrEqual(6);
  expect(bm.color).toBe(GOLD);
  expect(bm.pe).toBe("none");
  expect(bm.position).toBe("absolute");
  expect(bm.maxDur).toBeLessThanOrEqual(400);
  expect(bm.props).toEqual(["opacity", "transform"]);
  const burstShot = process.env.SETIMIG_V2_SHOT_BURST;
  if (burstShot) {
    await page.waitForTimeout(110);
    await page.screenshot({ path: burstShot });
  }
  await expect(burst).toHaveCount(0, { timeout: 2_000 });
  await page.waitForTimeout(800);
  await expect(burst, "una sola vegada per 7½").toHaveCount(0);
  const clsAfter = await page.evaluate(() => (window as unknown as { __cls: number }).__cls);
  console.log(`[r3 390] CLS esclat ${(clsAfter - clsBefore).toFixed(4)} (total ${clsAfter.toFixed(4)})`);
  expect(clsAfter - clsBefore).toBeLessThanOrEqual(0.01);
  // Taula gran (v147): el total propi no es mostra durant la jugada.
  await expect(page.getByTestId("my-hand-points")).toHaveCount(0);

  const axe = await new AxeBuilder({ page }).analyze();
  const serious = axe.violations.filter((v) => v.impact === "serious" || v.impact === "critical");
  expect(serious.map((v) => `${v.id}: ${v.nodes.map((n) => n.target.join(" ")).join(", ")}`)).toEqual([]);
});

for (const mode of ["sistema", "app"] as const) {
  test(`taula v2 · retoc 3 · moviment reduït (${mode}): cap esclat, cap anella, cap escala, bokeh quiet`, async ({ browser }) => {
    const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, locale: "en-US", colorScheme: "dark", reducedMotion: mode === "sistema" ? "reduce" : "no-preference" });
    const page = await ctx.newPage();
    await seedTurn(page, e2ePoolId(), [7], { appReduce: mode === "app" });
    const press = await page.evaluate(async () => {
      const btn = document.querySelector<HTMLButtonElement>("[data-testid=action-stand]")!;
      btn.dispatchEvent(new PointerEvent("pointerdown", { bubbles: true, pointerType: "touch", isPrimary: true }));
      await new Promise((r) => requestAnimationFrame(() => r(null)));
      return {
        transform: getComputedStyle(btn).transform,
        anims: btn.getAnimations({ subtree: true }).filter((a) => "animationName" in a).map((a) => (a as CSSAnimation).animationName),
      };
    });
    expect(press.transform).toBe("none");
    expect(press.anims).toEqual([]);
    await page.waitForTimeout(500);
    await page.getByTestId("action-hit").click();
    await expect(page.getByTestId("local-hand-card")).toHaveCount(2, { timeout: 5_000 });
    await expect(page.getByTestId("my-hand-points")).toHaveCount(0);
    for (let i = 0; i < 6; i++) {
      expect(await page.getByTestId("v2-seven-burst").count(), "sense esclat").toBe(0);
      await page.waitForTimeout(100);
    }
    const bokehAnims = await page.evaluate(() =>
      [...document.querySelectorAll<HTMLElement>("[data-testid='table-bokeh'] *")].reduce((n, el) => n + el.getAnimations().filter((a) => "animationName" in a).length, 0)
    );
    expect(bokehAnims, "bokeh sense centelleig").toBe(0);
    await ctx.close();
  });
}

/** 1280: taula gran (v147) → HIT sense subtítol de probabilitat (delatava els punts); colors dels botons iguals. */
test("taula v2 · retoc 3 · 1280 · HIT sense subtítol de probabilitat", async ({ browser }) => {
  for (const cards of [[1], [6]]) {
    const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 1, locale: "en-US", colorScheme: "dark" });
    const page = await ctx.newPage();
    await seedTurn(page, e2ePoolId(), cards);
    await page.waitForTimeout(500);
    await expect(page.getByTestId("hit-bust-risk-desktop")).toHaveCount(0);
    expect(await page.getByTestId("action-hit").innerText()).not.toMatch(/%|safe card/i);
    const b = await buttonStyles(page);
    expect(b.hit.bg).toBe(IVORY);
    expect(b.hit.color).toBe(INK);
    expect(b.stand.bg).toBe(SURFACE);
    expect(b.stand.border).toBe(`2px solid ${IVORY}`);
    await ctx.close();
  }
});

/** Rendiment: fil principal durant 8 s a 390×844 amb la CPU ×4 (torn propi, bokeh + centelleig actius). */
async function mainThreadMs(browser: Browser) {
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 3, isMobile: true, hasTouch: true, locale: "en-US", colorScheme: "dark" });
  const page = await ctx.newPage();
  await seedTurn(page, e2ePoolId(), [1]);
  await expect.poll(() => page.getByTestId("table-bokeh").getAttribute("data-particles").then(Number), { timeout: 5_000 }).toBeGreaterThan(0);
  await page.waitForTimeout(2_000);
  const cdp = await ctx.newCDPSession(page);
  await cdp.send("Performance.enable");
  await cdp.send("Emulation.setCPUThrottlingRate", { rate: 4 });
  await page.waitForTimeout(1_000);
  const get = async () => {
    const { metrics } = await cdp.send("Performance.getMetrics");
    const m = Object.fromEntries(metrics.map((x) => [x.name, x.value]));
    return { task: m.TaskDuration ?? 0, script: m.ScriptDuration ?? 0, layout: m.LayoutDuration ?? 0, style: m.RecalcStyleDuration ?? 0 };
  };
  const a = await get();
  await page.waitForTimeout(8_000);
  const z = await get();
  const info = await page.evaluate(() => {
    const l = document.querySelector<HTMLElement>("[data-testid='table-bokeh']")!;
    return { canvases: l.querySelectorAll("canvas").length, static: l.dataset.static, anims: l.getAnimations({ subtree: true }).length };
  });
  await ctx.close();
  return {
    taskMs: Math.round((z.task - a.task) * 1000),
    scriptMs: Math.round((z.script - a.script) * 1000),
    layoutMs: Math.round((z.layout - a.layout) * 1000),
    styleMs: Math.round((z.style - a.style) * 1000),
    ...info,
  };
}

test("taula v2 · retoc 3 · rendiment 8 s a 390×844 amb CPU ×4", async ({ browser }) => {
  // Depèn de la màquina: només amb SETIMIG_V2_PERF=1 (mesura comparada amb el bloc 3 a la mateixa màquina).
  test.skip(process.env.SETIMIG_V2_PERF !== "1", "mesura de rendiment opcional");
  const runs = [];
  for (let i = 0; i < 3; i++) runs.push(await mainThreadMs(browser));
  for (const r of runs) console.log(`[r3 perf] ${JSON.stringify(r)}`);
  const med = runs.map((r) => r.taskMs).sort((x, y) => x - y)[1]!;
  console.log(`[r3 perf] mediana TaskDuration ${med} ms / 8 s`);
  const budget = Number(process.env.SETIMIG_V2_PERF_BUDGET_MS ?? 173);
  expect(med, `fil principal ≤ ${budget} ms / 8 s (bloc 3: 125–143 ms + 30)`).toBeLessThanOrEqual(budget);
});
