import fs from "fs";
import path from "path";
import { expect, test, type Page } from "@playwright/test";
import { playUntilSettlement } from "./helpers/tableFlow";

/** #209 contra el servidor real. Saldos sembrats per playwright.saldo-buyin-real.config.ts. */

const MOBILE = { width: 390, height: 844 } as const;

async function enterLobby(page: Page, name: string, playerId: string) {
  await page.addInitScript(
    ({ id, n }: { id: string; n: string }) => {
      localStorage.setItem("setimig.locale", "en");
      localStorage.setItem("setimig_player_id", id);
      localStorage.setItem("setimig_player_name", n);
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem(
        "setimig_age_gate",
        JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
      );
    },
    { id: playerId, n: name }
  );
  await page.goto("/");
  await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 30_000 });
}

async function startNormalSolo(page: Page) {
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  await page.getByTestId("ai-bot-count-1").click();
  await page.getByTestId("ai-bot-picker-start").click();
}

test("saldo 0 (servidor real): oferta de pràctica i partida de pràctica", async ({ page }) => {
  await page.setViewportSize(MOBILE);
  await enterLobby(page, "RealZero", "buyinreal0zero");
  await expect(page.getByTestId("header-balance-chip")).toHaveAttribute("aria-label", /Balance: 0 chips/);
  await startNormalSolo(page);
  await expect(page.getByTestId("no-balance-dialog")).toBeVisible({ timeout: 15_000 });
  await page.getByTestId("no-balance-practice").click();
  await expect(page.getByTestId("bet-balance")).toContainText("Practice chips", { timeout: 30_000 });
  await expect(page.getByText(/Buy-in of/)).toHaveCount(0);
});

test("saldo parcial (servidor real): seu amb 750, avís amb l'import real i saldo del servidor", async ({ page }) => {
  await page.setViewportSize(MOBILE);
  await enterLobby(page, "RealPart", "buyinreal0part");
  await expect(page.getByTestId("header-balance-chip")).toHaveAttribute("aria-label", /Balance: 750 chips/);
  await startNormalSolo(page);
  await expect(page.getByTestId("no-balance-dialog")).toHaveCount(0);
  // Avís (toast) amb l'import real de la compra: min(2.000, 750) = 750.
  await expect(
    page.getByRole("status").filter({ hasText: "Buy-in of 750 chips from your balance; your result is credited when you leave." })
  ).toBeVisible({ timeout: 15_000 });
  await expect(page.getByTestId("bet-balance")).toContainText("750", { timeout: 30_000 });
  // Sortir abans d'apostar: el servidor abona les 750 fitxes i la capçalera les llegeix del servidor.
  await page.getByRole("button", { name: "Leave game" }).click();
  await page.getByRole("button", { name: "Confirm leaving the game" }).click();
  await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 15_000 });
  await expect(page.getByTestId("header-balance-chip")).toHaveAttribute("aria-label", /Balance: 750 chips/, {
    timeout: 10_000,
  });
});

/** Saldo desat pel servidor (balances.json del directori de dades de la tanda E2E). */
function savedBalance(playerId: string): number | null {
  const dir = process.env.SETIMIG_E2E_DATA_DIR;
  if (!dir) throw new Error("SETIMIG_E2E_DATA_DIR no definit");
  try {
    const store = JSON.parse(fs.readFileSync(path.join(dir, "balances.json"), "utf8")) as {
      accounts: Record<string, { chips: number }>;
    };
    return store.accounts[playerId]?.chips ?? null;
  } catch {
    return null;
  }
}

/** Últim saldo que el client ha llegit del servidor (/api/balance): el que mostra la capçalera. */
function trackFetchedBalance(page: Page): () => number | null {
  let chips: number | null = null;
  page.on("response", async (response) => {
    if (!response.url().includes("/api/balance")) return;
    try {
      const body = (await response.json()) as { chips?: number };
      if (typeof body.chips === "number") chips = body.chips;
    } catch {
      /* resposta no JSON */
    }
  });
  return () => chips;
}

function headerBalance(page: Page) {
  return page.getByTestId("header-balance-chip");
}

async function leaveToLobby(page: Page) {
  await page.getByRole("button", { name: "Leave game" }).click();
  await page.getByRole("button", { name: "Confirm leaving the game" }).click();
  await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 15_000 });
}

/** Fitxes de taula del jugador segons l'última vista de sala que ha enviat el servidor. */
function trackTableChips(page: Page, name: string): () => number | null {
  let chips: number | null = null;
  page.on("websocket", (ws) => {
    ws.on("framereceived", ({ payload }) => {
      const text = typeof payload === "string" ? payload : "";
      if (!text.startsWith("42[")) return;
      try {
        const [event, data] = JSON.parse(text.slice(2)) as [string, { players?: { name: string; chips: number; isBot?: boolean }[] }];
        if (event !== "room_update" && event !== "joined_room") return;
        const me = data?.players?.find((p) => !p.isBot && p.name === name);
        if (me && typeof me.chips === "number") chips = me.chips;
      } catch {
        /* altres missatges */
      }
    });
  });
  return () => chips;
}

test("24.500: en seure 22.500 (compra de 2.000) i, en sortir sense jugar, 24.500", async ({ page }) => {
  await page.setViewportSize(MOBILE);
  const fetched = trackFetchedBalance(page);
  await enterLobby(page, "RealFull", "buyinreal0full");
  await expect(headerBalance(page)).toHaveAttribute("aria-label", /Balance: 24,500 chips/);
  await startNormalSolo(page);
  await expect(page.getByTestId("bet-balance")).toContainText("2,000", { timeout: 30_000 });
  await expect.poll(() => savedBalance("buyinreal0full"), { timeout: 10_000 }).toBe(22_500);
  // A la taula la capçalera no es veu: el client ha tornat a llegir el saldo del servidor en seure.
  await expect.poll(fetched, { timeout: 10_000 }).toBe(22_500);
  await leaveToLobby(page);
  await expect.poll(() => savedBalance("buyinreal0full"), { timeout: 10_000 }).toBe(24_500);
  await expect(headerBalance(page)).toHaveAttribute("aria-label", /Balance: 24,500 chips/, { timeout: 10_000 });
});

test("24.500: en sortir després de jugar una mà, 22.500 (+ premis d'assoliments) + fitxes finals verificades", async ({ page }) => {
  test.setTimeout(200_000);
  await page.setViewportSize(MOBILE);
  const tableChips = trackTableChips(page, "RealPlay");
  await enterLobby(page, "RealPlay", "buyinreal0play");
  await startNormalSolo(page);
  await expect.poll(() => savedBalance("buyinreal0play"), { timeout: 30_000 }).toBe(22_500);
  await playUntilSettlement(page);
  // Fitxes finals: les de la mà següent abans d'apostar (panell d'aposta); si el jugador fa de
  // banca i no n'hi ha, l'última vista de sala del servidor.
  const betBalance = page.getByTestId("bet-balance");
  const shown = await betBalance
    .waitFor({ state: "visible", timeout: 60_000 })
    .then(async () => Number((await betBalance.locator("strong").innerText()).replace(/[^0-9]/g, "")))
    .catch(() => null);
  const finalChips = shown ?? tableChips();
  expect(finalChips).not.toBeNull();
  // Els assoliments i missions del servidor (p. ex. «Primera victòria», +500) s'abonen al saldo
  // real en liquidar la mà, amb la taula oberta. El saldo desat abans de sortir és 22.500 + aquests
  // premis; en sortir s'hi suma exactament el resultat verificat (les fitxes finals de la taula).
  const beforeLeave = savedBalance("buyinreal0play");
  expect(beforeLeave).not.toBeNull();
  expect(beforeLeave!).toBeGreaterThanOrEqual(22_500);
  await leaveToLobby(page);
  const expected = beforeLeave! + finalChips!;
  await expect.poll(() => savedBalance("buyinreal0play"), { timeout: 10_000 }).toBe(expected);
  await expect(headerBalance(page)).toHaveAttribute(
    "aria-label",
    new RegExp(`Balance: ${expected.toLocaleString("en-US")} chips`),
    { timeout: 10_000 }
  );
});
