import AxeBuilder from "@axe-core/playwright";
import { expect, test, type Page } from "@playwright/test";

/**
 * Millores de nit (millores-nit.md) · P0 de client, només mesures (sense captures):
 * - C1: el teu torn poc carregat: ≤ 30 textos, cap text repetit fora dels seients, cap hora, res < 12 px, ≥ 35 % buit.
 * - C2: un sol estat que se substitueix: mai «…» + «Et toca» encadenats; «registrada» desapareix abans de 2,5 s.
 * - C3: l'última acció s'esborra en començar cada mà.
 */
const VIEWPORTS = [
  { tag: "375x667", width: 375, height: 667 },
  { tag: "390x844", width: 390, height: 844 },
] as const;

async function seedLobby(page: Page, id: string) {
  await page.addInitScript((pid) => {
    localStorage.setItem("setimig_player_id", pid);
    localStorage.setItem("setimig_player_name", "Nit");
    localStorage.setItem("setimig_onboarding_v1", "1");
    localStorage.setItem("setimig_interactive_tutorial_v1", "1");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
    // C2: registra qualsevol estat encadenat («Plantant-se… Et toca …») a la regió viva o a la pantalla.
    const w = window as unknown as { __chained: string[] };
    w.__chained = [];
    const check = () => {
      const live = document.querySelector("[data-testid=game-live-region]")?.textContent ?? "";
      const body = document.body?.innerText ?? "";
      for (const text of [live, body]) {
        const m = text.match(/…\s*Et toca[^\n]{0,40}/);
        if (m) w.__chained.push(m[0]);
      }
    };
    const start = () =>
      new MutationObserver(check).observe(document.documentElement, { subtree: true, childList: true, characterData: true });
    if (document.documentElement) start();
    else document.addEventListener("DOMContentLoaded", start);
  }, id);
}

type TurnMetrics = {
  texts: string[];
  repeated: string[];
  clock: string[];
  small: string[];
  emptyPct: number;
  statusToasts: number;
};

/** Textos visibles reals: exclou sr-only (lectors de pantalla) i l'art SVG de les cartes (aria-hidden). */
async function turnMetrics(page: Page): Promise<TurnMetrics> {
  return page.evaluate(() => {
    const visible = (el: Element) => {
      const r = el.getBoundingClientRect();
      const s = getComputedStyle(el);
      return r.width > 1 && r.height > 1 && s.visibility !== "hidden" && Number(s.opacity) > 0.05 && r.bottom > 0 && r.top < innerHeight;
    };
    const srOnly = (el: Element) => !!el.closest(".sr-only");
    const leaves = [...document.querySelectorAll("body *")].filter(
      (el) =>
        !(el instanceof SVGElement) &&
        !srOnly(el) &&
        visible(el) &&
        [...el.childNodes].some((n) => n.nodeType === 3 && (n.textContent ?? "").trim())
    );
    const textOf = (el: Element) => ((el as HTMLElement).innerText || el.textContent || "").trim().replace(/\s+/g, " ");
    const texts = leaves.map(textOf);
    // Repetits fora dels seients (cada seient té les seves dades: dues apostes iguals no són repetició).
    const nonSeat = leaves.filter((el) => !el.closest("[data-seat-player], [data-testid=local-player-seat]")).map(textOf);
    const counts = nonSeat.reduce<Record<string, number>>((acc, t) => ((acc[t] = (acc[t] ?? 0) + 1), acc), {});
    const repeated = Object.entries(counts).filter(([t, n]) => n > 1 && t.length > 2).map(([t, n]) => `${t}×${n}`);
    const clock = texts.filter((t) => /^\d{2}:\d{2}$/.test(t));
    const small = leaves
      .map((el) => ({ t: textOf(el).slice(0, 30), px: parseFloat(getComputedStyle(el).fontSize) }))
      .filter((x) => x.px < 12)
      .map((x) => `${x.t}@${x.px}px`);
    let filled = 0;
    let n = 0;
    for (let x = 4; x < innerWidth; x += 12) {
      for (let y = 4; y < innerHeight; y += 12) {
        n += 1;
        const el = document.elementFromPoint(x, y);
        if (!el) continue;
        const content =
          !!el.closest("button, svg, img, canvas, input, summary, [role=button]") ||
          [...el.childNodes].some((c) => c.nodeType === 3 && (c.textContent ?? "").trim());
        if (content) filled += 1;
      }
    }
    const statusToasts = [...document.querySelectorAll(".casino-toast")].filter(visible).length;
    return { texts, repeated, clock, small, emptyPct: Math.round(100 - (filled / n) * 100), statusToasts };
  });
}

/**
 * Última acció de la mà. Taula v2 (retoc 1): al mòbil vertical ja no hi ha la tira «Accions»; la mateixa
 * `latestAction` es publica a la regió viva (sr-only), que és la font que també llegeixen els lectors de pantalla.
 */
const latestSummary = (page: Page) =>
  page.getByTestId("game-action-live-region").textContent().then((t) => t ?? "").catch(() => "");

for (const vp of VIEWPORTS) {
  test(`millores de nit P0 · C1–C3 (${vp.tag})`, async ({ page }) => {
    await page.setViewportSize({ width: vp.width, height: vp.height });
    await seedLobby(page, `nitp0-${vp.width}-${Date.now()}`);
    await page.goto("/");
    // Lobby v4.1 (#181): «Jugar» ja no obre el diàleg; la línia de context sí.
    await page.getByTestId("lobby-context").click();
    await page.getByTestId("ai-bot-count-3").click();
    await page.getByRole("button", { name: "Començar" }).click();

    let turnsMeasured = 0;
    let betsChecked = 0;
    let handStarts = 0;
    let axeDone = false;
    const deadline = Date.now() + 150_000;
    while (Date.now() < deadline && (turnsMeasured < 2 || betsChecked < 2 || handStarts < 2)) {
      const bet = page.getByTestId("bet-confirm");
      if ((await bet.isVisible().catch(() => false)) && (await bet.isEnabled().catch(() => false))) {
        await bet.click({ timeout: 2_000 }).catch(() => {});
        // C2: l'avis d'aposta registrada no es queda: als 2,5 s ja no hi és (ni visible ni a la regió sr-only).
        await page.waitForTimeout(2_500);
        await expect(page.getByText(/registrada/)).toHaveCount(0);
        betsChecked += 1;
        continue;
      }
      const stand = page.getByTestId("action-stand");
      const hit = page.getByTestId("action-hit");
      if ((await stand.isVisible().catch(() => false)) && (await hit.isVisible().catch(() => false)) && (await stand.isEnabled().catch(() => false))) {
        await page.waitForTimeout(450);
        if (await stand.isVisible().catch(() => false)) {
          const m = await turnMetrics(page);
          console.log(`[${vp.tag}] torn: ${m.texts.length} textos, buit ${m.emptyPct} %, repetits ${JSON.stringify(m.repeated)}, petits ${JSON.stringify(m.small)}`);
          expect(m.texts.length, `C1 textos: ${m.texts.join(" | ")}`).toBeLessThanOrEqual(30);
          expect(m.repeated, "C1 cap text repetit").toEqual([]);
          expect(m.clock, "C1 cap hora").toEqual([]);
          expect(m.small, "C1 res < 12 px").toEqual([]);
          expect(m.emptyPct, "C1 espai buit").toBeGreaterThanOrEqual(35);
          expect(m.statusToasts, "C2 un sol estat").toBeLessThanOrEqual(1);
          expect(await page.locator("[data-testid=game-live-region]").textContent()).not.toMatch(/…\s*\S/);
          if (!axeDone) {
            const axe = await new AxeBuilder({ page }).analyze();
            expect(axe.violations.map((v) => v.id)).toEqual([]);
            axeDone = true;
          }
          turnsMeasured += 1;
          await stand.click({ timeout: 2_000 }).catch(() => {});
          await page.waitForTimeout(300);
          continue;
        }
      }
      const next = page.getByTestId("settlement-next-hand");
      if ((await next.isVisible().catch(() => false)) && (await next.isEnabled().catch(() => false))) {
        const before = (await latestSummary(page)).trim();
        await next.click({ timeout: 2_000 }).catch(() => {});
        await page.waitForTimeout(500);
        const after = (await latestSummary(page)).trim();
        console.log(`[${vp.tag}] mà nova: «${before}» → «${after}»`);
        // C3: la línia d'accions no arrossega l'última acció de la mà anterior.
        if (before && before !== "Cronologia de la mà") expect(after).not.toBe(before);
        handStarts += 1;
        continue;
      }
      await page.waitForTimeout(150);
    }
    expect(turnsMeasured, "torns mesurats").toBeGreaterThanOrEqual(2);
    expect(betsChecked, "apostes comprovades").toBeGreaterThanOrEqual(2);
    expect(handStarts, "mans noves").toBeGreaterThanOrEqual(2);
    const chained = await page.evaluate(() => (window as unknown as { __chained: string[] }).__chained);
    expect(chained, "C2 cap estat encadenat").toEqual([]);
  });
}
