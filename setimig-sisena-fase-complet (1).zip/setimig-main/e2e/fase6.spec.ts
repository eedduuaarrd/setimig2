import { test, expect } from "@playwright/test";
import { e2ePoolId, seedE2eLaunch } from "./helpers/e2eSession.ts";
import { playerBettingSnapshot } from "./helpers/jugabilitatV1Fixtures.ts";

for (const viewport of [{width:320,height:640},{width:360,height:740},{width:390,height:844},{width:430,height:932}]) {
 test(`aposta i visibilitat mòbil ${viewport.width}x${viewport.height}`, async ({ page }) => {
  await page.setViewportSize(viewport);
  const id = e2ePoolId();
  await seedE2eLaunch(page,id);
  await page.addInitScript(({pid,snap}) => {
   localStorage.setItem("setimig_player_id",pid);
   localStorage.setItem("setimig_player_name","Nou");
   localStorage.setItem("setimig_onboarding_v1","1");
   localStorage.setItem("setimig_interactive_tutorial_v1","1");
   localStorage.setItem("setimig_table_tutorial_v1","1");
   localStorage.setItem("setimig_age_gate",JSON.stringify({accepted:true,at:new Date().toISOString(),version:"1"}));
   localStorage.setItem("setimig_local_solo_snapshot",snap);
   sessionStorage.setItem("setimig_solo_rejoin","1");
   sessionStorage.setItem("setimig_solo_local","1");
  },{pid:id,snap:playerBettingSnapshot(id,"Nou")});
  await page.route("**/socket.io/**", route => route.abort());
  await page.goto("/");
  await expect(page.getByTestId("fase6-session-button")).toBeVisible({timeout:20000});
  await page.getByTestId("fase6-session-button").click();
  await expect(page.getByRole("region",{name:"Resum de la sessió"})).toBeVisible();
  await expect(page.getByTestId("bet-confirmation-state")).toBeVisible();
  const xOverflow=await page.evaluate(() => document.documentElement.scrollWidth - window.innerWidth);
  expect(xOverflow).toBeLessThanOrEqual(2);
 });
}
