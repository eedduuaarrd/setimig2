import AxeBuilder from "@axe-core/playwright";
import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eLaunch } from "./helpers/e2eSession.ts";

/**
 * Lobby v4.1 · PR-L2+ (lobby-v4-1.md §4, criteris 1–12 + axe). Només mesures calculades, sense captures.
 * L'app és tota fosca: amb colorScheme 'light' la pàgina continua fosca.
 */
const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844, symbol: 192 },
  { tag: "375x667", width: 375, height: 667, symbol: 160 },
  { tag: "360x740", width: 360, height: 740, symbol: 160 },
] as const;

const MODES = [
  { tag: "fosc", colorScheme: "dark" as const, reducedMotion: "no-preference" as const },
  { tag: "reduced-motion", colorScheme: "dark" as const, reducedMotion: "reduce" as const },
  { tag: "sistema-clar", colorScheme: "light" as const, reducedMotion: "no-preference" as const },
];

async function seedLobby(page: Page, _label: string) {
  // Sessió real (login obligatori): compte e2e del pool + intro ja vista.
  const id = e2ePoolId();
  await seedE2eLaunch(page, id);
  await page.addInitScript(
    ({ pid, age }) => {
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", "Lobby41");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_home_intro_v1", "1");
      localStorage.setItem("setimig_age_gate", age);
      const w = window as unknown as { __lobbyAnims?: unknown[]; __lobbyMountAt?: number };
      const mo = new MutationObserver(() => {
        const shell = document.querySelector(".lobby-shell");
        if (!shell || w.__lobbyMountAt) return;
        w.__lobbyMountAt = performance.now();
        w.__lobbyAnims = document.getAnimations().map((a) => {
          const effect = a.effect as KeyframeEffect | null;
          const target = effect?.target as Element | null;
          const timing = effect?.getComputedTiming();
          const props = new Set<string>();
          for (const kf of effect?.getKeyframes() ?? [])
            for (const k of Object.keys(kf)) if (!["offset", "easing", "composite", "computedOffset"].includes(k)) props.add(k);
          return {
            name: (a as CSSAnimation).animationName ?? a.constructor.name,
            inLobby: !!target && shell.contains(target),
            duration: Number(timing?.duration ?? 0),
            endTime: Number(timing?.endTime ?? 0),
            infinite: timing?.iterations === Infinity,
            props: Array.from(props),
          };
        });
      });
      mo.observe(document, { childList: true, subtree: true });
    },
    { pid: id, age: JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }) }
  );
}

async function openLobby(page: Page) {
  await page.goto("/");
  await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 60_000 });
  // Espera que acabin les animacions d'entrada.
  await page.evaluate(async () => {
    const t0 = performance.now();
    while (document.getAnimations().some((a) => a.playState === "running" && !(a.effect?.getComputedTiming().iterations === Infinity)) && performance.now() - t0 < 3000)
      await new Promise((r) => requestAnimationFrame(r));
  });
}

/** Criteris 1–8 i 12 en una sola passada. */
async function layout(page: Page) {
  return page.evaluate(() => {
    const H = innerHeight;
    const W = innerWidth;
    const shell = document.querySelector(".lobby-shell") as HTMLElement;
    const header = document.querySelector("header") as HTMLElement;
    const vis = (e: Element) => {
      const r = e.getBoundingClientRect();
      const c = getComputedStyle(e);
      return r.width > 0 && r.height > 0 && c.visibility !== "hidden" && +c.opacity > 0 && r.bottom > 0 && r.top < H;
    };
    const rect = (sel: string) => {
      const e = document.querySelector(sel);
      if (!e) return null;
      const r = e.getBoundingClientRect();
      return { top: Math.round(r.top), bottom: Math.round(r.bottom), w: Math.round(r.width), h: Math.round(r.height), cy: Math.round(r.top + r.height / 2) };
    };
    // 3 · textos i estils
    const texts: string[] = [];
    const tw = document.createTreeWalker(shell, NodeFilter.SHOW_TEXT);
    for (let n = tw.nextNode(); n; n = tw.nextNode()) {
      const t = n.textContent?.trim();
      if (t && n.parentElement && vis(n.parentElement) && !n.parentElement.closest(".sr-only")) texts.push(t);
    }
    const styleKey = (e: Element) => {
      const c = getComputedStyle(e);
      return `${c.fontFamily.split(",")[0].replace(/"/g, "")} ${c.fontSize} w${c.fontWeight} ls${c.letterSpacing}`;
    };
    const stylesOf = (root: Element) => {
      const s = new Set<string>();
      for (const e of Array.from(root.querySelectorAll("*")))
        if (vis(e) && !e.closest(".sr-only") && Array.from(e.childNodes).some((c) => c.nodeType === 3 && c.textContent?.trim())) s.add(styleKey(e));
      return Array.from(s);
    };
    // 7 · espai buit (mostreig de 4 px sobre fulles visibles de la capçalera i el lobby)
    const all = Array.from(document.querySelectorAll(".lobby-shell *, header *")).filter(vis);
    const leaves = all.filter((e) => !Array.from(e.children).some(vis)).map((e) => e.getBoundingClientRect());
    let occ = 0;
    let tot = 0;
    for (let y = 0; y < H; y += 4)
      for (let x = 0; x < W; x += 4) {
        tot += 1;
        if (leaves.some((r) => x >= r.left && x < r.right && y >= r.top && y < r.bottom)) occ += 1;
      }
    // 8 · colors i efectes prohibits
    const bad: string[] = [];
    for (const e of all.concat(shell, header)) {
      const c = getComputedStyle(e);
      const id = `${e.tagName.toLowerCase()}.${String(e.getAttribute("class") ?? "").split(" ")[0]}`;
      if (/gradient/.test(c.backgroundImage)) bad.push(`${id} gradient`);
      if (c.boxShadow !== "none") bad.push(`${id} shadow ${c.boxShadow}`);
      if (c.transitionProperty.split(",").some((p) => p.trim() === "all") && parseFloat(c.transitionDuration) > 0) bad.push(`${id} transition all`);
      for (const v of [c.color, c.backgroundColor, c.borderTopColor, c.fill, c.stroke])
        if (/rgba?\(255, 255, 255|rgba?\(200, 169, 107/.test(v)) bad.push(`${id} ${v}`);
    }
    // 12 · objectius
    // Els enllaços SEO estàtics d'index.html (.seo-links, #199) són visualment amagats (clip 1px), no objectius tàctils.
    const small = Array.from(document.querySelectorAll("button, a, summary, [role=button]"))
      .filter((e) => !e.closest(".seo-links"))
      .filter(vis)
      .map((e) => ({ e, r: e.getBoundingClientRect() }))
      .filter(({ r }) => r.width < 44 || r.height < 44)
      .map(({ e, r }) => `${e.textContent?.trim().slice(0, 16)} ${Math.round(r.width)}x${Math.round(r.height)}`);
    const frame = document.querySelectorAll('[data-testid="lobby-hero-frame"]');
    const fr = frame[0]?.getBoundingClientRect();
    const fcs = frame[0] ? getComputedStyle(frame[0]) : null;
    const corners = Array.from(document.querySelectorAll(".lobby-v4-corner"));
    const cta = document.querySelector('[data-testid="play-vs-ai-button"]') as HTMLElement;
    const ccs = getComputedStyle(cta);
    const group = rect('[data-testid="lobby-group"]')!;
    const foot = rect('[data-testid="legal-footer"]')!;
    const head = rect("header")!;
    return {
      H,
      scroll: { shellS: shell.scrollHeight, shellC: shell.clientHeight, doc: document.documentElement.scrollHeight },
      bottomBarVisible: !!document.querySelector('[data-testid="lobby-bottom-bar"]') && vis(document.querySelector('[data-testid="lobby-bottom-bar"]')!),
      headerTitleVisible: Array.from(document.querySelectorAll('[data-testid="app-header-title"]')).some(vis),
      texts,
      styles: stylesOf(shell),
      stylesWithHeader: Array.from(new Set([...stylesOf(shell), ...stylesOf(header)])),
      cta: { ...rect('[data-testid="play-vs-ai-button"]')!, bg: ccs.backgroundColor, color: ccs.color, font: `${ccs.fontFamily.split(",")[0]} ${ccs.fontSize}` },
      symbol: rect('[data-testid="lobby-hero-symbol"]')!,
      frame: {
        count: frame.length,
        w: Math.round(fr?.width ?? 0),
        h: Math.round(fr?.height ?? 0),
        border: fcs?.borderTopWidth,
        color: fcs?.borderTopColor,
        corners: corners.length,
        cornersInside: corners.every((c) => frame[0]?.contains(c)),
      },
      shellDeco: shell.classList.contains("deco-frame"),
      group,
      gaps: { top: group.top - head.bottom, bottom: foot.top - group.bottom },
      emptyPct: Math.round(1000 * (1 - occ / tot)) / 10,
      bad,
      small,
      bodyBg: getComputedStyle(document.body).backgroundColor,
    };
  });
}

const axeViolations = async (page: Page) =>
  (await new AxeBuilder({ page }).analyze()).violations.map((v) => `${v.id}: ${v.nodes.map((n) => n.target.join(" ")).join(" | ")}`);

for (const vp of VIEWPORTS) {
  for (const mode of MODES) {
    test.describe(`lobby v4.1 ${vp.tag} ${mode.tag}`, () => {
      test.use({ viewport: { width: vp.width, height: vp.height }, colorScheme: mode.colorScheme });
      test.beforeEach(async ({ page }) => {
        await page.emulateMedia({ reducedMotion: mode.reducedMotion, colorScheme: mode.colorScheme });
      });

      test(`criteris 1–8, 11, 12 i axe (${vp.tag}, ${mode.tag})`, async ({ page }) => {
        await seedLobby(page, `lobby41-l-${vp.tag}-${mode.tag}`);
        await openLobby(page);
        const m = await layout(page);
        console.log(`[lobby-v4-1] layout ${vp.tag} ${mode.tag} ${JSON.stringify(m)}`);
        // 1
        expect(m.scroll.doc).toBeLessThanOrEqual(vp.height);
        expect(m.scroll.shellS).toBeLessThanOrEqual(m.scroll.shellC);
        // 2
        await expect(page.getByRole("button", { name: /^Jugar$/ })).toHaveCount(1);
        expect(m.bottomBarVisible).toBe(false);
        expect(m.headerTitleVisible).toBe(false);
        // 3
        // El peu legal (Legal · Privadesa · Condicions) no compta com a contingut.
        expect(m.texts.filter((x) => !/^(Legal|Privadesa|Condicions)$/.test(x)).length).toBeLessThanOrEqual(7);
        expect(m.texts.some((x) => /Guia/.test(x))).toBe(false);
        expect(m.styles.length).toBeLessThanOrEqual(5);
        // 4
        expect(m.cta.w).toBeGreaterThanOrEqual(232);
        expect(m.cta.w).toBeLessThanOrEqual(248);
        expect(m.cta.h).toBeGreaterThanOrEqual(52);
        expect(m.cta.bg).toBe("rgb(245, 242, 235)");
        expect(m.cta.color).toBe("rgb(11, 11, 11)");
        expect(m.cta.font).toMatch(/Cinzel.* 16px/);
        expect(m.cta.bottom).toBeGreaterThanOrEqual(0.55 * vp.height);
        expect(m.cta.bottom).toBeLessThanOrEqual(0.68 * vp.height);
        // 5
        // Logo nou (#251): una mica més amunt a 375x667 (cy ≈ 0,28·H).
        expect(m.symbol.cy).toBeGreaterThanOrEqual(0.27 * vp.height);
        expect(m.symbol.cy).toBeLessThanOrEqual(0.4 * vp.height);
        // v163: logo més gran (cartes a min(45vw, 30vh) + halo); ≥ l'antic i ≤ 50 % de l'alçada.
        expect(m.symbol.h).toBeGreaterThanOrEqual(vp.symbol);
        expect(m.symbol.h).toBeLessThanOrEqual(vp.height * 0.5);
        // Logo «C · Fum daurat»: l'Edu el vol sense el quadrat del voltant (ni marc ni escaires).
        expect(m.frame.count).toBe(0);
        expect(m.frame.corners).toBe(0);
        expect(m.shellDeco).toBe(false);
        // 6
        expect(Math.abs(m.gaps.top - m.gaps.bottom)).toBeLessThanOrEqual(24);
        // 7
        // v163: logo al 45 % d'amplada amb halo; queda ~50–57 % de pantalla buida (abans ~80 %).
        expect(m.emptyPct).toBeGreaterThanOrEqual(45);
        // 8
        expect(m.bad).toEqual([]);
        // 12
        expect(m.small).toEqual([]);
        // Tot fosc: el sistema en clar no canvia l'app.
        expect(m.bodyBg).toBe("rgb(11, 11, 11)");
        expect(await axeViolations(page)).toEqual([]);
      });

      test(`criteri 2 i 12: ordre de Tab (${vp.tag}, ${mode.tag})`, async ({ page }) => {
        await seedLobby(page, `lobby41-t-${vp.tag}-${mode.tag}`);
        await openLobby(page);
        await page.getByTestId("play-vs-ai-button").focus();
        const order: string[] = [];
        for (let i = 0; i < 5; i++) {
          order.push(await page.evaluate(() => {
            const e = document.activeElement as HTMLElement;
            const cs = getComputedStyle(e);
            return `${(e.textContent ?? "").trim()}|${cs.outlineWidth}`;
          }));
          await page.keyboard.press("Tab");
        }
        console.log(`[lobby-v4-1] tab ${vp.tag} ${mode.tag} ${JSON.stringify(order)}`);
        expect(order.map((o) => o.split("|")[0])).toEqual(["Jugar", "Contra 3 rivals · Normal", "Amb amics", "Com jugar", "Legal"]);
        // A partir del segon element el focus ve del teclat (focus-visible, 2 px).
        for (const o of order.slice(1)) expect(o.split("|")[1]).toBe("2px");
      });

      test(`criteris 9 i 11: «Jugar» comença sense diàleg, taula ≤ 600 ms (${vp.tag}, ${mode.tag})`, async ({ page }) => {
        await seedLobby(page, `lobby41-p-${vp.tag}-${mode.tag}`);
        await openLobby(page);
        // Deixa temps a la precàrrega en repòs de la taula.
        await page.waitForTimeout(800);
        const btn = page.getByTestId("play-vs-ai-button");
        await btn.evaluate((el) => {
          type Rec = { key: string; duration: number; infinite: boolean; props: string[] };
          const w = window as unknown as { __nav: { click?: number; table?: number; lobbyGone?: number; dialog: boolean; anims: Record<string, Rec> } };
          w.__nav = { dialog: false, anims: {} };
          el.addEventListener("click", () => (w.__nav.click = performance.now()), { capture: true, once: true });
          const tick = () => {
            const nav = w.__nav;
            const now = performance.now();
            if (nav.click) {
              if (document.querySelector('[role="dialog"]')) nav.dialog = true;
              for (const a of document.getAnimations()) {
                const eff = a.effect as KeyframeEffect | null;
                const timing = eff?.getComputedTiming();
                const props = new Set<string>();
                for (const kf of eff?.getKeyframes() ?? [])
                  for (const k of Object.keys(kf)) if (!["offset", "easing", "composite", "computedOffset"].includes(k)) props.add(k);
                const target = eff?.target as Element | null;
                const key = `${(a as CSSAnimation).animationName ?? (a as CSSTransition).transitionProperty ?? "waapi"}@${target?.tagName.toLowerCase()}.${String(target?.getAttribute("class") ?? "").split(" ")[0]}`;
                nav.anims[key] = { key, duration: Number(timing?.duration ?? 0), infinite: timing?.iterations === Infinity, props: Array.from(props) };
              }
              const root = document.querySelector(".game-table-root") as HTMLElement | null;
              const stage = document.querySelector('[data-testid="table-stage"]') as HTMLElement | null;
              if (nav.table === undefined && root && stage && Number(getComputedStyle(stage).opacity) > 0) nav.table = now - nav.click;
              if (nav.lobbyGone === undefined && !document.querySelector(".lobby-v4")) nav.lobbyGone = now - nav.click;
              if (now - nav.click > 600 && nav.table !== undefined && nav.lobbyGone !== undefined) return;
              if (now - nav.click > 3000) return;
            }
            requestAnimationFrame(tick);
          };
          requestAnimationFrame(tick);
        });
        await btn.click();
        await expect(page.locator(".game-table-root")).toBeVisible({ timeout: 20_000 });
        await page.waitForTimeout(700);
        const nav = await page.evaluate(() => (window as unknown as { __nav: { table?: number; lobbyGone?: number; dialog: boolean; anims: Record<string, { key: string; duration: number; infinite: boolean; props: string[] }> } }).__nav);
        // Fora d'abast d'aquest criteri: el bokeh de la taula (#222, infinit a propòsit) i l'avís de la compra solo (#216).
        const anims = Object.values(nav.anims).filter((a) => !a.key.includes("table-bokeh") && !a.key.endsWith(".casino-toast"));
        console.log(`[lobby-v4-1] play ${vp.tag} ${mode.tag} table=${Math.round(nav.table ?? -1)} lobbyGone=${Math.round(nav.lobbyGone ?? -1)} dialog=${nav.dialog} anims=${JSON.stringify(anims)}`);
        expect(nav.dialog).toBe(false);
        expect(nav.table).toBeLessThanOrEqual(600);
        expect(nav.lobbyGone).toBeLessThanOrEqual(600);
        for (const a of anims) {
          expect(a.infinite, a.key).toBe(false);
          expect(a.props.every((p) => p === "transform" || p === "opacity"), `${a.key} ${a.props}`).toBe(true);
          expect(a.duration, a.key).toBeLessThanOrEqual(mode.reducedMotion === "reduce" ? 120 : 320);
          if (mode.reducedMotion === "reduce") expect(a.props.includes("transform"), a.key).toBe(false);
        }
      });

      test(`criteris 10 i 11: el context obre la configuració; animacions del lobby (${vp.tag}, ${mode.tag})`, async ({ page }) => {
        await seedLobby(page, `lobby41-c-${vp.tag}-${mode.tag}`);
        await page.goto("/");
        await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 60_000 });
        const anims = await page.evaluate(() => ((window as unknown as { __lobbyAnims?: Array<{ name: string; inLobby: boolean; duration: number; endTime: number; infinite: boolean; props: string[] }> }).__lobbyAnims ?? []).filter((a) => a.inLobby));
        console.log(`[lobby-v4-1] intro ${vp.tag} ${mode.tag} ${JSON.stringify(anims)}`);
        expect(anims.length).toBeGreaterThan(0);
        for (const a of anims) {
          expect(a.infinite).toBe(false);
          expect(a.props.every((p) => p === "transform" || p === "opacity" || p === "rotate" || p === "scale"), `${a.name} ${a.props}`).toBe(true);
          expect(a.endTime, a.name).toBeLessThanOrEqual(600);
          if (mode.reducedMotion === "reduce") {
            expect(a.props.includes("transform"), a.name).toBe(false);
            expect(a.duration, a.name).toBeLessThanOrEqual(120);
          } else expect(a.duration, a.name).toBeLessThanOrEqual(320);
        }
        const ctx = page.getByTestId("lobby-context");
        await expect(ctx).toHaveText("Contra 3 rivals · Normal");
        const box = await ctx.boundingBox();
        expect(box!.height).toBeGreaterThanOrEqual(44);
        await ctx.click();
        await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
      });
    });
  }
}
