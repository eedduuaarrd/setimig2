import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * v180 · Separar amb qualsevol parella de mig punt i UI de fins a 3 mans (re-split) a 390 px.
 * - S+C: real, amb SETIMIG_TEST_DECK_SEED=3 (cavall + sota).
 * - R+S i 3 mans (S, R, R): injecció d'estat al client (`__SETIMIG_TEST_PATCH_ME`, només en dev),
 *   fins que el motor de re-split del Servidor existeixi.
 * Executar: NODE_ENV=test SETIMIG_TEST_DECK_SEED=3 E2E_PORT=3304 npx playwright test e2e/split-3mans.spec.ts
 */
const SEED = process.env.SETIMIG_TEST_DECK_SEED;
test.use({ viewport: { width: 390, height: 844 } });

async function startSolo(page: Page) {
  await seedE2eSession(page, e2ePoolId());
  await page.addInitScript(() => {
    if (sessionStorage.getItem("qa_split") === "1") return;
    sessionStorage.setItem("qa_split", "1");
    for (const k of ["setimig_onboarding_v1", "setimig_interactive_tutorial_v1", "setimig_table_tutorial_v1", "setimig_house_rules_enabled"]) localStorage.setItem(k, "1");
    localStorage.setItem("setimig.locale", "ca");
    localStorage.setItem("setimig_player_name", "Test Split");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
    sessionStorage.setItem("setimig_intro_launch_v1", "1");
  });
  await page.goto("/");
  const skip = page.getByTestId("interactive-tutorial-skip");
  await expect(page.getByTestId("lobby-context").or(skip).first()).toBeVisible({ timeout: 45_000 });
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  if (await page.getByTestId("ai-bot-count-1").isVisible().catch(() => false)) await page.getByTestId("ai-bot-count-1").click();
  const cb = page.getByTestId("house-rules-toggle").locator("input");
  if (!(await cb.isChecked())) await cb.check({ force: true });
  await page.getByTestId("ai-bot-picker-start").click();
  await page.getByTestId("bet-confirm").filter({ visible: true }).first().click({ timeout: 30_000 });
  await expect(page.getByTestId("action-stand").filter({ visible: true }).first()).toBeVisible({ timeout: 30_000 });
}

const fig = (id: string, suit: string, value: number, faceUp = true) => ({ id, card: { suit, value, points: 0.5 }, faceUp });
const slot = (id: string, cards: unknown[], status = "playing") => ({
  id, bet: 100, cards, doubled: false, canDouble: false, mort: false, blindPair: false, blindUntilBankEnd: false, mortOffered: false, status,
});

async function patchMe(page: Page, patch: unknown) {
  await page.evaluate((p) => window.__SETIMIG_TEST_PATCH_ME?.(p as Record<string, unknown>), patch);
}

async function expectSplitButton(page: Page) {
  const btn = page.getByTestId("mobile-split-button");
  await expect(btn).toBeVisible({ timeout: 20_000 });
  await expect(btn).toHaveText(/separar/i);
  const b = (await btn.boundingBox())!;
  expect(b.height).toBeGreaterThanOrEqual(44);
  expect(b.x).toBeGreaterThanOrEqual(0);
  expect(b.x + b.width).toBeLessThanOrEqual(390.5);
}

test("S+C (llavor 3, motor real): «Separar» visible a 390 px", async ({ page }) => {
  test.skip(SEED !== "3", "cal SETIMIG_TEST_DECK_SEED=3");
  await startSolo(page);
  await page.getByTestId("action-hit").filter({ visible: true }).first().click();
  await expectSplitButton(page);
});

test("R+S (injectat, primera tapada com a la captura): «Separar» visible", async ({ page }) => {
  await startSolo(page);
  await patchMe(page, {
    handSlots: [slot("rs", [fig("rs-s", "hearts", 10, false), fig("rs-r", "diamonds", 12)])],
    activeSlotIndex: 0,
    pendingChoices: { canSplit: true },
  });
  await expectSplitButton(page);
});

test("re-split: 3 mans (S, R, R) a 390 px sense retalls ni encavalcaments", async ({ page }) => {
  await startSolo(page);
  await patchMe(page, {
    handSlots: [
      slot("h1", [fig("s1", "hearts", 10), fig("x1", "clubs", 12)], "stood"),
      slot("h2", [fig("r1", "diamonds", 12), fig("x2", "spades", 10)]),
      slot("h3", [fig("r2", "spades", 12)]),
    ],
    activeSlotIndex: 1,
    pendingChoices: {},
  });
  const hands = page.getByTestId("own-split-hand");
  await expect(hands).toHaveCount(3);
  await expect(hands.nth(1)).toHaveAttribute("data-active", "yes");
  await page.waitForTimeout(800);
  const vh = 844;
  const dock = (await page.getByTestId("your-turn-row").filter({ visible: true }).first().boundingBox())!;
  const boxes = [];
  for (let i = 0; i < 3; i++) {
    const b = (await hands.nth(i).boundingBox())!;
    expect(b.x).toBeGreaterThanOrEqual(-0.5);
    expect(b.x + b.width).toBeLessThanOrEqual(390.5);
    expect(b.y).toBeGreaterThanOrEqual(0);
    expect(b.y + b.height).toBeLessThanOrEqual(Math.min(vh, dock.y + 0.5));
    // Cartes de cada mà dins del seu panell (cap retall entre mans).
    for (const c of await hands.nth(i).getByTestId("local-hand-card").all()) {
      const cb = (await c.boundingBox())!;
      expect(cb.x).toBeGreaterThanOrEqual(-0.5);
      expect(cb.x + cb.width).toBeLessThanOrEqual(390.5);
    }
    boxes.push(b);
  }
  for (let i = 0; i < 2; i++) {
    const a = boxes[i]!, n = boxes[i + 1]!;
    const sep = a.x + a.width <= n.x + 0.5 || a.y + a.height <= n.y + 0.5;
    expect(sep, `mans ${i + 1} i ${i + 2} encavalcades`).toBe(true);
  }
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
  for (const s of ["action-stand", "action-hit"]) {
    const b = (await page.getByTestId(s).filter({ visible: true }).first().boundingBox())!;
    expect(b.height).toBeGreaterThanOrEqual(44);
  }
});

for (const vp of [{ w: 390, h: 844 }, { w: 1280, h: 800 }]) {
  test.describe(`splitBlocked ${vp.w}`, () => {
    test.use({ viewport: { width: vp.w, height: vp.h } });
    const pair = () => [slot("bb", [fig("bb-s", "hearts", 10), fig("bb-r", "diamonds", 12)])];

    test(`bankCannotCoverSplit: «Separar» desactivat amb el motiu (${vp.w})`, async ({ page }) => {
      await startSolo(page);
      await patchMe(page, { handSlots: pair(), activeSlotIndex: 0, pendingChoices: { canSplit: false, splitBlocked: "bankCannotCoverSplit" } });
      const btn = page.getByTestId("split-blocked-button").filter({ visible: true });
      await expect(btn).toHaveAttribute("aria-disabled", "true");
      await expect(page.getByTestId("split-blocked-reason").filter({ visible: true })).toHaveText("La banca no pot cobrir el split");
      await expect(page.getByTestId("mobile-split-button")).toHaveCount(0);
      for (const id of ["split-blocked", "action-stand", "action-hit"]) {
        const b = (await page.getByTestId(id).filter({ visible: true }).first().boundingBox())!;
        expect(b.x).toBeGreaterThanOrEqual(-0.5);
        expect(b.x + b.width).toBeLessThanOrEqual(vp.w + 0.5);
        expect(b.y + b.height).toBeLessThanOrEqual(vp.h + 0.5);
        if (id !== "split-blocked") expect(b.height).toBeGreaterThanOrEqual(44);
      }
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
    });

    test(`codi desconegut: motiu genèric; sense codi: amagat (${vp.w})`, async ({ page }) => {
      await startSolo(page);
      await patchMe(page, { handSlots: pair(), activeSlotIndex: 0, pendingChoices: { canSplit: false, splitBlocked: "whatever" } });
      await expect(page.getByTestId("split-blocked-reason").filter({ visible: true })).toHaveText("No es pot separar ara");
      await patchMe(page, { handSlots: pair(), activeSlotIndex: 0, pendingChoices: { canSplit: false } });
      await expect(page.getByTestId("split-blocked")).toHaveCount(0);
      await expect(page.getByTestId("mobile-split-button")).toHaveCount(0);
    });
  });
}

test("decideSwapFirst amb oferta de 3 a la vista: «Separar» desactivat + motiu, sense retalls a 390", async ({ page }) => {
  await startSolo(page);
  await patchMe(page, {
    handSlots: [slot("sw", [fig("sw-s", "hearts", 10), fig("sw-r", "diamonds", 12)])],
    activeSlotIndex: 0,
    pendingChoices: { swapOffer: 3, offerCardId: "sw-s", splitBlocked: "decideSwapFirst" },
  });
  await expect(page.getByTestId("split-blocked-reason").filter({ visible: true })).toHaveText("Primer decideix el 3 o el 4");
  await expect(page.getByTestId("split-blocked-button").filter({ visible: true })).toHaveAttribute("aria-disabled", "true");
  for (const id of ["split-blocked", "action-stand", "action-hit"]) {
    const b = (await page.getByTestId(id).filter({ visible: true }).first().boundingBox())!;
    expect(b.x).toBeGreaterThanOrEqual(-0.5);
    expect(b.x + b.width).toBeLessThanOrEqual(390.5);
    expect(b.y + b.height).toBeLessThanOrEqual(844.5);
  }
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1)).toBe(true);
  await patchMe(page, { handSlots: [slot("bp", [fig("bp-s", "hearts", 10), fig("bp-r", "diamonds", 12)])], activeSlotIndex: 0, pendingChoices: { splitBlocked: "blindPairLocked" } });
  await expect(page.getByTestId("split-blocked-reason").filter({ visible: true })).toHaveText("Mà cega: no es pot separar");
});
