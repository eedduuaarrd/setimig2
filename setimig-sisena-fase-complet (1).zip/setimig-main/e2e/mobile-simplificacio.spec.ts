import { expect, test } from "@playwright/test";
import { startAiGameFromLobby } from "./helpers/aiLobby";
import { e2ePoolId, seedE2eLaunch } from "./helpers/e2eSession.ts";

/** Sessió (login obligatori) + intro vista + porta d'edat i onboarding fets. */
async function seedPlayer(target: import("@playwright/test").Page | import("@playwright/test").BrowserContext) {
  await seedE2eLaunch(target, e2ePoolId(), { locale: "ca" });
  await target.addInitScript(() => {
    localStorage.setItem("setimig_player_name", "Tester");
    localStorage.setItem("setimig_onboarding_v1", "1");
    localStorage.setItem("setimig_interactive_tutorial_v1", "1");
    localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
  });
}

async function enterName(page: import("@playwright/test").Page, name: string) {
  const input = page.getByPlaceholder("El teu nom");
  if (await input.isVisible().catch(() => false)) {
    await input.fill(name);
    await page.getByRole("button", { name: "Entrar al lobby" }).click();
  }
}

async function startAiGame(page: import("@playwright/test").Page, bots: number, playerName: string) {
  await seedPlayer(page);
  await page.goto("/");
  await enterName(page, playerName);
  await startAiGameFromLobby(page, bots);
  await expect(page.getByRole("button", { name: "Sortir" })).toBeVisible({ timeout: 45_000 });
}

test.describe("mobile 390x844 simplificacio", () => {
  test.use({ viewport: { width: 390, height: 844 } });

  for (const bots of [1, 3, 5] as const) {
    test(`IA amb ${bots} bot(s) entra sense «Partida en curs»`, async ({ page }) => {
      await startAiGame(page, bots, `Tester${bots}`);
      await expect(page.getByText("Partida en curs.")).toHaveCount(0);
    });
  }

  test("IA i taula privada en paral·lel: IA no queda bloquejada", async ({ browser }) => {
    const privContext = await browser.newContext({ viewport: { width: 390, height: 844 } });
    const aiContext = await browser.newContext({ viewport: { width: 390, height: 844 } });
    await seedPlayer(privContext);
    await seedPlayer(aiContext);
    const privPage = await privContext.newPage();
    const aiPage = await aiContext.newPage();

    await privPage.goto("/");
    await enterName(privPage, "PrivHost");
    await privPage.getByTestId("create-private-table").click();
    await expect(privPage.getByTestId("private-waiting-panel")).toBeVisible({ timeout: 30_000 });

    await aiPage.goto("/");
    await enterName(aiPage, "SoloPlayer");
    await startAiGameFromLobby(aiPage, 3);
    await expect(aiPage.getByText("Partida en curs.")).toHaveCount(0);
    await expect(aiPage.getByRole("button", { name: "Sortir" })).toBeVisible({ timeout: 45_000 });

    await privContext.close();
    await aiContext.close();
  });
});
