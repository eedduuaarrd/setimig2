import AxeBuilder from "@axe-core/playwright";
import { expect, test, type Page } from "@playwright/test";
import { E2E_ACCOUNT_IDS, e2ePoolId, seedE2eLaunch } from "./helpers/e2eSession.ts";
import { playerBettingSnapshot, playerTurnSnapshot } from "./helpers/jugabilitatV1Fixtures.ts";
import { settlementSnapshotJson } from "./helpers/esteticaFormalFixtures.ts";
import { matchEndSnapshotJson } from "./helpers/uxA11yFixtures.ts";
import { V2_GOLD_EXCEPTIONS, scanColors, scrollMetrics } from "./helpers/jugabilitatV2Probes.ts";

/** Jugabilitat v2 (jugabilitat-v2.md, ítems [CLIENT] 1–7). Només mesures calculades, sense captures. */
const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844 },
  { tag: "375x667", width: 375, height: 667 },
  { tag: "360x740", width: 360, height: 740 },
] as const;

const AGE_OK = () => JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" });

async function seedLobby(page: Page, id: string, withTutorial: boolean) {
  id = E2E_ACCOUNT_IDS.includes(id) ? id : e2ePoolId();
  await seedE2eLaunch(page, id);
  await page.addInitScript(
    ({ pid, tutorial, age }) => {
      if (sessionStorage.getItem("jug2_seeded") === "1") return;
      sessionStorage.setItem("jug2_seeded", "1");
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", "Nou");
      localStorage.setItem("setimig_onboarding_v1", "1");
      if (tutorial) localStorage.removeItem("setimig_interactive_tutorial_v1");
      else localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_age_gate", age);
    },
    { pid: id, tutorial: withTutorial, age: AGE_OK() }
  );
}

async function seedSolo(page: Page, snap: string, playerId: string, name: string) {
  playerId = E2E_ACCOUNT_IDS.includes(playerId) ? playerId : e2ePoolId();
  await seedE2eLaunch(page, playerId);
  await page.addInitScript(
    ({ snap, pid, pname, age }) => {
      if (sessionStorage.getItem("jug2_seeded") === "1") return;
      sessionStorage.setItem("jug2_seeded", "1");
      localStorage.setItem("setimig_player_id", pid);
      localStorage.setItem("setimig_player_name", pname);
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_table_tutorial_v1", "1");
      localStorage.setItem("setimig_house_rules_enabled", "1");
      localStorage.setItem("setimig_age_gate", age);
      localStorage.setItem("setimig_local_solo_snapshot", snap);
      sessionStorage.setItem("setimig_solo_rejoin", "1");
      sessionStorage.setItem("setimig_solo_local", "1");
    },
    { snap, pid: playerId, pname: name, age: AGE_OK() }
  );
  await page.route("**/socket.io/**", (route) => route.abort());
}

async function expectNoAxe(page: Page) {
  const results = await new AxeBuilder({ page }).analyze();
  expect(results.violations.map((v) => `${v.id}: ${v.nodes.map((n) => n.target.join(" ")).join(" | ")}`)).toEqual([]);
}

async function expectNoScroll(page: Page, label: string) {
  const m = await scrollMetrics(page);
  console.log(`[jugabilitat-v2] ${label}: document ${m.docScroll}/${m.innerHeight}, lobby ${m.lobbyScroll}/${m.lobbyClient}`);
  expect(m.docScroll, `${label}: document sense scroll`).toBeLessThanOrEqual(m.innerHeight);
  if (m.lobbyClient > 0) expect(m.lobbyScroll, `${label}: lobby sense scroll intern`).toBeLessThanOrEqual(m.lobbyClient + 1);
}

async function expectV3Palette(page: Page, label: string) {
  const hits = await scanColors(page, { mode: "palette" });
  expect(hits, `${label}: colors fora de la paleta v3`).toEqual([]);
}

async function expectNoYellow(page: Page, label: string) {
  // Retoc 3: l'or #D4AF6A és permès NOMÉS a la barra «Bust», l'anella del toc, la píndola «Stands 7½» i el CTA.
  const hits = await scanColors(page, { mode: "yellow", allowGold: V2_GOLD_EXCEPTIONS });
  expect(hits, `${label}: groc/or fora del torn i del 7½`).toEqual([]);
}

/** Recompte de botons de revenja visibles a la pantalla final. */
async function visibleRematchButtons(page: Page) {
  const buttons = page.getByRole("button", { name: /revenja|tornar a jugar/i });
  let visible = 0;
  for (let i = 0; i < (await buttons.count()); i += 1) if (await buttons.nth(i).isVisible()) visible += 1;
  return visible;
}

for (const vp of VIEWPORTS) {
  test.describe(`jugabilitat v2 ${vp.tag}`, () => {
    test.use({ viewport: { width: vp.width, height: vp.height }, isMobile: true, hasTouch: true });
    test.setTimeout(90_000);

    // ítem 2 (porta d'edat v3) esborrat: amb el login obligatori la porta d'edat ja no surt a un compte nou.

    test(`ítems 1 i 7: lobby sense scroll i paleta v3, amb i sense tutorial (${vp.tag})`, async ({ page }) => {
      await seedLobby(page, e2ePoolId(), false);
      await page.goto("/");
      await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 30_000 });
      await page.waitForTimeout(450);
      // Lobby v4 (PR-L1): el desplegable de guia s'ha tret; «Com jugar» obre el tutorial.
      await expect(page.getByTestId("lobby-quick-guide")).toHaveCount(0);
      await expect(page.getByTestId("lobby-open-tutorial")).toBeVisible();
      await expectNoScroll(page, `lobby ${vp.tag}`);
      await expectV3Palette(page, "lobby");
      await expectNoYellow(page, "lobby");
      await expectNoAxe(page);

      // Modal de nova partida (ítem 7).
      await page.getByTestId("lobby-context").click();
      await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
      await page.waitForTimeout(450);
      const selected = await page.evaluate(() => {
        const el = document.querySelector<HTMLElement>(".setup-choice.is-selected");
        return el ? { bg: getComputedStyle(el).backgroundColor, color: getComputedStyle(el).color } : null;
      });
      expect(selected).toEqual({ bg: "rgb(245, 242, 235)", color: "rgb(11, 11, 11)" });
      await expectV3Palette(page, "modal nova partida");
      await expectNoAxe(page);
    });

    test(`ítem 1: lobby amb el tutorial obert, sense scroll (${vp.tag})`, async ({ page }) => {
      await seedLobby(page, e2ePoolId(), true);
      await page.goto("/");
      await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 30_000 });
      await expect(page.getByRole("button", { name: /^Saltar/ })).toBeVisible({ timeout: 10_000 });
      await page.waitForTimeout(450);
      await expectNoScroll(page, `lobby+tutorial ${vp.tag}`);
    });

    test(`ítem 3: sense or a l'aposta, al torn i a la liquidació (${vp.tag})`, async ({ page }) => {
      const pid = e2ePoolId();
      await seedSolo(page, playerBettingSnapshot(pid, "Apostadora"), pid, "Apostadora");
      await page.goto("/");
      await expect(page.getByTestId("bet-confirm")).toBeVisible({ timeout: 30_000 });
      await page.waitForTimeout(450);
      const counter = page.getByTestId("current-turn-countdown");
      if (await counter.isVisible()) {
        const c = await counter.evaluate((el) => ({ bg: getComputedStyle(el).backgroundColor, color: getComputedStyle(el).color, border: getComputedStyle(el).borderTopWidth }));
        expect(c.bg).toBe("rgba(0, 0, 0, 0)");
        expect(c.color).toBe("rgba(245, 242, 235, 0.65)");
        expect(c.border).toBe("1px");
      }
      await expectNoYellow(page, "aposta");
      await expectNoAxe(page);
    });

    test(`ítem 3: torn propi sense groc (${vp.tag})`, async ({ page }) => {
      const pid = e2ePoolId();
      await seedSolo(page, playerTurnSnapshot(pid, "Jugadora"), pid, "Jugadora");
      await page.goto("/");
      await expect(page.getByTestId("action-hit")).toBeEnabled({ timeout: 30_000 });
      await page.waitForTimeout(450);
      await expectNoYellow(page, "torn");
    });

    test(`ítem 3: liquidació sense vora daurada a la banca (${vp.tag})`, async ({ page }) => {
      const pid = e2ePoolId();
      await seedSolo(page, settlementSnapshotJson(pid, "Liquida"), pid, "Liquida");
      await page.goto("/");
      await expect(page.getByTestId("settlement-sheet")).toBeVisible({ timeout: 30_000 });
      await page.waitForTimeout(450);
      expect(await scanColors(page, { mode: "accent-border" }), "cap vora #C8A96B a la liquidació").toEqual([]);
      await expectNoYellow(page, "liquidació");
    });

    test(`ítem 4: pantalla final amb un sol botó de revenja i sense ajustos (${vp.tag})`, async ({ page }) => {
      const pid = e2ePoolId();
      await seedSolo(page, matchEndSnapshotJson(pid, "Final"), pid, "Final");
      await page.goto("/");
      await expect(page.getByTestId("match-end-overlay")).toBeVisible({ timeout: 30_000 });
      await page.waitForTimeout(450);
      expect(await visibleRematchButtons(page), "exactament 1 botó de revenja").toBe(1);
      await expect(page.getByTestId("match-settings-save")).toBeHidden();
      await expect(page.getByRole("button", { name: /desar ajustos/i })).toHaveCount(0);
      await expectNoYellow(page, "final");
      await expectNoAxe(page);
    });
  });
}

test.describe("jugabilitat v2 · revenja i «Enviant…»", () => {
  for (const vp of VIEWPORTS) {
    test(`ítem 6: «Enviant…» no apareix en 10 cartes ràpides (${vp.tag})`, async ({ page }) => {
      test.setTimeout(90_000);
      await page.setViewportSize({ width: vp.width, height: vp.height });
      const pid = e2ePoolId();
      // 1 punt + 10 figures (½) = 6: el mall de la fixture només dona figures.
      await seedSolo(page, playerTurnSnapshot(pid, "Jugadora"), pid, "Jugadora");
      await page.addInitScript(() => {
        const w = window as unknown as { __sendingSeen: number };
        w.__sendingSeen = 0;
        const start = () =>
          new MutationObserver(() => {
            const hit = document.querySelector<HTMLElement>("[data-testid=action-hit]");
            const stand = document.querySelector<HTMLElement>("[data-testid=action-stand]");
            if (/enviant/i.test(`${hit?.innerText ?? ""} ${stand?.innerText ?? ""}`)) w.__sendingSeen += 1;
          }).observe(document, { subtree: true, childList: true, characterData: true, attributes: true });
        start();
      });
      await page.goto("/");
      const hit = page.getByTestId("action-hit");
      await expect(hit).toBeEnabled({ timeout: 30_000 });
      // Taula gran (v147): sense total propi; es compten les cartes i es comprova que no hi ha cap total.
      const cards = page.locator("[data-testid=local-hand-card], .desktop-own-card");
      for (let i = 0; i < 10; i += 1) {
        const before = await cards.count();
        await hit.click();
        await expect(cards).toHaveCount(before + 1, { timeout: 3_000 });
        await expect(hit).toBeEnabled({ timeout: 3_000 });
      }
      await expect(page.getByTestId("my-hand-points")).toHaveCount(0);
      expect(await page.evaluate(() => (window as unknown as { __sendingSeen: number }).__sendingSeen), "«Enviant…» mai visible").toBe(0);
    });

    test(`ítem 5: la revenja comença amb el registre d'accions buit (${vp.tag})`, async ({ page }) => {
      test.setTimeout(120_000);
      await page.setViewportSize({ width: vp.width, height: vp.height });
      const pid = e2ePoolId();
      const snap = JSON.parse(playerTurnSnapshot(pid, "Jugadora", [5])) as { room: Record<string, unknown> };
      // Darrera mà d'una partida d'1 mà: en plantar-se, la partida acaba.
      snap.room.phaseB = { handsTotal: 1, handsCompleted: 0, chipPool: 5900 };
      snap.room.matchProgress = { handNumber: 1, handsTotal: 1, structuredMatch: true };
      await seedSolo(page, JSON.stringify(snap), pid, "Jugadora");
      await page.addInitScript(() => {
        const w = window as unknown as { __timeline: string[] };
        w.__timeline = [];
        new MutationObserver(() => {
          // Taula v2 (retoc 1): la tira d'accions del mòbil ja no hi és; la mateixa última acció va a la regió viva.
          const text = document.querySelector("[data-testid=game-action-live-region]")?.textContent?.trim();
          if (text && w.__timeline[w.__timeline.length - 1] !== text) w.__timeline.push(text);
        }).observe(document, { subtree: true, childList: true, characterData: true });
      });
      await page.goto("/");
      await expect(page.getByTestId("action-stand")).toBeEnabled({ timeout: 30_000 });
      await page.getByTestId("action-stand").click();
      const next = page.getByTestId("settlement-next-hand");
      const overlay = page.getByTestId("match-end-overlay");
      await expect(next.or(overlay)).toBeVisible({ timeout: 30_000 });
      if (await next.isVisible()) await next.click();
      await expect(overlay).toBeVisible({ timeout: 30_000 });
      const latest = page.getByTestId("game-action-live-region");
      expect(await visibleRematchButtons(page)).toBe(1);
      const before = await page.evaluate(() => (window as unknown as { __timeline: string[] }).__timeline.slice());
      console.log(`[jugabilitat-v2] registre abans de la revenja: «${before.slice(-2).join(" / ")}» (${vp.tag})`);
      expect(before.join(" "), "la partida anterior ha deixat accions al registre").toMatch(/Jugadora|Laia|banca/i);
      await page.getByTestId("match-revenge-button").click();
      await expect(overlay).toBeHidden({ timeout: 5_000 });
      await page.waitForTimeout(1_000);
      // La regió viva sempre hi és (sr-only): la comprovació es fa sempre, no només si la tira és visible.
      const text = (await latest.textContent())?.trim() ?? "";
      console.log(`[jugabilitat-v2] registre 1 s després de la revenja: «${text}» (${vp.tag})`);
      expect(text).not.toMatch(/Jugadora|Laia/);
      // I l'historial (obert amb la icona de la capçalera) tampoc no arrossega la partida anterior.
      const historyButton = page.getByTestId("v2-history-button");
      if (await historyButton.isVisible()) {
        await historyButton.click();
        const timeline = page.getByTestId("recent-action-timeline");
        await expect(timeline).toBeVisible();
        const latestEntry = (await timeline.locator('[data-latest="true"]').first().textContent().catch(() => null))?.trim() ?? "";
        console.log(`[jugabilitat-v2] historial després de la revenja: «${latestEntry}» (${vp.tag})`);
        expect(latestEntry).not.toMatch(/Jugadora|Laia/);
        await historyButton.click();
      }
    });
  }
});
