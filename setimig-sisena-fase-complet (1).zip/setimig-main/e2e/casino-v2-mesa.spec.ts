import AxeBuilder from "@axe-core/playwright";
import { expect, test, type Page } from "@playwright/test";
import { safeHalfHandSnapshotJson } from "./helpers/f2ProbabilityFixtures.ts";
import { settlementSnapshotJson } from "./helpers/esteticaFormalFixtures.ts";
import { openFriendsLobby } from "./helpers/friendsLobby.ts";

/**
 * Casino v2 · PR 2 (docs: estetica-casino-v2.md §4–§6): tapet, cartes, botons, fitxes,
 * modal, lobby, barra d'acció i moviment. Només mesures (sense captures).
 */
const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844 },
  { tag: "375x667", width: 375, height: 667 },
  { tag: "360x740", width: 360, height: 740 },
] as const;

// v3 · estil logo: negre neutre, superfícies #161616/#1F1F1F i marfil; l'or queda només per al torn i el 7½ natural.
const IVORY = "rgb(245, 242, 235)";
const INK = "rgb(11, 11, 11)";
const SURFACE = "rgb(22, 22, 22)";
const SURFACE_2 = "rgb(31, 31, 31)";
const LINE = "rgba(245, 242, 235, 0.18)";
const TEXT = "rgb(245, 242, 235)";

function seed(page: Page, opts: { playerId: string; snapshot?: string; settlement?: boolean }) {
  return page.addInitScript(
    ({ playerId, snapshot, settlement }) => {
      if (sessionStorage.getItem("setimig_e2e_seeded") === "1") return;
      sessionStorage.setItem("setimig_e2e_seeded", "1");
      localStorage.setItem("setimig_player_id", playerId);
      localStorage.setItem("setimig_player_name", "Casino");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      localStorage.setItem("setimig_house_rules_enabled", "1");
      localStorage.setItem(
        "setimig_age_gate",
        JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
      );
      if (snapshot) {
        const parsed = JSON.parse(snapshot) as { room?: { settlementStartedAt?: number; lastRound?: { at?: number } } };
        if (settlement && parsed.room) {
          parsed.room.settlementStartedAt = Date.now();
          if (parsed.room.lastRound) parsed.room.lastRound.at = Date.now();
        }
        localStorage.setItem("setimig_local_solo_snapshot", JSON.stringify(parsed));
        sessionStorage.setItem("setimig_solo_rejoin", "1");
        sessionStorage.setItem("setimig_solo_local", "1");
      }
    },
    { playerId: opts.playerId, snapshot: opts.snapshot ?? null, settlement: !!opts.settlement }
  );
}

async function axeViolations(page: Page) {
  const results = await new AxeBuilder({ page }).analyze();
  return results.violations.map((v) => `${v.id}: ${v.nodes.map((n) => n.target.join(" ")).join(" | ")}`);
}

async function expectNoOverflow(page: Page, noVerticalScroll: boolean) {
  const m = await page.evaluate(() => ({
    scrollWidth: document.documentElement.scrollWidth,
    scrollHeight: document.documentElement.scrollHeight,
    innerWidth: window.innerWidth,
    innerHeight: window.innerHeight,
  }));
  expect(m.scrollWidth, "sense desbordament horitzontal").toBeLessThanOrEqual(m.innerWidth + 1);
  if (noVerticalScroll) expect(m.scrollHeight, "sense scroll vertical").toBeLessThanOrEqual(m.innerHeight + 1);
}

/** §5: cap @keyframes amb scale > 1, cap keyframe eliminat a §6 i un sol bloc prefers-reduced-motion: reduce. */
async function motionRules(page: Page) {
  return page.evaluate(() => {
    const scaleUp: string[] = [];
    const names: string[] = [];
    let reducedBlocks = 0;
    const walk = (rules: CSSRuleList) => {
      for (const rule of Array.from(rules)) {
        if (rule instanceof CSSKeyframesRule) {
          names.push(rule.name);
          for (const m of rule.cssText.matchAll(/scale\(\s*([0-9.]+)/g)) {
            // Excepció aprovada (jugabilitat v2 · ripple del HIT, 480 ms): l'ona creix des del punt del toc.
            if (Number(m[1]) > 1 && rule.name !== "v2-ripple") scaleUp.push(`${rule.name}: scale(${m[1]})`);
          }
        } else if (rule instanceof CSSMediaRule) {
          // Un sol bloc de reset global (selector universal); els blocs de la taula v2 només afinen elements concrets.
          if (
            /prefers-reduced-motion:\s*reduce/.test(rule.conditionText) &&
            Array.from(rule.cssRules).some((r) => r instanceof CSSStyleRule && /(^|[\s,>])\*/.test(r.selectorText))
          )
            reducedBlocks += 1;
          walk(rule.cssRules);
        }
      }
    };
    for (const sheet of Array.from(document.styleSheets)) {
      try {
        walk(sheet.cssRules);
      } catch {
        /* full d'estil d'un altre origen */
      }
    }
    return { scaleUp, names, reducedBlocks };
  });
}

/** Animacions CSS en curs: durada i iteracions. */
async function runningCssAnimations(page: Page) {
  return page.evaluate(() =>
    document
      .getAnimations()
      .filter((a) => a.constructor.name === "CSSAnimation")
      .map((a) => {
        const t = a.effect?.getTiming();
        return {
          name: (a as CSSAnimation).animationName,
          duration: Number(t?.duration ?? 0),
          iterations: Number(t?.iterations ?? 1),
        };
      })
  );
}

/** Pintures SVG verdes dins de les cartes visibles (bastos inclòs). */
async function greenCardPaint(page: Page) {
  return page.evaluate(() => {
    const out: string[] = [];
    const toRgb = (value: string) => {
      const m = value.match(/rgba?\(([^)]+)\)/);
      if (!m) return null;
      const [r, g, b] = m[1].split(/[\s,/]+/).filter(Boolean).map(Number);
      return { r, g, b };
    };
    for (const el of Array.from(document.querySelectorAll<SVGElement>(".spanish-card svg *"))) {
      const cs = getComputedStyle(el);
      for (const paint of [cs.fill, cs.stroke]) {
        const c = toRgb(paint);
        if (!c) continue;
        const max = Math.max(c.r, c.g, c.b);
        const min = Math.min(c.r, c.g, c.b);
        if (max < 24 || max - min < 18 || (max - min) / max < 0.2) continue;
        let hue = max === c.r ? ((c.g - c.b) / (max - min)) % 6 : max === c.g ? (c.b - c.r) / (max - min) + 2 : (c.r - c.g) / (max - min) + 4;
        hue = (hue * 60 + 360) % 360;
        if (hue >= 75 && hue <= 170) out.push(`${el.tagName} ${paint}`);
      }
    }
    return out;
  });
}

for (const vp of VIEWPORTS) {
  const smallScreen = vp.tag !== "390x844";

  test.describe(`Casino v2 mesa ${vp.tag}`, () => {
    test.use({ viewport: { width: vp.width, height: vp.height } });

    test("taula en joc: tapet, cartes, dors, botons i barra d'acció", async ({ page }) => {
      const playerId = `cv2m-play-${vp.tag}`;
      await seed(page, { playerId, snapshot: safeHalfHandSnapshotJson(playerId, "Casino") });
      await page.route("**/socket.io/**", (route) => route.abort());
      await page.goto("/");
      const hit = page.getByTestId("action-hit");
      const stand = page.getByTestId("action-stand");
      await expect(hit).toBeVisible({ timeout: 30_000 });
      await page.waitForTimeout(500); // repartiment (≤ 400 ms) acabat

      const s = await page.evaluate(() => {
        const css = (el: Element | null, pseudo?: string) => (el ? getComputedStyle(el, pseudo) : null);
        const felt = document.querySelector(".game-table-felt");
        const card = document.querySelector(".spanish-card");
        const deck = document.querySelector(".table-deck-stack");
        const hit = document.querySelector('[data-testid="action-hit"]');
        const stand = document.querySelector('[data-testid="action-stand"]');
        const dock = document.querySelector('[data-testid="action-dock"]');
        const points = document.querySelector('.mobile-player-points-badge');
        const f = css(felt)!;
        const c = css(card)!;
        const d = css(deck);
        const h = css(hit)!;
        const st = css(stand)!;
        const dk = css(dock)!;
        const p = css(points);
        return {
          feltImage: f.backgroundImage,
          feltBorder: `${f.borderTopWidth} ${f.borderTopStyle} ${f.borderTopColor}`,
          feltShadow: f.boxShadow,
          feltBefore: css(felt, "::before")!.display,
          cardRadius: c.borderTopLeftRadius,
          cardShadow: c.boxShadow,
          cardFilter: c.filter,
          cardBorder: c.borderTopColor,
          deckBg: d?.backgroundColor ?? null,
          deckImage: d?.backgroundImage ?? null,
          deckMonogramColor: deck ? getComputedStyle(deck, "::after").color : null,
          deckMonogramFont: deck ? getComputedStyle(deck, "::after").fontFamily : null,
          hitBg: h.backgroundColor,
          hitColor: h.color,
          hitRadius: h.borderTopLeftRadius,
          hitShadow: h.boxShadow,
          hitTransform: h.textTransform,
          hitSpacing: h.letterSpacing,
          standBg: st.backgroundColor,
          standBorder: `${st.borderTopWidth} ${st.borderTopColor}`,
          standColor: st.color,
          dockBg: dk.backgroundColor,
          dockBorderTop: `${dk.borderTopWidth} ${dk.borderTopStyle}`,
          pointsBg: p?.backgroundColor ?? null,
          pointsBorder: p?.borderTopWidth ?? null,
          pointsRadius: p?.borderTopLeftRadius ?? null,
        };
      });

      // Taula v2 · bloc 3 (#222): el tapet és el fons fosc radial del vídeo v2 (kit tokens --sm-bg-0…3), sense inset.
      expect.soft(s.feltImage).toBe(
        "radial-gradient(85% 60% at 50% 46%, rgb(31, 31, 24) 0%, rgb(20, 21, 16) 45%, rgb(14, 15, 12) 70%, rgb(6, 7, 5) 100%)"
      );
      expect.soft(s.feltBorder).toBe(`1px solid ${LINE}`);
      expect.soft(s.feltShadow).toBe("none");
      expect.soft(s.feltBefore).toBe("none");
      // v3 Cartes: --r-card, sense ombra.
      expect.soft(s.cardRadius).toBe("4px");
      expect.soft(s.cardShadow).toBe("none");
      expect.soft(s.cardFilter).toBe("none");
      expect.soft(s.cardBorder).toBe("rgba(11, 11, 11, 0.12)");
      // §4 Dors del munt: --c-surface, sense degradat, monograma serif daurat.
      if (s.deckBg !== null) {
        expect.soft(s.deckBg).toBe(SURFACE);
        expect.soft(s.deckImage).toBe("none");
        expect.soft(s.deckMonogramColor).toBe(IVORY);
        expect.soft(s.deckMonogramFont).toContain("Cormorant Garamond");
      }
      // v3 Botó primari: marfil, tinta, Cinzel en majúscules .14em, --r-ctl (2 px) i sense ombra.
      expect.soft(s.hitBg).toBe(IVORY);
      expect.soft(s.hitColor).toBe("rgb(20, 19, 15)");
      // Taula v2 (kit): HIT marfil #F5F2EB amb text #14130F, radi 6 px i Cinzel .28em.
      expect.soft(s.hitRadius).toBe("6px");
      expect.soft(s.hitShadow).toBe("none");
      expect.soft(s.hitTransform).toBe("uppercase");
      expect.soft(Number.parseFloat(s.hitSpacing)).toBeCloseTo(3.6, 1);
      // v3 Botó secundari (Plantar-se): transparent, filet ivori, text --c-text.
      // Taula v2 (kit): STAND #0F100D amb vora marfil de 2 px.
      expect.soft(s.standBg).toBe("rgb(15, 16, 13)");
      expect.soft(s.standBorder).toBe(`2px ${IVORY}`);
      expect.soft(s.standColor).toBe(TEXT);
      // §4 Barra d'acció: --c-bg amb filet superior.
      expect.soft(s.dockBg).toBe(INK);
      expect.soft(s.dockBorderTop).toBe("1px solid");
      // §6 Cercle «PUNTS» eliminat.
      if (s.pointsBg !== null) {
        expect.soft(s.pointsBg).toBe("rgba(0, 0, 0, 0)");
        expect.soft(s.pointsBorder).toBe("0px");
        expect.soft(s.pointsRadius).toBe("0px");
      }

      // Botons d'acció sencers: > 100 px d'amplada i ≥ 44 px d'alçada, dins de la pantalla.
      for (const [label, button] of [
        ["Demanar carta", hit],
        ["Plantar-se", stand],
      ] as const) {
        const box = await button.boundingBox();
        expect(box, label).not.toBeNull();
        expect(box!.width, `${label} amplada`).toBeGreaterThan(100);
        expect(box!.height, `${label} alçada`).toBeGreaterThanOrEqual(44);
        expect(box!.x, `${label} esquerra`).toBeGreaterThanOrEqual(0);
        expect(box!.x + box!.width, `${label} dreta`).toBeLessThanOrEqual(vp.width + 1);
        expect(box!.y + box!.height, `${label} a baix`).toBeLessThanOrEqual(vp.height + 1);
        const clipped = await button.evaluate((el) => el.scrollWidth > el.clientWidth + 1);
        expect(clipped, `${label} sense text retallat`).toBe(false);
      }

      expect(await greenCardPaint(page), "cartes sense verds").toEqual([]);
      await expectNoOverflow(page, smallScreen);

      // §5 Moviment: sense scale > 1, sense keyframes de §6 i un sol bloc reduced-motion.
      const rules = await motionRules(page);
      expect(rules.scaleUp).toEqual([]);
      for (const removed of [
        "celebracio-coin-fall",
        "settlement-chips-fly",
        "hand-bust-shake",
        "turn-pill-flash-keyframes",
        "hand-sevenhalf-glow",
        "celebracio-7mig-pulse",
        "settlement-particle-rise",
      ]) {
        expect(rules.names, `keyframe ${removed}`).not.toContain(removed);
      }
      expect(rules.reducedBlocks).toBe(1);
      for (const anim of await runningCssAnimations(page)) {
        // Fons v2 (#222, kit bokeh.css): la «respiració» del bokeh és ambient, lenta i en bucle per disseny.
        if (anim.name.startsWith("table-bokeh")) continue;
        expect(anim.duration, `${anim.name} ≤ 400 ms`).toBeLessThanOrEqual(400);
        expect(Number.isFinite(anim.iterations), `${anim.name} sense bucle`).toBe(true);
      }

      expect(await axeViolations(page), "axe taula").toEqual([]);
    });

    test("moviment reduït: cap animació CSS ni transició llarga", async ({ page }) => {
      await page.emulateMedia({ reducedMotion: "reduce" });
      const playerId = `cv2m-rm-${vp.tag}`;
      await seed(page, { playerId, snapshot: settlementSnapshotJson(playerId, "Casino"), settlement: true });
      await page.route("**/socket.io/**", (route) => route.abort());
      await page.goto("/");
      await expect(page.getByTestId("settlement-sheet")).toBeVisible({ timeout: 30_000 });
      const m = await page.evaluate(() => {
        const card = document.querySelector(".settlement-card")!;
        const btn = document.querySelector('[data-testid="settlement-next-hand"]')!;
        return {
          // Només la taula: el fos del vestíbul (lobby-v4-fade) pot quedar penjant mentre es munta la partida.
          cssAnimations: document
            .getAnimations()
            .filter((a) => a.constructor.name === "CSSAnimation")
            .filter((a) => ((a.effect as KeyframeEffect | null)?.target as Element | null)?.closest(".game-table-root")).length,
          cssAnimationNames: document
            .getAnimations()
            .filter((a) => a.constructor.name === "CSSAnimation")
            .map((a) => `${(a as CSSAnimation).animationName}@${((a.effect as KeyframeEffect | null)?.target as HTMLElement | null)?.className?.toString().slice(0, 30)}`),
          cardAnimation: getComputedStyle(card).animationName,
          btnTransition: `${getComputedStyle(btn).transitionProperty} ${getComputedStyle(btn).transitionDuration}`,
        };
      });
      expect(m.cssAnimations, m.cssAnimationNames.join(" | ")).toBe(0);
      expect(m.cardAnimation).toBe("none");
      expect(m.btnTransition).toBe("opacity 0.12s");
      await expectNoOverflow(page, false);
    });

    test("modal de liquidació: superfície, filets, radi i ombra", async ({ page }) => {
      const playerId = `cv2m-set-${vp.tag}`;
      await seed(page, { playerId, snapshot: settlementSnapshotJson(playerId, "Casino"), settlement: true });
      await page.route("**/socket.io/**", (route) => route.abort());
      await page.goto("/");
      await expect(page.getByTestId("settlement-sheet")).toBeVisible({ timeout: 30_000 });
      await expect(page.getByTestId("settlement-next-hand")).toBeEnabled({ timeout: 10_000 });
      await page.waitForTimeout(450); // entrada del modal (320 ms) acabada
      await expect(page.getByTestId("settlement-sheet")).toHaveCount(1);
      await expect(page.locator(".settlement-win-particle")).toHaveCount(0);
      const s = await page.evaluate(() => {
        const card = document.querySelector(".settlement-card")!;
        const title = document.getElementById("settlement-round-title")!;
        const next = document.querySelector('[data-testid="settlement-next-hand"]')!;
        const c = getComputedStyle(card);
        return {
          bg: c.backgroundColor,
          radius: c.borderTopLeftRadius,
          shadow: c.boxShadow,
          borderTop: c.borderTopColor,
          border: c.borderLeftColor,
          titleFont: getComputedStyle(title).fontFamily,
          titleSize: getComputedStyle(title).fontSize,
          nextBg: getComputedStyle(next).backgroundColor,
          nextColor: getComputedStyle(next).color,
          nextHeight: next.getBoundingClientRect().height,
        };
      });
      // v3 Modal: --c-surface-2, --r-modal (4 px), sense ombra, filet --rule.
      expect(s.bg).toBe(SURFACE_2);
      expect(s.radius).toBe("4px");
      expect(s.shadow).toBe("none");
      expect(s.borderTop).toBe(LINE);
      expect(s.border).toBe(LINE);
      // v3: capçaleres i etiquetes en Cinzel.
      expect(s.titleFont).toContain("Cinzel");
      expect(s.nextBg).toBe(IVORY);
      expect(s.nextColor).toBe(INK);
      expect(s.nextHeight).toBeGreaterThanOrEqual(52);
      await expectNoOverflow(page, false);
      expect(await axeViolations(page), "axe liquidació").toEqual([]);
    });

    test("lobby i fitxes d'aposta", async ({ page }) => {
      await seed(page, { playerId: `cv2m-lobby-${vp.tag}` });
      await page.goto("/");
      await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 60_000 });
      // Lobby v4 (PR-L2): espera que acabi l'entrada (≤ 600 ms) abans de mesurar colors i axe.
      await page.waitForFunction(() => document.getAnimations().every((a) => a.playState !== "running"));
      // Lobby v4 (PR-L1): el CTA «Jugar» és un botó primari marfil sòlid (abans targeta #161616 amb filet).
      const l = await page.evaluate(() => {
        const p = getComputedStyle(document.querySelector('[data-testid="play-vs-ai-button"]')!);
        return { primaryBg: p.backgroundColor, primaryColor: p.color, primaryRadius: p.borderTopLeftRadius };
      });
      expect(l.primaryBg).toBe(IVORY);
      expect(l.primaryColor).toBe(INK);
      expect(l.primaryRadius).toBe("2px");
      await expectNoOverflow(page, false);
      expect(await axeViolations(page), "axe lobby").toEqual([]);

      await page.getByTestId("lobby-context").click();
      await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
      await page.getByTestId("ai-bot-count-2").click();
      await page.getByRole("button", { name: "Començar" }).click();
      const minus = page.getByTestId("bet-minus");
      await expect(minus).toBeVisible({ timeout: 30_000 });
      const chips = await page.evaluate(() => {
        // Redisseny 3 pantalles · apostar: el cercle del −/+ és el ::before (40 px) dins d'una zona tàctil de 44 px.
        const m = getComputedStyle(document.querySelector('[data-testid="bet-minus"]')!, "::before");
        const r = document.querySelector('[data-testid="bet-minus"]')!.getBoundingClientRect();
        const preset = document.querySelector(".bet-screen-chip");
        const sel = document.querySelector(".bet-screen-chip.is-selected");
        return {
          w: r.width,
          h: r.height,
          bg: m.backgroundColor,
          border: `${m.borderTopWidth} ${m.borderTopColor}`,
          round: Number.parseFloat(m.borderTopLeftRadius) >= r.height / 2 - 0.5,
          preset: preset
            ? { bg: getComputedStyle(preset).backgroundColor, border: getComputedStyle(preset).borderTopColor, h: preset.getBoundingClientRect().height }
            : null,
          selected: sel ? { bg: getComputedStyle(sel).backgroundColor, color: getComputedStyle(sel).color } : null,
        };
      });
      // Redisseny 3 pantalles · apostar: −/+ i fitxes són cercles buits amb filet ivori al 28 %; la seleccionada, ivori amb tinta.
      expect(chips.w).toBeGreaterThanOrEqual(44);
      expect(chips.h).toBeGreaterThanOrEqual(44);
      expect(chips.bg).toBe("rgba(0, 0, 0, 0)");
      expect(chips.border).toBe("1px rgba(245, 242, 235, 0.28)");
      expect(chips.round).toBe(true);
      if (chips.preset) {
        expect(chips.preset.bg).toMatch(/^(rgba\(0, 0, 0, 0\)|rgb\(245, 242, 235\))$/);
        expect(chips.preset.h).toBeGreaterThanOrEqual(44);
      }
      if (chips.selected) {
        expect(chips.selected.bg).toBe(IVORY);
        expect(chips.selected.color).toBe(INK);
      }
      await expectNoOverflow(page, smallScreen);
      expect(await axeViolations(page), "axe apostes").toEqual([]);
    });
  });
}

test.describe("Codi de taula privada (#148): 6 caràcters, els antics de 4–5 valen", () => {
  test.use({ viewport: { width: 375, height: 667 } });

  test("camp de codi: accepta 4–6 (fins a 8), demana 6 i axe 0", async ({ page }) => {
    await seed(page, { playerId: "cv2m-code" });
    await page.goto("/");
    await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 60_000 });
    await openFriendsLobby(page);
    const input = page.getByTestId("private-join-code");
    const join = page.getByTestId("join-private-table");
    await expect(input).toHaveAttribute("placeholder", /AB12CD/);
    await expect(page.getByTestId("private-join-code-help")).toContainText("6 caràcters");
    await expect(input).toHaveAttribute("aria-describedby", "private-join-code-help");
    await input.fill("ab1");
    await expect(join).toBeDisabled();
    for (const code of ["k7m2", "ab12c", "ab12cd"]) {
      await input.fill(code);
      await expect(input).toHaveValue(code.toUpperCase());
      await expect(join).toBeEnabled();
    }
    await input.fill("abcdefghjk");
    await expect(input).toHaveValue("ABCDEFGH");
    await input.fill("AB12CD");
    expect(await axeViolations(page), "axe amics").toEqual([]);
  });
});
