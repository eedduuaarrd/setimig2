import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession";

const VIEWPORTS = [
  { width: 390, height: 844 },
  { width: 1280, height: 800 },
] as const;

async function boot(page: Page) {
  const id = e2ePoolId();
  await seedE2eSession(page, id);
  await page.addInitScript(() => {
    localStorage.setItem("setimig_player_name", "Temps");
    localStorage.setItem("setimig_onboarding_v1", "1");
    localStorage.setItem("setimig_interactive_tutorial_v1", "1");
    localStorage.setItem("setimig_table_tutorial_v1", "1");
    if (!localStorage.getItem("setimig.locale")) localStorage.setItem("setimig.locale", "ca");
    localStorage.setItem(
      "setimig_age_gate",
      JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
    );
  });
}

async function startSolo(page: Page) {
  await page.goto("/");
  await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 60_000 });
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  await page.getByTestId("ai-bot-count-1").click();
  await page.getByTestId("ai-bot-picker-start").click();
  await expect(page.getByTestId("bet-confirm")).toBeVisible({ timeout: 40_000 });
}

async function countdownSeconds(page: Page): Promise<number> {
  const text = await page.getByTestId("current-turn-countdown").first().innerText();
  return Number(text.replace(/\D/g, ""));
}

async function openRules(page: Page, locale: string, text: string) {
  await page.goto("/regles/");
  await page.evaluate((l) => localStorage.setItem("setimig.locale", l), locale);
  await page.reload();
  const line = page.getByTestId("regles-timers");
  await expect(line).toBeVisible({ timeout: 20_000 });
  await expect(line).toContainText(text);
}

for (const viewport of VIEWPORTS) {
  test(`regles i compte enrere d'aposta: 18 s i 22 s (${viewport.width})`, async ({ page }) => {
    await page.setViewportSize(viewport);
    await boot(page);
    await openRules(page, "ca", "18 s per apostar · 22 s per jugar");
    await openRules(page, "en", "18 s to bet · 22 s to play");
    await openRules(page, "es", "18 s para apostar · 22 s para jugar");
    await startSolo(page);
    const seconds = await countdownSeconds(page);
    expect(seconds).toBeGreaterThanOrEqual(15);
    expect(seconds).toBeLessThanOrEqual(18);
  });
}

test("390: en esgotar-se el temps d'aposta, avís d'aposta mínima", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await boot(page);
  await startSolo(page);
  const notice = page.getByTestId("turn-timeout-notice");
  await expect(notice).toHaveText("Temps esgotat: aposta mínima", { timeout: 25_000 });
  await expect(notice).toBeVisible();
});
