import { expect, test, type BrowserContext, type Route } from "@playwright/test";
import { blockSocketIoCtx, openLoginEmail } from "./helpers/loginSession.ts";

/**
 * QA v142 (1280): (1) el nom triat en registrar-se es desa i surt a la capçalera, també després de recarregar;
 * (3) un compte que ja existeix no torna a veure «Només +18» després del codi; (4) Tab al /login (amb l'intro
 * d'inici en marxa) no s'encalla mai a «Saltar» ni va a BODY, endavant i enrere.
 */
const PID = "qa-v142-01";
const TOKEN = "qa.v142.token";

async function mockServer(ctx: BrowserContext, created: boolean) {
  const state = { authed: false, name: created ? "" : "Antic" };
  await ctx.route("**/api/**", async (route: Route) => {
    const req = route.request();
    const path = new URL(req.url()).pathname.replace(/\/$/, "");
    const body = (req.postDataJSON?.() ?? {}) as Record<string, unknown>;
    const json = (status: number, j: unknown) => route.fulfill({ status, contentType: "application/json", body: JSON.stringify(j) });
    const key = `${req.method()} ${path}`;
    if (key === "GET /api/auth/providers") return json(200, { email: true, google: true, passkey: false, rpId: "sevenhalf.club" });
    if (key === "POST /api/auth/email/start") return json(202, { ok: true, expiresInSec: 600 });
    if (key === "POST /api/auth/email/verify") {
      if (created && body.ageConfirmed !== true) return json(403, { code: "AGE_CONFIRMATION_REQUIRED" });
      state.authed = true;
      return json(200, { playerId: PID, playerToken: TOKEN, method: "email", created, linked: true, switchedAccount: false });
    }
    if (path === "/api/health") return route.continue();
    if (!state.authed) return json(401, { code: "auth_required" });
    if (key === "PUT /api/profile") {
      state.name = String(body.displayName ?? "");
      return json(200, { displayName: state.name, avatarDataUrl: null });
    }
    if (key === "GET /api/profile") return json(200, { displayName: state.name || "Jugador", avatarDataUrl: null });
    if (key === "GET /api/auth/me") return json(200, { playerId: PID, emails: ["qa@example.com"], google: false, passkeys: 0, verified: true });
    // Com el servidor real: sense Bearer ni galeta, 401.
    if (key === "POST /api/player-session" && !route.request().headers()["authorization"]) return json(401, { error: "auth_required" });
    if (key === "POST /api/player-session") return json(200, { playerId: PID, playerToken: TOKEN });
    if (key === "GET /api/balance") return json(200, { chips: 1000, freeClaim: { available: false, nextAt: null } });
    return json(200, { ok: true });
  });
  return state;
}

async function newCtx(browser: import("@playwright/test").Browser, intro = false) {
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 800 }, locale: "ca-ES", colorScheme: "dark" });
  if (!intro) await ctx.addInitScript(() => sessionStorage.setItem("setimig_intro_launch_v1", "1"));
  await blockSocketIoCtx(ctx);
  return ctx;
}

async function signIn(page: import("@playwright/test").Page) {
  await page.goto("/login");
  await openLoginEmail(page);
  await page.getByTestId("login-email-input").fill("qa@example.com");
  await page.getByTestId("login-email-submit").click();
  await page.getByTestId("login-code-input").fill("123456");
  await page.getByTestId("login-code-submit").click();
}

test("1 · registre a 1280: el nom triat es desa i surt a la capçalera (també en recarregar)", async ({ browser }) => {
  const ctx = await newCtx(browser);
  const state = await mockServer(ctx, true);
  const page = await ctx.newPage();
  await signIn(page);
  await page.getByTestId("login-age-checkbox").check();
  await page.getByTestId("login-code-submit").click();
  await page.getByTestId("login-name-input").fill("Nova QA");
  await page.getByTestId("login-name-submit").click();
  await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 20_000 });
  expect(state.name).toBe("Nova QA");
  await expect(page.locator(".header-profile")).toContainText("Nova QA");
  await page.reload();
  await expect(page.locator(".header-profile")).toContainText("Nova QA", { timeout: 20_000 });
  await ctx.close();
});

test("1 · un compte encallat amb «Jugador» torna a demanar el nom", async ({ browser }) => {
  const ctx = await newCtx(browser);
  const state = await mockServer(ctx, true);
  state.authed = true;
  await ctx.addInitScript(([pid, tok]) => {
    localStorage.setItem("setimig_player_id", pid);
    localStorage.setItem("setimig_player_token", tok);
    localStorage.setItem("setimig_player_name", "Jugador");
  }, [PID, TOKEN]);
  const page = await ctx.newPage();
  await page.goto("/");
  // Primer, si cal, el 18+ propi de l'app; després, el nom.
  const age = page.getByTestId("age-gate-accept");
  if (await age.isVisible({ timeout: 8_000 }).catch(() => false)) await age.click();
  const input = page.locator("[role=dialog] input[type=text], [role=dialog] input:not([type])").first();
  await expect(input).toBeVisible({ timeout: 20_000 });
  await ctx.close();
});

test("3 · compte existent: després del codi no torna a sortir «Només +18»", async ({ browser }) => {
  const ctx = await newCtx(browser);
  await mockServer(ctx, false);
  const page = await ctx.newPage();
  await signIn(page);
  await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 20_000 });
  await expect(page.getByTestId("age-gate")).toHaveCount(0);
  await expect(page.getByTestId("login-signup-age")).toHaveCount(0);
  await page.reload();
  await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 20_000 });
  await expect(page.getByTestId("age-gate")).toHaveCount(0);
  await ctx.close();
});

const activeId = (page: import("@playwright/test").Page) =>
  page.evaluate(() => {
    const e = document.activeElement as HTMLElement | null;
    if (!e || e === document.body || e === document.documentElement) return "BODY";
    return `${e.tagName}#${e.dataset.testid ?? ""}#${e.id}#${(e.textContent ?? "").trim().slice(0, 20)}`;
  });

for (const dir of ["Tab", "Shift+Tab"] as const) {
  test(`4 · ${dir} al /login: l'intro no es salta, el focus s'hi queda i després recorre el login sense BODY`, async ({ browser }) => {
    const ctx = await newCtx(browser, true);
    await mockServer(ctx, false);
    const page = await ctx.newPage();
    await page.goto("/login");
    await expect(page.getByTestId("home-intro")).toBeVisible();
    await expect(page.getByTestId("home-intro-skip")).toHaveCount(0);
    // Durant l'intro: Tab/Esc no la salten i el focus no surt mai de l'intro.
    for (let i = 0; i < 4; i++) {
      await page.keyboard.press(dir);
      expect(await activeId(page)).toContain("home-intro");
    }
    await page.keyboard.press("Escape");
    await expect(page.getByTestId("home-intro")).toBeVisible();
    // En acabar, el focus és al primer control del login.
    await expect(page.getByTestId("launch-intro")).toHaveCount(0, { timeout: 15_000 });
    const first = await activeId(page);
    expect(first).not.toBe("BODY");
    expect(await page.evaluate(() => !!document.activeElement?.closest("[data-testid='login-page']"))).toBe(true);
    const seen: string[] = [first];
    for (let i = 0; i < 14; i++) {
      await page.keyboard.press(dir);
      seen.push(await activeId(page));
    }
    expect(seen.filter((s) => s === "BODY"), seen.join(" | ")).toEqual([]);
    for (let i = 1; i < seen.length; i++) expect(seen[i], seen.join(" | ")).not.toBe(seen[i - 1]);
    await ctx.close();
  });
}
