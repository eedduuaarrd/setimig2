import { expect, test } from "@playwright/test";
import { startAiGameFromLobby } from "./helpers/aiLobby";
import { passAgeGateToLobby } from "./helpers/ageGateLobby";
import { confirmBetIfShown, waitForHandSurface } from "./helpers/tableFlow";
import fs from "node:fs";
import path from "node:path";

function screenshotDir(): string {
  const candidates = [
    "/cursor/stores/self/media/pas6",
    path.join(process.cwd(), "media/pas6"),
  ];
  for (const dir of candidates) {
    try {
      fs.mkdirSync(dir, { recursive: true });
      return dir;
    } catch {
      /* try next */
    }
  }
  return candidates[1];
}

test.describe("PAS 6 mobile screenshots 390x844", () => {
  test.use({ viewport: { width: 390, height: 844 } });

  test("capture bank highlight, seat points, bank offer UI", async ({ page }) => {
    const OUT = screenshotDir();
    await passAgeGateToLobby(page, "Pas6Shot", { playerId: "pas6shotuser01", online: true });
    await startAiGameFromLobby(page, 3);
    await expect(page.getByRole("button", { name: "Sortir de la partida" })).toBeVisible({ timeout: 45_000 });
    await waitForHandSurface(page);

    await expect(page.locator("[data-seat-banker='true']").or(page.getByText("Sorteig de banca")).first()).toBeVisible({
      timeout: 60_000,
    });
    await page.screenshot({ path: path.join(OUT, "01-bank-and-table.png"), fullPage: true });

    await confirmBetIfShown(page);
    await expect(page.locator("[data-seat-banker='true']").first()).toBeVisible({ timeout: 30_000 });
    await expect(page.getByTestId("local-player-seat")).toBeVisible();
    await page.screenshot({ path: path.join(OUT, "02-points-at-seats.png"), fullPage: true });

    // The bank-offer dialog is not reachable in a single scripted hand. The shot keeps the
    // historical layout sample inside the real action dock.
    await page.evaluate(() => {
      const dock = document.querySelector(".glass-dock");
      if (!dock) return;
      const offer = document.createElement("div");
      offer.className = "mb-3 flex flex-col gap-2 rounded-xl border border-amber-400/30 bg-amber-950/30 p-3";
      offer.innerHTML = `
        <p class="text-center text-xs text-on-surface-variant">Has fet set i mig. Vols ser banca?</p>
        <div class="flex gap-2">
          <button type="button" class="min-h-[48px] flex-1 rounded-xl border border-white/15 py-3 text-xs font-semibold uppercase tracking-wider text-on-surface">No, gràcies</button>
          <button type="button" class="min-h-[48px] flex-[1.2] rounded-xl py-3 text-xs font-semibold uppercase tracking-wider btn-primary-solid">Ser banca</button>
        </div>`;
      dock.prepend(offer);
    });
    await page.screenshot({ path: path.join(OUT, "03-bank-choice-dialog.png"), fullPage: true });
  });
});
