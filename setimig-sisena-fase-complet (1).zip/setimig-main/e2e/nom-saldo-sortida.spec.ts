import { expect, test, type Page } from "@playwright/test";
import { seedE2eSession } from "./helpers/e2eSession";

const VIEWPORTS = [
  { width: 390, height: 844 },
  { width: 1280, height: 800 },
] as const;

async function boot(page: Page, playerId: string, localName: string) {
  await seedE2eSession(page, playerId);
  await page.addInitScript((name: string) => {
    localStorage.setItem("setimig_player_name", name);
    localStorage.setItem("setimig_onboarding_v1", "1");
    localStorage.setItem("setimig_interactive_tutorial_v1", "1");
    localStorage.setItem("setimig_table_tutorial_v1", "1");
    localStorage.setItem("setimig.locale", "ca");
    localStorage.setItem(
      "setimig_age_gate",
      JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
    );
  }, localName);
  await page.goto("/");
  await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 60_000 });
}

async function startSolo(page: Page) {
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  await page.getByTestId("ai-bot-count-1").click();
  await page.getByTestId("ai-bot-picker-start").click();
}

async function headerChips(page: Page): Promise<number> {
  const label = await page.getByTestId("header-balance-chip").getAttribute("aria-label");
  return Number((label ?? "").replace(/\D/g, ""));
}

for (const viewport of VIEWPORTS) {
  const balanceId = viewport.width === 390 ? "saldosort01" : "saldosort02";

  test(`perfil «Clara QA» a la taula i al rànquing (${viewport.width})`, async ({ page }) => {
    await page.setViewportSize(viewport);
    // El navegador duu un nom aleatori; el perfil del servidor és el que ha de guanyar.
    await boot(page, "nomclaraqa01", "Núria");
    await expect(page.getByRole("button", { name: /Clara QA/ })).toBeVisible({ timeout: 20_000 });
    await page.getByTestId("lobby-open-ranking").click();
    await expect(page.getByTestId("ranking-screen")).toBeVisible();
    await expect(page.getByTestId("ranking-row").filter({ hasText: "Clara QA" }).first()).toBeVisible({
      timeout: 15_000,
    });
    await expect(page.getByTestId("ranking-row").filter({ hasText: "Núria" })).toHaveCount(0);
    await page.getByTestId("ranking-back").click();
    await startSolo(page);
    await expect(page.getByTestId("local-player-seat")).toHaveAttribute("data-player-name", "Clara QA", {
      timeout: 30_000,
    });
    await page.getByRole("button", { name: "Sortir de la partida" }).click();
    await page.getByRole("button", { name: "Confirmar sortida de la partida" }).click();
    await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 20_000 });
  });

  test(`sortir a mitja mà no deixa el vestíbul 2.000 per sota (${viewport.width})`, async ({ page }) => {
    await page.setViewportSize(viewport);
    await boot(page, balanceId, "Sortida");
    await expect.poll(() => headerChips(page), { timeout: 20_000 }).toBe(10_000);
    await startSolo(page);
    const bet = page.getByTestId("bet-confirm");
    await bet.waitFor({ state: "visible", timeout: 30_000 });
    await bet.click();
    // A 390 les cartes pròpies no sempre posen data-local-hand; la mà ja és en joc quan
    // desapareix la pantalla d'aposta (l'aposta de 100 és al pot).
    await expect(bet).toBeHidden({ timeout: 30_000 });
    await page.getByRole("button", { name: "Sortir de la partida" }).click();
    await page.getByRole("button", { name: "Confirmar sortida de la partida" }).click();
    await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 20_000 });
    await expect.poll(() => headerChips(page), { timeout: 15_000 }).toBeGreaterThan(8_000);
    const after = await headerChips(page);
    await page.reload();
    await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 30_000 });
    await expect.poll(() => headerChips(page), { timeout: 15_000 }).toBe(after);
  });
}
