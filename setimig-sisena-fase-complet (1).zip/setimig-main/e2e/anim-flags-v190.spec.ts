import { expect, test, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eSession } from "./helpers/e2eSession.ts";

/**
 * v190 · animacions darrere de flag (NO FUSIONAR fins que l'Edu ho digui):
 * - `turnflip`: les cartes del rival volen del seient al centre (gir 3D) i tornen; acaben a la cara real.
 * - `actionpop`: HIT / STAND gran al centre amb rebot; la mà s'enfosqueix mentre surt.
 * Amb els flags apagats no apareix cap element nou. Partida solo amb 3 bots (sense llavor fixa).
 * Clips: V190_CLIPS=1 grava vídeo a /workspace/setimig/v190_anim_flags/.
 */
type Obs = {
  ghosts: { dir: string; face: string }[];
  outEnds: { faces: string[]; hidden: number; ghostFace: string }[];
  pops: { kind: string; word: string; color: string; sub: string; filter: string; anim: string }[];
  popGone: number;
  overflowX: number;
  layers: number;
  focusSeen: number;
  maxLife: number;
  visible: { kind: string; ms: number }[];
  cuts: number;
  replaceGapMs: number[];
  pe: string[];
  popAt: { id: string; kind: string; t: number }[];
  cardsChangedInHold: number;
};

async function startSolo(page: Page, flags: string, reduced = false) {
  if (reduced) await page.emulateMedia({ reducedMotion: "reduce" });
  await seedE2eSession(page, e2ePoolId());
  await page.addInitScript((f) => {
    if (sessionStorage.getItem("v190_init") !== "1") {
      sessionStorage.setItem("v190_init", "1");
      for (const k of ["setimig_onboarding_v1", "setimig_interactive_tutorial_v1", "setimig_table_tutorial_v1"]) localStorage.setItem(k, "1");
      localStorage.setItem("setimig.locale", "ca");
      localStorage.setItem("setimig_player_name", "Test Flags");
      localStorage.setItem("setimig_age_gate", JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" }));
      sessionStorage.setItem("setimig_intro_launch_v1", "1");
      localStorage.setItem("setimig.flags", f);
    }
    const o: Obs = { ghosts: [], outEnds: [], pops: [], popGone: 0, overflowX: 0, layers: 0, focusSeen: 0, maxLife: 0, visible: [], cuts: 0, replaceGapMs: [], pe: [], popAt: [], cardsChangedInHold: 0 };
    (window as unknown as { __v190: Obs }).__v190 = o;
    const check = () => {
      o.overflowX = Math.max(o.overflowX, document.documentElement.scrollWidth - innerWidth);
      if (document.querySelector('[data-testid="focus-stage"]')) o.focusSeen = o.focusSeen || Date.now();
      o.layers = Math.max(o.layers, document.querySelectorAll(".turn-flip-layer, .action-pop-layer, .turn-flip-ghost, .turn-flip-spark, [data-testid=action-pop]").length);
    };
    const mo = new MutationObserver((muts) => {
      check();
      for (const m of muts) {
        m.addedNodes.forEach((n) => {
          if (!(n instanceof HTMLElement)) return;
          if (n.classList.contains("turn-flip-ghost")) n.dataset.t0 = String(performance.now());
          if (n.classList.contains("turn-flip-ghost")) o.ghosts.push({ dir: n.dataset.dir ?? "", face: n.dataset.face ?? "" });
          const pop = n.matches("[data-testid=action-pop]") ? n : n.querySelector<HTMLElement>("[data-testid=action-pop]");
          if (pop) {
            pop.dataset.t0 = String(performance.now());
            if (!o.popAt.some((x) => x.id === pop.dataset.popId)) o.popAt.push({ id: pop.dataset.popId ?? "", kind: pop.dataset.kind ?? "", t: performance.now() });
            const fanCount = () => document.querySelectorAll('[data-testid="focus-stage"] .mobile-local-hand-card').length;
            pop.dataset.cards = String(fanCount());
            const lastGone = (window as unknown as { __popGoneAt?: number }).__popGoneAt;
            const goneId = (window as unknown as { __popGoneId?: string }).__popGoneId;
            if (lastGone != null && goneId !== pop.dataset.popId) {
              o.cuts += 1;
              o.replaceGapMs.push(performance.now() - lastGone);
            }
            (window as unknown as { __popGoneAt?: number }).__popGoneAt = undefined;
            const layer = pop.parentElement!;
            o.pe.push(getComputedStyle(layer).pointerEvents);
            const r = pop.getBoundingClientRect();
            const hitEl = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2);
            if (hitEl && layer.contains(hitEl)) o.pe.push("captures-taps");
            const w = pop.querySelector<HTMLElement>("[data-testid=action-pop-word]")!;
            setTimeout(() => {
              const hand = document.querySelector<HTMLElement>('[data-testid="focus-stage"] .focus-hero-panel');
              o.pops.push({
                kind: pop.dataset.kind ?? "",
                word: w.textContent ?? "",
                color: getComputedStyle(w).color,
                sub: pop.querySelector("[data-testid=action-pop-sub]")?.textContent ?? "",
                filter: hand ? getComputedStyle(hand).filter : "none",
                anim: getComputedStyle(pop).animationName,
              });
            }, 350);
          }
        });
        m.removedNodes.forEach((n) => {
          if (!(n instanceof HTMLElement)) return;
          if (n.classList.contains("turn-flip-ghost")) o.maxLife = Math.max(o.maxLife, performance.now() - Number(n.dataset.t0));
          if (n.classList.contains("turn-flip-ghost") && n.dataset.dir === "out") {
            const cards = [...document.querySelectorAll<HTMLElement>('[data-testid="focus-stage"] .mobile-local-hand-card')];
            if (cards.length) o.outEnds.push({
              faces: cards.map((c) => c.querySelector<HTMLElement>("[data-face]")?.dataset.face ?? ""),
              hidden: cards.filter((c) => c.style.opacity === "0").length,
              ghostFace: n.dataset.face ?? "",
            });
          }
          if (n.classList?.contains("action-pop-layer")) o.popGone += 1;
          const gone = n.matches?.("[data-testid=action-pop]") ? n : null;
          if (gone && !gone.classList.contains("action-pop--out")) {
            // Tret sense sortida: és un tall només si el substitueix un avís diferent (un remuntatge el continua).
            (window as unknown as { __popGoneAt?: number }).__popGoneAt = performance.now();
            (window as unknown as { __popGoneId?: string }).__popGoneId = gone.dataset.popId;
          }
        });
      }
    });
    const amo = new MutationObserver((muts) => {
      for (const m of muts) {
        const el = m.target as HTMLElement;
        if (el.dataset?.testid === "action-pop" && el.classList.contains("action-pop--out") && !el.dataset.done) {
          el.dataset.done = "1";
          o.visible.push({ kind: el.dataset.kind ?? "", ms: performance.now() - Number(el.dataset.t0) });
          const nowCards = document.querySelectorAll('[data-testid="focus-stage"] .mobile-local-hand-card').length;
          if (nowCards && Number(el.dataset.cards) && nowCards !== Number(el.dataset.cards)) o.cardsChangedInHold += 1;
        }
      }
    });
    const start = () => {
      mo.observe(document.body, { childList: true, subtree: true });
      amo.observe(document.body, { subtree: true, attributes: true, attributeFilter: ["class"] });
    };
    if (document.body) start();
    else document.addEventListener("DOMContentLoaded", start);
  }, flags);
  await page.goto("/");
  const skip = page.getByTestId("interactive-tutorial-skip");
  await expect(page.getByTestId("lobby-context").or(skip).first()).toBeVisible({ timeout: 45_000 });
  if (await skip.isVisible().catch(() => false)) await skip.click();
  await page.getByTestId("lobby-context").click();
  await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
  await page.getByTestId("ai-bot-count-3").click();
  await page.getByTestId("ai-bot-picker-start").click();
}

const obs = (page: Page) => page.evaluate(() => (window as unknown as { __v190: Obs }).__v190);

/** Juga (apostar, plantar-se, passar mà) fins que `done` és cert o s'acaba el temps. */
async function playUntil(page: Page, done: (o: Obs) => boolean, ms = 100_000) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    const o = await obs(page);
    if (done(o)) return o;
    const bet = page.getByTestId("bet-confirm").filter({ visible: true }).first();
    if (await bet.isVisible().catch(() => false)) await bet.click({ timeout: 2_000 }).catch(() => {});
    const st = page.getByTestId("action-stand").filter({ visible: true }).first();
    if (await st.isVisible().catch(() => false)) await st.click({ timeout: 2_000 }).catch(() => {});
    const next = page.getByTestId("settlement-next-hand").filter({ visible: true }).first();
    if (await next.isVisible().catch(() => false)) await next.click({ timeout: 2_000 }).catch(() => {});
    await page.waitForTimeout(250);
  }
  return obs(page);
}

const rgb = (hex: string) => `rgb(${parseInt(hex.slice(1, 3), 16)}, ${parseInt(hex.slice(3, 5), 16)}, ${parseInt(hex.slice(5, 7), 16)})`;

for (const vp of [{ width: 390, height: 844 }, { width: 390, height: 667 }]) {
  test.describe(`v190 flags ${vp.width}×${vp.height}`, () => {
    test.use({ viewport: vp });

    test("flags apagats: cap element nou", async ({ page }) => {
      await startSolo(page, "");
      const o = await playUntil(page, (x) => x.focusSeen > 0 && Date.now() - x.focusSeen > 8_000, 90_000);
      expect(o.focusSeen, "s'ha vist el torn d'un rival").toBeGreaterThan(0);
      expect(o.layers, "cap capa v190").toBe(0);
      expect(o.ghosts.length + o.pops.length).toBe(0);
      expect(await page.evaluate(() => document.documentElement.dataset.turnflip ?? document.documentElement.dataset.actionpop ?? null)).toBeNull();
    });

    test("turnflip: anada i tornada, cara real, sense desbordament", async ({ page }) => {
      await startSolo(page, "turnflip");
      const o = await playUntil(page, (x) => x.outEnds.length >= 2 && x.ghosts.some((g) => g.dir === "back"));
      expect(o.ghosts.some((g) => g.dir === "out"), "vol seient → centre").toBe(true);
      expect(o.ghosts.some((g) => g.dir === "back"), "vol centre → seient").toBe(true);
      for (const e of o.outEnds) {
        expect(e.faces, "la carta real queda a la seva cara").toContain(e.ghostFace);
        expect(e.hidden, "cap carta real amagada en acabar").toBe(0);
      }
      expect(o.overflowX, "sense desbordament horitzontal").toBeLessThanOrEqual(0);
      expect(o.maxLife, "cap fantasma penjat (vol ≤ 1 s + esglaonat)").toBeLessThan(1900);
    });

    test("actionpop: HIT i STAND amb color, text i mà enfosquida", async ({ page }) => {
      await startSolo(page, "actionpop");
      const o = await playUntil(page, (x) => x.pops.some((p) => p.kind === "hit") && x.pops.some((p) => p.kind === "stand") && x.popGone >= 2);
      const hit = o.pops.find((p) => p.kind === "hit")!;
      const stand = o.pops.find((p) => p.kind === "stand")!;
      expect(hit.word).toBe("HIT");
      expect(hit.color).toBe(rgb("#9fb5a0"));
      expect(hit.sub).toMatch(/demana carta|passat/i); // passar-se també és HIT (pausa del servidor)
      expect(stand.word).toBe("STAND");
      expect(stand.color).toBe(rgb("#c98f7a"));
      expect(stand.sub).toMatch(/planta/i);
      expect(o.pops.some((p) => /brightness/.test(p.filter) && /blur/.test(p.filter)), "mà enfosquida i desenfocada").toBe(true);
      expect(o.overflowX).toBeLessThanOrEqual(0);
      // Hold doble (v190 b): visible 1500 ms (HIT) / 2700 ms (STAND) abans de la sortida; entrada 700, sortida 250.
      for (const v of o.visible) {
        const want = v.kind === "hit" ? 1500 : 2700;
        expect(v.ms, `${v.kind} visible`).toBeGreaterThan(want - 150); // marge: si la capa es torna a muntar, l'avís continua (no es reinicia)
        expect(v.ms, `${v.kind} visible`).toBeLessThan(want + 400);
      }
      // No bloqueja: la capa no rep tocs i una acció nova el talla a l'instant.
      expect(o.pe.every((x) => x === "none"), `pointer-events: ${o.pe.join(",")}`).toBe(true);
      await expect(page.getByTestId("action-pop")).toHaveCount(0, { timeout: 5_000 });
    });
  });
}

test("moviment reduït: sense vol ni partícules; avís només amb fos i sense desenfocament", async ({ page }) => {
  await startSolo(page, "turnflip,actionpop", true);
  const o = await playUntil(page, (x) => x.pops.length >= 2, 100_000);
  expect(o.ghosts.length, "cap vol").toBe(0);
  expect(await page.locator(".turn-flip-spark").count()).toBe(0);
  expect(o.pops.length).toBeGreaterThan(0);
  for (const p of o.pops) {
    expect(p.anim, "sense rebot").not.toBe("action-pop-in");
    expect(p.filter).not.toMatch(/blur/);
  }
});

test("1280×720 amb els dos flags: res desborda", async ({ page }) => {
  await page.setViewportSize({ width: 1280, height: 720 });
  await startSolo(page, "turnflip,actionpop");
  const o = await playUntil(page, (x) => x.pops.length >= 1, 60_000);
  expect(o.overflowX).toBeLessThanOrEqual(0);
});

test.describe("clips 390 (V190_CLIPS=1)", () => {
  test.skip(!process.env.V190_CLIPS, "només per gravar");
  for (const [name, flag] of [["turn-flip", "turnflip"], ["hit-stand", "actionpop"]] as const) {
    test(`clip ${name}`, async ({ browser }) => {
      const ctx = await browser.newContext({
        viewport: { width: 390, height: 844 },
        deviceScaleFactor: 2,
        locale: "ca-ES",
        baseURL: test.info().project.use.baseURL,
        recordVideo: { dir: `/workspace/setimig/v190_anim_flags/raw-${name}`, size: { width: 390, height: 844 } },
      });
      const page = await ctx.newPage();
      await startSolo(page, flag);
      await playUntil(page, (x) => (flag === "turnflip" ? x.ghosts.filter((g) => g.dir === "back").length >= 3 : x.popGone >= 4), 90_000);
      await page.waitForTimeout(1500);
      await ctx.close();
    });
  }
});

test("actionpop pausa la partida: l'acció següent espera que acabi l'avís, i la cua va en ordre", async ({ page }) => {
  // Els bots del servidor actuen més de pressa que la pausa: el client ha de guardar les vistes i aplicar-les
  // en acabar l'avís (visible + 250 ms de sortida). Cap avís no es talla ni se salta.
  await startSolo(page, "actionpop");
  const o = await playUntil(page, (x) => x.popAt.length >= 4 && x.popGone >= 3, 100_000);
  expect(o.popAt.length).toBeGreaterThanOrEqual(2);
  expect(o.cuts, "cap avís tallat").toBe(0);
  for (let i = 1; i < o.popAt.length; i++) {
    const prev = o.popAt[i - 1];
    const need = (prev.kind === "hit" ? 1500 : 2700) + 250;
    if (o.popAt[i].t - prev.t < need - 60) test.info().annotations.push({ type: "v190", description: `curt ${i}: ${o.popAt.map((p) => p.kind + "#" + p.id + "@" + Math.round(p.t)).join(",")}` });
    expect(o.popAt[i].t - prev.t, `avís ${i} espera l'anterior (${prev.kind})`).toBeGreaterThanOrEqual(need - 60);
  }
  expect(o.cardsChangedInHold, "cap carta nova al centre durant l'avís").toBe(0);
  expect(o.pe.every((x) => x === "none"), "la capa no rep tocs").toBe(true);
  test.info().annotations.push({ type: "v190", description: `avisos ${o.popAt.map((p) => p.kind + "#" + p.id).join(",")}; intervals ${o.popAt.slice(1).map((p, i) => Math.round(p.t - o.popAt[i].t)).join("/")} ms` });
});
