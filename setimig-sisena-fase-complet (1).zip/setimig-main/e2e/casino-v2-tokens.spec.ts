import AxeBuilder from "@axe-core/playwright";
import { expect, test, type Locator, type Page } from "@playwright/test";
import { e2ePoolId, seedE2eLaunch } from "./helpers/e2eSession.ts";
import { safeHalfHandSnapshotJson } from "./helpers/f2ProbabilityFixtures.ts";

/**
 * Casino v2 · PR 1: tokens Midnight Gold, sense verds (excepte el tapet «Verd»),
 * axe 0, objectius tàctils de 44 px, text ≥ 12 px i sense scroll vertical a la taula.
 */
const VIEWPORTS = [
  { tag: "390x844", width: 390, height: 844 },
  { tag: "375x667", width: 375, height: 667 },
  { tag: "360x740", width: 360, height: 740 },
] as const;

const MIN_TARGET = 44;

async function baseStorage(page: Page, opts: { ageAccepted: boolean; snapshot?: string; playerId: string }) {
  await seedE2eLaunch(page, opts.playerId);
  return page.addInitScript(
    ({ ageAccepted, snapshot, playerId }) => {
      if (sessionStorage.getItem("setimig_e2e_seeded") === "1") return;
      sessionStorage.setItem("setimig_e2e_seeded", "1");
      localStorage.setItem("setimig_player_id", playerId);
      localStorage.setItem("setimig_player_name", "Casino");
      localStorage.setItem("setimig_onboarding_v1", "1");
      localStorage.setItem("setimig_interactive_tutorial_v1", "1");
      if (ageAccepted) {
        localStorage.setItem(
          "setimig_age_gate",
          JSON.stringify({ accepted: true, at: new Date().toISOString(), version: "1" })
        );
      }
      if (snapshot) {
        // Indicadors de probabilitat activats: la barra de risc «baix» ha de ser neutra, no verda.
        localStorage.setItem("setimig_probability_indicators", "1");
        localStorage.setItem("setimig_house_rules_enabled", "1");
        localStorage.setItem("setimig_local_solo_snapshot", snapshot);
        sessionStorage.setItem("setimig_solo_rejoin", "1");
        sessionStorage.setItem("setimig_solo_local", "1");
      }
    },
    { ageAccepted: opts.ageAccepted, snapshot: opts.snapshot ?? null, playerId: opts.playerId }
  );
}

async function axeViolations(page: Page) {
  const results = await new AxeBuilder({ page })
    .options({ rules: { "label-content-name-mismatch": { enabled: true } } })
    .analyze();
  return results.violations.map((v) => `${v.id}: ${v.nodes.map((n) => n.target.join(" ")).join(" | ")}`);
}

/** Elements visibles amb un color calculat verd (to 75–170°, saturat). El tapet «Verd» és l'excepció. */
async function computedGreens(page: Page) {
  return page.evaluate(() => {
    const parse = (value: string) =>
      [...value.matchAll(/rgba?\(([^)]+)\)/g)].map((m) => {
        const parts = m[1].split(/[\s,/]+/).filter(Boolean).map(Number);
        return { r: parts[0], g: parts[1], b: parts[2], a: parts.length > 3 ? parts[3] : 1 };
      });
    const isGreen = ({ r, g, b, a }: { r: number; g: number; b: number; a: number }) => {
      if (a < 0.05) return false;
      const max = Math.max(r, g, b);
      const min = Math.min(r, g, b);
      const d = max - min;
      if (max < 24 || d < 18) return false;
      const sat = d / max;
      if (sat < 0.2) return false;
      let hue = 0;
      if (max === r) hue = ((g - b) / d) % 6;
      else if (max === g) hue = (b - r) / d + 2;
      else hue = (r - g) / d + 4;
      hue = (hue * 60 + 360) % 360;
      return hue >= 75 && hue <= 170;
    };
    const out: string[] = [];
    for (const el of Array.from(document.querySelectorAll<HTMLElement>("body *"))) {
      if (el.closest(".game-table-felt") === el) continue;
      // Il·lustració de les cartes (pal de bastos): fora de l'abast d'aquest PR.
      if (el.closest("svg")) continue;
      const rect = el.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) continue;
      const cs = getComputedStyle(el);
      if (cs.visibility === "hidden" || cs.display === "none") continue;
      const hasText = Array.from(el.childNodes).some((n) => n.nodeType === 3 && n.textContent!.trim());
      const props: [string, string][] = [
        ["background-color", cs.backgroundColor],
        ["background-image", cs.backgroundImage],
        ["border-color", cs.borderTopWidth !== "0px" ? cs.borderTopColor : ""],
        ["color", hasText ? cs.color : ""],
        ["fill", el instanceof SVGElement ? cs.fill : ""],
        ["stroke", el instanceof SVGElement && cs.stroke !== "none" ? cs.stroke : ""],
      ];
      for (const [prop, value] of props) {
        if (value && parse(value).some(isGreen)) {
          const id = el.getAttribute("data-testid") ?? (el.className?.toString?.() ?? "").slice(0, 60);
          out.push(`${el.tagName.toLowerCase()}[${id}] ${prop}=${value.slice(0, 80)}`);
        }
      }
    }
    return out;
  });
}

/** Text visible amb mida < 12 px. */
async function smallText(page: Page) {
  return page.evaluate(() => {
    const out: string[] = [];
    for (const el of Array.from(document.querySelectorAll<HTMLElement>("body *"))) {
      const own = Array.from(el.childNodes).some((n) => n.nodeType === 3 && n.textContent!.trim());
      if (!own) continue;
      const rect = el.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) continue;
      if (el.closest(".sr-only, svg")) continue;
      const cs = getComputedStyle(el);
      if (cs.visibility === "hidden" || cs.display === "none" || Number(cs.opacity) === 0) continue;
      const size = Number.parseFloat(cs.fontSize);
      if (size < 11.95) out.push(`${el.tagName.toLowerCase()} ${size}px «${el.textContent!.trim().slice(0, 30)}»`);
    }
    return out;
  });
}

async function expectTarget(locator: Locator, label: string) {
  await expect(locator, label).toBeVisible({ timeout: 30_000 });
  const box = await locator.boundingBox();
  expect(box, label).not.toBeNull();
  expect(Math.round(box!.width), `${label} amplada`).toBeGreaterThanOrEqual(MIN_TARGET);
  expect(Math.round(box!.height), `${label} alçada`).toBeGreaterThanOrEqual(MIN_TARGET);
}

async function expectNoVerticalScroll(page: Page) {
  const m = await page.evaluate(() => ({
    scrollHeight: document.documentElement.scrollHeight,
    innerHeight: window.innerHeight,
    scrollWidth: document.documentElement.scrollWidth,
    innerWidth: window.innerWidth,
  }));
  expect(m.scrollWidth).toBeLessThanOrEqual(m.innerWidth + 1);
  expect(m.scrollHeight).toBeLessThanOrEqual(m.innerHeight + 1);
}

async function expectCleanScreen(page: Page, where: string) {
  // Lobby v4.1: el context també entra amb stagger; axe mesura el contrast amb les animacions acabades.
  await page.evaluate(() => Promise.all(document.getAnimations().filter((a) => a.effect?.getComputedTiming().iterations !== Infinity).map((a) => a.finished.catch(() => undefined))));
  expect(await axeViolations(page), `axe ${where}`).toEqual([]);
  expect(await computedGreens(page), `verds ${where}`).toEqual([]);
  expect(await smallText(page), `text < 12 px ${where}`).toEqual([]);
}

for (const vp of VIEWPORTS) {
  test.describe(`Casino v2 tokens ${vp.tag}`, () => {
    test.use({ viewport: { width: vp.width, height: vp.height } });

    test("porta d'edat: «No ho soc» ≥ 44 px i axe 0", async ({ page }) => {
      await baseStorage(page, { ageAccepted: false, playerId: e2ePoolId() });
      await page.goto("/");
      const notAdult = page.getByRole("button", { name: /No ho soc/ });
      await expectTarget(notAdult, "No ho soc");
      await page.waitForTimeout(700); // l'entrada animada del full ha d'acabar abans d'axe
      await expectCleanScreen(page, "porta d'edat");
    });

    test("lobby i selector de la IA: 44 px, sense verds, axe 0", async ({ page }) => {
      await baseStorage(page, { ageAccepted: true, playerId: e2ePoolId() });
      await page.goto("/");
      await expect(page.getByTestId("lobby-main")).toBeVisible({ timeout: 60_000 });
      // Lobby v4 (PR-L2): espera que acabi l'entrada (≤ 600 ms) abans de l'axe.
      await page.waitForFunction(() => document.getAnimations().every((a) => a.playState !== "running"));
      // Lobby v4 (PR-L1): «Com jugar» és un botó que obre el tutorial i els enllaços de guia surten del lobby.
      await expectTarget(page.getByTestId("lobby-open-tutorial"), "Com jugar");
      await expectTarget(page.getByTestId("play-with-friends-button"), "Amb amics");
      await expectCleanScreen(page, "lobby");
      // Tipografia autoallotjada: Cormorant Garamond (titulars) i DM Sans (text), woff2 del mateix origen.
      const fonts = await page.evaluate(async () => {
        await document.fonts.ready;
        await Promise.all([document.fonts.load('600 20px "Cormorant Garamond"'), document.fonts.load('400 15px "DM Sans"')]);
        return {
          serif: document.fonts.check('600 20px "Cormorant Garamond"'),
          sans: document.fonts.check('400 15px "DM Sans"'),
          woff2: performance
            .getEntriesByType("resource")
            .map((e) => e.name)
            .filter((n) => n.endsWith(".woff2"))
            .every((n) => n.startsWith(location.origin)),
        };
      });
      expect(fonts).toEqual({ serif: true, sans: true, woff2: true });

      await page.getByTestId("lobby-context").click();
      await expect(page.getByTestId("ai-bot-picker")).toBeVisible();
      await page.waitForTimeout(400);
      await expectTarget(page.locator("label", { has: page.getByTestId("ai-practice-mode") }), "Mode pràctica");
      await expectTarget(page.locator("label", { has: page.getByTestId("ai-fast-tournament") }), "Torneig ràpid");
      await expectCleanScreen(page, "selector IA");

      await page.getByTestId("ai-bot-count-2").click();
      await page.getByRole("button", { name: "Començar" }).click();
      await expect(page.getByTestId("ai-bot-picker")).toHaveCount(0);
      const minus = page.getByTestId("bet-minus");
      await expect(minus).toBeVisible({ timeout: 30_000 });
      await expectTarget(minus, "aposta −");
      await expectTarget(page.getByTestId("bet-plus"), "aposta +");
      await expect(page.locator("h1")).toHaveCount(1);
      await expectCleanScreen(page, "taula (apostes)");
      if (vp.tag !== "390x844") await expectNoVerticalScroll(page);
    });

    test("taula en joc: «Demanar carta», h1, sense scroll, axe 0", async ({ page }) => {
      const playerId = e2ePoolId();
      await baseStorage(page, {
        ageAccepted: true,
        playerId,
        snapshot: safeHalfHandSnapshotJson(playerId, "Casino"),
      });
      await page.route("**/socket.io/**", (route) => route.abort());
      await page.goto("/");
      const hit = page.getByTestId("action-hit");
      await expect(hit).toBeVisible({ timeout: 30_000 });
      const box = await hit.boundingBox();
      expect(box!.width).toBeGreaterThan(100);
      // Taula gran (v147): sense barra de risc.
      await expect(page.getByTestId("hit-bust-risk-bar")).toHaveCount(0);
      // Nom accessible = text visible (label-in-name).
      await expect(hit).toHaveAccessibleName(/Demanar carta/);
      await expect(page.locator("h1")).toHaveCount(1);
      await expectCleanScreen(page, "taula (joc)");
      await expectNoVerticalScroll(page);
    });
  });
}
