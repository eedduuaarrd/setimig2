import { defineConfig, devices } from "@playwright/test";
import { catalanStorageState } from "./e2e/catalanLocale";
import { e2eServerEnv } from "./e2e/helpers/e2eServerEnv";

export default defineConfig({
  testDir: "./e2e",
  testMatch: "game-chat-focus.spec.ts",
  timeout: 120_000,
  retries: 0,
  projects: [{ name: "desktop-chromium", use: { ...devices["Desktop Chrome"], browserName: "chromium" } }],
  use: {
    locale: "ca-ES",
    storageState: catalanStorageState(),
    baseURL: "http://127.0.0.1:3000",
    viewport: { width: 1280, height: 900 },
  },
  globalTeardown: "./e2e/helpers/e2eGlobalTeardown.ts",
  webServer: {
    command: "npm run dev",
    env: e2eServerEnv(),
    url: "http://127.0.0.1:3000",
    reuseExistingServer: false,
    timeout: 120_000,
  },
});
