import { defineConfig, devices } from "@playwright/test";
import { e2eServerEnv } from "./e2e/helpers/e2eServerEnv";
import { catalanStorageState } from "./e2e/catalanLocale";

const port = Number(process.env.SETIMIG_E2E_PORT ?? process.env.PORT ?? 3177);
const appUrl = process.env.APP_URL ?? `http://127.0.0.1:${port}`;

/** S1 (millores-nit): «Sortir» confirmat ⇒ el lobby no ofereix «Continuar la partida». */
export default defineConfig({
  testDir: "./e2e",
  testMatch: "s1-sortir-continuar.spec.ts",
  timeout: 150_000,
  retries: 0,
  use: {
    ...devices["iPhone 12"],
    browserName: "chromium",
    baseURL: appUrl,
    locale: "ca-ES",
    colorScheme: "dark",
    storageState: catalanStorageState(),
  },
  globalTeardown: "./e2e/helpers/e2eGlobalTeardown.ts",
  webServer: {
    command: `npm run build && cross-env NODE_ENV=production PORT=${port} APP_URL=${appUrl} PLAYER_TOKEN_SECRET=playwright-e2e-test-secret npm run start`,
    env: e2eServerEnv(),
    url: appUrl,
    reuseExistingServer: false,
    timeout: 120_000,
  },
});
