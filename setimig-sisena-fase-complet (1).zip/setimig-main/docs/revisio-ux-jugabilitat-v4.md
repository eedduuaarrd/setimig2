# Revisió UX i jugabilitat — V4 (25/10/2026)

Aquesta revisió parteix de les captures reals fetes en mòbil i del projecte complet. L'objectiu no ha estat canviar les regles del Set i Mig, sinó reduir fricció, fer la taula més llegible i donar una jerarquia més clara a cada decisió.

## Criteris utilitzats

- **Controls tàctils còmodes:** s'han mantingut les accions importants al voltant de 44–56 px d'alçada. Apple recomana 44×44 pt com a objectiu tàctil habitual a iPhone/iPad; web.dev recomana aproximadament 48×48 px i separació suficient entre controls.
- **UI contextual:** durant una mà es prioritza només la informació necessària per decidir ara. Els elements secundaris (historial, opcions, ajuda) queden disponibles però amb menys pes visual.
- **Zona del polze:** les accions decisives continuen al dock inferior; no s'han mogut a zones altes difícils d'arribar amb una mà.
- **Color amb significat:** el daurat passa a ser l'acció principal normal; el vermell queda reservat a risc alt, error o accions destructives.
- **Menys capes simultànies:** s'han eliminat blocs repetits a l'aposta i s'ha reduït el pes de la cronologia, del prompt de torn i de les capçaleres.
- **PWA/mòbil primer:** s'han conservat safe areas, `dvh`, feedback hàptic/sonor existent i preferència de moviment reduït.

## Canvis principals

### Lobby

- Nova jerarquia entre **Juga ara** i **Amb amics**.
- Targetes de mode més recognoscibles i menys semblants a formularis web.
- Accés a reprendre partida convertit en una acció clara i compacta.
- Enllaços de guia i partides recents visualment secundaris.
- Saldo visible també a mòbil sense convertir la capçalera en una barra pesada.

### Configuració de partida

- Modals d'IA i multijugador unificats visualment.
- Configuració d'IA separada en **Rivals** i **Nivell**, amb selecció més evident.
- Crear i entrar a una taula privada queden separats en dos blocs perceptius.
- Menys majúscules i tracking excessiu en botons d'acció.

### Aposta

- Eliminat el bloc mòbil redundant que repetia nom, saldo i aposta seleccionada al centre de la taula.
- Prompt **Et toca apostar** convertit en una píndola compacta amb compte enrere.
- Nou resum de límits + saldo en una sola capçalera.
- Nous botons d'**aposta ràpida** (mínim, 2×, 5× i màxim quan pertoqui), reutilitzant la lògica de presets ja existent.
- Control +/- i slider més compacte i més fàcil d'escanejar.
- Informació de saldo posterior i pagament condensada.
- Botó **Apostar** reforçat com a CTA principal; **Repetir** queda secundari.

### Torn de joc

- **Demanar carta** és daurat en risc normal, perquè és l'acció principal i no una acció destructiva.
- A partir d'un risc alt de passar-se, el botó canvia a vermell; així el color transmet risc real.
- **Plantar-se** manté un estil crema clar i estable.
- Estat disabled i feedback tàctil més coherents.
- Seient rival actiu més subtil: vora daurada, sense resplendors que competeixin amb les cartes.

### Taula

- Feltre més pla i menys sorollós.
- **Accions recents** deixa de ser una barra genèrica gran: ara mostra l'última acció en una línia compacta i l'historial queda desplegable.
- Si encara no hi ha cap acció en mòbil, no es reserva espai per a una cronologia buida.
- Centre de taula, rivals i prompts redueixen ombres i efectes per donar protagonisme a cartes, punts i decisions.

### Liquidació

- Full de resultat més alt quan cal, però amb jerarquia més compacta.
- Import guanyat/perdut continua sent el focus principal.
- Acció de continuar queda fixa al peu del full.
- Menys majúscules i menys sensació de modal administratiu.

### Perfil i pàgines

- Perfil més dens en mòbil: menys espai buit i estadístiques en una sola fila.
- Seccions de perfil unificades amb el llenguatge visual del joc.
- **Com jugar**, **Regles** i pàgines legals comparteixen una capçalera verda i panells més plans.
- La confirmació +18 passa de vermell a verd: confirmar l'edat és una acció positiva, no destructiva.

## Referents revisats

- Apple — *Design advanced games for Apple platforms* (44×44 pt per a controls tàctils):
  https://developer.apple.com/videos/play/wwdc2024/10085/
- Apple Human Interface Guidelines — Accessibilitat i controls tàctils:
  https://developer.apple.com/design/human-interface-guidelines/accessibility
- web.dev — *Accessible tap targets* (aprox. 48×48 px i espai entre objectius):
  https://web.dev/articles/accessible-tap-targets
- MichaelJ43/card-game — React + TypeScript + Vite, taula de cartes modular:
  https://github.com/MichaelJ43/card-game
- wsamuelw/slaps — joc de cartes web mòbil, PWA, `dvh`, hàptics i interacció tàctil:
  https://github.com/wsamuelw/slaps
- betacraft/250-500-card-game — joc de cartes web mobile-only/PWA amb fluxos d'aposta i multijugador:
  https://github.com/betacraft/250-500-card-game

## Validació feta en aquest entorn

- `git diff --check`: correcte.
- Validació sintàctica dels fitxers TS/TSX modificats amb el compilador TypeScript: correcte.
- Tests de lògica d'apostes/cobertura executats directament amb Node: 15/15 correctes en la passada focalitzada (`betPresets`, límits de taula i solvència de banca).
- També s'ha iniciat una passada més àmplia de tests purs; els tests executats fins al límit de temps no han mostrat errors.
- `npm ci` no ha pogut acabar dins del límit d'execució de l'entorn (la instal·lació completa de dependències queda pendent), de manera que aquí no s'ha pogut executar el build Vite ni la suite Playwright completa.

Abans de desplegar a producció, executar en un entorn amb les dependències disponibles:

```bash
npm ci
npm run check
npm test
npm run test:e2e:pas17
```
