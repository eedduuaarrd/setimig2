# Login obligatori

Sense un compte iniciat (correu, Google o passkey) no es pot jugar ni cridar l'API de joc.

## Contracte (App PWA)

### HTTP

- Totes les rutes `/api/*` **excepte** `/api/health`, `/api/auth/*` i el camí exacte `/api/handoff/exchange` exigeixen sessió.
- Sense sessió vàlida → **`401`** amb cos:
  ```json
  { "error": "auth_required" }
  ```
- Una `/api` desconeguda **sense** sessió també dóna `401 auth_required` (el middleware va abans del 404/405 de #247). Amb sessió vàlida, el 404 `{ "error": "NOT_FOUND" }` i el 405 `{ "error": "METHOD_NOT_ALLOWED" }` es mantenen.
- `POST /api/account/delete` ja exigia Bearer; ara també passa pel middleware global (mateix `auth_required` si falta sessió).
- `POST /api/player-session` **no crea** sessions anònimes ni comptes nous. Renova un token HMAC vàlid, o —si el client no el porta o el porta invàlid— la galeta `setimig_session` si és vàlida, no caducada i no revocada. Sense cap de les dues → `401 auth_required`. Un Bearer vàlid guanya sobre la galeta (no es barregen comptes); detall a `docs/auth-contracte.md`.

### Què compta com a sessió

- Capçalera **`Authorization: Bearer <playerToken>`** (preferida; és el que desa el client a `localStorage` com `setimig_player_token`).
- També s'accepta `playerToken` al cos o a la query (compatibilitat amb crides antigues).
- El token ha de ser un HMAC vàlid (`PLAYER_TOKEN_SECRET`) i el `playerId` ha de tenir un **compte verificat** (almenys un correu, Google o passkey a `data/identities.json`).
- Un token d'un perfil anònim / orfe **no** dóna accés.
- La galeta `setimig_session` no obre `/api/*` ni el socket. L'única excepció és `POST /api/player-session`, per recuperar la sessió (vegeu més avall). `sm_g_state` continua sent només el flux de Google.

### Socket.io

- El handshake es rebutja sense compte: el client rep **`connect_error`** amb `err.message === "auth_required"`.
- El client ha d'enviar el token al connectar, per exemple:
  ```ts
  io({ auth: { token: playerToken }, transports: ["websocket", "polling"] })
  ```
  Alternatives acceptades: `auth.playerToken`, `Authorization: Bearer …` a les capçaleres del handshake, o `query.playerToken`.

### Rutes i recursos que queden oberts

| Recurs | Motiu |
|--------|--------|
| `GET /api/health` | Monitoratge |
| `/api/auth/*` (providers, email/start, email/verify, Google, passkeys, me, exchange…) | Iniciar sessió |
| `/api/handoff/exchange` (camí exacte, no el prefix `/api/handoff/`) | Bescanvi del traspàs de domini: el domini nou encara no té sessió. El codi d'un sol ús (signatura, caducitat, consum, límit per IP i origen) és la prova |
| `/login`, `/login/correu`, `/login/google`, `/privacy`, `/terms` | SPA (HTML) |
| Estàtics de la SPA (`index.html`, `/assets/*`, manifest, service worker, icones) | Carregar l'app i redirigir a `/login` |

`/api/handoff/mint` segueix exigint sessió de compte. El handler també accepta un `playerId` sol (jugadors antics, sense token); deixar-lo passar sense sessió permetria emetre un codi de traspàs per a qualsevol `playerId` aliè. `/api/handoff/stats` tampoc és obert.

La resta de l'API (perfil, saldo, amics, estadístiques, campanya, taules via HTTP si n'hi ha, esdeveniments, etc.) i el socket exigeixen compte.

### Flux client esperat

1. Si no hi ha `setimig_player_token` o `/api/auth/me` / qualsevol `/api` protegida retorna `401 auth_required` → anar a `/login`.
2. Després d'un login amb èxit (`/api/auth/email/verify`, Google exchange, passkey…), desar `playerId` / `playerToken` com ara i connectar el socket amb `auth: { token }`.
3. Si el socket fa `connect_error` amb `auth_required`, netejar la sessió local i tornar a `/login`.

## Perfils sense compte (orfes)

Els perfils / saldos / historials sense identitat verificada **no** donen accés. Esborrat administratiu:

```bash
# Simulació (per defecte; només lectura)
npx tsx scripts/delete-orphan-profiles.ts --env-file ~/setimig/.env --data-dir ~/setimig/data

# Aplicar (servidor aturat): còpia sha256 a ~/setimig-backups/esborrat-perfils-sense-compte-<data>/
npx tsx scripts/delete-orphan-profiles.ts --apply --env-file ~/setimig/.env --data-dir ~/setimig/data
```

L'aplicació la fa la porta després del desplegament; no s'ha d'executar `--apply` en calent amb el servei en marxa.

## HTML estàtic de dist/ i galeta de sessió

- Sense sessió, qualsevol HTML estàtic de `dist/` (`*.html` o índex de directori: `/regles/`, `/regles/ca/`…) que no sigui públic respon **302 → `/login?next=<ruta>`** (`Cache-Control: no-store`). Públics: `/`, `/index.html` (shell SPA), `/offline.html`, `/privacy*`, `/terms*`, `/login*`, `/404*`. Assets, `sw.js`, manifest i icones continuen públics.
- La sessió per a aquests HTML és la capçalera `Authorization: Bearer` **o** la galeta **`setimig_session`** (mateix token HMAC, mateixa validació: signatura, caducitat i jugador amb compte).
- Galeta: `HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=<segons fins que caduca el token>` (1 any). La posa qualsevol resposta JSON d'`/api` amb un `playerToken` vàlid: login per correu, Google (`/api/auth/exchange`), passkey, renovació `POST /api/player-session`, traspàs de domini i refresc de token. Mai es registra el valor.
- Tancar sessió: `POST /api/auth/logout` → `Set-Cookie: setimig_session=; Max-Age=0`. També s'esborra a `POST /api/account/delete`.
- Revocació al logout: el servidor revoca el token del `Authorization: Bearer` i el de la galeta, i la **sessió** a què pertanyen (el token renovat i el d'abans de `POST /api/player-session`). No tanca els altres dispositius. `data/revoked-tokens.json` desa el sha256 del token, l'id de sessió revocat i el lligam hash→sessió (mai el token en clar) amb la caducitat; un fitxer antic de versió 1 es llegeix i, en desar, passa a versió 2 sense perdre `tokens`. Persisteix entre reinicis. Després del logout, qualsevol token d'aquesta sessió dona 401 a `/api/auth/me`, `/api/me` i la resta de `/api/*` (`auth_required` fora del prefix obert), `connect_error` `auth_required` al socket i 302 a `/login` a l'HTML estàtic; els sockets vius d'aquesta sessió es desconnecten.
- `/api/*` (tret de `POST /api/player-session`) i el socket **no** accepten la galeta. A la renovació per galeta, `SameSite=Lax` i el control d'origen eviten un POST creuat.
- Client: les crides `fetch` same-origin ja envien i reben galetes (`credentials: "same-origin"` per defecte). En tancar sessió el client ha de cridar `POST /api/auth/logout` a més d'esborrar localStorage.

## Registre per correu: confirmació d'edat i límit per correu

- `POST /api/auth/email/verify` per a un compte **nou** sense `ageConfirmed` respon `403 {"error":"…","code":"AGE_CONFIRMATION_REQUIRED"}` i **no gasta el codi** (ni l'enllaç). El client pot tornar a enviar el mateix codi amb `ageConfirmed: true` i el compte es crea amb un sol correu. Amb `ageConfirmed` el codi es consumeix com sempre. Codi erroni o caducat: igual que abans (400 `INVALID_CODE` / 410 `EXPIRED_OR_USED`), i els intents (5 per codi, 20 errors per IP) continuen comptant.
- `POST /api/auth/email/start` quan se supera `START_PER_EMAIL` (3 per correu i finestra de 15 min) respon `429 {"error":"Massa intents. Espera uns minuts.","code":"RATE_LIMIT","retryAfter":<segons>}` amb la capçalera `Retry-After: <segons>` (abans era un 202 que no enviava res). Els altres `RATE_LIMIT` (per IP) també porten ara `retryAfter` al cos.
