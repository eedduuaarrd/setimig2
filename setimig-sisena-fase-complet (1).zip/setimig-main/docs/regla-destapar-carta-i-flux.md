# Regla de joc: destapar cartes i repartir-ne de noves

## Comportament definit

1. La primera carta d'un jugador es reparteix tapada per als rivals, però el propietari de la mà la pot veure.
2. Durant el seu torn, el jugador pot triar **Destapar carta per als rivals**. És una acció informativa: no consumeix un torn, no roba cap carta, no canvia l'aposta i no altera el total de punts.
3. La carta destapada queda visible per a tothom i no es pot tornar a tapar.
4. Si el jugador prem **Carta**, la nova carta segueix la regla d'una sola tapada per mà: si encara hi ha alguna carta tapada a la mà, la nova es reparteix **destapada**; si totes les cartes de la mà ja estan destapades, la nova es reparteix **tapada** (i passa a ser l'única tapada). Això val tant si el jugador ha destapat la primera carta com si no. Les mans especials del 3 i del Mort mantenen les seves regles pròpies de secret (vegeu el punt 5).
5. Les cartes especials del 3 i del Mort, marcades com a secretes fins al final del torn de la banca, no es poden destapar abans. La interfície no ha d'oferir el botó mentre aquesta restricció sigui activa.
6. En acabar la banca, les cartes que restaven secretes es revelen en el procés de resolució de la mà.

## Per què és així

Destapar no és el mateix que demanar carta. Separar les dues accions evita que un toc accidental robi una carta o canviï el resultat. Fer la revelació irreversible també evita confusions sobre què han vist els rivals.

## Validacions manuals

- En una mà ordinària, destapar la primera carta la fa visible als rivals.
- Destapar i després demanar carta afegeix exactament una carta nova, tapada si era l'única tapada i ara totes les cartes visibles; destapada si encara queda alguna altra tapada.
- Demanar carta sense destapar abans afegeix una carta destapada (perquè la primera segueix tapada).
- El botó desapareix quan la carta ja és visible.
- En mans del 3 o del Mort, no apareix el botó de destapar abans que acabi la banca.
- El servidor rebutja intents de tornar a tapar una carta ja revelada.
