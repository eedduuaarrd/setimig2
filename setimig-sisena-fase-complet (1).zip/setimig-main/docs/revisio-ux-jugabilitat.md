# Revisió UX i jugabilitat — Setimig

## Canvis aplicats

- Capa visual final per donar més profunditat a la taula verda, un contorn daurat discret i millor separació visual sense canviar les regles de joc.
- Feedback tàctil coherent als botons: pressió subtil, hover només en dispositius amb ratolí i estat desactivat sense animació interactiva.
- Indicador de focus visible més consistent per a navegació amb teclat.
- Tractament coherent de camps, xifres i totals; els números tabulars eviten que els imports “ballin” quan canvien.
- Files horitzontals de rivals amb scroll més net, snap suau i sense barra de desplaçament invasiva.
- Ajustos conservadors per a mòbils molt estrets i respecte a les àrees segures d'iOS.
- Respecte a `prefers-reduced-motion` per a persones que prefereixen menys animació.

## Criteris de seguretat del canvi

Aquesta passada és deliberadament CSS-first: no canvia les regles, les apostes, el càlcul de puntuacions, l'ordre de torns ni el protocol Socket.IO. Els ajustos de dimensions només s'apliquen en pantalles estretes i mantenen les variables de disseny existents.

## Validació recomanada abans de desplegar

1. `npm ci`
2. `npm run check`
3. `npm test`
4. Proves Playwright incloses al projecte, especialment `pas15`, `pas16`, `pas17`, `pas12-mobile-table` i els tests d'accessibilitat.
5. Prova manual en iPhone petit, iPhone amb notch, Android estret, tauleta i escriptori: iniciar partida, demanar carta, plantar-se, apostar, acabar mà, reentrar i obrir diàlegs.

No es considera una auditoria visual completa de producció fins que aquestes proves s'executin contra els navegadors i dades reals del desplegament.
