# Estadístiques del perfil

El perfil mostra mans jugades, percentatge de victòries, mitjana de punts i passades (`passCount`). Només entren les mans amb fitxes reals. Les de pràctica i de torneig ràpid es desen a l'historial amb `practice: true` i no mouen aquests totals.

Cada **slot amb aposta** és una mà. Un split són dues mans. Una mà doblada és una sola mà (l'aposta és el doble, el recompte no).

## Passada

La mà supera 7½. També ho és la parella cega del 3 que, en destapar-se, passa de 7½.

No ho és:

- el Mort que no fa 7½ (perd l'aposta, però no és una passada);
- la banca que es passa («banca passada»): això és una victòria de qui s'havia plantat.

Abans el recompte mirava si el text de la liquidació contenia «banca passada». Una passada clara («Passat») quedava a 0, i una victòria contra la banca passada podia comptar com a passada.

## Plantada automàtica

Quan s'acaba el temps de jugar (22 s), la mà es planta amb els punts que té. No és una passada. Entra a la mitjana amb aquests punts i al percentatge de victòries segons si cobra o no.

## Victòria contra la banca

La mà cobra: guanya pel marcador, o cobra perquè la banca s'ha passat, o fa un 7½ natural que paga. Un empat no és una victòria (la banca guanya els empats). El percentatge és victòries / mans comptades.

Si el jugador fa de banca, una victòria és acabar la mà amb més fitxes que a l'inici. Si la seva mà passa de 7½, és una passada.

## 7½ natural

7½ exacte amb dues cartes de sortida, sense passar-se i sense haver separat. Si guanya la mà, és una victòria (paga 2:1). Si la banca també fa 7½, el natural es recorda però no compta com a victòria. Després de separar, un 7½ amb dues cartes (sota + 7) és un 7½ normal: no es recorda com a natural i paga 1×.

## Mitjana

Mitjana aritmètica dels punts de cada mà comptada, mitges incloses (6,5 es queda en 6,5). Les passades entren amb el total real (per exemple 9). El fitxer guarda la suma en dècimes al camp opcional `pointsSumTenths`; `pointsSum` continua sent la suma arrodonida cap avall, com abans.

## Sessió

El comptador «Sessió: N mans» és la memòria de la sala (`updateSessionStatsFromRound`), no el perfil. També puja a pràctica, torneig ràpid i sales amb fitxes aïllades. No escriu el saldo real: `persistHumanBalances` se salta aquestes sales.

Abans, `updateSessionStatsFromRound` tornava de seguida quan `roomUsesIsolatedPlayChips` era cert i la sala no era de pràctica (el torneig ràpid). El comptador es quedava a 0.
