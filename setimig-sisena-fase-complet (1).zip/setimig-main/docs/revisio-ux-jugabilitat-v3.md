# Revisió UX i jugabilitat — V3

## Canvis d'aquesta versió

- El component del torn actiu ara funciona com un focus visual: avatar, nom del jugador molt més gran, indicació «Juga ara»/«Torn de la banca» i acció actual.
- Els seients dels jugadors publiquen un estat `data-seat-active` per destacar el jugador actiu amb una vora, resplendor i elevació subtil.
- El control per fer pública una carta tapada ara diu «Destapar carta per als rivals», amb jerarquia visual més clara i estat tàctil/focus visible.
- Les cartes pròpies animen l'entrada i el canvi d'estat amb una rotació 3D curta; es respecta `prefers-reduced-motion`.
- S'han afegit acabats de moviment i contrast per a pantalles petites i avisos urgents de torn.

## Semàntica de les cartes tapades

La carta privada del jugador continua mostrant-se de cara al seu propietari. L'estat `faceUp` determina si la carta també és visible per als rivals. El control «Destapar carta per als rivals» crida l'acció de joc existent `flip_card`; no s'ha creat una regla de joc nova ni s'ha canviat el motor de puntuació.

## Validació

- L'arxiu ZIP resultant s'ha de validar amb `unzip -t`.
- La instal·lació de dependències (`npm ci`) ha excedit el temps disponible en aquest entorn; per això no s'ha pogut executar `npm run check` ni els tests automatitzats.
- Abans de publicar, executar `npm ci`, `npm run check` i provar una mà completa en mòbil i ordinador, inclòs destapar la carta i confirmar que els rivals la veuen.
