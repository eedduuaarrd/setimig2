# Correu del codi d'accés

El client envia `locale` (o `lang`) a `POST /api/auth/email/start`. L'assumpte i el cos (HTML i text pla) surten en aquest idioma. Si no és vàlid, es fa servir `Accept-Language` i, si tampoc, l'anglès. El codi de 6 xifres va a l'assumpte.

L'HTML fa servir els colors del login: fons `#0b0b0b`, paper `#f5f2eb`, or `#d4af6a`, i les famílies Cormorant Garamond i DM Sans. No hi ha imatges remotes ni enllaços `<a>`: l'adreça de la pantalla de login va escrita en text, perquè Brevo no la pugui reescriure.

## Seguiment de Brevo

Si hi ha `BREVO_API_KEY`, el codi surt per `POST https://api.brevo.com/v3/smtp/email`. La crida porta:

- `to[].contactPixelTrackingConsent: false`
- capçaleres `X-Mailin-Track`, `X-Mailin-Track-Clicks` i `X-Mailin-Track-Opens` a `0`

Això **no apaga el seguiment a tots els comptes**. El camp de consentiment només s'aplica si el compte té activat el consentiment de píxel per contacte; si no, l'API l'ignora. Amb el valor `false`, la documentació de Brevo diu que les obertures i els clics s'anonimitzen (es compten en agregat), no que el píxel deixi d'injectar-se. Les mateixes capçaleres, al relé SMTP `smtp-relay.brevo.com`, no van aturar el píxel ni la reescriptura d'enllaços (prova del 27/10/2026).

Per treure el píxel i el seguiment de clics de veritat cal el tauler de Brevo: Transactional → Settings → Tracking, amb el seguiment d'obertures i de clics desactivat. L'API transaccional actual no ofereix un camp que ho garanteixi per a un sol correu.

Sense `BREVO_API_KEY`, el codi surt pel canal `MAIL_PROVIDER` (Cloudflare o SMTP). En SMTP s'hi posen les mateixes capçaleres; a Cloudflare l'API no les admet i no s'hi envien.
