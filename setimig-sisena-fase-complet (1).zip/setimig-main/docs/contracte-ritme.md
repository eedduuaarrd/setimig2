# Contracte de ritme (servidor → client)

El servidor és qui marca el pas. El client no ha d'endevinar les pauses: les llegeix de cada `room_update` i de `joined_room`. Els noms de sota són exactament els camps del JSON.

## Camps de la vista

| Camp | Tipus | Quan |
| --- | --- | --- |
| `serverNow` | number | Epoch en ms del servidor en el moment d'enviar la vista. Ja hi era; el compte enrere s'hi ancora. |
| `phaseEndsAt` | number o null | Epoch en què acaba el pas actual. Durant un avís HIT/STAND és el mateix instant que `actionHoldEndsAt`. |
| `actionHoldEndsAt` | number o null | Epoch en què acaba l'avís de carta o de plantar-se. `null` si no hi ha pausa. |
| `pacing` | objecte | Durades nominals (ms). No es col·lapsen amb `SETIMIG_TEST_FAST`; els terminis sí. |

`phaseEndsAt` segons la fase, quan no hi ha avís:

- `betting` amb apostes tancades: fi de `BETS_SETTLE_MS` (les cartes encara no hi són). Aquesta vista s'emet en acceptar l'última aposta, abans de repartir.
- `betting` oberta: el mateix instant que `bettingDeadlineAt` / `turnDeadlineAt`.
- `playing` / `banker`: el termini del torn humà (`turnDeadlineAt`), que no comença fins que acaba l'avís anterior.
- `settlement`: fi de la revelació més el pagament.
- `bank_draw`: fi del sorteig de banca.
- `waiting`: `null`.

## Tancament d'apostes

El client llegeix el `phaseEndsAt` del final de les apostes només a les vistes amb `phase: "betting"`. Si l'última aposta arribés ja en una vista `playing`, es quedaria el `phaseEndsAt` de l'última vista `betting` i les fitxes no tindrien temps d'arribar al centre.

Per això, en acceptar l'última aposta —humana, d'un bot o perquè el termini s'ha esgotat— el servidor emet una vista amb:

- `phase` = `"betting"`
- `phaseEndsAt` = instant d'aquella aposta + `BETS_SETTLE_MS`
- `players[].betting` segueix el contracte del #340 (`SeatBettingView`): `{ "status": "placed", "amount": <fitxes> }` als seients que han apostat, i `null` a la banca i als exempts. En aquesta vista no queda ningú `pending`.
- cap carta repartida

La vista de repartiment (`phase: "playing"`, amb cartes) no s'emet fins que passa `BETS_SETTLE_MS`. Fora de la fase `betting`, `players[].betting` és `null`. Qui encara ha d'apostar, mentre la finestra és oberta, és `{ "status": "pending" }` sense `amount`.

## Objecte `pacing`

| Camp | Valor | Quan s'aplica |
| --- | --- | --- |
| `BOT_BET_GAP_MS` | 700 | Entre apostes de bots, una per una. Cada aposta surt en el seu `room_update`. |
| `BETS_SETTLE_MS` | 1800 | Després de l'última aposta i abans de repartir. El client en necessita 1300 (700 de vol + 600 del pot). |
| `DEAL_CARD_MS` | 350 | Cada carta del repartiment inicial, en seqüència. El primer torn espera cartes × 350. |
| `ACTION_HIT_HOLD_MS` | 1750 | Després de cada hit (bots, humans i banca, solitari i multijugador), també si la mà es passa. Inclou la sortida de l'avís. |
| `ACTION_STAND_HOLD_MS` | 2950 | Després de cada stand, els mateixos seients. Inclou la sortida de l'avís. |
| `REVEAL_PER_SEAT_MS` | 1500 | Revelació en gran de cada seient amb cartes (#339). |
| `SETTLEMENT_VISIBLE_MS` | 3000 | El full, un cop acabada la revelació. |
| `MORT_REVEAL_SUSPENSE_MS` | 5200 | Suspens del Mort; substitueix el primer seient. |
| `BANK_OFFER_FLOOR_MS` | 6400 | Si un humà decideix l'oferta de banca i la revelació és més curta, la revelació s'allarga fins aquí. El pagament s'hi suma igual. |
| `PAYOUT_BANK_MS` | 400 | Inici del viatge de fitxes del pagament. |
| `PAYOUT_PER_SEAT_MS` | 900 | Per cada seient amb resultat, sense la banca. |
| `PAYOUT_COUNTER_MS` | 800 | El comptador «+N». |
| `BET_WINDOW_MS` | 18000 | Finestra d'aposta humana. No canvia. |
| `PLAY_WINDOW_MS` | 22000 | Finestra de torn humana. No canvia. El rellotge del torn següent arrenca quan acaba l'avís. |
| `BOT_ACTION_MIN_MS` | 1200 | Pensada mínima d'un bot en el seu torn (no entre apostes). |
| `BOT_ACTION_MAX_MS` | 1500 | Pensada màxima. |
| `BOT_FIRST_ACTION_MS` | 1200 | Primera acció d'un bot en un torn nou, després de l'avís i del repartiment. |
| `BANKER_DRAW_MS` | 1300 | Entre cartes de la banca bot. |
| `BANK_DRAW_MS` | 1800 | Sorteig de qui fa de banca. No el col·lapsa el mode ràpid. |
| `BANK_CHOICE_TIMEOUT_MS` | 6000 | Temps per acceptar o rebutjar la banca. |
| `BANKER_TIMEOUT_MS` | 20000 | Torn de la banca humana. |
| `NEXT_HAND_START_MS` | 600 | Entre el final de la liquidació i l'obertura de la mà següent. No el col·lapsa el mode ràpid. |
| `SETTLEMENT_MIN_DISPLAY_MS` | 1500 | Mínim si tothom ha confirmat «Següent». |
| `DEAL_FLIGHT_MS` | 300 | Vol d'una carta demanada dins el torn. |
| `DEAL_FLIGHT_FLIP_MS` | 360 | Vol + gir dins el torn. |
| `DEAL_BUST_MS` | 600 | Passar-se dins el torn (l'avís de HIT és a part, 1750). |
| `BANK_REVEAL_MS` | 240 | La banca destapa l'oculta. |
| `SOLO_START_DELAY_MS` | 500 | Abans de la primera mà en reprendre un solo. No el col·lapsa el mode ràpid. |

## Fórmules

Revelació (#339), sense canvis:

- Sense Mort: `n × REVEAL_PER_SEAT_MS + SETTLEMENT_VISIBLE_MS` (n = seients amb almenys una carta, banca inclosa; un split compta un seient).
- Amb Mort: `MORT_REVEAL_SUSPENSE_MS + (n − 1) × REVEAL_PER_SEAT_MS + SETTLEMENT_VISIBLE_MS`.

Pagament, després de la revelació i abans de la mà següent:

`PAYOUT_BANK_MS + PAYOUT_PER_SEAT_MS × seients amb resultat (sense la banca) + PAYOUT_COUNTER_MS`

- 1 seient → 2100
- 3 seients → 3900
- 4 seients → 4800

La liquidació sencera és revelació (o el màxim amb `BANK_OFFER_FLOOR_MS` si un humà té l'oferta de banca) més el pagament. `phaseEndsAt` de `settlement` és aquest instant.

## Avís HIT/STAND

La carta d'un hit es veu de seguida. Després el servidor s'atura `ACTION_HIT_HOLD_MS` (també si es passa). Un stand s'atura `ACTION_STAND_HOLD_MS`. Durant la pausa no hi ha carta següent, ni acció de bot, ni canvi de torn. El termini del jugador següent comença quan `actionHoldEndsAt` queda enrere.

Si l'humà que té el torn envia una altra acció durant la pausa, el servidor no la rebutja: l'encua i l'aplica en acabar l'avís (i, si cal, obre l'avís de l'acció nova).

## Ack de hit i stand

L'aposta acceptada es confirma amb l'event `game_action_ack`. Hit i stand fan servir el mateix event, al mateix moment i als mateixos canals de socket (sala privada i solo amb socket). L'HTTP del solo no l'emet: la resposta segueix sent la vista o l'error, com a l'aposta.

S'envia amb les mateixes condicions que l'aposta: l'acció s'ha acceptat (sense `game_error`) i la petició porta un id vàlid. Just després de desar-la. Això inclou tres casos:

- s'aplica a l'instant
- queda a la cua de l'avís (`actionHoldEndsAt`, contracte del #343): l'ack surt en rebre-la i encuar-la, no quan s'aplica en acabar la pausa
- la mà ja s'ha tancat i el motor l'ignora sense error (no s'encua): tampoc hi ha `game_error`, i l'ack surt igual

L'id és `actionId` si és vàlid. Si no n'hi ha i sí un `requestId` vàlid, aquest valor és l'`actionId` de l'ack. Un reintent amb el mateix id no torna a aplicar ni a encuar l'acció i rep el mateix ack. Sense id no hi ha ack, igual que l'aposta, i l'acció s'aplica igualment.

`amount` només és a l'aposta (fitxes acceptades). La resta de camps són els mateixos.

```json
{ "action": "place_bet", "actionId": "<id>", "roomId": "<sala>", "amount": 100 }
{ "action": "hit", "actionId": "<id>", "roomId": "<sala>" }
{ "action": "stand", "actionId": "<id>", "roomId": "<sala>" }
```

Si l'acció es rebutja, no hi ha ack. Se segueix enviant `game_error`, amb `actionId` si la petició en portava.

## Mode ràpid i entorn

`SETIMIG_TEST_FAST=1` posa a 0 les pauses d'aposta, de repartiment, de pagament (dins el retard de liquidació) i dels avisos HIT/STAND. L'objecte `pacing` continua mostrant els valors nominals.

Es poden sobreescriure, amb un enter entre 0 i 120000, aquestes variables: `SETIMIG_BOT_BET_GAP_MS`, `SETIMIG_BETS_SETTLE_MS`, `SETIMIG_DEAL_CARD_MS`, `SETIMIG_ACTION_HIT_HOLD_MS`, `SETIMIG_ACTION_STAND_HOLD_MS`, `SETIMIG_REVEAL_PER_SEAT_MS`, `SETIMIG_SETTLEMENT_VISIBLE_MS`, `SETIMIG_MORT_REVEAL_SUSPENSE_MS`, `SETIMIG_PAYOUT_BANK_MS`, `SETIMIG_PAYOUT_PER_SEAT_MS`, `SETIMIG_PAYOUT_COUNTER_MS`. Un valor invàlid s'ignora. El mode ràpid guanya a la variable: els temporitzadors segueixen a 0.
