# Modes de joc (PAS 11+)

No hi ha **taula pública** ni botó «Multijugador».

| Mode | On corre | Connexió |
|------|----------|----------|
| Juga amb la IA | Client (local) | Opcional després de la primera visita (PWA) |
| Taula amb amics | Servidor (Socket.IO) | Cal xarxa |

Al lobby, si tens una partida oberta (IA servidor legacy o taula privada), apareix **Tornar a la partida** — mai un botó desactivat «Partida en curs» per una sala pública inexistent.
