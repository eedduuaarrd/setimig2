# Set i Mig · Edició Clàssica V6

**25 d'octubre de 2026 · Redisseny visual, sense canviar les regles.**

## Objectiu

Convertir la interfície del Set i Mig en un espai de joc elegant i formal, amb calma visual i prioritat absoluta a les cartes i a les decisions del jugador.

## Canvis

1. **Identitat:** verd carbó `#111C19`, verd taula `#20382D`, marfil `#EAE8E0`, accent xampany `#CABC9E`, sense daurats brillants ni degradats.
2. **Tipografia:** titulars i xifres distintives amb una serif clàssica; controls amb DM Sans. Iconografia amb línies fines i sense elements infantils.
3. **Lobby:** capçalera editorial, monograma 7½, dues modalitats principals ordenades, accés discret a regles i guia bàsica desplegable; disposició a dues columnes en escriptori.
4. **Taula:** feltre homogeni, butonera discreta, menor ús d'ombres, vores fines i contrast suficient; estats de risc mantenen diferenciació semàntica.
5. **Cartes:** dors tradicional de línies fines i monograma, sense trames ornamentals repetides.
6. **Resultats:** el 7½ es comunica amb una insígnia breu, sense pluja de fitxes. El resum manté els valors positius i negatius diferenciats.
7. **Diàlegs i perfil:** superfícies planes, selectors sobris, jerarquia tipogràfica clara, menys formes circulars.
8. **PWA:** icones coherents amb la nova identitat i increment de versió de memòria cau `v38`; nova imatge per compartir en xarxes.

## Fitxers principals

- `src/elegant.css` — estil V6, carregat últim per `src/main.tsx`.
- `src/App.tsx` — lobby, capçalera, navegació i configuració d'IA.
- `src/components/AgeGateOverlay.tsx` — accés per a majors d'edat.
- `src/components/SpanishCard.tsx` — dors de carta.
- `src/components/CurrentTurnPrompt.tsx` i `src/components/SevenHalfCelebration.tsx` — estat de torn i avís de 7½.
- `src/components/FreeChipsClaim.tsx`, `src/components/TableToolsMenu.tsx`, `src/components/SettlementSheet.tsx`, `src/GameView.tsx` — to visual dels controls.
- `public/` i `index.html` — iconografia, colors del navegador, càrrega inicial i metadades.

## Preservació funcional

No s'han modificat el motor de cartes, les apostes, la lògica de banc, les sales, els pagaments, les credencials ni la persistència. Es mantenen els identificadors `data-testid` dels fluxos principals.

## Verificació i límits

S'ha comprovat la sintaxi TypeScript/TSX i l'estructura CSS i dels recursos. En aquest entorn no ha estat possible completar `npm ci` i la compilació real amb Vite; **no es pot considerar una build verificada**. Abans del desplegament cal executar `npm run check`, `npm test` i les proves de navegació en un entorn amb dependències. Vegeu `DESPLEGAMENT-SUPERCBB.md`.
