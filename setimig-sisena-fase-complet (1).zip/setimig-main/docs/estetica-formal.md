# Guia d'estètica formal: partida (Edició Clàssica V6)

**Base:** `main` 12e564b.

**Objectiu:** durant la partida, menys elements, menys color i menys moviment. La informació es llegeix d'un cop d'ull: qui juga, què tinc, què m'hi jugo.

**Fonts:**
- el codi: `src/index.css`, `src/elegant.css`, `src/GameView.tsx`, `src/components/TableStatusPill.tsx` i `src/pacing.ts`;
- els informes de claredat mòbil 4–6.

## 1. Paleta «Midnight Gold»
Substitueix tots els tokens de color de la taula de `src/elegant.css:7-36` (avui `#111C19`, `#CABC9E`…). També els verds i daurats antics que queden a `index.css:10-16` (`#083C1D`, `#F9C95A`…) i a `GameView.tsx:1838` (`#E0A526`).

```css
:root {
  --sm-night:      #111827; /* fons de pantalla, capçalera, vora del tapet */
  --sm-graphite:   #1F2937; /* superfícies: panells, dock, modal, centre del tapet */
  --sm-graphite-2: #374151; /* només vores i separadors d'1 px; superfície activa */
  --sm-gold:       #C8A96B; /* ÚNIC accent: torn actiu, botó primari, focus */
  --sm-paper:      #F5F2EB; /* text principal i cara de les cartes */
  --sm-paper-70:   rgb(245 242 235 / .70); /* text secundari (≈ #B1B1B0 sobre night) */
  --sm-white:      #FFFFFF; /* realços puntuals: xifra del resultat, focus sobre or */
  --sm-ink:        #111827; /* text sobre paper (cartes) i sobre or (botó primari) */
  --sm-loss:       #F87171; /* PROPOSTA: estat «perds / passat» sobre fons foscos */
  --sm-loss-ink:   #B42318; /* PROPOSTA: el mateix estat si mai cal sobre paper */
}
```

**Rols:**
- **night:** fons.
- **graphite:** tot el que és superfície.
- **gold:** l'única crida d'atenció, com a màxim 2 vegades per pantalla.
- **paper:** text i cartes.
- **white:** només la xifra gran del resultat i l'anell de focus.
- **Sense degradats**, excepte el del tapet. Sense brillantors ni ombres de color. Com a ombra, només `0 1px 2px rgb(0 0 0 / .35)` a les cartes.

**Tapet de la taula:**

```css
.game-table-felt {
  background: radial-gradient(120% 85% at 50% 42%, #1F2937 0%, #182030 55%, #111827 100%);
  border: 1px solid #374151;          /* vora fina, sense «fusta» ni brillantor */
  box-shadow: inset 0 0 0 1px rgb(200 169 107 / .10); /* filet d'or al 10 % */
}
.spanish-card { background: #F5F2EB; color: #111827; border: 1px solid rgb(17 24 39 / .12); border-radius: 4px; }
```

El dors de les cartes va en `#1F2937` amb un filet `#C8A96B` d'1 px i un monograma també en `#C8A96B`.

**Vermell de «perds / passat»:**
- **Decisió:** cal un color d'estat. Només el color (com ara un «−200» en grafit) no es distingeix prou d'un «+200». A més, el `#A11D11` antic, sobre `#111827`, fa 2,28:1, i no arriba ni a 3:1.
- **Proposta:**
  - `--sm-loss: #F87171`, només per a text i icones d'estat sobre night o graphite, sempre amb signe «−» o la paraula «Passat»;
  - `--sm-loss-ink: #B42318`, només si cal mostrar-lo sobre paper;
  - els guanys no porten verd: es mostren en `--sm-white` amb «+».

**Contrastos** (WCAG 2.x, `(L1 + 0,05) / (L2 + 0,05)`, calculats amb un script):

| Text / primer pla | Fons | Ràtio | Text normal (4,5) | Text gran (3) |
|---|---|---|---|---|
| `#F5F2EB` paper | `#111827` night | 15,87:1 | AA | AA |
| `#F5F2EB` paper | `#1F2937` graphite | 13,13:1 | AA | AA |
| `#F5F2EB` al 70 % | `#111827` | 8,27:1 | AA | AA |
| `#F5F2EB` al 70 % | `#1F2937` | 7,22:1 | AA | AA |
| `#FFFFFF` white | `#111827` | 17,74:1 | AA | AA |
| `#FFFFFF` white | `#1F2937` | 14,68:1 | AA | AA |
| `#C8A96B` gold | `#111827` | 7,89:1 | AA | AA |
| `#C8A96B` gold | `#1F2937` | 6,53:1 | AA | AA |
| `#111827` ink (botó primari) | `#C8A96B` | 7,89:1 | AA | AA |
| `#111827` ink (cartes) | `#F5F2EB` | 15,87:1 | AA | AA |
| `#F87171` loss (proposta) | `#111827` | 6,41:1 | AA | AA |
| `#F87171` loss (proposta) | `#1F2937` | 5,31:1 | AA | AA |
| `#B42318` loss-ink (proposta) | `#F5F2EB` | 5,88:1 | AA | AA |
| `#C8A96B` gold | `#F5F2EB` | 2,01:1 | **NO** | **NO** → **prohibit** (res d'or sobre paper ni sobre les cartes) |

## 2. Tipografia
- **Serif clàssica** (`--classic-serif`, ja definida a `elegant.css:80`): només per a xifres grans (punts, resultat) i el títol del modal.
- **DM Sans** 400/600 (`index.css:2-3`): tota la resta. No cal cap font nova.

| Token | Mida / interlineat | Ús |
|---|---|---|
| `--fs-display` | 40/44, serif 600 | Resultat del modal («+200») |
| `--fs-score` | 28/32, serif 600 | Punts de la teva mà |
| `--fs-title` | 17/22, 600 | Missatge del torn, títols |
| `--fs-body` | 15/20, 400 | Text normal, botons |
| `--fs-meta` | 13/16, 400 | Saldos, noms dels rivals, pot |
| `--fs-min` | 12/16, 600 | **Mínim absolut.** Prohibit < 12 px. Avui n'hi ha a 10–11 px a `PlayerSeat.tsx:140` i `GameView.tsx:1753, 1838` |

Les majúscules amb `tracking` només es fan servir als botons (`letter-spacing: .04em`). Fora d'aquí, res d'`uppercase tracking-[0.2em]`.

## 3. Espais
`--sp-1: 4px; --sp-2: 8px; --sp-3: 12px; --sp-4: 16px; --sp-6: 24px; --sp-8: 32px`.
- Separació entre blocs de la taula: `clamp(8px, 1.6dvh, 16px)`.
- Marge lateral: 16 px.
- Àrea tàctil mínima: 44 px. Botó primari: 52 px.
- Radis: 8 px a botons i panells, 12 px al modal, 4 px a les cartes. Res de `rounded-full` excepte el comptador.

## 4. Badges i pastilles que cal treure o fusionar
| Element | On | Acció |
|---|---|---|
| Badge «🏛 BANCA» de la mà pròpia | `GameView.tsx:1837-1840` | **Treure l'emoji.** Fusionar amb el nom: «Banca · Tu», a 13 px, sense fons |
| Badge «BANCA» al seient (fons groc, 11 px) | `PlayerSeat.tsx:139-144` | Substituir per una línia «Banca» de 12 px en `--sm-paper-70` sota el nom. L'accent es reserva per al torn |
| Etiqueta «Banca» de la mà activa | `GameView.tsx:1071` | Treure: ja ho diu la línia del seient |
| Píndola de torn i comptador | `TableStatusPill.tsx:114, 139` | **Fusionar** amb `CurrentTurnPrompt` (`GameView.tsx:1648, 1731`) en **una sola línia d'estat** a dalt: «Et toca · 16 s» / «Juga Laia» / «Juga la banca» |
| Píndoles duplicades de la taula | `GameView.tsx:1455` i `1581` | Deixar-ne una (la de dalt) |
| «Pot» en majúscules 11 px | `GameView.tsx:1753` | Fer-lo «Pot 400», a 13 px, sense `uppercase` |
| Cercle «PUNTS» | `GameView.tsx:1978` | Treure el cercle i el text «Punts». Només la xifra a `--fs-score`, al costat de la mà |
| «Risc 31 %» | `GameView.tsx:2381` | Mantenir-lo, però a 12 px en `--sm-paper-70`, sota CARTA, sense fons |
| «Passat» en vermell clar | `GameView.tsx:155` | Fer servir `--sm-loss` (proposta) sobre graphite, amb la paraula «Passat». Un sol to |
| Resultat inline + pastilla de compartir | `GameView.tsx:1778, 1842, 1870` | **Treure.** La liquidació només surt al modal (§6) |
| Celebració de 7½ (banner + monedes) | `GameView.tsx:1602`, `index.css:895-906` | Treure les monedes. Una insígnia «Set i mig» dins el modal |
| Barra de progrés i «Mà 3/10» | `GameView.tsx:1453` | Deixar només el text «Mà 3/10» a 13 px a la capçalera |

## 5. Jerarquia de la pantalla de joc
Per a 360×740 i 375×667, sense scroll. Alçades d'1 a 6 a 375×667 (dvh útil ≈ 667):

| # | Bloc | Alçada | Contingut |
|---|---|---|---|
| 0 | Capçalera | 44 px | Sortir · «Mà 3/10» · menú |
| 1 | Línia d'estat | 32 px | «Et toca · 16 s». Accent només si et toca |
| 2 | **Rivals** | `clamp(72px, 12dvh, 96px)` | Fila horitzontal: nom 13 px, saldo 12 px, cartes de 40 px, aposta «200» en text. Màxim 4 visibles; la resta, amb scroll horitzontal dins la fila |
| 3 | **Banca** | `clamp(88px, 14dvh, 112px)` | Centrada: «Banca · Pau», cartes de 56 px i punts visibles |
| 4 | **Pot** | 24 px | «Pot 400», a 13 px. Res més (el mínim només surt al dock d'aposta) |
| 5 | **La teva mà** | `clamp(150px, 26dvh, 200px)` | Cartes de `clamp(84px, 13dvh, 112px)` d'alt, ventall de −40 px, punts a 28 px a la dreta, la teva aposta i el saldo en una línia de 13 px |
| 6 | **Botons** | 52 px + 16 px + `safe-area` | **Torn:** Plantar-se \| Carta (50/50), amb el risc a sota en 12 px. **Aposta:** 4 xips de 44 px, i Apostar N (2/3) \| Repetir (1/3) a la mateixa fila (≤ 160 px en total) |

**Criteri:**
- A 360×740 i a 375×667, `scrollHeight ≤ innerHeight`.
- Els botons del bloc 6 tenen `bottom ≤ innerHeight − env(safe-area-inset-bottom)`.
- No queda cap text < 12 px.

El dock deixa de tenir el `max-height: 118px` fix (`index.css:184` `--mobile-dock-reserve`) i passa a una alçada pròpia per fase.

## 6. Un únic modal de liquidació
Substitueix el resultat inline (`GameView.tsx:1842`), el bàner de 7½ i el panell d'escriptori (`GameView.tsx:1536`). Es manté només `SettlementSheet` (`GameView.tsx:1669`).

1. **Resultat net**, a `--fs-display`: «+200» (`--sm-white`) o «−200» (`--sm-loss`, proposta), i a sota «fitxes», a 13 px.
2. **Motiu**, a 15 px: «Tu 7 · Banca 6», «Banca passada (8)», «Set i mig natural · paga 2:1».
3. **Llista**, a 13 px, files de 32 px: tu, la banca i després la resta; màxim 4, i després «+N».
4. **Saldo nou:** «Tens 2.200».
5. **Botó** «Següent mà», de 52 px, amb el compte enrere en text de 12 px a sota: «Automàtic en 4 s».

Fons `--sm-graphite`, vora d'1 px `--sm-graphite-2`, text `--sm-paper`, radi de 12 px, `max-height: min(60dvh, 30rem)` i sense scroll intern a 375×667.

## 7. Animacions
Valors base a `pacing.ts`. Totes passen per `clientAnimationMs()` (`pacing.ts:91-95`), que ja retorna 0 amb `prefers-reduced-motion`.

| Moment | Durada | Easing | Detall | Reduced motion |
|---|---|---|---|---|
| Repartir una carta | 280 ms, amb 120 ms entre cartes | `cubic-bezier(0.2, 0.8, 0.2, 1)` | `translate` des del munt més un `rotateY(180→0)` en arribar (patró FLIP, vegeu les Referències). Substitueix `index.css:437` (300 ms) | Apareix amb un `opacity` de 0 a 1 en 120 ms, sense moviment |
| Girar la carta tapada | 240 ms | `cubic-bezier(0.4, 0, 0.2, 1)` | `rotateY` sobre l'eix vertical, `backface-visibility: hidden` | Canvi instantani de cara |
| Carta de la banca bot | 1.300 ms entre cartes (`BANKER_DRAW_MS`, `pacing.ts:53`), més 700 ms de pausa de tensió (`pacing.ts:56`) | igual que repartir | Mateixa animació de repartir | Sense animació. Les pauses **es mantenen**: són ritme, no moviment |
| Bots | **1.200–1.500 ms** (`pacing.ts:33-35`), sense canvis | — | — | Igual |
| Guanyar | 360 ms | `cubic-bezier(0.16, 1, 0.3, 1)` | El modal puja 16 px amb `opacity` de 0 a 1, i la xifra fa un *count-up* de 400 ms. Sense monedes ni confeti | `opacity` en 120 ms. La xifra surt directament |
| Perdre o passar-se | 240 ms | `cubic-bezier(0.4, 0, 1, 1)` | Les cartes baixen a `opacity .5` i es veu «−200». Substitueix el tremolor `index.css:952-953` (3 × 240 ms) | `opacity .5` instantània |
| Torn actiu | 200 ms | `ease-out` | Vora de 2 px `--sm-gold` al seient. **Sense pulsació** (treure `index.css:981, 1011, 1452`) | Vora sense transició |

Res no dura més de 400 ms, excepte el ritme dels bots i de la banca. Sense bucles infinits mentre s'espera.

## 8. Referències
He verificat la llicència de cada repo amb l'API de GitHub (`/license`). Només n'aprofitem idees o codi amb atribució; cap marca ni gràfic.

| Repo | Llicència | Què aprofitar |
|---|---|---|
| [baterson/blackjack-svelte-5](https://github.com/baterson/blackjack-svelte-5) | MIT (`LICENSE.txt`) | `src/lib/animation.ts`: `flyAndFlip`, repartiment FLIP (translate des del munt i `rotateY` 180→0, `cubicOut`). Es pot portar a React o CSS amb atribució. Disseny minimalista d'una mà |
| [stopnoanime/21-online](https://github.com/stopnoanime/21-online) | MIT | `placePlayersAtTable.ts`: rota els seients perquè el jugador local quedi sempre al centre (coincideix amb la nostra regla). Layout de taula amb Tailwind |
| [mhluska/blackjack-simulator](https://github.com/mhluska/blackjack-simulator) | MIT | Separació entre motor i UI, i taula sòbria d'una sola fila de controls. Idees de *feedback* textual curt per a cada decisió |
| [deck-of-cards/deck-of-cards](https://github.com/deck-of-cards/deck-of-cards) | **Codi MIT** (Juha Lindstedt); els **gràfics són LGPL-3.0** | Només les idees de l'animació (barrejar, repartir en ventall i *easing* de cada carta). **No n'aprofitem els gràfics** |

He buscat «siete y media» a GitHub i no he trobat cap repo amb llicència MIT, Apache o BSD i una UI aprofitable. El més complet (`Webierta/siete_media`) és GPL-3.0, i no l'hem fet servir.
