# Amagar comptes del rànquing

Es poden treure comptes concrets del rànquing de fitxes sense esborrar-los i sense
tocar-ne el saldo.

## Fitxer

`data/ranking-hidden.json`, al mateix directori que `balances.json` (si el servidor
fa servir `BALANCE_DATA_DIR`, el fitxer és allà). Format:

```json
{ "playerIds": ["id-del-compte", "un-altre-id"] }
```

Només es llegeix. El servidor no el crea ni el reescriu. El compte, el perfil i
`balances.json` queden com estaven.

## Què fa

- Cada id de `playerIds` desapareix del top i no compta per a les posicions dels altres.
- Si aquest jugador consulta el rànquing, la seva posició és null (`me.rank: null`,
  `me.inTop: false`). El nom i les fitxes de la resposta segueixen sent els del perfil
  i del saldo; no se li inventa una posició.
- Si el fitxer no existeix, no es pot llegir o el JSON no és vàlid (no és un objecte,
  o `playerIds` no és una llista), no s'amaga ningú i la petició respon com sempre.
- Dins d'una llista vàlida, les entrades que no són text s'ignoren; la resta s'amaga.

Per tornar a mostrar un compte, es treu l'id del fitxer. No cal reiniciar: cada
petició el torna a llegir.
