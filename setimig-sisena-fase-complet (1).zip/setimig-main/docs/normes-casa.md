# Normes de la casa: contracte servidor ↔ App PWA

Font: paraules de l'Edu (28/10/2026, amb les respostes als dubtes A-D). Tot només s'aplica amb
`houseRulesEnabled: true` (vista: `room.houseRulesEnabled`). El mode Tradicional no canvia.

## Regles que aplica el motor (`shared/gameEngine.ts`)

| # | Regla | Comportament |
|---|---|---|
| 1 | El 4 és opcional | Primer 4 → oferta «Jugar» o «Canviar». Canviar: el 4 va al descart i arriba 1 carta tapada que el propietari veu (els altres no). La carta nova es tracta com una primera carta. Si és un altre 4, es torna a oferir el canvi (termini nou), tantes vegades com surti un 4. Si és un 7, s'ofereix el Mort (`DECIDE_MORT_FIRST`). Si és un 3, s'aplica la regla del 3 (`DECIDE_SWAP_FIRST`). Amb una figura es pot doblar; amb dues figures o dues cartes del mateix valor, separar. Sense cartes al munt, la cadena s'acaba i es queda el 4. Si el termini venç sense decisió, es queda el 4. |
| 2 | El 3 és opcional | Primer 3 → «Jugar normal» (es queda el 3, flux normal) o «Canviar per 2 tapades». Amb el canvi, les 2 cartes no les veu ningú (ni el propietari) fins a la liquidació. El servidor el planta a l'instant i el torn s'acaba (següent jugador o banca). Després, demanar, plantar-se, doblar o separar es rebutgen. |
| 3 | 3 canviat paga el doble | Si guanya: +2× aposta (aposta 10 → +20). Si perd: −aposta (−10). Si en destapar-se passa de 7½, perd. |
| 4 | Doblar no planta | Doblar només amb la primera carta, abans de demanar-ne cap altra. Dobla l'aposta i dona 1 carta. Si no s'ha passat, el torn continua: demanar, plantar-te o separar. Una mà que ve d'un separar no es pot doblar (`canDouble` false). |
| 5 | Split | Dues cartes del mateix valor. Les figures compten juntes (Sota, Cavall i Rei valen totes mig punt i es poden separar entre elles). Es pot separar després d'haver doblat, i es pot tornar a separar una mà que ve d'un separar, sense límit de mans. |
| 6 | Mans del split | En separar, cada mà surt neta (`doubled` false, `canDouble` false), rep automàticament la segona carta i es juga sencera: cap mà no es queda amb una sola carta. L'aposta de cada mà és `splitHandBet` (l'aposta de la mà en separar; si s'havia doblat, l'aposta doblada; dubte D, un sol punt per canviar-la). Es liquida pel seu compte. |
| C | Doblar | No es pot doblar amb el Mort ni amb el 3 canviat. |
| B | Mort vs banca a 7½ | Guanya la banca. El Mort que guanya cobra el doble; si perd, l'aposta normal. |

## Noves accions

### Jugar o canviar el 3 / el 4

- **Quan s'ofereix:** al torn del jugador, si la carta amb què comença la mà (la inicial, o la que
  arriba en canviar un 4) és un 3 o un 4. La vista del
  propietari (i només la seva) porta:
  - `pendingChoices.swapOffer: 3 | 4`
  - `pendingChoices.offerCardId`: id de la carta de l'oferta (el 3, el 4 o el 7). El Mort només si aquesta carta és un 7.
  - `pendingChoices.swapDeadline?: number` (ms epoch del servidor; en esgotar-se, el servidor tria
    «Jugar»). No hi és en mode pràctica (sense temporitzador).
  - `room.mortDeadline` i `swapDeadline` / `mortDeadline` de `pendingChoices` **només** a la vista
    del propietari. Els rivals reben `mortDeadline: null` i sense `pendingChoices` (si no, sabrien
    que la carta és un 7, un 3 o un 4).
- Mentre hi ha oferta, «Carta», «Plantar-se», «Doblar» i «Separar» retornen
  `game_error { message: "Primer decideix si jugues o canvies la carta." }` (codi i18n
  `engine.decideSwapFirst`).
- **Socket (online):** `socket.emit("swap_action", { roomId, swap, playerToken?, actionSeq? })`
  - `swap: false` = «Jugar» (es queda la carta), `swap: true` = «Canviar».
  - `swap` ha de ser booleà; si no, `game_error { message: "Acció no vàlida.", code: "BAD" }`.
  - Si no hi ha oferta: `game_error { message: "Canvi no disponible.", code: "BAD" }`
    (`engine.swapUnavailable`).
  - `actionSeq` és opcional. En taules privades, si no arriba (o no és un enter ≥ 1),
    `normalizePrivateActionMeta` hi posa la següent seqüència. Mateixa autorització que la resta
    d'accions de torn (`playerToken`/`actionSeq`).
- **Canviar el 3 acaba el torn.** `swap: true` amb `pendingChoices.swapOffer === 3` deixa la mà
  `stood`, `lastAction` `"Canvia"`, i passa al següent jugador o a la banca. Val per a sockets
  multijugador, solo, pràctica i bots (tots passen per `applySwap`). Un `hit`, `stand`,
  `double_bet` o `split_hands` posterior es rebutja amb error. Un `double_bet` rebutjat
  envia `game_error` amb un codi de motiu estable i, si el client l'ha enviat, `actionId`
  (vegeu docs/codis-motor.md).
- **Cadena de 4.** `swap: true` amb `swapOffer === 4` tracta la carta nova com una primera carta,
  amb un termini de seguretat nou (el torn sencer; en pràctica, sense termini). Un altre 4 torna
  a posar `pendingChoices.swapOffer: 4`. Un 7 ofereix el Mort (`canMort`, `DECIDE_MORT_FIRST`).
  Un 3 ofereix la regla del 3 (`swapOffer: 3`, `DECIDE_SWAP_FIRST`). Una figura es pot doblar;
  si després hi ha dues figures o dues cartes del mateix valor, es pot separar. Es pot repetir
  mentre surtin 4 i quedi munt. Si `room.deck` és buit, el canvi no es fa i es queden el 4
  (no es remena el descart per seguir). Mateix camí a sockets, solo, pràctica i bots. Els bots
  continuen canviant sempre el 4 i juguen normal el 3; si el canvi no avança, es planten.
- **Solo local:** `session.swap(swap: boolean)` (`src/lib/localSoloSession.ts`).
- Les cartes noves es registren al `dealLog` amb `kind: "swap"` (nou valor de `DealKind`).
- L'última acció del jugador (`lastAction`) passa a ser `"Canvia"`.

### Peek: quan comença el termini de l'oferta

Fins que el propietari mira la carta, el termini és el **torn sencer** (animació + `turnMs`),
ancorat a l'inici de l'oferta. No escurça ni s'allarga en tornar a publicar.

- **Socket:** `socket.emit("card_peeked", { roomId, cardId, playerToken?, actionSeq? })`
  - `cardId`: la carta de l'oferta (el 7 del Mort, o el 3 / 4 del canvi).
  - Només val si qui l'envia és el propietari i és el seu torn. Si no, no fa res.
  - El primer peek vàlid posa el termini de l'oferta a `turnMs` des d'aquell moment.
  - Un altre `card_peeked` de la mateixa `cardId` s'ignora: el termini no es mou.
  - `playerToken` / `actionSeq` són opcionals, com a la resta d'accions de torn en taules privades.
- **Solo local:** `session.peekCard(cardId)` (`src/lib/localSoloSession.ts`), el mateix motor.
- **Pràctica:** no hi ha termini. El peek es recorda igual (un duplicat no fa res).
- **Temps esgotat** (el de seguretat o el del peek): Mort → jugar normal (`accept: false`);
  4 → quedar-se'l; 3 → com ara (quedar-se'l i seguir el torn).

### El Mort

- **Quan s'ofereix:** al torn del jugador, si la seva primera carta és un 7 (també el 7 que arriba
  en canviar un 4). La vista del propietari porta `pendingChoices.canMort: true` i, si n'hi ha,
  `pendingChoices.mortDeadline`.
- **Socket (online):** `socket.emit("mort_action", { roomId, accept, playerToken?, actionSeq? })`
  - `accept: true` = agafa el Mort (una carta tapada, es planta i el torn s'acaba).
  - `accept: false` = el rebutja i segueix el torn (pot doblar, demanar, plantar-se).
  - `actionSeq` és opcional, amb el mateix farciment que `swap_action`
    (`normalizePrivateActionMeta` en taules privades).
  - Sense oferta: `game_error { message: "Mort no disponible.", code: "BAD" }`
    (`engine.mortUnavailable`).
- **Solo local:** `session.mort(accept: boolean)`.
- El termini, si venç, tria «No» (`accept: false`).

## Indicador de mà especial (revelació)

- Camp nou a cada mà de la vista: `HandSlotView.special: "mort" | "threeSwap" | null`.
  - `"mort"`: el jugador ha acceptat el Mort.
  - `"threeSwap"`: el jugador ha canviat el 3 per 2 tapades.
  - `null`: mà normal (el 4 canviat també és una mà normal).
- Visible per a **tots** els espectadors des que es tria (el 7 del Mort i el 3 descartat ja són
  públics). Les cartes continuen amagades (`card: null`) per a tothom fins a la liquidació
  (`phase === "settlement"`): és el moment de la revelació.
- Els camps antics `mort` / `blindPair` es mantenen.

## Codis de liquidació (vegeu `docs/codis-motor.md`)

- Nou highlight `specialWin`: mà especial que guanya i cobra el doble.
  `params`: comuns + `special` (`"mort"|"threeSwap"`), `amount` (net d'aquella mà: el premi,
  sense tornar a sumar l'aposta; el jackpot hi entra si n'hi ha), `jackpot`, `bankScore`,
  `bankBusted`, `multiplier: 2`.
  Text de reserva: `Mort ×2 — +{amount}` / `3 canviat ×2 — +{amount}` (sense unitat; vegeu docs/codis-motor.md)
  (`parseGameMessage` → `engine.result.specialWin`, i el text de reserva torna `params.special`:
  `"mort"` o `"threeSwap"`).
- Tots els highlights d'una mà especial (també els que perden: `bust`, `mortLoses`, `bankWins`,
  `tieSevenHalfBank`, `tieBank`) porten `params.special`.
- Exemple (aposta 10, 3 canviat guanya): `chipDelta: 20`, highlight
  `{ code: "specialWin", params: { …, special: "threeSwap", amount: 20, multiplier: 2 } }`.
  El 20 és el net (el premi), i coincideix amb el `chipDelta` d'una sola mà.

## Compatibilitat

- `HandSlot.swapOffered` i `swappedFour` són opcionals: estats desats abans no els porten i es
  comporten com «sense oferta». Cap format de fitxer de dades no canvia.
- Clients antics: ignoren `special`, `swapOffer` i `specialWin` (tenen el text de reserva). Però
  sense el botó «Jugar/Canviar» el jugador amb un primer 3 o 4 queda bloquejat fins que venç el
  termini (online) — en solo local/pràctica no hi ha termini: cal la UI nova.

## Decisions on la llista i la font no deien el mateix

- Bots: canvien sempre el 4 (també el 4 que surt d'un canvi) i juguen normal el 3. La cadena
  s'atura quan el munt s'acaba o la carta nova no és un 4; si el canvi no avança, es planten.
- 4 canviat: la carta nova és una mà inicial. Un 7 ofereix el Mort. Un 3 ofereix la regla del 3.
  Un altre 4 es torna a poder canviar. Una figura es pot doblar; dues figures o dues del mateix
  valor es poden separar.
- Doblar només amb la primera carta, abans de demanar-ne cap altra. Després de separar, `canDouble`
  queda false a les dues mans (no es pot doblar una mà separada). Si la cadena ja havia doblat,
  el rebuig és `SPLIT_ALREADY_DOUBLED`; si no, `SPLIT_CANNOT_DOUBLE`. L'aposta de cada mà és la
  de `splitHandBet` (la doblada, si s'havia doblat). El separar no té límit de mans: `maxHands`
  ja no s'emet.
