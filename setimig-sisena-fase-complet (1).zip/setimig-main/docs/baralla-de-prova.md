# Baralla de prova (només tests)

La barreja de la partida és criptogràfica (`crypto.getRandomValues`). Perquè Qualitat pugui
repetir una mà, es pot fixar la llavor **només** en un servidor de prova.

## Com s'activa

Calen les dues condicions:

1. Variable d'entorn `SETIMIG_TEST_DECK_SEED` (nombre enter). Si no hi és, es mira
   `SETIMIG_TEST_SHUFFLE_SEED` (el mateix mecanisme d'abans). Si hi ha les dues, mana
   `SETIMIG_TEST_DECK_SEED`.
2. El procés **no** és producció (`NODE_ENV` diferent de `production`) **i** el servidor
   escolta en loopback (`127.0.0.1`, `localhost` o `::1`; és el valor per defecte de
   `SETIMIG_HOST` / `HOST`).

Si `NODE_ENV=production` i la variable hi és, **s'ignora** i el servidor registra un avís
(`[baralla] … ignorades`). El mateix si el procés no és producció però escolta en una
adreça que no és loopback (p. ex. `0.0.0.0`): la llavor no s'aplica.

No cal cap canvi al client. La llavor entra a `fisherYatesShuffle` (`shared/shuffle.ts`),
que és l'única barreja del munt (`createDeck` a `shared/gameEngine.ts`).

## Taula per reproduir els escenaris

Solo, **Normes de la casa**, **1 rival**. A la primera mà el bot és la banca i l'humà és
l'únic qui no banca: la primera carta del munt (l'última després de barrejar, `deck.pop()`)
és la carta inicial de l'humà; la següent és la de la banca; la tercera és la que surt si
l'humà demana o dobla.

Amb 3 rivals (el valor per defecte del vestíbul) els bots reben carta abans i les
seqüències d'aquí **no** valen.

| Escenari | `SETIMIG_TEST_DECK_SEED` | Carta inicial de l'humà | Següent (banca) | Carta de demanar / doblar |
|---|---|---|---|---|
| Separar, i separar després de doblar | `3` | cavall de bastos (11, mig punt) | 2 de copes | sota d'oros (10, mig punt) |
| Re-separar (S, R i una altra R) | `702` | sota d'oros (10) | 5 de bastos | rei d'oros (12). La carta següent, la que surt en demanar a la primera mà ja separada, és el rei de copes (12) |
| El Mort | `4` | 7 d'espases | 3 d'oros | cavall de copes |
| El Mort (falla / et passes) | `206` | 7 de bastos | 6 d'espases | 5 d'espases (7+5=12) |
| Canvi del 3 | `13` | 3 de bastos | 5 d'oros | 3 de copes (només si es demana; el canvi del 3 reparteix **dues** cartes) |
| Canvi del 4 | `23` | 4 de copes | 3 de copes | 5 de bastos |
| El Mort contra banca amb 7½ | `217` | 7 de copes | cavall d'oros | cavall d'espases (la carta del Mort). La següent, que demana la banca, és el 7 d'oros: ½+7 = 7½ i es planta |
| El Mort a una taula privada (2 humans) | `46` | 7 d'oros (el 3 de cors i el 6 d'espases van al sorteig de banca) | cavall de bastos | cavall de cors |
| Un 4 després del canvi del 4 | `44` | 4 d'espases | 7 de copes | 4 de copes (es torna a oferir el canvi) |

### Què fer a cada escenari

- **Separar.** Llavor `3`. Apostar, i quan surti la primera carta (figura) prémer «Doblar»
  o «Carta». La segona carta també és figura (mig punt). «Separar» queda disponible.
  En separar, cada mà rep sola una segona carta.
- **Separar després de doblar.** La mateixa llavor `3`. Doblar no planta: després del
  doble (cavall de bastos + sota d'oros) es pot separar. Cada mà porta l'aposta doblada,
  surt amb `doubled` fals i no es pot tornar a doblar. La primera mà rep el 3 de copes;
  la segona, la sota de bastos (una altra parella: es pot tornar a separar).
- **Tornar a separar.** Llavor `702`. La primera carta és la sota d'oros. «Carta» treu el
  rei d'oros: es pot separar. La segona carta de la primera mà arriba sola i és el rei de
  copes: es pot tornar a separar (en aquesta seqüència surten 3 mans; no hi ha límit). La mà nova del primer separar rep el 6 d'espases.
- **El Mort.** Llavor `4`. La primera carta és un 7: s'ofereix el Mort (acceptar o seguir).
- **El Mort que falla.** Llavor `206`. Acceptar el Mort: la carta secreta és el 5 d'espases (7+5=12, et passes). La 217 fa 7½ (èxit de la fórmula) però empat amb la banca; per a l'animació de fracàs cal la 206.
- **Canvi del 3.** Llavor `13`. La primera carta és un 3: «Jugar» o «Canviar». Canviar
  descarta el 3 i dona dues cartes tapades.
- **Canvi del 4.** Llavor `23`. La primera carta és un 4: «Jugar» o «Canviar». Canviar
  descarta el 4 i dona una carta tapada.
- **El Mort contra una banca amb 7½.** Llavor `217`. La primera carta és un 7: cal **acceptar
  el Mort**. La carta del Mort és el cavall d'espases. La banca obre amb el cavall d'oros
  (mig punt), demana el 7 d'oros i es planta a 7½. Si no s'accepta el Mort, aquesta seqüència
  no val: la banca es quedaria la carta del Mort.
- **El Mort a una taula privada.** Llavor `46`. Dos humans sense bots: el sorteig de banca gasta les
  dues primeres cartes i qui no banca rep el 7 d'oros (e2e/fixes-v178.spec.ts, vista del rival).
- **Un 4 que torna a sortir.** Llavor `44`. La primera carta és el 4 d'espases. «Canviar»
  el descarta i surt el 4 de copes: es torna a oferir el canvi.

Les figures són valor 10, 11 i 12 (sota, cavall, rei) i compten juntes: es poden separar
entre elles. També es pot separar qualsevol parella del mateix valor (5+5, 1+1…). Un 5 i un 6
no. Si la segona carta fa passar de 7½, la mà es tanca abans de poder separar.

## Llavor per sala privada (només tests i QA)

A més de la llavor global de dalt, una sala privada pot portar la seva llavor. Això
permet que Qualitat provi doblar, separar i la banca de l'amfitrió sense fixar la
barreja de tot el procés.

### Com s'activa

Calen les dues condicions:

1. `SETIMIG_TEST_SEEDED_DECK=1` (el valor ha de ser exactament `1`).
2. El procés **no** és producció (`NODE_ENV` diferent de `production`).

Si falta la variable, o `NODE_ENV=production` (encara que la variable hi sigui), el camp
`deckSeed` de `create_private_table` **s'ignora**: la sala es crea igual i la barreja
segueix sent criptogràfica (o la llavor global, si aquella sí que està activa). En
producció es registra un avís una sola vegada (`[baralla] SETIMIG_TEST_SEEDED_DECK ignorada`).

La llavor es passa en crear la sala, al payload de `create_private_table`:

```js
socket.emit("create_private_table", {
  playerName: "Qa",
  playerId: "…",
  playerToken: "…",
  houseRulesEnabled: true,
  deckSeed: 3,
});
```

`deckSeed` és un enter ≥ 0 (també s'accepta com a text `"3"`). Un valor que no ho sigui
s'ignora. La llavor no es torna al client (no surt a `joined_room` ni a `room_update`).
La mateixa funció de barreja que `SETIMIG_TEST_DECK_SEED` (`mulberry32` a
`shared/shuffle.ts`), així que els números de la taula de solo són els mateixos munts.

### Dos humans, sense bots (l'amfitrió seu primer)

El sorteig de banca gasta les dues primeres cartes (`pop`). Qui no banca rep la tercera;
la quarta és la carta inicial de la banca; la cinquena és la de demanar o doblar.
Per això el significat de solo (on no hi ha sorteig) **no** coincideix carta per carta.

| Què vol provar Qualitat | `deckSeed` | Què passa |
|---|---|---|
| Doblar, separar, i la banca és l'amfitrió | `3` | L'amfitrió guanya el sorteig (cavall de bastos contra el 2 de copes) i fa de banca. El convidat obre amb la sota d'oros i, si dobla, surt la sota de bastos. En separar, la mà 1 rep el 7 d'oros (7½) i la mà 2 el 5 d'espases; les dues porten l'aposta doblada i no es poden tornar a doblar. La banca obre amb el 3 de copes i, si demana, el 6 de copes (es passa a 9). |
| El Mort, per a l'amfitrió (no és la banca) | `46` | El convidat fa de banca. L'amfitrió rep el 7 d'oros: s'ofereix el Mort. La carta de demanar, si no s'accepta el Mort, és el cavall de copes. |
| Canvi del 3, per a l'amfitrió | `13` | El convidat fa de banca. L'amfitrió obre amb el 3 de copes. |
| Canvi del 4, i després la regla del 3 | `44` | El convidat fa de banca (7 de copes contra el 4 d'espases de l'amfitrió) i obre amb el rei de bastos. L'amfitrió obre amb el 4 de copes. «Canviar» dona el 3 de bastos i s'ofereix la regla del 3 (`DECIDE_SWAP_FIRST`): doblar, demanar o separar es rebutgen fins que es decideix. «Canviar» el 3 dona la sota d'oros i el 5 d'espases, tapa les dues i planta. «Jugar» es queda el 3 i el pot doblar. |
| Separar, però la banca és el convidat | `217` | L'amfitrió obre amb el cavall d'espases i, si dobla, surt la sota de bastos. En separar, la mà 1 rep el 7 de bastos (7½) i la mà 2 el 6 de bastos; les dues porten l'aposta doblada i no es poden tornar a doblar. La banca (el convidat) obre amb el 7 d'oros; si demana, el 6 de copes (7+6=13). |
| Separar sense haver doblat | `7` | El convidat fa de banca (3 de copes contra l'as de copes de l'amfitrió). L'amfitrió obre amb la sota d'espases. Si demana carta (no dobla), surt el cavall d'oros: dues figures, es pot separar. Cada mà surt amb `canDouble` false: una mà separada no es pot doblar (`SPLIT_CANNOT_DOUBLE`). La mà 1 queda sota d'espases + 5 d'oros; la mà 2, cavall d'oros + 6 d'oros. La banca obre amb el 6 de bastos. |
| Després del canvi del 4, un ½ (doblar) | `131` | El convidat fa de banca (cavall d'espases contra la sota de copes de l'amfitrió) i obre amb el 3 de copes. L'amfitrió obre amb el 4 de copes. «Canviar» dona el cavall de copes: és una primera carta i es pot doblar. Doblar treu l'as d'espases. |
| Després del canvi del 4, un 7 (el Mort) | `33` | El convidat fa de banca (cavall de bastos contra el 3 de bastos de l'amfitrió) i obre amb l'as de copes. L'amfitrió obre amb el 4 de bastos. «Canviar» dona el 7 d'oros i s'ofereix el Mort: doblar o demanar es rebutgen amb `DECIDE_MORT_FIRST`. Si es rebutja el Mort, el 7 es pot doblar i surt el cavall d'espases. |
| Després del canvi del 4, dues figures (separar) | `601` | El convidat fa de banca (cavall de bastos contra el cavall d'espases de l'amfitrió) i obre amb el 6 de copes. L'amfitrió obre amb el 4 d'espases. «Canviar» dona el cavall d'oros i es pot doblar. Doblar treu la sota de copes: dues figures, es pot separar. Cada mà porta l'aposta doblada i `canDouble` false (`SPLIT_ALREADY_DOUBLED`). La mà 1 queda cavall d'oros + 7 de bastos; la mà 2, sota de copes + 5 de bastos. |
| Tornar a separar una mà que ve d'un separar | `18` | L'amfitrió fa de banca (6 d'oros contra el 4 de bastos del convidat) i obre amb la sota de copes. El convidat obre amb el rei d'oros. «Carta» (no «Doblar») treu el cavall de bastos: dues figures, es pot separar. En separar, la mà 1 rep el cavall d'oros (una altra parella de figures: es pot tornar a separar) i la mà 2 el 5 de bastos. Tornar a separar deixa 3 mans, cadascuna amb `canDouble` false: rei d'oros + 7 de copes, cavall d'oros + 5 de copes, i cavall de bastos + 5 de bastos. |

- **Separar sense haver doblat.** Llavor `7`. Dos humans, normes de la casa, l'amfitrió assegut
  primer. El convidat guanya el sorteig i fa de banca. L'amfitrió aposta i, quan surt la sota
  d'espases, prem «Carta» (no «Doblar»): la segona és el cavall d'oros. «Separar» deixa les dues
  mans amb `canDouble` false. Doblar-ne qualsevol es rebutja amb `SPLIT_CANNOT_DOUBLE` i no
  canvia l'aposta.
- **Tornar a separar.** Llavor `18`. Els mateixos dos humans, l'amfitrió assegut primer. L'amfitrió
  guanya el sorteig (6 d'oros contra el 4 de bastos) i fa de banca; obre amb la sota de copes.
  El convidat aposta i, quan surt el rei d'oros, prem «Carta» (no «Doblar»): la segona és el
  cavall de bastos. «Separar» deixa la mà 1 amb rei d'oros + cavall d'oros (ja és una mà separada, i
  encara són dues figures) i la mà 2 amb cavall de bastos + 5 de bastos. «Separar» una altra
  vegada fa 3 mans, totes amb `canDouble` false: rei d'oros + 7 de copes, cavall d'oros + 5 de
  copes, i cavall de bastos + 5 de bastos. Doblar-ne qualsevol es rebutja amb `SPLIT_CANNOT_DOUBLE`.

Les llavors `4` i `206` del solo (el Mort) gasten el 7 al sorteig de banca: amb dos humans
l'amfitrió **és** la banca, però la mà que es juga no és un Mort. Per al Mort en sala
privada cal la `46`. La `702` (re-separar al solo) tampoc no dona dues figures seguides
a qui no banca, perquè el sorteig es menja les dues primeres cartes. En sala privada,
tornar a separar és la `18`.

### Mans següents de la mateixa sala

La llavor no fixa només la primera mà. Quan la sala ja ha liquidat una mà (`handSeq` ≥ 1),
la següent no continua el munt que quedava: s'obre una baralla nova de 40 cartes barrejada
amb la llavor combinada amb el número de mà (`seededHandSeed` a `shared/testSeededDeck.ts`).
La primera mà segueix sent la de la taula de dalt, perquè el número 0 deixa la llavor tal qual.

Dues sales amb el mateix `deckSeed` i les mateixes decisions reparteixen les mateixes cartes
a la mà 2 i a la mà 3, encara que a la primera mà s'hagin demanat cartes diferents.
Sense `SETIMIG_TEST_SEEDED_DECK=1`, o amb `NODE_ENV=production`, aquesta barreja no s'aplica
i cada mà continua sent criptogràfica (o la llavor global, si aquella sí que està activa).
