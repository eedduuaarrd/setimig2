# Inici de sessió: contracte per al client (App PWA)

Backend: PRs #234 (correu), #235 (identitats + correu), #236 (Google) i #237 (passkeys).
Tot és sota `/api/auth/`. Les respostes JSON d'error sempre tenen `{ error: "<text en català>", code: "<CODI>" }`.

## Sessió: res canvia
- Un compte continua sent un `playerId`, i la sessió continua sent el `playerToken` signat de sempre.
- Qualsevol login amb èxit retorna:
  ```json
  { "playerId": "…", "playerToken": "…", "method": "email|google|passkey",
    "created": false, "linked": true, "switchedAccount": false }
  ```
  El client el desa a `setimig_player_id` i `setimig_player_token`, com fa ara, i a partir d'aquí tot funciona igual: `Authorization: Bearer <playerToken>`, sockets i saldo.
- La sessió de l'API és el Bearer. A més, el servidor posa la galeta HttpOnly `setimig_session` (el mateix token) perquè l'HTML estàtic pugui obrir-se; `POST /api/auth/logout` l'esborra. `sm_g_state` és només el flux de Google; el client no l'ha de tocar.
- Envieu sempre `Authorization: Bearer <token actual>` (o, per als perfils antics sense token, `playerId` al cos) quan inicieu un login. Així un jugador anònim **enllaça** el seu compte actual (mateix saldo) en comptes de crear-ne un de nou.
- `created: true`: és un compte nou (saldo inicial). Demaneu l'àlies i feu `PUT /api/profile` com ara.
- `linked: true`: el compte anònim d'aquest navegador ara té aquesta identitat.
- `switchedAccount: true`: el navegador tenia un **altre** compte i ara s'entra al compte de la identitat. No es fusionen; l'altre compte queda intacte. Mostreu un avís, per exemple «Has entrat al compte associat a aquest correu. El compte anterior d'aquest dispositiu no s'ha modificat.»
- **18+**: el pas 18+ es manté al client com ara. Per crear un compte **nou**, envieu `ageConfirmed: true`, que el client només envia si l'usuari ha acceptat el pas 18+. Sense això, el servidor respon `AGE_CONFIRMATION_REQUIRED` (403, o `#error=` a Google). Entrar en un compte existent o enllaçar-ne un d'anònim no ho necessita.
- Tancar sessió: `POST /api/auth/logout` amb el Bearer (i la galeta `setimig_session`, si n'hi ha). El servidor revoca **aquesta sessió**: el token enviat i els que se n'han renovat amb `POST /api/player-session` (el token d'abans de renovar també deixa de valer). Esborra la galeta i desconnecta els sockets d'aquesta sessió. Un token emès a part (un altre dispositiu) continua valent. Després, `GET /api/auth/me` i `GET /api/me` amb qualsevol token d'aquesta sessió responen 401. El client també esborra `setimig_player_token` i `setimig_player_id`. Sense token, el logout respon 200 i no revoca res.
- Recuperar la sessió: `POST /api/player-session` sense Bearer, amb la galeta `setimig_session`, si el client ha perdut el token. Només si la galeta és vàlida, no caducada i no revocada. La resposta és un **token nou** del mateix compte (`{ playerId, playerToken }`), el mecanisme de sempre; no es crea cap usuari. Qui guanya si arriben les dues coses: un Bearer (o `playerToken` al cos o a la query, el primer que hi sigui, com fins ara) **vàlid** guanya sempre, encara que la galeta sigui d'un altre compte — no es fusionen. Si aquest valor hi és però no és vàlid (perdut, caducat o revocat), no es prova un altre `playerToken` explícit; només llavors es fa servir la galeta. Sense cap credencial vàlida: `401 { "error": "auth_required" }`. La galeta no autentica la resta de `/api` ni el socket. Protecció: `HttpOnly; Secure; SameSite=Lax` (un POST d'un altre lloc no l'envia) i, quan la credencial que guanya és la galeta, el mateix control d'origen que el login (`403` `BAD_ORIGIN`).

## Proveïdors disponibles
`GET /api/auth/providers` →
```json
{ "email": true, "google": false, "passkey": true, "rpId": "sevenhalf.club" }
```
Amagueu el botó de cada proveïdor que valgui `false`. `email` és `false` mentre el canal de correu no estigui configurat.
Per oferir passkeys, comproveu també al client `window.PublicKeyCredential` i `PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable()`.

## Estat del compte (perfil)
`GET /api/auth/me` i `GET /api/me` (cal Bearer) →
```json
{ "playerId": "…", "emails": ["marta@exemple.cat"], "google": false, "passkeys": 1, "verified": true }
```
Retorna 401 `AUTH_REQUIRED` si no hi ha token vàlid.

## 1. Correu (codi de 6 xifres)
1. `POST /api/auth/email/start` `{ "email": "…", "ageConfirmed": true, "locale": "en" }`, amb Bearer si n'hi ha.
   - **`locale` (NOU, opcional)**: l'idioma de la UI, un de `ca`, `en`, `es`, `it`, `pt-BR` (també s'accepta `pt`, `pt-PT`, `en-US`… i l'àlies `lang`). El correu (assumpte i cos) surt **sencer** en aquest idioma. Ordre: `locale` vàlid → capçalera `Accept-Language` → anglès. Envieu sempre l'idioma actual de la UI.
   - La resposta és **sempre** `202 { "ok": true, "expiresInSec": 600 }`, tant si el correu té compte com si no.
   - Errors: 400 `BAD_EMAIL`, 429 `RATE_LIMIT` (capçalera `Retry-After`), 503 `UNAVAILABLE` (canal de correu no configurat).
   - Arriba un correu amb la marca Seven Half Club (HTML + text pla) i el codi a l'assumpte. L'HTML no porta imatges ni enllaços clicables; l'adreça `https://sevenhalf.club/login/correu` va escrita en text (obrir-la **no** inicia sessió). La pàgina `/login/correu` sense `#t=` ha de mostrar el camp de correu i el de 6 xifres.
   - Seguiment de Brevo: la crida transaccional envia `contactPixelTrackingConsent: false` i les capçaleres `X-Mailin-Track*`. Això no garanteix que el píxel desaparegui a tots els comptes (les capçaleres no ho van aturar al relé SMTP, prova del 27/10/2026). Detall a `docs/correu-codi-acces.md`. El correu no porta cap token d'un sol ús.
2. Per verificar, hi ha dues opcions:
   - Codi: `POST /api/auth/email/verify` `{ "email": "…", "code": "123456", "ageConfirmed": true }`
   - Enllaç màgic (DESACTIVAT per defecte; només si el servidor té `MAIL_LOGIN_MAGIC_LINK=1`): la pàgina `/login/correu` llegeix `t` del **fragment** (`location.hash`), fa `POST /api/auth/email/verify` `{ "linkToken": "<t>" }` i neteja el hash amb `history.replaceState`. No feu servir GET. Mantingueu-ho al client: si no hi ha `#t=`, només es mostra el formulari del codi.
   - Èxit: 200 amb el cos de login.
   - Errors: 400 `INVALID_CODE` (5 intents màxim per codi), 400 `BAD_REQUEST`, 410 `EXPIRED_OR_USED` (en demaneu un altre), 403 `AGE_CONFIRMATION_REQUIRED`, 429 `RATE_LIMIT`.
   - El codi caduca als 10 min i és d'un sol ús. El codi i l'enllaç són el mateix repte, i demanar-ne un de nou invalida l'anterior.
   - Si l'enllaç s'obre en un altre navegador sense sessió, s'entra al compte del navegador que l'havia demanat. Dins la PWA d'iOS l'enllaç s'obre a Safari, que té una altra memòria. Per això, a la PWA, recomaneu sobretot **escriure el codi**.
- Límits: 3 correus per adreça i 10 per IP cada 15 min. Passat el límit per adreça, la resposta és la mateixa però no s'envia res.

## 2. Google
1. `POST /api/auth/google/start` `{ "ageConfirmed": true }`, amb Bearer si n'hi ha, retorna `{ "url": "https://accounts.google.com/…" }`. Feu `location.assign(url)` i no l'obriu en un iframe.
   - Errors: 404 `DISABLED` (sense credencials de Google), 429 `RATE_LIMIT`.
   - Alternativa sense compte actual: un enllaç simple a `GET /api/auth/google/start?ageConfirmed=1`.
2. Google torna a `https://sevenhalf.club/api/auth/google/callback`, que redirigeix a:
   - `https://sevenhalf.club/login/google#code=<codi>`: feu `POST /api/auth/exchange` `{ "code": "<codi>" }` i rebreu el cos de login (`method: "google"`). El codi és d'un sol ús i caduca en 2 min; si ha caducat, 410 `EXPIRED_OR_USED`.
   - `https://sevenhalf.club/login/google#error=<CODI>`, amb aquests codis:
     - `ACCESS_DENIED`: l'usuari ha cancel·lat.
     - `AGE_CONFIRMATION_REQUIRED`: demaneu el pas 18+ i torneu a començar amb `ageConfirmed: true`.
     - `BAD_STATE` o `STATE_MISMATCH`: el procés ha caducat o s'ha obert en un altre navegador; torneu-ho a provar.
     - `TOKEN_EXCHANGE_FAILED`, `BAD_ID_TOKEN`, `INTERNAL`: error genèric.
   - Netegeu el hash amb `history.replaceState`.
- La ruta `/login/google` (i `/login/correu`) l'ha de servir la SPA, que ja ho fa per a qualsevol ruta sense extensió.
- Si el correu de Google (verificat) ja és d'un compte, s'entra en aquell compte.

## 3. Passkeys (Face ID / Touch ID)
Recomanació: feu servir `@simplewebauthn/browser` (`startRegistration` i `startAuthentication`), que accepta tal qual les opcions JSON del servidor.

**Afegir una passkey des del perfil** (cal haver entrat amb token; l'id llegat no basta):
1. `POST /api/auth/passkey/register/options` `{}` + Bearer retorna `PublicKeyCredentialCreationOptionsJSON`.
2. `const response = await startRegistration({ optionsJSON })`
3. `POST /api/auth/passkey/register/verify` `{ "response": response, "name": "iPhone" }` + Bearer retorna `{ ok: true, passkey: { id, name, createdAt, lastUsedAt, deviceType, backedUp } }`.
   - Errors: 400 `NO_CHALLENGE` (caducat als 5 min), 400 `VERIFICATION_FAILED`, 409 `ALREADY_REGISTERED`, 409 `TOO_MANY` (màxim 10), 401 `AUTH_REQUIRED`.

**Entrar amb un toc** (sense escriure res):
1. `POST /api/auth/passkey/login/options` `{}` retorna `{ "challengeId": "…", "options": PublicKeyCredentialRequestOptionsJSON }`.
2. `const response = await startAuthentication({ optionsJSON: options })`. També podeu fer servir `useBrowserAutofill: true` amb un `<input autocomplete="username webauthn">`.
3. `POST /api/auth/passkey/login/verify` `{ "challengeId": "…", "response": response }`, amb Bearer si n'hi ha, retorna el cos de login (`method: "passkey"`).
   - Errors: 404 `UNKNOWN_CREDENTIAL` (aquesta passkey no és de cap compte; una passkey **mai** crea un compte), 400 `NO_CHALLENGE`, 400 `VERIFICATION_FAILED`, 429 `RATE_LIMIT`.

**Gestionar-les**:
- `GET /api/auth/passkeys` + Bearer retorna `{ passkeys: [...] }`.
- `DELETE /api/auth/passkeys/:id` + Bearer retorna `{ ok: true }`, o 404 `NOT_FOUND`.

Les passkeys només funcionen a `https://sevenhalf.club` (rpId `sevenhalf.club`), i no a l'antic `setimig.supercbb.com`.

## 4. Esborrar el compte (perfil)
`POST /api/account/delete` + `Authorization: Bearer <token>` amb el cos `{ "confirm": "DELETE_MY_ACCOUNT" }` (literal; és la confirmació explícita, que el client només envia després que l'usuari ho confirmi en un diàleg).
- Èxit: `200 { "ok": true, "deleted": true }`. Després, el client esborra `setimig_player_id` i `setimig_player_token` i torna a l'inici com un jugador nou.
- Errors: 401 `AUTH_REQUIRED` (sense token o token que ja no val), 400 `CONFIRMATION_REQUIRED` (falta o és incorrecte `confirm`), 403 `BAD_ORIGIN`, 500 `INTERNAL`.
- Què s'esborra: perfil (nom i avatar), saldo i compres d'entrada obertes, identitats (correus, Google, passkeys), estadístiques i historial, assoliments i missions, campanya, amics (i el jugador desapareix de les llistes dels altres), la seva entrada als rànquings setmanals, i analítica pseudònima. Les dades dels altres jugadors no canvien.
- **Tots els tokens d'aquest compte deixen de valer** (i el playerId antic sense token també). Si després s'entra amb el mateix correu o Google, és un compte **nou** (cal el pas 18+).
- No és reversible des de l'app. Text suggerit per al diàleg: «S'esborraran el teu perfil, les fitxes i l'historial. No es pot desfer.»
- Administració: `scripts/delete-account.ts` fa el mateix per playerId (simulació per defecte, `--apply` amb el servei aturat, còpia amb sha256 a `~/setimig-backups`).

## Esborrany mínim de la pàgina (només orientatiu)
`/login` conté:
- botó «Continua amb Google» (si `providers.google`);
- camp de correu, «Envia'm el codi», camp de 6 xifres i «Entra»;
- botó «Entra amb Face ID / Touch ID» (si `providers.passkey` i el dispositiu ho admet).

Al perfil: «Afegeix Face ID / Touch ID», la llista de passkeys amb «Elimina» i l'estat del correu i de Google (`/api/auth/me`).
