# Codis del motor: `highlights[]` i `results[]`

Des d'aquesta versió, cada entrada de `room.lastRound.highlights[]`, `room.lastRound.results[]`
(i les mateixes línies de `lastSettlement` / esdeveniment `settlement`) porta:

- `code`: codi estable (no canvia entre versions).
- `params`: només dades (noms de jugador, id de seient, números, booleans). Mai frases.
- `text` (highlights) / `detail` (results): **text català de reserva**, per als clients en cau.
  Els clients nous han de traduir `code` + `params` i no fer servir el text.
  Els imports d'aquest text **no porten unitat**: `+200`, no `+200 CF`. `detail` segueix sent un
  string (el client el parteix per ` · ` i el passa a `parseGameMessage`). La forma és la mateixa
  que les claus `engine.result.win`, `winBankBust`, `naturalWin` i `specialWin` del client:
  un enter amb signe, sense separadors de milers, i —si cal— la frase catalana entre parèntesis
  o davant d'un guió. `parseGameMessage` encara accepta el sufix antic ` CF` perquè les partides
  desades es tradueixin. No canvien `name`, `outcome`, `chipDelta`, `handPoints`, `code` ni `params`.

Font de veritat dels tipus: `shared/messageCodes.ts` (`HighlightMessage`, `ResultMessage`).
El text de reserva el genera `highlightFallbackText` / `resultFallbackDetail`.

## Highlights (una entrada per mà liquidada d'un jugador; un split en dona dues)

Paràmetres comuns a tots: `player` (nom visible), `seatId` (id de seient en el moment de
liquidar, el mateix que `PlayerView.id`), `hand` (0, o 1 per a la segona mà d'un split),
`score` (punts de la mà; pot ser 0,5 en 0,5, p. ex. 7.5).

| `code` | Paràmetres extra | Text català de reserva | Significat |
|---|---|---|---|
| `bust` | — | `Passat` | La mà ha passat de 7½ (també la parella cega del 3 en destapar-se). |
| `mortLoses` | — | `Mort — perd l'aposta` | El Mort no ha fet 7½: perd l'aposta. |
| `bankWins` | `bankScore` | `Banca guanya` | La banca guanya la mà. |
| `tieSevenHalfBank` | `bankScore` | `Empat a 7½ — banca` | Empat a 7½ amb la banca: guanya la banca. |
| `tieBank` | `bankScore` | `Empat — banca` | Empat: guanya la banca. |
| `win` | `amount`, `bankScore` | `+{amount}` | Guanya. `amount` és el **net** d'aquella mà (el que es cobra menys l'aposta, doble inclòs): un enter amb signe, sense unitat ni separadors de milers. La suma dels nets de les mans del jugador és el seu `chipDelta`. |
| `winBankBust` | `amount`, `bankScore` | `+{amount} (banca passada)` | Guanya perquè la banca s'ha passat. `amount` és el net d'aquella mà. |
| `naturalWin` | `amount`, `jackpot`, `bankBusted` | `7 i Mig natural — +{amount}` | 7½ natural de sortida (2 cartes, sense haver separat). `amount` és el net: 2× l'aposta, més el `jackpot` cobrat. Enter sense separadors (`+12500`, no `+12.500`). Després de separar, el mateix 7½ no porta aquest codi. |
| `specialWin` | `special`, `amount`, `jackpot`, `bankScore`, `bankBusted`, `multiplier` | `Mort ×2 — +{amount}` / `3 canviat ×2 — +{amount}` | Normes de la casa: Mort o 3 canviat que guanya i cobra el doble. `amount` és el net. Tots els highlights d'una mà especial porten `special` (`mort`/`threeSwap`). Vegeu docs/normes-casa.md. |

Exemple:

```json
{ "name": "Anna", "text": "+200", "code": "win",
  "params": { "player": "Anna", "seatId": "s1", "hand": 0, "score": 7, "amount": 200, "bankScore": 6 } }
```

## Results (una línia per jugador amb resultat)

Camps que ja hi eren i no canvien: `name`, `outcome` (`win|lose|push|bust|jackpot`), `chipDelta`,
`detail` (reserva), `handPoints`.

| `code` | `params` | `detail` català de reserva |
|---|---|---|
| `bank` | `player`, `seatId`, `chipDelta`, `score` (punts de la banca o `null`) | `Banca` |
| `noChange` | `player`, `seatId`, `chipDelta` | `Sense canvi` |
| `hands` | `player`, `seatId`, `chipDelta`, `hands: HighlightMessage[]` (els `{code, params}` de les seves mans, en ordre) | textos de reserva de `hands` units amb ` · ` (p. ex. `Passat · +200`) |

## Què ha de fer el client (App PWA)

1. Si l'entrada porta `code`, traduir-la amb una clau i18n per codi (p. ex. `engine.result.<code>`, que
   ja existeix per a part dels codis via `parseGameMessage`) i interpolar `params` (`amount`, `score`,
   `bankScore`, `player`…), als 5 idiomes.
2. Per a `results` amb `code: "hands"`, construir el detall traduint cada element de `params.hands`
   i unint-los amb el separador de l'idioma.
3. Si no hi ha `code` (estat desat abans d'aquest canvi, p. ex. solo local), fer servir el camí actual
   (`parseGameMessage(text)` o el text tal qual).

## Rebuig de doblar (`double_bet` → `game_error`)

Quan el doblar no s'aplica, el servidor envia `game_error` amb un codi estable (no `BAD` genèric).
El `message` continua sent el text català del motor, que el client tradueix amb `parseGameMessage`.
Si la petició portava un `actionId` vàlid (o, si no, un `requestId` vàlid), el mateix id torna a l'error.
Sense id, el camp no hi és. L'estat de la mà no canvia.

El codi el decideix `classifyDoubleReject` (`shared/gameEngine.ts`), el mateix motor a taula privada,
solo per socket i solo HTTP. A la taula privada i al solo HTTP, l'autorització pot respondre abans
(token, seqüència, fase o torn): llavors el codi és el d'autorització (`BAD_PHASE`, `BAD_TURN`, …)
i el missatge és el d'autorització, també amb `actionId` si n'hi havia.

| `code` | Quan | `message` (català) |
|---|---|---|
| `NOT_IN_ROOM` | El socket no és a la sala (només el servidor, abans del motor). | `No es pot doblar ara.` |
| `BAD_PHASE` | La fase no és `playing`. | `No es pot doblar ara.` |
| `BAD_TURN` | No és el seu torn, o no hi ha mà activa. | `No es pot doblar ara.` |
| `BLIND_PAIR_LOCKED` | Parella cega del 3 canviat. | `Mà cega (regla del 3): no pots demanar, doblar ni fer split; només plantar-te.` |
| `HOUSE_RULES` | Normes de la casa apagades. | `No es pot doblar.` |
| `DECIDE_MORT_FIRST` | Encara hi ha l'oferta del Mort. | `Primer decideix el Mort.` |
| `DECIDE_SWAP_FIRST` | Encara hi ha l'oferta de jugar o canviar el 3 o el 4. | `Primer decideix si jugues o canvies la carta.` |
| `MORT` | La mà és un Mort. | `No es pot doblar.` |
| `ALREADY_DOUBLED` | Aquesta mà ja ha doblat (`doubled` true). | `Aquesta mà ja ha doblat.` |
| `SPLIT_ALREADY_DOUBLED` | La mà ve d'un split i la cadena ja havia doblat (`fromSplit` i `splitFromDoubled`). Les mans separades surten amb `doubled` false i `canDouble` false. | `La mà original ja havia doblat abans del split.` |
| `SPLIT_CANNOT_DOUBLE` | La mà ve d'un split i no es pot doblar, encara que l'origen no hagués doblat (`fromSplit`, sense `splitFromDoubled`). | `Una mà separada no es pot doblar.` |
| `CANNOT_DOUBLE` | `canDouble` és false per un altre motiu (no és una mà separada). | `No es pot doblar.` |
| `WRONG_CARDS` | La mà no ve d'un split i no té exactament una carta: només es dobla la primera, abans de demanar-ne cap altra. | `No es pot doblar.` |
| `NOT_ENOUGH_CHIPS` | Fitxes insuficients per igualar l'aposta de la mà. | `No tens prou fitxes per doblar.` |
| `BANK_CANNOT_COVER` | La banca no pot cobrir el doble. | `La banca no pot cobrir el doble.` |

Un doblar acceptat no envia `game_error`. Si cau dins l'avís de ritme, s'encua com el hit i el stand (no és un rebuig).

`maxHands` (codi de `pendingChoices.splitBlocked`, no de `game_error`) ja no s'emet: el separar no té límit de mans. Es conserva a la llista de codis perquè un client antic el reconegui.

## Fora d'abast (encara en català, sense codi)

- `lastRound.title` (`Liquidació`).
- `lastSettlement.seats[].detail` (còpia del `detail` de `results`, o `Banca` / `Sense canvi`).
- Etiqueta d'última acció de cada jugador (`setPlayerHandAction`: `Carta`, `Mort`, `Dobla`, `Split`,
  `Passat`, `Es planta a {n}`).
- Errors del motor i del servidor per socket (`ENGINE_MESSAGES`, `L'aposta mínima és {n}.`,
  `SERVER_MESSAGES` a `shared/gameMessages.ts`): ja es tradueixen al client amb `parseGameMessage`.
  El doblar rebutjat és l'excepció de dalt: a més del text, porta un `code` estable.
