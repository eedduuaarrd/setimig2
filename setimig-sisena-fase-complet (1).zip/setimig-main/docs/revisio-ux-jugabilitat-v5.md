# Set i Mig — revisió V5 (25 d'octubre de 2026)

## Objectiu

Millorar el projecte rebut en el ZIP `setimig-millorat-2026-10-25.zip` de manera transversal, mantenint el motor del joc i les regles existents. Domini de referència: https://setimig.supercbb.com.

## Canvis incorporats

### Experiència d'inici
- Lobby amb una capçalera il·lustrada en CSS, baralla de cartes i identitat pròpia; no afegeix imatges pesades.
- Textos de presentació més clars, edat mínima i fitxes virtuals identificades.
- Guia plegable «Com jugar en 20 segons», que no desplaça la partida principal quan està tancada.
- Avís quan la connexió impedeix les sales amb amics i la IA segueix disponible.
- Estils per a mòbils estrets, focus visible, hover només en dispositius amb ratolí i moviment reduït.

### Ajuda del joc
- «Què puc fer ara?» deixa d'obrir les regles generals i mostra una explicació **contextual** real de la situació.
- Estats previstos: sala d'espera / amfitrió, elecció de banca, apostes, aposta enviada, saldo insuficient, torn propi, rival jugant, opcions especials, liquidació i final de partida.
- No es consulten cartes ocultes d'altres jugadors; tot es calcula amb les dades que el client ja pot veure.
- Enllaç directe a les regles completes i finestra accessible (focus i tecla Escape).
- Menú d'eines amb `aria-expanded`, tancament amb Escape i focus retornat al disparador.

### Perfil
- Fotos JPG/PNG/WebP processades a **320 × 320 px com a màxim**, retallades al centre i comprimides abans d'enviar-les.
- L'usuari rep feedback si la imatge és invàlida, supera el límit o no es pot desar al servidor.
- Filtratge addicional al servidor contra `data:image/svg+xml` i altres imatges de dades no autoritzades.
- No es canvia la identificació ni el saldo del jugador.

### Fiabilitat i seguretat
- Pantalla de càrrega visible per a la web inicial i la taula; abans un `Suspense` podia deixar blanc el contingut.
- Límit d'errors de React amb accions per tornar-ho a provar, sense exposar traces internes a la pantalla.
- Millora de la semàntica del formulari del nom (diàleg i focus).
- Capçaleres del servidor: `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, `Permissions-Policy`; respostes `/api/` sense memòria cau.
- PWA: manifest de fitxers JS/CSS generat en compilar, inclosos imports dinàmics; facilita jugar a la IA sense xarxa després de la primera instal·lació satisfactòria.
- Service worker V37: les actualitzacions esperen un moment segur entre mans, en comptes de `skipWaiting()` automàtic durant la instal·lació.
- Nova pàgina offline amb missatge ajustat: les sales privades necessiten xarxa, però la IA pot funcionar amb els recursos emmagatzemats.

## Canvis que no s'han fet

- No s'han alterat les regles, els càlculs d'apostes, la rotació de banca, el xat, la gestió de fitxes ni la integració Stripe.
- No s'han tocat els identificadors del jugador ni les seves dades de producció.
- No s'ha desplegat al servidor real.

## Validació en aquest entorn

- 256 fitxers TypeScript/TSX analitzats, sense errors de **sintaxi**.
- TypeScript estricte superat per als nous mòduls independents de React (`contextualGameHelp` i `avatarImage`).
- Fitxers CSS llegibles pel parser CSS (`tinycss2`): sense errors d'alt nivell.
- SW validat amb `node --check`.
- 19 proves focalitzades: 19 superades (ajuda, perfil, accessibilitat offline i rutes PWA).
- La bateria ampliada de tests executables sense dependències ha superat 235 casos; 13 fitxers no han pogut carregar perquè requereixen React, Socket.IO o el carregador `tsx` no instal·lables en aquest entorn.
- `npm ci` no s'ha pogut completar per un problema d'accés DNS al registre NPM; per tant, no s'ha pogut compilar Vite ni executar Playwright/Lighthouse amb el projecte complet. **El desplegament requereix passar aquests controls en un servidor amb NPM disponible.**

## Verificació abans de publicar

```bash
npm ci
npm run check
npm test
npm run test:e2e:pas17
```

Després de compilar, comprovar manualment: entrada +18, IA en mòbil i escriptori, ajuda contextual a l'aposta i durant el torn, taula privada, xat, canvi de nom i imatge, recàrrega entre mans, PWA i represa de partida.

Consulteu també `DESPLEGAMENT-SUPERCBB.md`.
