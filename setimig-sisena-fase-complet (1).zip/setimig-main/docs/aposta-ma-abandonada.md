# Aposta d'una mà abandonada

La solo amb saldo real (ni pràctica, ni torneig ràpid, ni taula privada) descompta una
compra de 2.000 fitxes en seure (`openSoloBuyIn`). El vestíbul mostra el saldo **gastable**
mentre el jugador és a la taula. Les 2.000 no s'han perdut: són a la taula.

## Què passa en sortir a mitja mà

«Sortir» (el botó de la taula, o `POST /api/solo/leave`) tanca la compra **aleshores**,
una sola vegada:

- Es retornen les fitxes que el jugador encara té al seient (`seat.chips`).
- **L'aposta ja posada al pot d'aquesta mà no es retorna.** Comptava per comprovar que
  el seient quadra amb el llibre (compra + mans liquidades), però no s'abona. És la
  regla de `soloBuyInPayout` (`server/soloBuyIn.ts`): a mitja mà el romanent que torna
  és `seat.chips`, sense `seat.bet`.
- No es paga dues vegades. La compra surt del llibre abans de cap espera; un segon
  «Sortir», una liquidació posterior de la mateixa mà o un reinici no tornen a abonar
  aquell id.

Exemple: saldo 10.000, compra 2.000, aposta 100 a la mà en curs (seient 1.900 + aposta
100). En sortir el vestíbul queda a 9.900. Les 100 de l'aposta abandonada no tornen.
Si encara no hi havia aposta, tornen les 2.000 senceres.

La taula privada no toca `balances.json`. Si un humà surt a mitja mà i en queda un
altre, `removePlayerFromHand` segueix la seva regla (a «betting» es torna l'aposta; amb
la mà repartida l'aposta va a la banca).

## Desconnexió (la partida continua)

Tancar la pestanya o perdre la xarxa **no** és «Sortir». El seient el segueix jugant la
IA i la compra continua oberta, per poder reprendre. El saldo gastable segueix sent
«saldo d'abans − 2.000», però el vestíbul suma les fitxes que encara són a la taula
(`seat.chips + seat.bet`) mentre el seient no està connectat. Així les 2.000 no
desapareixen del número del vestíbul fins que la mà es liquida o el jugador surt de debò.

Quan la partida acaba (o es comença una de nova), la compra es tanca una sola vegada
amb el resultat verificat. Reprendre i després sortir no duplica l'abonament.
