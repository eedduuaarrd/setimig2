# Contracte d'aposta en viu

La PWA pinta l'aposta a la mateixa pantalla de la taula. El servidor ja envia, durant la fase `betting`, qui ha apostat, quant i qui falta. No cal esperar que es tanqui la fase.

El camp és additiu: `bet`, `status`, `chips` i `pot` no canvien de significat. Els clients que no el llegeixen el poden ignorar.

## On arriba

| Canal | Esdeveniment o resposta | Quan |
| --- | --- | --- |
| Sala privada (socket) | `room_update` | Després de cada `place_bet` acceptat i després de cada aposta d'un bot |
| Solo amb socket | `room_update` | Igual |
| Solo HTTP | cos de `POST /api/solo/action` i `GET /api/solo/view` | La vista ja porta el camp; els bots avancen entre lectures |

`joined_room` és la mateixa vista en el moment d'entrar. El mazo no surt mai. Les cartes tapades arriben amb `card: null` (a la fase d'aposta les mans encara són buides).

## `players[].betting`

Només té sentit amb `phase === "betting"`. Fora d'aquesta fase el camp és `null` (l'aposta ja col·locada segueix a `players[].bet` i, un cop repartit, a `handSlots[].bet`).

```ts
type SeatBettingStatus = "pending" | "placed";

interface SeatBettingView {
  status: SeatBettingStatus;
  /** Fitxes ja apostades. Només si status és "placed". Sempre un enter > 0. */
  amount?: number;
}
```

| Seient | `betting` |
| --- | --- |
| Encara ha d'apostar | `{ "status": "pending" }` (sense `amount`) |
| Ja ha apostat | `{ "status": "placed", "amount": <fitxes> }` |
| Banca | `null` |
| No ha d'apostar (fitxes sota el mínim, o la banca no arriba a cobrir el mínim) | `null` |
| Qualsevol seient quan `phase` no és `"betting"` | `null` |

`players[].bet` coincideix amb `amount` quan l'aposta està col·locada i és `0` quan és `pending` o `null`. `players[].status` passa de `"betting"` a `"playing"` en el moment de col·locar l'aposta, encara que la sala segueixi a `"betting"`. Per saber qui falta, fes servir `betting`, no `status`.

## Quan s'emet

- Un humà aposta (`place_bet`) i encara falta algú: tot seguit, `phase` segueix sent `"betting"`, el seu seient és `placed` amb l'import i qui no ha apostat és `pending`. Tots els sockets de la sala reben aquest `room_update`.
- Cada bot aposta pel seu compte, amb el mateix criteri: una vista nova per aposta, amb la fase encara oberta mentre quedi algú `pending`. No s'agrupen en un sol enviament.
- L'aposta que completa la ronda no reparteix encara. Emet una vista `betting` amb `phaseEndsAt` (instant de l'aposta + `BETS_SETTLE_MS`) i, als seients que han apostat, `{ "status": "placed", "amount" }`. La banca i els exempts segueixen a `null`. No queda ningú `pending`. Les cartes arriben en una vista posterior, quan passa aquest temps (`docs/contracte-ritme.md`).
- Si s'esgota el termini, les apostes que faltaven (mínima dels humans, bots restants) es resolen juntes. La vista d'aquell moment és la de tancament (`betting` + `phaseEndsAt`), no el repartiment.
