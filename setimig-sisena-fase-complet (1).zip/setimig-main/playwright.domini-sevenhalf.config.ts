import { defineConfig, devices } from "@playwright/test";
import { e2eServerEnv } from "./e2e/helpers/e2eServerEnv";

/**
 * Traspàs setimig.supercbb.com -> sevenhalf.club. Els dos orígens se simulen amb page.route:
 * les peticions https://setimig.supercbb.com/* i https://sevenhalf.club/* es serveixen des del
 * servidor local (127.0.0.1, build de producció), inclosa l'API real de traspàs (#202); alguns
 * tests en simulen les respostes d'error. El DNS d'aquests dominis es bloqueja perquè cap
 * petició (ni el socket) arribi a producció. Cal `npm run build` abans.
 */
const port = Number(process.env.SETIMIG_E2E_PORT ?? 3298);

export default defineConfig({
  testDir: "./e2e",
  testMatch: "domini-sevenhalf.spec.ts",
  timeout: 90_000,
  retries: 0,
  workers: 1,
  projects: [
    {
      name: "chromium",
      use: {
        ...devices["Pixel 5"],
        browserName: "chromium",
        launchOptions: {
          args: [
            "--host-resolver-rules=MAP sevenhalf.club ~NOTFOUND, MAP www.sevenhalf.club ~NOTFOUND, MAP setimig.supercbb.com ~NOTFOUND",
          ],
        },
      },
    },
  ],
  use: {
    locale: "en-US",
    colorScheme: "dark",
    baseURL: `http://127.0.0.1:${port}`,
    serviceWorkers: "block",
    viewport: { width: 390, height: 844 },
  },
  globalTeardown: "./e2e/helpers/e2eGlobalTeardown.ts",
  webServer: {
    command: `cross-env NODE_ENV=production SETIMIG_HOST=127.0.0.1 PORT=${port} APP_URL=http://127.0.0.1:${port} PLAYER_TOKEN_SECRET=playwright-e2e-test-secret tsx server.ts`,
    env: e2eServerEnv(),
    url: `http://127.0.0.1:${port}/`,
    reuseExistingServer: false,
    timeout: 60_000,
  },
});
