import { defineConfig } from "@playwright/test";
import { catalanStorageState } from "./e2e/catalanLocale";
import { e2eServerEnv } from "./e2e/helpers/e2eServerEnv";

const port = Number(process.env.SETIMIG_E2E_PORT ?? 3305);
const appUrl = process.env.APP_URL ?? `http://127.0.0.1:${port}`;

/** v187: revelació de taula abans del full de liquidació. */
export default defineConfig({
  testDir: "./e2e",
  testMatch: process.env.PW_MATCH ?? "revelacio-v187.spec.ts",
  timeout: 240_000,
  retries: 0,
  workers: 1,
  use: {
    browserName: "chromium",
    baseURL: appUrl,
    locale: "ca-ES",
    storageState: catalanStorageState(),
    colorScheme: "dark",
    video: process.env.PW_VIDEO ? "on" : "off",
  },
  globalTeardown: "./e2e/helpers/e2eGlobalTeardown.ts",
  webServer: {
    command: `${process.env.PW_NOBUILD ? "" : "npm run build && "}${process.env.SETIMIG_TEST_DECK_SEED ? "cross-env NODE_ENV=test" : "cross-env NODE_ENV=production"} PORT=${port} APP_URL=${appUrl} PLAYER_TOKEN_SECRET=playwright-e2e-test-secret npx tsx server.ts`,
    env: e2eServerEnv(),
    url: appUrl,
    reuseExistingServer: true,
    timeout: 180_000,
  },
});
