/**
 * Re-split fins a 3 mans, i canSplit per a qualsevol parella de mig punt
 * a la primera mà de cada mode (la vista que rep el client).
 */
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { after, before, describe, it } from "node:test";
import type { Card } from "../src/gameTypes.ts";
import { recordHandStatsFromSettlement } from "../server/handStatsRecorder.ts";
import {
  flushPlayerStatsWritesForTests,
  getPlayerStats,
  resetPlayerStatsCacheForTests,
} from "../server/playerStats.ts";
import { ENGINE_MESSAGES } from "./gameMessages.ts";
import {
  applyDouble,
  applyHit,
  applyPlaceBet,
  applySplit,
  applyStand,
  beginGameStart,
  canSplitNow,
  clearRoomTimers,
  emptyRoomBase,
  isSplittablePair,
  publishRoom,
  roomToView,
  settleGame,
  strategyContextFor,
  type GameHost,
  type HandSlot,
  type Player,
  type Room,
} from "./gameEngine.ts";
import { createManualClockHost } from "./testing/manualClockHost.ts";

process.env.SETIMIG_TEST_FAST = "1";

const BET = 100;
const START = 2_000;

function card(value: number, suit: Card["suit"] = "hearts"): Card {
  return { suit, value, points: value >= 10 ? 0.5 : value };
}

function slot(values: number[], extra: Partial<HandSlot> = {}): HandSlot {
  return {
    id: `s${Math.random()}`,
    bet: BET,
    cards: values.map((value, i) => ({
      id: `c${i}-${value}`,
      card: card(value, i === 0 ? "spades" : "clubs"),
      faceUp: i > 0,
    })),
    doubled: false,
    canDouble: false,
    mort: false,
    blindPair: false,
    blindUntilBankEnd: false,
    mortOffered: false,
    status: "playing",
    ...extra,
  };
}

function seat(id: string, extra: Partial<Player> = {}): Player {
  return {
    id,
    playerId: id,
    seatToken: id,
    name: id,
    chips: START,
    bet: 0,
    isBanker: false,
    status: "waiting",
    handSlots: [],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
    ...extra,
  };
}

type Mode = {
  name: string;
  soloAi?: boolean;
  isPrivate?: boolean;
  practiceMode?: boolean;
  fastTournament?: boolean;
  botActs?: boolean;
};

const MODES: Mode[] = [
  { name: "multijugador" },
  { name: "sala privada", isPrivate: true },
  { name: "SOLO", soloAi: true },
  { name: "pràctica", soloAi: true, practiceMode: true },
  { name: "torneig", soloAi: true, fastTournament: true },
  { name: "bots", soloAi: true, botActs: true },
];

/** Primera mà real (banca ja assignada, mans completades 0): carta inicial + demanar. */
function openingPair(mode: Mode, first: number, second: number) {
  const room = emptyRoomBase(`obertura-${mode.name}`, mode.name, BET, 0);
  room.houseRulesEnabled = true;
  room.soloAi = mode.soloAi;
  room.isPrivate = mode.isPrivate;
  room.practiceMode = mode.practiceMode;
  room.fastTournament = mode.fastTournament;
  const structured = !!(mode.soloAi || mode.isPrivate);
  if (structured) {
    room.phaseB = { handsTotal: 10, handsCompleted: 0, chipPool: 10_000, startingChips: START };
  }
  // pop(): primera de l'actor, carta de la banca, carta de demanar.
  room.deck = [card(second, "clubs"), card(4, "diamonds"), card(first, "spades")];
  const bank = seat("bank", { isBanker: true, chips: 50_000, status: "waiting" });
  const actor = seat(mode.botActs ? "bot-actor" : "edu", {
    isBot: !!mode.botActs,
    chips: START,
    status: "waiting",
  });
  room.players = [bank, actor];
  const host = createManualClockHost().host;
  beginGameStart(host, room);
  assert.equal(room.phase, "betting", `${mode.name}: no ha obert les apostes`);
  assert.equal(applyPlaceBet(room, actor, BET), null);
  assert.equal(room.phase, "playing", `${mode.name}: no ha repartit`);
  assert.equal(actor.handSlots[0]!.cards.length, 1);
  assert.equal(actor.handSlots[0]!.cards[0]!.faceUp, false);
  assert.equal(canSplitNow(room, actor), false, "amb una sola carta no es separa");
  assert.equal(applyHit(host, room, actor.id), null);
  clearRoomTimers(host, room);
  return { room, actor, host, structured };
}

describe("primera mà: canSplit per a qualsevol parella de mig punt", () => {
  for (const mode of MODES) {
    it(`${mode.name}: sota, cavall i rei, en qualsevol ordre, i la primera carta encara tapada`, () => {
      for (const first of [10, 11, 12]) {
        for (const second of [10, 11, 12]) {
          const { room, actor, host, structured } = openingPair(mode, first, second);
          const hand = actor.handSlots[0]!;
          assert.deepEqual(
            hand.cards.map((c) => c.card.value),
            [first, second],
            `${mode.name} ${first}+${second}`,
          );
          assert.equal(hand.cards[0]!.faceUp, false);
          assert.equal(hand.cards[1]!.faceUp, true);
          assert.equal(isSplittablePair(hand.cards.map((c) => c.card)), true);
          assert.equal(canSplitNow(room, actor), true);
          const view = roomToView(room, actor.id, host);
          const me = view.players.find((p) => p.id === actor.id)!;
          assert.equal(me.pendingChoices?.canSplit, true, `${mode.name} ${first}+${second}`);
          assert.equal(me.activeSlotIndex, 0);
          assert.equal(me.handSlots.length, 1);
          assert.equal(me.handSlots[0]!.bet, BET);
          assert.equal(me.handSlots[0]!.doubled, false);
          assert.equal(me.handSlots[0]!.status, "playing");
          if (structured) assert.equal(view.matchProgress?.handNumber, 1);
          else assert.equal(view.matchProgress, null);
          if (mode.botActs) assert.equal(strategyContextFor(room, actor).canSplit, true);
          clearRoomTimers(host, room);
        }
      }
    });
  }

  it("multijugador: el segon seient, a la mà 1, també rep canSplit amb sota+rei", () => {
    const room = emptyRoomBase("segon", "Taula", BET, 0);
    room.houseRulesEnabled = true;
    room.phase = "betting";
    room.deck = [card(12, "hearts"), card(2, "clubs"), card(10, "spades"), card(5, "diamonds")];
    const bank = seat("bank", { isBanker: true, chips: 50_000, status: "waiting" });
    const first = seat("pau", { chips: START, status: "waiting" });
    const second = seat("edu", { chips: START, status: "waiting" });
    room.players = [bank, first, second];
    const host = createManualClockHost().host;
    assert.equal(applyPlaceBet(room, first, BET), null);
    assert.equal(room.phase, "betting");
    assert.equal(applyPlaceBet(room, second, BET), null);
    assert.equal(room.phase, "playing");
    assert.equal(applyStand(host, room, first.id), null);
    assert.equal(currentTurn(room), second.id);
    assert.equal(applyHit(host, room, second.id), null);
    const view = roomToView(room, second.id, host).players.find((p) => p.id === second.id)!;
    assert.deepEqual(
      view.handSlots[0]!.cards.map((c) => c.card?.value),
      [10, 12],
    );
    assert.equal(view.pendingChoices?.canSplit, true);
    clearRoomTimers(host, room);
  });

  it("una parella de números i el mode Tradicional no envien canSplit", () => {
    const off = openingPair({ name: "tradicional" }, 12, 10);
    off.room.houseRulesEnabled = false;
    assert.equal(canSplitNow(off.room, off.actor), false);
    const offPending = roomToView(off.room, off.actor.id, off.host).players.find((p) => p.id === off.actor.id)
      ?.pendingChoices;
    assert.equal(offPending?.canSplit, undefined);
    assert.equal(offPending?.splitBlocked, undefined);
    clearRoomTimers(off.host, off.room);

    const numbers = openingPair(MODES[0]!, 2, 3);
    assert.equal(canSplitNow(numbers.room, numbers.actor), false);
    const numPending = roomToView(numbers.room, numbers.actor.id, numbers.host).players.find(
      (p) => p.id === numbers.actor.id,
    )?.pendingChoices;
    assert.equal(numPending?.canSplit, undefined);
    assert.equal(numPending?.splitBlocked, undefined);
    clearRoomTimers(numbers.host, numbers.room);
  });
});

function currentTurn(room: Room): string | undefined {
  return room.players.filter((p) => !p.isBanker)[room.turnPlayerIndex]?.id;
}

function playing(hand: HandSlot, deck: number[]): { room: Room; player: Player; bank: Player; host: GameHost } {
  const room = emptyRoomBase("resplit", "Re", BET, 0);
  room.houseRulesEnabled = true;
  room.phase = "playing";
  room.deck = deck.map((value, i) => card(value, (["hearts", "diamonds", "clubs", "spades"] as const)[i % 4]!));
  const bank = seat("bank", { isBanker: true, chips: 50_000, bet: 0, status: "waiting", handSlots: [] });
  const player = seat("edu", {
    chips: START - BET,
    bet: BET,
    status: "playing",
    handSlots: [hand],
  });
  room.players = [bank, player];
  room.turnPlayerIndex = 0;
  room.pot = BET;
  room.roundStartChips = new Map([
    ["bank", bank.chips],
    ["edu", START],
  ]);
  const host = createManualClockHost().host;
  return { room, player, bank, host };
}

describe("re-split fins a 3 mans", () => {
  it("S, R i una altra R: tres mans, cada una amb la seva aposta, i liquidació de les tres", () => {
    // pop: 12 (segona de la mà 1, torna a ser parella), 6, 4, 3.
    const { room, player, bank, host } = playing(slot([10, 12]), [3, 4, 6, 12]);
    assert.equal(applySplit(room, player.id), null);
    assert.equal(player.handSlots.length, 2);
    assert.equal(player.chips, START - BET * 2);
    assert.deepEqual(
      player.handSlots[0]!.cards.map((c) => c.card.value),
      [10, 12],
    );
    assert.equal(player.handSlots.every((h) => h.cards.length === 2), true);
    assert.equal(roomToView(room, player.id, host).players.find((p) => p.id === player.id)?.pendingChoices?.canSplit, true);

    assert.equal(applySplit(room, player.id), null);
    assert.equal(player.handSlots.length, 3);
    assert.equal(player.activeSlotIndex, 0);
    assert.deepEqual(
      player.handSlots.map((h) => h.cards.map((c) => c.card.value)),
      [
        [10, 4],
        [12, 3],
        [12, 6],
      ],
    );
    assert.deepEqual(
      player.handSlots.map((h) => h.bet),
      [BET, BET, BET],
    );
    assert.equal(player.handSlots.every((h) => h.doubled === false), true);
    assert.equal(player.bet, BET * 3);
    assert.equal(player.chips, START - BET * 3);
    assert.equal(room.pot, BET * 3);

    assert.equal(applyStand(host, room, player.id), null);
    assert.equal(player.activeSlotIndex, 1);
    assert.equal(applyStand(host, room, player.id), null);
    assert.equal(player.activeSlotIndex, 2);
    assert.equal(applyStand(host, room, player.id), null);

    bank.handSlots = [slot([2], { bet: 0, status: "stood" })];
    room.phase = "banker";
    settleGame(host, room);
    const wins = room.lastRound!.highlights.filter((h) => h.params?.seatId === player.id);
    assert.deepEqual(
      wins.map((h) => [h.code, (h.params as { hand: number }).hand]),
      [
        ["win", 0],
        ["win", 1],
        ["win", 2],
      ],
    );
    const seatView = room.lastSettlement!.seats.find((s) => s.playerId === player.id)!;
    assert.equal(seatView.slots.length, 3);
    assert.deepEqual(
      seatView.slots.map((s) => s.bet),
      [BET, BET, BET],
    );
    assert.equal(player.chips - START, BET * 3, "+100 per cada mà");
    clearRoomTimers(host, room);
  });

  it("després de 3 mans, una parella de la mà activa es torna a separar", () => {
    const { room, player } = playing(slot([10, 12]), [3, 4, 6, 12, 5, 11]);
    assert.equal(applySplit(room, player.id), null);
    assert.equal(applySplit(room, player.id), null);
    assert.equal(player.handSlots.length, 3);
    player.handSlots[0]!.cards = [
      { id: "a", card: card(10, "hearts"), faceUp: true },
      { id: "b", card: card(12, "spades"), faceUp: true },
    ];
    assert.equal(applySplit(room, player.id), null);
    assert.equal(player.handSlots.length, 4);
    assert.equal(player.handSlots.every((h) => h.canDouble === false && h.fromSplit === true), true);
  });

  it("sense saldo per a l'aposta de la mà nova, canSplit és false", () => {
    const { room, player, host } = playing(slot([10, 12]), [12]);
    player.chips = BET;
    assert.equal(canSplitNow(room, player), true);
    assert.equal(applySplit(room, player.id), null);
    assert.equal(player.chips, 0);
    player.handSlots[0]!.cards[1] = { id: "r2", card: card(12, "hearts"), faceUp: true };
    assert.equal(canSplitNow(room, player), false);
    assert.notEqual(
      roomToView(room, player.id, host).players.find((p) => p.id === player.id)?.pendingChoices?.canSplit,
      true,
    );
    assert.equal(applySplit(room, player.id), ENGINE_MESSAGES.noChipsSplit);
    assert.equal(player.handSlots.length, 2);
    assert.equal(player.chips, 0);
  });

  it("separar després de doblar, i tornar a separar, copia l'aposta doblada a cada mà", () => {
    const { room, player, host } = playing(slot([12], { canDouble: true }), [3, 4, 6, 11, 10]);
    assert.equal(applyDouble(host, room, player.id), null);
    assert.equal(player.handSlots[0]!.doubled, true);
    assert.equal(player.handSlots[0]!.bet, BET * 2);
    assert.equal(roomToView(room, player.id, host).players.find((p) => p.id === player.id)?.pendingChoices?.canSplit, true);
    assert.equal(applySplit(room, player.id), null);
    assert.equal(player.handSlots[0]!.cards.map((c) => c.card.value).join(","), "12,11");
    assert.equal(applySplit(room, player.id), null);
    assert.equal(player.handSlots.length, 3);
    assert.deepEqual(
      player.handSlots.map((h) => ({ bet: h.bet, doubled: h.doubled, canDouble: h.canDouble, n: h.cards.length })),
      [
        { bet: BET * 2, doubled: false, canDouble: false, n: 2 },
        { bet: BET * 2, doubled: false, canDouble: false, n: 2 },
        { bet: BET * 2, doubled: false, canDouble: false, n: 2 },
      ],
    );
    assert.equal(player.bet, BET * 6);
    assert.equal(player.chips, START - BET * 6);
    clearRoomTimers(host, room);
  });

  it("cada mà té el seu termini: en expirar es planta només la mà activa i passa a la següent", () => {
    const prev = process.env.SETIMIG_TEST_FAST;
    process.env.SETIMIG_TEST_FAST = "1";
    const clock = createManualClockHost({ syncDateNow: true });
    try {
      const room = emptyRoomBase("temps", "Temps", BET, 0);
      room.houseRulesEnabled = true;
      room.phase = "playing";
      room.deck = [card(2), card(3), card(4), card(12)];
      const bank = seat("bank", { isBanker: true, chips: 50_000, bet: 0, status: "waiting" });
      const player = seat("edu", {
        chips: START - BET,
        bet: BET,
        status: "playing",
        handSlots: [slot([10, 12])],
      });
      room.players = [bank, player];
      room.turnPlayerIndex = 0;
      room.pot = BET;
      void publishRoom(clock.host, room);
      const firstDeadline = room.turnDeadlineAt!;
      assert.ok(firstDeadline > Date.now());

      assert.equal(applySplit(room, player.id), null);
      assert.equal(applySplit(room, player.id), null);
      assert.equal(player.handSlots.length, 3);
      void publishRoom(clock.host, room);
      const onFirstHand = room.turnDeadlineAt!;
      assert.ok(onFirstHand >= firstDeadline);
      assert.equal(player.activeSlotIndex, 0);

      clock.advance(onFirstHand - Date.now());
      assert.equal(player.handSlots[0]!.status, "stood");
      assert.equal(player.activeSlotIndex, 1);
      const onSecondHand = room.turnDeadlineAt!;
      assert.ok(onSecondHand > onFirstHand);

      clock.advance(onSecondHand - Date.now());
      assert.equal(player.handSlots[1]!.status, "stood");
      assert.equal(player.activeSlotIndex, 2);
      const onThirdHand = room.turnDeadlineAt!;
      assert.ok(onThirdHand > onSecondHand);

      clock.advance(onThirdHand - Date.now());
      assert.equal(player.handSlots[2]!.status, "stood");
      assert.equal(room.phase, "banker");
      clearRoomTimers(clock.host, room);
    } finally {
      clock.restoreDateNow();
      if (prev === undefined) delete process.env.SETIMIG_TEST_FAST;
      else process.env.SETIMIG_TEST_FAST = prev;
    }
  });
});

function viewPending(room: Room, player: Player, host: GameHost) {
  return roomToView(room, player.id, host).players.find((p) => p.id === player.id)?.pendingChoices ?? null;
}

describe("splitBlocked: Separar desactivat amb motiu", () => {
  it("la banca que no cobreix envia bankCannotCoverSplit i cap canSplit", () => {
    const { room, player, host } = playing(slot([10, 12]), []);
    room.players[0]!.chips = 399;
    const pending = viewPending(room, player, host);
    assert.equal(pending?.splitBlocked, "bankCannotCoverSplit");
    assert.equal(pending?.canSplit, undefined);
    assert.equal(canSplitNow(room, player), false);
  });

  it("sense saldo envia notEnoughChips i cap canSplit", () => {
    const { room, player, host } = playing(slot([10, 12]), []);
    player.chips = BET - 1;
    const pending = viewPending(room, player, host);
    assert.equal(pending?.splitBlocked, "notEnoughChips");
    assert.equal(pending?.canSplit, undefined);
  });

  it("amb 3 mans i dues figures encara es pot separar: el codi maxHands ja no s'emet", () => {
    const { room, player, host } = playing(slot([10, 12]), [2, 3]);
    player.handSlots.push(slot([11], { status: "stood" }), slot([12], { status: "stood" }));
    const pending = viewPending(room, player, host);
    assert.equal(player.handSlots.length, 3);
    assert.equal(pending?.splitBlocked, undefined);
    assert.equal(pending?.canSplit, true);
    assert.equal(applySplit(room, player.id), null);
    assert.equal(player.handSlots.length, 4);
  });

  it("dues cartes de valor diferent que no són figures: ni canSplit ni splitBlocked", () => {
    const { room, player, host } = playing(slot([5, 6]), []);
    const pending = viewPending(room, player, host);
    assert.equal(pending?.canSplit, undefined);
    assert.equal(pending?.splitBlocked, undefined);
    assert.equal(pending == null || !("splitBlocked" in pending), true);
  });

  it("el cas normal envia canSplit i cap splitBlocked", () => {
    const { room, player, host } = playing(slot([10, 12]), []);
    const pending = viewPending(room, player, host);
    assert.ok(pending);
    assert.equal(pending.canSplit, true);
    assert.equal(pending.splitBlocked, undefined);
    assert.equal("splitBlocked" in pending, false);
  });

  it("la resta de codis: oferta de Mort, canvi del 3/4, mà cega i Mort", () => {
    const mortOffer = playing(slot([10, 12], { mortOffered: true }), []);
    assert.equal(viewPending(mortOffer.room, mortOffer.player, mortOffer.host)?.splitBlocked, "decideMortFirst");

    const swap = playing(slot([10, 12], { swapOffered: 4 }), []);
    assert.equal(viewPending(swap.room, swap.player, swap.host)?.splitBlocked, "decideSwapFirst");
    assert.equal(viewPending(swap.room, swap.player, swap.host)?.canSplit, undefined);

    const blind = playing(slot([10, 12], { blindPair: true }), []);
    assert.equal(viewPending(blind.room, blind.player, blind.host)?.splitBlocked, "blindPairLocked");

    const mort = playing(slot([10, 12], { mort: true }), []);
    assert.equal(viewPending(mort.room, mort.player, mort.host)?.splitBlocked, "mort");
    assert.equal(viewPending(mort.room, mort.player, mort.host)?.canSplit, undefined);
  });
});

describe("estadístiques: tres mans separades compten per separat", () => {
  let dir = "";
  before(async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), "setimig-resplit-stats-"));
    process.env.BALANCE_DATA_DIR = dir;
    resetPlayerStatsCacheForTests();
  });
  after(async () => {
    await flushPlayerStatsWritesForTests();
    resetPlayerStatsCacheForTests();
    await fs.rm(dir, { recursive: true, force: true });
    delete process.env.BALANCE_DATA_DIR;
  });

  it("el perfil desa una mà per slot (victòria, passada i derrota)", async () => {
    const id = "resplitstats00001";
    const room = emptyRoomBase("stats-3", "Stats", BET, 0);
    room.houseRulesEnabled = true;
    const bank = seat("bank", { isBanker: true, isBot: true, chips: 50_000 });
    const player = seat(id, { playerId: id, name: "Tres" });
    room.players = [bank, player];
    room.roundStartChips = new Map([
      ["bank", bank.chips],
      [id, player.chips],
    ]);
    player.chips -= BET * 3;
    player.bet = BET * 3;
    room.pot = BET * 3;
    player.handSlots = [
      slot([7, 3], { status: "busted" }),
      slot([6], { status: "stood" }),
      slot([4], { status: "stood" }),
    ];
    bank.handSlots = [slot([5], { bet: 0, status: "stood" })];
    room.phase = "banker";
    const host = createManualClockHost().host;
    settleGame(host, room);
    await recordHandStatsFromSettlement(room, room.lastRound?.results);
    await flushPlayerStatsWritesForTests();
    const stats = await getPlayerStats(id);
    assert.equal(stats.handsPlayed, 3);
    assert.equal(stats.passCount, 1);
    const file = await import("../server/playerStats.ts").then((m) => m.readPlayerStatsFileForTests(id));
    assert.equal(file.hands.length, 3);
    assert.deepEqual(
      file.hands.map((h) => h.finalPoints).sort((a, b) => a - b),
      [4, 6, 10],
    );
    clearRoomTimers(host, room);
  });
});
