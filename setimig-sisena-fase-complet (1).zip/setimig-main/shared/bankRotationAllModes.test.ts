/** Regles-decisió 26/10: rotació cada 3 mans i relleu per cobertura en TOTS els modes. */
import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { emptyRoomBase, finishSettlementToWaiting, type GameHost, type Player } from "./gameEngine.ts";
import { createSingleSpanishDeck } from "./spanishDeck.ts";
import * as spanishDeck from "./spanishDeck.ts";

const host: GameHost = {
  emitRoomUpdate() {},
  schedule: () => null as unknown as ReturnType<typeof setTimeout>,
  clearTimeout() {},
};

function p(id: string, chips: number, isBanker = false): Player {
  return {
    id,
    playerId: id,
    seatToken: id,
    name: id,
    chips,
    bet: 0,
    isBanker,
    status: "waiting",
    handSlots: [],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
  } as Player;
}

function classicRoom() {
  const room = emptyRoomBase("classic", "Clàssica", 100, 0);
  room.soloAi = false;
  room.isPrivate = false;
  room.players = [p("a", 50_000, true), p("b", 50_000), p("c", 50_000)];
  room.bankerConsecutiveHands = 0;
  return room;
}

const bankerId = (room: ReturnType<typeof classicRoom>) => room.players.find((x) => x.isBanker)?.id;

describe("banca en mode clàssic (sense fase B)", () => {
  it("3 mans amb la mateixa banca → a la 4a la banca és un altre jugador", () => {
    const room = classicRoom();
    assert.equal(room.phaseB, undefined);
    finishSettlementToWaiting(host, room);
    finishSettlementToWaiting(host, room);
    assert.equal(bankerId(room), "a");
    finishSettlementToWaiting(host, room);
    assert.notEqual(bankerId(room), "a");
    assert.equal(room.bankerConsecutiveHands, 0);
  });

  it("relleu per cobertura: si la banca no pot cobrir, passa al següent que pugui", () => {
    const room = classicRoom();
    room.players[0]!.chips = 10;
    finishSettlementToWaiting(host, room);
    assert.notEqual(bankerId(room), "a");
  });
});

describe("baralla", () => {
  it("una sola baralla de 40 cartes (4 per valor); sense createDoubleSpanishDeck", () => {
    const deck = createSingleSpanishDeck();
    assert.equal(deck.length, 40);
    const byValue = new Map<number, number>();
    for (const c of deck) byValue.set(c.value, (byValue.get(c.value) ?? 0) + 1);
    for (const n of byValue.values()) assert.equal(n, 4);
    assert.equal("createDoubleSpanishDeck" in spanishDeck, false);
  });
});
