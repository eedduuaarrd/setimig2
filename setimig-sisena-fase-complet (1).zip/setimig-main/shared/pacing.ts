/**
 * Ritme del servidor (una sola font). El client no l'importa: rep els valors
 * dins `room_update` / `joined_room` al camp `pacing`.
 *
 * `SETIMIG_TEST_FAST=1` col·lapsa les pauses noves a 0 (apostes, repartiment,
 * pagament i avís HIT/STAND) perquè la suite no s'alenteixi. Les constants
 * nominals i l'objecte `pacing` segueixen dient el valor configurat; els
 * terminis reals (`phaseEndsAt`, `actionHoldEndsAt`) sí que es col·lapsen.
 *
 * Cada constant es pot sobreescriure amb la variable d'entorn indicada:
 * enter ≥ 0 i ≤ 120_000. Un valor invàlid s'ignora.
 */
export const BOT_BET_GAP_MS = 700;
/** Després de l'última aposta, abans de repartir (el client en necessita 1300: 700 de vol + 600 del pot). */
export const BETS_SETTLE_MS = 1_800;
/** Cada carta del repartiment inicial, en seqüència. El primer torn espera cartes × aquest valor. */
export const DEAL_CARD_MS = 350;

/** Avís de «carta» (també si la mà es passa). Inclou el temps de sortida de l'avís. */
export const ACTION_HIT_HOLD_MS = 1_250;
/** Avís de «es planta». Inclou el temps de sortida de l'avís. */
export const ACTION_STAND_HOLD_MS = 1_850;

/** Revelació en gran (#339). Sense Mort: n×1500+3000. Amb Mort: 5200+(n−1)×1500+3000. */
export const REVEAL_PER_SEAT_MS = 1_500;
export const SETTLEMENT_VISIBLE_MS = 3_000;
export const MORT_REVEAL_SUSPENSE_MS = 5_200;
/** El full visible del Mort és el mateix que el de la resta. */
export const MORT_SETTLEMENT_VISIBLE_MS = SETTLEMENT_VISIBLE_MS;

/** Oferta de banca a un humà: `BANK_CHOICE_TIMEOUT_MS` + aquest marge = 6_400. */
export const BANK_CHOICE_TIMEOUT_MS = 6_000;
export const BANK_OFFER_EXTRA_MS = 400;
export const BANK_OFFER_FLOOR_MS = BANK_CHOICE_TIMEOUT_MS + BANK_OFFER_EXTRA_MS;

/**
 * Viatge de fitxes del pagament, després de la revelació i abans de la mà següent.
 * `PAYOUT_BANK_MS` + `PAYOUT_PER_SEAT_MS` × seients amb resultat (sense la banca) + `PAYOUT_COUNTER_MS`.
 * 1 seient → 2100, 3 → 3900, 4 → 4800.
 */
export const PAYOUT_BANK_MS = 400;
export const PAYOUT_PER_SEAT_MS = 650;
export const PAYOUT_COUNTER_MS = 600;

/** Finestra d'aposta humana. No es toca. */
export const BET_WINDOW_MS = 18_000;
/** Finestra de torn humà. No es toca. */
export const PLAY_WINDOW_MS = 22_000;

/** Pensada d'un bot entre accions de joc (no entre apostes: això és `BOT_BET_GAP_MS`). */
export const BOT_ACTION_MIN_MS = 1_200;
export const BOT_ACTION_MAX_MS = 1_500;
export const BOT_FIRST_ACTION_MS = 1_200;
/** Entre cartes de la banca bot. */
export const BANKER_DRAW_MS = 1_300;
/** Sorteig de la banca en començar una taula sense banquer. No el col·lapsa el mode ràpid. */
export const BANK_DRAW_MS = 1_800;
/** Torn de la banca humana, a més del de joc. */
export const BANKER_TIMEOUT_MS = 20_000;
/** Mínim que el full queda visible si tothom ha confirmat «Següent». */
export const SETTLEMENT_MIN_DISPLAY_MS = 1_500;
/** Entre el final de la liquidació i l'obertura de la mà següent. No el col·lapsa el mode ràpid. */
export const NEXT_HAND_START_MS = 600;
/** Espera abans de la primera mà en reprendre un solo. No la col·lapsa el mode ràpid. */
export const SOLO_START_DELAY_MS = 500;

/** Vol d'una carta demanada dins el torn (repart-v2). No és la pausa entre torns. */
export const DEAL_FLIGHT_MS = 300;
/** Stagger antic del repartiment inicial; el ritme nou és `DEAL_CARD_MS`. Es conserva per al vol dins el torn. */
export const DEAL_STAGGER_MS = 110;
/** Vol + gir d'una carta demanada: acaba a 360 ms. */
export const DEAL_FLIGHT_FLIP_MS = 360;
/** Passar-se dins el torn: vol + gir + sacsejada. */
export const DEAL_BUST_MS = 600;
export const DEAL_MAX_IN_TURN_MS = 600;
/** La banca destapa l'oculta en començar el seu torn. */
export const BANK_REVEAL_MS = 240;

/** El vigilant força un bot encallat. La pausa d'avís és molt més curta. */
export const BOT_TURN_WATCHDOG_MS = 12_000;

const MAX_OVERRIDE_MS = 120_000;

export function isTestFastPacing(): boolean {
  return typeof process !== "undefined" && process.env?.SETIMIG_TEST_FAST === "1";
}

/** Enter vàlid o el valor per defecte. No llança. */
export function configuredMs(fallback: number, envName: string): number {
  const raw = typeof process !== "undefined" ? process.env?.[envName] : undefined;
  if (raw == null || raw === "") return fallback;
  if (!/^\d+$/.test(raw)) return fallback;
  const n = Number(raw);
  if (!Number.isInteger(n) || n < 0 || n > MAX_OVERRIDE_MS) return fallback;
  return n;
}

/** Pausa real: 0 amb `SETIMIG_TEST_FAST`, si no el valor configurat. */
export function pacedMs(fallback: number, envName: string): number {
  if (isTestFastPacing()) return 0;
  return configuredMs(fallback, envName);
}

export function botBetGapMs(): number {
  return pacedMs(BOT_BET_GAP_MS, "SETIMIG_BOT_BET_GAP_MS");
}

export function betsSettleMs(): number {
  return pacedMs(BETS_SETTLE_MS, "SETIMIG_BETS_SETTLE_MS");
}

export function dealCardMs(): number {
  return pacedMs(DEAL_CARD_MS, "SETIMIG_DEAL_CARD_MS");
}

export function actionHitHoldMs(): number {
  return pacedMs(ACTION_HIT_HOLD_MS, "SETIMIG_ACTION_HIT_HOLD_MS");
}

export function actionStandHoldMs(): number {
  return pacedMs(ACTION_STAND_HOLD_MS, "SETIMIG_ACTION_STAND_HOLD_MS");
}

export function payoutChipsMs(seatsWithResult: number): number {
  const n = Math.max(0, Math.floor(Number.isFinite(seatsWithResult) ? seatsWithResult : 0));
  const bank = configuredMs(PAYOUT_BANK_MS, "SETIMIG_PAYOUT_BANK_MS");
  const per = configuredMs(PAYOUT_PER_SEAT_MS, "SETIMIG_PAYOUT_PER_SEAT_MS");
  const counter = configuredMs(PAYOUT_COUNTER_MS, "SETIMIG_PAYOUT_COUNTER_MS");
  return bank + per * n + counter;
}

export function settlementRevealWindowMs(n: number, mort: boolean): number {
  const seats = Math.max(0, n);
  const per = configuredMs(REVEAL_PER_SEAT_MS, "SETIMIG_REVEAL_PER_SEAT_MS");
  const visible = configuredMs(SETTLEMENT_VISIBLE_MS, "SETIMIG_SETTLEMENT_VISIBLE_MS");
  const suspense = configuredMs(MORT_REVEAL_SUSPENSE_MS, "SETIMIG_MORT_REVEAL_SUSPENSE_MS");
  if (mort) return suspense + Math.max(0, seats - 1) * per + visible;
  return seats * per + visible;
}

/** Valors nominals que viatgen al client (no col·lapsats pel mode de tests). */
export interface PacingContract {
  BOT_BET_GAP_MS: number;
  BETS_SETTLE_MS: number;
  DEAL_CARD_MS: number;
  ACTION_HIT_HOLD_MS: number;
  ACTION_STAND_HOLD_MS: number;
  REVEAL_PER_SEAT_MS: number;
  SETTLEMENT_VISIBLE_MS: number;
  MORT_REVEAL_SUSPENSE_MS: number;
  BANK_OFFER_FLOOR_MS: number;
  PAYOUT_BANK_MS: number;
  PAYOUT_PER_SEAT_MS: number;
  PAYOUT_COUNTER_MS: number;
  BET_WINDOW_MS: number;
  PLAY_WINDOW_MS: number;
  BOT_ACTION_MIN_MS: number;
  BOT_ACTION_MAX_MS: number;
  BOT_FIRST_ACTION_MS: number;
  BANKER_DRAW_MS: number;
  BANK_DRAW_MS: number;
  BANK_CHOICE_TIMEOUT_MS: number;
  BANKER_TIMEOUT_MS: number;
  NEXT_HAND_START_MS: number;
  SETTLEMENT_MIN_DISPLAY_MS: number;
  DEAL_FLIGHT_MS: number;
  DEAL_FLIGHT_FLIP_MS: number;
  DEAL_BUST_MS: number;
  BANK_REVEAL_MS: number;
  SOLO_START_DELAY_MS: number;
}

export function pacingContract(): PacingContract {
  return {
    BOT_BET_GAP_MS: configuredMs(BOT_BET_GAP_MS, "SETIMIG_BOT_BET_GAP_MS"),
    BETS_SETTLE_MS: configuredMs(BETS_SETTLE_MS, "SETIMIG_BETS_SETTLE_MS"),
    DEAL_CARD_MS: configuredMs(DEAL_CARD_MS, "SETIMIG_DEAL_CARD_MS"),
    ACTION_HIT_HOLD_MS: configuredMs(ACTION_HIT_HOLD_MS, "SETIMIG_ACTION_HIT_HOLD_MS"),
    ACTION_STAND_HOLD_MS: configuredMs(ACTION_STAND_HOLD_MS, "SETIMIG_ACTION_STAND_HOLD_MS"),
    REVEAL_PER_SEAT_MS: configuredMs(REVEAL_PER_SEAT_MS, "SETIMIG_REVEAL_PER_SEAT_MS"),
    SETTLEMENT_VISIBLE_MS: configuredMs(SETTLEMENT_VISIBLE_MS, "SETIMIG_SETTLEMENT_VISIBLE_MS"),
    MORT_REVEAL_SUSPENSE_MS: configuredMs(MORT_REVEAL_SUSPENSE_MS, "SETIMIG_MORT_REVEAL_SUSPENSE_MS"),
    BANK_OFFER_FLOOR_MS,
    PAYOUT_BANK_MS: configuredMs(PAYOUT_BANK_MS, "SETIMIG_PAYOUT_BANK_MS"),
    PAYOUT_PER_SEAT_MS: configuredMs(PAYOUT_PER_SEAT_MS, "SETIMIG_PAYOUT_PER_SEAT_MS"),
    PAYOUT_COUNTER_MS: configuredMs(PAYOUT_COUNTER_MS, "SETIMIG_PAYOUT_COUNTER_MS"),
    BET_WINDOW_MS,
    PLAY_WINDOW_MS,
    BOT_ACTION_MIN_MS,
    BOT_ACTION_MAX_MS,
    BOT_FIRST_ACTION_MS,
    BANKER_DRAW_MS,
    BANK_DRAW_MS,
    BANK_CHOICE_TIMEOUT_MS,
    BANKER_TIMEOUT_MS,
    NEXT_HAND_START_MS,
    SETTLEMENT_MIN_DISPLAY_MS,
    DEAL_FLIGHT_MS,
    DEAL_FLIGHT_FLIP_MS,
    DEAL_BUST_MS,
    BANK_REVEAL_MS,
    SOLO_START_DELAY_MS,
  };
}

function testFastDelay(): number {
  return 20 + Math.floor(Math.random() * 40);
}

/** Primera acció d'un bot quan li toca el torn (després de la pausa d'avís, si n'hi ha). */
export function botFirstActionDelayMs(): number {
  if (isTestFastPacing()) return testFastDelay();
  return BOT_FIRST_ACTION_MS;
}

/** Entre cartes de la banca quan la juga un bot. */
export function bankerBotActionDelayMs(): number {
  if (isTestFastPacing()) return testFastDelay();
  return BANKER_DRAW_MS;
}

export function soloSettlementAutoMs(): number {
  if (isTestFastPacing()) return 220;
  return 6_000;
}

export function defaultSettlementAutoMs(): number {
  if (isTestFastPacing()) return 280;
  return 6_500;
}
