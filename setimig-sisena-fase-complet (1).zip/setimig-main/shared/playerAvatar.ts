export const AVATAR_SYMBOL_IDS = [
  "spade",
  "heart",
  "diamond",
  "club",
  "seven",
  "half",
  "star",
  "leaf",
] as const;

export type AvatarSymbolId = (typeof AVATAR_SYMBOL_IDS)[number];

export const AVATAR_SYMBOL_GLYPH: Record<AvatarSymbolId, string> = {
  spade: "♠",
  heart: "♥",
  diamond: "♦",
  club: "♣",
  seven: "7",
  half: "½",
  star: "★",
  leaf: "✦",
};

/**
 * Paleta d'avatars (estil negre, marfil i or). Els verds antics (emerald, teal, moss)
 * s'han retirat: cada un ocupa el mateix índex que el seu substitut, de manera que el
 * color per defecte derivat de l'id només canvia per a qui abans el tenia verd.
 */
export const AVATAR_COLOR_IDS = [
  "gold",
  "amber",
  "indigo",
  "slate",
  "rose",
  "onyx",
  "wine",
  "ivory",
] as const;

export type AvatarColorId = (typeof AVATAR_COLOR_IDS)[number];

/** Colors retirats que poden quedar en perfils o seients desats; es llegeixen com el substitut. */
export const LEGACY_AVATAR_COLOR_MAP = {
  emerald: "gold",
  teal: "onyx",
  moss: "ivory",
} as const satisfies Record<string, AvatarColorId>;

export type LegacyAvatarColorId = keyof typeof LEGACY_AVATAR_COLOR_MAP;

function isLegacyAvatarColorId(value: unknown): value is LegacyAvatarColorId {
  return typeof value === "string" && Object.prototype.hasOwnProperty.call(LEGACY_AVATAR_COLOR_MAP, value);
}

/** Color vàlid de la paleta actual, o el substitut d'un color retirat; null si és desconegut. */
export function migrateAvatarColor(value: unknown): AvatarColorId | null {
  if (isAvatarColorId(value)) return value;
  if (isLegacyAvatarColorId(value)) return LEGACY_AVATAR_COLOR_MAP[value];
  return null;
}

export type PlayerAvatarConfig =
  | { kind: "initials"; initials: string; color: AvatarColorId }
  | { kind: "symbol"; symbol: AvatarSymbolId; color: AvatarColorId };

export type PlayerAvatarView = {
  kind: PlayerAvatarConfig["kind"];
  label: string;
  color: AvatarColorId;
};

const INITIALS_RE = /^[\p{L}\p{N}]{1,2}$/u;

export function deriveInitialsFromName(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "J";
  if (parts.length === 1) {
    const letters = parts[0].replace(/[^\p{L}\p{N}]/gu, "");
    const slice = letters.slice(0, 2);
    return (slice || "J").toUpperCase();
  }
  const fromWords = parts
    .slice(0, 2)
    .map((part) => part.replace(/[^\p{L}\p{N}]/gu, "")[0] ?? "")
    .join("");
  return (fromWords.slice(0, 2) || "J").toUpperCase();
}

export function defaultAvatarColor(seed: string): AvatarColorId {
  const total = Array.from(seed).reduce((sum, char) => sum + char.charCodeAt(0), 0);
  return AVATAR_COLOR_IDS[total % AVATAR_COLOR_IDS.length];
}

export function defaultAvatarConfig(displayName: string, playerId: string): PlayerAvatarConfig {
  return {
    kind: "initials",
    initials: deriveInitialsFromName(displayName),
    color: defaultAvatarColor(playerId || displayName),
  };
}

function isAvatarColorId(value: unknown): value is AvatarColorId {
  return typeof value === "string" && (AVATAR_COLOR_IDS as readonly string[]).includes(value);
}

function isAvatarSymbolId(value: unknown): value is AvatarSymbolId {
  return typeof value === "string" && (AVATAR_SYMBOL_IDS as readonly string[]).includes(value);
}

function normalizeInitials(value: unknown, displayName: string): string | null {
  if (value === undefined || value === null || value === "") {
    return deriveInitialsFromName(displayName);
  }
  if (typeof value !== "string") return null;
  const trimmed = value.trim();
  if (!INITIALS_RE.test(trimmed)) return null;
  return trimmed.toUpperCase();
}

/** Strict validation for profile writes; returns null when the patch is invalid. */
export function parseAvatarPatch(
  raw: unknown,
  displayName: string
): PlayerAvatarConfig | null | "clear" {
  if (raw === null) return "clear";
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return null;
  const record = raw as Record<string, unknown>;
  const kind = record.kind;
  const color = record.color;
  if (!isAvatarColorId(color)) return null;

  if (kind === "symbol") {
    if (!isAvatarSymbolId(record.symbol)) return null;
    return { kind: "symbol", symbol: record.symbol, color };
  }
  if (kind === "initials") {
    const initials = normalizeInitials(record.initials, displayName);
    if (!initials) return null;
    return { kind: "initials", initials, color };
  }
  return null;
}

/**
 * Lectura de dades desades: com `parseAvatarPatch`, però accepta els colors retirats
 * i els tradueix al substitut (no trenca mai un perfil antic).
 */
export function parseStoredAvatar(
  raw: unknown,
  displayName: string
): PlayerAvatarConfig | null | "clear" {
  if (raw && typeof raw === "object" && !Array.isArray(raw)) {
    const record = raw as Record<string, unknown>;
    if (isLegacyAvatarColorId(record.color)) {
      return parseAvatarPatch({ ...record, color: LEGACY_AVATAR_COLOR_MAP[record.color] }, displayName);
    }
  }
  return parseAvatarPatch(raw, displayName);
}

/** Lenient read from disk: invalid fragments fall back to defaults. */
export function normalizeStoredAvatar(
  raw: unknown,
  displayName: string,
  playerId: string
): PlayerAvatarConfig {
  const parsed = parseStoredAvatar(raw, displayName);
  if (parsed === null || parsed === "clear") {
    return defaultAvatarConfig(displayName, playerId);
  }
  return parsed;
}

export function resolveProfileAvatar(
  stored: unknown,
  displayName: string,
  playerId: string
): PlayerAvatarConfig {
  if (stored === undefined || stored === null) {
    return defaultAvatarConfig(displayName, playerId);
  }
  return normalizeStoredAvatar(stored, displayName, playerId);
}

export function toPlayerAvatarView(config: PlayerAvatarConfig): PlayerAvatarView {
  // Seients persistits abans del canvi de paleta poden portar un color retirat.
  const color = migrateAvatarColor(config.color) ?? AVATAR_COLOR_IDS[0];
  if (config.kind === "symbol") {
    return { kind: "symbol", color, label: AVATAR_SYMBOL_GLYPH[config.symbol] };
  }
  return { kind: "initials", color, label: config.initials };
}
