/**
 * El detail per mà de lastRound és el net (guany − aposta d'aquella mà, doble inclòs).
 * La suma dels nets és el chipDelta. Després de separar, sota + 7 no és natural.
 */
import { describe, it } from "node:test";
import assert from "node:assert/strict";
import type { Card } from "../src/gameTypes.ts";
import {
  applyDouble,
  applyHit,
  applyPlaceBet,
  applySplit,
  applyStand,
  beginGameStart,
  emptyRoomBase,
  roomToView,
  settleGame,
  type GameHost,
  type HandSlot,
  type Player,
  type Room,
} from "./gameEngine.ts";
import { scoreCards } from "./scoring.ts";
import { resetPrivateSeededDeckWarningsForTests } from "./testSeededDeck.ts";

const host: GameHost = {
  emitRoomUpdate() {},
  schedule: () => 0 as unknown as ReturnType<typeof setTimeout>,
  clearTimeout() {},
};

function card(value: number, suit: Card["suit"] = "hearts"): Card {
  return { suit, value, points: value >= 10 ? 0.5 : value };
}

function slot(cards: Card[], bet: number, status: HandSlot["status"], extra: Partial<HandSlot> = {}): HandSlot {
  return {
    id: `s-${Math.random().toString(36).slice(2)}`,
    cards: cards.map((c, i) => ({ id: `c-${i}-${Math.random().toString(36).slice(2)}`, card: c, faceUp: true })),
    bet,
    doubled: false,
    canDouble: false,
    mort: false,
    blindPair: false,
    blindUntilBankEnd: false,
    mortOffered: false,
    status,
    ...extra,
  };
}

function seat(id: string, name: string, extra: Partial<Player> = {}): Player {
  return {
    id,
    playerId: `pid-${id}`,
    seatToken: `tok-${id}`,
    name,
    chips: 1_000,
    bet: 0,
    isBanker: false,
    status: "stood",
    handSlots: [],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
    ...extra,
  };
}

function roomWith(banker: Player, players: Player[], extra: Partial<Room> = {}): Room {
  const room = emptyRoomBase(`neta-${Math.random().toString(36).slice(2)}`, "Neta", 100, extra.jackpot ?? 0);
  room.players = [banker, ...players];
  room.pot = players.reduce((sum, p) => sum + p.handSlots.reduce((a, sl) => a + sl.bet, 0), 0);
  room.phase = "banker";
  room.roundStartChips = new Map(
    room.players.map((p) => [p.playerId, p.chips + (p.isBanker ? 0 : p.handSlots.reduce((a, sl) => a + sl.bet, 0))])
  );
  Object.assign(room, extra);
  if (extra.pot != null) room.pot = extra.pot;
  room.roundStartJackpot = room.jackpot;
  return room;
}

function handAmount(params: { amount?: number } | undefined): number | undefined {
  return typeof params?.amount === "number" ? params.amount : undefined;
}

/** Suma dels nets: l'import del highlight, o −aposta si la mà no en porta (pèrdua). */
function sumHandNets(player: Player, room: Room): number {
  let sum = 0;
  for (const h of room.lastRound?.highlights ?? []) {
    if (h.params?.seatId !== player.id) continue;
    const bet = player.handSlots[h.params.hand]?.bet ?? 0;
    const amount = handAmount(h.params as { amount?: number });
    sum += amount ?? -bet;
  }
  return sum;
}

function assertNetsMatchTotal(room: Room) {
  for (const p of room.players) {
    if (p.isBanker) continue;
    const line = room.lastRound?.results?.find((r) => r.params?.seatId === p.id);
    if (!line) continue;
    assert.equal(sumHandNets(p, room), line.chipDelta, `${p.name}: suma per mà = chipDelta`);
    assert.equal(line.detail.includes("CF"), false, line.detail);
    assert.doesNotMatch(line.detail, /\d[.,]\d{3}/, line.detail);
    for (const h of room.lastRound?.highlights ?? []) {
      if (h.params?.seatId !== p.id) continue;
      const amount = handAmount(h.params as { amount?: number });
      if (amount == null) continue;
      assert.equal(Number.isInteger(amount), true, `${p.name} import enter`);
      assert.match(h.text, amount < 0 ? /-\d+/ : /\+\d+/);
      assert.equal(h.text.includes("CF"), false);
    }
  }
}

function bank(cards: number[], status: HandSlot["status"] = "stood"): Player {
  return seat("b", "Banca", {
    isBanker: true,
    chips: 5_000,
    handSlots: [slot(cards.map((v) => card(v, "clubs")), 0, status)],
  });
}

describe("liquidació: el net per mà suma el total", () => {
  it("victòria normal, banca passada, Mort, 3 canviat i doblar", () => {
    const normal = seat("n", "Normal", { handSlots: [slot([card(6)], 100, "stood")] });
    const bustedBank = roomWith(bank([6, 5], "busted"), [seat("p", "Passada", { handSlots: [slot([card(5)], 100, "stood")] })]);
    settleGame(host, bustedBank);
    assertNetsMatchTotal(bustedBank);
    const bustLine = bustedBank.lastRound!.highlights.find((h) => h.name === "Passada")!;
    assert.equal(bustLine.code, "winBankBust");
    assert.equal(handAmount(bustLine.params as { amount?: number }), 100);
    assert.equal(bustLine.text, "+100 (banca passada)");

    const plain = roomWith(bank([4]), [normal]);
    settleGame(host, plain);
    assertNetsMatchTotal(plain);
    const plainLine = plain.lastRound!.highlights.find((h) => h.name === "Normal")!;
    assert.equal(plainLine.code, "win");
    assert.equal(handAmount(plainLine.params as { amount?: number }), 100);
    assert.equal(plainLine.text, "+100");

    const mort = seat("m", "Mort", {
      handSlots: [slot([card(7), card(10, "diamonds")], 100, "stood", { mort: true })],
    });
    const mortRoom = roomWith(bank([4]), [mort]);
    settleGame(host, mortRoom);
    assertNetsMatchTotal(mortRoom);
    const mortLine = mortRoom.lastRound!.highlights.find((h) => h.name === "Mort")!;
    assert.equal(mortLine.code, "specialWin");
    assert.equal(handAmount(mortLine.params as { amount?: number }), 200);
    assert.equal(mortLine.text, "Mort ×2 — +200");

    const swap = seat("c", "Canvi", {
      handSlots: [slot([card(4), card(2, "spades")], 100, "stood", { blindPair: true })],
    });
    const swapRoom = roomWith(bank([3]), [swap]);
    settleGame(host, swapRoom);
    assertNetsMatchTotal(swapRoom);
    const swapLine = swapRoom.lastRound!.highlights.find((h) => h.name === "Canvi")!;
    assert.equal(swapLine.code, "specialWin");
    assert.equal(handAmount(swapLine.params as { amount?: number }), 200);
    assert.equal(swapLine.text, "3 canviat ×2 — +200");

    const doubled = seat("d", "Doble", {
      handSlots: [slot([card(6, "spades")], 200, "stood", { doubled: true })],
    });
    const doubleRoom = roomWith(bank([4, 1]), [doubled]);
    settleGame(host, doubleRoom);
    assertNetsMatchTotal(doubleRoom);
    const doubleLine = doubleRoom.lastRound!.highlights.find((h) => h.name === "Doble")!;
    assert.equal(handAmount(doubleLine.params as { amount?: number }), 200);
    assert.equal(doubleRoom.lastRound!.results!.find((r) => r.name === "Doble")!.chipDelta, 200);
  });

  it("una mà guanyada i una de perduda: els nets, amb el −aposta de la pèrdua, sumen el total", () => {
    const split = seat("s", "Split", {
      handSlots: [
        slot([card(6), card(5, "spades")], 100, "busted"),
        slot([card(7, "diamonds")], 100, "stood"),
      ],
    });
    const room = roomWith(bank([5]), [split]);
    settleGame(host, room);
    assertNetsMatchTotal(room);
    const line = room.lastRound!.results!.find((r) => r.name === "Split")!;
    assert.equal(line.chipDelta, 0);
    assert.equal(line.detail, "Passat · +100");
    const win = room.lastRound!.highlights.find((h) => h.name === "Split" && h.code === "win")!;
    assert.equal(handAmount(win.params as { amount?: number }), 100);
  });
});

describe("després de separar, sota + 7 és un 7½ normal", () => {
  function sotaSet(bet = 100): HandSlot {
    return slot([card(10, "diamonds"), card(7, "diamonds")], bet, "stood");
  }

  it("sense separar, sota + 7 de sortida continua sent natural i paga 2×", () => {
    for (const soloAi of [false, true]) {
      const player = seat("p", "Sol", { handSlots: [sotaSet()] });
      const room = roomWith(bank([4]), [player], { soloAi, jackpot: 0 });
      settleGame(host, room);
      assertNetsMatchTotal(room);
      const h = room.lastRound!.highlights.find((x) => x.name === "Sol")!;
      assert.equal(h.code, "naturalWin");
      assert.equal(handAmount(h.params as { amount?: number }), 200);
      assert.match(h.text, /natural/);
      assert.equal(room.lastSettlement!.seats.find((s) => s.name === "Sol")!.slots[0]!.natural, true);
      assert.equal(room.lastRound!.results!.find((r) => r.name === "Sol")!.chipDelta, 200);
      const view = JSON.stringify(roomToView(room, "p", host));
      assert.equal(view.includes("naturalWin"), true);
    }
  });

  it("separat, sota + 7 paga 1×, es compara com un 7½ normal i no s'etiqueta natural", () => {
    for (const soloAi of [false, true]) {
      const player = seat("p", "Sep", {
        handSlots: [sotaSet(), slot([card(5, "spades")], 100, "stood")],
      });
      const room = roomWith(bank([4]), [player], { soloAi, jackpot: 400, pot: 600 });
      const jackpotBefore = room.jackpot;
      settleGame(host, room);
      assertNetsMatchTotal(room);
      const hands = room.lastRound!.highlights.filter((h) => h.name === "Sep");
      assert.deepEqual(
        hands.map((h) => [h.code, handAmount(h.params as { amount?: number })]),
        [
          ["win", 100],
          ["win", 100],
        ]
      );
      const detail = room.lastRound!.results!.find((r) => r.name === "Sep")!.detail;
      assert.equal(detail, "+100 · +100");
      assert.equal(detail.toLowerCase().includes("natural"), false);
      assert.equal(hands.some((h) => h.code === "naturalWin" || h.text.toLowerCase().includes("natural")), false);
      const slots = room.lastSettlement!.seats.find((s) => s.name === "Sep")!.slots;
      assert.equal(slots[0]!.points, 7.5);
      assert.equal(slots[0]!.natural, false);
      assert.equal(slots[1]!.natural, false);
      assert.equal(room.jackpot, jackpotBefore, "un 7½ separat no es queda el jackpot");
      assert.equal(room.lastRound!.results!.find((r) => r.name === "Sep")!.chipDelta, 200);
      const view = JSON.stringify(roomToView(room, "p", host));
      assert.equal(view.includes("naturalWin"), false);
      assert.equal(view.includes("7 i Mig natural"), false);
    }
  });

  it("separat contra una banca amb 7½, perd com qualsevol 7½ i no com a natural", () => {
    const player = seat("p", "Sep", {
      handSlots: [sotaSet(), slot([card(6)], 100, "stood")],
    });
    const room = roomWith(bank([7, 10]), [player], { jackpot: 250 });
    settleGame(host, room);
    assertNetsMatchTotal(room);
    const hands = room.lastRound!.highlights.filter((h) => h.name === "Sep");
    assert.deepEqual(hands.map((h) => h.code), ["tieSevenHalfBank", "bankWins"]);
    assert.equal(hands.some((h) => h.text.toLowerCase().includes("natural")), false);
    assert.equal(room.lastSettlement!.seats.find((s) => s.name === "Sep")!.slots[0]!.natural, false);
    assert.equal(room.jackpot, 250);
    assert.equal(room.lastRound!.results!.find((r) => r.name === "Sep")!.chipDelta, -200);
  });
});

describe("llavor 3: doblar, separar i banca passada", () => {
  it("cada mà mostra el net i la suma és el total, sense dir natural", () => {
    const prev = {
      flag: process.env.SETIMIG_TEST_SEEDED_DECK,
      node: process.env.NODE_ENV,
      fast: process.env.SETIMIG_TEST_FAST,
      deck: process.env.SETIMIG_TEST_DECK_SEED,
    };
    process.env.SETIMIG_TEST_SEEDED_DECK = "1";
    process.env.SETIMIG_TEST_FAST = "1";
    delete process.env.NODE_ENV;
    delete process.env.SETIMIG_TEST_DECK_SEED;
    resetPrivateSeededDeckWarningsForTests();
    const queued: Array<() => void | Promise<void>> = [];
    const clock: GameHost = {
      emitRoomUpdate() {},
      schedule(fn) {
        queued.push(fn as () => void);
        return queued.length as unknown as ReturnType<typeof setTimeout>;
      },
      clearTimeout() {},
    };
    try {
      const room = emptyRoomBase("llavor-3", "QA", 100, 0);
      room.isPrivate = true;
      room.houseRulesEnabled = true;
      room.autoFillBots = false;
      room.testDeckSeed = 3;
      room.players = [seat("host", "Test QA A", { chips: 12_000, status: "waiting" }), seat("guest", "Test QA B", { chips: 12_000, status: "waiting" })];
      beginGameStart(clock, room);
      queued.shift()?.();
      const guest = room.players.find((p) => p.id === "guest")!;
      const banker = room.players.find((p) => p.isBanker)!;
      assert.equal(applyPlaceBet(room, guest, 100, clock), null);
      assert.equal(applyDouble(clock, room, guest.id), null);
      assert.equal(applySplit(room, guest.id), null);
      assert.deepEqual(
        guest.handSlots.map((h) => h.cards.length),
        [2, 2],
        "cada mà rep la segona carta en separar",
      );
      assert.equal(applyStand(clock, room, guest.id), null);
      assert.equal(applyStand(clock, room, guest.id), null);
      while (room.phase === "banker") {
        const sc = scoreCards(banker.handSlots[0]!.cards);
        if (sc < 7) assert.equal(applyHit(clock, room, banker.id), null);
        else assert.equal(applyStand(clock, room, banker.id), null);
      }
      assert.equal(room.phase, "settlement");
      assertNetsMatchTotal(room);
      const line = room.lastRound!.results!.find((r) => r.name === "Test QA B")!;
      assert.equal(line.detail, "+200 (banca passada) · +200 (banca passada)");
      assert.equal(line.chipDelta, 400);
      const highs = room.lastRound!.highlights.filter((h) => h.name === "Test QA B");
      assert.deepEqual(highs.map((h) => h.code), ["winBankBust", "winBankBust"]);
      assert.deepEqual(highs.map((h) => handAmount(h.params as { amount?: number })), [200, 200]);
      const slots = room.lastSettlement!.seats.find((s) => s.name === "Test QA B")!.slots;
      assert.equal(slots[0]!.points, 7.5);
      assert.equal(slots[0]!.bet, 200);
      assert.equal(slots[0]!.doubled, false);
      assert.equal(slots[0]!.natural, false);
      assert.equal(slots[1]!.natural, false);
      const view = JSON.stringify(roomToView(room, "guest", clock));
      assert.equal(view.includes("naturalWin"), false);
      assert.equal(view.includes("7 i Mig natural"), false);
    } finally {
      const restore = (key: string, value: string | undefined) => {
        if (value === undefined) delete process.env[key];
        else process.env[key] = value;
      };
      restore("SETIMIG_TEST_SEEDED_DECK", prev.flag);
      restore("NODE_ENV", prev.node);
      restore("SETIMIG_TEST_FAST", prev.fast);
      restore("SETIMIG_TEST_DECK_SEED", prev.deck);
      resetPrivateSeededDeckWarningsForTests();
    }
  });
});
