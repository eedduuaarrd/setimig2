import { absoluteUrl } from "./seo.ts";
import { ca } from "../src/i18n/locales/ca.ts";

export const COM_JUGAR_PATH = "/com-jugar";

export type ComJugarFaqItem = {
  question: string;
  answer: string;
};

/** Preguntes del FAQ de /com-jugar, en ordre. Els textos són a les claus i18n `faq.<id>.q` / `faq.<id>.a`. */
export const COM_JUGAR_FAQ_IDS = ["hand", "deck", "bust", "bank", "actions", "royal", "money"] as const;
export type ComJugarFaqId = (typeof COM_JUGAR_FAQ_IDS)[number];

/** FAQ en català (idioma canònic), tret del diccionari perquè el text i l'esquema no es desviïn. */
export const COM_JUGAR_FAQ: readonly ComJugarFaqItem[] = COM_JUGAR_FAQ_IDS.map((id) => ({
  question: ca.faq[id].q.replace("{game}", ca.brand.game),
  answer: ca.faq[id].a,
}));

/** FAQPage de schema.org per a una llista de preguntes ja traduïda. */
export function buildComJugarFaqJsonLd(items: readonly ComJugarFaqItem[], inLanguage: string) {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    inLanguage,
    url: absoluteUrl(COM_JUGAR_PATH),
    mainEntity: items.map((item) => ({
      "@type": "Question",
      name: item.question,
      acceptedAnswer: {
        "@type": "Answer",
        text: item.answer,
      },
    })),
  };
}

export const COM_JUGAR_FAQ_JSON_LD = buildComJugarFaqJsonLd(COM_JUGAR_FAQ, "ca");
