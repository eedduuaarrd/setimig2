import assert from "node:assert/strict";
import { afterEach, beforeEach, describe, it } from "node:test";
import {
  BOT_TURN_WATCHDOG_MS,
  applyHit,
  applyStand,
  clearRoomTimers,
  currentPlayer,
  emptyRoomBase,
  publishRoom,
  runBotAction,
  type GameHost,
  type HandSlot,
  type Player,
  type Room,
} from "./gameEngine.ts";
import type { Card } from "../src/gameTypes.ts";
import { setBotRngForTests } from "./ai/botProfile.ts";
import { DEAL_MAX_IN_TURN_MS } from "./dealEvents.ts";

process.env.SETIMIG_TEST_FAST = "1";

// RNG dels bots fix a 0: amb qualsevol perfil, Núria sempre intenta el doble (i la banca el rebutja).
beforeEach(() => setBotRngForTests(() => 0));
afterEach(() => setBotRngForTests(null));

/** Manual clock: timers only run when the test fires them. */
function manualHost() {
  let seq = 0;
  const timers = new Map<number, { fn: () => void; ms: number }>();
  const host: GameHost = {
    emitRoomUpdate() {},
    schedule(fn, ms) {
      seq += 1;
      timers.set(seq, { fn, ms });
      return seq as unknown as ReturnType<typeof setTimeout>;
    },
    clearTimeout(id) {
      if (id != null) timers.delete(id as unknown as number);
    },
  };
  /** Runs the earliest pending timer (by delay); returns false when none is left. */
  function fireNext(filter?: (ms: number) => boolean): boolean {
    const entries = [...timers.entries()].filter(([, t]) => !filter || filter(t.ms));
    if (!entries.length) return false;
    entries.sort((a, b) => a[1].ms - b[1].ms || a[0] - b[0]);
    const [id, t] = entries[0];
    timers.delete(id);
    t.fn();
    return true;
  }
  return { host, timers, fireNext };
}

function card(value: number, suit: Card["suit"] = "hearts"): Card {
  return { suit, value, points: value >= 10 ? 0.5 : value };
}

function slot(id: string, bet: number, cards: Card[], canDouble = false): HandSlot {
  return {
    id,
    bet,
    cards: cards.map((c, i) => ({ id: `${id}-${i}`, card: c, faceUp: true })),
    doubled: false,
    canDouble,
    mort: false,
    blindPair: false,
    blindUntilBankEnd: false,
    mortOffered: false,
    status: "playing",
  };
}

function seat(id: string, chips: number, bet: number, slots: HandSlot[], extra: Partial<Player> = {}): Player {
  return {
    id,
    playerId: id,
    seatToken: id,
    name: id,
    chips,
    bet,
    isBanker: false,
    status: "playing",
    handSlots: slots,
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
    ...extra,
  };
}

/**
 * QA case (b): the human is the banker; Laia busts, Pau stands at 6½ and it is Núria's turn.
 * Núria (bot) holds one 5 with «Doblar» available, but the bank cannot cover the double.
 */
function stuckDoubleRoom(practiceMode = false): Room {
  const room = emptyRoomBase("solo-stuck", "Solo", 100, 0);
  room.soloAi = true;
  room.houseRulesEnabled = true;
  room.practiceMode = practiceMode;
  room.phase = "playing";
  const bank = seat("human", 1_000, 0, [slot("bank", 0, [card(4)])], { isBanker: true, status: "waiting" });
  const laia = seat("laia", 5_000, 200, [slot("laia", 200, [card(5), card(1)])], { isBot: true });
  const pau = seat("pau", 5_000, 100, [slot("pau", 100, [card(6)])], { isBot: true });
  const nuria = seat("nuria", 5_000, 200, [slot("nuria", 200, [card(5, "clubs")], true)], { isBot: true });
  room.players = [bank, laia, pau, nuria];
  room.turnPlayerIndex = 0;
  room.pot = 500;
  // deck.pop(): Laia draws a 7 (busts), Pau draws a figure (6½), then cards for Núria.
  room.deck = [card(2, "diamonds"), card(1, "spades"), card(10, "clubs"), card(7, "clubs")];
  return room;
}

function playLaiaAndPau(host: GameHost, room: Room) {
  assert.equal(applyHit(host, room, "laia"), null);
  assert.equal(room.players[1].handSlots[0].status, "busted");
  assert.equal(currentPlayer(room)?.id, "pau");
  assert.equal(applyHit(host, room, "pau"), null);
  assert.equal(applyStand(host, room, "pau"), null);
  assert.equal(currentPlayer(room)?.id, "nuria");
}

describe("bot turn never gets stuck (S-P0-1)", () => {
  for (const practiceMode of [false, true]) {
    it(`a rejected double no longer loops forever (${practiceMode ? "practice" : "normal"}, human banker)`, () => {
      const { host, fireNext } = manualHost();
      const room = stuckDoubleRoom(practiceMode);
      playLaiaAndPau(host, room);
      const nuria = room.players[3];
      // Only run bot-pace timers (not the watchdog): proves the bot itself makes progress.
      for (let i = 0; i < 20 && room.phase === "playing"; i++) {
        if (!fireNext((ms) => ms < 5_000)) break;
      }
      assert.notEqual(room.phase, "playing", "Núria's turn must end");
      assert.equal(nuria.handSlots[0].doubled, false);
      assert.notEqual(nuria.handSlots[0].status, "playing");
      clearRoomTimers(host, room);
    });
  }

  it("watchdog forces a stand when the bot timer is lost", () => {
    const { host, timers, fireNext } = manualHost();
    const room = stuckDoubleRoom(true);
    playLaiaAndPau(host, room);
    // Simulate the lost/failed bot callback: drop the pending bot timer.
    clearTimeoutWhere(host, timers, (ms) => ms < 5_000);
    room.botTimer = null;
    assert.equal(currentPlayer(room)?.id, "nuria");
    // Des de #188 el vigilant dona de més l'animació de repartiment pendent (aquí, Laia s'ha passat:
    // 600 ms). Amb SETIMIG_TEST_FAST l'animació val 0, sense el flag val fins a DEAL_MAX_IN_TURN_MS.
    assert.ok(
      [...timers.values()].some((t) => t.ms > 5_000 && t.ms <= BOT_TURN_WATCHDOG_MS + DEAL_MAX_IN_TURN_MS),
      "watchdog armed"
    );
    assert.ok(fireNext((ms) => ms > 5_000));
    assert.equal(room.players[3].handSlots[0].status, "stood");
    assert.equal(room.phase, "banker");
    clearRoomTimers(host, room);
  });

  it("watchdog keeps its deadline while a bot loops without progress", () => {
    const { host, timers } = manualHost();
    const room = stuckDoubleRoom(true);
    playLaiaAndPau(host, room);
    const since = room.botTurnWatch?.since;
    assert.ok(since);
    void publishRoom(host, room); // re-publish with the same state
    assert.equal(room.botTurnWatch?.since, since);
    const watchdogs = [...timers.values()].filter((t) => t.ms > 5_000);
    assert.equal(watchdogs.length, 1, "exactly one watchdog per room");
    clearRoomTimers(host, room);
    assert.equal(timers.size, 0, "no leaked timers after the room is cleared");
  });

  it("an exception inside the bot action forces a stand and advances", () => {
    const { host } = manualHost();
    const room = stuckDoubleRoom(false);
    playLaiaAndPau(host, room);
    const nuria = room.players[3];
    const s = nuria.handSlots[0];
    let reads = 0;
    const realCards = s.cards;
    Object.defineProperty(s, "cards", {
      configurable: true,
      get() {
        reads += 1;
        if (reads === 1) throw new Error("boom");
        return realCards;
      },
    });
    runBotAction(host, room, nuria);
    assert.equal(s.status, "stood");
    assert.equal(room.phase, "banker");
    clearRoomTimers(host, room);
  });

  it("watchdog reschedules when the state moved but no bot timer is pending", () => {
    const { host, timers, fireNext } = manualHost();
    const room = stuckDoubleRoom(false);
    playLaiaAndPau(host, room);
    clearTimeoutWhere(host, timers, (ms) => ms < 5_000);
    room.botTimer = null;
    // State changes without a publish (e.g. a failed broadcast): Núria got a card.
    room.players[3].handSlots[0].cards.push({ id: "x", card: card(1, "clubs"), faceUp: true });
    room.players[3].handSlots[0].canDouble = false;
    assert.ok(fireNext((ms) => ms > 5_000));
    assert.ok(room.botTimer, "bot timer rescheduled");
    assert.equal(room.players[3].handSlots[0].status, "playing", "no forced stand when the bot moved");
    clearRoomTimers(host, room);
  });
});

function clearTimeoutWhere(
  host: GameHost,
  timers: Map<number, { fn: () => void; ms: number }>,
  pred: (ms: number) => boolean
) {
  for (const [id, t] of [...timers.entries()]) {
    if (pred(t.ms)) host.clearTimeout(id as unknown as ReturnType<typeof setTimeout>);
  }
}
