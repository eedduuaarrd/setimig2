/**
 * Liquidació única: una mà liquidada surt en UNA sola emissió consistent (sense estats parcials)
 * i el servidor envia un esdeveniment `settlement` per socket i mà, amb el resum i la vista.
 */
import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { createServer } from "node:http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket } from "socket.io-client";
import {
  emptyRoomBase,
  publishRoom,
  roomToView,
  settleGame,
  type GameHost,
  type HandSlot,
  type Player,
  type Room,
} from "./gameEngine.ts";
import { createSingleSpanishDeck } from "./spanishDeck.ts";
import type { Card } from "../src/gameTypes.ts";
import type { SettlementEventPayload, SettlementView } from "./settlementSummary.ts";

const deck = createSingleSpanishDeck();
function card(value: number, suit: Card["suit"] = "hearts"): Card {
  const c = deck.find((d) => d.value === value && d.suit === suit);
  assert.ok(c);
  return { ...c };
}

function slot(cards: Card[], bet: number, status: HandSlot["status"]): HandSlot {
  return {
    id: `s-${Math.random()}`,
    cards: cards.map((c, i) => ({ id: `c${i}-${c.suit}-${c.value}`, card: c, faceUp: true })),
    bet,
    doubled: false,
    canDouble: false,
    mort: false,
    blindPair: false,
    blindUntilBankEnd: false,
    mortOffered: false,
    status,
  };
}

function seat(id: string, extra: Partial<Player> = {}): Player {
  return {
    id,
    playerId: id,
    seatToken: `tok-${id}`,
    name: id,
    chips: 1000,
    bet: 0,
    isBanker: false,
    status: "stood",
    handSlots: [],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
    ...extra,
  };
}

type Emitted = { phase: string; settlementId: string | null; hasLastRound: boolean; chips: number[] };

/** Host síncron (com el solo local del client): cada publicació és una emissió immediata. */
function countingHost() {
  const emits: Emitted[] = [];
  const persisted: { playerId: string; chips: number }[] = [];
  const host: GameHost = {
    emitRoomUpdate(room) {
      emits.push({
        phase: room.phase,
        settlementId: room.lastSettlement?.settlementId ?? null,
        hasLastRound: !!room.lastRound,
        chips: room.players.map((p) => p.chips),
      });
    },
    schedule: () => 0 as unknown as ReturnType<typeof setTimeout>,
    clearTimeout() {},
    async persistHumanBalance(playerId, chips) {
      persisted.push({ playerId, chips });
    },
  };
  return { host, emits, persisted };
}

/** Banca (bot) amb 7; P1 7½ natural (100), P2 5 (200), P3 humà passat (100). */
function bankerTurnRoom(extra: Partial<Room> = {}): Room {
  const room = emptyRoomBase("liq-unit", "Liquidació", 100, 0);
  const banker = seat("B", { isBot: true, isBanker: true, chips: 5000, handSlots: [slot([card(7)], 0, "stood")] });
  const p1 = seat("P1", { isBot: true, chips: 900, bet: 100, handSlots: [slot([card(7, "clubs"), card(10)], 100, "stood")] });
  const p2 = seat("P2", { isBot: true, chips: 800, bet: 200, handSlots: [slot([card(5)], 200, "stood")] });
  const p3 = seat("P3", { chips: 1000, bet: 100, handSlots: [slot([card(6), card(5, "clubs")], 100, "busted")] });
  room.players = [banker, p1, p2, p3];
  room.pot = 400;
  room.phase = "banker";
  room.roundStartChips = new Map([
    ["B", 5000],
    ["P1", 1000],
    ["P2", 1000],
    ["P3", 1100],
  ]);
  room.roundStartJackpot = 0;
  Object.assign(room, extra);
  return room;
}

function assertConsistent(view: SettlementView, players: { id: string; chips: number }[]) {
  let sum = 0;
  for (const s of view.seats) {
    assert.equal(s.chipDelta, s.chipsAfter - s.chipsBefore, `delta de ${s.name}`);
    const p = players.find((x) => x.id === s.seatId);
    assert.ok(p, `el seient ${s.name} té l'id de la vista`);
    assert.equal(s.chipsAfter, p!.chips, `saldo final de ${s.name} = fitxes de la vista`);
    sum += s.chipDelta;
  }
  assert.equal(view.totals.sumChipDelta, sum);
  assert.equal(view.totals.chipsAfter - view.totals.chipsBefore, sum);
  assert.equal(view.totals.potAfter, 0);
  if (view.bank) {
    const bankSeat = view.seats.find((s) => s.isBanker);
    assert.equal(bankSeat?.seatId, view.bank.seatId);
    assert.equal(bankSeat?.chipDelta, view.bank.chipDelta);
  }
  for (const r of view.results) {
    const s = view.seats.find((x) => x.name === r.name);
    assert.equal(s?.chipDelta, r.chipDelta, `results i seats coincideixen per a ${r.name}`);
  }
}

describe("liquidació única (motor)", () => {
  it("una liquidació = una sola emissió, ja amb el resum complet i saldos finals", () => {
    const { host, emits } = countingHost();
    const room = bankerTurnRoom({ soloAi: undefined });
    settleGame(host, room);
    assert.equal(emits.length, 1, "una sola publicació durant la liquidació");
    assert.equal(emits[0]!.phase, "settlement");
    assert.ok(emits[0]!.settlementId);
    assert.ok(emits[0]!.hasLastRound);

    const view = roomToView(room, "P3", host);
    const s = view.settlement!;
    assert.ok(s);
    assert.equal(s.settlementId, emits[0]!.settlementId);
    assert.equal(s.handSeq, 1);
    assert.equal(s.at, view.lastRound!.at);
    assert.equal(view.settlementStartedAt, s.at);
    assert.equal(s.chipsKind, "real");
    const byName = Object.fromEntries(s.seats.map((x) => [x.name, x]));
    assert.equal(byName.P1!.chipDelta, 200);
    assert.equal(byName.P1!.slots[0]!.natural, true);
    assert.equal(byName.P2!.chipDelta, -200);
    assert.equal(byName.P3!.chipDelta, -100);
    assert.equal(byName.B!.chipDelta, 100);
    assert.deepEqual(
      { points: s.bank!.points, busted: s.bank!.busted, sevenHalf: s.bank!.sevenHalf },
      { points: 7, busted: false, sevenHalf: false }
    );
    assert.equal(s.totals.sumChipDelta, 0);
    assertConsistent(s, view.players);
    assert.ok(!JSON.stringify(s).includes("playerId"), "el playerId intern no surt a la vista");
  });

  it("la mà que tanca la partida (banca passada sense relleu) no publica cap estat parcial", () => {
    const { host, emits } = countingHost();
    const room = emptyRoomBase("liq-end", "Final", 100, 0);
    room.soloAi = true;
    room.tableMaxBet = 5000;
    room.phaseB = { handsTotal: 10, handsCompleted: 10, chipPool: 600, startingChips: 300 };
    const banker = seat("B", { isBot: true, isBanker: true, chips: 300, handSlots: [slot([card(7), card(6)], 0, "busted")] });
    const human = seat("H", { chips: 50, bet: 100, handSlots: [slot([card(5)], 100, "stood")] });
    room.players = [banker, human];
    room.pot = 100;
    room.phase = "banker";
    room.roundStartChips = new Map([
      ["B", 300],
      ["H", 150],
    ]);
    room.roundStartJackpot = 0;
    settleGame(host, room);
    assert.equal(emits.length, 1, "abans sortia un estat amb fitxes pagades i sense lastRound");
    assert.ok(emits[0]!.hasLastRound);
    assert.ok(emits[0]!.settlementId);
    assert.equal(room.matchEnded, true);
    const view = roomToView(room, "H", host);
    assert.equal(view.settlement!.matchEnded, true);
    assert.ok(view.matchResult);
    assert.equal(view.settlement!.chipsKind, "match");
    assertConsistent(view.settlement!, view.players);
  });

  it("pràctica: fitxes de pràctica i cap escriptura de saldo real", async () => {
    const { host, emits, persisted } = countingHost();
    const room = bankerTurnRoom({ practiceMode: true });
    settleGame(host, room);
    await new Promise((r) => setImmediate(r));
    assert.equal(emits.length, 1);
    assert.equal(persisted.length, 0, "la pràctica no toca mai el saldo real");
    const view = roomToView(room, "P3", host);
    assert.equal(view.settlement!.chipsKind, "practice");
    assertConsistent(view.settlement!, view.players);
  });

  it("sense roundStartChips (partida antiga) lastRound.results no queda buit i les apostes no es toquen", () => {
    const { host: knownHost } = countingHost();
    const known = bankerTurnRoom();
    settleGame(knownHost, known);

    const { host } = countingHost();
    const old = bankerTurnRoom();
    old.roundStartChips = undefined;
    const betsBefore = old.players.map((p) => ({ bet: p.bet, slots: p.handSlots.map((s) => s.bet) }));
    settleGame(host, old);

    assert.deepEqual(
      old.players.map((p) => ({ bet: p.bet, slots: p.handSlots.map((s) => s.bet) })),
      betsBefore
    );
    assert.ok(old.lastRound);
    assert.ok(old.lastRound.results.length > 0);
    assert.deepEqual(
      old.lastRound.results.map((r) => ({ name: r.name, chipDelta: r.chipDelta })),
      known.lastRound!.results.map((r) => ({ name: r.name, chipDelta: r.chipDelta }))
    );
    assert.deepEqual(
      old.players.map((p) => p.chips),
      known.players.map((p) => p.chips)
    );
  });

  it("banca a 7½: el rival perd l'aposta i el text no diu que la banca s'ha passat", () => {
    const { host } = countingHost();
    const room = emptyRoomBase("liq-set", "Set", 100, 0);
    const banker = seat("Laia", {
      isBot: true,
      isBanker: true,
      chips: 5_000,
      handSlots: [slot([card(7), card(12, "spades")], 0, "stood")],
    });
    const pau = seat("Pau", { isBot: true, chips: 800, bet: 200, handSlots: [slot([card(5)], 200, "stood")] });
    room.players = [banker, pau];
    room.pot = 200;
    room.phase = "banker";
    room.roundStartChips = new Map([
      ["Laia", 5_000],
      ["Pau", 1_000],
    ]);
    settleGame(host, room);
    const line = room.lastRound!.results.find((r) => r.name === "Pau")!;
    assert.equal(line.chipDelta, -200);
    assert.equal(line.outcome, "lose");
    assert.equal(line.detail.includes("banca passada"), false);
    assert.equal(line.detail.includes("+"), false);
    const bank = room.lastRound!.results.find((r) => r.name === "Laia")!;
    assert.equal(bank.chipDelta, 200);
    assert.equal(bank.handPoints, 7.5);
    assert.equal(room.lastSettlement?.bank?.busted, false);
    assert.equal(room.lastSettlement?.bank?.sevenHalf, true);
  });

  it("dos seients amb el mateix nom no es barregen el resultat", () => {
    const { host } = countingHost();
    const room = emptyRoomBase("liq-homonim", "H", 100, 0);
    const banker = seat("Laia", {
      isBot: true,
      isBanker: true,
      chips: 5_000,
      handSlots: [slot([card(5), card(4)], 0, "busted")],
    });
    const winner = seat("Pau", { id: "pau-win", playerId: "pau-win", isBot: true, chips: 800, bet: 200, handSlots: [slot([card(6)], 200, "stood")] });
    const loser = seat("Pau", { id: "pau-lose", playerId: "pau-lose", isBot: true, chips: 700, bet: 300, handSlots: [slot([card(5), card(4)], 300, "busted")] });
    room.players = [banker, winner, loser];
    room.pot = 500;
    room.phase = "banker";
    room.roundStartChips = new Map([
      ["Laia", 5_000],
      ["pau-win", 1_000],
      ["pau-lose", 1_000],
    ]);
    settleGame(host, room);
    const lines = room.lastRound!.results.filter((r) => r.name === "Pau");
    assert.equal(lines.length, 2);
    const win = lines.find((r) => r.params && "seatId" in r.params && r.params.seatId === "pau-win")!;
    const loss = lines.find((r) => r.params && "seatId" in r.params && r.params.seatId === "pau-lose")!;
    assert.ok(win.chipDelta > 0);
    assert.ok(loss.chipDelta < 0);
    assert.equal(win.detail.includes("banca passada"), true);
    assert.equal(loss.detail.includes("banca passada"), false);
    assert.equal(loss.detail.includes("+"), false);
  });

  it("publishRoom no emet res mentre es liquida", async () => {
    const { host, emits } = countingHost();
    const room = bankerTurnRoom();
    room.settlingInProgress = true;
    await publishRoom(host, room);
    assert.equal(emits.length, 0);
    room.settlingInProgress = undefined;
    await publishRoom(host, room);
    assert.equal(emits.length, 1);
  });
});

// ---------------------------------------------------------------------------------------------
// Socket: solo, pràctica i taula privada multijugador.

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";

type RoomViewLite = {
  id: string;
  phase: string;
  turnPlayerId?: string | null;
  minBet: number;
  matchEnded?: boolean;
  players: { id: string; chips: number; bet: number; isBanker: boolean; pendingBankChoice?: { mandatory: boolean } | null }[];
  settlement?: SettlementView | null;
  playerToken?: string;
};

function connect(url: string): Promise<Socket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.on("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.on("connect_error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

/**
 * Juga com a humà (aposta mínima, es planta, «Següent») i recull els esdeveniments fins a veure
 * `hands` liquidacions. Comprova l'ordre: el `settlement` arriba abans de qualsevol room_update
 * que ja dugui aquella liquidació.
 */
function playHands(socket: Socket, hands: number, timeoutMs = 45_000) {
  const settlements: SettlementEventPayload[] = [];
  const updates: RoomViewLite[] = [];
  const errors: string[] = [];
  const bettedHand = new Set<string>();
  return new Promise<{ settlements: SettlementEventPayload[]; updates: RoomViewLite[]; errors: string[] }>(
    (resolve, reject) => {
      const timer = setTimeout(
        () => reject(new Error(`timeout: ${settlements.length}/${hands} liquidacions, fase ${updates.at(-1)?.phase}`)),
        timeoutMs
      );
      let roundKey = 0;
      const finish = () => {
        clearTimeout(timer);
        socket.off("settlement", onSettlement);
        socket.off("room_update", onRoom);
        resolve({ settlements, updates, errors });
      };
      const onSettlement = (payload: SettlementEventPayload) => {
        settlements.push(payload);
        if (settlements.length >= hands) setTimeout(finish, 150);
      };
      const onRoom = (room: RoomViewLite) => {
        updates.push(room);
        const sid = room.settlement?.settlementId;
        if (sid && !settlements.some((s) => s.settlementId === sid)) {
          errors.push(`room_update amb ${sid} abans de l'esdeveniment settlement`);
        }
        const me = room.players.find((p) => p.id === socket.id);
        if (!me) return;
        if (me.pendingBankChoice) {
          socket.emit("bank_keep_choice", { roomId: room.id, keep: !!me.pendingBankChoice.mandatory });
        }
        if (room.phase === "settlement") {
          roundKey += 1;
          socket.emit("settlement_next", room.id);
        }
        if (room.phase === "betting" && !me.isBanker && me.bet === 0 && !bettedHand.has(`${roundKey}`)) {
          bettedHand.add(`${roundKey}`);
          socket.emit("place_bet", { roomId: room.id, amount: room.minBet });
        }
        if (room.phase === "playing" && room.turnPlayerId === socket.id) socket.emit("stand", room.id);
        if (room.phase === "banker" && me.isBanker) socket.emit("stand", room.id);
      };
      socket.on("settlement", onSettlement);
      socket.on("room_update", onRoom);
    }
  );
}

function assertSocketRun(run: Awaited<ReturnType<typeof playHands>>) {
  assert.deepEqual(run.errors, []);
  const ids = run.settlements.map((s) => s.settlementId);
  assert.equal(new Set(ids).size, ids.length, "un sol esdeveniment settlement per mà i socket");
  for (const s of run.settlements) {
    assert.equal(s.room.settlement?.settlementId, s.settlementId, "el resum i la vista són de la mateixa mà");
    assert.ok(s.room.phase === "settlement" || s.matchEnded, `fase ${s.room.phase}`);
    assertConsistent(s, s.room.players);
    // Totes les room_update d'aquesta liquidació diuen el mateix (cap salt de saldos).
    for (const u of run.updates.filter((x) => x.settlement?.settlementId === s.settlementId)) {
      for (const seatLine of s.seats) {
        const p = u.players.find((x) => x.id === seatLine.seatId);
        if (p && u.phase === "settlement") assert.equal(p.chips, seatLine.chipsAfter);
      }
    }
  }
  for (let i = 1; i < run.settlements.length; i++) {
    assert.ok(run.settlements[i]!.handSeq > run.settlements[i - 1]!.handSeq);
  }
}

describe("liquidació única (socket)", () => {
  let dataDir = "";
  let http: ReturnType<typeof createServer>;
  let io: SocketIOServer;
  let url = "";
  let gameModule: typeof import("../server/game.ts");

  before(async () => {
    dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "setimig-liq-unica-"));
    process.env.BALANCE_DATA_DIR = dataDir;
    process.env.SETIMIG_TEST_FAST = "1";
    gameModule = await import("../server/game.ts");
    gameModule.resetGameStateForTests();
    http = createServer();
    io = new SocketIOServer(http, { cors: { origin: "*" } });
    await gameModule.setupGameHandlers(io);
    await new Promise<void>((r) => http.listen(0, "127.0.0.1", () => r()));
    url = `http://127.0.0.1:${(http.address() as { port: number }).port}`;
  });

  after(async () => {
    io.close();
    await new Promise<void>((r) => http.close(() => r()));
    const { removeTestDataDir } = await import("../server/testing/testDataDir.ts");
    await removeTestDataDir(dataDir);
    delete process.env.BALANCE_DATA_DIR;
  });

  for (const practiceMode of [false, true]) {
    it(`solo${practiceMode ? " (pràctica)" : ""}: un esdeveniment settlement consistent per mà`, async () => {
      const socket = await connect(url);
      try {
        const joined = new Promise<RoomViewLite>((resolve) => socket.once("joined_room", resolve));
        const runP = playHands(socket, 2);
        socket.emit("join_solo_room", {
          playerName: practiceMode ? "Practica" : "Solista",
          playerId: practiceMode ? "liqunicaprac0001" : "liqunicasolo0001",
          botCount: 2,
          botDifficulty: "easy",
          practiceMode,
        });
        const room = await joined;
        const run = await runP;
        assertSocketRun(run);
        assert.equal(run.settlements[0]!.roomId, room.id);
        assert.equal(run.settlements[0]!.chipsKind, practiceMode ? "practice" : "match");
        assert.ok(run.settlements[0]!.handNumber! >= 1);
      } finally {
        socket.disconnect();
      }
    });
  }

  it("taula privada amb dos humans: cada socket rep la mateixa liquidació una sola vegada", async () => {
    const host = await connect(url);
    const guest = await connect(url);
    try {
      const hostJoined = new Promise<RoomViewLite & { inviteCode?: string }>((r) => host.once("joined_room", r));
      host.emit("create_private_table", { playerName: "Amfitrio", playerId: "liqunicahost00001" });
      const hostRoom = await hostJoined;
      const guestJoined = new Promise<RoomViewLite>((r) => guest.once("joined_room", r));
      guest.emit("join_private_table", {
        inviteCode: hostRoom.inviteCode,
        playerName: "Convidat",
        playerId: "liqunicaguest0001",
      });
      await guestJoined;
      const hostRun = playHands(host, 2);
      const guestRun = playHands(guest, 2);
      host.emit("fill_private_bots", hostRoom.id);
      await new Promise((r) => setTimeout(r, 200));
      host.emit("start_game", hostRoom.id);
      const [h, g] = await Promise.all([hostRun, guestRun]);
      assertSocketRun(h);
      assertSocketRun(g);
      assert.deepEqual(
        h.settlements.map((s) => s.settlementId),
        g.settlements.map((s) => s.settlementId),
        "els dos jugadors reben la mateixa liquidació"
      );
      for (let i = 0; i < h.settlements.length; i++) {
        const a = h.settlements[i]!;
        const b = g.settlements[i]!;
        assert.deepEqual(
          a.seats.map((s) => [s.name, s.chipDelta, s.chipsAfter]),
          b.seats.map((s) => [s.name, s.chipDelta, s.chipsAfter])
        );
      }
    } finally {
      guest.disconnect();
      host.disconnect();
    }
  });
});
