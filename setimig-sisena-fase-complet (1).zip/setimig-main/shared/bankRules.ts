/** Regles de canvi de banca (7½ / set i mig) — lògica pura per provar sense socket. */

export interface BankOfferPlayer {
  id: string;
  refusedBankBefore?: boolean;
}

export interface BankOfferSlot {
  bet: number;
  score: number;
  status: string;
}

export interface PendingBankChoice {
  mandatory: boolean;
}

export function isSetIMigScore(score: number, status: string): boolean {
  return score === 7.5 && status !== "busted";
}

/** Primer jugador en ordre de torn (no banca) que ha fet set i mig aquesta mà. */
export function pickBankOfferWinner<T extends BankOfferPlayer>(
  nonBankersInTurnOrder: T[],
  playerHasSetIMig: (player: T) => boolean
): T | null {
  for (const player of nonBankersInTurnOrder) {
    if (playerHasSetIMig(player)) return player;
  }
  return null;
}

export function playerHasSetIMigHand(slots: BankOfferSlot[]): boolean {
  return slots.some((slot) => slot.bet > 0 && isSetIMigScore(slot.score, slot.status));
}

export function buildPendingBankChoice(player: BankOfferPlayer): PendingBankChoice {
  return { mandatory: !!player.refusedBankBefore };
}

export function botAcceptsBankOffer(chips: number, minBet: number, opponentCount = 1): boolean {
  if (chips < minBet) return false;
  if (opponentCount <= 0) return true;
  return chips >= minBet * 2 * opponentCount;
}

export function applyBankOfferDecision(
  players: { id: string; isBanker: boolean; refusedBankBefore?: boolean }[],
  chooserId: string,
  accept: boolean,
  mandatory: boolean
): { accept: boolean; refused: boolean } {
  const effectiveAccept = mandatory ? true : accept;
  if (effectiveAccept) {
    for (const p of players) {
      p.isBanker = p.id === chooserId;
    }
    return { accept: true, refused: false };
  }
  const chooser = players.find((p) => p.id === chooserId);
  if (chooser) chooser.refusedBankBefore = true;
  return { accept: false, refused: true };
}
