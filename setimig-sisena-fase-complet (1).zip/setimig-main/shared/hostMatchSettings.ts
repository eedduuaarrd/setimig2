import { PHASE_B_HAND_COUNT } from "./matchPhaseB.ts";
import { PLAY_WINDOW_MS } from "./turnTiming.ts";

export const DEFAULT_MATCH_HANDS = PHASE_B_HAND_COUNT;
export const MIN_MATCH_HANDS = 3;
export const MAX_MATCH_HANDS = 30;

/** Temps per defecte del servidor (prod); els tests poden usar valors més baixos via SETIMIG_TEST_FAST. */
export const DEFAULT_TURN_TIMEOUT_MS = PLAY_WINDOW_MS;
export const MIN_TURN_TIMEOUT_MS = 5_000;
export const MAX_TURN_TIMEOUT_MS = 90_000;

export type HostMatchSettings = {
  handsTotal: number;
  turnTimeoutMs: number;
  houseRulesEnabled: boolean;
};

export function defaultHostMatchSettings(): HostMatchSettings {
  return {
    handsTotal: DEFAULT_MATCH_HANDS,
    turnTimeoutMs: DEFAULT_TURN_TIMEOUT_MS,
    houseRulesEnabled: false,
  };
}

function clampInt(n: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, Math.floor(n)));
}

/** Valida ajustos d'amfitrió; retorna null si algun camp és invàlid. */
export function normalizeHostMatchSettings(raw: unknown): HostMatchSettings | null {
  if (raw === null || typeof raw !== "object" || Array.isArray(raw)) return null;
  const input = raw as Record<string, unknown>;
  const defaults = defaultHostMatchSettings();

  let handsTotal = defaults.handsTotal;
  if (input.handsTotal !== undefined) {
    const n = Number(input.handsTotal);
    if (!Number.isFinite(n)) return null;
    handsTotal = clampInt(n, MIN_MATCH_HANDS, MAX_MATCH_HANDS);
  }

  let turnTimeoutMs = defaults.turnTimeoutMs;
  if (input.turnTimeoutMs !== undefined) {
    const n = Number(input.turnTimeoutMs);
    if (!Number.isFinite(n)) return null;
    turnTimeoutMs = clampInt(n, MIN_TURN_TIMEOUT_MS, MAX_TURN_TIMEOUT_MS);
  }

  let houseRulesEnabled = defaults.houseRulesEnabled;
  if (input.houseRulesEnabled !== undefined) {
    if (typeof input.houseRulesEnabled !== "boolean") return null;
    houseRulesEnabled = input.houseRulesEnabled;
  }

  return { handsTotal, turnTimeoutMs, houseRulesEnabled };
}

export function turnTimeoutMsForRoom(settings?: HostMatchSettings | null): number {
  const ms = settings?.turnTimeoutMs;
  if (ms != null && Number.isFinite(ms)) {
    return clampInt(ms, MIN_TURN_TIMEOUT_MS, MAX_TURN_TIMEOUT_MS);
  }
  return DEFAULT_TURN_TIMEOUT_MS;
}
