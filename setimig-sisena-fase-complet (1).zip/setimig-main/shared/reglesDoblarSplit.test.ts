/**
 * Regles de doblar i separar (substitueixen les del PR #351).
 * 1. Doblar només amb la primera carta.
 * 2. Separar dues cartes del mateix valor; les figures compten juntes.
 * 3. Es pot separar després de doblar.
 * 4. Cada mà porta l'aposta doblada (splitHandBet no canvia).
 * 5. Una mà separada no pot doblar.
 * 6. Re-split sense límit.
 * 7. Després del canvi del 4, la carta nova és una mà inicial.
 */
import assert from "node:assert/strict";
import { afterEach, describe, it } from "node:test";
import type { Card } from "../src/gameTypes.ts";
import { DOUBLE_REJECT_CODE, ENGINE_MESSAGES } from "./gameMessages.ts";
import {
  applyDouble,
  applyHit,
  applyMort,
  applyPlaceBet,
  applySplit,
  applySwap,
  beginGameStart,
  canDoubleNow,
  canSplitNow,
  classifyDoubleReject,
  emptyRoomBase,
  isSplittablePair,
  splitHandBet,
  type GameHost,
  type HandSlot,
  type Player,
  type Room,
} from "./gameEngine.ts";

process.env.SETIMIG_TEST_FAST = "1";

const BET = 100;
const START = 5_000;

const host: GameHost = {
  emitRoomUpdate() {},
  schedule: () => 0 as unknown as ReturnType<typeof setTimeout>,
  clearTimeout() {},
};

function card(value: number, suit: Card["suit"] = "hearts"): Card {
  return { suit, value, points: value >= 10 ? 0.5 : value };
}

function slot(values: number[], extra: Partial<HandSlot> = {}): HandSlot {
  return {
    id: `s${values.join("-")}`,
    bet: BET,
    cards: values.map((value, i) => ({
      id: `c${i}-${value}`,
      card: card(value, i === 0 ? "spades" : "clubs"),
      faceUp: i > 0,
    })),
    doubled: false,
    canDouble: true,
    mort: false,
    blindPair: false,
    blindUntilBankEnd: false,
    mortOffered: false,
    status: "playing",
    ...extra,
  };
}

function playing(hand: HandSlot, deck: number[]): { room: Room; player: Player } {
  const room = emptyRoomBase("regles", "Regles", BET, 0);
  room.houseRulesEnabled = true;
  room.phase = "playing";
  room.deck = deck.map((value, i) => card(value, (["hearts", "diamonds", "clubs", "spades"] as const)[i % 4]!));
  const bank: Player = {
    id: "bank",
    playerId: "bank",
    seatToken: "bank",
    name: "Banca",
    chips: 50_000,
    bet: 0,
    isBanker: true,
    status: "waiting",
    handSlots: [slot([6], { bet: 0, canDouble: false })],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
  };
  const player: Player = {
    id: "edu",
    playerId: "edu",
    seatToken: "edu",
    name: "Edu",
    chips: START - hand.bet,
    bet: hand.bet,
    isBanker: false,
    status: "playing",
    handSlots: [hand],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
  };
  room.players = [bank, player];
  room.turnPlayerIndex = 0;
  room.pot = hand.bet;
  return { room, player };
}

describe("1. doblar només amb la primera carta", () => {
  it("amb una carta es pot doblar; després de demanar-ne una altra, no", () => {
    const { room, player } = playing(slot([4]), [6, 2]);
    assert.equal(classifyDoubleReject(room, player.id), null);
    assert.equal(canDoubleNow(room, player), true);
    assert.equal(applyHit(host, room, player.id), null);
    assert.equal(player.handSlots[0]!.cards.length, 2);
    const rejected = classifyDoubleReject(room, player.id);
    assert.equal(rejected?.code, DOUBLE_REJECT_CODE.wrongCards);
    assert.equal(applyDouble(host, room, player.id), ENGINE_MESSAGES.cannotDouble);
    assert.equal(player.handSlots[0]!.doubled, false);
    assert.equal(player.handSlots[0]!.cards.length, 2);
  });
});

describe("2. separar el mateix valor; les figures compten juntes", () => {
  it("5+5 es pot separar i 5+6 no", () => {
    assert.equal(isSplittablePair([card(5), card(5, "clubs")]), true);
    assert.equal(isSplittablePair([card(5), card(6)]), false);
    const same = playing(slot([5, 5]), [1, 2]);
    assert.equal(canSplitNow(same.room, same.player), true);
    assert.equal(applySplit(same.room, same.player.id), null);
    assert.equal(same.player.handSlots.length, 2);
    const diff = playing(slot([5, 6]), []);
    assert.equal(canSplitNow(diff.room, diff.player), false);
    assert.equal(applySplit(diff.room, diff.player.id), ENGINE_MESSAGES.splitUnavailable);
  });

  it("figures diferents es poden separar", () => {
    assert.equal(isSplittablePair([card(10), card(12)]), true);
    assert.equal(isSplittablePair([card(11), card(10)]), true);
    const { room, player } = playing(slot([10, 12]), [2, 3]);
    assert.equal(applySplit(room, player.id), null);
    assert.deepEqual(
      player.handSlots.map((h) => h.cards[0]!.card.value),
      [10, 12],
    );
  });
});

describe("3 i 4. separar després de doblar, amb l'aposta doblada a cada mà", () => {
  it("splitHandBet segueix sent l'aposta de la mà, ja doblada", () => {
    const hand = slot([11]);
    assert.equal(splitHandBet(hand), BET);
    hand.bet = BET * 2;
    hand.doubled = true;
    assert.equal(splitHandBet(hand), BET * 2);
  });

  it("després de doblar, les dues mans porten l'aposta doblada", () => {
    const { room, player } = playing(slot([12]), [4, 3, 10]);
    assert.equal(applyDouble(host, room, player.id), null);
    assert.equal(player.handSlots[0]!.bet, BET * 2);
    assert.equal(canSplitNow(room, player), true);
    assert.equal(applySplit(room, player.id), null);
    assert.equal(player.handSlots.length, 2);
    assert.deepEqual(
      player.handSlots.map((h) => h.bet),
      [BET * 2, BET * 2],
    );
    assert.equal(player.bet, BET * 4);
    assert.equal(player.chips, START - BET * 4);
  });
});

describe("5. una mà separada no pot doblar", () => {
  it("sense haver doblat abans: SPLIT_CANNOT_DOUBLE i canDouble false", () => {
    const { room, player } = playing(slot([10, 11]), [2, 4]);
    assert.equal(applySplit(room, player.id), null);
    assert.equal(player.handSlots.every((h) => h.canDouble === false && h.fromSplit && !h.splitFromDoubled), true);
    assert.equal(canDoubleNow(room, player), false);
    const rejected = classifyDoubleReject(room, player.id);
    assert.equal(rejected?.code, DOUBLE_REJECT_CODE.splitCannotDouble);
    assert.equal(applyDouble(host, room, player.id), ENGINE_MESSAGES.splitCannotDouble);
    assert.equal(player.handSlots[0]!.bet, BET);
    assert.equal(player.handSlots[0]!.cards.length, 2);
  });

  it("després de doblar: SPLIT_ALREADY_DOUBLED, també en un re-split", () => {
    const { room, player } = playing(slot([12]), [3, 6, 2, 11, 10]);
    assert.equal(applyDouble(host, room, player.id), null);
    assert.equal(applySplit(room, player.id), null);
    assert.equal(player.handSlots.every((h) => h.splitFromDoubled && h.canDouble === false && h.doubled === false), true);
    assert.equal(classifyDoubleReject(room, player.id)?.code, DOUBLE_REJECT_CODE.splitAlreadyDoubled);
    assert.equal(player.handSlots[0]!.cards.map((c) => c.card.value).join(","), "12,11");
    assert.equal(applySplit(room, player.id), null);
    assert.equal(player.handSlots[0]!.splitFromDoubled, true);
    assert.equal(classifyDoubleReject(room, player.id)?.code, DOUBLE_REJECT_CODE.splitAlreadyDoubled);
    assert.equal(player.handSlots.every((h) => h.bet === BET * 2), true);
  });
});

describe("6. re-split sense límit", () => {
  it("una mà que ve d'un split es torna a separar, més enllà de 3 mans", () => {
    // pop: 11, 2, 10, 3, 12, 4, 5, 6 → quatre separates, cinc mans.
    const { room, player } = playing(slot([10, 12]), [6, 5, 4, 12, 3, 10, 2, 11]);
    assert.equal(applySplit(room, player.id), null);
    assert.equal(applySplit(room, player.id), null);
    assert.equal(applySplit(room, player.id), null);
    assert.equal(player.handSlots.length, 4);
    assert.equal(canSplitNow(room, player), true);
    assert.equal(applySplit(room, player.id), null);
    assert.equal(player.handSlots.length, 5);
    assert.equal(player.handSlots.every((h) => h.fromSplit && h.canDouble === false), true);
    assert.equal(player.bet, BET * 5);
  });
});

describe("7. després del canvi del 4, la mà és inicial", () => {
  const prevFlag = process.env.SETIMIG_TEST_SEEDED_DECK;
  const prevNode = process.env.NODE_ENV;

  afterEach(() => {
    if (prevFlag === undefined) delete process.env.SETIMIG_TEST_SEEDED_DECK;
    else process.env.SETIMIG_TEST_SEEDED_DECK = prevFlag;
    if (prevNode === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = prevNode;
  });

  function queuedHost(): GameHost & { flush(): void } {
    const queued: Array<() => void> = [];
    return {
      emitRoomUpdate() {},
      schedule(fn) {
        queued.push(fn as () => void);
        return queued.length as unknown as ReturnType<typeof setTimeout>;
      },
      clearTimeout() {},
      flush() {
        queued.shift()?.();
      },
    };
  }

  function privateHand(seed: number) {
    process.env.SETIMIG_TEST_SEEDED_DECK = "1";
    delete process.env.NODE_ENV;
    const clock = queuedHost();
    const room = emptyRoomBase(`llavor-${seed}`, "Prova", BET, 0);
    room.isPrivate = true;
    room.houseRulesEnabled = true;
    room.autoFillBots = false;
    room.testDeckSeed = seed;
    const seat = (id: string): Player => ({
      id,
      playerId: `pid-${id}`,
      seatToken: `tok-${id}`,
      name: id,
      chips: 20_000,
      bet: 0,
      isBanker: false,
      status: "waiting",
      handSlots: [],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    });
    room.players = [seat("host"), seat("guest")];
    beginGameStart(clock, room);
    clock.flush();
    const player = room.players.find((p) => !p.isBanker)!;
    assert.equal(applyPlaceBet(room, player, BET, clock), null);
    return { room, clock, player };
  }

  it("llavor 131: el canvi del 4 dona un ½ i es pot doblar", () => {
    const { room, clock, player } = privateHand(131);
    assert.equal(player.id, "host");
    assert.equal(player.handSlots[0]!.cards[0]!.card.value, 4);
    assert.equal(applySwap(clock, room, player.id, true), null);
    const got = player.handSlots[0]!.cards[0]!.card;
    assert.equal(got.value, 11);
    assert.equal(got.suit, "hearts");
    assert.equal(player.handSlots[0]!.swapOffered ?? null, null);
    assert.equal(player.handSlots[0]!.mortOffered, false);
    assert.equal(canDoubleNow(room, player), true);
    assert.equal(applyDouble(clock, room, player.id), null);
    assert.equal(player.handSlots[0]!.bet, BET * 2);
    assert.equal(player.handSlots[0]!.cards[1]!.card.value, 1);
    assert.equal(classifyDoubleReject(room, player.id)?.code, DOUBLE_REJECT_CODE.alreadyDoubled);
  });

  it("llavor 33: el canvi del 4 dona un 7 i cal decidir el Mort abans de doblar", () => {
    const { room, clock, player } = privateHand(33);
    assert.equal(player.id, "host");
    assert.equal(applySwap(clock, room, player.id, true), null);
    assert.equal(player.handSlots[0]!.cards[0]!.card.value, 7);
    assert.equal(player.handSlots[0]!.cards[0]!.card.suit, "diamonds");
    assert.equal(player.handSlots[0]!.mortOffered, true);
    assert.equal(classifyDoubleReject(room, player.id)?.code, DOUBLE_REJECT_CODE.decideMortFirst);
    assert.equal(applyHit(clock, room, player.id), ENGINE_MESSAGES.decideMortFirst);
    assert.equal(applyMort(clock, room, player.id, false), null);
    assert.equal(canDoubleNow(room, player), true);
    assert.equal(applyDouble(clock, room, player.id), null);
    assert.equal(player.handSlots[0]!.cards[1]!.card.value, 11);
  });

  it("llavor 44: el canvi del 4 dona un 3 i s'aplica la regla del 3", () => {
    const { room, clock, player } = privateHand(44);
    assert.equal(player.id, "host");
    assert.equal(applySwap(clock, room, player.id, true), null);
    const slot = player.handSlots[0]!;
    assert.equal(slot.cards[0]!.card.value, 3);
    assert.equal(slot.cards[0]!.card.suit, "clubs");
    assert.equal(slot.swapOffered, 3);
    assert.equal(classifyDoubleReject(room, player.id)?.code, DOUBLE_REJECT_CODE.decideSwapFirst);
    assert.equal(applySplit(room, player.id), ENGINE_MESSAGES.decideSwapFirst);
    assert.equal(applySwap(clock, room, player.id, true), null);
    assert.equal(slot.blindPair, true);
    assert.equal(slot.status, "stood");
    assert.equal(slot.canDouble, false);
    assert.deepEqual(
      slot.cards.map((c) => c.card.value),
      [10, 5],
    );
  });

  it("llavor 601: després del canvi del 4, dues figures es poden separar amb l'aposta doblada", () => {
    const { room, clock, player } = privateHand(601);
    assert.equal(player.id, "host");
    assert.equal(applySwap(clock, room, player.id, true), null);
    assert.equal(player.handSlots[0]!.cards[0]!.card.value, 11);
    assert.equal(canDoubleNow(room, player), true);
    assert.equal(applyDouble(clock, room, player.id), null);
    assert.deepEqual(
      player.handSlots[0]!.cards.map((c) => c.card.value),
      [11, 10],
    );
    assert.equal(canSplitNow(room, player), true);
    assert.equal(applySplit(room, player.id), null);
    assert.equal(player.handSlots.length, 2);
    assert.deepEqual(
      player.handSlots.map((h) => ({ bet: h.bet, canDouble: h.canDouble, splitFromDoubled: h.splitFromDoubled })),
      [
        { bet: BET * 2, canDouble: false, splitFromDoubled: true },
        { bet: BET * 2, canDouble: false, splitFromDoubled: true },
      ],
    );
    assert.equal(classifyDoubleReject(room, player.id)?.code, DOUBLE_REJECT_CODE.splitAlreadyDoubled);
    assert.deepEqual(
      player.handSlots.map((h) => h.cards.map((c) => c.card.value)),
      [
        [11, 7],
        [10, 5],
      ],
    );
  });
});
