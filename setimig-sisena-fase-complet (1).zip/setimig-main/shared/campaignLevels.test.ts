import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  CAMPAIGN_LEVEL_COUNT,
  CAMPAIGN_LEVELS,
  getCampaignLevel,
  parseCampaignLevelInput,
} from "./campaignLevels.ts";

describe("campaignLevels", () => {
  it("define 10 nivells amb dificultat creixent", () => {
    assert.equal(CAMPAIGN_LEVELS.length, CAMPAIGN_LEVEL_COUNT);
    assert.equal(getCampaignLevel(1)?.botDifficulty, "easy");
    assert.equal(getCampaignLevel(10)?.botDifficulty, "hard");
    assert.equal(getCampaignLevel(0), null);
    assert.equal(getCampaignLevel(11), null);
  });

  it("parseCampaignLevelInput accepta només nivells vàlids", () => {
    assert.equal(parseCampaignLevelInput(undefined), null);
    assert.equal(parseCampaignLevelInput(3), 3);
    assert.equal(parseCampaignLevelInput("4"), 4);
    assert.equal(parseCampaignLevelInput(3.5), null);
    assert.equal(parseCampaignLevelInput(99), null);
  });
});
