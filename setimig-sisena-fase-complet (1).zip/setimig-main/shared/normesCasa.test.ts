/**
 * Normes de la casa (Edu, 28/10/2026; docs/normes-casa.md): 3 i 4 opcionals, 3 canviat paga el doble,
 * doblar no planta, split només amb dues cartes de mig punt, cada mà del split pel seu compte,
 * no es dobla amb el Mort ni amb el 3 canviat, Mort i banca a 7½ → banca, indicador `special` a la vista.
 * I el mode Tradicional (sense normes de la casa) no canvia.
 */
import assert from "node:assert/strict";
import { describe, it } from "node:test";
import type { Card } from "../src/gameTypes.ts";
import {
  applyDouble,
  applyHit,
  applyMort,
  applyPlaceBet,
  applyPlayingTurnTimeoutDefault,
  applyCardPeeked,
  applySplit,
  applyStand,
  applySwap,
  canDoubleNow,
  clearRoomTimers,
  runBotAction,
  currentPlayer,
  currentSlot,
  currentTurnPlayerId,
  emptyRoomBase,
  roomToView,
  settleGame,
  type GameHost,
  type HandSlot,
  type Player,
  type Room,
} from "./gameEngine.ts";
import { ENGINE_MESSAGES } from "./gameMessages.ts";
import { parseGameMessage } from "./gameMessages.ts";

process.env.SETIMIG_TEST_FAST = "1";

const host: GameHost = {
  emitRoomUpdate() {},
  schedule() {
    return null as unknown as ReturnType<typeof setTimeout>;
  },
  clearTimeout() {},
};

const BET = 10;
const START = 1_000;
const BANK_START = 50_000;

function card(value: number, suit: Card["suit"] = "hearts"): Card {
  return { suit, value, points: value >= 10 ? 0.5 : value };
}

function slot(values: number[], o: Partial<HandSlot> = {}): HandSlot {
  return {
    id: `s${Math.random()}`,
    bet: BET,
    cards: values.map((v, i) => ({ id: `c${i}-${Math.random()}`, card: card(v), faceUp: i > 0 })),
    doubled: false,
    canDouble: true,
    mort: false,
    blindPair: false,
    blindUntilBankEnd: false,
    mortOffered: false,
    status: "playing",
    ...o,
  };
}

function seat(id: string, o: Partial<Player> = {}): Player {
  return {
    id,
    playerId: id,
    seatToken: id,
    name: id,
    chips: START - BET,
    bet: BET,
    isBanker: false,
    status: "playing",
    handSlots: [],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
    ...o,
  };
}

/** Taula en joc: banca + p1 amb el torn i la mà donada. `deck`: l'última és la primera que surt. */
function playing(hand: HandSlot, deck: number[], house = true): { room: Room; p1: Player; bank: Player } {
  const room = emptyRoomBase("nc", "NC", BET, 0);
  room.houseRulesEnabled = house;
  room.phase = "playing";
  room.deck = deck.map((v) => card(v, "spades"));
  const bank = seat("bank", { isBanker: true, chips: BANK_START, bet: 0, status: "waiting", handSlots: [slot([5], { bet: 0 })] });
  const p1 = seat("p1", { handSlots: [hand] });
  room.players = [bank, p1];
  room.turnPlayerIndex = 0;
  room.pot = BET;
  room.roundStartChips = new Map([
    ["bank", BANK_START],
    ["p1", START],
  ]);
  return { room, p1, bank };
}

/** Taula en apostes perquè el motor reparteixi la primera carta (la del final de `deck` va a p1). */
function betting(deck: number[], house = true) {
  const room = emptyRoomBase("ncb", "NCB", BET, 0);
  room.houseRulesEnabled = house;
  room.phase = "betting";
  room.deck = deck.map((v) => card(v, "clubs"));
  const bank = seat("bank", { isBanker: true, chips: BANK_START, bet: 0, status: "waiting" });
  const p1 = seat("p1", { chips: START, bet: 0, status: "waiting" });
  room.players = [bank, p1];
  assert.equal(applyPlaceBet(room, p1, BET), null);
  assert.equal(room.phase, "playing");
  return { room, p1, bank };
}

function settleWithBank(room: Room, bank: Player, bankValues: number[]) {
  bank.handSlots = [slot(bankValues, { bet: 0, status: "stood" })];
  room.phase = "banker";
  settleGame(host, room);
  clearRoomTimers(host, room);
}

const view = (room: Room, viewer: string, who = "p1") => roomToView(room, viewer, host).players.find((p) => p.id === who)!;

describe("normes de la casa · 1) el 4 és opcional", () => {
  it("amb un primer 4 s'ofereix jugar o canviar (pendingChoices.swapOffer = 4) i no es pot demanar abans", () => {
    const { room, p1 } = betting([6, 2, 4]);
    const s = p1.handSlots[0]!;
    assert.equal(s.cards[0]!.card.value, 4);
    assert.equal(s.swapOffered, 4);
    assert.equal(view(room, "p1").pendingChoices?.swapOffer, 4);
    assert.equal(view(room, "bank").pendingChoices ?? null, null, "els altres no veuen l'oferta");
    assert.equal(applyHit(host, room, "p1"), ENGINE_MESSAGES.decideSwapFirst);
    assert.equal(applyStand(host, room, "p1"), ENGINE_MESSAGES.decideSwapFirst);
    assert.equal(applyDouble(host, room, "p1"), ENGINE_MESSAGES.decideSwapFirst);
    clearRoomTimers(host, room);
  });
  it("«Jugar»: es queda el 4 i juga normal (pot doblar)", () => {
    const { room, p1 } = betting([6, 2, 4]);
    assert.equal(applySwap(host, room, "p1", false), null);
    const s = p1.handSlots[0]!;
    assert.deepEqual(s.cards.map((c) => c.card.value), [4]);
    assert.equal(s.swapOffered, null);
    assert.equal(canDoubleNow(room, p1), true);
    assert.equal(applyHit(host, room, "p1"), null);
    clearRoomTimers(host, room);
  });
  it("«Canviar»: descarta el 4, rep 1 carta tapada que ell veu (els altres no) i juga normal", () => {
    const { room, p1 } = betting([6, 2, 4]);
    assert.equal(applySwap(host, room, "p1", true), null);
    const s = p1.handSlots[0]!;
    assert.equal(s.cards.length, 1);
    assert.notEqual(s.cards[0]!.card.value, 4);
    assert.equal(s.cards[0]!.faceUp, false);
    assert.equal(s.swappedFour, true);
    assert.ok(room.centerDiscard.some((c) => c.value === 4));
    assert.notEqual(view(room, "p1").handSlots[0]!.cards[0]!.card, null, "el propietari la veu");
    assert.equal(view(room, "bank").handSlots[0]!.cards[0]!.card, null, "els altres no");
    assert.equal(view(room, "p1").handSlots[0]!.special ?? null, null, "el 4 canviat no és mà especial");
    assert.equal(canDoubleNow(room, p1), true, "pot doblar");
    assert.equal(applyHit(host, room, "p1"), null, "pot demanar");
    clearRoomTimers(host, room);
  });
  it("el temps esgotat tria «Jugar»", () => {
    const { room, p1 } = betting([6, 2, 4]);
    applyPlayingTurnTimeoutDefault(host, room, "p1");
    assert.deepEqual(p1.handSlots[0]!.cards.map((c) => c.card.value), [4]);
    assert.equal(p1.handSlots[0]!.swapOffered, null);
    clearRoomTimers(host, room);
  });
  it("4→4: es torna a oferir el canvi (termini nou) i es pot canviar una altra vegada", () => {
    for (const mode of [
      { soloAi: false, practiceMode: false },
      { soloAi: true, practiceMode: false },
      { soloAi: true, practiceMode: true },
    ]) {
      const { room, p1 } = betting([3, 6, 4, 2, 4]);
      room.soloAi = mode.soloAi;
      room.practiceMode = mode.practiceMode;
      room.mortDeadlineAt = 1;
      const firstId = p1.handSlots[0]!.cards[0]!.id;
      assert.equal(applySwap(host, room, "p1", true), null);
      const s = p1.handSlots[0]!;
      assert.equal(s.cards[0]!.card.value, 4);
      assert.notEqual(s.cards[0]!.id, firstId);
      assert.equal(s.swapOffered, 4);
      assert.equal(view(room, "p1").pendingChoices?.swapOffer, 4);
      const deadline = view(room, "p1").pendingChoices?.swapDeadline;
      if (mode.practiceMode) assert.equal(deadline, undefined);
      else assert.ok(typeof deadline === "number" && deadline > 1);
      assert.equal(applyHit(host, room, "p1"), ENGINE_MESSAGES.decideSwapFirst);
      assert.equal(applySwap(host, room, "p1", true), null);
      assert.equal(s.cards[0]!.card.value, 6);
      assert.equal(s.swapOffered ?? null, null);
      assert.equal(view(room, "p1").pendingChoices?.swapOffer, undefined);
      assert.equal(applyHit(host, room, "p1"), null);
      clearRoomTimers(host, room);
    }

    const toThree = betting([5, 3, 2, 4]);
    assert.equal(applySwap(host, toThree.room, "p1", true), null);
    assert.equal(toThree.p1.handSlots[0]!.cards[0]!.card.value, 3);
    assert.equal(toThree.p1.handSlots[0]!.swapOffered, 3);
    assert.equal(view(toThree.room, "p1").pendingChoices?.swapOffer, 3);
    assert.equal(applyHit(host, toThree.room, "p1"), ENGINE_MESSAGES.decideSwapFirst);
    assert.equal(applyDouble(host, toThree.room, "p1"), ENGINE_MESSAGES.decideSwapFirst);
    clearRoomTimers(host, toThree.room);

    const toSeven = betting([5, 7, 2, 4]);
    assert.equal(applySwap(host, toSeven.room, "p1", true), null);
    assert.equal(toSeven.p1.handSlots[0]!.cards[0]!.card.value, 7);
    assert.equal(toSeven.p1.handSlots[0]!.swapOffered ?? null, null);
    assert.equal(toSeven.p1.handSlots[0]!.mortOffered, true);
    assert.equal(view(toSeven.room, "p1").pendingChoices?.canMort, true);
    assert.equal(view(toSeven.room, "p1").pendingChoices?.swapOffer, undefined);
    clearRoomTimers(host, toSeven.room);
  });
  it("4→4: si el temps s'esgota es queda el 4 i juga normal", () => {
    const { room, p1 } = betting([6, 4, 2, 4]);
    assert.equal(applySwap(host, room, "p1", true), null);
    const s = p1.handSlots[0]!;
    const keptId = s.cards[0]!.id;
    assert.equal(s.cards[0]!.card.value, 4);
    assert.equal(s.swapOffered, 4);
    applyPlayingTurnTimeoutDefault(host, room, "p1");
    assert.equal(s.cards[0]!.id, keptId);
    assert.deepEqual(s.cards.map((c) => c.card.value), [4]);
    assert.equal(s.swapOffered ?? null, null);
    assert.equal(room.phase, "playing");
    assert.equal(applyHit(host, room, "p1"), null);
    clearRoomTimers(host, room);
  });
  it("mortDeadline i swapDeadline només els veu el propietari", () => {
    const { room, p1, bank } = playing(slot([4], { swapOffered: 4 }), []);
    room.mortDeadlineAt = 50_000_000_000;
    const owner = roomToView(room, "p1", host);
    const rival = roomToView(room, "bank", host);
    assert.equal(owner.mortDeadline, room.mortDeadlineAt);
    assert.equal(owner.players.find((p) => p.id === "p1")!.pendingChoices?.swapDeadline, room.mortDeadlineAt);
    assert.equal(rival.mortDeadline, null);
    assert.equal(rival.players.find((p) => p.id === p1.id)!.pendingChoices ?? null, null);
    assert.equal(rival.players.find((p) => p.id === bank.id)!.pendingChoices ?? null, null);

    const mort = playing(slot([7], { mortOffered: true, canDouble: false }), []);
    mort.room.mortDeadlineAt = 50_000_000_000;
    const mortOwner = roomToView(mort.room, "p1", host);
    const mortRival = roomToView(mort.room, "bank", host);
    assert.equal(mortOwner.mortDeadline, mort.room.mortDeadlineAt);
    assert.equal(mortOwner.players.find((p) => p.id === "p1")!.pendingChoices?.mortDeadline, mort.room.mortDeadlineAt);
    assert.equal(mortRival.mortDeadline, null);
    assert.equal(mortRival.players.find((p) => p.id === "p1")!.pendingChoices ?? null, null);
    clearRoomTimers(host, room);
    clearRoomTimers(host, mort.room);
  });
  it("card_peeked arrenca el termini (turnMs) i un duplicat no el mou", () => {
    const { room, p1, bank } = playing(slot([4], { swapOffered: 4 }), []);
    const cardId = p1.handSlots[0]!.cards[0]!.id;
    const safety = Date.now() + 999_999;
    room.mortDeadlineAt = safety;
    assert.equal(applyCardPeeked(room, bank.id, cardId), false);
    assert.equal(applyCardPeeked(room, "p1", "altra"), false);
    assert.equal(room.mortDeadlineAt, safety);
    const before = Date.now();
    assert.equal(applyCardPeeked(room, "p1", cardId), true);
    const started = room.mortDeadlineAt!;
    assert.ok(started < safety);
    assert.ok(started >= before);
    assert.ok(started - before < 60_000);
    assert.equal(applyCardPeeked(room, "p1", cardId), false);
    assert.equal(room.mortDeadlineAt, started);
    assert.equal(roomToView(room, "p1", host).mortDeadline, started);
    assert.equal(roomToView(room, "bank", host).mortDeadline, null);

    const prac = playing(slot([3], { swapOffered: 3 }), []);
    prac.room.practiceMode = true;
    prac.room.soloAi = true;
    prac.room.mortDeadlineAt = null;
    const id3 = prac.p1.handSlots[0]!.cards[0]!.id;
    assert.equal(applyCardPeeked(prac.room, "p1", id3), true);
    assert.equal(prac.room.mortDeadlineAt ?? null, null);
    assert.equal(applyCardPeeked(prac.room, "p1", id3), false);
    clearRoomTimers(host, room);
    clearRoomTimers(host, prac.room);
  });
  it("després del peek, el temps esgotat segueix igual: Mort juga, el 4 es queda, el 3 també", () => {
    const mort = betting([6, 2, 7]);
    assert.equal(applyCardPeeked(mort.room, "p1", mort.p1.handSlots[0]!.cards[0]!.id), true);
    applyPlayingTurnTimeoutDefault(host, mort.room, "p1");
    assert.equal(mort.p1.handSlots[0]!.mort, false);
    assert.equal(mort.p1.handSlots[0]!.mortOffered, false);
    assert.equal(mort.p1.handSlots[0]!.cards[0]!.card.value, 7);
    assert.equal(mort.room.phase, "playing");
    clearRoomTimers(host, mort.room);

    const four = betting([6, 2, 4]);
    assert.equal(applyCardPeeked(four.room, "p1", four.p1.handSlots[0]!.cards[0]!.id), true);
    applyPlayingTurnTimeoutDefault(host, four.room, "p1");
    assert.deepEqual(four.p1.handSlots[0]!.cards.map((c) => c.card.value), [4]);
    assert.equal(four.p1.handSlots[0]!.swapOffered ?? null, null);
    assert.equal(four.room.phase, "playing");
    clearRoomTimers(host, four.room);

    const three = betting([6, 2, 3]);
    assert.equal(applyCardPeeked(three.room, "p1", three.p1.handSlots[0]!.cards[0]!.id), true);
    applyPlayingTurnTimeoutDefault(host, three.room, "p1");
    assert.deepEqual(three.p1.handSlots[0]!.cards.map((c) => c.card.value), [3]);
    assert.equal(three.p1.handSlots[0]!.swapOffered ?? null, null);
    assert.equal(three.room.phase, "playing");
    assert.equal(applyHit(host, three.room, "p1"), null);
    clearRoomTimers(host, three.room);
  });
  it("un bot encadena els 4 i s'atura quan el munt s'acaba", () => {
    const { room, p1 } = playing(slot([4], { swapOffered: 4 }), []);
    p1.isBot = true;
    room.soloAi = true;
    room.deck = [card(4, "clubs"), card(4, "diamonds"), card(4, "spades")];
    room.centerDiscard = [card(4, "hearts"), card(4, "hearts")];
    let steps = 0;
    while (p1.handSlots[0]!.swapOffered && steps < 8) {
      runBotAction(host, room, p1);
      steps += 1;
    }
    assert.equal(steps, 4);
    assert.equal(p1.handSlots[0]!.swapOffered ?? null, null);
    assert.equal(p1.handSlots[0]!.cards.length, 1);
    assert.equal(p1.handSlots[0]!.cards[0]!.card.value, 4);
    assert.equal(room.phase, "playing");
    assert.equal(currentPlayer(room)?.id, "p1");
    clearRoomTimers(host, room);
  });
});

describe("normes de la casa · 2) el 3 és opcional", () => {
  it("«Jugar normal»: es queda el 3, una sola carta tapada i flux normal", () => {
    const { room, p1 } = betting([6, 2, 3]);
    assert.equal(p1.handSlots[0]!.swapOffered, 3);
    assert.equal(view(room, "p1").pendingChoices?.swapOffer, 3);
    assert.equal(applySwap(host, room, "p1", false), null);
    const s = p1.handSlots[0]!;
    assert.deepEqual(s.cards.map((c) => c.card.value), [3]);
    assert.equal(s.blindPair, false);
    assert.equal(applyHit(host, room, "p1"), null);
    clearRoomTimers(host, room);
  });
  it("«Canviar per 2 tapades»: no les veu ningú i el servidor planta; el torn passa a la banca", () => {
    const { room, p1 } = betting([11, 10, 6, 2, 3]);
    assert.equal(applySwap(host, room, "p1", true), null);
    const s = p1.handSlots[0]!;
    assert.equal(s.blindPair, true);
    assert.equal(s.status, "stood");
    assert.equal(p1.lastHandAction, "Canvia");
    assert.equal(s.cards.length, 2);
    assert.equal(room.phase, "banker");
    assert.equal(currentTurnPlayerId(room), "bank");
    assert.ok(room.centerDiscard.some((c) => c.value === 3));
    for (const viewer of ["p1", "bank"]) {
      assert.deepEqual(view(room, viewer).handSlots[0]!.cards.map((c) => c.card), [null, null]);
    }
    assert.equal(applyHit(host, room, "p1"), ENGINE_MESSAGES.bankTurn);
    assert.equal(applyStand(host, room, "p1"), ENGINE_MESSAGES.bankTurn);
    assert.equal(applyDouble(host, room, "p1"), ENGINE_MESSAGES.cannotDoubleNow);
    assert.equal(applySplit(room, "p1"), "BAD");
    clearRoomTimers(host, room);
  });
  it("canviar el 3 acaba el torn en solo, pràctica, bots i amb un jugador següent", () => {
    for (const mode of [
      { soloAi: true, practiceMode: false, bot: false },
      { soloAi: true, practiceMode: true, bot: false },
      { soloAi: false, practiceMode: false, bot: true },
    ]) {
      const { room, p1 } = playing(slot([3], { swapOffered: 3 }), [4, 2]);
      room.soloAi = mode.soloAi;
      room.practiceMode = mode.practiceMode;
      if (mode.bot) p1.isBot = true;
      assert.equal(applySwap(host, room, "p1", true), null);
      assert.equal(p1.handSlots[0]!.status, "stood");
      assert.equal(p1.handSlots[0]!.blindPair, true);
      assert.equal(room.phase, "banker");
      assert.equal(applyHit(host, room, "p1"), ENGINE_MESSAGES.bankTurn);
      assert.equal(applyStand(host, room, "p1"), ENGINE_MESSAGES.bankTurn);
      assert.equal(applyDouble(host, room, "p1"), ENGINE_MESSAGES.cannotDoubleNow);
      assert.equal(applySplit(room, "p1"), "BAD");
      clearRoomTimers(host, room);
    }

    const { room, p1, bank } = playing(slot([3], { swapOffered: 3 }), [4, 2]);
    const p2 = seat("p2", { handSlots: [slot([6])] });
    room.players = [bank, p1, p2];
    room.pot = BET * 2;
    assert.equal(applySwap(host, room, "p1", true), null);
    assert.equal(room.phase, "playing");
    assert.equal(currentPlayer(room)?.id, "p2");
    assert.equal(p1.handSlots[0]!.status, "stood");
    assert.equal(applyHit(host, room, "p1"), ENGINE_MESSAGES.notYourTurn);
    assert.equal(applyStand(host, room, "p1"), ENGINE_MESSAGES.notYourTurn);
    assert.equal(applyDouble(host, room, "p1"), ENGINE_MESSAGES.cannotDoubleNow);
    assert.equal(applySplit(room, "p1"), "BAD");
    assert.equal(applyStand(host, room, "p2"), null);
    clearRoomTimers(host, room);
  });
  it("no es pot canviar dues vegades ni sense oferta", () => {
    const { room } = betting([6, 2, 3]);
    assert.equal(applySwap(host, room, "p1", true), null);
    assert.equal(applySwap(host, room, "p1", true), ENGINE_MESSAGES.invalidAction);
    clearRoomTimers(host, room);
    const n = betting([6, 2, 5]);
    assert.equal(applySwap(host, n.room, "p1", true), ENGINE_MESSAGES.swapUnavailable);
    clearRoomTimers(host, n.room);
  });
});

describe("normes de la casa · 3) el 3 canviat cobra el doble", () => {
  const threeSwap = (values: number[]) => {
    const h = slot(values, { blindPair: true, blindUntilBankEnd: true, canDouble: false, status: "stood" });
    h.cards.forEach((c) => (c.faceUp = false));
    return h;
  };
  it("aposta 10 que guanya (6 contra 5) → +20, highlight specialWin", () => {
    const { room, p1, bank } = playing(threeSwap([4, 2]), []);
    settleWithBank(room, bank, [5]);
    assert.equal(p1.chips - START, 20);
    assert.equal(bank.chips - BANK_START, -20);
    const h = room.lastRound!.highlights.find((x) => x.name === "p1")!;
    assert.equal(h.code, "specialWin");
    assert.equal((h.params as { special: string }).special, "threeSwap");
    assert.equal((h.params as { amount: number }).amount, 20);
    assert.equal(parseGameMessage(h.text)?.code, "engine.result.specialWin");
  });
  it("guanya perquè la banca es passa → també +20", () => {
    const { room, p1, bank } = playing(threeSwap([4, 2]), []);
    settleWithBank(room, bank, [5, 2, 1]);
    assert.equal(p1.chips - START, 20);
  });
  it("perd (5 contra 6) → −10, no −20", () => {
    const { room, p1, bank } = playing(threeSwap([4, 1]), []);
    settleWithBank(room, bank, [6]);
    assert.equal(p1.chips - START, -10);
    assert.equal(bank.chips - BANK_START, 10);
  });
});

describe("normes de la casa · 4) doblar no planta", () => {
  it("després de doblar, si no s'ha passat, continua el torn: pot demanar i plantar-se", () => {
    const { room, p1 } = playing(slot([2]), [7, 3]);
    assert.equal(applyDouble(host, room, "p1"), null);
    const s = p1.handSlots[0]!;
    assert.equal(s.doubled, true);
    assert.equal(s.bet, 20);
    assert.equal(s.status, "playing");
    assert.equal(room.phase, "playing");
    assert.equal(currentSlot(room), s);
    assert.equal(canDoubleNow(room, p1), false, "no es dobla dues vegades");
    assert.equal(applyHit(host, room, "p1"), null);
    assert.equal(s.status, "busted", "2+3+7 es passa");
    clearRoomTimers(host, room);
  });
  it("després de doblar es pot plantar", () => {
    const { room, p1 } = playing(slot([2]), [3]);
    assert.equal(applyDouble(host, room, "p1"), null);
    assert.equal(applyStand(host, room, "p1"), null);
    assert.equal(p1.handSlots[0]!.status, "stood");
    clearRoomTimers(host, room);
  });
  it("si es passa en doblar, la mà acaba", () => {
    const { room, p1 } = playing(slot([6]), [5]);
    assert.equal(applyDouble(host, room, "p1"), null);
    assert.equal(p1.handSlots[0]!.status, "busted");
    clearRoomTimers(host, room);
  });
  it("després de doblar amb dues figures s'ofereix el split, i cada mà porta l'aposta doblada (dubte D)", () => {
    const { room, p1 } = playing(slot([12]), [4, 3, 10]);
    assert.equal(applyDouble(host, room, "p1"), null);
    assert.equal(view(room, "p1").pendingChoices?.canSplit, true);
    assert.equal(applySplit(room, "p1"), null);
    assert.deepEqual(p1.handSlots.map((h) => h.bet), [20, 20]);
    assert.deepEqual(p1.handSlots.map((h) => h.cards.length), [2, 2]);
    assert.equal(p1.handSlots.every((h) => h.doubled === false && h.canDouble === false), true);
    assert.equal(p1.bet, 40);
    assert.equal(p1.chips, START - 40);
    clearRoomTimers(host, room);
  });
  it("separar després de doblar: mans netes amb l'aposta doblada, dues cartes i liquidació coherent", () => {
    const { room, p1, bank } = playing(slot([12]), [6, 6, 10]);
    assert.equal(applyDouble(host, room, "p1"), null);
    assert.equal(applySplit(room, "p1"), null);
    assert.deepEqual(
      p1.handSlots.map((h) => ({
        bet: h.bet,
        doubled: h.doubled,
        canDouble: h.canDouble,
        cards: h.cards.length,
      })),
      [
        { bet: 20, doubled: false, canDouble: false, cards: 2 },
        { bet: 20, doubled: false, canDouble: false, cards: 2 },
      ]
    );
    assert.equal(p1.bet, 40);
    assert.equal(room.pot, 40);
    assert.equal(canDoubleNow(room, p1), false);
    assert.equal(applyDouble(host, room, "p1"), ENGINE_MESSAGES.splitAlreadyDoubled);

    assert.equal(applyStand(host, room, "p1"), null);
    assert.equal(p1.activeSlotIndex, 1);
    assert.equal(canDoubleNow(room, p1), false, "la segona mà tampoc no es pot doblar");
    assert.equal(applyDouble(host, room, "p1"), ENGINE_MESSAGES.splitAlreadyDoubled);
    assert.equal(applyStand(host, room, "p1"), null);

    settleWithBank(room, bank, [5]);
    assert.equal(p1.chips - START, 40, "+20 per cada mà amb l'aposta doblada");
    assert.equal(bank.chips - BANK_START, -40);
    const wins = room.lastRound!.highlights.filter((h) => h.name === "p1");
    assert.deepEqual(
      wins.map((h) => [h.code, (h.params as { hand: number; amount: number }).hand, (h.params as { amount: number }).amount]),
      [
        ["win", 0, 20],
        ["win", 1, 20],
      ]
    );
    const seat = room.lastSettlement!.seats.find((s) => s.playerId === "p1")!;
    assert.deepEqual(
      seat.slots.map((s) => ({ bet: s.bet, doubled: s.doubled, points: s.points })),
      [
        { bet: 20, doubled: false, points: 6.5 },
        { bet: 20, doubled: false, points: 6.5 },
      ]
    );
    assert.equal(seat.chipDelta, 40);
    clearRoomTimers(host, room);
  });
});

describe("normes de la casa · 5) split amb el mateix valor o dues figures", () => {
  it("Sota+Rei es pot separar", () => {
    const { room, p1 } = playing(slot([10, 12], { canDouble: false }), []);
    assert.equal(applySplit(room, "p1"), null);
    assert.equal(p1.handSlots.length, 2);
    clearRoomTimers(host, room);
  });
  it("5+5 es pot separar; 5+6 no", () => {
    const same = playing(slot([5, 5], { canDouble: false }), [2, 3]);
    assert.equal(applySplit(same.room, "p1"), null);
    assert.equal(same.p1.handSlots.length, 2);
    assert.equal(same.p1.handSlots.every((h) => h.canDouble === false), true);
    clearRoomTimers(host, same.room);
    const { room, p1 } = playing(slot([5, 6], { canDouble: false }), []);
    assert.equal(applySplit(room, "p1"), ENGINE_MESSAGES.splitUnavailable);
    assert.equal(p1.handSlots.length, 1);
    clearRoomTimers(host, room);
  });
});

describe("normes de la casa · 6) cada mà del split es liquida pel seu compte", () => {
  it("2 mans de 10 guanyadores cobren +10 i +10 encara que un altre jugador perdi", () => {
    const { room, p1, bank } = playing(slot([6], { status: "stood" }), []);
    p1.handSlots.push(slot([7], { status: "stood" }));
    p1.bet = 20;
    p1.chips = START - 20;
    const p2 = seat("p2", { handSlots: [slot([6, 5], { status: "busted" })] });
    room.players.push(p2);
    room.pot = 30;
    room.roundStartChips!.set("p2", START);
    settleWithBank(room, bank, [5]);
    assert.equal(p1.chips - START, 20, "+10 per cada mà");
    const hs = room.lastRound!.highlights.filter((h) => h.name === "p1");
    assert.deepEqual(hs.map((h) => [h.code, (h.params as { hand: number }).hand, (h.params as { amount: number }).amount]), [
      ["win", 0, 10],
      ["win", 1, 10],
    ]);
    assert.equal(p2.chips - START, -10);
  });
  it("split doblat: cada mà guanyadora cobra la seva aposta doblada (+20 i +20)", () => {
    const { room, p1, bank } = playing(slot([6], { status: "stood", bet: 20, doubled: true }), []);
    p1.handSlots.push(slot([7], { status: "stood", bet: 20 }));
    p1.bet = 40;
    p1.chips = START - 40;
    room.pot = 40;
    settleWithBank(room, bank, [5]);
    assert.equal(p1.chips - START, 40);
  });
});

describe("normes de la casa · Mort (dubtes B i C) i indicador special", () => {
  it("no es pot doblar amb el Mort ni separar-lo", () => {
    const h = slot([7, 12], { mort: true, blindUntilBankEnd: true, canDouble: true });
    const { room, p1 } = playing(h, []);
    assert.equal(canDoubleNow(room, p1), false);
    assert.equal(applySplit(room, "p1"), ENGINE_MESSAGES.splitUnavailable);
    clearRoomTimers(host, room);
  });
  it("Mort a 7½ i banca a 7½ → guanya la banca (perd 10)", () => {
    const h = slot([7, 12], { mort: true, blindUntilBankEnd: true, status: "stood" });
    const { room, p1, bank } = playing(h, []);
    settleWithBank(room, bank, [7, 10]);
    assert.equal(p1.chips - START, -10);
  });
  it("Mort 7+4 fa 11, perd l'aposta i no és un passat; la liquidació envia aquestes dues cartes", () => {
    const dealt = betting([4, 6, 7]);
    const offer = view(dealt.room, "p1").pendingChoices;
    const seven = dealt.p1.handSlots[0]!.cards[0]!;
    assert.equal(offer?.canMort, true);
    assert.equal(offer?.swapOffer, undefined);
    assert.equal(offer?.offerCardId, seven.id);
    assert.equal(seven.card.value, 7);
    assert.equal(applyMort(host, dealt.room, "p1", true), null);
    const mortCards = dealt.p1.handSlots[0]!.cards;
    assert.deepEqual(mortCards.map((c) => c.card.value), [7, 4]);
    assert.equal(dealt.p1.handSlots[0]!.status, "stood");
    settleWithBank(dealt.room, dealt.bank, [6]);
    const line = dealt.room.lastRound!.results.find((r) => r.name === "p1")!;
    assert.equal(line.outcome, "lose");
    assert.equal(line.handPoints, undefined);
    assert.equal(line.chipDelta, -BET);
    const highlight = dealt.room.lastRound!.highlights.find((h) => h.name === "p1")!;
    assert.equal(highlight.code, "mortLoses");
    assert.equal((highlight.params as { score: number }).score, 11);
    const shown = view(dealt.room, "p1").handSlots[0]!.cards.map((c) => c.card?.value);
    assert.deepEqual(shown, [7, 4]);
    clearRoomTimers(host, dealt.room);
  });
  it("un 3 o un 4 no ofereix el Mort; l'oferta porta la carta", () => {
    for (const rank of [3, 4] as const) {
      const { room, p1 } = betting([6, 2, rank]);
      const pending = view(room, "p1").pendingChoices;
      const first = p1.handSlots[0]!.cards[0]!;
      assert.equal(first.card.value, rank);
      assert.equal(pending?.canMort, undefined);
      assert.equal(pending?.swapOffer, rank);
      assert.equal(pending?.offerCardId, first.id);
      assert.equal(view(room, "bank").pendingChoices ?? null, null);
      clearRoomTimers(host, room);
    }
  });
  it("la liquidació de la banca suma la carta que era tapada i, si passa, es passa", () => {
    const { room, bank } = playing(slot([6], { status: "stood" }), []);
    // 4 tapada + rei + 6 de bastos = 4 + ½ + 6 = 10½, no 6½ (rei + 6).
    const hand = slot([4, 12, 6], { bet: 0, status: "stood" });
    hand.cards[0]!.faceUp = false;
    hand.cards[2]!.card = card(6, "clubs");
    bank.handSlots = [hand];
    room.phase = "banker";
    settleGame(host, room);
    clearRoomTimers(host, room);
    const bankLine = room.lastRound!.results.find((r) => r.name === "bank")!;
    assert.equal(bankLine.handPoints, 10.5);
    const playerLine = room.lastRound!.results.find((r) => r.name === "p1")!;
    assert.ok(playerLine.chipDelta > 0, "la banca passada paga");
    assert.equal(hand.cards.every((c) => c.faceUp), true);
    const shown = view(room, "p1", "bank").handSlots[0]!.cards;
    assert.deepEqual(shown.map((c) => c.card?.value), [4, 12, 6]);
    assert.equal(shown.every((c) => c.faceUp), true);
  });
  it("Mort guanyador → +20 (doble) amb specialWin «mort»; Mort passat → −10", () => {
    const w = playing(slot([7, 12], { mort: true, blindUntilBankEnd: true, status: "stood" }), []);
    settleWithBank(w.room, w.bank, [6]);
    assert.equal(w.p1.chips - START, 20);
    const h = w.room.lastRound!.highlights.find((x) => x.name === "p1")!;
    assert.equal(h.code, "specialWin");
    assert.equal((h.params as { special: string }).special, "mort");
    const l = playing(slot([7, 5], { mort: true, blindUntilBankEnd: true, status: "stood" }), []);
    settleWithBank(l.room, l.bank, [6]);
    assert.equal(l.p1.chips - START, -10);
    const lh = l.room.lastRound!.highlights.find((x) => x.name === "p1")!;
    assert.equal(lh.code, "mortLoses");
    assert.equal((lh.params as { special?: string }).special, "mort");
  });
  it("la vista porta special = «mort» / «threeSwap» per a tots els espectadors; null en mans normals", () => {
    const m = betting([12, 6, 7]);
    assert.equal(view(m.room, "p1").pendingChoices?.canMort, true);
    assert.equal(applyMort(host, m.room, "p1", true), null);
    for (const v of ["p1", "bank"]) assert.equal(view(m.room, v).handSlots[0]!.special, "mort");
    clearRoomTimers(host, m.room);
    const t = betting([11, 10, 6, 2, 3]);
    assert.equal(view(t.room, "p1").handSlots[0]!.special, null);
    assert.equal(applySwap(host, t.room, "p1", true), null);
    for (const v of ["p1", "bank"]) assert.equal(view(t.room, v).handSlots[0]!.special, "threeSwap");
    clearRoomTimers(host, t.room);
  });
});

describe("mode Tradicional (sense normes de la casa): res no canvia", () => {
  it("el 3 i el 4 es juguen normals, sense oferta", () => {
    for (const first of [3, 4]) {
      const { room, p1 } = betting([6, 2, first], false);
      const s = p1.handSlots[0]!;
      assert.deepEqual(s.cards.map((c) => c.card.value), [first]);
      assert.equal(s.swapOffered ?? null, null);
      assert.equal(view(room, "p1").pendingChoices ?? null, null);
      assert.equal(applySwap(host, room, "p1", true), ENGINE_MESSAGES.swapUnavailable);
      assert.equal(applyHit(host, room, "p1"), null);
      clearRoomTimers(host, room);
    }
  });
  it("no es pot doblar ni separar", () => {
    const { room, p1 } = playing(slot([10, 12]), [], false);
    assert.equal(canDoubleNow(room, p1), false);
    assert.equal(applySplit(room, "p1"), ENGINE_MESSAGES.splitUnavailable);
    clearRoomTimers(host, room);
  });
  it("una mà normal que guanya cobra 1:1", () => {
    const { room, p1, bank } = playing(slot([6], { status: "stood" }), [], false);
    settleWithBank(room, bank, [5]);
    assert.equal(p1.chips - START, 10);
  });
});
