/**
 * Recompte del perfil a partir d'una liquidació real del motor.
 * El bug: «Passat» no sumava i «banca passada» sí (a l'inrevés). Un split són dues mans.
 */
import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import {
  emptyRoomBase,
  settleGame,
  type GameHost,
  type HandSlot,
  type Player,
  type Room,
} from "./gameEngine.ts";
import { createSingleSpanishDeck } from "./spanishDeck.ts";
import type { Card } from "../src/gameTypes.ts";
import { recordHandStatsFromSettlement } from "../server/handStatsRecorder.ts";
import {
  flushPlayerStatsWritesForTests,
  getPlayerStats,
  resetPlayerStatsCacheForTests,
} from "../server/playerStats.ts";

const PLAYER = "profilehands00001";
const deck = createSingleSpanishDeck();

function card(value: number, suit: Card["suit"] = "hearts"): Card {
  const c = deck.find((d) => d.value === value && d.suit === suit);
  assert.ok(c);
  return { ...c };
}

function slot(cards: Card[], bet: number, status: HandSlot["status"], extra: Partial<HandSlot> = {}): HandSlot {
  return {
    id: `s-${Math.random()}`,
    cards: cards.map((c, i) => ({ id: `c${i}-${c.suit}-${c.value}`, card: c, faceUp: true })),
    bet,
    doubled: false,
    canDouble: false,
    mort: false,
    blindPair: false,
    blindUntilBankEnd: false,
    mortOffered: false,
    status,
    ...extra,
  };
}

function seat(id: string, extra: Partial<Player> = {}): Player {
  return {
    id,
    playerId: id === "H" ? PLAYER : id,
    seatToken: `tok-${id}`,
    name: id === "H" ? "Humà" : id,
    chips: 5_000,
    bet: 0,
    isBanker: false,
    status: "stood",
    handSlots: [],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
    ...extra,
  };
}

const host: GameHost = {
  emitRoomUpdate() {},
  schedule: () => 0 as unknown as ReturnType<typeof setTimeout>,
  clearTimeout() {},
};

function roomWith(humanSlots: HandSlot[], bankCards: Card[], bankStatus: HandSlot["status"] = "stood"): Room {
  const room = emptyRoomBase("stats-room", "Taula", 100, 0);
  room.players = [seat("B", { isBot: true, isBanker: true, chips: 5_000 }), seat("H")];
  const human = room.players[1]!;
  const banker = room.players[0]!;
  const staked = humanSlots.reduce((sum, s) => sum + s.bet, 0);
  room.roundStartChips = new Map([
    ["B", banker.chips],
    [PLAYER, human.chips],
  ]);
  human.chips -= staked;
  human.bet = staked;
  room.pot = staked;
  human.handSlots = humanSlots;
  banker.handSlots = [slot(bankCards, 0, bankStatus)];
  room.phase = "banker";
  return room;
}

async function play(humanSlots: HandSlot[], bankCards: Card[], bankStatus?: HandSlot["status"]) {
  const room = roomWith(humanSlots, bankCards, bankStatus);
  settleGame(host, room);
  await recordHandStatsFromSettlement(room, room.lastRound?.results);
  await flushPlayerStatsWritesForTests();
  return room;
}

describe("perfil: recompte des de la liquidació", () => {
  let dir = "";
  before(async () => {
    dir = await fs.mkdtemp(path.join(os.tmpdir(), "setimig-profile-hands-"));
    process.env.BALANCE_DATA_DIR = dir;
    resetPlayerStatsCacheForTests();
  });
  after(async () => {
    await flushPlayerStatsWritesForTests();
    resetPlayerStatsCacheForTests();
    await fs.rm(dir, { recursive: true, force: true });
    delete process.env.BALANCE_DATA_DIR;
  });

  it("4 mans amb una passada clara: bust 1, 25 % de victòries, mitjana amb mitges", async () => {
    await play([slot([card(7), card(2, "clubs")], 100, "busted")], [card(5)]);
    await play([slot([card(4)], 100, "stood")], [card(6)]);
    await play([slot([card(3)], 100, "stood")], [card(6, "clubs")]);
    await play([slot([card(6), card(10, "diamonds")], 100, "stood")], [card(5, "spades")]);
    const stats = await getPlayerStats(PLAYER);
    assert.equal(stats.handsPlayed, 4);
    assert.equal(stats.passCount, 1, "la passada (9) ha de comptar; abans sortia 0");
    assert.equal(stats.winRatePercent, 25);
    // 9 + 4 + 3 + 6.5 = 22.5 → 5.6
    assert.equal(stats.averagePoints, 5.6);
  });

  it("guanyar contra una banca passada no és una passada, i el 7½ natural sí que es desa", async () => {
    resetPlayerStatsCacheForTests();
    const fresh = "profilehands00002";
    const room = emptyRoomBase("stats-2", "Taula", 100, 0);
    room.players = [seat("B", { isBot: true, isBanker: true }), seat("H", { playerId: fresh, name: "Natura" })];
    const human = room.players[1]!;
    const banker = room.players[0]!;
    room.roundStartChips = new Map([
      ["B", banker.chips],
      [fresh, human.chips],
    ]);
    human.chips -= 100;
    human.bet = 100;
    room.pot = 100;
    human.handSlots = [slot([card(7), card(10)], 100, "stood")];
    banker.handSlots = [slot([card(5), card(4, "clubs")], 0, "busted")];
    room.phase = "banker";
    settleGame(host, room);
    await recordHandStatsFromSettlement(room, room.lastRound?.results);
    await flushPlayerStatsWritesForTests();
    const stats = await getPlayerStats(fresh);
    assert.equal(stats.passCount, 0, "«banca passada» no és un bust del jugador");
    assert.equal(stats.handsPlayed, 1);
    assert.equal(stats.winRatePercent, 100);
    assert.equal(stats.averagePoints, 7.5);
    const file = await import("../server/playerStats.ts").then((m) => m.readPlayerStatsFileForTests(fresh));
    assert.equal(file.hands[0]?.naturalSevenHalf, true);
    assert.equal(file.hands[0]?.passed, false);
  });

  it("split: dues mans; doblada: una; plantada automàtica: no és passada", async () => {
    resetPlayerStatsCacheForTests();
    const id = "profilehands00003";
    const base = () => {
      const room = emptyRoomBase("stats-3", "Taula", 100, 0);
      room.players = [seat("B", { isBot: true, isBanker: true }), seat("H", { playerId: id, name: "Split" })];
      return room;
    };
    const split = base();
    const human = split.players[1]!;
    const banker = split.players[0]!;
    split.roundStartChips = new Map([
      ["B", banker.chips],
      [id, human.chips],
    ]);
    human.chips -= 200;
    human.bet = 200;
    split.pot = 200;
    human.handSlots = [
      slot([card(7), card(3, "clubs")], 100, "busted"),
      slot([card(6), card(10, "clubs")], 100, "stood"),
    ];
    banker.handSlots = [slot([card(5)], 0, "stood")];
    split.phase = "banker";
    settleGame(host, split);
    await recordHandStatsFromSettlement(split, split.lastRound?.results);

    const doubled = base();
    const h2 = doubled.players[1]!;
    const b2 = doubled.players[0]!;
    doubled.roundStartChips = new Map([
      ["B", b2.chips],
      [id, h2.chips],
    ]);
    h2.chips -= 200;
    h2.bet = 200;
    doubled.pot = 200;
    h2.handSlots = [slot([card(6)], 200, "stood", { doubled: true })];
    b2.handSlots = [slot([card(4)], 0, "stood")];
    doubled.phase = "banker";
    settleGame(host, doubled);
    await recordHandStatsFromSettlement(doubled, doubled.lastRound?.results);

    const auto = base();
    const h3 = auto.players[1]!;
    const b3 = auto.players[0]!;
    auto.roundStartChips = new Map([
      ["B", b3.chips],
      [id, h3.chips],
    ]);
    h3.chips -= 100;
    h3.bet = 100;
    auto.pot = 100;
    h3.handSlots = [slot([card(5)], 100, "stood", { autoStood: true })];
    b3.handSlots = [slot([card(6)], 0, "stood")];
    auto.phase = "banker";
    settleGame(host, auto);
    await recordHandStatsFromSettlement(auto, auto.lastRound?.results);
    await flushPlayerStatsWritesForTests();

    const stats = await getPlayerStats(id);
    // split 2 + doubled 1 + auto-stand 1
    assert.equal(stats.handsPlayed, 4);
    assert.equal(stats.passCount, 1, "només la mà separada que s'ha passat");
    // split: bust + win; doubled win; auto-stand lose → 2/4 = 50 %
    assert.equal(stats.winRatePercent, 50);
    const file = await import("../server/playerStats.ts").then((m) => m.readPlayerStatsFileForTests(id));
    assert.equal(file.hands.filter((h) => h.naturalSevenHalf).length, 0);
    assert.ok(file.hands.some((h) => h.passed && h.finalPoints === 10));
    assert.ok(file.hands.some((h) => !h.passed && h.finalPoints === 6.5));
    assert.ok(file.hands.some((h) => !h.passed && h.finalPoints === 6));
    assert.ok(file.hands.some((h) => !h.passed && h.finalPoints === 5));
  });
});
