/**
 * Normes de les cartes tapades (decisió de l'Edu, 27/10 16:12). Un test d'integració per norma:
 * motor (accions reals) + vista serialitzada per a cada viewer (roomToView) + context de la IA.
 */
import assert from "node:assert/strict";
import { describe, it } from "node:test";
import type { Card } from "../src/gameTypes.ts";
import {
  applyDouble,
  applyHit,
  applyMort,
  applySwap,
  applyPlaceBet,
  applyRevealCard,
  applySplit,
  applyStand,
  beginBettingPhase,
  clearRoomTimers,
  emptyRoomBase,
  roomToView,
  strategyContextFor,
  type GameHost,
  type HandSlot,
  type Player,
  type Room,
} from "./gameEngine.ts";
import { resetTestDeckSeedWarningsForTests, testShuffleSeed } from "./shuffle.ts";

process.env.SETIMIG_TEST_FAST = "1";

const host: GameHost = {
  emitRoomUpdate() {},
  // Cap temporitzador real: el test controla cada pas.
  schedule: () => 0 as unknown as ReturnType<typeof setTimeout>,
  clearTimeout() {},
};

function card(value: number, suit: Card["suit"] = "hearts"): Card {
  return { suit, value, points: value >= 10 ? 0.5 : value };
}

function basePlayer(id: string, overrides: Partial<Player> = {}): Player {
  return {
    id,
    playerId: id,
    seatToken: id,
    name: id,
    chips: 5_000,
    bet: 0,
    isBanker: false,
    status: "betting",
    handSlots: [],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
    ...overrides,
  };
}

function slotOf(cards: HandSlot["cards"], extra: Partial<HandSlot> = {}): HandSlot {
  return {
    id: "s0",
    bet: 100,
    doubled: false,
    canDouble: false,
    mort: false,
    blindPair: false,
    blindUntilBankEnd: false,
    mortOffered: false,
    status: "playing",
    cards,
    ...extra,
  };
}

/** Taula en joc: banca + p1 (torn) + p2 (rival que mira). */
function playingRoom(id: string, p1Slot: HandSlot, opts: { house?: boolean; deck?: Card[] } = {}) {
  const room = emptyRoomBase(id, id, 100, 0);
  room.houseRulesEnabled = !!opts.house;
  room.phase = "playing";
  room.deck = opts.deck ?? [];
  const banker = basePlayer("bank", {
    isBanker: true,
    chips: 100_000,
    status: "playing",
    handSlots: [slotOf([{ id: "b0", card: card(6, "clubs"), faceUp: false }], { id: "bs", bet: 0 })],
  });
  const p1 = basePlayer("p1", { bet: 100, chips: 5_000, status: "playing", handSlots: [p1Slot] });
  const p2 = basePlayer("p2", {
    bet: 100,
    chips: 5_000,
    status: "stood",
    handSlots: [slotOf([{ id: "q0", card: card(5, "diamonds"), faceUp: false }], { id: "s2", status: "stood" })],
  });
  room.players = [banker, p1, p2];
  room.turnPlayerIndex = 0;
  room.pot = 200;
  room.roundStartChips = new Map([
    ["bank", 100_000],
    ["p1", 5_100],
    ["p2", 5_100],
  ]);
  return { room, banker, p1, p2 };
}

function viewCards(room: Room, viewerId: string, ownerId: string, slot = 0) {
  const pv = roomToView(room, viewerId, host).players.find((p) => p.id === ownerId)!;
  return pv.handSlots[slot]!.cards;
}

describe("cartes tapades: normes de l'Edu (27/10)", () => {
  it("1) ningú, ni la banca, veu la carta de la banca abans del seu torn; després, totes destapades", () => {
    const room = emptyRoomBase("n1", "n1", 100, 0);
    room.phase = "betting";
    const banker = basePlayer("bank", { isBanker: true, chips: 100_000, status: "waiting" });
    const p1 = basePlayer("p1", { isBot: true });
    room.players = [banker, p1];
    // drawCard fa pop(): p1 rep el 2, la banca el 6; després la banca roba el rei.
    room.deck = [card(10, "clubs"), card(6, "clubs"), card(2)];
    assert.equal(applyPlaceBet(room, p1, 100), null);
    assert.equal(room.phase, "playing");
    const bankCard = banker.handSlots[0]!.cards[0]!;
    assert.equal(bankCard.card.value, 6);
    assert.equal(bankCard.faceUp, false, "la carta de la banca es reparteix tapada");
    for (const viewer of ["p1", "bank"]) {
      const cs = viewCards(room, viewer, "bank");
      assert.equal(cs[0]!.card, null, `${viewer} no veu la carta de la banca`);
      assert.equal(cs[0]!.faceUp, false);
    }
    // La IA dels jugadors tampoc la pot comptar.
    const ctx = strategyContextFor(room, p1);
    assert.ok(!ctx.seen.some((c) => c.value === 6), "la IA no veu la carta de la banca");
    assert.equal(ctx.rivalVisibleMax, 0);

    assert.equal(applyStand(host, room, "p1"), null);
    assert.equal(room.phase, "banker");
    for (const viewer of ["p1", "bank"]) {
      assert.equal(viewCards(room, viewer, "bank")[0]!.card?.value, 6, `${viewer} veu la carta al torn de la banca`);
    }
    assert.equal(applyHit(host, room, "bank"), null);
    const drawn = banker.handSlots[0]!.cards[1]!;
    assert.equal(drawn.faceUp, true, "les que roba la banca surten destapades");
    assert.equal(viewCards(room, "p1", "bank")[1]!.card?.value, 10);
    clearRoomTimers(host, room);
  });

  it("2) al torn de la banca, la banca (persona o IA) només veu les destapades dels jugadors", () => {
    const build = (hiddenValue: number) => {
      const { room, banker } = playingRoom(
        `n2-${hiddenValue}`,
        slotOf(
          [
            { id: "h", card: card(hiddenValue), faceUp: false },
            { id: "v", card: card(11, "spades"), faceUp: true },
          ],
          { status: "stood" },
        ),
      );
      room.phase = "banker";
      banker.handSlots[0]!.cards[0]!.faceUp = true;
      return { room, banker };
    };
    const a = build(7);
    const cs = viewCards(a.room, "bank", "p1");
    assert.equal(cs[0]!.card, null, "la tapada no viatja a la banca");
    assert.equal(cs[1]!.card?.value, 11);
    assert.equal(viewCards(a.room, "bank", "p2")[0]!.card, null);
    // El context de la IA de banca és idèntic sigui quina sigui la carta tapada (no en fa servir ni valor ni total).
    const b = build(1);
    const ctxA = strategyContextFor(a.room, a.banker);
    const ctxB = strategyContextFor(b.room, b.banker);
    assert.deepEqual(ctxA, ctxB);
    assert.ok(!ctxA.seen.some((c) => c.value === 7 && c.suit === "hearts"));
    assert.deepEqual(ctxA.bankerTargetScores, [0.5, 4]);
    // A la liquidació es destapa tot.
    a.room.phase = "settlement";
    assert.equal(viewCards(a.room, "bank", "p1")[0]!.card?.value, 7);
    clearRoomTimers(host, a.room);
    clearRoomTimers(host, b.room);
  });

  it("3) qui es passa de 7½ destapa al moment totes les cartes i perd (carta, doblar i split per mà)", () => {
    // Carta
    {
      const { room, p1 } = playingRoom("n3-hit", slotOf([{ id: "h", card: card(7), faceUp: false }]), {
        deck: [card(5)],
      });
      assert.equal(applyHit(host, room, "p1"), null);
      const slot = p1.handSlots[0]!;
      assert.equal(slot.status, "busted");
      assert.ok(slot.cards.every((c) => c.faceUp));
      for (const viewer of ["bank", "p2"]) {
        assert.deepEqual(
          viewCards(room, viewer, "p1").map((c) => c.card?.value),
          [7, 5],
          `${viewer} veu tota la mà passada`,
        );
      }
      clearRoomTimers(host, room);
    }
    // Doblar
    {
      const { room, p1 } = playingRoom(
        "n3-dbl",
        slotOf([{ id: "h", card: card(6), faceUp: false }], { canDouble: true }),
        { house: true, deck: [card(4)] },
      );
      assert.equal(applyDouble(host, room, "p1"), null);
      assert.equal(p1.handSlots[0]!.status, "busted");
      assert.deepEqual(viewCards(room, "p2", "p1").map((c) => c.card?.value), [6, 4]);
      clearRoomTimers(host, room);
    }
    // Split: només es destapa la mà que es passa.
    {
      const { room, p1 } = playingRoom(
        "n3-split",
        // Normes de la casa: només es separen dues cartes de mig punt.
        slotOf([
          { id: "a", card: card(12), faceUp: false },
          { id: "b", card: card(10, "clubs"), faceUp: true },
        ]),
        // pop: 6 i 6 d'espases (segones cartes del separar), després els 7 que fan passar cada mà.
        { house: true, deck: [card(7, "spades"), card(7), card(6, "spades"), card(6)] },
      );
      assert.equal(applySplit(room, "p1"), null);
      assert.deepEqual(
        p1.handSlots.map((h) => h.cards.map((c) => c.card.value)),
        [
          [12, 6],
          [10, 6],
        ],
      );
      assert.equal(applyHit(host, room, "p1"), null); // mà 1: + 7 → es passa
      assert.equal(p1.handSlots[0]!.status, "busted");
      assert.deepEqual(viewCards(room, "p2", "p1", 0).map((c) => c.card?.value), [12, 6, 7]);
      assert.equal(p1.activeSlotIndex, 1, "el torn passa a la segona mà");
      assert.equal(applyHit(host, room, "p1"), null); // mà 2: + 7 → també es passa
      assert.equal(p1.handSlots[1]!.status, "busted");
      assert.deepEqual(viewCards(room, "bank", "p1", 1).map((c) => c.card?.value), [10, 6, 7]);
      clearRoomTimers(host, room);
    }
    // I perd: a la liquidació la mà passada no cobra.
    {
      const { room, p1 } = playingRoom("n3-lose", slotOf([{ id: "h", card: card(7), faceUp: false }]), {
        deck: [card(5)],
      });
      room.players = room.players.filter((p) => p.id !== "p2");
      room.pot = 100;
      applyHit(host, room, "p1");
      assert.equal(room.phase, "settlement");
      assert.equal(p1.chips, 5_000, "l'aposta de la mà passada es perd");
      clearRoomTimers(host, room);
    }
  });

  it("4) una sola carta tapada per mà: destapar l'única fa que la següent surti tapada (també en split)", () => {
    const { room, p1 } = playingRoom("n4", slotOf([{ id: "c0", card: card(1), faceUp: false }]), {
      deck: [card(11), card(10, "clubs"), card(10, "spades"), card(10, "diamonds"), card(1, "clubs")],
    });
    const hiddenForRivals = () => viewCards(room, "p2", "p1").filter((c) => c.card === null).length;
    const slot = p1.handSlots[0]!;
    assert.equal(hiddenForRivals(), 1);
    applyHit(host, room, "p1");
    assert.equal(slot.cards[1]!.faceUp, true, "ja n'hi ha una de tapada: la nova surt destapada");
    assert.equal(hiddenForRivals(), 1);
    assert.equal(applyRevealCard(room, "p2", "c0"), "No és el teu torn.");
    assert.equal(applyRevealCard(room, "p1", "c0"), null);
    assert.equal(hiddenForRivals(), 0);
    assert.equal(applyRevealCard(room, "p1", "c0"), "Aquesta carta ja està destapada.");
    applyHit(host, room, "p1");
    assert.equal(slot.cards[2]!.faceUp, false, "has destapat l'única: la següent surt tapada");
    assert.equal(hiddenForRivals(), 1);
    applyHit(host, room, "p1");
    assert.equal(slot.cards[3]!.faceUp, true);
    assert.equal(hiddenForRivals(), 1);
    assert.equal(slot.status, "playing");
    clearRoomTimers(host, room);

    // Split: cada mà en manté una de tapada pel seu compte.
    const s = playingRoom(
      "n4-split",
      slotOf([
        { id: "a", card: card(12), faceUp: false },
        { id: "b", card: card(11, "clubs"), faceUp: true },
      ]),
      {
        house: true,
        // pop: 1 de bastos (mà 1, destapada), 1 d'espases (mà 2, tapada: és la seva única oculta),
        // 1 d'oros (carta de la mà 1), 2 de copes i 2 d'oros (cartes de la mà 2).
        deck: [card(2, "diamonds"), card(2), card(1, "diamonds"), card(1, "spades"), card(1, "clubs")],
      },
    );
    assert.equal(applySplit(s.room, "p1"), null);
    applyHit(host, s.room, "p1"); // mà 1 ja té la tapada: la nova surt destapada
    assert.equal(s.p1.handSlots[0]!.cards[1]!.faceUp, true);
    applyStand(host, s.room, "p1");
    assert.equal(s.p1.activeSlotIndex, 1);
    // La segona carta del separar és la tapada de la mà 2 (no n'hi havia cap).
    assert.equal(s.p1.handSlots[1]!.cards[1]!.faceUp, false);
    applyHit(host, s.room, "p1");
    assert.equal(s.p1.handSlots[1]!.cards[2]!.faceUp, true);
    for (const i of [0, 1]) {
      assert.equal(viewCards(s.room, "p2", "p1", i).filter((c) => c.card === null).length, 1);
    }
    clearRoomTimers(host, s.room);
  });

  it("5) el 3 i el Mort queden tapats fins que acaba la banca (també per al propietari)", () => {
    // Mort
    const m = playingRoom("n5-mort", slotOf([{ id: "seven", card: card(7), faceUp: false }], { mortOffered: true }), {
      house: true,
      deck: [card(12)],
    });
    m.room.players = m.room.players.filter((p) => p.id !== "p2");
    assert.equal(applyMort(host, m.room, "p1", true), null);
    assert.equal(m.room.phase, "banker");
    for (const viewer of ["p1", "bank"]) {
      const cs = viewCards(m.room, viewer, "p1");
      assert.equal(cs[1]!.card, null, `${viewer} no veu la carta del Mort durant la banca`);
    }
    assert.ok(!strategyContextFor(m.room, m.banker).seen.some((c) => c.value === 12));
    assert.equal(applyStand(host, m.room, "bank"), null);
    assert.equal(m.room.phase, "settlement");
    assert.equal(viewCards(m.room, "p1", "p1")[1]!.card?.value, 12);
    clearRoomTimers(host, m.room);

    // 3: parella secreta repartida pel motor.
    const room = emptyRoomBase("n5-tres", "n5", 100, 0);
    room.houseRulesEnabled = true;
    room.phase = "betting";
    const banker = basePlayer("bank", { isBanker: true, chips: 100_000, status: "waiting" });
    const p1 = basePlayer("p1");
    room.players = [banker, p1];
    room.deck = [card(6, "clubs"), card(5, "spades"), card(2, "diamonds"), card(3)];
    assert.equal(applyPlaceBet(room, p1, 100), null);
    const slot = p1.handSlots[0]!;
    // Normes de la casa: el 3 és opcional; el jugador tria «Canviar».
    assert.equal(slot.swapOffered, 3);
    assert.equal(applySwap(host, room, "p1", true), null);
    assert.equal(slot.blindPair, true);
    assert.equal(slot.status, "stood");
    assert.deepEqual(viewCards(room, "p1", "p1").map((c) => c.card), [null, null]);
    assert.notEqual(applyRevealCard(room, "p1", slot.cards[0]!.id), null);
    assert.equal(room.phase, "banker");
    assert.notEqual(applyStand(host, room, "p1"), null);
    for (const viewer of ["p1", "bank"]) {
      assert.deepEqual(viewCards(room, viewer, "p1").map((c) => c.card), [null, null]);
    }
    assert.equal(applyStand(host, room, "bank"), null);
    // El canvi es fa al torn del jugador (després del repartiment inicial, que dona el 2 a la banca).
    assert.deepEqual(viewCards(room, "bank", "p1").map((c) => c.card?.value), [5, 6]);
    clearRoomTimers(host, room);
  });

  it("6) llavor 4: acceptar el Mort destapa el 7 a la vista del rival; rebutjar-lo el deixa tapat", () => {
    const prevSeed = process.env.SETIMIG_TEST_DECK_SEED;
    const prevShuffle = process.env.SETIMIG_TEST_SHUFFLE_SEED;
    const prevHost = process.env.SETIMIG_HOST;
    const prevEnv = process.env.NODE_ENV;
    process.env.SETIMIG_TEST_DECK_SEED = "4";
    delete process.env.SETIMIG_TEST_SHUFFLE_SEED;
    process.env.SETIMIG_HOST = "127.0.0.1";
    delete process.env.NODE_ENV;
    resetTestDeckSeedWarningsForTests();
    try {
      assert.equal(testShuffleSeed(), 4, "la llavor 4 només val fora de producció i en loopback");

      const deal = () => {
        const room = emptyRoomBase(`mort-seed4-${Math.random().toString(36).slice(2)}`, "Mort", 100, 0);
        room.houseRulesEnabled = true;
        const banker = basePlayer("bank", { isBanker: true, isBot: true, chips: 50_000, status: "waiting" });
        const human = basePlayer("human", { isBot: false, chips: 2_000, status: "waiting" });
        room.players = [banker, human];
        beginBettingPhase(host, room);
        assert.equal(applyPlaceBet(room, human, 100), null);
        assert.equal(room.phase, "playing");
        const seven = human.handSlots[0]!.cards[0]!;
        assert.equal(seven.card.value, 7);
        assert.equal(seven.card.suit, "spades");
        assert.equal(seven.faceUp, false);
        assert.equal(human.handSlots[0]!.mortOffered, true);
        const offered = viewCards(room, banker.id, human.id)[0]!;
        assert.equal(offered.faceUp, false);
        assert.equal(offered.card, null, "abans de decidir, el rival no veu el 7");
        return { room, banker, human };
      };

      const accepted = deal();
      assert.equal(applyMort(host, accepted.room, accepted.human.id, true), null);
      assert.equal(accepted.human.handSlots[0]!.cards[0]!.faceUp, true);
      assert.equal(accepted.human.handSlots[0]!.cards[1]!.faceUp, false);
      for (const viewerId of [accepted.banker.id, "espectador"]) {
        const cards = viewCards(accepted.room, viewerId, accepted.human.id);
        assert.equal(cards[0]!.faceUp, true, `${viewerId} veu el 7 destapat`);
        assert.equal(cards[0]!.card?.value, 7);
        assert.equal(cards[0]!.card?.suit, "spades");
        assert.equal(cards[1]!.faceUp, false, "la carta del Mort segueix tapada");
        assert.equal(cards[1]!.card, null);
      }
      clearRoomTimers(host, accepted.room);

      const declined = deal();
      assert.equal(applyMort(host, declined.room, declined.human.id, false), null);
      assert.equal(declined.human.handSlots[0]!.cards[0]!.faceUp, false);
      assert.equal(declined.human.handSlots[0]!.mort, false);
      const hidden = viewCards(declined.room, declined.banker.id, declined.human.id)[0]!;
      assert.equal(hidden.faceUp, false);
      assert.equal(hidden.card, null, "rebutjar el Mort deixa el 7 tapat per al rival");
      const owner = viewCards(declined.room, declined.human.id, declined.human.id)[0]!;
      assert.equal(owner.card?.value, 7, "el propietari continua veient la seva carta");
      assert.equal(owner.faceUp, false);
      clearRoomTimers(host, declined.room);
    } finally {
      if (prevSeed === undefined) delete process.env.SETIMIG_TEST_DECK_SEED;
      else process.env.SETIMIG_TEST_DECK_SEED = prevSeed;
      if (prevShuffle === undefined) delete process.env.SETIMIG_TEST_SHUFFLE_SEED;
      else process.env.SETIMIG_TEST_SHUFFLE_SEED = prevShuffle;
      if (prevHost === undefined) delete process.env.SETIMIG_HOST;
      else process.env.SETIMIG_HOST = prevHost;
      if (prevEnv === undefined) delete process.env.NODE_ENV;
      else process.env.NODE_ENV = prevEnv;
      resetTestDeckSeedWarningsForTests();
    }
  });
});
