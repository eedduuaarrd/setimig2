import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { uniqueDisplayNameInRoom } from "./playerNames.ts";

describe("uniqueDisplayNameInRoom", () => {
  it("keeps the first name unchanged", () => {
    assert.equal(uniqueDisplayNameInRoom([], "Anna", "Jugador"), "Anna");
  });

  it("suffixes duplicate names case-insensitively", () => {
    assert.equal(uniqueDisplayNameInRoom(["Anna"], "anna", "Jugador"), "anna 2");
    assert.equal(uniqueDisplayNameInRoom(["Anna", "Anna 2"], "Anna", "Jugador"), "Anna 3");
  });

  it("uses fallback when requested name is empty", () => {
    assert.equal(uniqueDisplayNameInRoom(["Jugador"], "  ", "Jugador"), "Jugador 2");
  });
});
