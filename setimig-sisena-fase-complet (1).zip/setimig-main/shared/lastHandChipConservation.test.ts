import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  applyDouble,
  applySplit,
  emptyRoomBase,
  finishSettlementToWaiting,
  settleGame,
  type GameHost,
  type Player,
  type Room,
} from "./gameEngine.ts";
import { totalTableChips } from "./matchPhaseB.ts";
import type { Card } from "../src/gameTypes.ts";

const host: GameHost = {
  emitRoomUpdate() {},
  schedule: (fn) => setTimeout(fn, 0),
  clearTimeout() {},
};

function card(value: number): Card {
  const points = value >= 10 ? 0.5 : value;
  return { suit: "hearts", value, points };
}

function figure(suit: Card["suit"] = "hearts"): Card {
  return { suit, value: 10, points: 0.5 };
}

function tableTotal(room: Room): number {
  return totalTableChips({ players: room.players, pot: room.pot, jackpot: room.jackpot });
}

function baseBanker(chips: number, cards: Card[]): Player {
  return {
    id: "h",
    playerId: "human",
    seatToken: "h",
    name: "Human",
    chips,
    bet: 0,
    isBanker: true,
    status: "stood",
    handSlots: [
      {
        id: "b",
        bet: 0,
        cards: cards.map((c, i) => ({ id: `b${i}`, card: c, faceUp: true })),
        status: "stood",
        doubled: false,
        canDouble: false,
        mort: false,
        blindPair: false,
        blindUntilBankEnd: false,
        mortOffered: false,
      },
    ],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
  };
}

describe("last hand chip conservation (B2)", () => {
  it("applySplit increases player.bet to match pot contributions", () => {
    const room = emptyRoomBase("split-bet", "Split", 100, 0);
    room.houseRulesEnabled = true;
    room.phase = "playing";
    const bot: Player = {
      id: "bot",
      playerId: "bot",
      seatToken: "bot",
      name: "Laia",
      chips: 1_800,
      bet: 200,
      isBanker: false,
      isBot: true,
      status: "playing",
      handSlots: [
        {
          id: "s0",
          bet: 200,
          cards: [
            { id: "a", card: figure("hearts"), faceUp: true },
            { id: "b", card: figure("spades"), faceUp: true },
          ],
          status: "playing",
          doubled: false,
          canDouble: false,
          mort: false,
          blindPair: false,
          blindUntilBankEnd: false,
          mortOffered: false,
        },
      ],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    room.players = [baseBanker(2_000, [card(7), card(3)]), bot];
    room.pot = 200;
    room.turnPlayerIndex = 0;
    assert.equal(applySplit(room, bot.id), null);
    assert.equal(bot.handSlots.length, 2);
    assert.equal(bot.bet, 400);
    assert.equal(room.pot, 400);
  });

  it("orphan pot after split/double is paid to banker, not destroyed on last hand", () => {
    const room = emptyRoomBase("orphan-pot", "Orphan", 100, 0);
    room.houseRulesEnabled = true;
    room.soloAi = true;
    room.autoFillBots = false;
    room.soloBotCount = 0;
    room.phaseB = { handsTotal: 10, handsCompleted: 9, chipPool: 4_000 };
    const banker = baseBanker(2_000, [card(7), card(3)]);
    const laia: Player = {
      id: "l",
      playerId: "laia",
      seatToken: "l",
      name: "Laia",
      chips: 1_400,
      bet: 200,
      isBanker: false,
      isBot: true,
      status: "stood",
      handSlots: [
        {
          id: "s0",
          bet: 400,
          cards: [
            { id: "a", card: card(4), faceUp: true },
            { id: "b", card: card(2), faceUp: true },
          ],
          status: "stood",
          doubled: true,
          canDouble: false,
          mort: false,
          blindPair: false,
          blindUntilBankEnd: false,
          mortOffered: false,
        },
      ],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    room.pot = 600;
    room.players = [banker, laia];
    const baseline = tableTotal(room);
    assert.equal(room.phaseB!.chipPool, 4_000);

    settleGame(host, room);
    assert.equal(room.pot, 0);
    assert.equal(tableTotal(room), baseline);

    finishSettlementToWaiting(host, room);
    assert.equal(room.pot, 0);
    assert.equal(tableTotal(room), baseline);
    assert.equal(room.matchEnded, true);
    assert.equal(room.phaseB!.handsCompleted, 10);
  });

  it("split with mixed outcomes drains pot on settlement", () => {
    const room = emptyRoomBase("last-hand", "Last", 100, 0);
    room.houseRulesEnabled = true;
    room.soloAi = true;
    room.autoFillBots = false;
    room.soloBotCount = 0;
    room.phaseB = { handsTotal: 10, handsCompleted: 9, chipPool: 4_000 };
    const banker = baseBanker(2_000, [card(7), card(3)]);
    const laia: Player = {
      id: "l",
      playerId: "laia",
      seatToken: "l",
      name: "Laia",
      chips: 1_400,
      bet: 200,
      isBanker: false,
      isBot: true,
      status: "stood",
      handSlots: [
        {
          id: "s0",
          bet: 200,
          cards: [
            { id: "a", card: card(4), faceUp: true },
            { id: "b", card: card(2), faceUp: true },
          ],
          status: "stood",
          doubled: false,
          canDouble: false,
          mort: false,
          blindPair: false,
          blindUntilBankEnd: false,
          mortOffered: false,
        },
        {
          id: "s1",
          bet: 400,
          cards: [
            { id: "c", card: card(5), faceUp: true },
            { id: "d", card: card(4), faceUp: true },
          ],
          status: "stood",
          doubled: true,
          canDouble: false,
          mort: false,
          blindPair: false,
          blindUntilBankEnd: false,
          mortOffered: false,
        },
      ],
      activeSlotIndex: 1,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    room.pot = 600;
    room.players = [banker, laia];
    const baseline = tableTotal(room);
    assert.equal(baseline, 4_000);

    settleGame(host, room);
    assert.equal(room.pot, 0);
    assert.equal(tableTotal(room), baseline);
    finishSettlementToWaiting(host, room);
    assert.equal(tableTotal(room), baseline);
  });

  it("double after split uses updated player.bet for pot total", () => {
    const room = emptyRoomBase("dbl-split", "Dbl", 100, 0);
    room.houseRulesEnabled = true;
    room.phase = "playing";
    const bot: Player = {
      id: "bot",
      playerId: "bot",
      seatToken: "bot",
      name: "Laia",
      chips: 1_600,
      bet: 400,
      isBanker: false,
      isBot: true,
      status: "playing",
      handSlots: [
        {
          id: "s0",
          bet: 200,
          cards: [{ id: "a", card: figure("hearts"), faceUp: true }],
          status: "playing",
          doubled: false,
          canDouble: true,
          mort: false,
          blindPair: false,
          blindUntilBankEnd: false,
          mortOffered: false,
        },
        {
          id: "s1",
          bet: 200,
          cards: [{ id: "b", card: figure("spades"), faceUp: true }],
          status: "playing",
          doubled: false,
          canDouble: false,
          mort: false,
          blindPair: false,
          blindUntilBankEnd: false,
          mortOffered: false,
        },
      ],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    room.players = [baseBanker(2_000, [card(7), card(3)]), bot];
    // This fixture starts after one legal split: both hands already carry their stake.
    room.pot = 400;
    room.turnPlayerIndex = 0;
    assert.equal(bot.bet, 400);
    assert.equal(applyDouble(host, room, bot.id), null);
    assert.equal(room.pot, 600);
    assert.equal(bot.handSlots[0]!.bet, 400);
    assert.equal(bot.handSlots[1]!.bet, 200);
  });
});
