/**
 * Codis estables per als missatges que el motor (gameEngine) i el servidor envien al client.
 * El text català segueix viatjant com a `message` (compatibilitat amb clients antics i tests);
 * el client en treu el codi amb `parseGameMessage` i el tradueix amb la clau i18n `<code>`.
 */

/** Errors del motor. El valor és el text canònic en català que retorna gameEngine.ts. */
export const ENGINE_MESSAGES = {
  invalidSettings: "Ajustos de partida no vàlids.",
  blindPairLocked: "Mà cega (regla del 3): no pots demanar, doblar ni fer split; només plantar-te.",
  invalidBet: "Aposta no vàlida.",
  cannotBetNow: "No es pot apostar ara.",
  bankDoesNotBet: "La banca no aposta.",
  alreadyBet: "Ja has apostat.",
  bankCannotCoverMin: "La banca no pot cobrir l'aposta mínima.",
  bankTurn: "Torn de la banca.",
  wrongPhase: "Fase incorrecta.",
  notYourTurn: "No és el teu torn.",
  decideMortFirst: "Primer decideix el Mort.",
  invalidAction: "Acció no vàlida.",
  mortUnavailable: "Mort no disponible.",
  decideSwapFirst: "Primer decideix si jugues o canvies la carta.",
  swapUnavailable: "Canvi no disponible.",
  cannotDoubleNow: "No es pot doblar ara.",
  cannotDouble: "No es pot doblar.",
  alreadyDoubled: "Aquesta mà ja ha doblat.",
  splitAlreadyDoubled: "La mà original ja havia doblat abans del split.",
  splitCannotDouble: "Una mà separada no es pot doblar.",
  noChipsDouble: "No tens prou fitxes per doblar.",
  bankCannotCoverDouble: "La banca no pot cobrir el doble.",
  splitUnavailable: "Split no disponible.",
  noChipsSplit: "No tens prou fitxes per fer split.",
  bankCannotCoverSplit: "La banca no pot cobrir el split.",
} as const;

/**
 * Motiu pel qual «Separar» no es pot fer encara que la mà activa sigui una parella separable
 * (mateix valor, o dues figures). El client el rep a `pendingChoices.splitBlocked`.
 * No s'envia quan `canSplit` és true, ni quan la mà no es pot separar per les cartes.
 * `maxHands` ja no s'emet: el separar no té límit de mans. El codi es conserva perquè un
 * client antic el reconegui si arribés d'un estat anterior.
 */
export const SPLIT_BLOCKED_CODES = [
  "bankCannotCoverSplit",
  "notEnoughChips",
  "maxHands",
  "decideMortFirst",
  "decideSwapFirst",
  "blindPairLocked",
  "mort",
] as const;
export type SplitBlockedCode = (typeof SPLIT_BLOCKED_CODES)[number];
export type EngineMessageCode = keyof typeof ENGINE_MESSAGES;

/**
 * Codis estables de `game_error` quan `double_bet` es rebutja.
 * El text català segueix a `message` (compatibilitat); `code` no canvia entre versions.
 * `NOT_IN_ROOM` el posa el servidor si el socket no té seient; la resta surt del motor.
 */
export const DOUBLE_REJECT_CODE = {
  badPhase: "BAD_PHASE",
  badTurn: "BAD_TURN",
  blindPairLocked: "BLIND_PAIR_LOCKED",
  houseRules: "HOUSE_RULES",
  decideMortFirst: "DECIDE_MORT_FIRST",
  decideSwapFirst: "DECIDE_SWAP_FIRST",
  mort: "MORT",
  alreadyDoubled: "ALREADY_DOUBLED",
  splitAlreadyDoubled: "SPLIT_ALREADY_DOUBLED",
  splitCannotDouble: "SPLIT_CANNOT_DOUBLE",
  cannotDouble: "CANNOT_DOUBLE",
  wrongCards: "WRONG_CARDS",
  notEnoughChips: "NOT_ENOUGH_CHIPS",
  bankCannotCover: "BANK_CANNOT_COVER",
} as const;
export type DoubleRejectCode = (typeof DOUBLE_REJECT_CODE)[keyof typeof DOUBLE_REJECT_CODE];

export const engineMinBetMessage = (n: number) => `L'aposta mínima és ${n}.`;
export const engineMaxBetMessage = (n: number) => `L'aposta màxima ara és ${n}.`;

/** Etiquetes de resultat de la liquidació (highlights). */
export const ENGINE_LABELS = {
  bust: "Passat",
  mortLoses: "Mort — perd l'aposta",
  natural: "7 i Mig natural",
  bankWins: "Banca guanya",
  tieSevenHalfBank: "Empat a 7½ — banca",
  tieBank: "Empat — banca",
  bank: "Banca",
  noChange: "Sense canvi",
  settlement: "Liquidació",
} as const;
export type EngineLabelCode = keyof typeof ENGINE_LABELS;

/** Missatges del servidor (server/*.ts), text exacte que s'envia avui → codi. */
const SERVER_MESSAGES: Record<string, string> = {
  "Sol·licitud invàlida.": "server.badPayload",
  "Massa accions seguides. Espera un moment.": "server.rateLimit",
  "Massa intents amb codis incorrectes. Torna-ho a provar d'aquí a uns minuts.": "server.rateLimitCodes",
  "Defineix una aposta mínima i màxima vàlides (entre 1 i 1.000.000 fitxes).": "server.badBetLimits",
  "Token de jugador invalid o caducat.": "server.badToken",
  "Token de jugador invalid per reprendre aquest seient.": "server.badTokenSeat",
  "El token no correspon a aquest seient.": "server.tokenSeatMismatch",
  "Identitat de jugador invalida.": "server.playerIdInvalid",
  "Jugador no trobat a la taula.": "server.playerNotFound",
  "Codi de taula invalid.": "server.badCode",
  "Taula no trobada.": "server.roomNotFound",
  "Partida en curs. Torna amb el mateix enllaç per reprendre el teu seient.": "server.gameInProgress",
  "Sala plena.": "server.roomFull",
  "Només l'amfitrió pot canviar els ajustos.": "server.notHostSettings",
  "Els ajustos només es poden canviar entre partides.": "server.settingsBetweenGames",
  "Només l'amfitrió pot omplir bots.": "server.notHostBots",
  "Només l'amfitrió pot iniciar la partida.": "server.notHostStart",
  "Cal el token per reprendre la partida.": "server.soloResumeRequired",
  "Nivell de campanya no vàlid.": "server.campaignInvalid",
  "La campanya no està disponible en mode pràctica.": "server.campaignPractice",
  "La campanya no està disponible en torneig ràpid.": "server.campaignTournament",
  "Aquest nivell de campanya encara no està desbloquejat.": "server.campaignLocked",
  "No es pot reiniciar la sessió ara.": "server.cannotResetSession",
  "No es pot repetir ara.": "lobby.ai.cannotRepeat",
  "Calen mes jugadors.": "lobby.ai.needMorePlayers",
  "Calen almenys 2 jugadors.": "server.needTwoPlayers",
  "Acció duplicada o reenviada.": "server.duplicateAction",
  "Acció no permesa en aquesta fase.": "server.actionWrongPhase",
  "Seqüència d'acció invalida.": "server.badSequence",
  "Aquesta carta ja està destapada.": "server.cardAlreadyRevealed",
  "No es pot girar aquesta carta encara.": "server.cannotFlipYet",
  "No es pot girar fins que acabi la banca.": "server.cannotFlipUntilBank",
  "Ara la banca és obligatòria.": "server.bankMandatory",
};

export type ParsedGameMessage = { code: string; params?: Record<string, number | string> };

const BY_TEXT = new Map<string, string>([
  ...Object.entries(ENGINE_MESSAGES).map(([code, text]) => [text, `engine.${code}`] as [string, string]),
  ...Object.entries(ENGINE_LABELS).map(
    ([code, text]) => [text, code === "settlement" ? "game.settlement" : `engine.result.${code}`] as [string, string],
  ),
  ...Object.entries(SERVER_MESSAGES),
]);

const num = (s: string) => Number(s.replace(/[.,\s\u00a0]/g, ""));

/** Text del motor/servidor → codi (clau i18n) i paràmetres. `null` si no és un missatge conegut. */
export function parseGameMessage(text: string | null | undefined): ParsedGameMessage | null {
  if (!text) return null;
  const exact = BY_TEXT.get(text.trim());
  if (exact) return { code: exact };
  let m = /^L'aposta mínima és ([\d.,\s\u00a0]+)\.$/.exec(text);
  if (m) return { code: "engine.minBetIs", params: { n: num(m[1]!) } };
  m = /^L'aposta màxima ara és ([\d.,\s\u00a0]+)\.$/.exec(text);
  if (m) return { code: "engine.maxBetNow", params: { n: num(m[1]!) } };
  // « CF» és opcional: el servidor ja no l'envia; els textos antics (amb unitat) es continuen reconeixent.
  m = /^7 i Mig natural — \+([\d.,\s\u00a0]+?)(?: CF)?$/.exec(text);
  if (m) return { code: "engine.result.naturalWin", params: { amount: num(m[1]!) } };
  m = /^(Mort|3 canviat) ×2 — \+([\d.,\s\u00a0]+?)(?: CF)?$/.exec(text);
  if (m) {
    return {
      code: "engine.result.specialWin",
      params: { amount: num(m[2]!), special: m[1] === "Mort" ? "mort" : "threeSwap" },
    };
  }
  m = /^\+([\d.,\s\u00a0]+?)(?: CF)? \(banca passada\)$/.exec(text);
  if (m) return { code: "engine.result.winBankBust", params: { amount: num(m[1]!) } };
  m = /^\+([\d.,\s\u00a0]+?)(?: CF)?$/.exec(text);
  if (m) return { code: "engine.result.win", params: { amount: num(m[1]!) } };
  return null;
}
