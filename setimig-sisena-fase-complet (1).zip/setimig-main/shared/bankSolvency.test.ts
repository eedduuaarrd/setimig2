import assert from "node:assert/strict";
import { describe, it } from "node:test";
import {
  applyBettingPhaseTimeout,
  applyDouble,
  applyPlaceBet,
  applySplit,
  emptyRoomBase,
  settleGame,
  type GameHost,
  type HandSlot,
  type Player,
  type Room,
} from "./gameEngine.ts";
import { pickNextBankerInSeatOrder } from "./bankRotation.ts";
import type { Card } from "../src/gameTypes.ts";

const host: GameHost = {
  emitRoomUpdate() {},
  schedule: () => ({} as ReturnType<typeof setTimeout>),
  clearTimeout() {},
};

function card(value: number, suit: Card["suit"] = "hearts"): Card {
  const points = value >= 10 ? 0.5 : value;
  return { suit, value, points };
}

function player(id: string, chips: number, bet = 0, handSlots: HandSlot[] = []): Player {
  return {
    id,
    playerId: id,
    seatToken: id,
    name: id,
    chips,
    bet,
    isBanker: false,
    status: "betting",
    handSlots,
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
  };
}

function banker(chips: number): Player {
  return { ...player("bank", chips), isBanker: true };
}

function slot(id: string, bet: number, cards: Card[], canDouble = false): HandSlot {
  return {
    id,
    bet,
    cards: cards.map((c, i) => ({ id: `${id}-${i}`, card: c, faceUp: true })),
    doubled: false,
    canDouble,
    mort: false,
    blindPair: false,
    blindUntilBankEnd: false,
    mortOffered: false,
    status: "playing",
  };
}

describe("bank solvency", () => {
  it("rejects wagers when the banker cannot fund minimum natural liability for all eligible opponents", () => {
    const room = emptyRoomBase("short-bank", "Short", 100, 0);
    room.phase = "betting";
    const bank = banker(250);
    const first = player("first", 1_000);
    const second = player("second", 1_000);
    room.players = [bank, first, second];

    assert.equal(applyPlaceBet(room, first, 100), "La banca no pot cobrir l'aposta mínima.");
    assert.equal(applyPlaceBet(room, second, 100), "La banca no pot cobrir l'aposta mínima.");
    assert.equal(first.bet + second.bet, 0);
    assert.equal(room.phase, "betting");
  });

  it("returns to waiting when no eligible replacement banker exists", () => {
    const room = emptyRoomBase("no-solvent-bank", "No solvent banker", 100, 0);
    room.phase = "betting";
    const bank = banker(250);
    const first = player("first", 100);
    const second = player("second", 100);
    room.players = [bank, first, second];

    assert.equal(pickNextBankerInSeatOrder(room.players, room.minBet, bank.id), null);
    assert.equal(applyPlaceBet(room, first, 100), "La banca no pot cobrir l'aposta mínima.");
    applyBettingPhaseTimeout(host, room);

    assert.equal(room.phase, "waiting");
    assert.equal(room.pot, 0);
    assert.equal(first.bet + second.bet, 0);
  });

  it("pays multiple accepted natural winners in full", () => {
    const room = emptyRoomBase("two-naturals", "Naturals", 100, 0);
    room.phase = "betting";
    const bank = banker(400);
    bank.status = "stood";
    bank.handSlots = [slot("bank-hand", 0, [card(2), card(3)])];
    const first = player("first", 1_000);
    const second = player("second", 1_000);
    room.players = [bank, first, second];
    room.deck = [card(2), card(3), card(4), card(5)];

    assert.equal(applyPlaceBet(room, first, 100), null);
    assert.equal(applyPlaceBet(room, second, 100), null);
    bank.status = "stood";
    bank.handSlots = [slot("bank-hand", 0, [card(2), card(3)])];
    first.status = "stood";
    first.handSlots = [slot("first-hand", 100, [card(7), card(10, "spades")])];
    second.status = "stood";
    second.handSlots = [slot("second-hand", 100, [card(7, "clubs"), card(10, "diamonds")])];

    settleGame(host, room);

    assert.equal(first.chips, 1_200);
    assert.equal(second.chips, 1_200);
    assert.equal(bank.chips, 0);
  });

  it("reserves committed wagers below minBet and settles both naturals in full", () => {
    const room = emptyRoomBase("committed-naturals", "Committed naturals", 100, 0);
    room.phase = "betting";
    const bank = banker(400);
    const first = player("first", 150);
    const second = player("second", 500);
    room.players = [bank, first, second];

    assert.equal(applyPlaceBet(room, first, 100), null);
    assert.equal(first.chips, 50);
    assert.equal(applyPlaceBet(room, second, 200), null);
    assert.equal(room.pot, first.bet + second.bet);

    bank.handSlots = [slot("bank-hand", 0, [card(7), card(7, "spades")])];
    bank.status = "busted";
    first.handSlots = [slot("first-hand", first.bet, [card(7), card(10, "spades")])];
    first.status = "stood";
    second.handSlots = [slot("second-hand", second.bet, [card(7, "clubs"), card(10, "diamonds")])];
    second.status = "stood";

    settleGame(host, room);

    assert.equal(first.chips, 150 + first.bet * 2);
    assert.equal(second.chips, 500 + second.bet * 2);
    assert.equal(second.bet, 100);
    assert.equal(second.chips, 700);
    assert.equal(bank.chips, 0);
    assert.equal(room.pot, 0);
  });

  it("rejects a split that would put total table natural liability over the bank", () => {
    const room = emptyRoomBase("split-exposure", "Split", 100, 0);
    room.houseRulesEnabled = true;
    room.phase = "playing";
    room.turnPlayerIndex = 0;
    const bank = banker(500);
    const first = player("first", 900, 100, [slot("first-hand", 100, [card(10), card(10, "spades")])]);
    const second = player("second", 900, 100, [slot("second-hand", 100, [card(3)])]);
    room.players = [bank, first, second];
    room.pot = 200;

    assert.equal(applySplit(room, first.id), "La banca no pot cobrir el split.");
    assert.equal(first.bet, 100);
    assert.equal(first.handSlots.length, 1);
    assert.equal(room.pot, 200);
  });

  it("una mà separada no es dobla; un doble aliè que la banca no cobreix es rebutja", () => {
    const room = emptyRoomBase("double-exposure", "Double", 100, 0);
    room.houseRulesEnabled = true;
    room.phase = "playing";
    room.turnPlayerIndex = 0;
    const bank = banker(1_000);
    const first = player("first", 900, 100, [slot("first-hand", 100, [card(10), card(10, "spades")], true)]);
    const second = player("second", 700, 300, [slot("second-hand", 300, [card(3)], true)]);
    room.players = [bank, first, second];
    room.pot = 400;

    assert.equal(applySplit(room, first.id), null);
    assert.equal(first.bet, 200);
    assert.equal(room.pot, 500);
    assert.equal(applyDouble(host, room, first.id), "Una mà separada no es pot doblar.");
    assert.equal(first.bet, 200);
    assert.equal(first.handSlots[0]!.bet, 100);
    assert.equal(first.handSlots[0]!.canDouble, false);
    assert.equal(room.pot, 500);

    room.turnPlayerIndex = 1;
    assert.equal(applyDouble(host, room, second.id), "La banca no pot cobrir el doble.");
    assert.equal(second.bet, 300);
    assert.equal(second.handSlots[0]!.doubled, false);
    assert.equal(room.pot, 500);
  });
});
