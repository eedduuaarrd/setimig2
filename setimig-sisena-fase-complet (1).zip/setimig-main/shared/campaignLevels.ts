import type { BotDifficulty } from "./ai/botDifficulty.ts";

export const CAMPAIGN_LEVEL_COUNT = 10;

export type CampaignLevelDef = {
  level: number;
  title: string;
  botDifficulty: BotDifficulty;
  botCount: number;
  startingChips: number;
  handsTotal: number;
};

/** Seqüència de campanya: dificultat i paràmetres progressius (sense canviar regles del motor). */
export const CAMPAIGN_LEVELS: readonly CampaignLevelDef[] = [
  { level: 1, title: "Entrenament", botDifficulty: "easy", botCount: 1, startingChips: 1_500, handsTotal: 5 },
  { level: 2, title: "Dues rivales", botDifficulty: "easy", botCount: 2, startingChips: 1_500, handsTotal: 6 },
  { level: 3, title: "Taula plena", botDifficulty: "easy", botCount: 3, startingChips: 1_800, handsTotal: 7 },
  { level: 4, title: "Ritme normal", botDifficulty: "normal", botCount: 2, startingChips: 2_000, handsTotal: 8 },
  { level: 5, title: "Pressió mitjana", botDifficulty: "normal", botCount: 3, startingChips: 2_000, handsTotal: 9 },
  { level: 6, title: "Deu mans", botDifficulty: "normal", botCount: 4, startingChips: 2_000, handsTotal: 10 },
  { level: 7, title: "Dur", botDifficulty: "hard", botCount: 2, startingChips: 2_000, handsTotal: 10 },
  { level: 8, title: "Cercle tancat", botDifficulty: "hard", botCount: 3, startingChips: 2_200, handsTotal: 11 },
  { level: 9, title: "Quartet", botDifficulty: "hard", botCount: 4, startingChips: 2_500, handsTotal: 12 },
  { level: 10, title: "Final", botDifficulty: "hard", botCount: 5, startingChips: 3_000, handsTotal: 15 },
];

export function getCampaignLevel(level: number): CampaignLevelDef | null {
  if (!Number.isInteger(level) || level < 1 || level > CAMPAIGN_LEVEL_COUNT) return null;
  return CAMPAIGN_LEVELS[level - 1] ?? null;
}

export function parseCampaignLevelInput(raw: unknown): number | null {
  if (raw === undefined || raw === null) return null;
  const n = Number(raw);
  if (!Number.isInteger(n)) return null;
  return getCampaignLevel(n) ? n : null;
}
