import { normalizeRisingBlindsOptions, type RisingBlindsOptions } from "./risingBlinds.ts";

export const FAST_TOURNAMENT_START_CHIPS = 2_000;

export type FastTournamentOptions = {
  enabled: boolean;
  risingBlinds: RisingBlindsOptions;
};

export function defaultFastTournamentRisingBlinds(): RisingBlindsOptions {
  return { enabled: true, handsPerLevel: 3 };
}

export function normalizeFastTournamentOptions(raw: unknown): FastTournamentOptions | null {
  if (raw === undefined || raw === null) {
    return { enabled: false, risingBlinds: { enabled: false, handsPerLevel: 3 } };
  }
  if (typeof raw !== "object" || Array.isArray(raw)) return null;
  const input = raw as Record<string, unknown>;
  let enabled = false;
  if (input.enabled !== undefined) {
    if (typeof input.enabled !== "boolean") return null;
    enabled = input.enabled;
  }
  const risingRaw = input.risingBlinds ?? (enabled ? { enabled: true } : undefined);
  const risingBlinds = normalizeRisingBlindsOptions(risingRaw);
  if (!risingBlinds) return null;
  if (enabled && !risingBlinds.enabled) {
    return { enabled: true, risingBlinds: defaultFastTournamentRisingBlinds() };
  }
  return { enabled, risingBlinds };
}

export function isFastTournamentRoom(room: { fastTournament?: boolean }): boolean {
  return room.fastTournament === true;
}

/** Fitxes de torneig / pràctica: no es persiste el saldo real. */
export function roomUsesIsolatedPlayChips(room: {
  practiceMode?: boolean;
  fastTournament?: boolean;
}): boolean {
  return !!(room.practiceMode || room.fastTournament);
}
