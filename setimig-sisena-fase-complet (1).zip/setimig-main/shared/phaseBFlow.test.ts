import { describe, it, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";
import { createServer, type Server as HttpServer } from "http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket as ClientSocket } from "socket.io-client";
import { setupGameHandlers } from "../server/game.ts";
import type { RoomView } from "../src/gameTypes.ts";
import { resetBalanceStoreCacheForTests, setBalance } from "../server/balances.ts";
import { issuePlayerToken } from "../server/playerToken.ts";
import { resetGameStateForTests } from "../server/game.ts";
import { PHASE_B_HAND_COUNT, PHASE_B_START_CHIPS, totalTableChips } from "./matchPhaseB.ts";
import { getRoomSnapshotForTests } from "../server/game.ts";

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";

const SOLO_ID = "phasebsoloplayer01";
const HOST_ID = "phasebprivhost01";
const GUEST_ID = "phasebprivguest1";
const SEED = "84001";

type TestServer = { url: string; http: HttpServer; io: SocketIOServer };

async function startTestServer(): Promise<TestServer> {
  const http = createServer();
  const io = new SocketIOServer(http, { cors: { origin: "*" } });
  await setupGameHandlers(io);
  await new Promise<void>((resolve) => http.listen(0, "127.0.0.1", () => resolve()));
  const addr = http.address();
  const port = typeof addr === "object" && addr ? addr.port : 0;
  return { url: `http://127.0.0.1:${port}`, http, io };
}

async function stopTestServer(server: TestServer): Promise<void> {
  server.io.close();
  await new Promise<void>((resolve, reject) => {
    server.http.close((err) => (err ? reject(err) : resolve()));
  });
}

function connect(url: string): Promise<ClientSocket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.on("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.on("connect_error", reject);
  });
}

function bindGameErrors(socket: ClientSocket, onFatal: (err: Error) => void) {
  socket.on("game_error", (err: { message?: string; code?: string }) => {
    const msg = err.message ?? "";
    if (err.code === "BAD_TURN" || msg.includes("No és el teu torn")) return;
    if (msg.includes("Ja has apostat")) return;
    if (err.code === "BAD_PHASE" || err.code === "REPLAY") return;
    if (msg.includes("duplicada")) return;
    onFatal(new Error(msg || err.code || "game_error"));
  });
}

function autoSolo(socket: ClientSocket, room: RoomView, humanId: string) {
  const me = room.players?.find((p) => p.id === humanId);
  if (!me) return;
  if (me.pendingBankChoice) {
    socket.emit("bank_keep_choice", { roomId: room.id, keep: false });
    return;
  }
  if (room.phase === "betting" && !me.isBanker && me.bet === 0) {
    socket.emit("place_bet", { roomId: room.id, amount: room.minBet ?? 100 });
    return;
  }
  const turnId = (() => {
    if (room.turnPlayerId) return room.turnPlayerId;
    const list = room.players ?? [];
    const bankerIdx = list.findIndex((p) => p.isBanker);
    const nonBankers =
      bankerIdx < 0
        ? list.filter((p) => !p.isBanker)
        : (() => {
            const ordered: typeof list = [];
            for (let i = 1; i <= list.length; i += 1) {
              const p = list[(bankerIdx + i) % list.length]!;
              if (!p.isBanker) ordered.push(p);
            }
            return ordered;
          })();
    if (room.phase === "playing") return nonBankers[room.turnIndex ?? 0]?.id;
    if (room.phase === "banker") return list.find((p) => p.isBanker)?.id;
    return undefined;
  })();
  if (turnId !== humanId) return;
  if (room.phase === "playing" && me.pendingChoices?.canMort) {
    socket.emit("mort_action", { roomId: room.id, accept: false });
    return;
  }
  if (room.phase === "playing" || room.phase === "banker") {
    socket.emit("stand", room.id);
  }
}

describe("phase B integration", () => {
  beforeEach(() => {
    process.env.SETIMIG_TEST_FAST = "1";
    process.env.SETIMIG_TEST_SHUFFLE_SEED = SEED;
    resetGameStateForTests();
    resetBalanceStoreCacheForTests();
  });

  afterEach(() => {
    resetGameStateForTests();
    delete process.env.SETIMIG_TEST_FAST;
    delete process.env.SETIMIG_TEST_SHUFFLE_SEED;
  });

  it("solo: 10-hand match to game_over, chip conservation, revenge", async () => {
    await setBalance(SOLO_ID, 9_999);
    const server = await startTestServer();
    const socket = await connect(server.url);
    let humanId = "";
    try {
      await new Promise<void>((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("solo phase B timeout")), 120_000);
        let rematched = false;

        const onRoom = (room: RoomView) => {
          autoSolo(socket, room, humanId);
          const snap = getRoomSnapshotForTests(room.id);
          if (snap?.matchEnded && room.matchResult && !rematched) {
            assert.equal(snap.phaseB?.handsCompleted, PHASE_B_HAND_COUNT);
            rematched = true;
            socket.emit("quick_rematch", room.id);
            return;
          }

          if (rematched && snap?.phase === "betting" && !room.matchResult) {
            clearTimeout(timer);
            socket.off("room_update", onRoom);
            resolve();
          }
        };

        socket.on("joined_room", (room) => {
          humanId = socket.id;
          onRoom(room);
        });
        socket.on("room_update", onRoom);
        bindGameErrors(socket, reject);

        socket.emit("join_solo_room", { playerName: "PBSolo", playerId: SOLO_ID, botCount: 2 });
      });
    } finally {
      socket.disconnect();
      await stopTestServer(server);
    }
  });

  it("private two humans: 10-hand match with chip conservation", async () => {
    const hostToken = issuePlayerToken(HOST_ID)!;
    const guestToken = issuePlayerToken(GUEST_ID)!;
    const server = await startTestServer();
    const host = await connect(server.url);
    const guest = await connect(server.url);
    let poolBaseline: number | null = null;
    const actionSeq = { host: 1, guest: 1 };

    function currentTurnId(room: RoomView): string | undefined {
      if (room.turnPlayerId) return room.turnPlayerId;
      const list = room.players ?? [];
      const bankerIdx = list.findIndex((p) => p.isBanker);
      const nonBankers =
        bankerIdx < 0
          ? list.filter((p) => !p.isBanker)
          : (() => {
              const ordered: typeof list = [];
              for (let i = 1; i <= list.length; i += 1) {
                const p = list[(bankerIdx + i) % list.length]!;
                if (!p.isBanker) ordered.push(p);
              }
              return ordered;
            })();
      if (room.phase === "playing") return nonBankers[room.turnIndex ?? 0]?.id;
      if (room.phase === "banker") return list.find((p) => p.isBanker)?.id;
      return undefined;
    }

    const autoPrivate = (
      socket: ClientSocket,
      room: RoomView,
      id: string,
      token: string,
      side: "host" | "guest"
    ) => {
      const me = room.players?.find((p) => p.id === id);
      if (!me || me.isBot) return;
      const nextSeq = () => actionSeq[side]++;
      if (me.pendingBankChoice) {
        socket.emit("bank_keep_choice", {
          roomId: room.id,
          keep: false,
          playerToken: token,
          actionSeq: nextSeq(),
        });
        return;
      }
      if (room.phase === "betting" && !me.isBanker && me.status === "betting" && me.bet === 0) {
        socket.emit("place_bet", {
          roomId: room.id,
          amount: room.minBet ?? 100,
          playerToken: token,
          actionSeq: nextSeq(),
        });
        return;
      }
      const turnId = currentTurnId(room);
      if (turnId !== id) return;
      if (room.phase === "playing" && me.pendingChoices?.canMort) {
        socket.emit("mort_action", {
          roomId: room.id,
          accept: false,
          playerToken: token,
          actionSeq: nextSeq(),
        });
        return;
      }
      if (room.phase === "playing" || room.phase === "banker") {
        socket.emit("stand", { roomId: room.id, playerToken: token, actionSeq: nextSeq() });
      }
    };

    try {
      const hostRoom = await new Promise<RoomView>((resolve, reject) => {
        const t = setTimeout(() => reject(new Error("host timeout")), 15_000);
        host.once("joined_room", (room) => {
          clearTimeout(t);
          resolve(room);
        });
        host.emit("create_private_table", {
          playerName: "Host",
          playerId: HOST_ID,
          playerToken: hostToken,
        });
      });

      await new Promise<void>((resolve, reject) => {
        const t = setTimeout(() => reject(new Error("guest timeout")), 15_000);
        guest.once("joined_room", () => {
          clearTimeout(t);
          resolve();
        });
        guest.emit("join_private_table", {
          inviteCode: hostRoom.inviteCode,
          playerName: "Guest",
          playerId: GUEST_ID,
          playerToken: guestToken,
        });
      });

      host.emit("start_game", {
        roomId: hostRoom.id,
        playerToken: hostToken,
        actionSeq: actionSeq.host++,
      });

      await new Promise<void>((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error("private 10-hand timeout")), 180_000);
        let hostId = host.id;
        let guestId = guest.id;

        const onUpdate = (room: RoomView) => {
          autoPrivate(host, room, hostId, hostToken, "host");
          autoPrivate(guest, room, guestId, guestToken, "guest");
          const snap = getRoomSnapshotForTests(room.id);
          if (snap?.phaseB && poolBaseline === null) {
            poolBaseline = snap.phaseB.chipPool;
          }
          if (snap?.matchEnded && room.matchResult) {
            assert.equal(snap.phaseB?.handsCompleted, PHASE_B_HAND_COUNT);
            if (poolBaseline !== null) {
              assert.equal(
                totalTableChips({ players: snap.players, pot: snap.pot, jackpot: snap.jackpot }),
                poolBaseline
              );
            }
            clearTimeout(timer);
            host.off("room_update", onUpdate);
            guest.off("room_update", onUpdate);
            resolve();
          }
        };

        host.on("room_update", onUpdate);
        guest.on("room_update", onUpdate);
        bindGameErrors(host, reject);
        bindGameErrors(guest, reject);
      });
    } finally {
      host.disconnect();
      guest.disconnect();
      await stopTestServer(server);
    }
  });
});
