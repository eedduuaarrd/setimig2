import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  applyBankerToPlayer,
  bankerCanCover,
  bankerCanCoverWagerRange,
  bettingCoverageCap,
  maxBet,
  botAcceptsBankOfferWithCover,
  maxBetPerOpponent,
  mustRotateBankAfterHand,
  pickNextBankerInSeatOrder,
} from "./bankRotation.ts";

describe("bankRotation", () => {
  it("requires 2:1 natural coverage for every opponent's minimum wager", () => {
    assert.equal(bankerCanCover(600, 100, 3), true);
    assert.equal(bankerCanCover(599, 100, 3), false);
    assert.equal(bankerCanCover(400, 100, 2), true);
    assert.equal(bankerCanCover(399, 100, 2), false);
  });

  it("maxBet respects player balance and available bank coverage", () => {
    const state = {
      minBet: 100,
      players: [
        { id: "b", isBanker: true, chips: 250 },
        { id: "p1", isBanker: false, chips: 666 },
        { id: "p2", isBanker: false, chips: 50 },
      ],
    };
    assert.equal(maxBet(state, "p1"), 125);
    assert.equal(maxBet(state, "p2"), 50);
  });

  it("applies a creator-selected maximum in addition to solvency and player chips", () => {
    const state = {
      minBet: 100,
      tableMaxBet: 550,
      players: [
        { id: "b", isBanker: true, chips: 20_000 },
        { id: "p", isBanker: false, chips: 2_000 },
      ],
    };
    assert.equal(maxBet(state, "p"), 550);
    assert.equal(maxBet({ ...state, players: [...state.players.slice(0, 1), { id: "p", isBanker: false, chips: 400 }] }, "p"), 400);
    assert.equal(maxBet({ ...state, players: [{ id: "b", isBanker: true, chips: 1_000 }, state.players[1]!] }, "p"), 0);
    const mixedStacks = {
      ...state,
      players: [
        { id: "b", isBanker: true, chips: 1_500 },
        { id: "p", isBanker: false, chips: 2_000 },
        { id: "q", isBanker: false, chips: 200 },
      ],
    };
    assert.equal(maxBet(mixedStacks, "p"), 550);
    assert.equal(maxBet(mixedStacks, "q"), 200);
  });

  it("reserves committed wagers and pending minimums without lowering the safe maximum", () => {
    const state = {
      minBet: 100,
      players: [
        { id: "b", isBanker: true, chips: 500 },
        { id: "p1", isBanker: false, chips: 1_000 },
        { id: "p2", isBanker: false, chips: 1_000 },
      ],
    };
    assert.equal(maxBet(state, "p1"), 150);
    const afterFirstWager = {
      ...state,
      players: [state.players[0]!, { ...state.players[1]!, chips: 850, bet: 150 }, state.players[2]!],
    };
    assert.equal(maxBet(afterFirstWager, "p2"), 100);
  });

  it("covers the players' actual maxima within the creator-selected range", () => {
    assert.equal(bankerCanCoverWagerRange(1_500, 100, [2_000, 200], 550), true);
    assert.equal(bankerCanCoverWagerRange(1_499, 100, [2_000, 200], 550), false);
    assert.equal(bankerCanCoverWagerRange(400, 100, [2_000, 200]), true);
  });

  it("caps per-opponent bets by worst-case 2:1 natural liability", () => {
    assert.equal(maxBetPerOpponent(250, 2), 125);
    assert.equal(maxBetPerOpponent(250, 2, 2), 62);
    assert.equal(bettingCoverageCap(250, 2, 100), null);
    assert.equal(bettingCoverageCap(500, 2, 100), 125);
    assert.equal(bettingCoverageCap(399, 2, 100), null);
    assert.equal(bettingCoverageCap(400, 2, 100), 100);
  });

  it("bots reject bank without natural-payout cover", () => {
    assert.equal(botAcceptsBankOfferWithCover(399, 100, 2), false);
    assert.equal(botAcceptsBankOfferWithCover(400, 100, 2), true);
  });

  it("rotates after three consecutive hands", () => {
    assert.equal(mustRotateBankAfterHand(2), false);
    assert.equal(mustRotateBankAfterHand(3), true);
  });

  it("chooses a banker who can cover the configured maximum", () => {
    const players = [
      { id: "a", isBanker: true, chips: 50 },
      { id: "b", isBanker: false, chips: 300 },
      { id: "c", isBanker: false, chips: 2_000 },
    ];
    assert.equal(pickNextBankerInSeatOrder(players, 100, "a", 300)?.id, "c");
  });

  it("picks next eligible banker in seat order", () => {
    const players = [
      { id: "a", isBanker: true, chips: 50 },
      { id: "b", isBanker: false, chips: 2_000 },
      { id: "c", isBanker: false, chips: 2_000 },
    ];
    const next = pickNextBankerInSeatOrder(players, 100);
    assert.equal(next?.id, "b");
    applyBankerToPlayer(players, "b");
    assert.equal(players[0]!.isBanker, false);
    assert.equal(players[1]!.isBanker, true);
  });
});
