/**
 * Repart v2 (servidor): `card_dealt` ordenat i sense forats, cartes ocultes que no es filtren,
 * i el torn següent que no s'activa fins que acaba l'animació (temps de repart-v2.md).
 * Els tests del motor fan servir el rellotge virtual (shared/testing/manualClockHost.ts).
 */
import { describe, it, before, after, beforeEach, afterEach } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { createServer } from "node:http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient, type Socket } from "socket.io-client";
import {
  applyDouble,
  applyHit,
  applyMort,
  applyPlaceBet,
  applySplit,
  applyStand,
  BOT_TURN_WATCHDOG_MS,
  currentPlayer,
  dealAnimWaitMs,
  emptyRoomBase,
  roomToView,
  scheduleAfterRoomChange,
  type Player,
  type Room,
} from "./gameEngine.ts";
import { createManualClockHost } from "./testing/manualClockHost.ts";
import { createSingleSpanishDeck } from "./spanishDeck.ts";
import type { Card } from "../src/gameTypes.ts";
import type { CardDealtEvent } from "./dealEvents.ts";
import { ACTION_HIT_HOLD_MS, BOT_ACTION_MAX_MS, BOT_ACTION_MIN_MS, DEAL_CARD_MS } from "./pacing.ts";

const deckCards = createSingleSpanishDeck();
function card(value: number, suit: Card["suit"] = "hearts"): Card {
  const c = deckCards.find((d) => d.value === value && d.suit === suit);
  assert.ok(c, `carta ${value} ${suit}`);
  return { ...c };
}
/** `drawCard` fa pop(): la primera carta de la llista és la primera que surt. */
function stackDeck(room: Room, draws: Card[]) {
  const rest = deckCards.filter((d) => !draws.some((x) => x.value === d.value && x.suit === d.suit));
  room.deck = [...rest.map((c) => ({ ...c })), ...[...draws].reverse()];
}

function seat(id: string, extra: Partial<Player> = {}): Player {
  return {
    id,
    playerId: id,
    seatToken: `tok-${id}`,
    name: id,
    chips: 5_000,
    bet: 0,
    isBanker: false,
    status: "betting",
    handSlots: [],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
    ...extra,
  };
}

function bettingRoom(players: Player[], draws: Card[], extra: Partial<Room> = {}): Room {
  const room = emptyRoomBase("rep-unit", "Repart", 100, 0);
  room.players = players;
  room.phase = "betting";
  room.houseRulesEnabled = false;
  Object.assign(room, extra);
  stackDeck(room, draws);
  return room;
}

function placeAllBets(room: Room) {
  for (const p of room.players) if (!p.isBanker) assert.equal(applyPlaceBet(room, p, 100), null);
  assert.equal(room.phase, "playing");
}

/** Acaba l'avís HIT/STAND amb el rellotge virtual (sense espera real). */
function endHold(clock: ReturnType<typeof createManualClockHost>, room: Room) {
  for (let i = 0; i < 6 && room.actionHoldEndsAt; i += 1) {
    const wait = Math.max(0, room.actionHoldEndsAt - clock.dateNow());
    clock.advance(wait === 0 ? 1 : wait);
  }
}

function assertGapless(room: Room) {
  const seqs = (room.dealLog ?? []).map((d) => d.dealSeq);
  assert.deepEqual(seqs, seqs.map((_, i) => i + 1), "dealSeq 1..n sense forats");
}

describe("repart v2 (motor, rellotge virtual)", () => {
  let clock: ReturnType<typeof createManualClockHost>;
  let scheduled: number[];
  let savedFast: string | undefined;

  beforeEach(() => {
    // Temps reals de l'animació (amb SETIMIG_TEST_FAST valen 0).
    savedFast = process.env.SETIMIG_TEST_FAST;
    delete process.env.SETIMIG_TEST_FAST;
    scheduled = [];
    clock = createManualClockHost({ syncDateNow: true, onSchedule: (ms) => scheduled.push(ms) });
  });
  afterEach(() => {
    clock.restoreDateNow();
    if (savedFast === undefined) delete process.env.SETIMIG_TEST_FAST;
    else process.env.SETIMIG_TEST_FAST = savedFast;
  });

  it("repartiment inicial: un per seient, la banca l'última i tapada, i finestra cartes × DEAL_CARD_MS", () => {
    const B = seat("B", { isBot: true, isBanker: true, chips: 50_000 });
    const H = seat("H");
    const A = seat("A", { isBot: true });
    const C = seat("C", { isBot: true });
    const room = bettingRoom([B, H, A, C], [card(5), card(6), card(2), card(1)]);
    placeAllBets(room);
    const log = room.dealLog!;
    assert.equal(log.length, 4);
    assertGapless(room);
    assert.deepEqual(log.map((d) => d.playerId), ["H", "A", "C", "B"]);
    assert.ok(log.every((d) => d.kind === "initial" && d.handSeq === 1));
    assert.deepEqual(log.map((d) => d.initialIndex), [0, 1, 2, 3]);
    assert.deepEqual(log.map((d) => d.delayMs), [0, DEAL_CARD_MS, 2 * DEAL_CARD_MS, 3 * DEAL_CARD_MS]);
    assert.equal(dealAnimWaitMs(room), 4 * DEAL_CARD_MS, "4 cartes × DEAL_CARD_MS abans del primer torn");

    // La carta de la banca no surt a cap vista (ni a la mateixa banca) fins al seu torn.
    for (const viewer of ["H", "A", "B"]) {
      const v = roomToView(room, viewer, clock.host);
      const bankCard = v.players.find((p) => p.id === "B")!.handSlots[0]!.cards[0]!;
      assert.equal(bankCard.card, null);
      assert.equal(bankCard.faceUp, false);
      assert.deepEqual(v.deal, { handSeq: 1, lastDealSeq: 4, animUntil: clock.dateNow() + 4 * DEAL_CARD_MS });
    }
  });

  it("humà primer: el termini del torn comença quan acaba l'animació del repartiment", () => {
    const room = bettingRoom(
      [seat("B", { isBot: true, isBanker: true, chips: 50_000 }), seat("H"), seat("A", { isBot: true })],
      [card(5), card(6), card(2)]
    );
    placeAllBets(room);
    assert.equal(currentPlayer(room)?.id, "H");
    const wait = dealAnimWaitMs(room);
    assert.equal(wait, 3 * DEAL_CARD_MS, "3 cartes × DEAL_CARD_MS");
    scheduleAfterRoomChange(clock.host, room);
    const withAnim = room.turnDeadlineAt! - clock.dateNow();
    // Mateixa sala sense animació pendent: el termini «normal». El termini queda ancorat al punt
    // de decisió (una nova publicació no l'allarga), així que es desancora per tornar-lo a calcular.
    room.dealAnimUntil = null;
    room.turnDeadlineKey = null;
    scheduleAfterRoomChange(clock.host, room);
    const plain = room.turnDeadlineAt! - clock.dateNow();
    assert.equal(withAnim, plain + wait);
    assert.ok(scheduled.includes(plain + wait), "el temporitzador de l'humà també espera l'animació");
  });

  it("bot: no actua abans del final de l'animació i manté el ritme 1,2–1,5 s; passar-se = 600 ms màxim", () => {
    const B = seat("B", { isBot: true, isBanker: true, chips: 50_000 });
    const A = seat("A", { isBot: true });
    const C = seat("C", { isBot: true });
    const H = seat("H");
    // A: 6 inicial i després un 7 → es passa.
    const room = bettingRoom([B, A, C, H], [card(6), card(2), card(1), card(5), card(7)]);
    placeAllBets(room);
    const initialWait = dealAnimWaitMs(room);
    assert.equal(initialWait, 4 * DEAL_CARD_MS);
    scheduled = [];
    scheduleAfterRoomChange(clock.host, room);
    const botDelay = Math.max(...scheduled.filter((ms) => ms < BOT_TURN_WATCHDOG_MS));
    assert.ok(botDelay >= initialWait, "el primer bot no actua abans que acabi el repartiment");
    assert.ok(botDelay >= BOT_ACTION_MIN_MS && botDelay <= BOT_ACTION_MAX_MS, `ritme del bot ${botDelay}`);

    // Passat el repartiment però abans que el bot decideixi; la decisió del bot és aleatòria,
    // així que forcem «demana» per controlar la carta. El temporitzador del bot cau al mateix
    // instant que acaba el repartiment (cartes × 350 ≥ 1,2 s): es cancel·la abans d'avançar.
    clock.host.clearTimeout(room.botTimer);
    clock.host.clearTimeout(room.botWatchdogTimer);
    clearBotTimers(room);
    clock.advance(initialWait);
    assert.equal(dealAnimWaitMs(room), 0);
    assert.equal(applyHit(clock.host, room, "A"), null);
    assert.equal(room.dealLog!.at(-1)!.kind, "hit");
    assert.equal(room.dealLog!.at(-1)!.dealSeq, 5);
    const bustWait = dealAnimWaitMs(room);
    assert.equal(bustWait, 600, "vol + gir + sacsejada = 600 ms, el màxim dins el torn d'un bot");
    assert.equal(currentPlayer(room)?.id, "A", "passar-se no canvia de torn fins que acaba l'avís de HIT");
    endHold(clock, room);
    assert.equal(currentPlayer(room)?.id, "C");
    scheduled = [];
    scheduleAfterRoomChange(clock.host, room);
    const nextBot = Math.max(...scheduled.filter((ms) => ms < BOT_TURN_WATCHDOG_MS));
    assert.ok(nextBot >= BOT_ACTION_MIN_MS && nextBot <= BOT_ACTION_MAX_MS);
    assertGapless(room);
  });

  it("carta sense passar-se dins el torn: 360 ms (vol 300 + gir fins a 360)", () => {
    const room = bettingRoom(
      [seat("B", { isBot: true, isBanker: true, chips: 50_000 }), seat("H"), seat("A", { isBot: true })],
      [card(2), card(1), card(5), card(1, "clubs")]
    );
    placeAllBets(room);
    clock.advance(3 * DEAL_CARD_MS);
    assert.equal(dealAnimWaitMs(room), 0);
    assert.equal(applyHit(clock.host, room, "H"), null);
    assert.equal(dealAnimWaitMs(room), 360);
    assert.equal(room.actionHoldEndsAt, clock.dateNow() + ACTION_HIT_HOLD_MS);
    scheduleAfterRoomChange(clock.host, room);
    assert.equal(room.turnDeadlineAt, null, "el rellotge del torn no corre durant l'avís");
    endHold(clock, room);
    assert.equal(room.actionHoldEndsAt ?? null, null);
    assert.ok(room.turnDeadlineAt && room.turnDeadlineAt > clock.dateNow(), "el torn comença quan acaba l'avís");
  });

  it("dealSeq sense forats amb demana, separar, doblar, mort i la banca", () => {
    const B = seat("B", { isBanker: true, chips: 50_000 });
    const H = seat("H");
    const M = seat("M");
    const room = bettingRoom(
      [B, H, M],
      [
        card(10), // H inicial
        card(7, "clubs"), // M inicial (mort)
        card(5), // banca
        card(10, "spades"), // H dobla → parella de sotes; després es pot separar
        card(2), // segona carta automàtica de la mà 1 (½+2)
        card(1, "diamonds"), // segona carta automàtica de la mà 2 (½+1)
        card(4), // H demana a la mà 2 (½+1+4 = 5½, no es passa)
        card(1), // M mort
        card(1, "clubs"), // banca demana
      ],
      { houseRulesEnabled: true }
    );
    placeAllBets(room);
    // Doblar només amb la primera carta; després, amb dues figures, es pot separar.
    // Una mà separada ja no es pot doblar.
    assert.equal(applyDouble(clock.host, room, "H"), null);
    assert.equal(applySplit(room, "H"), null);
    assert.equal(applyDouble(clock.host, room, "H"), "La mà original ja havia doblat abans del split.");
    // Es planta la mà 1 i passa a la mà 2.
    assert.equal(applyStand(clock.host, room, "H"), null);
    endHold(clock, room);
    assert.equal(applyHit(clock.host, room, "H"), null);
    endHold(clock, room);
    assert.equal(applyStand(clock.host, room, "H"), null);
    endHold(clock, room);
    assert.equal(currentPlayer(room)?.id, "M");
    assert.equal(applyMort(clock.host, room, "M", true), null);
    assert.equal(room.phase, "banker");
    assert.equal(dealAnimWaitMs(room) >= 240, true, "la revelació de la banca (240 ms) compta");
    assert.equal(applyHit(clock.host, room, "B"), null);
    assertGapless(room);
    assert.deepEqual(
      room.dealLog!.map((d) => `${d.playerId}:${d.kind}:${d.slotIndex}`),
      [
        "H:initial:0",
        "M:initial:0",
        "B:initial:0",
        "H:double:0",
        "H:split:1",
        "H:hit:0",
        "H:hit:1",
        "H:hit:1",
        "M:mort:0",
        "B:hit:0",
      ]
    );
    // La carta moguda en separar és la de «demana» (mateix cardId), ara a la mà 2.
    assert.equal(room.dealLog![4]!.cardId, room.dealLog![3]!.cardId);
    // L'últim registre de cada carta apunta on és ara.
    const latest = new Map(room.dealLog!.map((d) => [d.cardId, d]));
    for (const d of latest.values()) {
      const p = room.players.find((x) => x.playerId === d.playerId)!;
      assert.equal(p.handSlots[d.slotIndex]!.cards.some((c) => c.id === d.cardId), true, `${d.dealSeq}`);
    }
  });

  it("el vigilant del bot dona el temps de l'animació de més", () => {
    const room = bettingRoom(
      [seat("B", { isBot: true, isBanker: true, chips: 50_000 }), seat("A", { isBot: true }), seat("H")],
      [card(2), card(1), card(5)]
    );
    placeAllBets(room);
    room.botTurnWatch = null;
    room.dealAnimUntil = clock.dateNow() + 600;
    scheduled = [];
    scheduleAfterRoomChange(clock.host, room);
    assert.ok(scheduled.includes(BOT_TURN_WATCHDOG_MS + 600), `programats: ${scheduled.join(",")}`);
  });

  it("la mà següent torna a començar a dealSeq 1 amb el handSeq següent", () => {
    const room = bettingRoom(
      [seat("B", { isBot: true, isBanker: true, chips: 50_000 }), seat("H")],
      [card(2), card(1)]
    );
    placeAllBets(room);
    assert.equal(room.dealLog![0]!.handSeq, 1);
    room.handSeq = 1; // la liquidació de la mà 1 ja ha passat
    room.phase = "betting";
    for (const p of room.players) {
      p.bet = 0;
      p.handSlots = [];
      p.status = "betting";
    }
    stackDeck(room, [card(5), card(6)]);
    placeAllBets(room);
    assert.deepEqual(room.dealLog!.map((d) => [d.handSeq, d.dealSeq]), [
      [2, 1],
      [2, 2],
    ]);
  });
});

function clearBotTimers(room: Room) {
  room.botTimer = null;
  room.humanTimer = null;
}

// ---------------------------------------------------------------------------------------------
// Socket: solo, pràctica i taula privada.

process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";

type ViewLite = {
  id: string;
  phase: string;
  turnPlayerId?: string | null;
  minBet: number;
  players: {
    id: string;
    bet: number;
    isBanker: boolean;
    pendingBankChoice?: { mandatory: boolean } | null;
    handSlots: { cards: { id: string; card: Card | null; faceUp: boolean }[] }[];
  }[];
  settlement?: { handSeq: number } | null;
};

function connect(url: string): Promise<Socket> {
  return new Promise((resolve, reject) => {
    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    const timer = setTimeout(() => reject(new Error("connect timeout")), 10_000);
    socket.on("connect", () => {
      clearTimeout(timer);
      resolve(socket);
    });
    socket.on("connect_error", (err) => {
      clearTimeout(timer);
      reject(err);
    });
  });
}

type Run = { deals: CardDealtEvent[]; errors: string[]; settledHands: number[] };

/** Juga com a humà i comprova en viu l'ordre: cap carta al room_update sense el seu card_dealt. */
function playHands(socket: Socket, hands: number, timeoutMs = 45_000): Promise<Run> {
  const deals: CardDealtEvent[] = [];
  const errors: string[] = [];
  const settledHands: number[] = [];
  const seen = new Set<string>();
  let betKey = "";
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`timeout (${settledHands.length}/${hands})`)), timeoutMs);
    const finish = () => {
      clearTimeout(timer);
      socket.off("card_dealt", onDeal);
      socket.off("room_update", onRoom);
      resolve({ deals, errors, settledHands });
    };
    const onDeal = (d: CardDealtEvent) => {
      deals.push(d);
      seen.add(d.cardId);
      if (d.seatId !== socket.id && !d.faceUp && d.card) errors.push(`carta oculta filtrada (${d.dealSeq})`);
      if (d.isBanker && d.kind === "initial" && (d.card || d.faceUp)) errors.push("la carta inicial de la banca s'ha filtrat");
    };
    const onRoom = (room: ViewLite) => {
      if (room.phase === "playing" || room.phase === "banker" || room.phase === "settlement") {
        for (const p of room.players) {
          for (const s of p.handSlots) {
            for (const c of s.cards) if (!seen.has(c.id)) errors.push(`room_update amb ${c.id} abans del card_dealt`);
          }
        }
      }
      if (room.settlement && !settledHands.includes(room.settlement.handSeq)) {
        settledHands.push(room.settlement.handSeq);
        if (settledHands.length >= hands) setTimeout(finish, 150);
      }
      const me = room.players.find((p) => p.id === socket.id);
      if (!me) return;
      if (me.pendingBankChoice) socket.emit("bank_keep_choice", { roomId: room.id, keep: !!me.pendingBankChoice.mandatory });
      if (room.phase === "settlement") socket.emit("settlement_next", room.id);
      if (room.phase === "betting" && !me.isBanker && me.bet === 0 && betKey !== `${settledHands.length}`) {
        betKey = `${settledHands.length}`;
        socket.emit("place_bet", { roomId: room.id, amount: room.minBet });
      }
      if (room.phase === "playing" && room.turnPlayerId === socket.id) socket.emit("hit", room.id);
      if (room.phase === "banker" && me.isBanker) socket.emit("stand", room.id);
    };
    socket.on("card_dealt", onDeal);
    socket.on("room_update", onRoom);
  });
}

function assertRun(run: Run, label: string) {
  assert.deepEqual(run.errors, [], label);
  const byHand = new Map<number, number[]>();
  for (const d of run.deals) byHand.set(d.handSeq, [...(byHand.get(d.handSeq) ?? []), d.dealSeq]);
  assert.ok(byHand.size >= 1, `${label}: cap card_dealt`);
  for (const [hand, seqs] of byHand) {
    assert.deepEqual(seqs, seqs.map((_, i) => i + 1), `${label}: mà ${hand} dealSeq ordenat i sense forats`);
  }
  for (const h of run.settledHands) assert.ok(byHand.has(h), `${label}: settlement.handSeq ${h} = handSeq de card_dealt`);
}

describe("repart v2 (socket)", () => {
  let dataDir = "";
  let http: ReturnType<typeof createServer>;
  let io: SocketIOServer;
  let url = "";
  let gameModule: typeof import("../server/game.ts");

  before(async () => {
    dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "setimig-repart-v2-"));
    process.env.BALANCE_DATA_DIR = dataDir;
    process.env.SETIMIG_TEST_FAST = "1";
    gameModule = await import("../server/game.ts");
    gameModule.resetGameStateForTests();
    http = createServer();
    io = new SocketIOServer(http, { cors: { origin: "*" } });
    await gameModule.setupGameHandlers(io);
    await new Promise<void>((r) => http.listen(0, "127.0.0.1", () => r()));
    url = `http://127.0.0.1:${(http.address() as { port: number }).port}`;
  });

  after(async () => {
    io.close();
    await new Promise<void>((r) => http.close(() => r()));
    const { removeTestDataDir } = await import("../server/testing/testDataDir.ts");
    await removeTestDataDir(dataDir);
    delete process.env.BALANCE_DATA_DIR;
  });

  for (const practiceMode of [false, true]) {
    it(`solo${practiceMode ? " (pràctica)" : ""}: card_dealt ordenat, sense filtracions`, async () => {
      const socket = await connect(url);
      try {
        const runP = playHands(socket, 2);
        socket.emit("join_solo_room", {
          playerName: practiceMode ? "PracticaR" : "SolistaR",
          playerId: practiceMode ? "repartv2prac0001" : "repartv2solo0001",
          botCount: 2,
          botDifficulty: "easy",
          practiceMode,
        });
        assertRun(await runP, practiceMode ? "pràctica" : "solo");
      } finally {
        socket.disconnect();
      }
    });
  }

  it("taula privada amb dos humans: mateixa seqüència i cap carta oculta de l'altre", async () => {
    const host = await connect(url);
    const guest = await connect(url);
    try {
      const hostJoined = new Promise<ViewLite & { inviteCode?: string }>((r) => host.once("joined_room", r));
      host.emit("create_private_table", { playerName: "AmfitrioR", playerId: "repartv2host0001" });
      const hostRoom = await hostJoined;
      const guestJoined = new Promise<ViewLite>((r) => guest.once("joined_room", r));
      guest.emit("join_private_table", {
        inviteCode: hostRoom.inviteCode,
        playerName: "ConvidatR",
        playerId: "repartv2guest001",
      });
      await guestJoined;
      const hostRun = playHands(host, 2);
      const guestRun = playHands(guest, 2);
      host.emit("fill_private_bots", hostRoom.id);
      await new Promise((r) => setTimeout(r, 200));
      host.emit("start_game", hostRoom.id);
      const [h, g] = await Promise.all([hostRun, guestRun]);
      assertRun(h, "amfitrió");
      assertRun(g, "convidat");
      // Només les mans liquidades per tots dos (un socket pot haver vist ja l'inici de la següent).
      const both = h.settledHands.filter((x) => g.settledHands.includes(x));
      assert.ok(both.length >= 1);
      const pick = (r: Run) =>
        r.deals.filter((d) => both.includes(d.handSeq)).map((d) => [d.handSeq, d.dealSeq, d.cardId, d.kind]);
      assert.deepEqual(
        pick(h),
        pick(g),
        "els dos sockets reben les mateixes cartes en el mateix ordre"
      );
      // La primera carta (oculta) de l'amfitrió: ell la veu, el convidat no.
      // (Excepte la banca i la parella cega del 3 —2 cartes inicials—, que ni el propietari no veu.)
      const initialsOf = (hand: number) =>
        h.deals.filter((d) => d.handSeq === hand && d.seatId === host.id && d.kind === "initial").length;
      const hostOwn = h.deals.find(
        (d) =>
          d.seatId === host.id && !d.isBanker && d.kind === "initial" && !d.faceUp && initialsOf(d.handSeq) === 1
      );
      if (hostOwn) {
        assert.ok(hostOwn.card, "el propietari veu la seva carta oculta");
        const asGuest = g.deals.find((d) => d.cardId === hostOwn.cardId)!;
        assert.equal(asGuest.card, null, "el convidat no veu l'oculta de l'amfitrió");
      }
    } finally {
      guest.disconnect();
      host.disconnect();
    }
  });
});
