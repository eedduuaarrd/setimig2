import assert from "node:assert/strict";
import { describe, it } from "node:test";
import type { BotDifficulty } from "./ai/botDifficulty.ts";
import { BOT_DIFFICULTIES } from "./ai/botDifficulty.ts";
import {
  decideHitOrStandByDifficulty,
  decideHitOrStandHard,
} from "./ai/decisions.ts";
import {
  decideDouble,
  gatherSeenCards,
  type StrategyContext,
} from "./ai/strategy.ts";
import {
  applyDouble,
  applyHit,
  applyMort,
  applyPlaceBet,
  applyStand,
  createBotPlayer,
  emptyRoomBase,
  settleGame,
  type GameHost,
  type Player,
  type Room,
} from "./gameEngine.ts";
import { ENGINE_MESSAGES } from "./gameMessages.ts";
import { scoreCards } from "./scoring.ts";
import { fisherYatesShuffle } from "./shuffle.ts";
import { cardKey, countCardsByKey, createSingleSpanishDeck } from "./spanishDeck.ts";
import type { Card } from "../src/gameTypes.ts";

process.env.SETIMIG_TEST_FAST = "1";

const SIM_HANDS = 500;
const SIM_SEED_BASE = 149_700;

function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function instantHost(): GameHost {
  return {
    emitRoomUpdate() {},
    schedule(fn) {
      fn();
      return null as unknown as ReturnType<typeof setTimeout>;
    },
    clearTimeout() {},
  };
}

function playSubjectTurn(
  host: GameHost,
  room: Room,
  subject: Player,
  difficulty: BotDifficulty,
  rng: () => number,
  onStand?: (score: number) => void
) {
  const ctx = strategyContextForRoom(room, subject);
  const slot = subject.handSlots[subject.activeSlotIndex];
  if (!slot) return;
  if (slot.mortOffered) {
    applyMort(host, room, subject.id, false);
    return;
  }
  if (ctx.canDouble && decideDouble(ctx)) {
    applyDouble(host, room, subject.id);
    return;
  }
  const action = decideHitOrStandByDifficulty(ctx, difficulty, rng);
  if (action === "hit") applyHit(host, room, subject.id);
  else {
    onStand?.(scoreCards(slot.cards));
    applyStand(host, room, subject.id);
  }
}

function playBankerTurn(host: GameHost, room: Room, banker: Player) {
  const ctx = strategyContextForRoom(room, banker);
  const action = decideHitOrStandHard({ ...ctx, isBanker: true });
  if (action === "hit") applyHit(host, room, banker.id);
  else applyStand(host, room, banker.id);
}

function strategyContextForRoom(room: Room, player: Player): StrategyContext {
  const seen = gatherSeenCards({
    centerDiscard: room.centerDiscard,
    players: room.players,
    selfId: player.id,
    selfSlots: player.handSlots,
  });
  const slot = player.handSlots[player.activeSlotIndex] ?? player.handSlots[0];
  const hand = slot?.cards.map((c) => c.card) ?? [];
  return {
    seen,
    hand,
    minBet: room.minBet,
    chips: player.chips,
    bet: player.bet,
    rivalVisibleMax: maxVisibleNonBanker(room, player.id),
    bankerTargetScores: bankerVisibleTargets(room),
    isBanker: player.isBanker,
    mortOffered: !!slot?.mortOffered,
    canDouble: !!slot?.canDouble,
    canSplit:
      !!slot &&
      slot.cards.length === 2 &&
      slot.cards[0]!.card.points === 0.5 &&
      slot.cards[1]!.card.points === 0.5,
    blindPair: !!slot?.blindPair,
  };
}

function maxVisibleNonBanker(room: Room, selfId: string): number {
  let max = 0;
  for (const p of room.players) {
    if (p.id === selfId) continue;
    for (const slot of p.handSlots) {
      const vis = slot.cards.filter((c) => c.faceUp).map((c) => ({ card: c.card }));
      const sc = scoreCards(vis);
      if (sc > max && sc <= 7.5) max = sc;
    }
  }
  return max;
}

function bankerVisibleTargets(room: Room): number[] {
  const out: number[] = [];
  for (const p of room.players) {
    if (p.isBanker) continue;
    for (const slot of p.handSlots) {
      if (slot.status === "busted") continue;
      const vis = slot.cards.filter((c) => c.faceUp).map((c) => ({ card: c.card }));
      const sc = scoreCards(vis);
      if (sc > 0 && sc <= 7.5) out.push(sc);
    }
  }
  return out.length ? out : [5.5];
}

function startBettingWithoutPublish(room: Room) {
  room.deck = fisherYatesShuffle(createSingleSpanishDeck());
  room.centerDiscard = [];
  room.bankDraw = undefined;
  room.players.forEach((p) => {
    p.status = "betting";
    p.bet = 0;
    p.handSlots = [];
  });
  room.phase = "betting";
}

function resetPlayersForHand(room: Room, banker: Player, subject: Player) {
  banker.isBanker = true;
  subject.isBanker = false;
  subject.isBot = false;
  banker.isBot = true;
  room.pot = 0;
  room.centerDiscard = [];
  startBettingWithoutPublish(room);
}

function runSubjectHand(
  seed: number,
  difficulty: BotDifficulty
): { won: boolean; standScore: number | null } {
  process.env.SETIMIG_TEST_SHUFFLE_SEED = String(seed);
  const host = instantHost();
  const room = emptyRoomBase(`sim-${seed}`, "Sim", 100, 0);
  room.autoFillBots = false;
  const banker = createBotPlayer(room, "Bank IA");
  banker.chips = 80_000;
  const subject = createBotPlayer(room, "Subject");
  subject.chips = 80_000;
  room.players = [banker, subject];

  resetPlayersForHand(room, banker, subject);
  const chipsBefore = subject.chips;
  applyPlaceBet(room, subject, 100);

  const rng = mulberry32(seed ^ 0x9e37);
  let standScore: number | null = null;
  let guard = 0;
  while (room.phase !== "settlement" && guard++ < 120) {
    if (room.phase === "playing" && room.players.filter((p) => !p.isBanker)[room.turnPlayerIndex]?.id === subject.id) {
      playSubjectTurn(host, room, subject, difficulty, rng, (sc) => {
        standScore = sc;
      });
    } else if (room.phase === "banker") {
      playBankerTurn(host, room, banker);
    } else if (room.phase === "playing") {
      applyStand(host, room, subject.id);
    }
  }

  if (room.phase !== "settlement") {
    settleGame(host, room);
  }

  const won = subject.chips > chipsBefore + 0.001;
  delete process.env.SETIMIG_TEST_SHUFFLE_SEED;
  return { won, standScore };
}

type LevelStats = {
  wins: number;
  standScores: number[];
  winPct: number;
  meanStand: number;
};

function simulateLevel(difficulty: BotDifficulty): LevelStats {
  let wins = 0;
  const standScores: number[] = [];
  for (let i = 0; i < SIM_HANDS; i += 1) {
    const seed = SIM_SEED_BASE + i * 997 + (difficulty === "easy" ? 1 : difficulty === "normal" ? 2 : 3);
    const { won, standScore } = runSubjectHand(seed, difficulty);
    if (won) wins += 1;
    if (standScore !== null) standScores.push(standScore);
  }
  const meanStand =
    standScores.length === 0
      ? 0
      : standScores.reduce((a, b) => a + b, 0) / standScores.length;
  return { wins, standScores, winPct: wins / SIM_HANDS, meanStand };
}

function chiSquareUniform(observed: number[], expected: number): { chi2: number; pass: boolean } {
  let chi2 = 0;
  for (const o of observed) {
    const diff = o - expected;
    chi2 += (diff * diff) / expected;
  }
  const df = observed.length - 1;
  const critical = df <= 40 ? 69 : df <= 79 ? 105 : 120;
  return { chi2, pass: chi2 <= critical };
}

describe("engineSim bot levels", () => {
  it(`differentiates easy/normal/hard over ${SIM_HANDS} seeded hands each`, () => {
    const stats = Object.fromEntries(
      BOT_DIFFICULTIES.map((d) => [d, simulateLevel(d)])
    ) as Record<BotDifficulty, LevelStats>;

    const easy = stats.easy;
    const normal = stats.normal;
    const hard = stats.hard;

    assert.ok(hard.winPct > normal.winPct + 0.02, `hard win ${hard.winPct} vs normal ${normal.winPct}`);
    assert.ok(normal.winPct > easy.winPct + 0.02, `normal win ${normal.winPct} vs easy ${easy.winPct}`);
    assert.ok(hard.meanStand > easy.meanStand + 0.08, `stand spread hard=${hard.meanStand} easy=${easy.meanStand}`);
    assert.ok(normal.meanStand > easy.meanStand + 0.08, `stand spread normal=${normal.meanStand} easy=${easy.meanStand}`);
    assert.ok(
      Math.abs(hard.meanStand - normal.meanStand) > 0.04 || Math.abs(hard.meanStand - easy.meanStand) > 0.5,
      `stand thresholds differ (hard=${hard.meanStand} normal=${normal.meanStand} easy=${easy.meanStand})`
    );

    (globalThis as { __engineSimStats?: Record<string, LevelStats> }).__engineSimStats = stats;
  });
});

describe("engineSim single-deck shuffle", () => {
  it("has correct composition (one of each card identity)", () => {
    process.env.SETIMIG_TEST_SHUFFLE_SEED = "149701";
    const deck = createSingleSpanishDeck();
    delete process.env.SETIMIG_TEST_SHUFFLE_SEED;
    assert.equal(deck.length, 40);
    const counts = countCardsByKey(deck);
    for (const [, n] of counts) {
      assert.equal(n, 1);
    }
    assert.equal(counts.size, 40);
  });

  it("draw simulation never exceeds one copy per card key", () => {
    process.env.SETIMIG_TEST_SHUFFLE_SEED = "149702";
    const deck = createSingleSpanishDeck();
    const drawn = deck.slice(0, 20);
    const counts = countCardsByKey(drawn);
    for (const [, n] of counts) {
      assert.ok(n <= 1);
    }
    delete process.env.SETIMIG_TEST_SHUFFLE_SEED;
  });

  it("passes chi-square uniformity on first-card frequency (fixed seeds)", () => {
    const single = createSingleSpanishDeck();
    const keys = single.map((c) => cardKey(c));
    const tallies = new Map<string, number>();
    for (const k of keys) tallies.set(k, 0);

    const runs = 400;
    for (let s = 0; s < runs; s += 1) {
      process.env.SETIMIG_TEST_SHUFFLE_SEED = String(SIM_SEED_BASE + s);
      const deck = fisherYatesShuffle(createSingleSpanishDeck());
      delete process.env.SETIMIG_TEST_SHUFFLE_SEED;
      const top = cardKey(deck[0]!);
      tallies.set(top, (tallies.get(top) ?? 0) + 1);
    }

    const expected = runs / keys.length;
    const observed = keys.map((k) => tallies.get(k) ?? 0);
    const { chi2, pass } = chiSquareUniform(observed, expected);
    assert.ok(pass, `chi-square ${chi2.toFixed(2)} expected ~${expected} per rank`);
    (globalThis as { __engineSimChi2?: number }).__engineSimChi2 = chi2;
  });
});

describe("engineSim jackpot and double (regles)", () => {
  const host = instantHost();

  it("pays royal jackpot from pot without debiting banker beyond 2:1 payout", () => {
    const room = emptyRoomBase("jp", "JP", 100, 800);
    room.pot = 800;
    const banker: Player = {
      id: "b",
      playerId: "b",
      seatToken: "tb",
      name: "Bank",
      chips: 10_000,
      bet: 0,
      isBanker: true,
      status: "stood",
      handSlots: [
        {
          id: "bs",
          bet: 0,
          cards: [
            { id: "b1", card: { suit: "hearts", value: 5, points: 5 }, faceUp: true },
            { id: "b2", card: { suit: "clubs", value: 2, points: 2 }, faceUp: true },
          ],
          doubled: false,
          canDouble: false,
          mort: false,
          blindPair: false,
          blindUntilBankEnd: false,
          mortOffered: false,
          status: "stood",
        },
      ],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    const player: Player = {
      id: "p",
      playerId: "p",
      seatToken: "tp",
      name: "P",
      chips: 5000,
      bet: 100,
      isBanker: false,
      status: "stood",
      handSlots: [
        {
          id: "ps",
          bet: 100,
          cards: [
            { id: "p1", card: { suit: "hearts", value: 7, points: 7 }, faceUp: true },
            { id: "p2", card: { suit: "diamonds", value: 10, points: 0.5 }, faceUp: true },
          ],
          doubled: false,
          canDouble: false,
          mort: false,
          blindPair: false,
          blindUntilBankEnd: false,
          mortOffered: false,
          status: "stood",
        },
      ],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    room.players = [banker, player];
    room.pot = 900;
    room.phase = "banker";
    const bankBefore = banker.chips;
    const potBefore = room.pot;
    settleGame(host, room);
    assert.ok(player.chips > 5000);
    assert.equal(room.jackpot, 0);
    assert.ok(room.pot < potBefore, "jackpot paid from pot");
    assert.equal(banker.chips, bankBefore - 200, "bank pays only 2:1, not jackpot");
  });

  it("allows double only with one visible card (first card)", () => {
    const hostNoTimers: GameHost = {
      emitRoomUpdate() {},
      schedule() {
        return null as unknown as ReturnType<typeof setTimeout>;
      },
      clearTimeout() {},
    };
    const room = emptyRoomBase("dbl", "D", 100, 0);
    room.houseRulesEnabled = true;
    room.phase = "playing";
    room.pot = 100;
    const player: Player = {
      id: "p",
      playerId: "p",
      seatToken: "t",
      name: "P",
      chips: 500,
      bet: 100,
      isBanker: false,
      status: "playing",
      handSlots: [
        {
          id: "s",
          bet: 100,
          cards: [{ id: "c1", card: { suit: "hearts", value: 5, points: 5 }, faceUp: true }],
          doubled: false,
          canDouble: true,
          mort: false,
          blindPair: false,
          blindUntilBankEnd: false,
          mortOffered: false,
          status: "playing",
        },
      ],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    room.players = [
      {
        id: "b",
        playerId: "b",
        seatToken: "tb",
        name: "B",
        chips: 5000,
        bet: 0,
        isBanker: true,
        status: "stood",
        handSlots: [],
        activeSlotIndex: 0,
        lastRoyal7Payout: 0,
        royal7AsBankerStreak: 0,
      },
      player,
    ];
    room.turnPlayerIndex = 0;
    room.deck = [{ suit: "clubs", value: 2, points: 2 }];
    assert.equal(applyDouble(hostNoTimers, room, player.id), null);
    assert.equal(player.handSlots[0]!.doubled, true);
    assert.equal(player.handSlots[0]!.cards.length, 2);
    // Normes de la casa (Edu, 28/10/2026): doblar NO planta; continua el torn.
    assert.equal(player.handSlots[0]!.status, "playing");
    assert.equal(room.phase, "playing");
    assert.equal(applyStand(hostNoTimers, room, player.id), null);
    assert.notEqual(room.phase, "playing");

    room.phase = "playing";
    room.turnPlayerIndex = 0;
    player.handSlots[0]!.cards.push({
      id: "c2",
      card: { suit: "spades", value: 3, points: 3 },
      faceUp: true,
    });
    player.handSlots[0]!.canDouble = true;
    player.handSlots[0]!.status = "playing";
    assert.equal(applyDouble(hostNoTimers, room, player.id), ENGINE_MESSAGES.alreadyDoubled);
  });

  it("rejects double in traditional mode (R10)", () => {
    const room = emptyRoomBase("dbl-trad", "D", 100, 0);
    room.phase = "playing";
    room.pot = 100;
    const player: Player = {
      id: "p",
      playerId: "p",
      seatToken: "t",
      name: "P",
      chips: 500,
      bet: 100,
      isBanker: false,
      status: "playing",
      handSlots: [
        {
          id: "s",
          bet: 100,
          cards: [{ id: "c1", card: { suit: "hearts", value: 5, points: 5 }, faceUp: true }],
          doubled: false,
          canDouble: true,
          mort: false,
          blindPair: false,
          blindUntilBankEnd: false,
          mortOffered: false,
          status: "playing",
        },
      ],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    room.players = [
      {
        id: "b",
        playerId: "b",
        seatToken: "tb",
        name: "B",
        chips: 5000,
        bet: 0,
        isBanker: true,
        status: "stood",
        handSlots: [],
        activeSlotIndex: 0,
        lastRoyal7Payout: 0,
        royal7AsBankerStreak: 0,
      },
      player,
    ];
    room.turnPlayerIndex = 0;
    assert.match(applyDouble(host, room, player.id) ?? "", /No es pot doblar/);
    assert.equal(player.handSlots[0]!.doubled, false);
  });
});

describe("engineSim R13 banker IA no hidden rival cards", () => {
  it("gatherSeenCards for banker excludes rival face-down cards", () => {
    const hidden: Card = { suit: "spades", value: 7, points: 7 };
    const seen = gatherSeenCards({
      centerDiscard: [],
      players: [
        {
          isBanker: false,
          handSlots: [
            {
              cards: [
                { card: { suit: "hearts", value: 2, points: 2 }, faceUp: true },
                { card: hidden, faceUp: false },
              ],
            },
          ],
        },
        {
          isBanker: true,
          handSlots: [{ cards: [{ card: { suit: "clubs", value: 4, points: 4 }, faceUp: true }] }],
        },
      ],
      selfId: "banker-id",
      selfSlots: [{ cards: [{ card: { suit: "clubs", value: 4, points: 4 }, faceUp: true }] }],
    });
    assert.ok(!seen.some((c) => c.value === hidden.value && c.suit === hidden.suit));
  });

  it("banker stand/hit unchanged when rival hidden card would change optimal play if seen", () => {
    const bankerHand = [{ suit: "hearts" as const, value: 6, points: 6 }];
    const visibleRival = [{ suit: "diamonds" as const, value: 5, points: 5 }];
    const hiddenHigh: Card = { suit: "spades", value: 7, points: 7 };
    const hiddenLow: Card = { suit: "clubs", value: 1, points: 1 };

    function bankerAction(hidden: Card): "hit" | "stand" {
      const seen = gatherSeenCards({
        centerDiscard: [],
        players: [
          {
            isBanker: false,
            handSlots: [
              {
                cards: [
                  { card: visibleRival[0]!, faceUp: true },
                  { card: hidden, faceUp: false },
                ],
              },
            ],
          },
        ],
        selfId: "b",
        selfSlots: [{ cards: [{ card: bankerHand[0]!, faceUp: true }] }],
      });
      const ctx: StrategyContext = {
        seen,
        hand: bankerHand,
        minBet: 100,
        chips: 5000,
        bet: 0,
        rivalVisibleMax: 5,
        bankerTargetScores: [5],
        isBanker: true,
        mortOffered: false,
        canDouble: false,
        canSplit: false,
        blindPair: false,
      };
      return decideHitOrStandHard(ctx);
    }

    assert.equal(bankerAction(hiddenHigh), bankerAction(hiddenLow));
  });
});
