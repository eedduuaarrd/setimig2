/**
 * Public, indexable legal documents.
 *
 * English is the default (also hreflang x-default):
 *   /privacy   /terms
 * Catalan and Spanish follow the same suffix as /regles/ca and /regles/es,
 * without a trailing slash, because these routes answer 200 either way:
 *   /privacy/ca   /privacy/es
 *   /terms/ca     /terms/es
 *
 * `express` serves the file before the SPA fallback (server/staticLegalDocs.ts).
 * The HTML is generated into public/ by scripts/render-legal-html.ts.
 */
export type LegalDocId = "privacy" | "terms";
export type LegalDocLang = "en" | "ca" | "es";

export type LegalDocPage = {
  id: LegalDocId;
  lang: LegalDocLang;
  path: string;
  /** Path under public/ and dist/. */
  file: string;
  title: string;
  description: string;
  h1: string;
};

export const LEGAL_DOC_PAGES: readonly LegalDocPage[] = [
  {
    id: "privacy",
    lang: "en",
    path: "/privacy",
    file: "privacy/index.html",
    title: "Privacy Policy · Seven Half Club",
    description:
      "Privacy policy of Seven Half Club. Adults 18+ only. Virtual chips have no cash value and cannot be bought, cashed out or exchanged for prizes.",
    h1: "Privacy Policy",
  },
  {
    id: "privacy",
    lang: "ca",
    path: "/privacy/ca",
    file: "privacy/ca/index.html",
    title: "Política de privadesa · Seven Half Club",
    description:
      "Política de privadesa de Seven Half Club. Només majors de 18 anys. Les fitxes virtuals no tenen valor i no es poden comprar, cobrar ni bescanviar per premis.",
    h1: "Política de privadesa",
  },
  {
    id: "privacy",
    lang: "es",
    path: "/privacy/es",
    file: "privacy/es/index.html",
    title: "Política de privacidad · Seven Half Club",
    description:
      "Política de privacidad de Seven Half Club. Solo mayores de 18 años. Las fichas virtuales no tienen valor y no se pueden comprar, cobrar ni canjear por premios.",
    h1: "Política de privacidad",
  },
  {
    id: "terms",
    lang: "en",
    path: "/terms",
    file: "terms/index.html",
    title: "Terms of Service · Seven Half Club",
    description:
      "Terms of Service of Seven Half Club. Adults 18+ only. Virtual chips have no cash value. Cosmetics give no gameplay advantage. Spanish law applies.",
    h1: "Terms of Service",
  },
  {
    id: "terms",
    lang: "ca",
    path: "/terms/ca",
    file: "terms/ca/index.html",
    title: "Condicions del servei · Seven Half Club",
    description:
      "Condicions del servei de Seven Half Club. Només majors de 18 anys. Les fitxes virtuals no tenen valor. Els cosmètics no donen avantatge de joc. Llei espanyola.",
    h1: "Condicions del servei",
  },
  {
    id: "terms",
    lang: "es",
    path: "/terms/es",
    file: "terms/es/index.html",
    title: "Condiciones del servicio · Seven Half Club",
    description:
      "Condiciones de Seven Half Club. Solo mayores de 18 años. Las fichas virtuales no tienen valor. Los cosméticos no dan ventaja de juego. Ley española.",
    h1: "Condiciones del servicio",
  },
];

const BY_PATH = new Map(LEGAL_DOC_PAGES.map((page) => [page.path, page]));

export function legalDocByPath(pathname: string): LegalDocPage | undefined {
  const path = pathname.length > 1 && pathname.endsWith("/") ? pathname.slice(0, -1) : pathname;
  return BY_PATH.get(path);
}

/** English for every locale other than Catalan and Spanish. */
export function legalDocHref(id: LegalDocId, locale: string): string {
  const lang: LegalDocLang = locale === "ca" || locale === "es" ? locale : "en";
  return LEGAL_DOC_PAGES.find((page) => page.id === id && page.lang === lang)?.path ?? `/${id}`;
}
