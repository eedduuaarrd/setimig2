import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  applyBankOfferDecision,
  botAcceptsBankOffer,
  buildPendingBankChoice,
  isSetIMigScore,
  pickBankOfferWinner,
  playerHasSetIMigHand,
} from "./bankRules.ts";
import { scoreCards } from "./scoring.ts";
import {
  applyPlaceBet,
  applyPlayingTurnTimeoutDefault,
  applySplit,
  applyHit,
  applyMort,
  applyStand,
  canRevealCardsToRivals,
  nextCardFaceUp,
  beginGameStart,
  beginBettingPhase,
  clearRoomTimers,
  computeSettlementDelayMs,
  MORT_REVEAL_SUSPENSE_MS,
  MORT_SETTLEMENT_VISIBLE_MS,
  REVEAL_PER_SEAT_MS,
  SETTLEMENT_VISIBLE_MS,
  settlementRevealSeatCount,
  settlementRevealWindowMs,
  emptyRoomBase,
  ensurePhaseBMatchInitialized,
  privateTableChips,
  maybeFinishSettlementEarly,
  publishRoom,
  roomToView,
  runBotAction,
  scheduleAfterRoomChange,
  type GameHost,
  type HandSlot,
  type Player,
  type Room,
} from "./gameEngine.ts";
import type { Card } from "../src/gameTypes.ts";
import { createManualClockHost } from "./testing/manualClockHost.ts";
import { BANK_OFFER_FLOOR_MS, payoutChipsMs } from "./pacing.ts";

/** Revelació del #339 més el pagament (seients amb resultat = n − 1, la banca no compta). */
function settleWithPayout(revealMs: number, revealSeats: number, humanOffer = false): number {
  const decision = humanOffer ? Math.max(revealMs, BANK_OFFER_FLOOR_MS) : revealMs;
  return decision + payoutChipsMs(Math.max(0, revealSeats - 1));
}
import { setBotRngForTests } from "./ai/botProfile.ts";
import { resetTestDeckSeedWarningsForTests } from "./shuffle.ts";

function stoodSlot(id: string, cardId: string, mort = false): HandSlot {
  return {
    id,
    cards: [{ id: cardId, card: { suit: "hearts", value: mort ? 7 : 5, points: mort ? 7 : 5 }, faceUp: mort }],
    bet: 0,
    doubled: false,
    canDouble: false,
    mort,
    blindPair: false,
    blindUntilBankEnd: false,
    mortOffered: false,
    status: "stood",
  };
}

function revealSeat(id: string, extra: Partial<Player> = {}, slots: HandSlot[] = [stoodSlot(id, `${id}-c`)]): Player {
  return {
    id,
    playerId: id,
    seatToken: id,
    name: id,
    chips: extra.isBanker ? 50_000 : 2_000,
    bet: 0,
    isBanker: false,
    isBot: false,
    status: "stood",
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
    ...extra,
    handSlots: extra.handSlots ?? slots,
  };
}

/** n seients amb cartes (el primer és la banca). `splitHands` afegeix mans al segon seient, sense sumar n. */
function roomWithRevealSeats(
  n: number,
  opts: { mort?: boolean; soloAi?: boolean; splitHands?: number; emptySeats?: number; humanBankOffer?: boolean } = {}
): Room {
  const room = emptyRoomBase(`reveal-${n}`, "Revelació", 100, 1000);
  room.soloAi = !!opts.soloAi;
  const players: Player[] = [];
  for (let i = 0; i < n; i += 1) {
    const id = i === 0 ? "bank" : `p${i}`;
    const split = i === 1 ? Math.max(1, opts.splitHands ?? 1) : 1;
    const slots = Array.from({ length: split }, (_, hand) =>
      stoodSlot(`${id}-${hand}`, `${id}-${hand}-c`, !!opts.mort && i === 1 && hand === 0)
    );
    players.push(
      revealSeat(id, {
        isBanker: i === 0,
        isBot: i === 0,
        pendingBankChoice: opts.humanBankOffer && i === 1 ? { mandatory: false } : undefined,
      }, slots)
    );
  }
  for (let i = 0; i < (opts.emptySeats ?? 0); i += 1) {
    players.push(revealSeat(`empty-${i}`, { status: "waiting", isBot: true }, []));
  }
  room.players = players;
  return room;
}

describe("settlement delay", () => {
  it("does not extend settlement for bot-only bank offers", () => {
    delete process.env.SETIMIG_TEST_FAST;
    const room = emptyRoomBase("r1", "Test", 100, 1000);
    room.soloAi = true;
    room.players = [
      {
        id: "h",
        playerId: "h",
        seatToken: "h",
        name: "Human",
        chips: 1000,
        bet: 0,
        isBanker: false,
        isBot: false,
        status: "stood",
        handSlots: [stoodSlot("h0", "hc")],
        activeSlotIndex: 0,
        lastRoyal7Payout: 0,
        royal7AsBankerStreak: 0,
        pendingBankChoice: { mandatory: false },
      },
      {
        id: "b",
        playerId: "b",
        seatToken: "b",
        name: "Bot",
        chips: 1000,
        bet: 0,
        isBanker: true,
        isBot: true,
        status: "stood",
        handSlots: [stoodSlot("b0", "bc")],
        activeSlotIndex: 0,
        lastRoyal7Payout: 0,
        royal7AsBankerStreak: 0,
      },
    ];
    assert.equal(settlementRevealSeatCount(room), 2);
    assert.equal(computeSettlementDelayMs(room), settleWithPayout(6_000, 2, true));
    room.players[0]!.pendingBankChoice = undefined;
    room.players[1]!.pendingBankChoice = { mandatory: false };
    assert.equal(computeSettlementDelayMs(room), settleWithPayout(6_000, 2));
    room.players[1]!.pendingBankChoice = undefined;
  });

  it("maybeFinishSettlementEarly advances when bank choices are cleared", () => {
    process.env.SETIMIG_TEST_FAST = "1";
    const timers: ReturnType<typeof setTimeout>[] = [];
    const host: GameHost = {
      emitRoomUpdate: () => {},
      schedule: (fn, ms) => {
        const t = setTimeout(fn, ms);
        timers.push(t);
        return t;
      },
      clearTimeout: (t) => clearTimeout(t),
    };
    const room = emptyRoomBase("r2", "Test", 100, 1000);
    room.phase = "settlement";
    room.soloAi = true;
    room.settlementStartedAt = Date.now() - 500;
    room.players = [
      {
        id: "b",
        playerId: "b",
        seatToken: "b",
        name: "Bot",
        chips: 1000,
        bet: 0,
        isBanker: false,
        isBot: true,
        status: "stood",
        handSlots: [],
        activeSlotIndex: 0,
        lastRoyal7Payout: 0,
        royal7AsBankerStreak: 0,
      },
    ];
    maybeFinishSettlementEarly(host, room);
    assert.ok(room.settlementEndTimer);
    delete process.env.SETIMIG_TEST_FAST;
    for (const t of timers) clearTimeout(t);
  });
});

describe("retard de liquidació segons els seients revelats", () => {
  function withoutFastPacing(run: () => void): void {
    const prev = process.env.SETIMIG_TEST_FAST;
    delete process.env.SETIMIG_TEST_FAST;
    try {
      run();
    } finally {
      if (prev === undefined) delete process.env.SETIMIG_TEST_FAST;
      else process.env.SETIMIG_TEST_FAST = prev;
    }
  }

  it("les constants són 1,5 s per seient, 3 s de full i 5,2 s de suspens del Mort", () => {
    assert.equal(REVEAL_PER_SEAT_MS, 1_500);
    assert.equal(SETTLEMENT_VISIBLE_MS, 3_000);
    assert.equal(MORT_REVEAL_SUSPENSE_MS, 5_200);
    assert.equal(MORT_SETTLEMENT_VISIBLE_MS, SETTLEMENT_VISIBLE_MS);
  });

  it("sense Mort: n=2 → 6000, n=4 → 9000, n=5 → 10500", () => {
    withoutFastPacing(() => {
      assert.equal(settlementRevealWindowMs(2, false), 6_000);
      assert.equal(settlementRevealWindowMs(4, false), 9_000);
      assert.equal(settlementRevealWindowMs(5, false), 10_500);
      for (const soloAi of [true, false]) {
        assert.equal(computeSettlementDelayMs(roomWithRevealSeats(2, { soloAi })), settleWithPayout(6_000, 2));
        assert.equal(computeSettlementDelayMs(roomWithRevealSeats(4, { soloAi })), settleWithPayout(9_000, 4));
        assert.equal(computeSettlementDelayMs(roomWithRevealSeats(5, { soloAi })), settleWithPayout(10_500, 5));
      }
    });
  });

  it("amb Mort acceptat: n=2 → 9700, n=4 → 12700, n=5 → 14200", () => {
    withoutFastPacing(() => {
      assert.equal(settlementRevealWindowMs(2, true), 9_700);
      assert.equal(settlementRevealWindowMs(4, true), 12_700);
      assert.equal(settlementRevealWindowMs(5, true), 14_200);
      for (const soloAi of [true, false]) {
        assert.equal(computeSettlementDelayMs(roomWithRevealSeats(2, { soloAi, mort: true })), settleWithPayout(9_700, 2));
        assert.equal(computeSettlementDelayMs(roomWithRevealSeats(4, { soloAi, mort: true })), settleWithPayout(12_700, 4));
        assert.equal(computeSettlementDelayMs(roomWithRevealSeats(5, { soloAi, mort: true })), settleWithPayout(14_200, 5));
      }
    });
  });

  it("un split de diverses mans al mateix seient no suma n", () => {
    withoutFastPacing(() => {
      const room = roomWithRevealSeats(2, { splitHands: 3 });
      const splitter = room.players.find((p) => p.id === "p1")!;
      assert.equal(splitter.handSlots.length, 3);
      assert.equal(settlementRevealSeatCount(room), 2);
      assert.equal(computeSettlementDelayMs(room), settleWithPayout(6_000, 2));
    });
  });

  it("un seient sense cartes no es revela i no suma", () => {
    withoutFastPacing(() => {
      const room = roomWithRevealSeats(2, { emptySeats: 2 });
      assert.equal(room.players.length, 4);
      assert.equal(settlementRevealSeatCount(room), 2);
      assert.equal(computeSettlementDelayMs(room), settleWithPayout(6_000, 2));
    });
  });

  it("l'oferta de banca pren el màxim amb 6400 i després hi suma el pagament", () => {
    withoutFastPacing(() => {
      assert.equal(computeSettlementDelayMs(roomWithRevealSeats(2, { humanBankOffer: true })), settleWithPayout(6_000, 2, true));
      assert.equal(computeSettlementDelayMs(roomWithRevealSeats(4, { humanBankOffer: true })), settleWithPayout(9_000, 4, true));
      assert.equal(
        computeSettlementDelayMs(roomWithRevealSeats(2, { mort: true, humanBankOffer: true })),
        settleWithPayout(9_700, 2, true)
      );
    });
  });

  it("SETIMIG_TEST_FAST col·lapsa el retard encara que n i el Mort l'allarguin", () => {
    const prev = process.env.SETIMIG_TEST_FAST;
    process.env.SETIMIG_TEST_FAST = "1";
    try {
      const room = roomWithRevealSeats(5, { mort: true, soloAi: true });
      const delay = computeSettlementDelayMs(room);
      assert.ok(delay < 500);
      assert.ok(delay < settlementRevealWindowMs(5, true));
    } finally {
      if (prev === undefined) delete process.env.SETIMIG_TEST_FAST;
      else process.env.SETIMIG_TEST_FAST = prev;
    }
  });
});

function seatForMortDelay(id: string, extra: Partial<Player> = {}): Player {
  return {
    id,
    playerId: id,
    seatToken: id,
    name: id,
    chips: extra.isBanker ? 50_000 : 2_000,
    bet: 0,
    isBanker: false,
    isBot: false,
    status: "waiting",
    handSlots: [],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
    ...extra,
  };
}

/** Juga una mà amb la baralla de prova fins a la liquidació. La banca és humana per controlar el torn. */
function playTestDeckToSettlement(opts: {
  seed: string;
  soloAi: boolean;
  acceptMort: boolean;
  bankerHits?: number;
}): Room {
  const clock = createManualClockHost();
  const room = emptyRoomBase(`mort-delay-${opts.seed}-${opts.soloAi}-${opts.acceptMort}`, "Mort", 100, 0);
  room.houseRulesEnabled = true;
  room.soloAi = opts.soloAi;
  const banker = seatForMortDelay("bank", { isBanker: true });
  const human = seatForMortDelay("human");
  room.players = [banker, human];
  beginBettingPhase(clock.host, room);
  assert.equal(applyPlaceBet(room, human, 100), null);
  assert.equal(room.phase, "playing");
  const slot = human.handSlots[0]!;
  assert.equal(slot.cards[0]?.card.value, 7, `llavor ${opts.seed}: la primera carta ha de ser el Mort`);
  assert.equal(slot.mortOffered, true);
  assert.equal(applyMort(clock.host, room, human.id, opts.acceptMort), null);
  if (opts.acceptMort) {
    assert.equal(slot.mort, true);
    assert.equal(slot.cards[0]?.faceUp, true, "acceptar el Mort destapa el 7");
  } else {
    assert.equal(slot.mort, false);
    assert.equal(slot.cards[0]?.faceUp, false);
    assert.equal(applyStand(clock.host, room, human.id), null);
    pumpActionHolds(clock, room);
  }
  assert.equal(room.phase, "banker");
  for (let i = 0; i < (opts.bankerHits ?? 0); i += 1) {
    assert.equal(applyHit(clock.host, room, banker.id), null);
    pumpActionHolds(clock, room);
    assert.equal(room.phase, "banker", "la banca encara no s'ha passat");
  }
  assert.equal(applyStand(clock.host, room, banker.id), null);
  pumpActionHolds(clock, room);
  assert.equal(room.phase, "settlement");
  return room;
}

/** El rellotge virtual dispara les pauses HIT/STAND sense esperar de debò. */
function pumpActionHolds(clock: ReturnType<typeof createManualClockHost>, room: Room): void {
  for (let i = 0; i < 8 && room.actionHoldEndsAt; i += 1) clock.advance(3_000);
}

function withTestDeckSeed(seed: string, run: () => void): void {
  const prev = {
    seed: process.env.SETIMIG_TEST_DECK_SEED,
    shuffle: process.env.SETIMIG_TEST_SHUFFLE_SEED,
    host: process.env.SETIMIG_HOST,
    env: process.env.NODE_ENV,
    fast: process.env.SETIMIG_TEST_FAST,
  };
  process.env.SETIMIG_TEST_DECK_SEED = seed;
  delete process.env.SETIMIG_TEST_SHUFFLE_SEED;
  process.env.SETIMIG_HOST = "127.0.0.1";
  delete process.env.NODE_ENV;
  delete process.env.SETIMIG_TEST_FAST;
  resetTestDeckSeedWarningsForTests();
  try {
    run();
  } finally {
    if (prev.seed === undefined) delete process.env.SETIMIG_TEST_DECK_SEED;
    else process.env.SETIMIG_TEST_DECK_SEED = prev.seed;
    if (prev.shuffle === undefined) delete process.env.SETIMIG_TEST_SHUFFLE_SEED;
    else process.env.SETIMIG_TEST_SHUFFLE_SEED = prev.shuffle;
    if (prev.host === undefined) delete process.env.SETIMIG_HOST;
    else process.env.SETIMIG_HOST = prev.host;
    if (prev.env === undefined) delete process.env.NODE_ENV;
    else process.env.NODE_ENV = prev.env;
    if (prev.fast === undefined) delete process.env.SETIMIG_TEST_FAST;
    else process.env.SETIMIG_TEST_FAST = prev.fast;
    resetTestDeckSeedWarningsForTests();
  }
}

describe("retard de liquidació amb Mort revelat", () => {
  for (const soloAi of [true, false]) {
    const mode = soloAi ? "solitari" : "multijugador";

    it(`${mode}: amb el Mort acceptat (llavor 4) dos seients duren 9700 ms`, () => {
      withTestDeckSeed("4", () => {
        const room = playTestDeckToSettlement({ seed: "4", soloAi, acceptMort: true });
        const slot = room.players.find((p) => p.id === "human")!.handSlots[0]!;
        assert.equal(slot.mort, true);
        assert.equal(slot.cards[0]?.faceUp, true);
        assert.equal(settlementRevealSeatCount(room), 2);
        const withMort = computeSettlementDelayMs(room);
        slot.mort = false;
        const withoutMort = computeSettlementDelayMs(room);
        slot.mort = true;
        // La mà pot portar oferta de banca (Mort guanyador): 6,4 s, per sota de 9,7 s.
        const offer = room.players.some((p) => p.pendingBankChoice && !p.isBot);
        assert.equal(withoutMort, settleWithPayout(6_000, 2, offer));
        assert.equal(withMort, settleWithPayout(9_700, 2));
        assert.ok(withMort >= withoutMort);
      });
    });

    it(`${mode}: rebutjar el Mort no allarga la liquidació`, () => {
      withTestDeckSeed("4", () => {
        const room = playTestDeckToSettlement({ seed: "4", soloAi, acceptMort: false });
        const slot = room.players.find((p) => p.id === "human")!.handSlots[0]!;
        assert.equal(slot.mort, false);
        assert.equal(settlementRevealSeatCount(room), 2);
        assert.equal(computeSettlementDelayMs(room), settleWithPayout(6_000, 2));
      });
    });
  }

  it("llavor 217: Mort contra una banca a 7½, en solitari i en multijugador", () => {
    for (const soloAi of [true, false]) {
      withTestDeckSeed("217", () => {
        const room = playTestDeckToSettlement({ seed: "217", soloAi, acceptMort: true, bankerHits: 1 });
        const banker = room.players.find((p) => p.isBanker)!;
        const human = room.players.find((p) => p.id === "human")!;
        assert.equal(scoreCards(banker.handSlots[0]!.cards), 7.5);
        assert.equal(human.handSlots[0]!.mort, true);
        assert.equal(scoreCards(human.handSlots[0]!.cards), 7.5);
        assert.equal(settlementRevealSeatCount(room), 2);
        const withMort = computeSettlementDelayMs(room);
        human.handSlots[0]!.mort = false;
        const withoutMort = computeSettlementDelayMs(room);
        assert.equal(withoutMort, settleWithPayout(6_000, 2));
        assert.equal(withMort, settleWithPayout(9_700, 2));
      });
    }
  });

  it("amb una oferta de banca pendent, el Mort pren el màxim i no escurça", () => {
    for (const soloAi of [true, false]) {
      withTestDeckSeed("4", () => {
        const room = playTestDeckToSettlement({ seed: "4", soloAi, acceptMort: true });
        const human = room.players.find((p) => p.id === "human")!;
        human.pendingBankChoice = { mandatory: false };
        assert.equal(settlementRevealSeatCount(room), 2);
        const withMort = computeSettlementDelayMs(room);
        human.handSlots[0]!.mort = false;
        const onlyBankOffer = computeSettlementDelayMs(room);
        assert.equal(onlyBankOffer, settleWithPayout(6_000, 2, true));
        assert.equal(withMort, settleWithPayout(9_700, 2));
        assert.ok(withMort >= onlyBankOffer);
      });
    }
  });
});

describe("shared scoring", () => {
  it("sums card points like server scoring module", () => {
    const cards: { card: Card }[] = [
      { card: { suit: "hearts", value: 7, points: 7 } },
      { card: { suit: "clubs", value: 10, points: 0.5 } },
    ];
    assert.equal(scoreCards(cards), 7.5);
  });

  it("el total segueix el rang de l'índex, no un points que no hi quadra", () => {
    // 2 d'espases + un 7 amb points d'as: l'índex diu 7, el total ha de ser 9 (no 8 ni 3).
    assert.equal(
      scoreCards([
        { card: { suit: "spades", value: 2, points: 2 } },
        { card: { suit: "spades", value: 7, points: 1 } },
      ]),
      9
    );
    // Banca: 5 copes, 1 copes, rei, 2 oros, sota. Amb points inflats encara és 9, no 12.
    assert.equal(
      scoreCards([
        { card: { suit: "hearts", value: 5, points: 5 } },
        { card: { suit: "hearts", value: 1, points: 1 } },
        { card: { suit: "hearts", value: 12, points: 12 } },
        { card: { suit: "diamonds", value: 2, points: 2 } },
        { card: { suit: "diamonds", value: 10, points: 10 } },
      ]),
      9
    );
  });
});

describe("shared bankRules parity", () => {
  it("detects set i mig (7½) scores", () => {
    assert.equal(isSetIMigScore(7.5, "stood"), true);
    assert.equal(isSetIMigScore(7.5, "playing"), true);
    assert.equal(isSetIMigScore(7.5, "busted"), false);
    assert.equal(isSetIMigScore(7, "stood"), false);
  });

  it("picks first non-banker in turn order with set i mig", () => {
    const players = [
      { id: "a", refusedBankBefore: false },
      { id: "b", refusedBankBefore: false },
    ];
    const winner = pickBankOfferWinner(players, (p) => p.id === "b");
    assert.equal(winner?.id, "b");
  });

  it("applyBankOfferDecision toggles banker", () => {
    const players = [
      { id: "a", isBanker: true, refusedBankBefore: false },
      { id: "b", isBanker: false, refusedBankBefore: false },
    ];
    applyBankOfferDecision(players, "b", true, false);
    assert.equal(players[0].isBanker, false);
    assert.equal(players[1].isBanker, true);
  });

  it("botAcceptsBankOffer requires min bet chips and cover", () => {
    assert.equal(botAcceptsBankOffer(200, 100, 1), true);
    assert.equal(botAcceptsBankOffer(50, 100, 1), false);
    assert.equal(botAcceptsBankOffer(399, 100, 2), false);
    assert.equal(botAcceptsBankOffer(400, 100, 2), true);
  });

  it("buildPendingBankChoice marks mandatory after refuse", () => {
    assert.deepEqual(buildPendingBankChoice({ id: "x" }), { mandatory: false });
    assert.deepEqual(buildPendingBankChoice({ id: "x", refusedBankBefore: true }), { mandatory: true });
  });

  it("playerHasSetIMigHand ignores zero bets", () => {
    assert.equal(
      playerHasSetIMigHand([
        { bet: 0, score: 7.5, status: "stood" },
        { bet: 100, score: 7.5, status: "stood" },
      ]),
      true
    );
  });
});

describe("shared gameEngine betting", () => {
  // Rellotge virtual: cap temporitzador real que continuï jugant en segon pla després del test.
  const noopHost: GameHost = createManualClockHost().host;

  function makeRoom(): Room {
    return emptyRoomBase("test-room", "Test", 100, 1000);
  }

  function addHuman(room: Room, chips: number): Player {
    const p: Player = {
      id: "human-1",
      playerId: "pid-1",
      seatToken: "seat-1",
      name: "Human",
      chips,
      bet: 0,
      isBanker: false,
      status: "waiting",
      handSlots: [],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    room.players.push(p);
    return p;
  }

  it("betting deadline is not extended on publishRoom republish", async () => {
    process.env.SETIMIG_TEST_FAST = "1";
    const host: GameHost = createManualClockHost().host;
    const room = makeRoom();
    const banker: Player = {
      id: "banker",
      playerId: "bank",
      seatToken: "seat-b",
      name: "Bank",
      chips: 10_000,
      bet: 0,
      isBanker: true,
      status: "waiting",
      handSlots: [],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    const human = addHuman(room, 500);
    room.players.push(banker, human);
    beginBettingPhase(host, room);
    const firstDeadline = room.bettingDeadlineAt;
    assert.ok(firstDeadline && firstDeadline > Date.now());
    await publishRoom(host, room);
    assert.equal(room.bettingDeadlineAt, firstDeadline);
    assert.equal(room.turnDeadlineAt, firstDeadline);
    delete process.env.SETIMIG_TEST_FAST;
  });

  it("applies configured private-table minimum and maximum inclusively", () => {
    for (const [requested, expected] of [[200, 200], [550, 550], [999, 550]] as const) {
      const room = makeRoom();
      room.phase = "betting";
      room.minBet = 200;
      room.tableMaxBet = 550;
      const human = addHuman(room, 5_000);
      human.status = "betting";
      room.players.push({
        id: "banker",
        playerId: "bank",
        seatToken: "seat-b",
        name: "Bank",
        chips: 50_000,
        bet: 0,
        isBanker: true,
        status: "betting",
        handSlots: [],
        activeSlotIndex: 0,
        lastRoyal7Payout: 0,
        royal7AsBankerStreak: 0,
      });
      assert.equal(applyPlaceBet(room, human, requested), null);
      assert.equal(human.bet, expected);
    }
  });

  it("funds a private table banker to cover every configured maximum wager", () => {
    const room = makeRoom();
    room.isPrivate = true;
    room.tableMaxBet = 500;
    const human = addHuman(room, 500);
    const banker: Player = {
      id: "banker",
      playerId: "bank",
      seatToken: "seat-b",
      name: "Bank",
      chips: 500,
      bet: 0,
      isBanker: true,
      status: "waiting",
      handSlots: [],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    room.players.push(banker);
    assert.equal(privateTableChips(room), 6_000);
    ensurePhaseBMatchInitialized(room);
    assert.equal(human.chips, 6_000);
    assert.equal(banker.chips, 6_000);
    assert.equal(room.phaseB?.startingChips, 6_000);
    assert.equal(room.phaseB?.chipPool, 12_000);
  });

  it("applyPlaceBet clamps below minimum to minBet", () => {
    const room = makeRoom();
    room.phase = "betting";
    const human = addHuman(room, 500);
    human.status = "betting";
    room.players.push({
      id: "banker",
      playerId: "bank",
      seatToken: "seat-b",
      name: "Bank",
      chips: 10_000,
      bet: 0,
      isBanker: true,
      status: "betting",
      handSlots: [],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    });
    const err = applyPlaceBet(room, human, 50);
    assert.equal(err, null);
    assert.equal(human.bet, 100);
    void noopHost;
  });
});

describe("shared gameEngine R12 banker upcard", () => {
  it("deals banker first card face-down until the bank turn (no bot can count it)", () => {
    const room = emptyRoomBase("r12", "R12", 100, 0);
    room.deck = [
      { suit: "hearts", value: 5, points: 5 },
      { suit: "clubs", value: 3, points: 3 },
    ];
    room.phase = "betting";
    const banker: Player = {
      id: "bank",
      playerId: "bank",
      seatToken: "s",
      name: "Bank",
      chips: 5_000,
      bet: 0,
      isBanker: true,
      status: "betting",
      handSlots: [],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    const player: Player = {
      id: "p1",
      playerId: "p1",
      seatToken: "s1",
      name: "P",
      chips: 2_000,
      bet: 0,
      isBanker: false,
      status: "betting",
      handSlots: [],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    room.players.push(banker, player);
    applyPlaceBet(room, player, 100);
    const bslot = banker.handSlots[0];
    assert.ok(bslot);
    assert.equal(bslot.cards.length, 1);
    assert.equal(bslot.cards[0]!.faceUp, false);
  });
});

describe("shared gameEngine banker hand redaction", () => {
  const host: GameHost = createManualClockHost().host;

  it("hides banker cards from all viewers until bank turn", () => {
    const room = emptyRoomBase("redact", "Redact", 100, 0);
    room.phase = "playing";
    const card = { suit: "hearts" as const, value: 5, points: 5 };
    const banker: Player = {
      id: "bank",
      playerId: "bank",
      seatToken: "s",
      name: "Bank",
      chips: 5_000,
      bet: 0,
      isBanker: true,
      status: "stood",
      handSlots: [
        {
          id: "bs",
          bet: 0,
          cards: [{ id: "c1", card, faceUp: true }],
          doubled: false,
          canDouble: false,
          mort: false,
          blindPair: false,
          blindUntilBankEnd: false,
          mortOffered: false,
          status: "stood",
        },
      ],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    const human: Player = {
      id: "p1",
      playerId: "p1",
      seatToken: "s1",
      name: "P",
      chips: 2_000,
      bet: 100,
      isBanker: false,
      status: "playing",
      handSlots: [],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    room.players = [banker, human];

    const rivalView = roomToView(room, human.id, host).players.find((p) => p.isBanker)!;
    assert.equal(rivalView.handSlots[0]!.cards[0]!.card, null);
    assert.equal(rivalView.handSlots[0]!.cards[0]!.faceUp, false);

    const bankerView = roomToView(room, banker.id, host).players.find((p) => p.isBanker)!;
    assert.equal(bankerView.handSlots[0]!.cards[0]!.card, null);

    room.phase = "banker";
    const afterBank = roomToView(room, human.id, host).players.find((p) => p.isBanker)!;
    assert.deepEqual(afterBank.handSlots[0]!.cards[0]!.card, card);
    assert.equal(afterBank.handSlots[0]!.cards[0]!.faceUp, true);
  });
});

describe("shared gameEngine split and turn timeout", () => {
  function figureCard(suit: Card["suit"] = "hearts"): Card {
    return { suit, value: 10, points: 0.5 };
  }

  function playingBotRoom(): { room: Room; bot: Player } {
    const room = emptyRoomBase("split-room", "Split", 100, 0);
    room.houseRulesEnabled = true;
    room.phase = "playing";
    room.deck = [2, 2, 3, 3, 4, 4].map((value, i) => ({
      suit: (["hearts", "diamonds", "clubs", "spades"] as const)[i % 4]!,
      value,
      points: value,
    }));
    const banker: Player = {
      id: "banker",
      playerId: "bank",
      seatToken: "b",
      name: "Bank",
      chips: 5000,
      bet: 0,
      isBanker: true,
      status: "stood",
      handSlots: [],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    const bot: Player = {
      id: "bot-1",
      playerId: "bot-1",
      seatToken: "bot",
      name: "Bot",
      chips: 500,
      bet: 100,
      isBanker: false,
      isBot: true,
      status: "playing",
      handSlots: [],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    const slot: HandSlot = {
      id: "s0",
      bet: 100,
      cards: [
        { id: "c1", card: figureCard("hearts"), faceUp: true },
        { id: "c2", card: figureCard("spades"), faceUp: true },
      ],
      doubled: false,
      canDouble: false,
      mort: false,
      blindPair: false,
      blindUntilBankEnd: false,
      mortOffered: false,
      status: "playing",
    };
    bot.handSlots = [slot];
    room.players = [banker, bot];
    room.turnPlayerIndex = 0;
    return { room, bot };
  }

  it("applySplit splits the active hand slot", () => {
    const { room, bot } = playingBotRoom();
    const host: GameHost = createManualClockHost().host;
    assert.equal(applySplit(room, bot.id), null);
    assert.equal(bot.handSlots.length, 2);
    runBotAction(host, room, bot);
    assert.equal(bot.handSlots.length, 2);
  });

  it("re-splits the active pair past 3 hands and charges the new stake", () => {
    const { room, bot } = playingBotRoom();
    // pop: figura (la mà activa torna a ser parella), 2, 4, 3.
    room.deck = [
      { suit: "spades", value: 3, points: 3 },
      { suit: "hearts", value: 4, points: 4 },
      { suit: "diamonds", value: 2, points: 2 },
      figureCard("clubs"),
    ];
    assert.equal(applySplit(room, bot.id), null);
    assert.equal(bot.handSlots[0]!.cards.length, 2);
    const chipsAfterFirst = bot.chips;

    assert.equal(applySplit(room, bot.id), null);
    assert.equal(bot.handSlots.length, 3);
    assert.equal(bot.chips, chipsAfterFirst - 100);
    assert.equal(bot.activeSlotIndex, 0);
    assert.equal(bot.handSlots[0]!.cards.length, 2);
    assert.equal(bot.handSlots[1]!.cards.length, 2);
    assert.equal(bot.handSlots[1]!.cards[0]!.card.value, 10);

    bot.handSlots[0]!.cards = [
      { id: "cA", card: figureCard("hearts"), faceUp: true },
      { id: "cB", card: figureCard("diamonds"), faceUp: true },
    ];
    room.deck = [
      { suit: "spades", value: 6, points: 6 },
      { suit: "hearts", value: 5, points: 5 },
    ];
    const chipsBefore = bot.chips;
    assert.equal(applySplit(room, bot.id), null);
    assert.equal(bot.handSlots.length, 4);
    assert.equal(bot.chips, chipsBefore - 100);
    assert.equal(bot.handSlots.every((h) => h.canDouble === false), true);
  });

  it("advertises a re-split with two hands and hides it at three", () => {
    const { room, bot } = playingBotRoom();
    room.deck = [
      { suit: "spades", value: 3, points: 3 },
      { suit: "hearts", value: 4, points: 4 },
      { suit: "diamonds", value: 2, points: 2 },
      figureCard("diamonds"),
    ];
    assert.equal(applySplit(room, bot.id), null);
    const host: GameHost = createManualClockHost().host;

    const two = roomToView(room, bot.id, host).players.find((player) => player.id === bot.id);
    assert.equal(two?.pendingChoices?.canSplit, true);

    assert.equal(applySplit(room, bot.id), null);
    const three = roomToView(room, bot.id, host).players.find((player) => player.id === bot.id);
    assert.notEqual(three?.pendingChoices?.canSplit, true);
  });

  it("runBotAction performs split without stalling", () => {
    const { room, bot } = playingBotRoom();
    const host: GameHost = createManualClockHost().host;
    // La decisió de separar depèn del perfil i del RNG dels bots: RNG fix perquè sempre separi.
    setBotRngForTests(() => 0);
    try {
      runBotAction(host, room, bot);
    } finally {
      setBotRngForTests(null);
    }
    assert.equal(bot.handSlots.length, 2);
  });

  it("applyPlayingTurnTimeoutDefault rejects mort (No)", () => {
    const { room, bot } = playingBotRoom();
    bot.handSlots[0]!.cards = [{ id: "c1", card: { suit: "hearts", value: 7, points: 7 }, faceUp: true }];
    bot.handSlots[0]!.mortOffered = true;
    room.turnPlayerIndex = 0;
    const host: GameHost = createManualClockHost().host;
    applyPlayingTurnTimeoutDefault(host, room, bot.id);
    assert.equal(bot.handSlots[0]!.mortOffered, false);
    assert.equal(bot.handSlots[0]!.mort, false);
    assert.equal(bot.handSlots[0]!.canDouble, true);
  });

  it("mort decision uses one turn timeout and exposes mortDeadline", async () => {
    process.env.SETIMIG_TEST_FAST = "1";
    const { humanTurnTimeoutMs } = await import("../server/bots.ts");
    const turnMs = humanTurnTimeoutMs();
    const scheduled: number[] = [];
    const room = emptyRoomBase("mort-deadline", "Mort", 100, 0);
    room.houseRulesEnabled = true;
    room.phase = "playing";
    room.deck = [];
    room.pot = 200;
    // Rellotge virtual (abans: setTimeout real limitat a 80 ms i espera real de 200 ms).
    const clock = createManualClockHost({ capMs: 80, onSchedule: (ms) => scheduled.push(ms) });
    const host = clock.host;
    const banker: Player = {
      id: "banker",
      playerId: "bank",
      seatToken: "b",
      name: "Bank",
      chips: 5000,
      bet: 0,
      isBanker: true,
      status: "stood",
      handSlots: [
        {
          id: "bs",
          bet: 0,
          cards: [],
          doubled: false,
          canDouble: false,
          mort: false,
          blindPair: false,
          blindUntilBankEnd: false,
          mortOffered: false,
          status: "stood",
        },
      ],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    const human: Player = {
      id: "human-1",
      playerId: "h1",
      seatToken: "h",
      name: "Human",
      chips: 400,
      bet: 100,
      isBanker: false,
      status: "playing",
      handSlots: [
        {
          id: "mort-slot",
          bet: 100,
          cards: [{ id: "seven", card: { suit: "hearts", value: 7, points: 7 }, faceUp: true }],
          doubled: false,
          canDouble: false,
          mort: false,
          blindPair: false,
          blindUntilBankEnd: false,
          mortOffered: true,
          status: "playing",
        },
      ],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    room.players = [banker, human];
    room.turnPlayerIndex = 0;

    clearRoomTimers(host, room);
    void publishRoom(host, room);
    const firstDeadline = room.mortDeadlineAt;
    assert.ok(firstDeadline && firstDeadline > Date.now());
    assert.equal(room.turnDeadlineAt, firstDeadline);
    assert.ok(scheduled.length >= 1);
    assert.ok(scheduled[0]! <= turnMs);

    void publishRoom(host, room);
    assert.equal(room.mortDeadlineAt, firstDeadline, "republish must not extend mort window");

    const view = roomToView(room, human.id, host);
    const me = view.players.find((p) => p.id === human.id);
    assert.equal(me?.pendingChoices?.mortDeadline, firstDeadline);
    assert.equal(view.mortDeadline, firstDeadline);

    clock.advance(200);
    assert.equal(human.handSlots[0]!.mortOffered, false);
    assert.equal(scheduled[0], turnMs, "mort window uses humanTurnTimeoutMs");
    delete process.env.SETIMIG_TEST_FAST;
  });

  it("mort timeout declines then finishes the hand without timer loop", async () => {
    process.env.SETIMIG_TEST_FAST = "1";
    let timerStarts = 0;
    const room = emptyRoomBase("mort-room", "Mort", 100, 0);
    room.houseRulesEnabled = true;
    room.phase = "playing";
    // Baralla fixa: amb room.deck = [] es barrejava una baralla nova a l'atzar i el nombre de
    // cartes (i de temporitzadors) del bot variava entre execucions (de vegades 13 > 12).
    room.deck = Array.from({ length: 20 }, (_, i) => {
      const value = i % 2 ? 4 : 2;
      return { suit: "clubs" as const, value, points: value };
    });
    room.pot = 200;
    // Rellotge virtual (abans: setTimeout real limitat a 40 ms i dues esperes reals de 120 ms).
    const clock = createManualClockHost({ capMs: 40, onSchedule: () => (timerStarts += 1) });
    const host = clock.host;
    const banker: Player = {
      id: "banker",
      playerId: "bank",
      seatToken: "b",
      name: "Bank",
      chips: 5000,
      bet: 0,
      isBanker: true,
      status: "stood",
      handSlots: [{ id: "bs", bet: 0, cards: [], doubled: false, canDouble: false, mort: false, blindPair: false, blindUntilBankEnd: false, mortOffered: false, status: "stood" }],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    const human: Player = {
      id: "human-1",
      playerId: "h1",
      seatToken: "h",
      name: "Human",
      chips: 400,
      bet: 100,
      isBanker: false,
      status: "playing",
      handSlots: [
        {
          id: "mort-slot",
          bet: 100,
          cards: [{ id: "seven", card: { suit: "hearts", value: 7, points: 7 }, faceUp: true }],
          doubled: false,
          canDouble: false,
          mort: false,
          blindPair: false,
          blindUntilBankEnd: false,
          mortOffered: true,
          status: "playing",
        },
      ],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    const bot: Player = {
      id: "bot-1",
      playerId: "bot-1",
      seatToken: "bot",
      name: "Bot",
      chips: 500,
      bet: 100,
      isBanker: false,
      isBot: true,
      status: "stood",
      handSlots: [
        {
          id: "bot-slot",
          bet: 100,
          cards: [{ id: "b1", card: figureCard("clubs"), faceUp: true }],
          doubled: false,
          canDouble: false,
          mort: false,
          blindPair: false,
          blindUntilBankEnd: false,
          mortOffered: false,
          status: "stood",
        },
      ],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    room.players = [banker, human, bot];
    room.turnPlayerIndex = 0;

    // Atzar fix (decisions de bots i ofertes de banca): el nombre de temporitzadors no ha de variar.
    const realRandom = Math.random;
    let seed = 42;
    Math.random = () => ((seed = (seed * 1_103_515_245 + 12_345) % 2_147_483_648) / 2_147_483_648);
    try {
      clearRoomTimers(host, room);
      void publishRoom(host, room);
      clock.advance(120);
      assert.equal(human.handSlots[0]!.mortOffered, false);
      assert.equal(human.handSlots[0]!.canDouble, true);

      clock.advance(120);
      const phase: Room["phase"] = room.phase;
      const slotStatus = human.handSlots[0]?.status;
      const finished =
        phase !== "playing" || slotStatus === "stood" || slotStatus === "busted";
      assert.ok(finished, `expected hand to finish, phase=${phase} slot=${slotStatus ?? "cleared"}`);
      assert.ok(timerStarts <= 12, `expected <= 12 timer schedules, got ${timerStarts}`);
    } finally {
      Math.random = realRandom;
    }
    delete process.env.SETIMIG_TEST_FAST;
  });
});

describe("betting coverage (human banker)", () => {
  function botPlayer(id: string, name: string): Player {
    return {
      id,
      playerId: id,
      seatToken: id,
      name,
      chips: 2_000,
      bet: 0,
      isBanker: false,
      isBot: true,
      status: "betting",
      handSlots: [],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
  }

  it("accepts both minimum wagers when the human banker funds their natural liability", () => {
    const room = emptyRoomBase("cov", "Cov", 100, 0);
    room.soloAi = true;
    room.phaseB = { handsTotal: 10, handsCompleted: 5, chipPool: 6_000 };
    const human: Player = {
      id: "human",
      playerId: "human",
      seatToken: "human",
      name: "Human",
      chips: 400,
      bet: 0,
      isBanker: true,
      isBot: false,
      status: "betting",
      handSlots: [],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    const firstBot = botPlayer("b1", "Laia");
    const secondBot = botPlayer("b2", "Pau");
    room.players = [human, firstBot, secondBot];
    const host: GameHost = {
      emitRoomUpdate() {},
      schedule: () => ({} as ReturnType<typeof setTimeout>),
      clearTimeout() {},
    };
    beginBettingPhase(host, room);
    assert.equal(room.phase, "betting");
    assert.equal(applyPlaceBet(room, firstBot, 100), null);
    assert.equal(applyPlaceBet(room, secondBot, 100), null);
    assert.equal(firstBot.bet, 100);
    assert.equal(secondBot.bet, 100);
    assert.equal(room.phase, "playing");
  });

  it("clamps a wager to the remaining aggregate natural-exposure budget", () => {
    const room = emptyRoomBase("cap", "Cap", 100, 0);
    const banker: Player = {
      id: "bank",
      playerId: "bank",
      seatToken: "bank",
      name: "Bank",
      chips: 500,
      bet: 0,
      isBanker: true,
      isBot: false,
      status: "betting",
      handSlots: [],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    const bot = botPlayer("b1", "Bot");
    const bot2 = botPlayer("b2", "Bot2");
    room.players = [banker, bot, bot2];
    room.phase = "betting";
    assert.equal(applyPlaceBet(room, bot, 999), null);
    assert.equal(bot.bet, 150);
    assert.equal(applyPlaceBet(room, bot2, 100), null);
    assert.equal(bot2.bet, 100);
  });

  it("accepts the creator's minimum, any in-range wager, and maximum inclusively", () => {
    for (const [index, amount] of [200, 375, 550].entries()) {
      const room = emptyRoomBase(`private-limits-${index}`, "Private limits", 200, 0);
      room.phase = "betting";
      room.tableMaxBet = 550;
      const banker: Player = {
        id: "bank",
        playerId: "bank",
        seatToken: "bank",
        name: "Bank",
        chips: 2_200,
        bet: 0,
        isBanker: true,
        isBot: false,
        status: "betting",
        handSlots: [],
        activeSlotIndex: 0,
        lastRoyal7Payout: 0,
        royal7AsBankerStreak: 0,
      };
      const player = botPlayer(`p-${index}`, "Player");
      const waitingPlayer = botPlayer(`waiting-${index}`, "Waiting");
      room.players = [banker, player, waitingPlayer];

      assert.equal(applyPlaceBet(room, player, amount), null);
      assert.equal(player.bet, amount);
    }
  });
});

describe("beginGameStart guards", () => {
  function mockHost(): GameHost {
    return createManualClockHost().host;
  }

  it("does not crash with zero players and leaves room waiting", () => {
    const room = emptyRoomBase("empty-room", "Empty", 100, 1000);
    room.players = [];
    room.phase = "waiting";
    const host = mockHost();
    beginGameStart(host, room);
    assert.equal(room.phase, "waiting");
    assert.equal(room.bankDraw, undefined);
  });

  it("does not crash when bank draw would be empty and leaves room waiting", () => {
    const room = emptyRoomBase("solo-stale", "Solo", 100, 1000);
    room.soloAi = true;
    room.players = [
      {
        id: "only",
        playerId: "only-id",
        seatToken: "s1",
        name: "Solo",
        chips: 1000,
        bet: 0,
        isBanker: false,
        status: "waiting",
        handSlots: [],
        activeSlotIndex: 0,
        lastRoyal7Payout: 0,
        royal7AsBankerStreak: 0,
      },
    ];
    room.phase = "waiting";
    const host = mockHost();
    beginGameStart(host, room);
    assert.equal(room.phase, "waiting");
    assert.equal(room.bankDraw, undefined);
  });
});


function minimalHandSlot(overrides: Partial<HandSlot> & Pick<HandSlot, "cards">): HandSlot {
  return {
    id: "s1",
    bet: 10,
    doubled: false,
    canDouble: false,
    mort: false,
    blindPair: false,
    blindUntilBankEnd: false,
    mortOffered: false,
    status: "playing",
    ...overrides,
  };
}

function card(value: number): Card {
  return { suit: "hearts", value, points: value <= 7 ? value : 0.5 };
}

describe("one hidden card per ordinary hand", () => {
  it("deals the next card face up when a hidden card already exists", () => {
    assert.equal(
      nextCardFaceUp(
        minimalHandSlot({
          cards: [
            { id: "hidden", card: card(2), faceUp: false },
            { id: "visible", card: card(4), faceUp: true },
          ],
        }),
      ),
      true,
    );
  });

  it("deals the next card face down when all cards are visible", () => {
    assert.equal(
      nextCardFaceUp(
        minimalHandSlot({
          cards: [
            { id: "visible-1", card: card(2), faceUp: true },
            { id: "visible-2", card: card(4), faceUp: true },
          ],
        }),
      ),
      false,
    );
  });

  it("applyHit adds a face-up card when the hand still has a hidden card", () => {
    const host: GameHost = createManualClockHost().host;
    const room = emptyRoomBase("hit-face", "Hit", 100, 0);
    room.phase = "playing";
    room.deck = [card(4)];
    const banker: Player = {
      id: "bank",
      playerId: "bank",
      seatToken: "b",
      name: "Bank",
      chips: 5_000,
      bet: 0,
      isBanker: true,
      status: "stood",
      handSlots: [],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    const human: Player = {
      id: "human",
      playerId: "human",
      seatToken: "h",
      name: "Human",
      chips: 400,
      bet: 100,
      isBanker: false,
      status: "playing",
      handSlots: [
        minimalHandSlot({
          cards: [{ id: "c0", card: card(2), faceUp: false }],
        }),
      ],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    room.players = [banker, human];
    room.turnPlayerIndex = 0;
    applyHit(host, room, human.id);
    assert.equal(human.handSlots[0]!.cards.length, 2);
    assert.equal(human.handSlots[0]!.cards[1]!.faceUp, true);
  });

  it("applyHit adds a face-down card when every card is already visible", () => {
    const host: GameHost = createManualClockHost().host;
    const room = emptyRoomBase("hit-hidden", "Hit", 100, 0);
    room.phase = "playing";
    room.deck = [card(1)];
    const banker: Player = {
      id: "bank",
      playerId: "bank",
      seatToken: "b",
      name: "Bank",
      chips: 5_000,
      bet: 0,
      isBanker: true,
      status: "stood",
      handSlots: [],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    const human: Player = {
      id: "human",
      playerId: "human",
      seatToken: "h",
      name: "Human",
      chips: 400,
      bet: 100,
      isBanker: false,
      status: "playing",
      handSlots: [
        minimalHandSlot({
          cards: [
            { id: "c0", card: card(2), faceUp: true },
            { id: "c1", card: card(3), faceUp: true },
          ],
        }),
      ],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    room.players = [banker, human];
    room.turnPlayerIndex = 0;
    applyHit(host, room, human.id);
    assert.equal(human.handSlots[0]!.cards.length, 3);
    assert.equal(human.handSlots[0]!.cards[2]!.faceUp, false);
  });

  it("secret-3 hand still draws face up while blind cards remain", () => {
    assert.equal(
      nextCardFaceUp(
        minimalHandSlot({
          blindPair: true,
          blindUntilBankEnd: true,
          cards: [
            { id: "p1", card: card(10), faceUp: false },
            { id: "p2", card: card(7), faceUp: false },
          ],
        }),
      ),
      true,
    );
  });
});

describe("reveal control eligibility", () => {
  it("allows reveal on ordinary hands", () => {
    assert.equal(canRevealCardsToRivals({ blindPair: false, blindUntilBankEnd: false }), true);
  });

  it("blocks reveal for secret-3 hands", () => {
    assert.equal(canRevealCardsToRivals({ blindPair: true, blindUntilBankEnd: true }), false);
  });

  it("blocks reveal for Mort hands", () => {
    assert.equal(canRevealCardsToRivals({ blindPair: false, blindUntilBankEnd: true }), false);
  });

  it("roomToView exposes blindUntilBankEnd without extra card data", () => {
    const host: GameHost = createManualClockHost().host;
    const room = emptyRoomBase("blind-flag", "Blind", 100, 0);
    room.phase = "playing";
    const secret = { suit: "clubs" as const, value: 3, points: 3 };
    const player: Player = {
      id: "p1",
      playerId: "p1",
      seatToken: "s1",
      name: "P",
      chips: 1_000,
      bet: 100,
      isBanker: false,
      status: "playing",
      handSlots: [
        {
          id: "hs",
          bet: 100,
          cards: [{ id: "c1", card: secret, faceUp: false }],
          doubled: false,
          canDouble: false,
          mort: true,
          blindPair: false,
          blindUntilBankEnd: true,
          mortOffered: false,
          status: "stood",
        },
      ],
      activeSlotIndex: 0,
      lastRoyal7Payout: 0,
      royal7AsBankerStreak: 0,
    };
    room.players = [
      {
        id: "bank",
        playerId: "bank",
        seatToken: "b",
        name: "Bank",
        chips: 5_000,
        bet: 0,
        isBanker: true,
        status: "stood",
        handSlots: [],
        activeSlotIndex: 0,
        lastRoyal7Payout: 0,
        royal7AsBankerStreak: 0,
      },
      player,
    ];
    const view = roomToView(room, "p1", host).players.find((p) => p.id === "p1")!;
    assert.equal(view.handSlots[0]!.blindUntilBankEnd, true);
    assert.equal(canRevealCardsToRivals(view.handSlots[0]!), false);
    const wire = JSON.stringify(view.handSlots[0]);
    assert.doesNotMatch(wire, /"value":3/);
  });
});
