const MAX_NAME_LEN = 24;

function normalizeBase(name: string, fallback: string): string {
  const trimmed = name.trim();
  const base = (trimmed || fallback).slice(0, MAX_NAME_LEN);
  return base || fallback;
}

/** Assign a room-unique display name (case-insensitive), suffixing «Nom 2», «Nom 3», … */
export function uniqueDisplayNameInRoom(
  existingNames: string[],
  requested: string,
  fallback = "Jugador"
): string {
  const base = normalizeBase(requested, fallback);
  const taken = new Set(existingNames.map((n) => n.trim().toLowerCase()).filter(Boolean));
  if (!taken.has(base.toLowerCase())) return base;
  for (let n = 2; n < 100; n++) {
    const suffix = ` ${n}`;
    const candidate = `${base.slice(0, Math.max(1, MAX_NAME_LEN - suffix.length))}${suffix}`;
    if (!taken.has(candidate.toLowerCase())) return candidate;
  }
  return `${base.slice(0, 18)}-${Date.now().toString(36).slice(-5)}`;
}
