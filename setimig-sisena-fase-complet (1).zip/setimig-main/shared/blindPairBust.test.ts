/**
 * auditoria-regles.md #39: la parella cega del 3 segueix les regles normals.
 * Si es passa de 7½ perd l'aposta i no cobra mai, encara que la banca també es passi.
 * Si no es passa i la banca sí, guanya 1:1.
 */
import assert from "node:assert/strict";
import { describe, it } from "node:test";
import type { Card } from "../src/gameTypes.ts";
import {
  clearRoomTimers,
  emptyRoomBase,
  settleGame,
  type GameHost,
  type HandSlot,
  type Player,
} from "./gameEngine.ts";
import { scoreCards } from "./scoring.ts";

const noopHost: GameHost = {
  emitRoomUpdate() {},
  schedule: (fn, ms) => setTimeout(fn, ms),
  clearTimeout() {},
};

const BET = 100;
const START = 1_000;
const BANK_START = 5_000;

function card(value: number): Card {
  return { suit: "hearts", value, points: value >= 10 ? 0.5 : value };
}

function slot(id: string, values: number[], overrides: Partial<HandSlot> = {}): HandSlot {
  return {
    id,
    bet: 0,
    cards: values.map((v, i) => ({ id: `${id}-${i}`, card: card(v), faceUp: true })),
    status: "stood",
    mort: false,
    blindPair: false,
    doubled: false,
    canDouble: false,
    blindUntilBankEnd: false,
    mortOffered: false,
    ...overrides,
  };
}

function basePlayer(id: string, overrides: Partial<Player> = {}): Player {
  return {
    id,
    playerId: id,
    seatToken: id,
    name: id,
    chips: START,
    bet: 0,
    isBanker: false,
    status: "stood",
    handSlots: [],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
    ...overrides,
  };
}

/** Liquida una mà amb una parella cega del 3 (tal com la deixa dealInitialForPlayer) contra la banca donada. */
function settleBlindPair(pairValues: number[], bankValues: number[]) {
  const room = emptyRoomBase("bp39", "BP39", BET, 0);
  room.houseRulesEnabled = true;
  const banker = basePlayer("bank", {
    isBanker: true,
    chips: BANK_START,
    handSlots: [slot("bs", bankValues)],
  });
  const pair = slot("ps", pairValues, {
    bet: BET,
    blindPair: true,
    blindUntilBankEnd: true,
    status: "playing",
  });
  pair.cards.forEach((c) => {
    c.faceUp = false;
  });
  const player = basePlayer("p1", {
    bet: BET,
    chips: START - BET,
    status: "playing",
    handSlots: [pair],
  });
  room.pot = BET;
  room.players = [banker, player];
  room.roundStartChips = new Map([
    ["bank", BANK_START],
    ["p1", START],
  ]);
  settleGame(noopHost, room);
  clearRoomTimers(noopHost, room);
  return { room, banker, player };
}

describe("#39 parella cega del 3 passada", () => {
  process.env.SETIMIG_TEST_FAST = "1";

  it("7+6 (13) contra banca amb 6 → perd l'aposta i no cobra", () => {
    const { room, banker, player } = settleBlindPair([7, 6], [6]);
    assert.equal(scoreCards(player.handSlots[0]!.cards), 13);
    assert.equal(player.chips - START, -BET);
    assert.equal(banker.chips - BANK_START, BET);
    assert.equal(room.pot, 0);
  });

  it("7+6 (13) contra banca passada (5+2+1) → perd igualment", () => {
    const { room, banker, player } = settleBlindPair([7, 6], [5, 2, 1]);
    assert.equal(player.chips - START, -BET);
    assert.equal(banker.chips - BANK_START, BET);
    assert.equal(room.pot, 0);
  });

  // Normes de la casa (Edu, 28/10/2026): el 3 canviat que guanya cobra el doble.
  it("4+2 (6) contra banca passada (5+2+1) → guanya el doble", () => {
    const { room, banker, player } = settleBlindPair([4, 2], [5, 2, 1]);
    assert.equal(player.chips - START, 2 * BET);
    assert.equal(banker.chips - BANK_START, -2 * BET);
    assert.equal(room.pot, 0);
  });

  it("7+6 (13) contra banca amb 7½ → perd (no arriba a la comparació de punts)", () => {
    const { banker, player } = settleBlindPair([7, 6], [7, 10]);
    assert.equal(player.chips - START, -BET);
    assert.equal(banker.chips - BANK_START, BET);
  });
});
