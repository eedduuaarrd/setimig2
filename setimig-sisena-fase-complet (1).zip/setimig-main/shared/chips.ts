/** Starting balance for new players (server store and local IA session). */
export const DEFAULT_CHIPS = 24_500;
