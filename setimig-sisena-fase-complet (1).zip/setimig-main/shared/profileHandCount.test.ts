import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  averagePointsFromTenths,
  bankerFact,
  factsFromSlots,
  pointsToTenths,
  profileFact,
  type SlotCountInput,
} from "./profileHandCount.ts";

function slot(partial: Partial<SlotCountInput> & Pick<SlotCountInput, "points" | "cardCount">): SlotCountInput {
  return { handIndex: 0, ...partial };
}

describe("estadístiques del perfil: definicions", () => {
  it("passada: superar 7½, també la parella cega; el Mort que falla no ho és", () => {
    assert.equal(profileFact(slot({ points: 9, cardCount: 3, code: "bust" })).bust, true);
    assert.equal(profileFact(slot({ points: 13, cardCount: 2, code: "bust" })).bust, true);
    const mort = profileFact(slot({ points: 11, cardCount: 2, code: "mortLoses", mort: true }));
    assert.equal(mort.bust, false);
    assert.equal(mort.result, "lose");
    assert.equal(profileFact(slot({ points: 6.5, cardCount: 2, code: "bankWins" })).bust, false);
  });

  it("«banca passada» és una victòria contra la banca, no una passada del jugador", () => {
    const win = profileFact(slot({ points: 5, cardCount: 2, code: "winBankBust" }));
    assert.equal(win.bust, false);
    assert.equal(win.winAgainstBank, true);
    assert.equal(win.result, "win");
  });

  it("plantada automàtica: no és passada i conserva els punts", () => {
    const stood = profileFact(slot({ points: 5, cardCount: 2, code: "bankWins", autoStood: true }));
    assert.equal(stood.autoStood, true);
    assert.equal(stood.bust, false);
    assert.equal(stood.winAgainstBank, false);
    assert.equal(stood.points, 5);
    assert.equal(profileFact(slot({ points: 9, cardCount: 3, code: "bust", autoStood: true })).autoStood, false);
  });

  it("victòria contra la banca: cobra; l'empat no compta", () => {
    assert.equal(profileFact(slot({ points: 6.5, cardCount: 2, code: "win" })).winAgainstBank, true);
    assert.equal(profileFact(slot({ points: 6, cardCount: 2, code: "tieBank" })).winAgainstBank, false);
    assert.equal(profileFact(slot({ points: 6, cardCount: 2, code: "tieBank" })).result, "lose");
    assert.equal(profileFact(slot({ points: 4, cardCount: 1, code: "bankWins" })).winAgainstBank, false);
  });

  it("7½ natural: dues cartes i 7½, també si la banca també en fa i guanya ella", () => {
    const won = profileFact(slot({ points: 7.5, cardCount: 2, code: "naturalWin" }));
    assert.equal(won.naturalSevenHalf, true);
    assert.equal(won.winAgainstBank, true);
    assert.equal(won.bust, false);
    const lost = profileFact(slot({ points: 7.5, cardCount: 2, code: "tieSevenHalfBank" }));
    assert.equal(lost.naturalSevenHalf, true);
    assert.equal(lost.winAgainstBank, false);
    assert.equal(lost.result, "lose");
    assert.equal(profileFact(slot({ points: 7.5, cardCount: 3, code: "win" })).naturalSevenHalf, false);
  });

  it("split: dues mans; doblada: una sola mà que sí que compta", () => {
    const facts = factsFromSlots(
      [
        slot({ points: 9, cardCount: 3, handIndex: 0 }),
        slot({ points: 6.5, cardCount: 2, handIndex: 1 }),
      ],
      [
        { code: "bust", hand: 0 },
        { code: "win", hand: 1 },
      ]
    );
    assert.equal(facts.length, 2);
    assert.equal(facts[0]!.bust, true);
    assert.equal(facts[1]!.winAgainstBank, true);
    assert.equal(facts[1]!.points, 6.5);
    const splitSeven = factsFromSlots(
      [
        slot({ points: 7.5, cardCount: 2, handIndex: 0 }),
        slot({ points: 5, cardCount: 2, handIndex: 1 }),
      ],
      [
        { code: "win", hand: 0 },
        { code: "win", hand: 1 },
      ]
    );
    assert.equal(splitSeven[0]!.naturalSevenHalf, false, "després de separar, sota + 7 no és natural");
    assert.equal(splitSeven[1]!.naturalSevenHalf, false);
    const doubled = profileFact(slot({ points: 6, cardCount: 2, code: "win", doubled: true }));
    assert.equal(doubled.doubled, true);
    assert.equal(doubled.winAgainstBank, true);
  });

  it("la banca que es passa compta com a passada; si cobra, és victòria", () => {
    assert.equal(bankerFact({ points: 9, cardCount: 3, chipDelta: -100 }).bust, true);
    const collected = bankerFact({ points: 7, cardCount: 2, chipDelta: 200, autoStood: true });
    assert.equal(collected.bust, false);
    assert.equal(collected.winAgainstBank, true);
    assert.equal(collected.autoStood, true);
  });

  it("la mitjana conserva les mitges (6,5 no es torna 6)", () => {
    assert.equal(pointsToTenths(6.5), 65);
    assert.equal(pointsToTenths(7.5), 75);
    const tenths = [6.5, 7.5, 5.5, 6.5].reduce((sum, p) => sum + pointsToTenths(p), 0);
    assert.equal(averagePointsFromTenths(tenths, 4), 6.5);
  });
});
