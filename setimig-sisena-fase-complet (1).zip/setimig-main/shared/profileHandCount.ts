/**
 * Què entra a les estadístiques del perfil. Definició: docs/estadistiques-perfil.md.
 * Les mitges es guarden en dècimes perquè 6,5 no es converteixi en 6.
 */

export type ProfileHandResult = "win" | "lose" | "push" | "bust" | "jackpot";

export type ProfileHandFact = {
  points: number;
  /** Passada: la mà supera 7½. El Mort que no fa 7½ no ho és. La banca passada tampoc. */
  bust: boolean;
  /** El temporitzador ha plantat la mà (no és una passada). */
  autoStood: boolean;
  /** El jugador cobra a la banca (o, si ell és la banca, acaba amb més fitxes). */
  winAgainstBank: boolean;
  /** 7½ exacte amb dues cartes, sense passar-se. */
  naturalSevenHalf: boolean;
  /** La mà està doblada: continua sent una sola mà i sí que compta. */
  doubled: boolean;
  result: ProfileHandResult;
};

const WIN_CODES = new Set(["win", "winBankBust", "naturalWin", "specialWin"]);

export function pointsToTenths(points: number): number {
  if (!Number.isFinite(points) || points <= 0) return 0;
  return Math.round(points * 10);
}

export function averagePointsFromTenths(tenths: number, handsPlayed: number): number {
  if (handsPlayed <= 0) return 0;
  return Math.round((tenths / handsPlayed / 10) * 10) / 10;
}

export function isNaturalSevenHalf(points: number, cardCount: number, bust: boolean): boolean {
  return !bust && cardCount === 2 && Math.abs(points - 7.5) < 0.001;
}

export type SlotCountInput = {
  points: number;
  cardCount: number;
  /** Codi d'highlight del motor (`bust`, `win`, `winBankBust`, …). */
  code?: string;
  mort?: boolean;
  doubled?: boolean;
  autoStood?: boolean;
  /** Índex de la mà (0, 1 o 2: un re-split arriba a 3 mans). */
  handIndex: number;
  /** La mà ve d'una separació: un 7½ de dues cartes no és natural. */
  fromSplit?: boolean;
};

/**
 * Passada: total > 7½, o el codi `bust` (inclou la parella cega del 3 en destapar-se).
 * El Mort que no és 7½ perd l'aposta i no és una passada.
 * `winBankBust` («banca passada») és una victòria, no una passada del jugador.
 */
export function profileFact(input: Omit<SlotCountInput, "handIndex"> & { chipDelta?: number; fromSplit?: boolean }): ProfileHandFact {
  const mortMiss = !!input.mort && Math.abs(input.points - 7.5) > 0.001;
  const bust =
    !mortMiss &&
    input.code !== "mortLoses" &&
    !WIN_CODES.has(input.code ?? "") &&
    (input.code === "bust" || input.points > 7.5);
  const naturalSevenHalf = input.fromSplit ? false : isNaturalSevenHalf(input.points, input.cardCount, bust);
  let result: ProfileHandResult;
  if (bust) result = "bust";
  else if (input.code && WIN_CODES.has(input.code)) result = "win";
  // Empat: guanya la banca. No és victòria del jugador (però tampoc una passada).
  else if (input.code === "tieBank" || input.code === "tieSevenHalfBank") result = "lose";
  else if (input.chipDelta != null) result = input.chipDelta > 0 ? "win" : input.chipDelta < 0 ? "lose" : "push";
  else result = "lose";
  return {
    points: input.points,
    bust,
    autoStood: !!input.autoStood && !bust,
    winAgainstBank: result === "win",
    naturalSevenHalf,
    doubled: !!input.doubled,
    result,
  };
}

/** Una entrada per mà amb aposta: un split són dues mans; una doblada és una. */
export function factsFromSlots(
  slots: SlotCountInput[],
  hands: { code: string; hand: number }[]
): ProfileHandFact[] {
  const fromSplit = slots.length > 1;
  return slots.map((slot) => {
    const hand = hands.find((h) => h.hand === slot.handIndex);
    return profileFact({ ...slot, code: hand?.code, fromSplit });
  });
}

/** La banca (quan el jugador ho és): una mà. Passada si supera 7½. Victòria si el delta de fitxes és positiu. */
export function bankerFact(input: {
  points: number;
  cardCount: number;
  chipDelta: number;
  autoStood?: boolean;
}): ProfileHandFact {
  return profileFact({
    points: input.points,
    cardCount: input.cardCount,
    autoStood: input.autoStood,
    chipDelta: input.chipDelta,
  });
}
