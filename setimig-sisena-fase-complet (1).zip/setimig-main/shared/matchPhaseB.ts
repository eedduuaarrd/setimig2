import type { MatchRankingEntry, MatchResult } from "../src/gameTypes.ts";

/** Partida estructurada (IA servidor + taula privada): 10 mans, 2.000 CF de partida. */
export const PHASE_B_HAND_COUNT = 10;
export const PHASE_B_START_CHIPS = 2_000;
export const PHASE_B_ELIMINATION_BELOW = 100;

export type PhaseBMatchPlayer = {
  id: string;
  name: string;
  chips: number;
  isBot?: boolean;
  seatOrder?: number;
};

export type PhaseBMatchState = {
  handsTotal: number;
  handsCompleted: number;
  /** Fitxes totals al inici (conservació). */
  chipPool: number;
  /** Starting stack for new and rematch hands; optional for older persisted rooms. */
  startingChips?: number;
};

export function phaseBMatchEnabled(room: { soloAi?: boolean; isPrivate?: boolean }): boolean {
  return !!(room.soloAi || room.isPrivate);
}

export function initialPhaseBMatchState(
  playerCount: number,
  extraChips = 0,
  startingChips = PHASE_B_START_CHIPS
): PhaseBMatchState {
  return {
    handsTotal: PHASE_B_HAND_COUNT,
    handsCompleted: 0,
    chipPool: playerCount * startingChips + extraChips,
    startingChips,
  };
}

export function resetPlayersToPhaseBChips(
  players: { chips: number; bet: number; status: string }[],
  startingChips = PHASE_B_START_CHIPS
): void {
  for (const p of players) {
    p.chips = startingChips;
    p.bet = 0;
    p.status = "waiting";
  }
}

export function recordPhaseBHandComplete(state: PhaseBMatchState): PhaseBMatchState {
  return {
    ...state,
    handsCompleted: Math.min(state.handsTotal, state.handsCompleted + 1),
  };
}

export function phaseBHandsRemaining(state: PhaseBMatchState): number {
  return Math.max(0, state.handsTotal - state.handsCompleted);
}

export function isPhaseBMatchComplete(state: PhaseBMatchState): boolean {
  return state.handsCompleted >= state.handsTotal;
}

function tieBreak(a: PhaseBMatchPlayer, b: PhaseBMatchPlayer): number {
  const orderA = a.seatOrder ?? 0;
  const orderB = b.seatOrder ?? 0;
  if (orderA !== orderB) return orderA - orderB;
  return a.id.localeCompare(b.id);
}

type RankedPhaseBPlayer = PhaseBMatchPlayer & { seatOrder: number; eliminated: boolean };

function sortPhaseBPlayers(players: PhaseBMatchPlayer[], minBet: number): RankedPhaseBPlayer[] {
  const enriched: RankedPhaseBPlayer[] = players.map((p, index) => ({
    ...p,
    seatOrder: p.seatOrder ?? index,
    eliminated: p.chips < minBet,
  }));
  enriched.sort((a, b) => {
    if (a.eliminated !== b.eliminated) return a.eliminated ? 1 : -1;
    if (b.chips !== a.chips) return b.chips - a.chips;
    return tieBreak(a, b);
  });
  return enriched;
}

/** Guanyador per fitxes; desempat per ordre de seient (spec tie-break determinista). */
export function rankPhaseBPlayers(
  players: PhaseBMatchPlayer[],
  minBet: number
): MatchRankingEntry[] {
  return sortPhaseBPlayers(players, minBet).map((p) => ({
    name: p.name,
    chips: p.chips,
    isHuman: !p.isBot,
    eliminated: p.eliminated,
  }));
}

export function computePhaseBMatchResult(
  players: PhaseBMatchPlayer[],
  minBet: number,
  viewerId: string,
  state: PhaseBMatchState
): MatchResult | null {
  const active = players.filter((p) => p.chips >= minBet);
  const scheduleDone = isPhaseBMatchComplete(state);
  const humanEliminated = players.some((p) => !p.isBot && p.chips < minBet);
  const earlyFinish = state.handsCompleted > 0 && (active.length <= 1 || humanEliminated);
  if (!scheduleDone && !earlyFinish) return null;

  const sorted = sortPhaseBPlayers(players, minBet);
  const ranking = sorted.map((p) => ({
    name: p.name,
    chips: p.chips,
    isHuman: !p.isBot,
    eliminated: p.eliminated,
  }));
  const winnerPlayer = sorted.find((p) => !p.eliminated) ?? sorted[0] ?? null;
  const viewerPlayer = sorted.find((p) => p.id === viewerId);
  let viewerOutcome: MatchResult["viewerOutcome"] = null;
  if (viewerPlayer) {
    if (viewerPlayer.eliminated) viewerOutcome = "eliminated";
    else if (winnerPlayer && viewerPlayer.id === winnerPlayer.id) viewerOutcome = "win";
    else viewerOutcome = "lose";
  }

  return {
    winnerName: winnerPlayer?.name ?? null,
    ranking,
    viewerOutcome,
  };
}

/** Pot + jugadors (sense jackpot de casa). */
export function phaseBPlayerPool(input: { players: { chips: number }[]; pot: number }): number {
  return input.players.reduce((s, p) => s + p.chips, 0) + input.pot;
}

/** @deprecated use phaseBPlayerPool for fase B */
export function totalTableChips(input: {
  players: { chips: number }[];
  pot: number;
  jackpot: number;
}): number {
  return phaseBPlayerPool(input);
}
