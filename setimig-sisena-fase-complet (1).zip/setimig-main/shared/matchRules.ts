import type { MatchRankingEntry, MatchResult } from "../src/gameTypes.ts";

export type MatchPlayer = {
  id: string;
  name: string;
  chips: number;
  isBot?: boolean;
};

/** Partida IA acaba quan el humà o tots els bots queden sense fitxes per a l'aposta mínima. */
export function computeSoloMatchResult(
  players: MatchPlayer[],
  minBet: number,
  viewerId: string
): MatchResult | null {
  const human = players.find((p) => !p.isBot);
  if (!human) return null;

  const ranking: MatchRankingEntry[] = [...players]
    .map((p) => ({
      name: p.name,
      chips: p.chips,
      isHuman: !p.isBot,
      eliminated: p.chips < minBet,
    }))
    .sort((a, b) => b.chips - a.chips);

  const humanActive = human.chips >= minBet;
  const activeBots = players.filter((p) => p.isBot && p.chips >= minBet);

  if (!humanActive) {
    const topBot = [...players].filter((p) => p.isBot).sort((a, b) => b.chips - a.chips)[0];
    return {
      winnerName: topBot?.name ?? null,
      ranking,
      viewerOutcome: human.id === viewerId ? "eliminated" : "lose",
    };
  }

  if (activeBots.length === 0) {
    return {
      winnerName: human.name,
      ranking,
      viewerOutcome: human.id === viewerId ? "win" : "win",
    };
  }

  return null;
}
