import assert from "node:assert/strict";
import { describe, it } from "node:test";
import type { Card } from "../src/gameTypes.ts";
import { createManualClockHost } from "./testing/manualClockHost.ts";
import { maxBet } from "./bankRotation.ts";
import {
  applyPlaceBet,
  beginBettingPhase,
  clearRoomTimers,
  drawCard,
  emptyRoomBase,
  finishSettlementToWaiting,
  scheduleAfterRoomChange,
  settleGame,
  type GameHost,
  type Player,
  type Room,
} from "./gameEngine.ts";
import { cardKey, countCardsByKey, createSingleSpanishDeck } from "./spanishDeck.ts";
import { fisherYatesShuffle } from "./shuffle.ts";
import { scoreCards } from "./scoring.ts";

const noopHost: GameHost = {
  emitRoomUpdate() {},
  schedule: (fn, ms) => setTimeout(fn, ms),
  clearTimeout() {},
};

function card(value: number): Card {
  return { suit: "hearts", value, points: value >= 10 ? 0.5 : value };
}

function basePlayer(id: string, overrides: Partial<Player> = {}): Player {
  return {
    id,
    playerId: id,
    seatToken: id,
    name: id,
    chips: 5_000,
    bet: 0,
    isBanker: false,
    status: "betting",
    handSlots: [],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
    ...overrides,
  };
}

function allRoomCards(room: Room): Card[] {
  const out: Card[] = [...room.deck, ...room.centerDiscard];
  if (room.bankDraw) {
    for (const e of room.bankDraw) out.push(e.card);
  }
  for (const p of room.players) {
    for (const slot of p.handSlots) {
      for (const c of slot.cards) out.push(c.card);
    }
  }
  return out;
}

function assertSingleShoeIntegrity(room: Room) {
  const cards = allRoomCards(room);
  assert.equal(cards.length, 40);
  const counts = countCardsByKey(cards);
  assert.equal(counts.size, 40);
  for (const c of createSingleSpanishDeck()) {
    assert.equal(counts.get(cardKey(c)), 1);
  }
}

function assertNoDuplicateInHand(room: Room) {
  for (const p of room.players) {
    for (const slot of p.handSlots) {
      const keys = slot.cards.map((c) => cardKey(c.card));
      assert.equal(new Set(keys).size, keys.length);
    }
  }
}

describe("bets engine fixes", () => {
  process.env.SETIMIG_TEST_FAST = "1";

  it("reshuffles discard into deck only when deck is empty", () => {
    const room = emptyRoomBase("deck", "Deck", 100, 0);
    room.deck = fisherYatesShuffle(createSingleSpanishDeck());
    while (room.deck.length > 0) {
      const c = drawCard(room);
      assert.ok(c);
      room.centerDiscard.push(c);
    }
    assert.equal(room.deck.length, 0);
    assert.equal(room.centerDiscard.length, 40);
    const c = drawCard(room);
    assert.ok(c);
    room.centerDiscard.push(c);
    assert.equal(room.deck.length, 39);
    assert.equal(room.centerDiscard.length, 1);
    assertSingleShoeIntegrity(room);
  });

  it("200 hands: no duplicate in hand and always 40 cards in shoe", () => {
    const room = emptyRoomBase("sim", "Sim", 100, 0);
    room.deck = fisherYatesShuffle(createSingleSpanishDeck());
    room.centerDiscard = [];
    const banker = basePlayer("bank", { isBanker: true, chips: 50_000 });
    const p1 = basePlayer("p1", { chips: 50_000 });
    room.players = [banker, p1];

    for (let h = 0; h < 200; h += 1) {
      p1.handSlots = [];
      banker.handSlots = [
        {
          id: "bs",
          bet: 0,
          cards: [],
          status: "playing",
          mort: false,
          blindPair: false,
          doubled: false,
          canDouble: false,
          blindUntilBankEnd: false,
          mortOffered: false,
        },
      ];
      const cardsThisHand: Card[] = [];
      const drawCount = 3 + (h % 4);
      for (let i = 0; i < drawCount; i += 1) {
        const c = drawCard(room);
        assert.ok(c);
        cardsThisHand.push(c);
      }
      const keys = cardsThisHand.map(cardKey);
      assert.equal(new Set(keys).size, keys.length);
      p1.handSlots = [
        {
          id: "ps",
          bet: 100,
          cards: cardsThisHand.slice(0, 2).map((c, i) => ({
            id: `p${i}`,
            card: c,
            faceUp: true,
          })),
          status: "stood",
          mort: false,
          blindPair: false,
          doubled: false,
          canDouble: false,
          blindUntilBankEnd: false,
          mortOffered: false,
        },
      ];
      for (const c of cardsThisHand.slice(2)) {
        banker.handSlots[0]!.cards.push({ id: `b${c.value}`, card: c, faceUp: true });
      }
      assertNoDuplicateInHand(room);
      assertSingleShoeIntegrity(room);
      finishSettlementToWaiting(noopHost, room);
      assertSingleShoeIntegrity(room);
    }
  });

  it("natural 7½ vs busted banker pays 2:1 from bank", () => {
    const room = emptyRoomBase("nat", "Nat", 100, 0);
    const banker = basePlayer("bank", {
      isBanker: true,
      chips: 1_000,
      status: "busted",
      handSlots: [
        {
          id: "bs",
          bet: 0,
          cards: [
            { id: "b1", card: card(7), faceUp: true },
            { id: "b2", card: card(5), faceUp: true },
          ],
          status: "busted",
          mort: false,
          blindPair: false,
          doubled: false,
          canDouble: false,
          blindUntilBankEnd: false,
          mortOffered: false,
        },
      ],
    });
    const player = basePlayer("p1", {
      bet: 100,
      chips: 900,
      status: "stood",
      handSlots: [
        {
          id: "ps",
          bet: 100,
          cards: [
            { id: "p1", card: card(7), faceUp: true },
            { id: "p2", card: card(10), faceUp: true },
          ],
          status: "stood",
          mort: false,
          blindPair: false,
          doubled: false,
          canDouble: false,
          blindUntilBankEnd: false,
          mortOffered: false,
        },
      ],
    });
    assert.equal(scoreCards(player.handSlots[0]!.cards), 7.5);
    room.pot = 100;
    room.players = [banker, player];
    room.roundStartChips = new Map([["bank", 1_000], ["p1", 1_000]]);
    settleGame(noopHost, room);
    clearRoomTimers(noopHost, room);
    assert.equal(player.chips, 900 + 100 + 200);
    assert.equal(banker.chips, 1_000 - 200);
  });

  it("maxBet accounts for opponent minimums and player chips", () => {
    const state = {
      minBet: 100,
      players: [
        { id: "b", isBanker: true, chips: 400 },
        { id: "p1", isBanker: false, chips: 666 },
        { id: "p2", isBanker: false, chips: 666 },
      ],
    };
    assert.equal(maxBet(state, "p1"), 100);
    assert.equal(maxBet(state, "p2"), 100);
    const rich = { ...state, players: [...state.players.slice(0, 2), { id: "p2", isBanker: false, chips: 2_000 }] };
    assert.equal(maxBet(rich, "p2"), 100);
  });

  it("3 bots with 666 chips: excessive bet clamped, betting phase completes", async () => {
    const room = emptyRoomBase("clamp", "Clamp", 100, 0);
    room.soloAi = true;
    const banker = basePlayer("bank", { isBanker: true, isBot: true, chips: 5_000 });
    const b1 = basePlayer("b1", { isBot: true, chips: 666 });
    const b2 = basePlayer("b2", { isBot: true, chips: 666 });
    const b3 = basePlayer("b3", { isBot: true, chips: 666 });
    room.players = [banker, b1, b2, b3];
    // Rellotge virtual: abans s'esperaven 120 ms reals i, amb càrrega, la mà ja era a «banker».
    const clock = createManualClockHost();
    beginBettingPhase(clock.host, room);
    const capBefore = maxBet(room, "b1");
    assert.equal(applyPlaceBet(room, b1, 9_999), null);
    assert.equal(b1.bet, capBefore);
    scheduleAfterRoomChange(clock.host, room);
    clock.runUntil(() => room.phase !== "betting", 10_000);
    assert.equal(room.phase, "playing");
    for (const bot of [b2, b3]) {
      assert.ok(bot.bet >= 100);
      assert.ok(bot.bet <= maxBet(room, bot.playerId));
    }
  });
});
