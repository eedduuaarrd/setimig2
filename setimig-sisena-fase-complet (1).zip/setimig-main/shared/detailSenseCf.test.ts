/**
 * El text de reserva de lastRound (`detail` / `text`) no porta la unitat «CF».
 * El client el parteix per « · » i el tradueix amb parseGameMessage; code i params no canvien.
 */
import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { parseGameMessage } from "./gameMessages.ts";
import {
  formatSignedAmount,
  highlightFallbackText,
  resultFallbackDetail,
  type HighlightMessage,
} from "./messageCodes.ts";

const base = { player: "Anna", seatId: "s1", hand: 0, score: 7 };

describe("detail de lastRound sense unitat CF", () => {
  it("l'import és un enter amb signe, sense separadors", () => {
    assert.equal(formatSignedAmount(200), "+200");
    assert.equal(formatSignedAmount(12500), "+12500");
    assert.equal(formatSignedAmount(0), "+0");
    assert.equal(formatSignedAmount(-40), "-40");
  });

  const cases: { msg: HighlightMessage; text: string; old: string }[] = [
    {
      msg: { code: "win", params: { ...base, amount: 200, bankScore: 6 } },
      text: "+200",
      old: "+200 CF",
    },
    {
      msg: { code: "winBankBust", params: { ...base, amount: 300, bankScore: 9 } },
      text: "+300 (banca passada)",
      old: "+300 CF (banca passada)",
    },
    {
      msg: { code: "naturalWin", params: { ...base, score: 7.5, amount: 12500, jackpot: 12200, bankBusted: false } },
      text: "7 i Mig natural — +12500",
      old: "7 i Mig natural — +12,500 CF",
    },
    {
      msg: {
        code: "specialWin",
        params: {
          ...base,
          special: "mort",
          amount: 300,
          jackpot: 0,
          bankScore: 5,
          bankBusted: false,
          multiplier: 2,
        },
      },
      text: "Mort ×2 — +300",
      old: "Mort ×2 — +300 CF",
    },
    {
      msg: {
        code: "specialWin",
        params: {
          ...base,
          special: "threeSwap",
          amount: 1200,
          jackpot: 0,
          bankScore: 5,
          bankBusted: false,
          multiplier: 2,
        },
      },
      text: "3 canviat ×2 — +1200",
      old: "3 canviat ×2 — +1,200 CF",
    },
  ];

  for (const { msg, text, old } of cases) {
    it(`${msg.code} → «${text}», i l'antic «${old}» es continua reconeixent`, () => {
      assert.equal(highlightFallbackText(msg), text);
      assert.doesNotMatch(text, /\bCF\b/);
      const parsed = parseGameMessage(text);
      const legacy = parseGameMessage(old);
      assert.equal(parsed?.code, `engine.result.${msg.code}`);
      assert.equal(legacy?.code, parsed?.code);
      assert.equal(parsed?.params?.amount, (msg.params as { amount: number }).amount);
      assert.equal(legacy?.params?.amount, parsed?.params?.amount);
      if (msg.code === "specialWin") {
        assert.equal(parsed?.params?.special, msg.params.special);
        assert.equal(legacy?.params?.special, msg.params.special);
      }
    });
  }

  it("el detail d'unes mans és la unió dels textos, i els camps estructurats es queden", () => {
    const hands: HighlightMessage[] = [
      { code: "bust", params: { ...base, score: 8 } },
      { code: "win", params: { ...base, hand: 1, amount: 200, bankScore: 6 } },
    ];
    const detail = resultFallbackDetail({
      code: "hands",
      params: { player: "Anna", seatId: "s1", chipDelta: 100, hands },
    });
    assert.equal(detail, "Passat · +200");
    assert.doesNotMatch(detail, /\bCF\b/);
    assert.deepEqual(
      detail.split(" · ").map((part) => parseGameMessage(part)?.code),
      ["engine.result.bust", "engine.result.win"]
    );
  });

  it("les etiquetes sense import no canvien", () => {
    assert.equal(highlightFallbackText({ code: "bust", params: base }), "Passat");
    assert.equal(highlightFallbackText({ code: "bankWins", params: { ...base, bankScore: 6 } }), "Banca guanya");
    assert.equal(
      resultFallbackDetail({ code: "bank", params: { player: "B", seatId: "b", chipDelta: 5, score: 6 } }),
      "Banca"
    );
    assert.equal(
      resultFallbackDetail({ code: "noChange", params: { player: "A", seatId: "a", chipDelta: 0 } }),
      "Sense canvi"
    );
  });
});
