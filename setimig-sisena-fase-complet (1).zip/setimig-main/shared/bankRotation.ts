/** Rotació de banca (fase B): cobertura, 7½ (via bankRules), cada 3 mans. */

export type BankRotationPlayer = {
  id: string;
  isBanker: boolean;
  chips: number;
  /** Wager already committed in the current hand, if any. */
  bet?: number;
  isBot?: boolean;
  refusedBankBefore?: boolean;
};

export function activeNonBankerCount(players: BankRotationPlayer[], minBet: number): number {
  return players.filter((p) => !p.isBanker && ((p.bet ?? 0) > 0 || p.chips >= minBet)).length;
}

/** Banker can fund every eligible opponent's worst-case 2:1 natural payout at minBet. */
export function bankerCanCover(
  bankerChips: number,
  minBet: number,
  opponentCount: number
): boolean {
  if (opponentCount <= 0) return bankerChips >= minBet;
  return bankerChips >= naturalBankPayout(minBet) * opponentCount;
}

/** Màxim que pot apostar cada oponent sense superar la cobertura total de la banca. */
export function maxBetPerOpponent(
  bankerChips: number,
  opponentCount: number,
  /** Worst-case bank payout multiplier per bet (7½ natural = 2:1 from bank). */
  payoutMultiplier = 1
): number {
  if (opponentCount <= 0) return bankerChips;
  const denom = opponentCount * Math.max(1, payoutMultiplier);
  return Math.floor(bankerChips / denom);
}

/** Bank liability for a single bet if the hand is a 7½ natural (2:1 from bank). */
export function naturalBankPayout(bet: number): number {
  return bet * 2;
}

/** Checks worst-case natural liability for each eligible player's actual wager ceiling. */
export function bankerCanCoverWagerRange(
  bankerChips: number,
  minBet: number,
  opponentChips: number[],
  tableMaxBet?: number
): boolean {
  const liabilityBase = opponentChips
    .filter((chips) => chips >= minBet)
    .reduce((sum, chips) => sum + Math.min(chips, tableMaxBet ?? minBet), 0);
  return naturalBankPayout(liabilityBase) <= bankerChips;
}

/** Cap d'aposta per oponent, o null si la banca no pot cobrir ni l'aposta mínima de la taula. */
export function bettingCoverageCap(
  bankerChips: number,
  opponentCount: number,
  minBet: number
): number | null {
  if (!bankerCanCover(bankerChips, minBet, opponentCount)) return null;
  return maxBetPerOpponent(bankerChips, opponentCount, 2);
}

export type MaxBetState = {
  minBet: number;
  /** Optional creator-selected wager ceiling for a private table. */
  tableMaxBet?: number;
  players: Array<BankRotationPlayer & { playerId?: string }>;
};

/** Màxim que pot apostar un jugador: min(fitxes, cobertura de la banca). */
export function maxBet(state: MaxBetState, playerId: string): number {
  const player = state.players.find((p) => p.id === playerId || p.playerId === playerId);
  if (!player || player.isBanker) return 0;
  if ((player.bet ?? 0) > 0) return Math.floor(player.bet ?? 0);
  let limit = Math.floor(player.chips);
  const tableMaxBet =
    state.tableMaxBet != null && Number.isFinite(state.tableMaxBet)
      ? Math.floor(state.tableMaxBet)
      : undefined;
  if (tableMaxBet != null) limit = Math.min(limit, tableMaxBet);

  const banker = state.players.find((p) => p.isBanker);
  if (!banker || player.chips < state.minBet) return limit;

  const eligible = state.players.filter(
    (p) => !p.isBanker && ((p.bet ?? 0) > 0 || p.chips >= state.minBet)
  );
  const open = eligible.filter((p) => (p.bet ?? 0) <= 0);
  const committed = eligible.reduce((sum, p) => sum + Math.max(0, p.bet ?? 0), 0);
  const otherOpen = open.filter((p) => p !== player).length;
  const otherOpenPlayers = open.filter((p) => p !== player);
  const reserveForOthers =
    tableMaxBet == null
      ? state.minBet * otherOpen
      : otherOpenPlayers.reduce((sum, p) => sum + Math.min(tableMaxBet, p.chips), 0);
  const availableForPlayer = Math.floor(banker.chips / 2 - committed - reserveForOthers);
  const playerMax = tableMaxBet == null ? undefined : Math.min(tableMaxBet, player.chips);

  // A creator-selected range is all-or-nothing: never advertise a lower cap.
  if (playerMax != null && availableForPlayer < playerMax) return 0;
  limit = Math.min(limit, availableForPlayer);
  return limit >= state.minBet ? limit : 0;
}

export function botAcceptsBankOfferWithCover(
  chips: number,
  minBet: number,
  opponentCount: number
): boolean {
  return bankerCanCover(chips, minBet, opponentCount);
}

/** Següent jugador en ordre de seient que pot cobrir (inclou bots). */
export function pickNextBankerInSeatOrder<T extends BankRotationPlayer>(
  players: T[],
  minBet: number,
  excludeId?: string,
  tableMaxBet?: number
): T | null {
  if (players.length === 0) return null;
  const start = players.findIndex((p) => p.isBanker);
  const order: T[] = [];
  for (let i = 1; i <= players.length; i++) {
    const idx = (start + i) % players.length;
    order.push(players[idx]!);
  }
  for (const p of order) {
    if (excludeId && p.id === excludeId) continue;
    const opponents = players.filter((x) => x.id !== p.id);
    const eligibleOpponentCount = opponents.filter((x) => x.chips >= minBet).length;
    if (tableMaxBet != null) {
      if (!bankerCanCoverWagerRange(p.chips, minBet, opponents.map((x) => x.chips), tableMaxBet)) continue;
    } else {
      const opponentCount = eligibleOpponentCount || opponents.length;
      if (!bankerCanCover(p.chips, minBet, opponentCount)) continue;
    }
    return p;
  }
  return null;
}

export function applyBankerToPlayer<T extends BankRotationPlayer>(players: T[], bankerId: string): void {
  for (const p of players) {
    p.isBanker = p.id === bankerId;
  }
}

export function mustRotateBankAfterHand(consecutiveHandsAsBanker: number): boolean {
  return consecutiveHandsAsBanker >= 3;
}
