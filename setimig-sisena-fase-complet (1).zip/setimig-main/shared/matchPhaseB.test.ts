import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  PHASE_B_HAND_COUNT,
  PHASE_B_START_CHIPS,
  computePhaseBMatchResult,
  initialPhaseBMatchState,
  rankPhaseBPlayers,
  recordPhaseBHandComplete,
  totalTableChips,
} from "./matchPhaseB.ts";

describe("matchPhaseB", () => {
  it("declares winner by chips after 10 hands", () => {
    const state = initialPhaseBMatchState(3);
    let s = state;
    for (let i = 0; i < PHASE_B_HAND_COUNT; i++) s = recordPhaseBHandComplete(s);
    const players = [
      { id: "h", name: "Human", chips: 2_400, isBot: false, seatOrder: 0 },
      { id: "b1", name: "Bot1", chips: 1_800, isBot: true, seatOrder: 1 },
      { id: "b2", name: "Bot2", chips: 1_800, isBot: true, seatOrder: 2 },
    ];
    const result = computePhaseBMatchResult(players, 100, "h", s);
    assert.ok(result);
    assert.equal(result!.winnerName, "Human");
    assert.equal(result!.viewerOutcome, "win");
  });

  it("tie-break uses seat order when chips equal", () => {
    const ranking = rankPhaseBPlayers(
      [
        { id: "b", name: "B", chips: 2_000, seatOrder: 1 },
        { id: "a", name: "A", chips: 2_000, seatOrder: 0 },
      ],
      100
    );
    assert.equal(ranking[0]!.name, "A");
    assert.equal(ranking[1]!.name, "B");
  });

  it("marks elimination below min bet before schedule ends", () => {
    const state = { handsTotal: 10, handsCompleted: 2, chipPool: 4_000 };
    const players = [
      { id: "a", name: "A", chips: 2_100, seatOrder: 0 },
      { id: "b", name: "B", chips: 50, seatOrder: 1 },
    ];
    const result = computePhaseBMatchResult(players, 100, "a", state);
    assert.ok(result);
    assert.equal(result!.winnerName, "A");
    assert.equal(result!.ranking.find((r) => r.name === "B")?.eliminated, true);
  });

  it("ends with viewer eliminated when human has 0 chips but bots remain active", () => {
    const state = { handsTotal: 10, handsCompleted: 7, chipPool: 6_000 };
    const players = [
      { id: "h", name: "Human", chips: 0, isBot: false, seatOrder: 0 },
      { id: "b1", name: "Laia", chips: 2_400, isBot: true, seatOrder: 1 },
      { id: "b2", name: "Pau", chips: 1_800, isBot: true, seatOrder: 2 },
    ];
    const result = computePhaseBMatchResult(players, 100, "h", state);
    assert.ok(result);
    assert.equal(result!.viewerOutcome, "eliminated");
    assert.equal(result!.ranking.find((r) => r.isHuman)?.eliminated, true);
  });

  it("viewer outcome uses player id when duplicate display names exist", () => {
    const state = { handsTotal: 10, handsCompleted: 10, chipPool: 4_000 };
    const players = [
      { id: "h1", name: "Anna", chips: 2_500, isBot: false, seatOrder: 0 },
      { id: "h2", name: "Anna 2", chips: 1_500, isBot: false, seatOrder: 1 },
    ];
    const win = computePhaseBMatchResult(players, 100, "h1", state);
    const lose = computePhaseBMatchResult(players, 100, "h2", state);
    assert.equal(win!.viewerOutcome, "win");
    assert.equal(lose!.viewerOutcome, "lose");
  });

  it("conserves chip pool in accounting helper", () => {
    const total = totalTableChips({
      players: [{ chips: 1_500 }, { chips: 2_500 }],
      pot: 200,
      jackpot: 0,
    });
    assert.equal(total, 4_200);
    assert.equal(PHASE_B_START_CHIPS, 2_000);
  });
});
