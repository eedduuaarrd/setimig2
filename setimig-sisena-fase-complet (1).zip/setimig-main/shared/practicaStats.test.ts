/**
 * Pràctica: les mans compten a les estadístiques de sessió (pantalla final «Mans guanyades x/10»),
 * però mai no toquen el saldo real (balances.json) ni res persistent.
 */
import { describe, it, before, after } from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { createServer } from "node:http";
import { Server as SocketIOServer } from "socket.io";
import { io as ioClient } from "socket.io-client";
import {
  emptyRoomBase,
  resetSessionStats,
  roomToView,
  settleGame,
  type GameHost,
  type HandSlot,
  type Player,
  type Room,
} from "./gameEngine.ts";
import { createSingleSpanishDeck } from "./spanishDeck.ts";
import type { Card } from "../src/gameTypes.ts";

const deck = createSingleSpanishDeck();
function card(value: number, suit: Card["suit"] = "hearts"): Card {
  const c = deck.find((d) => d.value === value && d.suit === suit);
  assert.ok(c);
  return { ...c };
}
function slot(cards: Card[], bet: number, status: HandSlot["status"]): HandSlot {
  return {
    id: `s-${Math.random()}`,
    cards: cards.map((c, i) => ({ id: `c${i}-${c.suit}-${c.value}`, card: c, faceUp: i > 0 })),
    bet,
    doubled: false,
    canDouble: false,
    mort: false,
    blindPair: false,
    blindUntilBankEnd: false,
    mortOffered: false,
    status,
  };
}
function seat(id: string, extra: Partial<Player> = {}): Player {
  return {
    id,
    playerId: id,
    seatToken: `tok-${id}`,
    name: id,
    chips: 1_900,
    bet: 0,
    isBanker: false,
    status: "stood",
    handSlots: [],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
    ...extra,
  };
}

function countingHost() {
  const persisted: string[] = [];
  const host: GameHost = {
    emitRoomUpdate() {},
    schedule: () => 0 as unknown as ReturnType<typeof setTimeout>,
    clearTimeout() {},
    async persistHumanBalance(playerId) {
      persisted.push(playerId);
    },
  };
  return { host, persisted };
}

/** Una mà ja jugada: banca (bot) amb `bankCards`; l'humà H aposta 100 amb `humanCards`. */
function playedHand(room: Room, humanCards: Card[], bankCards: Card[], humanStatus: HandSlot["status"] = "stood") {
  const banker = room.players.find((p) => p.isBanker)!;
  const human = room.players.find((p) => p.id === "H")!;
  room.roundStartChips = new Map(room.players.map((p) => [p.playerId, p.chips]));
  human.chips -= 100;
  human.bet = 100;
  room.pot = 100;
  human.handSlots = [slot(humanCards, 100, humanStatus)];
  banker.handSlots = [slot(bankCards, 0, "stood")];
  banker.status = "stood";
  room.phase = "banker";
}

function practiceRoom(extra: Partial<Room> = {}): Room {
  const room = emptyRoomBase("solo-H", "Pràctica", 100, 0);
  room.soloAi = true;
  room.soloHumanPlayerId = "H";
  room.practiceMode = true;
  room.players = [seat("B", { isBot: true, isBanker: true, chips: 2_000 }), seat("H", { chips: 2_000 })];
  Object.assign(room, extra);
  return room;
}

describe("pràctica: estadístiques de sessió (P1, prod 6eaedda)", () => {
  for (const practiceMode of [true, false]) {
    it(`${practiceMode ? "pràctica" : "mode normal"}: guanyar plantant-se a 7 compta com a mà jugada i guanyada`, () => {
      const { host, persisted } = countingHost();
      const room = practiceRoom({ practiceMode });
      playedHand(room, [card(2), card(5, "clubs")], [card(6)]); // 7 contra 6
      settleGame(host, room);
      let stats = roomToView(room, "H", host).sessionStats!;
      assert.equal(stats.handsPlayed, 1);
      assert.equal(stats.handsWon, 1);
      assert.equal(stats.netCf, 100);
      assert.equal(stats.bestHandWin, 100);
      assert.equal(stats.winStreak, 1);
      assert.equal(stats.lastOutcome, "win");

      // Segona mà: perd (5 contra 6).
      room.phase = "waiting";
      playedHand(room, [card(5)], [card(6, "clubs")]);
      settleGame(host, room);
      stats = roomToView(room, "H", host).sessionStats!;
      assert.equal(stats.handsPlayed, 2);
      assert.equal(stats.handsWon, 1, "«Mans guanyades 1/2»");
      assert.equal(stats.netCf, 0);
      assert.equal(stats.winStreak, 0);
      assert.equal(stats.lastOutcome, "lose");
      assert.ok(stats.handsWon <= stats.handsPlayed);
      // Solo (fase B) i pràctica no escriuen mai el saldo real des de la liquidació.
      assert.deepEqual(persisted, []);
    });
  }

  it("pràctica: el reinici de sessió continua posant-ho tot a zero", () => {
    const { host } = countingHost();
    const room = practiceRoom();
    playedHand(room, [card(2), card(5, "clubs")], [card(6)]);
    settleGame(host, room);
    assert.equal(roomToView(room, "H", host).sessionStats!.handsPlayed, 1);
    resetSessionStats(room);
    const stats = roomToView(room, "H", host).sessionStats!;
    assert.equal(stats.handsPlayed, 0);
    assert.equal(stats.handsWon, 0);
    assert.equal(stats.netCf, 0);
  });

  it("torneig ràpid i fitxes aïllades: les mans de sessió compten i el saldo real no s'escriu", () => {
    const { host, persisted } = countingHost();
    const room = practiceRoom({ practiceMode: false, fastTournament: true });
    playedHand(room, [card(2), card(5, "clubs")], [card(6)]);
    settleGame(host, room);
    const stats = roomToView(room, "H", host).sessionStats!;
    assert.equal(stats.handsPlayed, 1, "abans el torneig deixava «Sessió: 0 mans»");
    assert.equal(stats.handsWon, 1);
    assert.deepEqual(persisted, [], "el saldo real no es toca");
  });
});

describe("pràctica per socket: compta mans i no toca balances.json", () => {
  let dataDir = "";
  let http: ReturnType<typeof createServer>;
  let io: SocketIOServer;
  let url = "";
  let game: typeof import("../server/game.ts");
  let balances: typeof import("../server/balances.ts");
  let writes: typeof import("../server/writeCoalescing.ts");

  before(async () => {
    dataDir = await fs.mkdtemp(path.join(os.tmpdir(), "setimig-practica-stats-"));
    process.env.BALANCE_DATA_DIR = dataDir;
    process.env.SETIMIG_TEST_FAST = "1";
    process.env.SETIMIG_SKIP_PRIVATE_ROOM_LOAD = "1";
    game = await import("../server/game.ts");
    balances = await import("../server/balances.ts");
    writes = await import("../server/writeCoalescing.ts");
    balances.resetBalanceStoreCacheForTests();
    game.resetGameStateForTests();
    http = createServer();
    io = new SocketIOServer(http, { cors: { origin: "*" } });
    await game.setupGameHandlers(io);
    await new Promise<void>((r) => http.listen(0, "127.0.0.1", () => r()));
    url = `http://127.0.0.1:${(http.address() as { port: number }).port}`;
  });

  after(async () => {
    io.close();
    await new Promise<void>((r) => http.close(() => r()));
    const { removeTestDataDir } = await import("../server/testing/testDataDir.ts");
    await removeTestDataDir(dataDir);
    delete process.env.BALANCE_DATA_DIR;
  });

  it("dues o més mans de pràctica: sessionStats > 0, saldo real intacte, reset a zero", async () => {
    const playerId = "practicastats0001";
    await balances.setBalance(playerId, 7_777);
    await writes.flushAllPendingWrites();
    writes.resetWriteCounts();

    const socket = ioClient(url, { transports: ["websocket"], forceNew: true });
    await new Promise<void>((r) => socket.on("connect", () => r()));
    try {
      let lastStats: { handsPlayed: number; handsWon: number } | null = null;
      let roomId = "";
      let betKey = "";
      await new Promise<void>((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error(`timeout: ${JSON.stringify(lastStats)}`)), 45_000);
        socket.on("room_update", (room: {
          id: string;
          phase: string;
          minBet: number;
          turnPlayerId?: string | null;
          practiceMode?: boolean;
          sessionStats?: { handsPlayed: number; handsWon: number } | null;
          players: { id: string; bet: number; isBanker: boolean; pendingBankChoice?: { mandatory: boolean } | null }[];
        }) => {
          roomId = room.id;
          assert.equal(room.practiceMode, true);
          if (room.sessionStats) lastStats = room.sessionStats;
          if (lastStats && lastStats.handsPlayed >= 2) {
            clearTimeout(timer);
            resolve();
            return;
          }
          const me = room.players.find((p) => p.id === socket.id);
          if (!me) return;
          if (me.pendingBankChoice) socket.emit("bank_keep_choice", { roomId: room.id, keep: !!me.pendingBankChoice.mandatory });
          if (room.phase === "settlement") socket.emit("settlement_next", room.id);
          const key = `${lastStats?.handsPlayed ?? 0}`;
          if (room.phase === "betting" && !me.isBanker && me.bet === 0 && betKey !== key) {
            betKey = key;
            socket.emit("place_bet", { roomId: room.id, amount: room.minBet });
          }
          if (room.phase === "playing" && room.turnPlayerId === socket.id) socket.emit("stand", room.id);
          if (room.phase === "banker" && me.isBanker) socket.emit("stand", room.id);
        });
        socket.emit("join_solo_room", {
          playerName: "PracticaStats",
          playerId,
          botCount: 2,
          botDifficulty: "easy",
          practiceMode: true,
        });
      });
      assert.ok(lastStats!.handsPlayed >= 2, "les mans de pràctica compten");
      assert.ok(lastStats!.handsWon <= lastStats!.handsPlayed);
      const snap = game.getRoomSnapshotForTests(roomId)!;
      assert.equal(snap.practiceMode, true);

      // Reinici de sessió (botó de la pantalla final).
      const afterReset = new Promise<{ handsPlayed: number }>((resolve) => {
        const onUpdate = (room: { sessionStats?: { handsPlayed: number } | null }) => {
          if (room.sessionStats && room.sessionStats.handsPlayed === 0) {
            socket.off("room_update", onUpdate);
            resolve(room.sessionStats);
          }
        };
        socket.on("room_update", onUpdate);
      });
      socket.emit("reset_session", roomId);
      assert.equal((await afterReset).handsPlayed, 0);

      socket.emit("leave_room", roomId);
      await new Promise((r) => setTimeout(r, 300));
      await writes.flushAllPendingWrites();
      assert.equal(writes.getWriteCounts()["balances.json"] ?? 0, 0, "cap escriptura a balances.json");
      balances.resetBalanceStoreCacheForTests();
      assert.equal(await balances.getBalance(playerId), 7_777, "el saldo real no canvia");
    } finally {
      socket.disconnect();
    }
  });
});
