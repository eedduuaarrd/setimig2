/**
 * Cada rebuig de doblar té un codi estable i no toca l'estat.
 */
import assert from "node:assert/strict";
import { describe, it } from "node:test";
import type { Card } from "../src/gameTypes.ts";
import {
  applyDouble,
  classifyDoubleReject,
  clearRoomTimers,
  emptyRoomBase,
  type GameHost,
  type HandSlot,
  type Player,
  type Room,
} from "./gameEngine.ts";
import { DOUBLE_REJECT_CODE, ENGINE_MESSAGES } from "./gameMessages.ts";

const host: GameHost = {
  emitRoomUpdate() {},
  schedule: () => 0 as unknown as ReturnType<typeof setTimeout>,
  clearTimeout() {},
};

function card(value: number, suit: Card["suit"] = "hearts"): Card {
  return { suit, value, points: value >= 10 ? 0.5 : value };
}

function slot(extra: Partial<HandSlot> = {}): HandSlot {
  return {
    id: "h",
    bet: 100,
    cards: [{ id: "c0", card: card(4), faceUp: true }],
    doubled: false,
    canDouble: true,
    mort: false,
    blindPair: false,
    blindUntilBankEnd: false,
    mortOffered: false,
    status: "playing",
    ...extra,
  };
}

function seated(partial: Partial<Player> & Pick<Player, "id" | "isBanker">): Player {
  return {
    playerId: partial.id,
    seatToken: `tok-${partial.id}`,
    name: partial.id,
    chips: partial.isBanker ? 50_000 : 1_000,
    bet: partial.isBanker ? 0 : 100,
    status: "playing",
    handSlots: partial.isBanker ? [slot({ bet: 0, canDouble: false })] : [slot()],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
    ...partial,
  };
}

function makeRoom(extra?: Partial<Room>): { room: Room; player: Player } {
  const room = emptyRoomBase("dbl", "Doblar", 100, 0);
  room.houseRulesEnabled = true;
  room.phase = "playing";
  room.pot = 100;
  room.deck = [card(2, "clubs"), card(3, "diamonds")];
  const player = seated({ id: "edu", isBanker: false });
  room.players = [seated({ id: "bank", isBanker: true }), player];
  room.turnPlayerIndex = 0;
  Object.assign(room, extra);
  return { room, player };
}

function fingerprint(room: Room): string {
  return JSON.stringify({
    phase: room.phase,
    pot: room.pot,
    turn: room.turnPlayerIndex,
    deck: room.deck,
    players: room.players.map((p) => ({
      id: p.id,
      chips: p.chips,
      bet: p.bet,
      status: p.status,
      active: p.activeSlotIndex,
      slots: p.handSlots.map((s) => ({
        bet: s.bet,
        doubled: s.doubled,
        canDouble: s.canDouble,
        status: s.status,
        fromSplit: s.fromSplit === true,
        mort: s.mort,
        blindPair: s.blindPair,
        mortOffered: s.mortOffered,
        swapOffered: s.swapOffered ?? null,
        cards: s.cards.map((c) => [c.card.suit, c.card.value]),
      })),
    })),
  });
}

describe("rebuig de doblar: codi estable i estat intacte", () => {
  const cases: Array<{
    name: string;
    code: string;
    message: string;
    setup: (room: Room, player: Player) => void;
    actor?: string;
  }> = [
    {
      name: "fase incorrecta",
      code: DOUBLE_REJECT_CODE.badPhase,
      message: ENGINE_MESSAGES.cannotDoubleNow,
      setup: (room) => {
        room.phase = "betting";
      },
    },
    {
      name: "torn incorrecte",
      code: DOUBLE_REJECT_CODE.badTurn,
      message: ENGINE_MESSAGES.cannotDoubleNow,
      setup: (room) => {
        room.turnPlayerIndex = 4;
      },
    },
    {
      name: "jugador que no és a la sala",
      code: DOUBLE_REJECT_CODE.badTurn,
      message: ENGINE_MESSAGES.cannotDoubleNow,
      actor: "ningú",
      setup: () => {},
    },
    {
      name: "parella cega",
      code: DOUBLE_REJECT_CODE.blindPairLocked,
      message: ENGINE_MESSAGES.blindPairLocked,
      setup: (_room, player) => {
        player.handSlots[0]!.blindPair = true;
      },
    },
    {
      name: "normes de la casa apagades",
      code: DOUBLE_REJECT_CODE.houseRules,
      message: ENGINE_MESSAGES.cannotDouble,
      setup: (room) => {
        room.houseRulesEnabled = false;
      },
    },
    {
      name: "cal decidir el Mort",
      code: DOUBLE_REJECT_CODE.decideMortFirst,
      message: ENGINE_MESSAGES.decideMortFirst,
      setup: (_room, player) => {
        player.handSlots[0]!.mortOffered = true;
        player.handSlots[0]!.cards = [{ id: "c0", card: card(7), faceUp: false }];
      },
    },
    {
      name: "cal decidir el canvi",
      code: DOUBLE_REJECT_CODE.decideSwapFirst,
      message: ENGINE_MESSAGES.decideSwapFirst,
      setup: (_room, player) => {
        player.handSlots[0]!.swapOffered = 4;
      },
    },
    {
      name: "mà de Mort",
      code: DOUBLE_REJECT_CODE.mort,
      message: ENGINE_MESSAGES.cannotDouble,
      setup: (_room, player) => {
        player.handSlots[0]!.mort = true;
        player.handSlots[0]!.canDouble = false;
      },
    },
    {
      name: "aquesta mà ja ha doblat",
      code: DOUBLE_REJECT_CODE.alreadyDoubled,
      message: ENGINE_MESSAGES.alreadyDoubled,
      setup: (_room, player) => {
        player.handSlots[0]!.doubled = true;
        player.handSlots[0]!.canDouble = false;
        player.handSlots[0]!.bet = 200;
      },
    },
    {
      name: "la mà original ja havia doblat abans del split",
      code: DOUBLE_REJECT_CODE.splitAlreadyDoubled,
      message: ENGINE_MESSAGES.splitAlreadyDoubled,
      setup: (_room, player) => {
        const hand = player.handSlots[0]!;
        hand.fromSplit = true;
        hand.splitFromDoubled = true;
        hand.canDouble = false;
        hand.doubled = false;
        hand.cards = [
          { id: "a", card: card(12, "spades"), faceUp: true },
          { id: "b", card: card(3, "clubs"), faceUp: true },
        ];
      },
    },
    {
      name: "una mà separada no es pot doblar",
      code: DOUBLE_REJECT_CODE.splitCannotDouble,
      message: ENGINE_MESSAGES.splitCannotDouble,
      setup: (_room, player) => {
        const hand = player.handSlots[0]!;
        hand.fromSplit = true;
        hand.splitFromDoubled = false;
        hand.canDouble = false;
        hand.doubled = false;
        hand.cards = [
          { id: "a", card: card(10, "spades"), faceUp: true },
          { id: "b", card: card(5, "clubs"), faceUp: true },
        ];
      },
    },
    {
      name: "canDouble false",
      code: DOUBLE_REJECT_CODE.cannotDouble,
      message: ENGINE_MESSAGES.cannotDouble,
      setup: (_room, player) => {
        player.handSlots[0]!.canDouble = false;
      },
    },
    {
      name: "ja hi ha massa cartes",
      code: DOUBLE_REJECT_CODE.wrongCards,
      message: ENGINE_MESSAGES.cannotDouble,
      setup: (_room, player) => {
        player.handSlots[0]!.cards.push({ id: "c1", card: card(2, "clubs"), faceUp: true });
      },
    },
    {
      name: "fitxes insuficients",
      code: DOUBLE_REJECT_CODE.notEnoughChips,
      message: ENGINE_MESSAGES.noChipsDouble,
      setup: (_room, player) => {
        player.chips = 99;
      },
    },
    {
      name: "la banca no pot cobrir el doble",
      code: DOUBLE_REJECT_CODE.bankCannotCover,
      message: ENGINE_MESSAGES.bankCannotCoverDouble,
      setup: (room) => {
        room.players[0]!.chips = 399;
      },
    },
  ];

  for (const item of cases) {
    it(`${item.name}: ${item.code} i l'estat no canvia`, () => {
      const { room, player } = makeRoom();
      item.setup(room, player);
      const before = fingerprint(room);
      const actor = item.actor ?? player.id;
      const rejected = classifyDoubleReject(room, actor);
      assert.ok(rejected, item.name);
      assert.equal(rejected.code, item.code);
      assert.equal(rejected.message, item.message);
      assert.equal(applyDouble(host, room, actor), item.message);
      assert.equal(fingerprint(room), before);
    });
  }

  it("amb una carta i canDouble, el doblar sí que s'aplica", () => {
    const { room, player } = makeRoom();
    assert.equal(classifyDoubleReject(room, player.id), null);
    assert.equal(applyDouble(host, room, player.id), null);
    assert.equal(player.handSlots[0]!.doubled, true);
    assert.equal(player.handSlots[0]!.canDouble, false);
    assert.equal(player.handSlots[0]!.cards.length, 2);
    assert.equal(player.chips, 900);
    clearRoomTimers(host, room);
  });
});
