/**
 * Repart v2 (servidor): cada carta repartida és un esdeveniment ordenat i el torn següent no
 * s'activa fins que el client ha tingut temps de mostrar-la (temps de `repart-v2.md`).
 *
 * - El motor desa a `room.dealLog` les cartes repartides a la mà actual, amb `dealSeq` 1, 2, 3…
 *   sense forats (repartiment inicial, «demana», doblar, mort, separar i les cartes de la banca).
 * - El servidor les envia com a `card_dealt` per socket, en ordre i just abans del `room_update`,
 *   amb la carta NOMÉS si aquell socket la pot veure (mateixa regla que `PlayerView`).
 * - `room.dealAnimUntil` marca fins quan dura l'animació: els temporitzadors i els terminis dels
 *   humans comencen després, i els bots no actuen abans (sense allargar el seu ritme d'1,2–1,5 s).
 */
import type { Card, RoomView, TableCard } from "../src/gameTypes.ts";
import { dealCardMs, isTestFastPacing, type PacingContract } from "./pacing.ts";
import type { SettlementView } from "./settlementSummary.ts";

/** Constants de `repart-v2.md` §2–§4 (ms). El repartiment inicial usa `DEAL_CARD_MS` de `shared/pacing.ts`. */
export {
  BANK_REVEAL_MS,
  DEAL_BUST_MS,
  DEAL_FLIGHT_FLIP_MS,
  DEAL_FLIGHT_MS,
  DEAL_MAX_IN_TURN_MS,
  DEAL_STAGGER_MS,
} from "./pacing.ts";

export type DealKind = "initial" | "hit" | "double" | "mort" | "split" | "swap";

/** Registre intern (es desa a la sala). `playerId` no surt mai cap al client. */
export interface DealRecord {
  dealSeq: number;
  handSeq: number;
  kind: DealKind;
  playerId: string;
  slotIndex: number;
  /** Posició de la carta dins la mà (0, 1, 2…). */
  cardIndex: number;
  /** = `TableCard.id` a `PlayerView.handSlots[].cards[]`. */
  cardId: string;
  isBanker: boolean;
  /** Ordre dins del repartiment inicial (0…n−1); null per a la resta. */
  initialIndex: number | null;
  /** ms des de l'emissió en què el client ha de començar el vol (stagger del repartiment inicial). */
  delayMs: number;
  /** ms epoch del repartiment al servidor. */
  at: number;
}

/** Payload de l'esdeveniment socket `card_dealt` (un per carta, en ordre de `dealSeq`). */
export interface CardDealtEvent {
  roomId: string;
  handSeq: number;
  /** 1, 2, 3… dins la mà, sense forats. Es reinicia a cada mà nova. */
  dealSeq: number;
  kind: DealKind;
  /** = `PlayerView.id` del seient que rep la carta. */
  seatId: string;
  isBanker: boolean;
  slotIndex: number;
  cardIndex: number;
  cardId: string;
  /** Com es veu la carta per a AQUEST socket (igual que al `room_update` que ve just després). */
  faceUp: boolean;
  /** La carta només si aquest socket la pot veure; si no, null. */
  card: Card | null;
  initialIndex: number | null;
  delayMs: number;
  at: number;
  /** Fi de l'animació de tot el que s'ha repartit fins ara (ms epoch del servidor). */
  animUntil: number;
}

/** Estat del repartiment a la vista (també per al solo local, que no té sockets). */
export interface DealStateView {
  handSeq: number;
  /** Darrer `dealSeq` repartit en aquesta mà (0 si encara no n'hi ha cap). */
  lastDealSeq: number;
  /** Fins quan dura l'animació (ms epoch); el torn s'activa a partir d'aquí. */
  animUntil: number | null;
}

export type RoomViewExtended = RoomView & {
  settlement?: SettlementView | null;
  deal?: DealStateView | null;
  /** Durades nominals. Els terminis reals són `phaseEndsAt` i `actionHoldEndsAt`. */
  pacing?: PacingContract;
  /** Epoch ms en què acaba el pas actual (pausa d'avís, d'apostes, torn o liquidació). */
  phaseEndsAt?: number | null;
  /** Epoch ms en què acaba l'avís HIT/STAND. Null si no hi ha pausa. */
  actionHoldEndsAt?: number | null;
};

/** Durades a 0 amb SETIMIG_TEST_FAST (els tests ràpids no esperen animacions). */
export function dealAnimMs(ms: number): number {
  return isTestFastPacing() ? 0 : ms;
}

/**
 * Finestra del repartiment inicial: cartes × `DEAL_CARD_MS` (350), en seqüència,
 * abans del primer torn. El vol de cada carta hi cap a dins. Amb `SETIMIG_TEST_FAST` val 0.
 * `flips` es conserva a la signatura per qui ja el passava; no allarga la finestra.
 */
export function initialDealWindowMs(cards: { initialIndex: number; flips?: boolean }[]): number {
  return cards.length * dealCardMs();
}

/** Cerca com veu una carta un visor concret, a partir de la seva vista de jugadors. */
export function cardAsSeen(
  view: { players: { id: string; handSlots: { cards: TableCard[] }[] }[] },
  seatId: string,
  slotIndex: number,
  cardId: string
): { faceUp: boolean; card: Card | null } {
  const seat = view.players.find((p) => p.id === seatId);
  const slots = seat?.handSlots ?? [];
  const inSlot = slots[slotIndex]?.cards.find((c) => c.id === cardId);
  const found = inSlot ?? slots.flatMap((s) => s.cards).find((c) => c.id === cardId);
  if (!found) return { faceUp: false, card: null };
  return { faceUp: !!found.faceUp, card: found.card ?? null };
}
