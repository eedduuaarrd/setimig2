import { describe, it } from "node:test";
import assert from "node:assert/strict";
import {
  defaultAvatarConfig,
  deriveInitialsFromName,
  parseAvatarPatch,
  resolveProfileAvatar,
  toPlayerAvatarView,
} from "./playerAvatar.ts";

describe("playerAvatar", () => {
  it("deriva inicials del nom (1–2 lletres)", () => {
    assert.equal(deriveInitialsFromName("Ana"), "AN");
    assert.equal(deriveInitialsFromName("Pau Soler"), "PS");
    assert.equal(deriveInitialsFromName("  "), "J");
  });

  it("perfils antics sense avatar reben valors per defecte", () => {
    const cfg = resolveProfileAvatar(undefined, "Maria Costa", "player-abc");
    assert.equal(cfg.kind, "initials");
    assert.equal(cfg.initials, "MC");
    assert.ok(cfg.color);
  });

  it("rebutja símbol, color i inicials fora de llista", () => {
    assert.equal(parseAvatarPatch({ kind: "symbol", symbol: "dragon", color: "emerald" }, "X"), null);
    assert.equal(parseAvatarPatch({ kind: "initials", initials: "ABC", color: "emerald" }, "X"), null);
    assert.equal(parseAvatarPatch({ kind: "initials", initials: "A", color: "neon" }, "X"), null);
    assert.equal(parseAvatarPatch({ kind: "unknown", color: "emerald" }, "X"), null);
  });

  it("accepta patch vàlid de símbol i inicials", () => {
    const sym = parseAvatarPatch({ kind: "symbol", symbol: "heart", color: "rose" }, "X");
    assert.deepEqual(sym, { kind: "symbol", symbol: "heart", color: "rose" });
    const ini = parseAvatarPatch({ kind: "initials", initials: "z", color: "onyx" }, "Nom");
    assert.deepEqual(ini, { kind: "initials", initials: "Z", color: "onyx" });
  });

  it("exposa label a la vista de sala", () => {
    const view = toPlayerAvatarView(defaultAvatarConfig("Joan", "id-1"));
    assert.equal(view.kind, "initials");
    assert.equal(view.label, "JO");
    const sym = toPlayerAvatarView({ kind: "symbol", symbol: "seven", color: "amber" });
    assert.equal(sym.label, "7");
  });
});
