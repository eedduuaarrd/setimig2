/**
 * Codis estables per a les entrades de `lastRound.highlights[]` i `lastRound.results[]`
 * (i les mateixes línies de `lastSettlement`). Contracte: docs/codis-motor.md.
 *
 * Cada entrada porta `code` + `params` (només dades: noms, ids, números) i, com a reserva per als
 * clients en cau, el camp `text` / `detail` en català, generat aquí a partir del codi.
 * Els imports d'aquest text no porten unitat («+200», no «+200 CF»). Vegeu docs/codis-motor.md.
 */
import { ENGINE_LABELS } from "./gameMessages.ts";
import type { HandOutcome } from "../src/gameTypes.ts";

/** Paràmetres comuns de qualsevol highlight: de qui és i quina mà (índex de slot, 0 si no hi ha split). */
export interface HighlightBaseParams {
  /** Nom visible del jugador a la taula (dada, no frase). */
  player: string;
  /** Id de seient (el mateix que `PlayerView.id`). */
  seatId: string;
  /** Índex de la mà del jugador (0; 1 en la segona mà d'un split). */
  hand: number;
  /** Punts de la mà del jugador en liquidar. */
  score: number;
  /** Normes de la casa: mà especial (Mort o 3 canviat). Absent en mans normals. */
  special?: "mort" | "threeSwap";
}

export type HighlightMessage =
  /** «Passat»: la mà ha passat de 7½ (també la parella cega del 3 en destapar-se). */
  | { code: "bust"; params: HighlightBaseParams }
  /** «Mort — perd l'aposta»: el Mort no ha fet 7½. */
  | { code: "mortLoses"; params: HighlightBaseParams }
  /** «Banca guanya». */
  | { code: "bankWins"; params: HighlightBaseParams & { bankScore: number } }
  /** «Empat a 7½ — banca». */
  | { code: "tieSevenHalfBank"; params: HighlightBaseParams & { bankScore: number } }
  /** «Empat — banca». */
  | { code: "tieBank"; params: HighlightBaseParams & { bankScore: number } }
  /** «+{amount}»: guanya la mà; `amount` = net d'aquella mà (pagament − aposta, doble inclòs), sense unitat. */
  | { code: "win"; params: HighlightBaseParams & { amount: number; bankScore: number } }
  /** «+{amount} (banca passada)». */
  | { code: "winBankBust"; params: HighlightBaseParams & { amount: number; bankScore: number } }
  /** «7 i Mig natural — +{amount}»; `amount` és el net (2× l'aposta, més el jackpot). */
  | {
      code: "naturalWin";
      params: HighlightBaseParams & { amount: number; jackpot: number; bankBusted: boolean };
    }
  /** «×2 — +{amount}»: mà especial (Mort o 3 canviat) que guanya i cobra el doble. Sense unitat. */
  | {
      code: "specialWin";
      params: HighlightBaseParams & {
        special: "mort" | "threeSwap";
        amount: number;
        jackpot: number;
        bankScore: number;
        bankBusted: boolean;
        multiplier: 2;
      };
    };

export type HighlightCode = HighlightMessage["code"];

export type HighlightEntry = HighlightMessage & {
  /** Nom del jugador (compatibilitat). */
  name: string;
  /** Text català de reserva (clients antics). */
  text: string;
};

export type ResultMessage =
  /** Línia de la banca: «Banca». */
  | { code: "bank"; params: { player: string; seatId: string; chipDelta: number; score: number | null } }
  /** Jugador sense highlights ni canvi: «Sense canvi». */
  | { code: "noChange"; params: { player: string; seatId: string; chipDelta: number } }
  /** Jugador amb una o més mans liquidades: `detail` = textos dels highlights units amb « · ». */
  | {
      code: "hands";
      params: { player: string; seatId: string; chipDelta: number; hands: HighlightMessage[] };
    };

export type ResultCode = ResultMessage["code"];

/** Línia de resultat tal com la construeix el motor (amb `detail` català de reserva). */
export type ResultEntry = ResultMessage & {
  name: string;
  outcome: HandOutcome;
  chipDelta: number;
  detail: string;
  handPoints?: number;
};

/**
 * Import amb signe, sense unitat ni separadors de milers.
 * El client el tradueix (`engine.result.*`); `parseGameMessage` també accepta el text antic amb « CF».
 */
export function formatSignedAmount(amount: number): string {
  const n = Math.trunc(amount);
  return `${n < 0 ? "-" : "+"}${Math.abs(n)}`;
}

/**
 * Text de reserva d'un highlight. Els imports no porten unitat («+200», no «+200 CF»).
 * La forma és la que el client ja tradueix: `+{amount}`, `+{amount} (banca passada)`,
 * `7 i Mig natural — +{amount}`, `Mort ×2 — +{amount}` / `3 canviat ×2 — +{amount}`.
 */
export function highlightFallbackText(msg: HighlightMessage): string {
  switch (msg.code) {
    case "bust":
      return ENGINE_LABELS.bust;
    case "mortLoses":
      return ENGINE_LABELS.mortLoses;
    case "bankWins":
      return ENGINE_LABELS.bankWins;
    case "tieSevenHalfBank":
      return ENGINE_LABELS.tieSevenHalfBank;
    case "tieBank":
      return ENGINE_LABELS.tieBank;
    case "win":
      return formatSignedAmount(msg.params.amount);
    case "winBankBust":
      return `${formatSignedAmount(msg.params.amount)} (banca passada)`;
    case "naturalWin":
      return `7 i Mig natural — ${formatSignedAmount(msg.params.amount)}`;
    case "specialWin":
      return `${msg.params.special === "mort" ? "Mort" : "3 canviat"} ×2 — ${formatSignedAmount(msg.params.amount)}`;
  }
}

/** Text català de reserva d'una línia de resultat (`detail`). */
export function resultFallbackDetail(msg: ResultMessage): string {
  switch (msg.code) {
    case "bank":
      return ENGINE_LABELS.bank;
    case "noChange":
      return ENGINE_LABELS.noChange;
    case "hands":
      return msg.params.hands.map(highlightFallbackText).join(" · ") || ENGINE_LABELS.noChange;
  }
}

export function makeHighlight(msg: HighlightMessage): HighlightEntry {
  return { ...msg, name: msg.params.player, text: highlightFallbackText(msg) } as HighlightEntry;
}

/** Tots els codis (per a tests i per al document del contracte). */
export const HIGHLIGHT_CODES: readonly HighlightCode[] = [
  "bust",
  "mortLoses",
  "bankWins",
  "tieSevenHalfBank",
  "tieBank",
  "win",
  "winBankBust",
  "naturalWin",
  "specialWin",
];
export const RESULT_CODES: readonly ResultCode[] = ["bank", "noChange", "hands"];
