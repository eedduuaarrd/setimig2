import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { emptyRoomBase, settleGame, type GameHost, type Player, type Room } from "./gameEngine.ts";
import { scoreCards } from "./scoring.ts";
import type { Card } from "../src/gameTypes.ts";

const host: GameHost = {
  emitRoomUpdate() {},
  schedule: (fn) => setTimeout(fn, 0),
  clearTimeout() {},
};

function card(value: number): Card {
  const points = value >= 10 ? 0.5 : value;
  const suit = "hearts";
  return { suit, value, points };
}

function totalChips(room: Room): number {
  return room.players.reduce((sum, p) => sum + p.chips, 0) + room.pot + room.jackpot;
}

function makeHeadToHeadRoom(): Room {
  const room = emptyRoomBase("sim", "Sim", 100, 0);
  room.jackpot = 0;
  const banker: Player = {
    id: "bank",
    playerId: "bank",
    seatToken: "t-bank",
    name: "Banca",
    chips: 10_000,
    bet: 0,
    isBanker: true,
    status: "stood",
    handSlots: [
      {
        id: "b0",
        bet: 0,
        cards: [
          { id: "c1", card: card(7), faceUp: true },
          { id: "c2", card: card(10), faceUp: true },
        ],
        status: "stood",
        mort: false,
        blindPair: false,
        doubled: false,
        canDouble: false,
        blindUntilBankEnd: false,
        mortOffered: false,
      },
    ],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
  };
  const player: Player = {
    id: "p1",
    playerId: "p1",
    seatToken: "t-p1",
    name: "Jugador",
    chips: 10_000,
    bet: 100,
    isBanker: false,
    status: "stood",
    handSlots: [
      {
        id: "p0",
        bet: 100,
        cards: [
          { id: "c3", card: card(7), faceUp: true },
          { id: "c4", card: card(11), faceUp: true },
        ],
        status: "stood",
        mort: false,
        blindPair: false,
        doubled: false,
        canDouble: false,
        blindUntilBankEnd: false,
        mortOffered: false,
      },
    ],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
  };
  player.chips -= 100;
  room.pot = 100;
  room.players = [banker, player];
  room.phase = "playing";
  return room;
}

describe("fairnessSimulation", () => {
  it("bank wins tie at 7½ against player natural", () => {
    const room = makeHeadToHeadRoom();
    const before = totalChips(room);
    settleGame(host, room);
    const human = room.players.find((p) => !p.isBanker)!;
    const banker = room.players.find((p) => p.isBanker)!;
    assert.equal(scoreCards(human.handSlots[0].cards), 7.5);
    assert.ok(human.chips < 10_000);
    assert.ok(banker.chips > 10_000);
    assert.equal(totalChips(room), before);
  });

  it("many random settlements conserve chips", () => {
    for (let round = 0; round < 200; round += 1) {
      const room = makeHeadToHeadRoom();
      const before = totalChips(room);
      settleGame(host, room);
      assert.equal(totalChips(room), before);
    }
  });

  it("mort bust loses the bet without jackpot bonus", () => {
    const room = makeHeadToHeadRoom();
    const human = room.players.find((p) => !p.isBanker)!;
    human.handSlots[0].mort = true;
    human.handSlots[0].cards = [
      { id: "c5", card: card(7), faceUp: true },
      { id: "c6", card: card(2), faceUp: true },
    ];
    human.handSlots[0].status = "busted";
    const before = human.chips;
    settleGame(host, room);
    assert.equal(human.chips, before);
    assert.ok(room.jackpot === 0);
  });
});
