/**
 * Shared 7 i Mig game engine (server + local solo).
 */
import {
  DOUBLE_REJECT_CODE,
  ENGINE_LABELS,
  ENGINE_MESSAGES,
  engineMaxBetMessage,
  engineMinBetMessage,
  type DoubleRejectCode,
  type SplitBlockedCode,
} from "./gameMessages.ts";
import type { BotDifficulty } from "./ai/botDifficulty.ts";
import { DEFAULT_BOT_DIFFICULTY } from "./ai/botDifficulty.ts";
import { decideBotDouble, decideBotHitOrStand, decideBotMort, decideBotSplit, botProfileFor } from "./ai/botProfile.ts";
import { botBetWithMemory } from "./ai/botBet.ts";
import {
  bankerTargetScores,
  decideBetAmount,
  gatherSeenCards,
  maxRivalVisibleScore,
} from "./ai/strategy.ts";
import {
  bankChoiceTimeoutMs,
  bankerTimeoutMs,
  botSocketId,
  botStartingChips,
  defaultSettlementMs,
  humanBetTimeoutMs,
  humanTurnTimeoutMs,
  nextBotName,
  pickBotNameAvoiding,
  randomBotPaceMs,
  soloSettlementMs,
} from "../server/bots.ts";
import {
  BANK_DRAW_MS,
  BANK_OFFER_EXTRA_MS,
  BANK_OFFER_FLOOR_MS,
  BOT_TURN_WATCHDOG_MS,
  MORT_REVEAL_SUSPENSE_MS,
  MORT_SETTLEMENT_VISIBLE_MS,
  NEXT_HAND_START_MS,
  REVEAL_PER_SEAT_MS,
  SETTLEMENT_MIN_DISPLAY_MS,
  SETTLEMENT_VISIBLE_MS,
  actionHitHoldMs,
  actionStandHoldMs,
  bankerBotActionDelayMs,
  betsSettleMs,
  botBetGapMs,
  botFirstActionDelayMs,
  dealCardMs,
  isTestFastPacing,
  pacingContract,
  payoutChipsMs,
  settlementRevealWindowMs,
} from "./pacing.ts";
import {
  applyBankOfferDecision,
  botAcceptsBankOffer,
  buildPendingBankChoice,
  isSetIMigScore,
  pickBankOfferWinner,
  playerHasSetIMigHand,
} from "./bankRules.ts";
import { scoreCards } from "./scoring.ts";
import { cardKey, createSingleSpanishDeck } from "./spanishDeck.ts";
import { fisherYatesShuffle, fisherYatesShuffleSeeded } from "./shuffle.ts";
import { activePrivateDeckSeed, seededHandSeed } from "./testSeededDeck.ts";
import { computeSoloMatchResult } from "./matchRules.ts";
import {
  computePhaseBMatchResult,
  PHASE_B_HAND_COUNT,
  PHASE_B_START_CHIPS,
  phaseBMatchEnabled,
  recordPhaseBHandComplete,
  resetPlayersToPhaseBChips,
  totalTableChips,
  type PhaseBMatchState,
} from "./matchPhaseB.ts";
import {
  applyBankerToPlayer,
  bankerCanCoverWagerRange,
  maxBet,
  naturalBankPayout,
  mustRotateBankAfterHand,
  pickNextBankerInSeatOrder,
} from "./bankRotation.ts";
import { classifyOutcomeFromHighlight } from "../src/lib/handResults.ts";
import {
  makeHighlight,
  resultFallbackDetail,
  type HighlightEntry,
  type HighlightMessage,
  type ResultEntry,
  type ResultMessage,
} from "./messageCodes.ts";
import { privateShareUrl } from "../server/privateRooms.ts";
import { MAX_PRIVATE_TABLE_PLAYERS } from "./tableBetLimits.ts";
import {
  defaultHostMatchSettings,
  normalizeHostMatchSettings,
  turnTimeoutMsForRoom,
  type HostMatchSettings,
} from "./hostMatchSettings.ts";
import { FAST_TOURNAMENT_START_CHIPS, roomUsesIsolatedPlayChips } from "./fastTournament.ts";
import { risingBlindsToView } from "./risingBlinds.ts";
import { tickRisingBlindsOnRoom } from "./roomWagerConfig.ts";
import type {
  Card,
  HandResultLine,
  HandSlotView,
  PlayerView,
  RoomView,
  RoomPhase,
  LastRoundSummary,
  BankDrawEntry,
  SessionStats,
  MatchResult,
} from "../src/gameTypes.ts";
import {
  defaultAvatarConfig,
  toPlayerAvatarView,
  type PlayerAvatarConfig,
} from "./playerAvatar.ts";
import {
  settlementIdFor,
  toSettlementView,
  type SettlementChipsKind,
  type SettlementRecord,
} from "./settlementSummary.ts";
import {
  BANK_REVEAL_MS,
  DEAL_BUST_MS,
  DEAL_FLIGHT_FLIP_MS,
  DEAL_FLIGHT_MS,
  DEAL_STAGGER_MS,
  dealAnimMs,
  initialDealWindowMs,
  type DealKind,
  type DealRecord,
  type RoomViewExtended,
} from "./dealEvents.ts";

export interface GameHost {
  emitRoomUpdate(room: Room, viewerId: string): void;
  /** Full room broadcast (e.g. socket.io). When set, used instead of emitRoomUpdate. */
  publishRoom?(room: Room): void | Promise<void>;
  schedule(fn: () => void, ms: number): ReturnType<typeof setTimeout>;
  clearTimeout(id: ReturnType<typeof setTimeout> | null | undefined): void;
  persistHumanBalance?(playerId: string, chips: number): Promise<void>;
  /** Origen dels enllaços d'invitació; `viewerId` permet fer servir el domini del jugador que mira. */
  getPrivateTableOrigin?(viewerId?: string): string;
  onHandSettled?(room: Room): void | Promise<void>;
  onMatchFinished?(room: Room): void | Promise<void>;
}

export interface HandSlot {
  id: string;
  cards: { id: string; card: Card; faceUp: boolean }[];
  bet: number;
  doubled: boolean;
  canDouble: boolean;
  mort: boolean;
  blindPair: boolean;
  blindUntilBankEnd: boolean;
  mortOffered: boolean;
  /**
   * Normes de la casa: primera carta 3 o 4 pendent de «Jugar» o «Canviar» (applySwap).
   * Opcional: estats desats abans d'aquest canvi no el porten (= cap oferta pendent).
   */
  swapOffered?: 3 | 4 | null;
  /** La mà ha canviat el 4 (informatiu). */
  swappedFour?: boolean;
  status: "playing" | "stood" | "busted" | "pending";
  /** El temporitzador ha plantat aquesta mà (no és una passada). No es persisteix al saldo. */
  autoStood?: boolean;
  /**
   * La mà ha sortit d'un separar (l'origen i la nova). No viatja a la vista.
   * Una mà separada no es pot doblar: `canDouble` queda false.
   */
  fromSplit?: boolean;
  /**
   * El separar ve d'una mà que ja havia doblat (o d'una altra de la mateixa cadena).
   * No viatja a la vista. Distingeix `SPLIT_ALREADY_DOUBLED` de `SPLIT_CANNOT_DOUBLE`.
   */
  splitFromDoubled?: boolean;
}

/** Mà especial per a la revelació (App PWA): Mort o 3 canviat per 2 tapades. */
export type SpecialHandKind = "mort" | "threeSwap";
export function specialHandKind(slot: Pick<HandSlot, "mort" | "blindPair">): SpecialHandKind | null {
  if (slot.mort) return "mort";
  if (slot.blindPair) return "threeSwap";
  return null;
}

/** Hi ha una decisió de primera carta pendent (Mort, o jugar/canviar el 3 o el 4)? */
export function firstCardChoicePending(slot: Pick<HandSlot, "mortOffered" | "swapOffered">): boolean {
  return !!slot.mortOffered || !!slot.swapOffered;
}

export interface Player {
  id: string;
  playerId: string;
  seatToken: string;
  /** Per-seat secret used to authorize online solo resumes; absent on legacy seats. */
  soloResumeToken?: string;
  name: string;
  chips: number;
  bet: number;
  isBanker: boolean;
  isBot?: boolean;
  status: "waiting" | "betting" | "playing" | "stood" | "busted";
  handSlots: HandSlot[];
  activeSlotIndex: number;
  lastRoyal7Payout: number;
  royal7AsBankerStreak: number;
  refusedBankBefore?: boolean;
  pendingBankChoice?: { mandatory: boolean };
  pendingBankAfterRoyal?: boolean;
  /**
   * Human confirmed the current settlement (resolved their own bank offer, or «Següent»).
   * Until every connected human has confirmed, settlement is never cut short. Reset per hand.
   */
  settlementAck?: boolean;
  /** Monotonic action counter for private-table anti-replay (server-owned). */
  lastActionSeq?: number;
  /** Last visible action this hand (UI). */
  lastHandAction?: string;
  /** Last successful stake this session (for betting timeout default). */
  lastBetAmount?: number;
  disconnectedAt?: number;
  graceUntil?: number;
  /** Cosmetic avatar (server / persisted private seats). */
  avatar?: PlayerAvatarConfig;
}

export interface Room {
  id: string;
  name: string;
  isPrivate?: boolean;
  inviteCode?: string;
  hostSeatToken?: string;
  players: Player[];
  deck: Card[];
  pot: number;
  phase: RoomPhase;
  minBet: number;
  /** Optional creator-selected cap for private-table wagers. */
  tableMaxBet?: number;
  jackpot: number;
  lastRound: LastRoundSummary | null;
  centerDiscard: Card[];
  bankDraw?: { playerId: string; card: Card }[];
  turnPlayerIndex: number;
  soloAi?: boolean;
  autoFillBots?: boolean;
  botSlotSeq?: number;
  botTimer?: ReturnType<typeof setTimeout> | null;
  humanTimer?: ReturnType<typeof setTimeout> | null;
  sessionStats: Map<string, SessionStats>;
  soloHumanPlayerId?: string;
  soloBotCount?: number;
  soloBotPresets?: { name: string; playerId: string; chips: number }[];
  roundStartChips?: Map<string, number>;
  settlementEndTimer?: ReturnType<typeof setTimeout> | null;
  /** Vigilant del torn d'un bot (no es persisteix). */
  botWatchdogTimer?: ReturnType<typeof setTimeout> | null;
  /** Estat del torn de bot que vigila el watchdog (no es persisteix). */
  botTurnWatch?: { key: string; since: number } | null;
  /** When settlement phase began (ms); used for min display + early advance. */
  settlementStartedAt?: number;
  turnDeadlineAt?: number | null;
  /**
   * Punt de decisió de l'humà al qual pertany `turnDeadlineAt` (no es persisteix). Mentre no canviï,
   * una nova publicació (p. ex. després d'una acció rebutjada) no allarga el termini.
   */
  turnDeadlineKey?: string | null;
  /** Mort decision window end (ms); anchored so republish does not extend it. */
  mortDeadlineAt?: number | null;
  /**
   * Id de la carta d'oferta (7/3/4) que el propietari ja ha mirat.
   * Fins llavors el termini és el torn sencer; `card_peeked` el passa a `turnMs` des del peek.
   * No es publica a la vista.
   */
  offerClockCardId?: string | null;
  /** Betting phase deadline (ms); anchored so republish does not extend it. */
  bettingDeadlineAt?: number | null;
  /**
   * Avís de temps esgotat per seient (memòria de la sala, fins a la mà següent).
   * `minBet`: s'ha aplicat l'aposta mínima. `stand`: la mà s'ha plantat sola.
   */
  timeoutNotices?: { kind: "minBet" | "stand"; seatId: string }[];
  matchResult?: MatchResult | null;
  botDifficulty?: BotDifficulty;
  /** Partida estructurada fase B (10 mans / 2.000 CF). */
  phaseB?: PhaseBMatchState;
  /** Mans consecutives com a banca (rotació cada 3). */
  bankerConsecutiveHands?: number;
  /** Saldo real (fora de partida) per jugadors humans en solo IA. */
  soloRealBalances?: Map<string, number>;
  /** Compra d'entrada solo oberta (saldo real); només la toca server/soloBuyIn.ts. */
  soloBuyIn?: { id: string; playerId: string; amount: number; handsNet: number; hands: number };
  /** Compres d'entrada obertes de taula pública (saldo real), per playerId; només server/publicBuyIn.ts. */
  realBuyIns?: Record<string, { id: string; playerId: string; amount: number; handsNet: number; hands: number }>;
  /** Partida estructurada acabada (fase B); `phase` resta `waiting` per al client. */
  matchEnded?: boolean;
  /** Regles de la casa (doblar, mort, split, 3 i 4). Per defecte fals = mode Tradicional (R10). */
  houseRulesEnabled?: boolean;
  /** Sala de pràctica: sense apostes persistents ni temporitzadors humans. */
  practiceMode?: boolean;
  /** Perfil d'aposta triat en crear la sala (taula privada / torneig). */
  betProfileId?: string;
  /** Cegues que pugen (estat en curs). */
  risingBlinds?: import("./risingBlinds.ts").RisingBlindsState;
  risingBlindsOptions?: import("./risingBlinds.ts").RisingBlindsOptions;
  /** Torneig ràpid online: fitxes aïllades del saldo real. */
  fastTournament?: boolean;
  /** Ajustos d'amfitrió (entre partides). */
  hostMatchSettings?: import("./hostMatchSettings.ts").HostMatchSettings;
  /** Nivell de campanya IA (solo en línia). */
  campaignLevel?: number;
  /** Fitxes inicials del nivell de campanya (fase B). */
  campaignStartingChips?: number;
  /**
   * Llavor de la baralla, només sales privades de prova. No es publica a la vista.
   * S'ignora sense `SETIMIG_TEST_SEEDED_DECK=1` i sempre en producció.
   * Vegeu docs/baralla-de-prova.md.
   */
  testDeckSeed?: number;
  /** Jackpot al inici de la mà (per revertir en pràctica). */
  roundStartJackpot?: number;
  /** Mans liquidades en aquesta sala (per a `settlementId`). */
  handSeq?: number;
  /** Resum únic de la darrera liquidació (mateix cicle de vida que `lastRound`). */
  lastSettlement?: SettlementRecord | null;
  /**
   * Cert només mentre `settleGame` mou fitxes (síncron, no es persisteix): qualsevol
   * `publishRoom` intern s'ignora perquè no surti cap estat a mitja liquidació.
   */
  settlingInProgress?: boolean;
  /** Cartes repartides a la mà actual, en ordre (`card_dealt`). */
  dealLog?: DealRecord[];
  /** Darrer `dealSeq` de la mà actual. */
  dealSeq?: number;
  /** `handSeq` de la mà que s'està repartint (= el de la seva liquidació). */
  dealHandSeq?: number;
  /** Fi de l'animació de repartiment (ms epoch): el torn s'activa a partir d'aquí. */
  dealAnimUntil?: number | null;
  /**
   * Epoch en què es pot repartir, un cop tancades les apostes (`BETS_SETTLE_MS`).
   * Mentrestant la fase segueix sent «betting» i no hi ha cartes.
   */
  dealAfterBetsAt?: number | null;
  betsSettleTimer?: ReturnType<typeof setTimeout> | null;
  /** Fi de l'avís HIT/STAND (epoch). Absent si no hi ha pausa. */
  actionHoldEndsAt?: number | null;
  /** Què passa quan acaba l'avís: seguir el torn, passar-lo o liquidar. */
  actionHoldThen?: "continue" | "nextTurn" | "settle";
  actionHoldTimer?: ReturnType<typeof setTimeout> | null;
  /** Accions humanes arribades durant l'avís. S'apliquen en ordre en acabar la pausa. */
  queuedActions?: QueuedTableAction[];
  /** Fi del sorteig de banca (epoch). */
  bankDrawEndsAt?: number | null;
  /** Fi real de la liquidació (epoch), també si «Següent» l'escurça. */
  phaseEndsAt?: number | null;
}

/** Acció humana rebuda mentre dura l'avís HIT/STAND. No es rebutja: s'encua. */
export type QueuedTableAction =
  | { kind: "hit"; actorId: string }
  | { kind: "stand"; actorId: string }
  | { kind: "double"; actorId: string }
  | { kind: "split"; actorId: string };

/** R10: per defecte mode Tradicional sense regles de la casa. */
export function isHouseRulesEnabled(room: Room): boolean {
  return room.houseRulesEnabled === true;
}

export function resolvedHostMatchSettings(room: Room): HostMatchSettings {
  return room.hostMatchSettings ?? defaultHostMatchSettings();
}

export function applyHostMatchSettings(room: Room, raw: unknown): string | null {
  const normalized = normalizeHostMatchSettings(raw);
  if (!normalized) return ENGINE_MESSAGES.invalidSettings;
  room.hostMatchSettings = normalized;
  room.houseRulesEnabled = normalized.houseRulesEnabled;
  return null;
}

function configuredHandsTotal(room: Room): number {
  return resolvedHostMatchSettings(room).handsTotal;
}

function playerTurnTimeoutMs(room: Room): number {
  if (room.practiceMode) return humanTurnTimeoutMs();
  const base = turnTimeoutMsForRoom(room.hostMatchSettings);
  return isTestFastPacing() ? Math.min(base, humanTurnTimeoutMs()) : base;
}

/** Termini nou per a una oferta de 4 que acaba de sortir. En pràctica no n'hi ha. */
function refreshFirstCardDeadline(room: Room): void {
  if (room.practiceMode) {
    room.mortDeadlineAt = null;
    return;
  }
  room.mortDeadlineAt = Date.now() + dealAnimWaitMs(room) + playerTurnTimeoutMs(room);
}

function notifyMatchFinished(host: GameHost, room: Room): void {
  void host.onMatchFinished?.(room);
}

function botDifficultyFor(room: Room): BotDifficulty {
  return room.botDifficulty ?? DEFAULT_BOT_DIFFICULTY;
}

export async function publishRoom(host: GameHost, room: Room): Promise<void> {
  // A mitja liquidació no es publica res: `settleGame` fa una sola publicació al final.
  if (room.settlingInProgress) return;
  try {
    if (host.publishRoom) {
      await host.publishRoom(room);
    } else {
      const viewerId =
        room.players.find((p) => !p.isBot)?.id ??
        (room.soloHumanPlayerId
          ? room.players.find((p) => p.playerId === room.soloHumanPlayerId)?.id
          : undefined) ??
        room.players[0]?.id ??
        "";
      if (viewerId) host.emitRoomUpdate(room, viewerId);
    }
  } finally {
    // Even if the broadcast fails, the next bot/human timer must be scheduled.
    scheduleAfterRoomChange(host, room);
  }
}

function privateTableOrigin(host: GameHost, viewerId?: string): string {
  return host.getPrivateTableOrigin?.(viewerId) ?? "https://setimig.supercbb.com";
}

/** Mà en curs: la mateixa numeració que `settlement.handSeq` d'aquesta mà. */
function currentHandSeq(room: Room): number {
  return (room.handSeq ?? 0) + 1;
}

function beginDealLog(room: Room): void {
  room.dealHandSeq = currentHandSeq(room);
  room.dealSeq = 0;
  room.dealLog = [];
  room.dealAnimUntil = null;
}

/** Desa una carta repartida (o moguda en separar) amb el següent `dealSeq`, sense forats. */
function recordDeal(
  room: Room,
  player: Player,
  slot: HandSlot,
  tc: HandSlot["cards"][number],
  kind: DealKind,
  initialIndex: number | null = null
): DealRecord {
  if (room.dealHandSeq !== currentHandSeq(room) || !room.dealLog) beginDealLog(room);
  const dealSeq = (room.dealSeq ?? 0) + 1;
  room.dealSeq = dealSeq;
  const rec: DealRecord = {
    dealSeq,
    handSeq: room.dealHandSeq!,
    kind,
    playerId: player.playerId,
    slotIndex: Math.max(0, player.handSlots.indexOf(slot)),
    cardIndex: Math.max(0, slot.cards.indexOf(tc)),
    cardId: tc.id,
    isBanker: player.isBanker,
    initialIndex,
    delayMs: initialIndex == null ? 0 : initialIndex * dealCardMs(),
    at: Date.now(),
  };
  room.dealLog!.push(rec);
  return rec;
}

/** Allarga la finestra d'animació fins a `ms` des d'ara (mai l'escurça). */
function extendDealAnim(room: Room, ms: number): void {
  const until = Date.now() + dealAnimMs(ms);
  room.dealAnimUntil = Math.max(room.dealAnimUntil ?? 0, until);
}

/** ms que falten perquè el client acabi d'animar el que s'ha repartit. */
export function dealAnimWaitMs(room: Room): number {
  return Math.max(0, (room.dealAnimUntil ?? 0) - Date.now());
}

function cid(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
}

export function emptyRoomBase(id: string, name: string, minBet: number, jackpot: number): Room {
  return {
    id,
    name,
    players: [],
    deck: [],
    pot: 0,
    phase: "waiting",
    minBet,
    jackpot,
    lastRound: null,
    centerDiscard: [],
    turnPlayerIndex: 0,
    autoFillBots: true,
    botSlotSeq: 0,
    botTimer: null,
    humanTimer: null,
    sessionStats: new Map(),
  };
}

function shuffleRoomCards<T>(room: Room, items: readonly T[]): T[] {
  const seed = activePrivateDeckSeed(room);
  if (seed !== null) return fisherYatesShuffleSeeded(items, seededHandSeed(seed, room.handSeq ?? 0));
  return fisherYatesShuffle(items);
}

/**
 * A partir de la segona mà, la llavor de la sala obre una baralla nova
 * (llavor + número de mà). La primera mà no es toca: el sorteig de banca
 * ja ha barrejat amb la llavor tal qual.
 */
function installSeededHandShoe(room: Room): void {
  const seed = activePrivateDeckSeed(room);
  if (seed === null) return;
  const hand = room.handSeq ?? 0;
  if (hand <= 0) return;
  discardPlayedHandsToPile(room);
  room.centerDiscard = [];
  room.bankDraw = undefined;
  room.deck = fisherYatesShuffleSeeded(createSingleSpanishDeck(), seededHandSeed(seed, hand));
}

function createDeck(room: Room): Card[] {
  return shuffleRoomCards(room, createSingleSpanishDeck());
}

function reshuffleDeckFromDiscard(room: Room) {
  const combined = [...room.centerDiscard, ...room.deck];
  room.centerDiscard = [];
  room.deck = shuffleRoomCards(room, combined);
}

function discardBankDrawToPile(room: Room) {
  if (!room.bankDraw) return;
  for (const entry of room.bankDraw) {
    room.centerDiscard.push(entry.card);
  }
}

function discardPlayedHandsToPile(room: Room) {
  for (const p of room.players) {
    for (const slot of p.handSlots) {
      for (const c of slot.cards) {
        room.centerDiscard.push(c.card);
      }
    }
  }
  discardBankDrawToPile(room);
}

/** @internal tests */
export function drawCard(room: Room): Card | null {
  if (room.deck.length === 0 && room.centerDiscard.length > 0) {
    reshuffleDeckFromDiscard(room);
  }
  if (room.deck.length === 0) {
    if (room.centerDiscard.length === 0) {
      room.deck = rebuildDeckFromCardsNotInPlay(room);
    } else {
      return null;
    }
  }
  return room.deck.pop() ?? null;
}

/**
 * Deck and discard pile both empty: rebuild ONLY from the 40-card deck minus the cards still in
 * play (hands and bank draw), so no card can ever be duplicated. On a fresh room nothing is in
 * play and this is a full shuffled deck; if every card is in play it is empty and drawCard
 * returns null.
 */
function rebuildDeckFromCardsNotInPlay(room: Room): Card[] {
  const inPlay = new Map<string, number>();
  const mark = (c: Card | null | undefined) => {
    if (!c) return;
    const k = cardKey(c);
    inPlay.set(k, (inPlay.get(k) ?? 0) + 1);
  };
  for (const p of room.players) {
    for (const slot of p.handSlots ?? []) {
      for (const tc of slot.cards) mark(tc.card);
    }
  }
  for (const entry of room.bankDraw ?? []) mark(entry.card);
  const free: Card[] = [];
  for (const c of createSingleSpanishDeck()) {
    const k = cardKey(c);
    const n = inPlay.get(k) ?? 0;
    if (n > 0) {
      inPlay.set(k, n - 1);
      continue;
    }
    free.push(c);
  }
  return shuffleRoomCards(room, free);
}

function highCardRank(card: Card): number {
  if (card.value <= 7) return card.value;
  return 8 + (card.value - 10);
}

function suitRank(s: Card["suit"]): number {
  const o = { hearts: 4, diamonds: 3, clubs: 2, spades: 1 };
  return o[s];
}

function compareDraws(a: Card, b: Card): number {
  const ra = highCardRank(a);
  const rb = highCardRank(b);
  if (ra !== rb) return ra - rb;
  return suitRank(a.suit) - suitRank(b.suit);
}

/** Non-bankers in seat order starting right of the banker. */
export function nonBankersInPlayOrder(room: Room): Player[] {
  const players = room.players;
  if (players.length === 0) return [];
  const bankIdx = players.findIndex((p) => p.isBanker);
  if (bankIdx < 0) return players.filter((p) => !p.isBanker);
  const ordered: Player[] = [];
  for (let i = 1; i <= players.length; i += 1) {
    const p = players[(bankIdx + i) % players.length]!;
    if (!p.isBanker) ordered.push(p);
  }
  return ordered;
}

function nonBankers(room: Room): Player[] {
  return nonBankersInPlayOrder(room);
}

export function currentTurnPlayerId(room: Room): string | undefined {
  if (room.phase === "playing") return nonBankers(room)[room.turnPlayerIndex]?.id;
  if (room.phase === "banker") return room.players.find((p) => p.isBanker)?.id;
  return undefined;
}

function setPlayerHandAction(player: Player, label: string) {
  player.lastHandAction = label;
}

function standActionLabel(cards: { card: Card }[]): string {
  const sc = scoreCards(cards);
  if (sc > 7.5) return ENGINE_LABELS.bust;
  return `Es planta a ${formatVisibleScore(sc)}`;
}

function formatVisibleScore(score: number): string {
  return score === 7.5 ? "7½" : String(score).replace(".5", "½");
}

function getSlot(p: Player, i: number): HandSlot {
  if (!p.handSlots[i]) {
    p.handSlots[i] = {
      id: cid(),
      cards: [],
      bet: 0,
      doubled: false,
      canDouble: false,
      mort: false,
      blindPair: false,
      blindUntilBankEnd: false,
      mortOffered: false,
      status: "playing",
    };
  }
  return p.handSlots[i];
}

export function currentPlayer(room: Room): Player | undefined {
  const nb = nonBankers(room);
  return nb[room.turnPlayerIndex];
}

export function currentSlot(room: Room): HandSlot | undefined {
  const p = currentPlayer(room);
  if (!p) return undefined;
  return getSlot(p, p.activeSlotIndex);
}

export function humanPlayers(room: Room): Player[] {
  return room.players.filter((p) => !p.isBot);
}

export function nextBotSlot(room: Room): number {
  room.botSlotSeq = (room.botSlotSeq ?? 0) + 1;
  return room.botSlotSeq;
}

function phaseBStartingChips(room: Room): number {
  if (room.fastTournament) return FAST_TOURNAMENT_START_CHIPS;
  if (room.campaignStartingChips != null && Number.isFinite(room.campaignStartingChips)) {
    return Math.max(100, Math.floor(room.campaignStartingChips));
  }
  if (room.isPrivate && room.tableMaxBet != null) {
    const worstCaseBankCover = room.tableMaxBet * (MAX_PRIVATE_TABLE_PLAYERS - 1) * 2;
    return Math.max(PHASE_B_START_CHIPS, worstCaseBankCover);
  }
  return PHASE_B_START_CHIPS;
}

export function createBotPlayer(room: Room, name?: string): Player {
  const slot = nextBotSlot(room);
  return {
    id: botSocketId(room.id, slot),
    playerId: `bot-${room.id}-${slot}`,
    seatToken: `bot-${room.id}-${slot}`,
    name: name ?? nextBotName(),
    chips: phaseBMatchEnabled(room) ? phaseBStartingChips(room) : botStartingChips(room.minBet),
    bet: 0,
    isBanker: false,
    isBot: true,
    status: "waiting",
    handSlots: [],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
  };
}

export function ensureFillBots(room: Room, targetNonBankerHumans = 1): void {
  if (room.isPrivate || room.soloAi || room.autoFillBots === false) return;
  if (room.phase !== "waiting") return;
  const humans = humanPlayers(room);
  if (humans.length === 0) return;
  const total = room.players.length;
  if (total >= 7) return;
  if (total >= 2) return;
  room.players.push(createBotPlayer(room));
}

/**
 * Seient del jugador humà en una sala solo: el del socket connectat o, si s'ha desconnectat a
 * mitja mà, el que ara juga una IA amb el mateix `playerId` (`soloHumanPlayerId`). Aquest seient
 * NO és un bot de la sala: no compta per a `soloBotCount`, no entra als presets dels bots i
 * decideix el final de la partida (eliminació o última mà) encara que el jugador no hi sigui.
 */
export function isSoloHumanSeat(room: Room, player: Player): boolean {
  if (!player.isBot) return true;
  return !!room.soloAi && !!room.soloHumanPlayerId && player.playerId === room.soloHumanPlayerId;
}

export function soloHumanSeat(room: Room): Player | undefined {
  return room.players.find((p) => !p.isBot) ?? room.players.find((p) => isSoloHumanSeat(room, p));
}

/** Seients per calcular el resultat de la partida (el seient humà d'una sala solo compta com a humà). */
function matchResultSeats(room: Room) {
  return room.players.map((p, seatOrder) => ({
    id: p.id,
    name: p.name,
    chips: p.chips,
    isBot: room.soloAi ? !isSoloHumanSeat(room, p) : p.isBot,
    seatOrder,
  }));
}

export function ensureSoloBots(room: Room, botCount: number): void {
  const humans = room.players.filter((p) => isSoloHumanSeat(room, p));
  const capped = Math.min(6, Math.max(1, botCount));
  room.soloBotCount = capped;
  const existingBots = room.players.filter((p) => !isSoloHumanSeat(room, p));
  const bankerPlayerId = room.players.find((p) => p.isBanker)?.playerId;
  if (existingBots.length === capped && humans.length >= 1) {
    room.soloBotPresets = existingBots.map((p) => ({
      name: p.name,
      playerId: p.playerId,
      chips: p.chips,
    }));
    return;
  }
  const presets = room.soloBotPresets?.slice(0, capped);
  room.players = [...humans];
  const avoidNames = new Set(humans.map((h) => h.name.trim().toLowerCase()));
  for (let i = 0; i < capped; i++) {
    const preset = presets?.[i];
    let botName = preset?.name;
    if (botName && avoidNames.has(botName.trim().toLowerCase())) {
      botName = pickBotNameAvoiding(avoidNames);
    }
    if (preset) {
      const bot = createBotPlayer(room, botName ?? preset.name);
      bot.playerId = preset.playerId;
      // Un bot que ja és a la taula conserva les fitxes actuals (els presets poden ser d'una mà
      // anterior): refer la llista de bots mai no pot crear ni destruir fitxes.
      bot.chips = existingBots.find((b) => b.playerId === preset.playerId)?.chips ?? preset.chips;
      room.players.push(bot);
    } else {
      const bot = createBotPlayer(room, pickBotNameAvoiding(avoidNames));
      room.players.push(bot);
    }
    const added = room.players[room.players.length - 1]!;
    avoidNames.add(added.name.trim().toLowerCase());
  }
  if (bankerPlayerId) {
    const bankerSeat = room.players.find((p) => p.playerId === bankerPlayerId);
    if (bankerSeat) applyBankerToPlayer(room.players, bankerSeat.id);
  }
  room.soloBotPresets = room.players
    .filter((p) => !isSoloHumanSeat(room, p))
    .map((p) => ({ name: p.name, playerId: p.playerId, chips: p.chips }));
}

export function freshSessionStats(): SessionStats {
  return { handsPlayed: 0, netCf: 0, winStreak: 0, lastOutcome: null, handsWon: 0, bestHandWin: 0 };
}

function getSessionStats(room: Room, playerId: string): SessionStats {
  const existing = room.sessionStats.get(playerId);
  if (existing) return existing;
  const fresh = freshSessionStats();
  room.sessionStats.set(playerId, fresh);
  return fresh;
}

/**
 * Les estadístiques de sessió són de la partida: es reinicien en començar una partida solo
 * nova (també pràctica) i amb Revenja. Abans vivien a la sala solo (reutilitzada) i s'acumulaven.
 */
export function resetSessionStats(room: Room): void {
  room.sessionStats = new Map();
}

/** Vista de les estadístiques: mai més mans guanyades que jugades. */
function sessionStatsView(stats: SessionStats): SessionStats {
  const handsPlayed = Math.max(0, stats.handsPlayed);
  return { ...stats, handsPlayed, handsWon: Math.min(Math.max(0, stats.handsWon ?? 0), handsPlayed) };
}

export function clearRoomTimers(host: GameHost, room: Room) {
  if (room.botTimer) {
    host.clearTimeout(room.botTimer);
    room.botTimer = null;
  }
  if (room.humanTimer) {
    host.clearTimeout(room.humanTimer);
    room.humanTimer = null;
  }
  if (room.settlementEndTimer) {
    host.clearTimeout(room.settlementEndTimer);
    room.settlementEndTimer = null;
  }
  if (room.botWatchdogTimer) {
    host.clearTimeout(room.botWatchdogTimer);
    room.botWatchdogTimer = null;
  }
  if (room.betsSettleTimer) {
    host.clearTimeout(room.betsSettleTimer);
    room.betsSettleTimer = null;
  }
  if (room.actionHoldTimer) {
    host.clearTimeout(room.actionHoldTimer);
    room.actionHoldTimer = null;
  }
}

export function resolvePendingBankChoice(
  room: Room,
  player: Player,
  accept: boolean,
  host?: GameHost,
  opts: { timedOut?: boolean } = {}
) {
  if (!player.pendingBankChoice) return;
  // A human answering their own offer has seen the result; an engine timeout has not.
  if (!player.isBot && !opts.timedOut) player.settlementAck = true;
  const mandatory = player.pendingBankChoice.mandatory;
  const wasBanker = player.isBanker;
  applyBankOfferDecision(room.players, player.id, accept, mandatory);
  if (accept && !wasBanker && player.isBanker) {
    room.bankerConsecutiveHands = 0;
  }
  player.pendingBankChoice = undefined;
  player.pendingBankAfterRoyal = undefined;
  if (host) maybeFinishSettlementEarly(host, room);
}

/** Revelació (#339) i vigilant de bots: viuen a `shared/pacing.ts`. */
export {
  BOT_TURN_WATCHDOG_MS,
  MORT_REVEAL_SUSPENSE_MS,
  MORT_SETTLEMENT_VISIBLE_MS,
  REVEAL_PER_SEAT_MS,
  SETTLEMENT_VISIBLE_MS,
  settlementRevealWindowMs,
};

/** Mort acceptat (`applyMort`): el 7 es destapa i la mà porta `slot.mort`. */
function roomHasAcceptedMort(room: Room): boolean {
  return room.players.some((player) => player.handSlots.some((slot) => slot.mort));
}

/**
 * n: seients que participen a la mà i es revelen, banca inclosa.
 * Un seient compta si té almenys una carta. Qui seu sense cartes (no ha jugat la mà)
 * no es revela i no suma. Un split —diverses mans al mateix seient— compta un sol cop:
 * el client les ensenya juntes a la revelació en gran d'aquell seient.
 */
export function settlementRevealSeatCount(room: Room): number {
  let n = 0;
  for (const player of room.players) {
    if (player.handSlots.some((slot) => slot.cards.length > 0)) n += 1;
  }
  return n;
}

/** Seients amb resultat de la mà, sense la banca: tenen cartes i no són la banca. */
export function payoutSeatCount(room: Room): number {
  let n = 0;
  for (const player of room.players) {
    if (player.isBanker) continue;
    if (player.handSlots.some((slot) => slot.cards.length > 0)) n += 1;
  }
  return n;
}

/**
 * Finestra de liquidació (ms): revelació del #339, i després el viatge de fitxes del pagament.
 * Sense Mort: n×1,5 s + 3 s. Amb Mort: 5,2 s + (n−1)×1,5 s + 3 s.
 * Pagament: 400 + 900 × seients amb resultat (sense la banca) + 800.
 * Si un humà encara decideix l'oferta de banca, la revelació pren el màxim amb 6,4 s
 * i el pagament s'hi suma igual.
 * Amb `SETIMIG_TEST_FAST` els retards es col·lapsen, com la resta del ritme de joc.
 */
export function computeSettlementDelayMs(room: Room): number {
  const baseSettleMs = room.soloAi ? soloSettlementMs() : defaultSettlementMs();
  const humanPending = room.players.some((p) => p.pendingBankChoice && !p.isBot);
  const current = humanPending ? Math.max(baseSettleMs, bankChoiceTimeoutMs() + BANK_OFFER_EXTRA_MS) : baseSettleMs;
  if (isTestFastPacing()) return current;
  const revealMs = settlementRevealWindowMs(settlementRevealSeatCount(room), roomHasAcceptedMort(room));
  const decisionMs = humanPending ? Math.max(revealMs, BANK_OFFER_FLOOR_MS) : revealMs;
  return decisionMs + payoutChipsMs(payoutSeatCount(room));
}

function settlementMinDisplayEngineMs(): number {
  return isTestFastPacing() ? 0 : SETTLEMENT_MIN_DISPLAY_MS;
}

/** True while some connected human has not confirmed the current settlement. */
export function hasConnectedHumanWithoutSettlementAck(room: Room): boolean {
  return room.players.some((p) => !p.isBot && p.disconnectedAt == null && !p.settlementAck);
}

/**
 * Re-arm the settlement end once bank offers are resolved. Only cuts the window down to
 * SETTLEMENT_MIN_DISPLAY_MS when every connected human has confirmed; otherwise (e.g. a bot
 * resolved its own 7½ bank offer) the full settlement window is kept.
 */
export function maybeFinishSettlementEarly(host: GameHost, room: Room) {
  if (room.phase !== "settlement") return;
  if (room.players.some((p) => p.pendingBankChoice)) return;
  const started = room.settlementStartedAt ?? Date.now();
  const elapsed = Date.now() - started;
  const minMs = settlementMinDisplayEngineMs();
  const targetMs = hasConnectedHumanWithoutSettlementAck(room)
    ? Math.max(minMs, computeSettlementDelayMs(room))
    : minMs;
  const waitMs = Math.max(0, targetMs - elapsed);
  room.phaseEndsAt = Date.now() + waitMs;
  if (room.settlementEndTimer) host.clearTimeout(room.settlementEndTimer);
  room.settlementEndTimer = host.schedule(() => {
    room.settlementEndTimer = null;
    if (room.phase !== "settlement") return;
    finishSettlementToWaiting(host, room);
  }, waitMs);
}

/**
 * «Següent» al full de liquidació: marca la confirmació de l'humà. Quan tots els humans
 * connectats han confirmat, la liquidació s'acaba respectant SETTLEMENT_MIN_DISPLAY_MS.
 * Retorna un missatge d'error o null. Fora de settlement no fa res (clic tardà).
 */
export function acknowledgeSettlement(host: GameHost, room: Room, player: Player): string | null {
  if (player.isBot) return "Jugador no trobat a la taula.";
  if (room.phase !== "settlement") return null;
  player.settlementAck = true;
  if (!hasConnectedHumanWithoutSettlementAck(room)) maybeFinishSettlementEarly(host, room);
  return null;
}

function scheduleSettlementEnd(
  host: GameHost,
  room: Room,
  delayMs: number = computeSettlementDelayMs(room)
) {
  room.phaseEndsAt = Date.now() + delayMs;
  if (room.settlementEndTimer) host.clearTimeout(room.settlementEndTimer);
  room.settlementEndTimer = host.schedule(() => {
    room.settlementEndTimer = null;
    if (room.phase !== "settlement") return;
    for (const p of room.players) {
      if (p.pendingBankChoice) resolvePendingBankChoice(room, p, false, undefined, { timedOut: true });
    }
    finishSettlementToWaiting(host, room);
  }, delayMs);
}

function offerBankAfterSetIMig(room: Room) {
  const banker = room.players.find((p) => p.isBanker);
  const bslot = banker?.handSlots[0];
  const bankerScore = scoreCards(bslot?.cards.map((c) => ({ card: c.card })) ?? []);
  const bankerStatus = banker?.status ?? "stood";
  if (isSetIMigScore(bankerScore, bankerStatus)) return;

  const nb = nonBankers(room);
  const winner = pickBankOfferWinner(nb, (p) =>
    playerHasSetIMigHand(
      p.handSlots.map((slot) => ({
        bet: slot.bet,
        score: scoreCards(slot.cards),
        status: slot.status,
      }))
    )
  );
  if (!winner || winner.isBanker) return;
  winner.pendingBankChoice = buildPendingBankChoice(winner);
  winner.pendingBankAfterRoyal = true;
}

function opponentCountForBankOffer(room: Room): number {
  return Math.max(0, room.players.length - 1);
}

function bankCoversConfiguredRange(room: Room, banker: Player): boolean {
  const opponentChips = room.players.filter((p) => !p.isBanker).map((p) => p.chips);
  return bankerCanCoverWagerRange(banker.chips, room.minBet, opponentChips, room.tableMaxBet);
}

function prepareBankForNextHand(room: Room) {
  const banker = room.players.find((p) => p.isBanker);
  if (banker && mustRotateBankAfterHand(room.bankerConsecutiveHands ?? 0)) {
    const next = pickNextBankerInSeatOrder(room.players, room.minBet, banker.id, room.tableMaxBet);
    if (next) {
      applyBankerToPlayer(room.players, next.id);
      room.bankerConsecutiveHands = 0;
    }
  }
  const current = room.players.find((p) => p.isBanker);
  if (current && !bankCoversConfiguredRange(room, current)) {
    const next = pickNextBankerInSeatOrder(room.players, room.minBet, current.id, room.tableMaxBet);
    if (next) {
      applyBankerToPlayer(room.players, next.id);
      room.bankerConsecutiveHands = 0;
    }
  }
}

export function ensurePhaseBMatchInitialized(room: Room) {
  if (!phaseBMatchEnabled(room)) return;
  if (room.phaseB) return;
  const startingChips = phaseBStartingChips(room);
  resetPlayersToPhaseBChips(room.players, startingChips);
  if (room.soloAi) resetSessionStats(room);
  room.pot = 0;
  room.jackpot = 0;
  room.phaseB = {
    handsTotal: configuredHandsTotal(room),
    handsCompleted: 0,
    chipPool: totalTableChipsFromRoom(room),
    startingChips,
  };
  room.bankerConsecutiveHands = 0;
}

function totalTableChipsFromRoom(room: Room): number {
  return totalTableChips({
    players: room.players,
    pot: room.pot,
    jackpot: room.jackpot,
  });
}

export function applyPhaseBRevenge(room: Room) {
  if (!phaseBMatchEnabled(room)) return;
  room.matchResult = null;
  room.matchEnded = false;
  room.phase = "waiting";
  const startingChips = room.phaseB?.startingChips ?? phaseBStartingChips(room);
  resetPlayersToPhaseBChips(room.players, startingChips);
  if (room.soloAi) resetSessionStats(room);
  room.pot = 0;
  room.jackpot = 0;
  room.phaseB = {
    handsTotal: configuredHandsTotal(room),
    handsCompleted: 0,
    chipPool: totalTableChipsFromRoom(room),
    startingChips,
  };
  room.bankerConsecutiveHands = 0;
  room.lastRound = null;
  room.lastSettlement = null;
  room.players.forEach((p) => {
    p.isBanker = false;
    p.bet = 0;
    p.handSlots = [];
    p.status = "waiting";
    p.refusedBankBefore = false;
    p.pendingBankChoice = undefined;
  });
}

function scheduleBankChoiceResponses(host: GameHost, room: Room, elapsedMs = 0) {
  const pending = room.players.filter((p) => p.pendingBankChoice);
  if (pending.length === 0) return;
  const opponents = opponentCountForBankOffer(room);

  for (const bot of pending.filter((p) => p.isBot)) {
    room.botTimer = host.schedule(() => {
      if (room.phase !== "settlement" || !bot.pendingBankChoice) return;
      const accept = botAcceptsBankOffer(bot.chips, room.minBet, opponents);
      resolvePendingBankChoice(room, bot, accept, host);
      void publishRoom(host, room);
    }, Math.max(0, randomBotPaceMs() - elapsedMs));
  }

  const humans = pending.filter((p) => !p.isBot);
  if (humans.length > 0) {
    room.humanTimer = host.schedule(() => {
      if (room.phase !== "settlement") return;
      for (const p of humans) {
        if (p.pendingBankChoice) resolvePendingBankChoice(room, p, false, host, { timedOut: true });
      }
      void publishRoom(host, room);
    }, Math.max(0, bankChoiceTimeoutMs() - elapsedMs));
  }
}

/** Re-arm the timers omitted from a persisted room when resuming during settlement. */
export function resumeSettlementAfterRestore(host: GameHost, room: Room) {
  if (room.phase !== "settlement") return;

  const savedStart = room.settlementStartedAt;
  const roundStart = room.lastRound?.at;
  const startedAt = Number.isFinite(savedStart)
    ? savedStart!
    : Number.isFinite(roundStart)
      ? roundStart!
      : Date.now();
  room.settlementStartedAt = startedAt;
  const elapsedMs = Math.max(0, Date.now() - startedAt);

  scheduleBankChoiceResponses(host, room, elapsedMs);
  scheduleSettlementEnd(
    host,
    room,
    Math.max(0, computeSettlementDelayMs(room) - elapsedMs)
  );
}

/** @internal tests */
export function finishSettlementToWaiting(host: GameHost, room: Room) {
  room.phase = "waiting";
  settleRemainingPotToBanker(room);
  room.lastRound = null;
  room.lastSettlement = null;
  discardPlayedHandsToPile(room);
  room.bankDraw = undefined;
  room.turnDeadlineAt = null;
  room.players.forEach((p) => {
    p.status = "waiting";
    p.bet = 0;
    p.handSlots = [];
    p.activeSlotIndex = 0;
    p.pendingBankChoice = undefined;
    p.pendingBankAfterRoyal = undefined;
    p.settlementAck = undefined;
  });

  if (phaseBMatchEnabled(room) && room.phaseB && !room.fastTournament) {
    room.phaseB = recordPhaseBHandComplete(room.phaseB);
  }
  if (room.soloAi && room.phaseB) {
    // Invariant de fitxes: en una partida solo les fitxes només es mouen entre seients.
    const total = totalTableChipsFromRoom(room);
    if (total !== room.phaseB.chipPool) {
      console.error(`[fitxes] sala ${room.id}: total ${total} != inici de partida ${room.phaseB.chipPool}`);
    }
  }
  // Rotació cada 3 mans i relleu per cobertura: en TOTS els modes (regles-decisio 26/10).
  if (room.players.some((p) => p.isBanker)) {
    room.bankerConsecutiveHands = (room.bankerConsecutiveHands ?? 0) + 1;
  }
  prepareBankForNextHand(room);

  tickRisingBlindsOnRoom(room);

  if (room.soloAi) {
    ensureSoloBots(room, room.soloBotCount ?? 2);
    const human = room.soloAi ? soloHumanSeat(room) : room.players.find((p) => !p.isBot);
    if (human) {
      if (phaseBMatchEnabled(room) && room.phaseB && !room.fastTournament) {
        const match = computePhaseBMatchResult(
          matchResultSeats(room),
          room.minBet,
          human.id,
          room.phaseB
        );
        if (match) {
          room.matchResult = match;
          room.matchEnded = true;
          notifyMatchFinished(host, room);
          void publishRoom(host, room);
          return;
        }
      } else if (room.soloAi) {
        const match = computeSoloMatchResult(
          room.players.map((p) => ({ ...p, isBot: !isSoloHumanSeat(room, p) })),
          room.minBet,
          human.id
        );
        if (match) {
          room.matchResult = match;
          room.matchEnded = true;
          notifyMatchFinished(host, room);
          void publishRoom(host, room);
          return;
        }
      }
    }
    room.matchResult = null;
  } else {
    ensureFillBots(room);
    if (phaseBMatchEnabled(room) && room.phaseB) {
      const viewer = room.players.find((p) => !p.isBot) ?? room.players[0];
      const match = computePhaseBMatchResult(
        room.players.map((p, seatOrder) => ({
          id: p.id,
          name: p.name,
          chips: p.chips,
          isBot: p.isBot,
          seatOrder,
        })),
        room.minBet,
        viewer?.id ?? "",
        room.phaseB
      );
      if (match) {
        room.matchResult = match;
        room.matchEnded = true;
        notifyMatchFinished(host, room);
        void publishRoom(host, room);
        return;
      }
    }
    room.matchResult = null;
  }
  void publishRoom(host, room);
  // Una sala solo sense el seu jugador (ni connectat ni en mans de la IA) no juga sola: abans els
  // bots continuaven indefinidament a «Última mà» i un «Començar» posterior hi podia caure.
  const soloWithoutHuman = !!room.soloAi && !soloHumanSeat(room);
  const autoContinue =
    (room.soloAi || room.isPrivate) &&
    canStartGame(room) &&
    !room.matchResult &&
    !room.matchEnded &&
    !soloWithoutHuman;
  if (autoContinue) {
    host.schedule(() => beginGameStart(host, room), NEXT_HAND_START_MS);
  }
}

async function persistHumanBalances(host: GameHost, room: Room) {
  if (phaseBMatchEnabled(room) || roomUsesIsolatedPlayChips(room)) return;
  for (const p of room.players) {
    if (!p.isBot && p.playerId && !p.playerId.startsWith("bot-")) {
      await host.persistHumanBalance?.(p.playerId, p.chips);
    }
  }
}

export function strategyContextFor(room: Room, player: Player): import("./ai/strategy.ts").StrategyContext {
  const seen = gatherSeenCards({
    centerDiscard: room.centerDiscard,
    players: room.players,
    selfId: player.id,
    selfSlots: player.handSlots,
  });
  const slot = getSlot(player, player.activeSlotIndex);
  const hand = slot.cards.map((c) => c.card);
  return {
    seen,
    hand,
    minBet: room.minBet,
    chips: player.chips,
    bet: player.bet,
    rivalVisibleMax: maxRivalVisibleScore(room.players, player.id),
    bankerTargetScores: bankerTargetScores(room.players),
    isBanker: player.isBanker,
    mortOffered: isHouseRulesEnabled(room) && !!slot.mortOffered,
    // Mateixes validacions que applyDouble/applySplit (incloent-hi si la banca ho pot cobrir).
    canDouble: canDoubleNow(room, player),
    canSplit: canSplitNow(room, player),
    blindPair: !!slot.blindPair,
  };
}

function buildPlayerView(p: Player, viewerId: string, room: Room): PlayerView {
  const revealAll = room.phase === "settlement";
  const bankDone = room.phase === "banker" || room.phase === "settlement";
  /** Banker hand stays off the wire until the bank turn (all viewers, including the banker). */
  const hideBankerHand = p.isBanker && !bankDone && !revealAll;

  const slots: HandSlotView[] = p.handSlots.map((slot) => {
    const cards: HandSlotView["cards"] = slot.cards.map((tc) => {
      let show = true;
      if (hideBankerHand) show = false;
      else {
        if (viewerId !== p.id && !tc.faceUp && !revealAll) show = false;
        // 3 i Mort: tapats (també per al propietari) fins que acaba la banca, és a dir, fins a la liquidació.
        if (slot.blindUntilBankEnd && !revealAll && !tc.faceUp) show = false;
        if (slot.blindPair && !revealAll) show = false;
      }
      if (revealAll) show = true;
      return {
        id: tc.id,
        card: show ? tc.card : null,
        faceUp: hideBankerHand ? false : tc.faceUp,
      };
    });
    return {
      id: slot.id,
      bet: slot.bet,
      doubled: slot.doubled,
      cards,
      status: slot.status,
      mort: slot.mort,
      blindPair: slot.blindPair,
      blindUntilBankEnd: slot.blindUntilBankEnd,
      special: specialHandKind(slot),
    };
  });

  const pending: PlayerView["pendingChoices"] = {};
  if (p.id === viewerId && room.phase === "playing") {
    const slot = currentSlot(room);
    if (slot && p.id === currentPlayer(room)?.id && isHouseRulesEnabled(room)) {
      if (slot.mortOffered && slot.cards.length === 1 && slot.cards[0].card.value === 7) {
        pending.canMort = true;
        pending.offerCardId = slot.cards[0].id;
        if (room.mortDeadlineAt) pending.mortDeadline = room.mortDeadlineAt;
      } else if (slot.swapOffered && slot.cards.length === 1 && slot.cards[0].card.value === slot.swapOffered) {
        pending.swapOffer = slot.swapOffered;
        pending.offerCardId = slot.cards[0].id;
        if (room.mortDeadlineAt) pending.swapDeadline = room.mortDeadlineAt;
      } else {
        // Mateix predicat que l'acció: no s'ofereix «Separar»/«Doblar» si el servidor el rebutjaria
        // (p. ex. «La banca no pot cobrir el split.»).
        if (canDoubleNow(room, p)) pending.canDouble = true;
        if (canSplitNow(room, p)) pending.canSplit = true;
        else {
          // Dues figures, però un altre motiu ho bloqueja: el client pinta Separar desactivat.
          // canSplit no s'envia. Si es pot separar, splitBlocked tampoc.
          const blocked = splitBlockedForPair(room, p);
          if (blocked) pending.splitBlocked = blocked;
        }
      }
    }
  }

  const hasPending = Object.keys(pending).length > 0;

  const avatarConfig = p.avatar ?? defaultAvatarConfig(p.name, p.playerId);

  return {
    id: p.id,
    name: p.name,
    chips: p.chips,
    bet: p.bet,
    isBanker: p.isBanker,
    isBot: p.isBot,
    status: p.status,
    handSlots: slots,
    activeSlotIndex: p.activeSlotIndex,
    pendingChoices: hasPending ? pending : null,
    pendingBankChoice: p.pendingBankChoice ?? null,
    pendingBankAfterRoyal: !!p.pendingBankChoice,
    lastAction: p.lastHandAction ?? null,
    avatar: toPlayerAvatarView(avatarConfig),
    betting: seatBettingView(p, room),
  };
}

/**
 * Contracte d'aposta en viu (#340). Només durant `phase === "betting"`.
 * Qui ja ha apostat (fins i tot si s'ha quedat sense fitxes) va primer: si no,
 * un all-in semblaria exempt perquè `chips < minBet`.
 * Després de l'última aposta la fase segueix sent `betting`: els seients amb aposta
 * són `{ status: "placed", amount }` i no en queda cap `pending`.
 */
function seatBettingView(p: Player, room: Room): PlayerView["betting"] {
  if (room.phase !== "betting") return null;
  if (p.bet > 0) return { status: "placed", amount: p.bet };
  if (playerExemptFromBetting(room, p)) return null;
  return { status: "pending" };
}

function actionHoldEndsAtFor(room: Room): number | null {
  if (room.actionHoldEndsAt == null || room.actionHoldEndsAt <= Date.now()) return null;
  return room.actionHoldEndsAt;
}

/** Epoch en què acaba el pas que el client ha d'esperar. Durant un avís, és l'avís. */
function phaseEndsAtFor(room: Room): number | null {
  const hold = actionHoldEndsAtFor(room);
  if (hold != null) return hold;
  if (room.phase === "betting") {
    if (room.dealAfterBetsAt != null) return room.dealAfterBetsAt;
    return room.bettingDeadlineAt ?? null;
  }
  if (room.phase === "playing" || room.phase === "banker") return room.turnDeadlineAt ?? null;
  if (room.phase === "settlement") {
    if (room.phaseEndsAt != null) return room.phaseEndsAt;
    if (room.settlementStartedAt != null) return room.settlementStartedAt + computeSettlementDelayMs(room);
  }
  if (room.phase === "bank_draw") return room.bankDrawEndsAt ?? null;
  return null;
}

export function roomToView(room: Room, viewerId: string, host: GameHost): RoomViewExtended {
  const players = room.players.map((p) => buildPlayerView(p, viewerId, room));
  let bankDraw: BankDrawEntry[] | null = null;
  if (room.bankDraw && room.phase === "bank_draw") {
    bankDraw = room.bankDraw.map((e) => ({ playerId: e.playerId, card: e.card }));
  }
  const viewer = room.players.find((p) => p.id === viewerId);
  const rawSessionStats =
    viewer && !viewer.isBot ? getSessionStats(room, viewer.playerId) : room.soloHumanPlayerId
      ? getSessionStats(room, room.soloHumanPlayerId)
      : null;
  const sessionStats = rawSessionStats ? sessionStatsView(rawSessionStats) : null;
  const viewerSeat = viewer?.seatToken;
  let matchProgress: RoomView["matchProgress"] = null;
  if (room.phaseB) {
    const handsTotal = room.phaseB.handsTotal;
    const completed = room.phaseB.handsCompleted;
    const handNumber =
      room.matchResult && room.phase === "waiting"
        ? Math.min(handsTotal, completed)
        : Math.min(handsTotal, completed + 1);
    matchProgress = { handNumber, handsTotal, structuredMatch: true };
  }
  return {
    id: room.id,
    name: room.name,
    players,
    pot: room.pot,
    phase: room.phase,
    turnIndex: room.turnPlayerIndex,
    turnPlayerId: currentTurnPlayerId(room) ?? null,
    minBet: room.minBet,
    tableMaxBet: room.tableMaxBet,
    jackpot: room.jackpot,
    lastRound: room.lastRound,
    settlementStartedAt: room.phase === "settlement" ? room.settlementStartedAt : undefined,
    settlement: room.lastSettlement ? toSettlementView(room.lastSettlement, room.players) : null,
    deal: room.dealHandSeq
      ? { handSeq: room.dealHandSeq, lastDealSeq: room.dealSeq ?? 0, animUntil: room.dealAnimUntil ?? null }
      : null,
    centerDiscard: [...room.centerDiscard],
    bankDraw,
    soloAi: room.soloAi,
    sessionStats,
    serverNow: Date.now(),
    pacing: pacingContract(),
    phaseEndsAt: phaseEndsAtFor(room),
    actionHoldEndsAt: actionHoldEndsAtFor(room),
    turnWindowMs: room.practiceMode
      ? null
      : room.phase === "betting"
        ? humanBetTimeoutMs()
        : room.phase === "playing" || room.phase === "banker"
          ? playerTurnTimeoutMs(room)
          : null,
    timeoutNotice: room.timeoutNotices?.find((n) => n.seatId === viewerId) ?? null,
    turnDeadlineAt: room.turnDeadlineAt ?? null,
    // El termini de Mort/canvi revela un 7, 3 o 4. Només el veu el propietari de la mà.
    mortDeadline:
      room.phase === "playing" && currentPlayer(room)?.id === viewerId ? (room.mortDeadlineAt ?? null) : null,
    matchResult: room.matchResult ?? null,
    matchProgress,
    matchEnded: room.matchEnded ?? false,
    houseRulesEnabled: isHouseRulesEnabled(room),
    practiceMode: !!room.practiceMode,
    fastTournament: !!room.fastTournament,
    betProfileId: room.betProfileId,
    risingBlinds: risingBlindsToView(room.risingBlinds, room.risingBlindsOptions, room.minBet),
    hostMatchSettings: resolvedHostMatchSettings(room),
    isPrivate: room.isPrivate,
    inviteCode: room.inviteCode,
    isHost: isPrivateHost(room, viewer),
    shareUrl: room.isPrivate && room.inviteCode ? privateShareUrl(privateTableOrigin(host, viewerId), room.inviteCode) : undefined,
    viewerSeatToken: viewerSeat,
    soloResumeToken: room.soloAi && viewer && !viewer.isBot ? viewer.soloResumeToken : undefined,
  };
}

export function privateTableChips(room: Room): number {
  if (phaseBMatchEnabled(room)) return phaseBStartingChips(room);
  return botStartingChips(room.minBet);
}

export function isPrivateHost(room: Room, player: Player | undefined): boolean {
  return !!(room.isPrivate && player && room.hostSeatToken && player.seatToken === room.hostSeatToken);
}

export function fillPrivateBots(room: Room, maxTotal = MAX_PRIVATE_TABLE_PLAYERS): void {
  if (!room.isPrivate || room.phase !== "waiting") return;
  while (room.players.length < maxTotal) {
    room.players.push(createBotPlayer(room));
  }
}

export function clearSoloRoomState(host: GameHost, room: Room) {
  clearRoomTimers(host, room);
  if (room.players.some((p) => !isSoloHumanSeat(room, p))) {
    room.soloBotPresets = room.players
      .filter((p) => !isSoloHumanSeat(room, p))
      .map((p) => ({ name: p.name, playerId: p.playerId, chips: p.chips }));
  }
  room.players = [];
  room.phase = "waiting";
  room.pot = 0;
  room.deck = [];
  room.lastRound = null;
  room.lastSettlement = null;
  room.centerDiscard = [];
  room.bankDraw = undefined;
  room.turnPlayerIndex = 0;
  room.matchResult = null;
  room.turnDeadlineAt = null;
  room.phaseB = undefined;
  room.bankerConsecutiveHands = 0;
  room.soloRealBalances = undefined;
  room.matchEnded = false;
  room.campaignLevel = undefined;
  room.campaignStartingChips = undefined;
  resetSessionStats(room);
}

export function canStartGame(room: Room): boolean {
  return room.players.length >= 2;
}

function snapshotRoundChips(room: Room) {
  room.roundStartChips = new Map();
  room.roundStartJackpot = room.jackpot;
  for (const p of room.players) {
    const atHandStart = p.isBanker ? p.chips : p.chips + p.bet;
    room.roundStartChips.set(p.playerId, atHandStart);
  }
}

/**
 * Estadístiques de sessió (pantalla: mans jugades/guanyades, net, ratxa, millor mà).
 * Compten a totes les sales, també pràctica, torneig ràpid i fitxes aïllades: només viuen a la
 * memòria de la sala. El saldo real el continua escrivint `persistHumanBalances`, que se salta
 * aquestes sales.
 */
function updateSessionStatsFromRound(room: Room) {
  if (!room.roundStartChips) return;
  for (const p of room.players) {
    if (p.isBot) continue;
    const before = room.roundStartChips.get(p.playerId);
    if (before === undefined) continue;
    const delta = p.chips - before;
    const stats = getSessionStats(room, p.playerId);
    stats.handsPlayed += 1;
    stats.netCf += delta;
    if (delta > 0) {
      stats.winStreak += 1;
      stats.lastOutcome = "win";
      stats.handsWon = Math.min((stats.handsWon ?? 0) + 1, stats.handsPlayed);
      stats.bestHandWin = Math.max(stats.bestHandWin ?? 0, delta);
    } else if (delta < 0) {
      stats.winStreak = 0;
      stats.lastOutcome = "lose";
    } else {
      stats.lastOutcome = "push";
    }
  }
  room.roundStartChips = undefined;
}

function playerExemptFromBetting(room: Room, player: Player): boolean {
  if (player.isBanker) return true;
  if (player.chips < room.minBet) return true;
  if (maxBet(room, player.playerId) < room.minBet) return true;
  return false;
}

function bettingRoundComplete(room: Room): boolean {
  return room.players.every((p) => p.isBanker || p.bet > 0 || playerExemptFromBetting(room, p));
}

function ensureBankerCanCoverTable(room: Room): boolean {
  const banker = room.players.find((p) => p.isBanker);
  if (!banker) return true;
  if (bankCoversConfiguredRange(room, banker)) return true;
  const next = pickNextBankerInSeatOrder(room.players, room.minBet, banker.id, room.tableMaxBet);
  if (next) {
    applyBankerToPlayer(room.players, next.id);
    room.bankerConsecutiveHands = 0;
    return true;
  }
  return false;
}

function tryFinishPhaseBMatchFromTable(host: GameHost, room: Room, viewerId: string): boolean {
  if (!phaseBMatchEnabled(room) || !room.phaseB) return false;
  const match = computePhaseBMatchResult(
    matchResultSeats(room),
    room.minBet,
    viewerId,
    room.phaseB
  );
  if (!match) return false;
  room.matchResult = match;
  room.matchEnded = true;
  room.phase = "waiting";
  room.turnDeadlineAt = null;
  room.mortDeadlineAt = null;
  notifyMatchFinished(host, room);
  void publishRoom(host, room);
  return true;
}

/**
 * Regla del 3: la parella cega no es pot demanar, doblar ni separar.
 * Qui canvia el 3 queda plantat a l'acte (applySwap) i el torn passa endavant.
 */
export const BLIND_PAIR_LOCKED = ENGINE_MESSAGES.blindPairLocked;

/**
 * Validació estricta de l'import d'una aposta humana: fora de rang es rebutja
 * (abans s'ajustava en silenci). Retorna null si és vàlida o si l'error l'ha de donar applyPlaceBet.
 */
export function betRangeError(room: Room, player: Player, amount: unknown): string | null {
  if (room.phase !== "betting" || player.isBanker || player.bet > 0) return null;
  const bet = Number(amount);
  if (!Number.isFinite(bet) || bet <= 0) return ENGINE_MESSAGES.invalidBet;
  const allowedMax = maxBet(room, player.playerId);
  if (allowedMax < room.minBet) return null;
  if (Math.floor(bet) < room.minBet) return engineMinBetMessage(room.minBet);
  if (Math.floor(bet) > allowedMax) return engineMaxBetMessage(allowedMax);
  return null;
}

export function applyPlaceBet(room: Room, player: Player, amount: number, host?: GameHost): string | null {
  if (room.phase !== "betting") return ENGINE_MESSAGES.cannotBetNow;
  if (player.isBanker) return ENGINE_MESSAGES.bankDoesNotBet;
  if (player.bet > 0) return ENGINE_MESSAGES.alreadyBet;
  let bet = Math.floor(Number(amount));
  if (!Number.isFinite(bet) || bet <= 0) return ENGINE_MESSAGES.invalidBet;
  const allowedMax = maxBet(room, player.playerId);
  if (allowedMax < room.minBet) return ENGINE_MESSAGES.bankCannotCoverMin;
  bet = Math.min(Math.max(bet, room.minBet), allowedMax);
  player.bet = bet;
  player.lastBetAmount = bet;
  player.chips -= bet;
  player.status = "playing";
  room.pot += bet;
  startHandIfBettingComplete(room, host);
  return null;
}

function armBetsSettle(host: GameHost, room: Room): void {
  if (room.phase !== "betting" || room.dealAfterBetsAt == null) return;
  const wait = Math.max(0, room.dealAfterBetsAt - Date.now());
  room.phaseEndsAt = room.dealAfterBetsAt;
  if (room.betsSettleTimer) host.clearTimeout(room.betsSettleTimer);
  room.betsSettleTimer = host.schedule(() => {
    room.betsSettleTimer = null;
    if (room.phase !== "betting" || room.dealAfterBetsAt == null) return;
    room.dealAfterBetsAt = null;
    openInitialDeal(room);
    void publishRoom(host, room);
  }, wait);
}

/** Reparteix la mà. La fase ha de ser encara «betting». */
function openInitialDeal(room: Room): void {
  if (room.phase !== "betting") return;
  room.dealAfterBetsAt = null;
  room.phase = "playing";
  room.bettingDeadlineAt = null;
  room.turnPlayerIndex = 0;
  snapshotRoundChips(room);
  beginDealLog(room);
  nonBankers(room).forEach((p) => {
    p.handSlots = [];
    p.activeSlotIndex = 0;
    dealInitialForPlayer(room, p);
  });
  const banker = room.players.find((p) => p.isBanker);
  if (banker) {
    banker.handSlots = [
      {
        id: cid(),
        cards: [],
        bet: 0,
        doubled: false,
        canDouble: false,
        mort: false,
        blindPair: false,
        blindUntilBankEnd: false,
        mortOffered: false,
        status: "playing",
      },
    ];
    const bc = drawCard(room);
    if (bc) {
      // Tapada fins al torn de la banca (goToBankerTurn la destapa): ni la vista ni la IA dels bots
      // (gatherSeenCards / maxRivalVisibleScore compten només cartes faceUp) la poden veure abans.
      const tc = { id: cid(), card: bc, faceUp: false };
      banker.handSlots[0].cards.push(tc);
      // La banca és l'última i va tapada per a tothom fins al seu torn (repart-v2 §4).
      recordDeal(room, banker, banker.handSlots[0], tc, "initial", room.dealLog?.length ?? 0);
    }
  }
  // El primer torn espera cartes × DEAL_CARD_MS (el vol de cada carta hi cap).
  const initial = (room.dealLog ?? []).filter((d) => d.kind === "initial");
  const window = initialDealWindowMs(initial.map((d) => ({ initialIndex: d.initialIndex ?? 0 })));
  room.dealAnimUntil = null;
  extendDealAnim(room, window);
}

/**
 * Quan tothom ha apostat (o n'està exempt), espera `BETS_SETTLE_MS` i després reparteix.
 * Sense host (proves del motor que no publiquen) o amb el mode ràpid, reparteix a l'instant.
 */
function startHandIfBettingComplete(room: Room, host?: GameHost): void {
  if (room.phase !== "betting") return;
  if (room.dealAfterBetsAt != null) return;
  const allBet = bettingRoundComplete(room);
  if (allBet) {
    const anyPlayerBet = room.players.some((p) => !p.isBanker && p.bet > 0);
    if (!anyPlayerBet) {
      room.phase = "waiting";
      room.players.forEach((p) => {
        p.status = "waiting";
        p.bet = 0;
      });
      return;
    }
    const wait = betsSettleMs();
    if (wait <= 0 || !host) {
      openInitialDeal(room);
      return;
    }
    room.dealAfterBetsAt = Date.now() + wait;
    room.phaseEndsAt = room.dealAfterBetsAt;
    room.bettingDeadlineAt = null;
    armBetsSettle(host, room);
    // Vista de tancament abans del repartiment: phase betting, phaseEndsAt i betting placed|null.
    // El temporitzador de BETS_SETTLE_MS és el que publica després la vista de cartes.
    void publishRoom(host, room);
  }
}

function stakeInPot(player: Player): number {
  if (player.handSlots.length > 0) return player.handSlots.reduce((sum, slot) => sum + Math.max(0, slot.bet), 0);
  return Math.max(0, player.bet);
}

function discardPlayerCards(room: Room, player: Player): void {
  for (const slot of player.handSlots) {
    for (const c of slot.cards) room.centerDiscard.push(c.card);
  }
  player.handSlots = [];
}

/**
 * Sortida confirmada d'un seient (taula privada) amb la mà en curs: el seient s'allibera
 * a l'instant i la mà continua de manera consistent per a la resta.
 * - Fora de mà («waiting»/«settlement»): només es treu el jugador.
 * - Repartiment de banca («bank_draw»): es treu la seva carta; si l'havia guanyat, la banca
 *   passa al següent en ordre de seient (pickNextBankerInSeatOrder).
 * - Apostes: se li torna l'aposta (encara no hi ha cartes) i, si ja hi havia tothom, es reparteix.
 * - Jugador amb cartes («playing»/«banker»): abandona; l'aposta va a la banca com una mà perduda.
 *   Si era el seu torn, el torn passa al següent; si era l'últim, juga la banca.
 * - Banca amb la mà en curs: mà anul·lada, cada aposta torna al seu jugador, la banca passa
 *   al següent en ordre de seient i comença una mà nova.
 * No publica: el cridador ha de fer publishRoom/commitRoom. Torna el jugador tret, o null si no hi era.
 */
export function removePlayerFromHand(host: GameHost, room: Room, playerId: string): Player | null {
  const idx = room.players.findIndex((p) => p.id === playerId);
  if (idx === -1) return null;
  const leaving = room.players[idx]!;
  const phase = room.phase;

  if (phase === "waiting" || phase === "settlement") {
    room.players.splice(idx, 1);
    return leaving;
  }

  if (phase === "bank_draw") {
    if (room.bankDraw) {
      room.bankDraw = room.bankDraw.filter((d) => {
        if (d.playerId !== leaving.id) return true;
        room.centerDiscard.push(d.card);
        return false;
      });
    }
    if (leaving.isBanker) {
      const next = room.players.find((p) => p.id !== leaving.id);
      if (next) applyBankerToPlayer(room.players, next.id);
    }
    room.players.splice(idx, 1);
    return leaving;
  }

  if (leaving.isBanker) {
    clearRoomTimers(host, room);
    for (const p of room.players) {
      if (p === leaving) continue;
      const refund = Math.min(stakeInPot(p), room.pot);
      p.chips += refund;
      room.pot -= refund;
    }
    discardPlayedHandsToPile(room);
    // Ordre de seient a partir del de la banca que surt; amb les fitxes ja retornades.
    const rest = [...room.players.slice(idx + 1), ...room.players.slice(0, idx)];
    rest.forEach((p) => (p.isBanker = false));
    const next = pickNextBankerInSeatOrder(rest, room.minBet, undefined, room.tableMaxBet);
    room.players.splice(idx, 1);
    // Si ningú no pot cobrir la taula, no hi ha banca i la mà següent la sorteja (beginGameStart).
    if (next) applyBankerToPlayer(room.players, next.id);
    room.bankerConsecutiveHands = 0;
    room.phase = "waiting";
    room.lastRound = null;
    room.bankDraw = undefined;
    room.turnPlayerIndex = 0;
    room.turnDeadlineAt = null;
    room.mortDeadlineAt = null;
    room.bettingDeadlineAt = null;
    room.players.forEach((p) => {
      p.status = "waiting";
      p.bet = 0;
      p.handSlots = [];
      p.activeSlotIndex = 0;
      p.pendingBankChoice = undefined;
      p.pendingBankAfterRoyal = undefined;
      p.settlementAck = undefined;
    });
    if (canStartGame(room) && !room.matchEnded && !room.matchResult) {
      host.schedule(() => {
        // Ningú humà a la taula (o ja ha començat una altra mà): no es reprèn res.
        if (room.phase !== "waiting" || !room.players.some((p) => !p.isBot)) return;
        beginGameStart(host, room);
      }, NEXT_HAND_START_MS);
    }
    return leaving;
  }

  const stake = stakeInPot(leaving);
  const banker = room.players.find((p) => p.isBanker);
  if (phase === "betting" || !banker) {
    const refund = Math.min(stake, room.pot);
    leaving.chips += refund;
    room.pot -= refund;
  } else {
    const lost = Math.min(stake, room.pot);
    banker.chips += lost;
    room.pot -= lost;
  }

  let turnWasTheirs = false;
  if (phase === "playing") {
    const pos = nonBankers(room).indexOf(leaving);
    turnWasTheirs = pos >= 0 && pos === room.turnPlayerIndex;
    if (pos >= 0 && pos < room.turnPlayerIndex) room.turnPlayerIndex -= 1;
  }
  discardPlayerCards(room, leaving);
  leaving.bet = 0;
  room.players.splice(idx, 1);

    if (phase === "betting") {
    startHandIfBettingComplete(room, host);
  } else if (phase === "playing") {
    if (turnWasTheirs) {
      const cur = currentPlayer(room);
      if (cur) cur.activeSlotIndex = 0;
    }
    if (room.turnPlayerIndex >= nonBankers(room).length) {
      goToBankerTurn(host, room);
    }
  } else if (phase === "banker" && nonBankers(room).every((p) => stakeInPot(p) === 0)) {
    settleGame(host, room);
  }
  // El cridador publica (publishRoom torna a armar temporitzadors i vigilant del torn).
  return leaving;
}

function actionHoldRemainingMs(room: Room): number {
  if (room.actionHoldEndsAt == null) return 0;
  return Math.max(0, room.actionHoldEndsAt - Date.now());
}

/**
 * Durant l'avís, una acció de qui té el torn no es rebutja.
 * Si el torn encara continua, s'encua. Si la mà ja s'ha tancat (planta o passa), s'ignora.
 */
function queueIfHolding(room: Room, action: QueuedTableAction): boolean {
  if (actionHoldRemainingMs(room) <= 0) return false;
  if (currentTurnPlayerId(room) !== action.actorId) return false;
  if (room.actionHoldThen === "continue") {
    const queued = room.queuedActions ?? [];
    if (queued.length < 8) room.queuedActions = [...queued, action];
  }
  return true;
}

function applyQueuedAction(host: GameHost, room: Room, action: QueuedTableAction): void {
  if (action.kind === "hit") applyHit(host, room, action.actorId);
  else if (action.kind === "stand") applyStand(host, room, action.actorId);
  else if (action.kind === "double") applyDouble(host, room, action.actorId);
  else applySplit(room, action.actorId);
}

function finishActionHold(host: GameHost, room: Room): void {
  room.actionHoldTimer = null;
  if (room.phase !== "playing" && room.phase !== "banker") {
    room.actionHoldEndsAt = null;
    room.actionHoldThen = undefined;
    room.queuedActions = undefined;
    return;
  }
  const then = room.actionHoldThen ?? "continue";
  room.actionHoldEndsAt = null;
  room.actionHoldThen = undefined;
  const queued = room.queuedActions?.shift();
  if (room.queuedActions && room.queuedActions.length === 0) room.queuedActions = undefined;
  if (queued) {
    applyQueuedAction(host, room, queued);
    void publishRoom(host, room);
    return;
  }
  if (then === "nextTurn") {
    nextTurn(host, room);
    return;
  }
  if (then === "settle") {
    settleGame(host, room);
    return;
  }
  // La pausa JA és l'espera: el bot següent actua en acabar-la, sense sumar-hi la pensada.
  const actor =
    room.phase === "banker" ? room.players.find((p) => p.isBanker) : currentPlayer(room);
  if (actor?.isBot && (room.phase === "playing" || room.phase === "banker")) {
    runBotAction(host, room, actor);
    return;
  }
  void publishRoom(host, room);
}

function armActionHold(host: GameHost, room: Room): void {
  const wait = actionHoldRemainingMs(room);
  if (wait <= 0) return;
  if (room.actionHoldTimer) host.clearTimeout(room.actionHoldTimer);
  room.actionHoldTimer = host.schedule(() => finishActionHold(host, room), wait);
}

/** Després d'un hit o un stand: la carta o la planta ja es veuen; el torn no avança fins que acaba l'avís. */
function beginActionHold(
  host: GameHost,
  room: Room,
  kind: "hit" | "stand",
  then: "continue" | "nextTurn" | "settle"
): void {
  const ms = kind === "hit" ? actionHitHoldMs() : actionStandHoldMs();
  if (ms <= 0) {
    if (then === "nextTurn") nextTurn(host, room);
    else if (then === "settle") settleGame(host, room);
    return;
  }
  room.actionHoldEndsAt = Date.now() + ms;
  room.actionHoldThen = then;
  room.phaseEndsAt = room.actionHoldEndsAt;
  armActionHold(host, room);
}

export function applyHit(host: GameHost, room: Room, actorId: string): string | null {
  if (queueIfHolding(room, { kind: "hit", actorId })) return null;
  const banker = room.players.find((p) => p.isBanker);
  if (room.phase === "banker") {
    if (!banker || banker.id !== actorId) return ENGINE_MESSAGES.bankTurn;
    const bslot = banker.handSlots[0];
    const c = drawCard(room);
    if (!c) return null;
    const btc = { id: cid(), card: c, faceUp: true };
    bslot.cards.push(btc);
    recordDeal(room, banker, bslot, btc, "hit");
    extendDealAnim(room, scoreCards(bslot.cards) > 7.5 ? DEAL_BUST_MS : DEAL_FLIGHT_FLIP_MS);
    if (scoreCards(bslot.cards) > 7.5) {
      setPlayerHandAction(banker, ENGINE_LABELS.bust);
      banker.status = "busted";
      beginActionHold(host, room, "hit", "settle");
    } else {
      setPlayerHandAction(banker, "Carta");
      beginActionHold(host, room, "hit", "continue");
    }
    return null;
  }
  if (room.phase !== "playing") return ENGINE_MESSAGES.wrongPhase;
  const player = currentPlayer(room);
  if (!player || player.id !== actorId || player.isBanker) return ENGINE_MESSAGES.notYourTurn;
  const slot = currentSlot(room);
  if (!slot) return null;
  if (slot.blindPair) return BLIND_PAIR_LOCKED;
  if (slot.mortOffered) return ENGINE_MESSAGES.decideMortFirst;
  if (slot.swapOffered) return ENGINE_MESSAGES.decideSwapFirst;
  const face = nextCardFaceUp(slot);
  const c = drawCard(room);
  if (!c) return null;
  const tc = { id: cid(), card: c, faceUp: face };
  slot.cards.push(tc);
  recordDeal(room, player, slot, tc, "hit");
  // Dins el torn: vol + gir (360 ms); si es passa, + sacsejada (600 ms, el màxim del doc).
  extendDealAnim(room, scoreCards(slot.cards) > 7.5 ? DEAL_BUST_MS : DEAL_FLIGHT_FLIP_MS);
  if (scoreCards(slot.cards) > 7.5) {
    setPlayerHandAction(player, ENGINE_LABELS.bust);
    slot.status = "busted";
    revealBustedSlot(slot);
    beginActionHold(host, room, "hit", "nextTurn");
  } else {
    setPlayerHandAction(player, "Carta");
    beginActionHold(host, room, "hit", "continue");
  }
  return null;
}

export function applyStand(host: GameHost, room: Room, actorId: string): string | null {
  if (queueIfHolding(room, { kind: "stand", actorId })) return null;
  const banker = room.players.find((p) => p.isBanker);
  if (room.phase === "banker") {
    if (!banker || banker.id !== actorId) return ENGINE_MESSAGES.bankTurn;
    const bslot = banker.handSlots[0];
    if (bslot) setPlayerHandAction(banker, standActionLabel(bslot.cards));
    banker.status = "stood";
    beginActionHold(host, room, "stand", "settle");
    return null;
  }
  if (room.phase !== "playing") return ENGINE_MESSAGES.notYourTurn;
  const player = currentPlayer(room);
  if (!player || player.id !== actorId) return ENGINE_MESSAGES.notYourTurn;
  const slot = currentSlot(room);
  if (!slot) return null;
  if (slot.mortOffered) return ENGINE_MESSAGES.decideMortFirst;
  if (slot.swapOffered) return ENGINE_MESSAGES.decideSwapFirst;
  setPlayerHandAction(player, standActionLabel(slot.cards));
  slot.status = "stood";
  beginActionHold(host, room, "stand", "nextTurn");
  return null;
}

export function applyMort(host: GameHost, room: Room, actorId: string, accept: boolean): string | null {
  const player = currentPlayer(room);
  const slot = currentSlot(room);
  if (!room || !player || !slot || room.phase !== "playing" || player.id !== actorId) {
    return ENGINE_MESSAGES.invalidAction;
  }
  if (!isHouseRulesEnabled(room)) return ENGINE_MESSAGES.mortUnavailable;
  if (!slot.mortOffered || slot.cards[0]?.card.value !== 7) return ENGINE_MESSAGES.mortUnavailable;
  if (!accept) {
    slot.mortOffered = false;
    slot.canDouble = true;
    room.mortDeadlineAt = null;
    room.offerClockCardId = null;
    return null;
  }
  slot.mortOffered = false;
  room.mortDeadlineAt = null;
  room.offerClockCardId = null;
  slot.mort = true;
  // El 7 acceptat es destapa per a tothom (roomToView). La carta del Mort segueix tapada.
  slot.cards[0].faceUp = true;
  setPlayerHandAction(player, "Mort");
  const c = drawCard(room);
  if (c) {
    const tc = { id: cid(), card: c, faceUp: false };
    slot.cards.push(tc);
    recordDeal(room, player, slot, tc, "mort");
    extendDealAnim(room, DEAL_FLIGHT_MS);
  }
  slot.blindUntilBankEnd = true;
  slot.canDouble = false;
  slot.status = "stood";
  nextTurn(host, room);
  return null;
}

/**
 * Normes de la casa: primera carta 3 o 4 → «Jugar» (swap=false, es queda la carta) o «Canviar» (swap=true).
 * - 4 canviat: es descarta i rep 1 carta tapada que ell sí que veu.
 *   La carta nova es tracta com una primera carta.
 *   Si és un altre 4, es torna a oferir el canvi (termini nou), tantes vegades com surti un 4.
 *   Si és un 7, s'ofereix el Mort. Si és un 3, s'aplica la regla del 3 (jugar o canviar).
 *   Amb una figura es pot doblar; amb dues figures o dues del mateix valor, separar.
 *   Sense cartes al munt, la cadena s'acaba i es queda el 4.
 * - 3 canviat: es descarta i rep 2 tapades que no veu ningú fins a la liquidació. El servidor el planta
 *   i el torn s'acaba (següent jugador o banca): després, demanar, plantar-se, doblar o separar es
 *   rebutgen. Si guanya cobra el doble; si perd, l'aposta normal.
 */
export function applySwap(host: GameHost, room: Room, actorId: string, swap: boolean): string | null {
  const player = currentPlayer(room);
  const slot = currentSlot(room);
  if (!room || !player || !slot || room.phase !== "playing" || player.id !== actorId) {
    return ENGINE_MESSAGES.invalidAction;
  }
  if (!isHouseRulesEnabled(room)) return ENGINE_MESSAGES.swapUnavailable;
  const offered = slot.swapOffered;
  if (!offered || slot.cards.length !== 1 || slot.cards[0]?.card.value !== offered) {
    return ENGINE_MESSAGES.swapUnavailable;
  }
  slot.swapOffered = null;
  room.mortDeadlineAt = null;
  room.offerClockCardId = null;
  if (!swap) {
    slot.canDouble = true;
    return null;
  }
  // Cadena de 4: sense cartes al munt no es remena el descart (si no, un bot que sempre
  // canvia el 4 no acabaria). El jugador es queda aquest 4 i juga normal.
  if (offered === 4 && room.deck.length === 0) {
    slot.canDouble = true;
    return null;
  }
  const old = slot.cards.pop()!;
  room.centerDiscard.push(old.card);
  if (offered === 4) {
    const c = drawCard(room);
    if (!c) {
      slot.cards.push(old);
      const discarded = room.centerDiscard.lastIndexOf(old.card);
      if (discarded >= 0) room.centerDiscard.splice(discarded, 1);
      slot.canDouble = true;
      return null;
    }
    const tc = { id: cid(), card: c, faceUp: false };
    slot.cards.push(tc);
    recordDeal(room, player, slot, tc, "swap");
    extendDealAnim(room, DEAL_FLIGHT_MS);
    slot.swappedFour = true;
    // La carta nova és una mà inicial: es pot doblar amb una sola carta, i les ofertes
    // del 7, del 3 i d'un altre 4 tornen a bloquejar la resta (DECIDE_MORT_FIRST / DECIDE_SWAP_FIRST).
    slot.canDouble = true;
    slot.fromSplit = false;
    slot.splitFromDoubled = false;
    if (c.value === 7) {
      slot.mortOffered = true;
      refreshFirstCardDeadline(room);
    } else if (c.value === 3 || c.value === 4) {
      slot.swapOffered = c.value;
      refreshFirstCardDeadline(room);
    }
    setPlayerHandAction(player, "Canvia");
    return null;
  }
  const d1 = drawCard(room);
  const d2 = drawCard(room);
  for (const d of [d1, d2]) {
    if (!d) continue;
    const tc = { id: cid(), card: d, faceUp: false };
    slot.cards.push(tc);
    recordDeal(room, player, slot, tc, "swap");
  }
  extendDealAnim(room, DEAL_FLIGHT_MS);
  slot.blindPair = true;
  slot.blindUntilBankEnd = true;
  slot.canDouble = false;
  setPlayerHandAction(player, "Canvia");
  // Canviar el 3 acaba el torn: el servidor planta i passa al següent (o a la banca).
  slot.status = "stood";
  nextTurn(host, room);
  return null;
}

/**
 * El propietari ha mirat la carta de l'oferta (7, 3 o 4). Arrenca el termini de decisió
 * (`turnMs` des d'ara). Un segon peek de la mateixa carta no el mou. En pràctica no hi ha termini.
 * Retorna false si s'ignora (no és el seu torn, no és la carta de l'oferta, o és un duplicat).
 */
export function applyCardPeeked(room: Room, actorId: string, cardId: string): boolean {
  if (room.phase !== "playing" || !isHouseRulesEnabled(room)) return false;
  const player = currentPlayer(room);
  const slot = currentSlot(room);
  if (!player || !slot || player.id !== actorId) return false;
  if (typeof cardId !== "string" || !cardId) return false;
  const top = slot.cards[0];
  if (!top || top.id !== cardId || slot.cards.length !== 1) return false;
  const mort = !!slot.mortOffered && top.card.value === 7;
  const swap = !!slot.swapOffered && top.card.value === slot.swapOffered;
  if (!mort && !swap) return false;
  if (room.offerClockCardId === cardId) return false;
  room.offerClockCardId = cardId;
  if (!room.practiceMode) {
    room.mortDeadlineAt = Date.now() + playerTurnTimeoutMs(room);
  }
  return true;
}

function canFundAdditionalNaturalExposure(room: Room, additionalBet: number): boolean {
  const banker = room.players.find((p) => p.isBanker);
  if (!banker) return true;
  const committedBets = room.players
    .filter((p) => !p.isBanker)
    .reduce((total, p) => total + Math.max(0, p.bet), 0);
  return naturalBankPayout(committedBets + additionalBet) <= banker.chips;
}

export type DoubleReject = { code: DoubleRejectCode; message: string };

/**
 * Per què `actorId` no pot doblar ara, amb codi estable de `game_error`, o null si pot.
 * Mateix predicat que la vista (`pendingChoices.canDouble`) i els bots.
 * No muta l'estat, tret del que ja feia `currentSlot` (crea la mà buida si el torn no en té).
 */
export function classifyDoubleReject(room: Room, actorId: string): DoubleReject | null {
  const player = room.players.find((p) => p.id === actorId);
  if (room.phase !== "playing") {
    return { code: DOUBLE_REJECT_CODE.badPhase, message: ENGINE_MESSAGES.cannotDoubleNow };
  }
  if (!player || currentPlayer(room) !== player) {
    return { code: DOUBLE_REJECT_CODE.badTurn, message: ENGINE_MESSAGES.cannotDoubleNow };
  }
  const slot = currentSlot(room);
  if (!slot) return { code: DOUBLE_REJECT_CODE.badTurn, message: ENGINE_MESSAGES.cannotDoubleNow };
  if (slot.blindPair) return { code: DOUBLE_REJECT_CODE.blindPairLocked, message: BLIND_PAIR_LOCKED };
  if (!isHouseRulesEnabled(room)) {
    return { code: DOUBLE_REJECT_CODE.houseRules, message: ENGINE_MESSAGES.cannotDouble };
  }
  if (slot.mortOffered) return { code: DOUBLE_REJECT_CODE.decideMortFirst, message: ENGINE_MESSAGES.decideMortFirst };
  if (slot.swapOffered) return { code: DOUBLE_REJECT_CODE.decideSwapFirst, message: ENGINE_MESSAGES.decideSwapFirst };
  // Dubte C de l'Edu: no es pot doblar amb el Mort ni amb el 3 canviat.
  if (slot.mort) return { code: DOUBLE_REJECT_CODE.mort, message: ENGINE_MESSAGES.cannotDouble };
  if (slot.doubled) return { code: DOUBLE_REJECT_CODE.alreadyDoubled, message: ENGINE_MESSAGES.alreadyDoubled };
  // Una mà separada no es pot doblar. Si la cadena ja havia doblat, el motiu és més concret.
  if (slot.fromSplit && slot.splitFromDoubled) {
    return { code: DOUBLE_REJECT_CODE.splitAlreadyDoubled, message: ENGINE_MESSAGES.splitAlreadyDoubled };
  }
  if (slot.fromSplit) {
    return { code: DOUBLE_REJECT_CODE.splitCannotDouble, message: ENGINE_MESSAGES.splitCannotDouble };
  }
  if (!slot.canDouble) return { code: DOUBLE_REJECT_CODE.cannotDouble, message: ENGINE_MESSAGES.cannotDouble };
  // Només amb la primera carta, abans de demanar-ne cap altra.
  if (slot.cards.length !== 1) return { code: DOUBLE_REJECT_CODE.wrongCards, message: ENGINE_MESSAGES.cannotDouble };
  if (player.chips < slot.bet) {
    return { code: DOUBLE_REJECT_CODE.notEnoughChips, message: ENGINE_MESSAGES.noChipsDouble };
  }
  if (!canFundAdditionalNaturalExposure(room, slot.bet)) {
    return { code: DOUBLE_REJECT_CODE.bankCannotCover, message: ENGINE_MESSAGES.bankCannotCoverDouble };
  }
  return null;
}

/**
 * Per què el jugador del torn no pot doblar ara (missatge que retorna applyDouble), o null si pot.
 * És l'únic predicat: el fan servir l'acció, la vista (`pendingChoices.canDouble`) i els bots.
 */
export function doubleBlockedReason(room: Room, player: Player): string | null {
  return classifyDoubleReject(room, player.id)?.message ?? null;
}

/**
 * Es pot separar amb dues cartes del mateix valor. Les figures compten juntes: sota, cavall
 * i rei valen totes mig punt (`value` 10–12) i es poden separar encara que el rang no coincideixi.
 * No hi ha límit de mans: una mà que ve d'un separar es pot tornar a separar.
 * `maxHands` es conserva a `SPLIT_BLOCKED_CODES` però el motor ja no l'emet.
 */
export function isSplittablePair(cards: readonly Pick<Card, "value">[]): boolean {
  if (cards.length !== 2) return false;
  const [a, b] = cards;
  if (!a || !b) return false;
  if (a.value === b.value) return true;
  return a.value >= 10 && b.value >= 10;
}

type SplitBlockInternal = SplitBlockedCode | "notYourTurn" | "houseRules" | "notAPair";

/** Classificació única de per què no es pot separar. null si es pot. */
function classifySplitBlock(room: Room, player: Player): SplitBlockInternal | null {
  if (room.phase !== "playing" || currentPlayer(room) !== player) return "notYourTurn";
  if (!isHouseRulesEnabled(room)) return "houseRules";
  const slot = currentSlot(room);
  if (slot?.blindPair) return "blindPairLocked";
  if (!slot) return "notAPair";
  if (slot.mortOffered) return "decideMortFirst";
  if (slot.swapOffered) return "decideSwapFirst";
  if (slot.mort) return "mort";
  if (!isSplittablePair(slot.cards.map((c) => c.card))) return "notAPair";
  if (player.chips < slot.bet) return "notEnoughChips";
  if (!canFundAdditionalNaturalExposure(room, slot.bet)) return "bankCannotCoverSplit";
  return null;
}

const SPLIT_BLOCK_MESSAGE: Record<SplitBlockInternal, string> = {
  notYourTurn: "BAD",
  houseRules: ENGINE_MESSAGES.splitUnavailable,
  notAPair: ENGINE_MESSAGES.splitUnavailable,
  blindPairLocked: BLIND_PAIR_LOCKED,
  maxHands: ENGINE_MESSAGES.splitUnavailable,
  decideMortFirst: ENGINE_MESSAGES.decideMortFirst,
  decideSwapFirst: ENGINE_MESSAGES.decideSwapFirst,
  mort: ENGINE_MESSAGES.splitUnavailable,
  notEnoughChips: ENGINE_MESSAGES.noChipsSplit,
  bankCannotCoverSplit: ENGINE_MESSAGES.bankCannotCoverSplit,
};

/**
 * Codi per al client quan és el seu torn, la mà activa és una parella separable
 * i un altre motiu impedeix separar. null si es pot separar, o si no és aquesta parella.
 */
export function splitBlockedForPair(room: Room, player: Player): SplitBlockedCode | null {
  const slot = currentPlayer(room) === player ? currentSlot(room) : undefined;
  if (!slot || !isSplittablePair(slot.cards.map((c) => c.card))) return null;
  const code = classifySplitBlock(room, player);
  if (!code || code === "notYourTurn" || code === "houseRules" || code === "notAPair") return null;
  return code;
}

/** Com doubleBlockedReason, per a la separació (missatge que retorna applySplit). */
export function splitBlockedReason(room: Room, player: Player): string | null {
  const code = classifySplitBlock(room, player);
  if (!code) return null;
  return SPLIT_BLOCK_MESSAGE[code];
}

export function canDoubleNow(room: Room, player: Player): boolean {
  return doubleBlockedReason(room, player) === null;
}

export function canSplitNow(room: Room, player: Player): boolean {
  return splitBlockedReason(room, player) === null;
}

/** Punt de decisió de l'humà del torn: canvia amb qualsevol progrés (carta, separació, mà, mort…). */
function humanTurnKey(room: Room, p: Player): string {
  const s = p.handSlots[p.activeSlotIndex];
  return [
    "playing",
    p.id,
    room.turnPlayerIndex,
    p.activeSlotIndex,
    p.handSlots.length,
    s?.id ?? "-",
    s?.cards.length ?? -1,
    s?.status ?? "-",
    s?.mortOffered ? 1 : 0,
    s?.swapOffered ?? 0,
  ].join("|");
}

export function applyDouble(host: GameHost, room: Room, actorId: string): string | null {
  if (queueIfHolding(room, { kind: "double", actorId })) return null;
  const rejected = classifyDoubleReject(room, actorId);
  if (rejected) return rejected.message;
  const player = currentPlayer(room)!;
  const slot = currentSlot(room)!;
  const extra = slot.bet;
  player.chips -= extra;
  player.bet += extra;
  slot.bet += extra;
  slot.doubled = true;
  slot.canDouble = false;
  setPlayerHandAction(player, "Dobla");
  room.pot += extra;
  const face = nextCardFaceUp(slot);
  const c = drawCard(room);
  if (!c) return null;
  const tc = { id: cid(), card: c, faceUp: face };
  slot.cards.push(tc);
  recordDeal(room, player, slot, tc, "double");
  extendDealAnim(room, scoreCards(slot.cards) > 7.5 ? DEAL_BUST_MS : DEAL_FLIGHT_FLIP_MS);
  if (scoreCards(slot.cards) > 7.5) {
    setPlayerHandAction(player, ENGINE_LABELS.bust);
    slot.status = "busted";
    revealBustedSlot(slot);
    nextTurn(host, room);
  }
  // Normes de la casa: doblar NO planta. Si no s'ha passat, continua el torn
  // (demanar, plantar-se o separar si les dues cartes són del mateix valor o dues figures).
  return null;
}

/**
 * Aposta que porta cada mà en separar (dubte D).
 * Ara és l'aposta de la mà en el moment de separar: si s'havia doblat, ja és l'aposta doblada.
 * Per tornar a l'aposta inicial (la d'abans de doblar), canvia només aquesta funció, per exemple
 * `return slot.doubled ? slot.bet / 2 : slot.bet`.
 */
export function splitHandBet(slot: Pick<HandSlot, "bet" | "doubled">): number {
  return slot.bet;
}

/**
 * Segona carta d'una mà que acaba de separar. `kind: "hit"` perquè el client ja anima
 * una carta demanada; no és un doblar. Una figura + qualsevol carta del munt no passa de 7½.
 */
function dealSplitSecondCard(room: Room, player: Player, slot: HandSlot): void {
  const face = nextCardFaceUp(slot);
  const c = drawCard(room);
  if (!c) return;
  const tc = { id: cid(), card: c, faceUp: face };
  slot.cards.push(tc);
  recordDeal(room, player, slot, tc, "hit");
  if (scoreCards(slot.cards) > 7.5) {
    slot.status = "busted";
    revealBustedSlot(slot);
    setPlayerHandAction(player, ENGINE_LABELS.bust);
  }
}

export function applySplit(room: Room, actorId: string): string | null {
  if (queueIfHolding(room, { kind: "split", actorId })) return null;
  const player = room.players.find((p) => p.id === actorId);
  if (!room || !player || room.phase !== "playing" || currentPlayer(room) !== player) return "BAD";
  const blocked = splitBlockedReason(room, player);
  if (blocked) return blocked;
  const slot = currentSlot(room)!;
  const stake = splitHandBet(slot);
  // Cada mà porta l'aposta d'ara (la doblada, si s'havia doblat). Cap mà separada no es pot
  // tornar a doblar. `splitFromDoubled` recorda si la cadena ja havia doblat, per al codi d'error.
  const lineageDoubled = !!slot.doubled || !!slot.splitFromDoubled;
  player.chips -= stake;
  room.pot += stake;
  player.bet += stake;
  const second = slot.cards.pop()!;
  // S'insereix just després de la mà activa: es continua jugant aquesta, i la nova és la següent.
  const spawned: HandSlot = {
    id: cid(),
    cards: [second],
    bet: stake,
    doubled: false,
    canDouble: false,
    fromSplit: true,
    splitFromDoubled: lineageDoubled,
    mort: false,
    blindPair: false,
    blindUntilBankEnd: false,
    mortOffered: false,
    status: "playing",
  };
  slot.bet = stake;
  slot.doubled = false;
  slot.canDouble = false;
  slot.fromSplit = true;
  slot.splitFromDoubled = lineageDoubled;
  player.handSlots.splice(player.activeSlotIndex + 1, 0, spawned);
  // La segona carta passa a la mà nova: també és un esdeveniment ordenat (kind "split").
  recordDeal(room, player, spawned, second, "split");
  setPlayerHandAction(player, "Split");
  dealSplitSecondCard(room, player, slot);
  dealSplitSecondCard(room, player, spawned);
  extendDealAnim(room, DEAL_FLIGHT_MS);
  extendDealAnim(room, DEAL_FLIGHT_FLIP_MS + DEAL_STAGGER_MS);
  return null;
}

function autoBetForPlayer(room: Room, player: Player, host?: GameHost) {
  if (playerExemptFromBetting(room, player)) return;
  const cap = maxBet(room, player.playerId);
  if (cap < room.minBet) return;
  const amount = player.isBot
    ? botBetWithMemory({ minBet: room.minBet, chips: player.chips, maxBet: cap, lastBetAmount: player.lastBetAmount, profile: botProfileFor(player.name) })
    : decideBetAmount({ minBet: room.minBet, chips: player.chips, maxBet: cap });
  if (amount < room.minBet) return;
  applyPlaceBet(room, player, amount, host);
}

/** Stake used when the betting deadline expires (last bet clamped to coverage). */
export function timeoutBetAmount(room: Room, player: Player): number | null {
  if (player.isBanker || player.bet > 0) return null;
  if (player.chips < room.minBet) return null;
  const cap = maxBet(room, player.playerId);
  if (cap < room.minBet) return null;
  const base = player.lastBetAmount ?? room.minBet;
  return Math.min(Math.max(base, room.minBet), cap);
}

function noteTurnTimeout(room: Room, kind: "minBet" | "stand", seatId: string): void {
  const prev = room.timeoutNotices ?? [];
  room.timeoutNotices = [...prev.filter((n) => n.seatId !== seatId), { kind, seatId }];
}

/** Auto-bet humans (and remaining bots) when the betting window ends. */
export function applyBettingPhaseTimeout(host: GameHost, room: Room): void {
  if (room.phase !== "betting") return;
  room.bettingDeadlineAt = null;
  for (const p of room.players) {
    if (p.isBot || p.isBanker || p.bet > 0) continue;
    const amount = timeoutBetAmount(room, p);
    if (amount === null) continue;
    noteTurnTimeout(room, "minBet", p.id);
    applyPlaceBet(room, p, amount, host);
    if (room.phase !== "betting" || room.dealAfterBetsAt != null) return;
  }
  resolvePendingBets(host, room);
}

function pendingBotBettors(room: Room): Player[] {
  return room.players.filter(
    (p) => !p.isBanker && p.isBot && p.bet === 0 && !playerExemptFromBetting(room, p)
  );
}

/**
 * Tanca d'un cop les apostes dels bots que queden (fi del termini).
 * Durant la finestra oberta cada bot aposta sol i es publica a `scheduleNextBotBet`:
 * aquí no, perquè un sol `publishRoom` al final coalesceria les vistes intermèdies.
 */
function resolvePendingBets(host: GameHost, room: Room) {
  if (room.phase !== "betting" || room.dealAfterBetsAt != null) return;
  for (const p of pendingBotBettors(room)) {
    autoBetForPlayer(room, p, host);
    if (room.phase !== "betting" || room.dealAfterBetsAt != null) return;
  }
  if (room.phase !== "betting" || room.dealAfterBetsAt != null) return;
  if (pendingBotBettors(room).length > 0) return;
  if (!bettingRoundComplete(room)) return;

  const anyPlayerBet = room.players.some((p) => !p.isBanker && p.bet > 0);
  if (!anyPlayerBet) {
    room.phase = "waiting";
    room.players.forEach((p) => {
      p.status = "waiting";
      p.bet = 0;
    });
    const human = room.soloAi ? soloHumanSeat(room) : room.players.find((p) => !p.isBot);
    if (human) {
      if (!tryFinishPhaseBMatchFromTable(host, room, human.id) && room.soloAi) {
        const match = computeSoloMatchResult(
          room.players.map((p) => ({ ...p, isBot: !isSoloHumanSeat(room, p) })),
          room.minBet,
          human.id
        );
        if (match) {
          room.matchResult = match;
          room.matchEnded = true;
          notifyMatchFinished(host, room);
        }
      }
    }
    void publishRoom(host, room);
    return;
  }

  const human = room.soloAi ? soloHumanSeat(room) : room.players.find((p) => !p.isBot);
  if (human && tryFinishPhaseBMatchFromTable(host, room, human.id)) return;
  if (!ensureBankerCanCoverTable(room) && human) {
    tryFinishPhaseBMatchFromTable(host, room, human.id);
  }
}

/** Safe defaults when a human decision timer expires (~20s prod, short in tests). */
export function applyPlayingTurnTimeoutDefault(host: GameHost, room: Room, actorId: string): void {
  if (room.phase !== "playing") return;
  const player = currentPlayer(room);
  if (!player || player.id !== actorId) return;
  const slot = currentSlot(room);
  if (!slot) return;
  if (slot.mortOffered) {
    applyMort(host, room, actorId, false);
  } else if (slot.swapOffered) {
    applySwap(host, room, actorId, false);
  } else {
    slot.autoStood = true;
    noteTurnTimeout(room, "stand", actorId);
    applyStand(host, room, actorId);
  }
}

/** Identifies the exact bot decision point; any progress changes it. Null when it is not a bot's turn. */
export function botTurnKey(room: Room): string | null {
  if (room.phase === "playing") {
    const p = currentPlayer(room);
    if (!p?.isBot) return null;
    const s = p.handSlots[p.activeSlotIndex];
    return [
      "playing",
      p.id,
      room.turnPlayerIndex,
      p.activeSlotIndex,
      p.handSlots.length,
      s?.cards.length ?? -1,
      s?.cards[0]?.id ?? "-",
      s?.status ?? "-",
      s?.mortOffered ? 1 : 0,
      s?.swapOffered ?? 0,
    ].join("|");
  }
  if (room.phase === "banker") {
    const b = room.players.find((p) => p.isBanker);
    if (!b?.isBot) return null;
    return ["banker", b.id, b.handSlots[0]?.cards.length ?? -1, b.status].join("|");
  }
  return null;
}

/**
 * Forces the bot whose turn it is to stand and always moves the hand on.
 * With `onlyPlayerId`, it does nothing if that bot is no longer the one to act.
 */
export function forceBotStand(host: GameHost, room: Room, onlyPlayerId?: string): void {
  if (room.phase === "banker") {
    const b = room.players.find((p) => p.isBanker);
    if (!b?.isBot || (onlyPlayerId && b.id !== onlyPlayerId)) return;
    let err: string | null = "error";
    try {
      err = applyStand(host, room, b.id);
    } catch (e) {
      console.error("[bot] forced banker stand failed:", e);
    }
    if (err !== null && room.phase === "banker") {
      b.status = "stood";
      settleGame(host, room);
    }
    return;
  }
  if (room.phase !== "playing") return;
  const p = currentPlayer(room);
  if (!p?.isBot || (onlyPlayerId && p.id !== onlyPlayerId)) return;
  const turnIndex = room.turnPlayerIndex;
  const slotIndex = p.activeSlotIndex;
  try {
    if (currentSlot(room)?.mortOffered) applyMort(host, room, p.id, false);
    if (currentSlot(room)?.swapOffered) applySwap(host, room, p.id, false);
    if (room.phase === "playing" && currentPlayer(room) === p && p.activeSlotIndex === slotIndex) {
      applyStand(host, room, p.id);
    }
  } catch (e) {
    console.error("[bot] forced stand failed:", e);
  }
  // Last resort: if nothing moved, close the slot by hand and advance the turn.
  if (
    room.phase === "playing" &&
    room.turnPlayerIndex === turnIndex &&
    currentPlayer(room) === p &&
    p.activeSlotIndex === slotIndex
  ) {
    const slot = getSlot(p, slotIndex);
    slot.mortOffered = false;
    slot.swapOffered = null;
    if (slot.status === "playing") slot.status = "stood";
    nextTurn(host, room);
  }
}

/** Arms (or keeps) the per-room watchdog for the current bot decision point. */
function armBotTurnWatchdog(host: GameHost, room: Room): void {
  const key = botTurnKey(room);
  if (!key) {
    room.botTurnWatch = null;
    return;
  }
  const now = Date.now();
  if (!room.botTurnWatch || room.botTurnWatch.key !== key) {
    room.botTurnWatch = { key, since: now };
  }
  // Si el bot ha d'esperar una animació de repartiment, el vigilant li dona aquest temps de més.
  const animExtra = Math.max(0, (room.dealAnimUntil ?? 0) - room.botTurnWatch.since);
  const delayMs = Math.max(1, room.botTurnWatch.since + BOT_TURN_WATCHDOG_MS + animExtra - now);
  room.botWatchdogTimer = host.schedule(() => runBotTurnWatchdog(host, room), delayMs);
}

/**
 * Watchdog callback: if the bot has not moved since it was armed, it is forced to stand;
 * if the state moved but nothing was scheduled (no bot timer pending), it reschedules.
 */
export function runBotTurnWatchdog(host: GameHost, room: Room): void {
  room.botWatchdogTimer = null;
  if (actionHoldRemainingMs(room) > 0) {
    armActionHold(host, room);
    armBotTurnWatchdog(host, room);
    return;
  }
  const key = botTurnKey(room);
  if (!key) return;
  if (room.botTurnWatch?.key === key) {
    console.warn(`[bot] watchdog: torn de bot encallat a la sala ${room.id}; es força plantar-se`);
    forceBotStand(host, room);
    void publishRoom(host, room);
    return;
  }
  if (!room.botTimer) scheduleAfterRoomChange(host, room);
  else armBotTurnWatchdog(host, room);
}

export function runBotAction(host: GameHost, room: Room, player: Player) {
  try {
    runBotActionUnsafe(host, room, player);
  } catch (err) {
    console.error("[bot] action failed; forcing stand:", err);
    forceBotStand(host, room, player.id);
    void publishRoom(host, room);
  }
}

function runBotActionUnsafe(host: GameHost, room: Room, player: Player) {
  if (actionHoldRemainingMs(room) > 0) return;
  if (room.phase === "betting" && !player.isBanker && player.bet === 0) {
    autoBetForPlayer(room, player);
    void publishRoom(host, room);
    return;
  }

  if (room.phase === "playing" && currentPlayer(room)?.id === player.id) {
    const ctx = strategyContextFor(room, player);
    const profile = botProfileFor(player.name);
    const slot = currentSlot(room);
    if (!slot) {
      forceBotStand(host, room, player.id);
      void publishRoom(host, room);
      return;
    }
    if (slot.mortOffered) {
      if (applyMort(host, room, player.id, decideBotMort(ctx, profile))) forceBotStand(host, room, player.id);
      void publishRoom(host, room);
      return;
    }
    if (slot.swapOffered) {
      // Bots: canvien el 4 (també el 4 que surt del canvi) i juguen normal el 3.
      // Si el canvi no avança (el munt s'ha acabat i segueix el mateix 4), es planten.
      const offer = slot.swapOffered;
      const cardId = slot.cards[0]?.id;
      if (applySwap(host, room, player.id, offer === 4)) forceBotStand(host, room, player.id);
      const stuck =
        room.phase === "playing" &&
        currentPlayer(room)?.id === player.id &&
        currentSlot(room) === slot &&
        slot.swapOffered === offer &&
        slot.cards[0]?.id === cardId;
      if (stuck) forceBotStand(host, room, player.id);
      void publishRoom(host, room);
      return;
    }
    if (ctx.canSplit && decideBotSplit(ctx, profile)) {
      const splitErr = applySplit(room, player.id);
      if (!splitErr) {
        void publishRoom(host, room);
        return;
      }
    }
    if (ctx.canDouble && decideBotDouble(ctx, profile)) {
      // A rejected double (e.g. the bank cannot cover it) used to return here with no change,
      // and the bot retried the same double forever: fall through to hit/stand instead.
      if (!applyDouble(host, room, player.id)) {
        void publishRoom(host, room);
        return;
      }
    }
    const cardsBefore = slot.cards.length;
    const action = decideBotHitOrStand(ctx, botDifficultyFor(room), profile);
    const err = action === "hit" ? applyHit(host, room, player.id) : applyStand(host, room, player.id);
    const noProgress =
      action === "hit" && currentSlot(room) === slot && slot.cards.length === cardsBefore && slot.status === "playing";
    if (err || noProgress) forceBotStand(host, room, player.id);
    void publishRoom(host, room);
    return;
  }

  if (room.phase === "banker" && player.isBanker) {
    const ctx = strategyContextFor(room, player);
    const cardsBefore = player.handSlots[0]?.cards.length ?? 0;
    const action = decideBotHitOrStand({ ...ctx, isBanker: true }, botDifficultyFor(room), botProfileFor(player.name));
    const err = action === "hit" ? applyHit(host, room, player.id) : applyStand(host, room, player.id);
    const noProgress =
      action === "hit" && room.phase === "banker" && (player.handSlots[0]?.cards.length ?? 0) === cardsBefore;
    if (err || noProgress) forceBotStand(host, room, player.id);
    void publishRoom(host, room);
  }
}

/**
 * Després d'un reinici, torna a armar les pauses que només viuen en memòria
 * (liquidació d'apostes i avís HIT/STAND). Els temporitzadors no es desen al disc.
 */
export function resumePacingTimers(host: GameHost, room: Room): void {
  if (room.phase === "playing" || room.phase === "banker") {
    if (room.actionHoldEndsAt != null && actionHoldRemainingMs(room) <= 0) {
      finishActionHold(host, room);
      return;
    }
  }
  if (room.phase === "betting" && room.dealAfterBetsAt != null && room.dealAfterBetsAt <= Date.now()) {
    room.dealAfterBetsAt = null;
    openInitialDeal(room);
    void publishRoom(host, room);
    return;
  }
  if (room.dealAfterBetsAt != null || actionHoldRemainingMs(room) > 0) {
    scheduleAfterRoomChange(host, room);
  }
}

/**
 * Programa l'aposta del pròxim bot, un per tic. `publishRoom` (al callback) torna a
 * entrar aquí i encadena el següent, així cada aposta surt en el seu `room_update`
 * abans que el bot següent mogui fitxes. El forat és `BOT_BET_GAP_MS` (0 al mode ràpid,
 * on es recupera la pensada curta). Si no en queda cap, no es programa res.
 */
function scheduleNextBotBet(host: GameHost, room: Room): void {
  if (room.phase !== "betting" || room.dealAfterBetsAt != null) return;
  const bot = room.players.find((p) => p.isBot && p.bet === 0 && !playerExemptFromBetting(room, p));
  if (!bot) return;
  const delay = botBetGapMs() > 0 ? botBetGapMs() : randomBotPaceMs();
  room.botTimer = host.schedule(() => {
    room.botTimer = null;
    if (room.phase !== "betting" || room.dealAfterBetsAt != null) return;
    const pending = room.players.find((p) => p.isBot && p.bet === 0 && !playerExemptFromBetting(room, p));
    if (!pending) return;
    const before = pending.bet;
    autoBetForPlayer(room, pending, host);
    if (pending.bet === before && room.phase === "betting" && room.dealAfterBetsAt == null) return;
    void publishRoom(host, room);
  }, delay);
}

export function scheduleAfterRoomChange(host: GameHost, room: Room) {
  if (room.phase === "waiting" || room.phase === "settlement" || room.phase === "bank_draw") {
    room.turnDeadlineAt = null;
    room.mortDeadlineAt = null;
    room.bettingDeadlineAt = null;
    room.botTurnWatch = null;
    return;
  }
  clearRoomTimers(host, room);

  if ((room.phase === "playing" || room.phase === "banker") && actionHoldRemainingMs(room) > 0) {
    armActionHold(host, room);
    armBotTurnWatchdog(host, room);
    room.phaseEndsAt = room.actionHoldEndsAt ?? null;
    room.turnDeadlineAt = null;
    return;
  }

  if (room.phase === "betting" && room.dealAfterBetsAt != null) {
    armBetsSettle(host, room);
    room.turnDeadlineAt = room.dealAfterBetsAt;
    return;
  }

  armBotTurnWatchdog(host, room);

  if (room.phase === "betting") {
    scheduleNextBotBet(host, room);
    if (room.practiceMode) {
      room.bettingDeadlineAt = null;
      room.turnDeadlineAt = null;
      return;
    }
    if (!room.bettingDeadlineAt) {
      room.bettingDeadlineAt = Date.now() + humanBetTimeoutMs();
    }
    room.turnDeadlineAt = room.bettingDeadlineAt;
    const delayMs = Math.max(1, room.bettingDeadlineAt - Date.now());
    room.humanTimer = host.schedule(() => {
      applyBettingPhaseTimeout(host, room);
      void publishRoom(host, room);
    }, delayMs);
    return;
  }

  const previousTurnDeadlineAt = room.turnDeadlineAt ?? null;
  room.turnDeadlineAt = null;

  if (room.phase === "playing") {
    const cur = currentPlayer(room);
    if (cur?.isBot) {
      // El bot no actua abans que acabi l'animació (≤ 600 ms dins el torn, ≤ 850 ms el repartiment),
      // però tampoc no allarga el seu ritme: és el màxim, no la suma.
      const delay = Math.max(
        cur.lastHandAction ? randomBotPaceMs() : botFirstActionDelayMs(),
        dealAnimWaitMs(room)
      );
      room.botTimer = host.schedule(() => {
        room.botTimer = null;
        runBotAction(host, room, cur);
      }, delay);
    } else if (cur) {
      const slot = currentSlot(room);
      const mortPending =
        isHouseRulesEnabled(room) &&
        ((!!slot?.mortOffered && slot.cards[0]?.card.value === 7) || !!slot?.swapOffered);
      const now = Date.now();
      // El termini de l'humà comença quan acaba l'animació del repartiment (repart-v2).
      const animWait = dealAnimWaitMs(room);
      const turnMs = playerTurnTimeoutMs(room);
      let delayMs = animWait + turnMs;
      if (!room.practiceMode) {
        if (mortPending) {
          const offerCardId = slot.cards[0]?.id ?? null;
          const peeked = !!offerCardId && room.offerClockCardId === offerCardId;
          // Sense peek: termini de seguretat = el torn sencer. Amb peek: `turnMs` des del peek
          // (ja escrit per applyCardPeeked; aquí només es reposa si s'ha perdut).
          if (!room.mortDeadlineAt || room.mortDeadlineAt <= now) {
            room.mortDeadlineAt = now + (peeked ? turnMs : animWait + turnMs);
          }
          room.turnDeadlineAt = room.mortDeadlineAt;
          delayMs = Math.max(1, room.mortDeadlineAt - now);
        } else {
          room.mortDeadlineAt = null;
          room.offerClockCardId = null;
          // Termini ancorat al punt de decisió: tornar a publicar sense progrés (una acció rebutjada,
          // un clic repetit a «Separar», una reconnexió…) no el reinicia. Abans cada publicació
          // el tornava a posar a now + torn i el torn no expirava mai mentre l'humà anés clicant.
          const key = humanTurnKey(room, cur);
          if (room.turnDeadlineKey === key && previousTurnDeadlineAt !== null && previousTurnDeadlineAt > now) {
            room.turnDeadlineAt = previousTurnDeadlineAt;
          } else {
            room.turnDeadlineAt = now + animWait + turnMs;
            room.turnDeadlineKey = key;
          }
          delayMs = Math.max(1, room.turnDeadlineAt - now);
        }
        room.humanTimer = host.schedule(() => {
          if (room.phase !== "playing" || currentPlayer(room)?.id !== cur.id) return;
          room.mortDeadlineAt = null;
          // Mort pending: default No (applyMort), not hit/stand — then a fresh timer runs for the rest of the turn.
          applyPlayingTurnTimeoutDefault(host, room, cur.id);
          void publishRoom(host, room);
        }, delayMs);
      } else {
        room.turnDeadlineAt = null;
        room.mortDeadlineAt = null;
      }
    }
    return;
  }

  if (room.phase === "banker") {
    const banker = room.players.find((p) => p.isBanker);
    if (!banker) return;
    if (banker.isBot) {
      room.botTimer = host.schedule(() => {
        room.botTimer = null;
        runBotAction(host, room, banker);
      }, Math.max(bankerBotActionDelayMs(), dealAnimWaitMs(room)));
    } else if (!room.practiceMode) {
      const bankMs = dealAnimWaitMs(room) + Math.max(playerTurnTimeoutMs(room), bankerTimeoutMs());
      room.turnDeadlineAt = Date.now() + bankMs;
      room.humanTimer = host.schedule(() => {
        if (room.phase !== "banker") return;
        const bankSlot = banker.handSlots[0];
        if (bankSlot) bankSlot.autoStood = true;
        noteTurnTimeout(room, "stand", banker.id);
        applyStand(host, room, banker.id);
        void publishRoom(host, room);
      }, bankMs);
    } else {
      room.turnDeadlineAt = null;
    }
  }
}

export function beginBettingPhase(host: GameHost, room: Room) {
  installSeededHandShoe(room);
  if (room.deck.length === 0 && room.centerDiscard.length === 0) {
    room.deck = createDeck(room);
  }
  discardBankDrawToPile(room);
  room.bankDraw = undefined;
  room.players.forEach((p) => {
    p.status = "betting";
    p.bet = 0;
    p.handSlots = [];
    p.lastHandAction = undefined;
  });
  if (phaseBMatchEnabled(room)) {
    const bankerReady = ensureBankerCanCoverTable(room);
    const human = room.soloAi ? soloHumanSeat(room) : room.players.find((p) => !p.isBot);
    if (human && human.chips < room.minBet && tryFinishPhaseBMatchFromTable(host, room, human.id)) {
      return;
    }
    const banker = room.players.find((p) => p.isBanker);
    if (banker && (!bankerReady || !bankCoversConfiguredRange(room, banker)) && human) {
      tryFinishPhaseBMatchFromTable(host, room, human.id);
      return;
    }
  }
  room.timeoutNotices = [];
  if (room.practiceMode) {
    // Pràctica: el jugador tria l'aposta amb fitxes de pràctica, sense temporitzador
    // (abans s'apostava sol al moment). Els bots aposten al seu ritme.
    room.bettingDeadlineAt = null;
    room.turnDeadlineAt = null;
    room.phase = "betting";
    void publishRoom(host, room);
    return;
  }
  room.bettingDeadlineAt = Date.now() + humanBetTimeoutMs();
  room.turnDeadlineAt = room.bettingDeadlineAt;
  room.phase = "betting";
  void publishRoom(host, room);
}

export function beginGameStart(host: GameHost, room: Room) {
  if (room.matchEnded) return;
  ensurePhaseBMatchInitialized(room);
  prepareBankForNextHand(room);
  const currentBanker = room.players.find((p) => p.isBanker);
  if (currentBanker) {
    beginBettingPhase(host, room);
    return;
  }

  const firstSoloHand =
    room.soloAi && phaseBMatchEnabled(room) && (room.phaseB?.handsCompleted ?? 0) === 0;
  if (firstSoloHand) {
    const botBanker = room.players.find((p) => p.isBot);
    if (botBanker) {
      applyBankerToPlayer(room.players, botBanker.id);
      beginBettingPhase(host, room);
      return;
    }
  }

  if (!canStartGame(room)) {
    room.phase = "waiting";
    room.bankDraw = undefined;
    void publishRoom(host, room);
    return;
  }

  room.deck = createDeck(room);
  room.centerDiscard = [];
  room.bankDraw = [];
  room.players.forEach((p) => {
    p.handSlots = [];
    const c = drawCard(room);
    if (c) room.bankDraw!.push({ playerId: p.id, card: c });
  });
  if (room.bankDraw!.length === 0) {
    room.phase = "waiting";
    room.bankDraw = undefined;
    void publishRoom(host, room);
    return;
  }
  let winner = room.players[0];
  let best = room.bankDraw![0].card;
  for (let i = 1; i < room.bankDraw!.length; i++) {
    const cmp = compareDraws(room.bankDraw![i].card, best);
    if (cmp > 0) {
      best = room.bankDraw![i].card;
      winner = room.players.find((p) => p.id === room.bankDraw![i].playerId) ?? winner;
    }
  }
  winner.isBanker = true;
  room.players.forEach((p) => {
    if (p.id !== winner.id) p.isBanker = false;
  });
  room.phase = "bank_draw";
  room.bankDrawEndsAt = Date.now() + BANK_DRAW_MS;
  host.schedule(async () => {
    room.phase = "betting";
    discardBankDrawToPile(room);
    room.bankDraw = undefined;
    room.players.forEach((p) => {
      p.status = "betting";
      p.bet = 0;
      p.handSlots = [];
    });
    await publishRoom(host, room);
  }, BANK_DRAW_MS);
  void publishRoom(host, room);
}

/** Pot wagers with no matching slot outcome (split/double edge cases) return to the banker. */
function settleRemainingPotToBanker(room: Room): void {
  if (room.pot <= 0) return;
  const banker = room.players.find((p) => p.isBanker);
  if (banker) banker.chips += room.pot;
  room.pot = 0;
}

/**
 * Liquida la mà i la publica UNA sola vegada, quan tots els moviments de fitxes ja estan fets.
 * Mentre es liquida, cap `publishRoom` intern (p. ex. el final de partida per falta de banca)
 * no surt cap a fora: abans, amb un host síncron (solo local), sortia un estat amb les fitxes
 * ja pagades però sense `lastRound`.
 */
export function settleGame(host: GameHost, room: Room) {
  room.settlingInProgress = true;
  let settled = false;
  try {
    settled = settleGameState(host, room);
  } finally {
    room.settlingInProgress = undefined;
  }
  void publishRoom(host, room);
  if (settled) scheduleSettlementEnd(host, room);
}

function settlementChipsKind(room: Room): SettlementChipsKind {
  if (room.practiceMode) return "practice";
  if (room.fastTournament) return "tournament";
  if (phaseBMatchEnabled(room)) return "match";
  return "real";
}

/**
 * 7½ amb les dues cartes de sortida (la mà sense separar).
 * Després de separar, el mateix 7½ és normal: es compara i es paga com qualsevol altre, a 1×.
 */
function isOpeningNatural(player: Player, slot: HandSlot): boolean {
  if (player.handSlots.length > 1) return false;
  if (slot.status === "busted") return false;
  if (slot.cards.length !== 2) return false;
  return scoreCards(slot.cards) === 7.5;
}

function buildSettlementRecord(
  room: Room,
  results: ResultEntry[],
  highlights: HighlightEntry[],
  bankInfo: { points: number | null; busted: boolean; sevenHalf: boolean },
  at: number
): SettlementRecord {
  const handSeq = (room.handSeq ?? 0) + 1;
  room.handSeq = handSeq;
  const resultByName = new Map(results.map((r) => [r.name, r]));
  const seats: SettlementRecord["seats"] = [];
  let bank: SettlementRecord["bank"] = null;
  for (const p of room.players) {
    const before = room.roundStartChips?.get(p.playerId);
    if (before === undefined) continue;
    const chipDelta = p.chips - before;
    const line = resultByName.get(p.name);
    const outcome = line?.outcome ?? (chipDelta > 0 ? "win" : chipDelta < 0 ? "lose" : "push");
    seats.push({
      playerId: p.playerId,
      name: p.name,
      isBanker: p.isBanker,
      isBot: !!p.isBot,
      chipsBefore: before,
      chipsAfter: p.chips,
      chipDelta,
      outcome,
      detail: line?.detail ?? (p.isBanker ? ENGINE_LABELS.bank : ENGINE_LABELS.noChange),
      handPoints: line?.handPoints,
      slots: p.isBanker
        ? []
        : p.handSlots
            .filter((slot) => slot.bet > 0)
            .map((slot) => {
              const points = scoreCards(slot.cards);
              return {
                bet: slot.bet,
                points,
                status: slot.status,
                doubled: slot.doubled,
                natural: isOpeningNatural(p, slot),
              };
            }),
    });
    if (p.isBanker) {
      bank = {
        playerId: p.playerId,
        name: p.name,
        isBot: !!p.isBot,
        points: bankInfo.points,
        busted: bankInfo.busted,
        sevenHalf: bankInfo.sevenHalf,
        chipsBefore: before,
        chipsAfter: p.chips,
        chipDelta,
      };
    }
  }
  const chipsBefore = seats.reduce((sum, s) => sum + s.chipsBefore, 0);
  const chipsAfter = seats.reduce((sum, s) => sum + s.chipsAfter, 0);
  return {
    settlementId: settlementIdFor(room.id, handSeq, at),
    roomId: room.id,
    handSeq,
    handNumber: room.phaseB ? Math.min(room.phaseB.handsTotal, room.phaseB.handsCompleted + 1) : null,
    handsTotal: room.phaseB ? room.phaseB.handsTotal : null,
    at,
    chipsKind: settlementChipsKind(room),
    bank,
    seats,
    totals: {
      sumChipDelta: seats.reduce((sum, s) => sum + s.chipDelta, 0),
      chipsBefore,
      chipsAfter,
      jackpotBefore: room.roundStartJackpot ?? room.jackpot,
      jackpotAfter: room.jackpot,
      potAfter: room.pot,
    },
    highlights: highlights.map((h) => ({ ...h, params: { ...h.params } }) as HighlightEntry),
    results: results.map((r) => ({ ...r, params: { ...r.params } }) as ResultEntry),
    matchEnded: !!room.matchEnded,
  };
}

/** Moviments de fitxes de la liquidació (sense publicar). Retorna fals si no hi havia banca. */
function settleGameState(host: GameHost, room: Room): boolean {
  room.phase = "settlement";
  room.turnDeadlineAt = null;
  const banker = room.players.find((p) => p.isBanker);
  const highlights: HighlightEntry[] = [];
  const pushHighlight = (msg: HighlightMessage) => {
    highlights.push(makeHighlight(msg));
  };

  if (!banker) {
    return false;
  }

  // Partides antigues sense foto d'inici: es reconstrueix abans de moure fitxes
  // (fitxes actuals + suma de les apostes de les mans). No es toquen fitxes ni apostes.
  if (!room.roundStartChips) {
    room.roundStartChips = new Map(
      room.players.map((p) => [p.playerId, p.chips + p.handSlots.reduce((sum, slot) => sum + slot.bet, 0)])
    );
  }

  const bslot = banker.handSlots[0];
  // La carta inicial de la banca va tapada fins al seu torn. A la liquidació entra al total
  // (i es destapa) encara que el torn de la banca no l'hagi girat.
  if (bslot) {
    for (const c of bslot.cards) c.faceUp = true;
  }
  const bankerScore = scoreCards(bslot?.cards.map((c) => ({ card: c.card })) ?? []);
  const bankerBusted = bankerScore > 7.5;
  const bankerSetIMig = isSetIMigScore(bankerScore, bankerBusted ? "busted" : "stood");

  const collectPotToBank = (amount: number) => {
    const fromPot = Math.min(amount, room.pot);
    room.pot -= fromPot;
    banker.chips += fromPot;
  };

  const payPlayerWin = (player: Player, slotBet: number, bankPayout: number) => {
    const fromPot = Math.min(slotBet, room.pot);
    room.pot -= fromPot;
    banker.chips -= bankPayout;
    player.chips += fromPot + bankPayout;
    return fromPot + bankPayout;
  };

  type LoseCode = "bust" | "mortLoses" | "bankWins" | "tieSevenHalfBank" | "tieBank";
  type SlotOutcome =
    | { kind: "lose"; player: Player; slot: HandSlot; code: LoseCode }
    | {
        kind: "win";
        player: Player;
        slot: HandSlot;
        bankPayout: number;
        bankBust: boolean;
        natural?: boolean;
        special?: SpecialHandKind;
      };
  const baseParams = (player: Player, slot: HandSlot) => ({
    player: player.name,
    seatId: player.id,
    hand: Math.max(0, player.handSlots.indexOf(slot)),
    score: scoreCards(slot.cards),
    ...(specialHandKind(slot) ? { special: specialHandKind(slot)! } : {}),
  });

  type WinOutcome = Extract<SlotOutcome, { kind: "win" }>;
  type LoseOutcome = Extract<SlotOutcome, { kind: "lose" }>;
  const losers: LoseOutcome[] = [];
  const winners: WinOutcome[] = [];

  for (const player of room.players) {
    if (player.isBanker) continue;

    for (const slot of player.handSlots) {
      if (slot.bet <= 0) continue;
      const sc = scoreCards(slot.cards);
      // Després de separar, sota + 7 (7½ amb 2 cartes) és un 7½ normal: paga 1×, no el natural.
      const natural = isOpeningNatural(player, slot);

      if (slot.status === "busted") {
        losers.push({ kind: "lose", player, slot, code: "bust" });
        continue;
      }

      if (slot.mort && slot.cards.length === 2 && sc !== 7.5) {
        losers.push({ kind: "lose", player, slot, code: "mortLoses" });
        continue;
      }

      // #39: la parella cega del 3 no es planta ni es passa durant el torn; si en destapar-la
      // passa de 7½, perd laposta encara que la banca també shagi passat.
      if (slot.blindPair && sc > 7.5) {
        losers.push({ kind: "lose", player, slot, code: "bust" });
        continue;
      }

      // Normes de la casa: el 3 canviat que guanya cobra el doble (aposta 10 → +20); si perd, l'aposta normal.
      // El Mort només pot guanyar amb 7½ (7 + figura), que ja paga el doble.
      const special = specialHandKind(slot) ?? undefined;
      const specialMult = special ? 2 : 1;
      if (bankerBusted) {
        winners.push({
          kind: "win",
          player,
          slot,
          bankPayout: natural ? slot.bet * 2 : slot.bet * specialMult,
          bankBust: true,
          natural: natural || undefined,
          special,
        });
        continue;
      }

      if (bankerSetIMig && sc <= 7.5) {
        losers.push({
          kind: "lose",
          player,
          slot,
          code: sc === 7.5 ? "tieSevenHalfBank" : "bankWins",
        });
        continue;
      }

      if (natural) {
        winners.push({
          kind: "win",
          player,
          slot,
          bankPayout: slot.bet * 2,
          bankBust: false,
          natural: true,
          special,
        });
        continue;
      }

      if (sc > bankerScore) {
        winners.push({
          kind: "win",
          player,
          slot,
          bankPayout: slot.bet * specialMult,
          bankBust: false,
          special,
        });
      } else {
        losers.push({
          kind: "lose",
          player,
          slot,
          code: sc === bankerScore ? "tieBank" : "bankWins",
        });
      }
    }
  }

  for (const outcome of losers) {
    collectPotToBank(outcome.slot.bet);
    const params = baseParams(outcome.player, outcome.slot);
    if (outcome.code === "bust" || outcome.code === "mortLoses") {
      pushHighlight({ code: outcome.code, params });
    } else {
      pushHighlight({ code: outcome.code, params: { ...params, bankScore: bankerScore } });
    }
  }

  for (const outcome of winners) {
    const returned = payPlayerWin(outcome.player, outcome.slot.bet, outcome.bankPayout);
    let jackpotPaid = 0;
    if (outcome.natural) {
      jackpotPaid = Math.min(room.jackpot, room.pot);
      if (jackpotPaid > 0) {
        room.pot -= jackpotPaid;
        outcome.player.chips += jackpotPaid;
        room.jackpot -= jackpotPaid;
      }
      outcome.player.lastRoyal7Payout = returned + jackpotPaid;
    }
    // Net de la mà: el que torna (aposta + pagament + jackpot) menys l'aposta d'aquella mà, doble inclòs.
    const net = returned + jackpotPaid - outcome.slot.bet;
    const params = baseParams(outcome.player, outcome.slot);
    if (outcome.natural) {
      if (outcome.special) {
        pushHighlight({
          code: "specialWin",
          params: {
            ...params,
            special: outcome.special,
            amount: net,
            jackpot: jackpotPaid,
            bankScore: bankerScore,
            bankBusted: outcome.bankBust,
            multiplier: 2,
          },
        });
        continue;
      }
      pushHighlight({
        code: "naturalWin",
        params: { ...params, amount: net, jackpot: jackpotPaid, bankBusted: outcome.bankBust },
      });
    } else if (outcome.special) {
      pushHighlight({
        code: "specialWin",
        params: {
          ...params,
          special: outcome.special,
          amount: net,
          jackpot: 0,
          bankScore: bankerScore,
          bankBusted: outcome.bankBust,
          multiplier: 2,
        },
      });
    } else {
      pushHighlight({
        code: outcome.bankBust ? "winBankBust" : "win",
        params: { ...params, amount: net, bankScore: bankerScore },
      });
    }
  }

  settleRemainingPotToBanker(room);

  offerBankAfterSetIMig(room);

  if (bankerBusted) {
    tryMatchEndWhenNoBankSubstitute(host, room);
  }

  const results: ResultEntry[] = [];
  for (const player of room.players) {
    const before = room.roundStartChips?.get(player.playerId);
    if (before === undefined) continue;
    const chipDelta = player.chips - before;
    // Per seient, no per nom: dos «Pau» no es barregen el text de la victòria amb el delta de l'altre.
    const playerHighlights = highlights.filter(
      (h) => h.params?.seatId === player.id || (h.params?.seatId == null && h.name === player.name)
    );
    if (playerHighlights.length === 0 && chipDelta === 0 && !player.isBanker) continue;
    const playerHands = playerHighlights.map((h) => ({ code: h.code, params: h.params }) as HighlightMessage);
    const message: ResultMessage = player.isBanker
      ? {
          code: "bank",
          params: {
            player: player.name,
            seatId: player.id,
            chipDelta,
            score: bslot?.cards?.length ? bankerScore : null,
          },
        }
      : playerHands.length === 0
        ? { code: "noChange", params: { player: player.name, seatId: player.id, chipDelta } }
        : { code: "hands", params: { player: player.name, seatId: player.id, chipDelta, hands: playerHands } };
    const detail = resultFallbackDetail(message);
    const outcome = player.isBanker
      ? chipDelta > 0
        ? "win"
        : chipDelta < 0
          ? "lose"
          : "push"
      : classifyOutcomeFromHighlight(playerHighlights.map((h) => h.text).join(" "), chipDelta);
    let handPoints: number | undefined;
    if (!player.isBanker) {
      const slots = player.handSlots.filter((slot) => slot.cards.length > 0);
      // El Mort que no és 7½ perd l'aposta: no és un «passat» i el total (7+4 = 11) no es pinta com a bust.
      const mortMiss = slots.find((slot) => slot.mort && Math.abs(scoreCards(slot.cards) - 7.5) > 0.001);
      // El resum diu «t'has passat a N»: N ha de ser la mà passada, no una altra mà del split ni el Mort.
      const busted = slots.find((slot) => !slot.mort && (slot.status === "busted" || scoreCards(slot.cards) > 7.5));
      const slot = busted ?? (mortMiss ? undefined : slots[0]);
      if (slot) handPoints = scoreCards(slot.cards);
    } else if (bslot?.cards?.length) {
      handPoints = bankerScore;
    }
    results.push({ ...message, name: player.name, outcome, chipDelta, detail, handPoints } as ResultEntry);
  }

  const settledAt = Date.now();
  room.lastRound = { title: ENGINE_LABELS.settlement, highlights, results, at: settledAt };
  room.lastSettlement = buildSettlementRecord(
    room,
    results,
    highlights,
    {
      points: bslot?.cards?.length ? bankerScore : null,
      busted: bankerBusted,
      sevenHalf: bankerSetIMig,
    },
    settledAt
  );
  updateSessionStatsFromRound(room);
  void persistHumanBalances(host, room);
  void host.onHandSettled?.(room);
  room.settlementStartedAt = settledAt;
  for (const p of room.players) p.settlementAck = undefined;
  scheduleBankChoiceResponses(host, room);
  return true;
}

function tryMatchEndWhenNoBankSubstitute(host: GameHost, room: Room) {
  const banker = room.players.find((p) => p.isBanker);
  if (!banker) return;
  const next = pickNextBankerInSeatOrder(room.players, room.minBet, banker.id, room.tableMaxBet);
  if (next) return;
  const human = room.soloAi ? soloHumanSeat(room) : room.players.find((p) => !p.isBot);
  const viewerId = human?.id ?? room.players[0]?.id ?? "";
  if (!viewerId) return;
  if (phaseBMatchEnabled(room) && room.phaseB) {
    tryFinishPhaseBMatchFromTable(host, room, viewerId);
    return;
  }
  if (room.soloAi) {
    const match = computeSoloMatchResult(room.players, room.minBet, viewerId);
    if (match) {
      room.matchResult = match;
      room.matchEnded = true;
      room.phase = "waiting";
      notifyMatchFinished(host, room);
    }
  }
}

function allNonBankersBusted(room: Room): boolean {
  const nb = nonBankers(room);
  if (nb.length === 0) return false;
  return nb.every((p) => {
    const active = p.handSlots.filter((slot) => slot.bet > 0);
    return active.length > 0 && active.every((slot) => slot.status === "busted");
  });
}

function goToBankerTurn(host: GameHost, room: Room) {
  const banker = room.players.find((p) => p.isBanker);
  if (!banker) {
    settleGame(host, room);
    return;
  }
  if (allNonBankersBusted(room)) {
    settleGame(host, room);
    return;
  }
  room.phase = "banker";
  const bs = banker.handSlots[0];
  if (bs) {
    bs.cards.forEach((c) => {
      c.faceUp = true;
    });
    // R4: la banca destapa la seva oculta (240 ms) abans que comenci el seu torn.
    extendDealAnim(room, BANK_REVEAL_MS);
  }
  void publishRoom(host, room);
}

function nextTurn(host: GameHost, room: Room) {
  const nb = nonBankers(room);
  const cur = currentPlayer(room);
  if (!cur) {
    goToBankerTurn(host, room);
    return;
  }
  const slot = getSlot(cur, cur.activeSlotIndex);
  const hasSecond = cur.handSlots.length > cur.activeSlotIndex + 1;
  if (hasSecond && slot.status !== "playing") {
    cur.activeSlotIndex++;
    void publishRoom(host, room);
    return;
  }
  room.turnPlayerIndex++;
  cur.activeSlotIndex = 0;
  if (room.turnPlayerIndex >= nb.length) {
    goToBankerTurn(host, room);
    return;
  }
  void publishRoom(host, room);
}

function dealInitialForPlayer(room: Room, player: Player) {
  const slot = getSlot(player, 0);
  const c = drawCard(room);
  if (!c) return;
  const house = isHouseRulesEnabled(room);
  const tc = { id: cid(), card: c, faceUp: false };
  slot.cards.push(tc);
  recordDeal(room, player, slot, tc, "initial", room.dealLog?.length ?? 0);
  slot.bet = player.bet;
  if (house && c.value === 7) {
    slot.mortOffered = true;
  }
  // Normes de la casa: el 3 i el 4 són opcionals («Jugar» o «Canviar», applySwap).
  slot.swapOffered = house && (c.value === 3 || c.value === 4) ? (c.value as 3 | 4) : null;
  slot.canDouble = house;
  slot.status = "playing";
}

/**
 * Normal draws maintain exactly one hidden card per hand: if a hidden card
 * already exists, the next draw is face up; if the hand is fully revealed,
 * the next draw becomes the new hidden card. Special blind hands (3/Mort)
 * keep their dedicated rules and are handled separately.
 */
export function nextCardFaceUp(slot: HandSlot): boolean {
  return slot.cards.some((card) => !card.faceUp);
}

/** Una mà que es passa de 7½ es destapa al moment per a tothom (i perd). */
export function revealBustedSlot(slot: HandSlot): void {
  for (const tc of slot.cards) tc.faceUp = true;
}

/**
 * «Destapar carta» del jugador en torn (només fase playing). Retorna el missatge d'error o null.
 * Un cop destapada no es torna a tapar; si era l'única tapada, la següent carta que demani surt tapada.
 */
export function applyRevealCard(room: Room, actorId: string, cardId: string): string | null {
  if (room.phase !== "playing") return ENGINE_MESSAGES.notYourTurn;
  const player = currentPlayer(room);
  if (!player || player.id !== actorId) return ENGINE_MESSAGES.notYourTurn;
  const slot = currentSlot(room);
  if (!slot) return ENGINE_MESSAGES.invalidAction;
  const tc = slot.cards.find((c) => c.id === cardId);
  if (!tc) return ENGINE_MESSAGES.invalidAction;
  if (slot.blindPair) return "No es pot girar fins que acabi la banca.";
  if (!tc.faceUp && slot.blindUntilBankEnd) return "No es pot girar aquesta carta encara.";
  if (tc.faceUp) return "Aquesta carta ja està destapada.";
  tc.faceUp = true;
  return null;
}

/** Whether the client may offer «Destapar carta per als rivals» for this hand slot. */
export function canRevealCardsToRivals(
  slot: Pick<HandSlotView, "blindPair" | "blindUntilBankEnd">,
): boolean {
  return !slot.blindPair && !slot.blindUntilBankEnd;
}


