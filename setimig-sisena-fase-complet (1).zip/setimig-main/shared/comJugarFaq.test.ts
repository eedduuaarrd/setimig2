import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { COM_JUGAR_FAQ, COM_JUGAR_FAQ_JSON_LD, COM_JUGAR_PATH } from "./comJugarFaq.ts";
import { SITE_ORIGIN } from "./seo.ts";

describe("FAQ de com jugar", () => {
  it("té entre 6 i 8 preguntes i un FAQPage en català", () => {
    assert.ok(COM_JUGAR_FAQ.length >= 6 && COM_JUGAR_FAQ.length <= 8);
    assert.equal(COM_JUGAR_FAQ_JSON_LD["@type"], "FAQPage");
    assert.equal(COM_JUGAR_FAQ_JSON_LD["@context"], "https://schema.org");
    assert.equal(COM_JUGAR_FAQ_JSON_LD.inLanguage, "ca");
    assert.equal(COM_JUGAR_FAQ_JSON_LD.url, `${SITE_ORIGIN}${COM_JUGAR_PATH}`);
    assert.equal(SITE_ORIGIN, "https://sevenhalf.club");
    assert.doesNotMatch(COM_JUGAR_FAQ_JSON_LD.url, /setimig\.supercbb\.com/);
    assert.equal(COM_JUGAR_FAQ_JSON_LD.mainEntity.length, COM_JUGAR_FAQ.length);

    for (let i = 0; i < COM_JUGAR_FAQ.length; i++) {
      const item = COM_JUGAR_FAQ[i];
      const entity = COM_JUGAR_FAQ_JSON_LD.mainEntity[i];
      assert.ok(item.question.length > 10);
      assert.ok(item.answer.length > 40);
      assert.equal(entity["@type"], "Question");
      assert.equal(entity.name, item.question);
      assert.equal(entity.acceptedAnswer["@type"], "Answer");
      assert.equal(entity.acceptedAnswer.text, item.answer);
      assert.doesNotMatch(item.answer, /premi en metàl|diners de veritat|apostes amb diners/i);
    }
  });

  it("deixa clar que no hi ha diners reals ni premis", () => {
    const money = COM_JUGAR_FAQ.find((item) => /diners reals/i.test(item.question + item.answer));
    assert.ok(money);
    assert.match(money.answer, /majors de 18/i);
    assert.match(money.answer, /sense diners reals ni premis|no hi ha diners reals ni premis/i);
    assert.match(money.answer, /virtuals/i);
  });
});
