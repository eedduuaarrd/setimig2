import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { maxBet, type MaxBetState } from "./bankRotation.ts";
import {
  advanceRisingBlindsAfterHand,
  buildRisingBlindLevels,
  currentRisingBlindMinBet,
  initialRisingBlindsState,
} from "./risingBlinds.ts";
import { resolvePrivateTableLimits, resolveTableBetProfile } from "./tableBetProfiles.ts";
import { buildRoomWagerConfig, tickRisingBlindsOnRoom } from "./roomWagerConfig.ts";
import { FAST_TOURNAMENT_START_CHIPS, roomUsesIsolatedPlayChips } from "./fastTournament.ts";

describe("fase3 perfils i cegues", () => {
  it("perfils d'aposta resolen min/max vàlids", () => {
    const mitja = resolveTableBetProfile("mitja");
    assert.ok(mitja);
    const limits = resolvePrivateTableLimits({ betProfileId: "mitja" });
    assert.deepEqual(limits, { minBet: 100, maxBet: 1_000 });
  });

  it("cegues pujants augmenten minBet cada N mans", () => {
    const levels = buildRisingBlindLevels(100, 1_000);
    assert.ok(levels.length >= 2);
    let state = initialRisingBlindsState(levels);
    const opts = { enabled: true, handsPerLevel: 2 };
    assert.equal(currentRisingBlindMinBet(state), 100);
    let r = advanceRisingBlindsAfterHand(state, opts);
    assert.equal(r.minBet, 100);
    r = advanceRisingBlindsAfterHand(r.state, opts);
    assert.ok(r.advancedLevel);
    assert.ok(r.minBet > 100);
  });

  it("maxBet respecta tableMaxBet del perfil", () => {
    const limits = resolvePrivateTableLimits({ betProfileId: "baix" })!;
    const state: MaxBetState = {
      minBet: limits.minBet,
      tableMaxBet: limits.maxBet,
      players: [
        { id: "b", isBanker: true, chips: 50_000 },
        { id: "p", isBanker: false, chips: 5_000 },
      ],
    };
    const cap = maxBet(state, "p");
    assert.ok(cap <= limits.maxBet);
    assert.ok(cap >= limits.minBet);
  });

  it("torneig ràpid aïlla el saldo real", () => {
    assert.equal(roomUsesIsolatedPlayChips({ fastTournament: true }), true);
    assert.equal(roomUsesIsolatedPlayChips({ practiceMode: false }), false);
    const cfg = buildRoomWagerConfig({
      betProfileId: "mitja",
      fastTournament: { enabled: true },
    });
    assert.ok(cfg);
    assert.equal(cfg.fastTournament.enabled, true);
    assert.equal(cfg.risingBlindsOptions.enabled, true);
    assert.equal(FAST_TOURNAMENT_START_CHIPS, 2_000);
  });

  it("tickRisingBlindsOnRoom actualitza la sala", () => {
    const cfg = buildRoomWagerConfig({
      betProfileId: "baix",
      risingBlinds: { enabled: true, handsPerLevel: 1 },
    })!;
    const room = {
      minBet: cfg.effectiveMinBet,
      tableMaxBet: cfg.limits.maxBet,
      risingBlindsOptions: cfg.risingBlindsOptions,
      risingBlinds: cfg.risingBlindsState,
    };
    const before = room.minBet;
    tickRisingBlindsOnRoom(room);
    assert.ok(room.minBet >= before);
  });
});
