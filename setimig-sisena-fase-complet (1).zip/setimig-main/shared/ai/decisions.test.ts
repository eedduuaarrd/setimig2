import assert from "node:assert/strict";
import { describe, it } from "node:test";
import type { Card } from "../../src/gameTypes.ts";
import {
  decideHitOrStandByDifficulty,
  decideHitOrStandEasy,
  decideHitOrStandHard,
  decideHitOrStandNormal,
} from "./decisions.ts";
import type { StrategyContext } from "./strategy.ts";

function card(value: number): Card {
  const points = value >= 10 ? 0.5 : value;
  return { suit: "hearts", value, points };
}

function baseCtx(overrides: Partial<StrategyContext> = {}): StrategyContext {
  return {
    seen: [],
    hand: [card(2)],
    minBet: 100,
    chips: 5000,
    bet: 100,
    rivalVisibleMax: 6,
    bankerTargetScores: [],
    isBanker: false,
    mortOffered: false,
    canDouble: false,
    canSplit: false,
    blindPair: false,
    ...overrides,
  };
}

describe("decideHitOrStandNormal", () => {
  it("hits on very low total", () => {
    assert.equal(decideHitOrStandNormal(baseCtx({ hand: [card(2)] })), "hit");
  });

  it("uses the exact one-card win probability near the hit threshold", () => {
    const seen = [card(10), card(6)];
    for (const [value, count] of [[1, 6], [2, 8], [3, 7], [4, 5], [5, 4], [6, 7], [7, 5], [10, 8]] as const) {
      for (let i = 0; i < count; i++) seen.push(card(value));
    }

    assert.equal(
      decideHitOrStandNormal(
        baseCtx({
          hand: [card(10), card(6)],
          seen,
          rivalVisibleMax: 7,
        })
      ),
      "stand"
    );
  });

  it("stands on 7.5", () => {
    assert.equal(decideHitOrStandNormal(baseCtx({ hand: [card(7), card(10)] })), "stand");
  });
});

describe("decideHitOrStandHard", () => {
  it("stands when already beating rivals with bust risk", () => {
    const ctx = baseCtx({
      hand: [card(6), card(10)],
      rivalVisibleMax: 5,
    });
    assert.equal(decideHitOrStandHard(ctx), "stand");
  });

  it("hits when below target and bust odds are low", () => {
    const ctx = baseCtx({
      hand: [card(3)],
      rivalVisibleMax: 6.5,
    });
    assert.equal(decideHitOrStandHard(ctx), "hit");
  });

  it("banker stands when beating visible targets", () => {
    const ctx = baseCtx({
      hand: [card(6), card(10)],
      isBanker: true,
      bankerTargetScores: [5, 5.5],
      rivalVisibleMax: 0,
    });
    assert.equal(decideHitOrStandHard(ctx), "stand");
  });
});

describe("decideHitOrStandEasy", () => {
  it("can stand incorrectly on low totals with unlucky rng", () => {
    let i = 0;
    const rng = () => {
      const seq = [0.01, 0.99];
      return seq[i++] ?? 0.99;
    };
    assert.equal(decideHitOrStandEasy(baseCtx({ hand: [card(2)] }), rng), "stand");
  });

  it("matches normal when rng never flips", () => {
    const ctx = baseCtx({ hand: [card(7), card(10)] });
    assert.equal(decideHitOrStandEasy(ctx, () => 0.99), decideHitOrStandNormal(ctx));
  });
});

describe("decideHitOrStandByDifficulty", () => {
  it("routes to hard logic", () => {
    const ctx = baseCtx({ hand: [card(6), card(10)], rivalVisibleMax: 5 });
    assert.equal(decideHitOrStandByDifficulty(ctx, "hard"), "stand");
  });

  it("routes to easy with rng", () => {
    let i = 0;
    const rng = () => {
      const seq = [0.01, 0.99];
      return seq[i++] ?? 0.99;
    };
    const ctx = baseCtx({ hand: [card(2)] });
    assert.equal(decideHitOrStandByDifficulty(ctx, "easy", rng), "stand");
  });
});
