import type { Card } from "../../src/gameTypes.ts";

/** Point values in one Spanish 40-card deck (figures = 0.5). */
export function singleDeckPointHistogram(): Map<number, number> {
  const m = new Map<number, number>();
  for (let v = 1; v <= 7; v++) m.set(v, 4);
  m.set(0.5, 12);
  return m;
}

/**
 * Full shoe histogram by card points. The engine plays with a single 40-card deck
 * (`createSingleSpanishDeck`), so the shoe is exactly one deck.
 */
export function fullShoeHistogram(): Map<number, number> {
  return singleDeckPointHistogram();
}

export function cardPoints(card: Card): number {
  return card.points;
}

/** Subtract one card from histogram; returns false if not available. */
export function subtractCard(hist: Map<number, number>, card: Card): boolean {
  const p = cardPoints(card);
  const n = hist.get(p) ?? 0;
  if (n <= 0) return false;
  if (n === 1) hist.delete(p);
  else hist.set(p, n - 1);
  return true;
}

/** Build remaining histogram from shoe minus known cards. */
export function remainingFromSeen(seen: Card[]): Map<number, number> {
  const hist = fullShoeHistogram();
  for (const c of seen) subtractCard(hist, c);
  return hist;
}

export function histogramTotal(hist: Map<number, number>): number {
  let t = 0;
  for (const c of hist.values()) t += c;
  return t;
}

/** Expand histogram to array of point values for sampling. */
export function histogramToPoints(hist: Map<number, number>): number[] {
  const out: number[] = [];
  for (const [p, count] of hist) {
    for (let i = 0; i < count; i++) out.push(p);
  }
  return out;
}

export function copyHistogram(hist: Map<number, number>): Map<number, number> {
  return new Map(hist);
}
