import type { Card } from "../../src/gameTypes.ts";
import { scoreCards } from "../scoring.ts";
import {
  copyHistogram,
  histogramTotal,
  remainingFromSeen,
  subtractCard,
} from "./deck.ts";

export type PlayerActionKind = "hit" | "stand" | "double" | "split" | "mort_accept" | "mort_decline";

export interface VisibleHand {
  cards: Card[];
  /** Face-down count we know exists but not values (rivals). */
  hiddenRivalDownCount: number;
}

export interface StrategyContext {
  seen: Card[];
  hand: Card[];
  minBet: number;
  chips: number;
  bet: number;
  /** Best rival visible score (non-banker), for player decisions. */
  rivalVisibleMax: number;
  /** Scores banker must beat (visible + known), for banker. */
  bankerTargetScores: number[];
  isBanker: boolean;
  mortOffered: boolean;
  canDouble: boolean;
  canSplit: boolean;
  blindPair: boolean;
}

const BUST = 7.5;

function wouldBust(current: number, draw: number): boolean {
  return current + draw > BUST;
}

/** Exact P(bust on one draw) from remaining histogram. */
export function probBustOneDraw(currentScore: number, hist: Map<number, number>): number {
  const total = histogramTotal(hist);
  if (total === 0) return 0;
  let bust = 0;
  for (const [p, count] of hist) {
    if (wouldBust(currentScore, p)) bust += count;
  }
  return bust / total;
}

/** Expected score after one hit (capped at bust as 0 value for stand comparison). */
export function expectedScoreAfterHit(currentScore: number, hist: Map<number, number>): number {
  const total = histogramTotal(hist);
  if (total === 0) return currentScore;
  let sum = 0;
  for (const [p, count] of hist) {
    const next = currentScore + p;
    sum += count * (next > BUST ? 0 : next);
  }
  return sum / total;
}

function oneDrawWinRate(hand: Card[], hist: Map<number, number>, targetToBeat: number): number {
  const total = histogramTotal(hist);
  const score = scoreCards(hand.map((c) => ({ card: c })));
  if (total === 0) return score > targetToBeat && score <= BUST ? 1 : 0;

  let wins = 0;
  for (const [points, count] of hist) {
    const next = score + points;
    if (next <= BUST && next > targetToBeat) wins += count;
  }
  return wins / total;
}

function decideHitStandPlayer(ctx: StrategyContext): "hit" | "stand" {
  const hist = remainingFromSeen(ctx.seen);
  const score = scoreCards(ctx.hand.map((c) => ({ card: c })));
  if (score >= BUST) return "stand";
  if (score === BUST) return "stand";

  const target = Math.max(ctx.rivalVisibleMax, 5);
  const pBust = probBustOneDraw(score, hist);
  const pWinHit = oneDrawWinRate(ctx.hand, hist, target);
  const pWinStand = score > target && score <= BUST ? 1 : score === target ? 0.45 : 0;

  if (score <= 4) return "hit";
  if (score >= 7) return "stand";
  if (pBust > 0.55) return "stand";
  if (pWinHit > pWinStand + 0.08) return "hit";
  if (score >= 6.5 && pBust > 0.35) return "stand";
  return score < 6 ? "hit" : "stand";
}

function decideHitStandBanker(ctx: StrategyContext): "hit" | "stand" {
  const hist = remainingFromSeen(ctx.seen);
  const score = scoreCards(ctx.hand.map((c) => ({ card: c })));
  if (score >= BUST) return "stand";
  const target = ctx.bankerTargetScores.length ? Math.max(...ctx.bankerTargetScores) : 5.5;
  if (score > target && score <= BUST) return "stand";
  if (score > BUST) return "stand";

  const pBust = probBustOneDraw(score, hist);
  const expHit = expectedScoreAfterHit(score, hist);

  if (score < 5) return "hit";
  if (score >= 7) return "stand";
  if (pBust > 0.42 && score >= target) return "stand";
  if (expHit > target && pBust < 0.5) return "hit";
  if (score < target) return "hit";
  return "stand";
}

export function decideHitOrStand(ctx: StrategyContext): "hit" | "stand" {
  if (ctx.blindPair) return "stand";
  if (ctx.isBanker) return decideHitStandBanker(ctx);
  return decideHitStandPlayer(ctx);
}

export function decideBetAmount(
  ctx: Pick<StrategyContext, "minBet" | "chips"> & { maxBet?: number }
): number {
  const { minBet, chips } = ctx;
  const hardCap = ctx.maxBet != null ? Math.min(chips, ctx.maxBet) : chips;
  if (hardCap < minBet) return 0;
  const cap = Math.min(hardCap, minBet * 5);
  if (chips >= minBet * 8) return Math.min(minBet * 2, cap);
  return Math.min(minBet, cap);
}

export function decideMort(ctx: StrategyContext): boolean {
  const score = scoreCards(ctx.hand.map((c) => ({ card: c })));
  if (score !== 7) return false;
  return ctx.chips < ctx.minBet * 15;
}

export function decideDouble(ctx: StrategyContext): boolean {
  if (!ctx.canDouble || ctx.hand.length !== 1) return false;
  const visible = scoreCards(ctx.hand.map((c) => ({ card: c })));
  if (visible < 4 || visible > 5.5) return false;
  return ctx.chips >= ctx.bet;
}

export function decideSplit(ctx: StrategyContext): boolean {
  if (!ctx.canSplit || ctx.hand.length !== 2) return false;
  return ctx.chips >= ctx.bet;
}

/** Collect publicly visible cards from table state for counting. */
export function gatherSeenCards(input: {
  centerDiscard: Card[];
  players: {
    isBanker: boolean;
    handSlots: { cards: { card: Card; faceUp: boolean }[] }[];
  }[];
  selfId: string;
  selfSlots: { cards: { card: Card; faceUp: boolean }[] }[];
}): Card[] {
  const seen: Card[] = [...input.centerDiscard];
  for (const p of input.players) {
    for (const slot of p.handSlots) {
      for (const tc of slot.cards) {
        if (tc.faceUp) seen.push(tc.card);
      }
    }
  }
  for (const slot of input.selfSlots) {
    for (const tc of slot.cards) {
      if (!tc.faceUp) seen.push(tc.card);
    }
  }
  return seen;
}

export function maxRivalVisibleScore(
  players: { id: string; isBanker: boolean; handSlots: { cards: { card: Card; faceUp: boolean }[] }[] }[],
  selfId: string
): number {
  let max = 0;
  for (const p of players) {
    if (p.id === selfId) continue;
    for (const slot of p.handSlots) {
      const vis = slot.cards.filter((c) => c.faceUp).map((c) => ({ card: c.card }));
      const sc = scoreCards(vis);
      if (sc > max && sc <= BUST) max = sc;
    }
  }
  return max;
}

export function bankerTargetScores(
  players: { isBanker: boolean; handSlots: { cards: { card: Card; faceUp: boolean }[]; status: string }[] }[]
): number[] {
  const out: number[] = [];
  for (const p of players) {
    if (p.isBanker) continue;
    for (const slot of p.handSlots) {
      if (slot.status === "busted") continue;
      const vis = slot.cards.filter((c) => c.faceUp).map((c) => ({ card: c.card }));
      const sc = scoreCards(vis);
      if (sc > 0 && sc <= BUST) out.push(sc);
      else if (vis.length === 0) out.push(4);
    }
  }
  return out.length ? out : [5.5];
}

/** Simulate drawing one card from histogram (mutates copy). */
export function drawFromHistogram(hist: Map<number, number>): number | null {
  const total = histogramTotal(hist);
  if (total === 0) return null;
  let pick = Math.floor(Math.random() * total);
  for (const [p, count] of hist) {
    if (pick < count) {
      subtractCard(hist, { suit: "clubs", value: 1, points: p } as Card);
      return p;
    }
    pick -= count;
  }
  return null;
}

export { copyHistogram, remainingFromSeen };
