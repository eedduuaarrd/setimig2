import { scoreCards } from "../scoring.ts";
import type { BotDifficulty } from "./botDifficulty.ts";
import { decideHitOrStandByDifficulty, type DecisionRng } from "./decisions.ts";
import { probBustOneDraw, remainingFromSeen, type StrategyContext } from "./strategy.ts";

/**
 * Personalitat de cada bot: modula lleugerament la decisió base (per dificultat) segons el
 * risc de passar-se (baralla única, `probBustOneDraw`) i una mica d'atzar acotat.
 * Mai fa res absurd: sempre demana per sota de MIN_STAND_SCORE i mai demana a partir de
 * MAX_HIT_SCORE (7 o 7½).
 */
export type BotProfile = "prudent" | "normal" | "agosarat";

export const BOT_PROFILES: readonly BotProfile[] = ["prudent", "normal", "agosarat"];

/** Per sota d'aquest total el bot sempre demana carta (mai es planta amb 3½ o menys). */
export const MIN_STAND_SCORE = 4;
/** A partir d'aquest total el bot mai demana carta (7 i 7½). */
export const MAX_HIT_SCORE = 7;

export interface BotProfileParams {
  /** En zona grisa (≥ 4½) es planta si el risc de passar-se supera aquest valor. */
  maxBustToHit: number;
  /** Per sota de `pushBelow`, demana encara que la base es plantés si el risc és menor que això. */
  pushBust: number;
  pushBelow: number;
  /** Soroll uniforme ± sobre el risc percebut (decisions menys robòtiques). */
  jitter: number;
  /** Doblar només amb la carta visible dins [min, max]; `chance` per a l'interval «normal». */
  double: { min: number; max: number; chance: number; edgeChance: number; chipsBetMultiple: number };
  /** Probabilitat de separar una parella quan és possible. */
  splitChance: number;
  splitChipsBetMultiple: number;
  /** Accepta el «mort» amb 7 si té menys fitxes que aquest múltiple de l'aposta mínima. */
  mortChipsMinBets: number;
}

export const BOT_PROFILE_PARAMS: Readonly<Record<BotProfile, BotProfileParams>> = {
  prudent: {
    maxBustToHit: 0.42,
    pushBust: 0,
    pushBelow: 0,
    jitter: 0.05,
    double: { min: 4, max: 5, chance: 0.6, edgeChance: 0, chipsBetMultiple: 3 },
    splitChance: 0.7,
    splitChipsBetMultiple: 3,
    mortChipsMinBets: 25,
  },
  normal: {
    maxBustToHit: 0.56,
    pushBust: 0.3,
    pushBelow: 5.5,
    jitter: 0.05,
    double: { min: 4, max: 5, chance: 0.9, edgeChance: 0, chipsBetMultiple: 1 },
    splitChance: 0.9,
    splitChipsBetMultiple: 1,
    mortChipsMinBets: 15,
  },
  agosarat: {
    maxBustToHit: 0.7,
    pushBust: 0.56,
    pushBelow: 6,
    jitter: 0.05,
    double: { min: 4, max: 5, chance: 1, edgeChance: 0.5, chipsBetMultiple: 1 },
    splitChance: 1,
    splitChipsBetMultiple: 1,
    mortChipsMinBets: 8,
  },
};

/** FNV-1a de 32 bits: perfil estable per a un mateix nom de bot (i per tant per a tota la partida). */
function hash32(s: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return h >>> 0;
}

export function botProfileFor(nameOrSeat: string): BotProfile {
  return BOT_PROFILES[hash32(`setimig-bot:${nameOrSeat.trim().toLowerCase()}`) % BOT_PROFILES.length];
}

/** RNG reproduïble (mulberry32) per a tests i simulacions. */
export function seededRng(seed: number): DecisionRng {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4_294_967_296;
  };
}

let injectedRng: DecisionRng | null = null;

/** RNG de les decisions i del ritme dels bots: `Math.random` en producció. */
export function botRng(): number {
  return (injectedRng ?? Math.random)();
}

/** Només per a tests: fixa (o treu, amb null) el RNG dels bots. Ignorat en producció. */
export function setBotRngForTests(rng: DecisionRng | null): void {
  if (typeof process !== "undefined" && process.env?.NODE_ENV === "production") return;
  injectedRng = rng;
}

function handScore(ctx: StrategyContext): number {
  return scoreCards(ctx.hand.map((c) => ({ card: c })));
}

export function decideBotHitOrStand(
  ctx: StrategyContext,
  difficulty: BotDifficulty,
  profile: BotProfile,
  rng: DecisionRng = botRng
): "hit" | "stand" {
  if (ctx.blindPair) return "stand";
  const score = handScore(ctx);
  if (score >= MAX_HIT_SCORE) return "stand";
  if (score < MIN_STAND_SCORE) return "hit";

  const base = decideHitOrStandByDifficulty(ctx, difficulty, rng);
  // La banca juga contra objectius coneguts: només s'hi apliquen els límits.
  if (ctx.isBanker) return base;

  const p = BOT_PROFILE_PARAMS[profile];
  const risk = probBustOneDraw(score, remainingFromSeen(ctx.seen)) + (rng() * 2 - 1) * p.jitter;
  if (base === "hit" && score >= 4.5 && risk > p.maxBustToHit) return "stand";
  if (base === "stand" && score < p.pushBelow && risk < p.pushBust) return "hit";
  return base;
}

export function decideBotDouble(ctx: StrategyContext, profile: BotProfile, rng: DecisionRng = botRng): boolean {
  // Només la primera carta, abans de demanar-ne cap altra. `canDouble` ja és canDoubleNow:
  // una mà separada no hi arriba (canDouble false). Amb més d'una carta tampoc no es dobla.
  if (!ctx.canDouble || ctx.hand.length !== 1) return false;
  const p = BOT_PROFILE_PARAMS[profile].double;
  if (ctx.chips < ctx.bet * p.chipsBetMultiple) return false;
  const visible = handScore(ctx);
  if (visible >= p.min && visible <= p.max) return rng() < p.chance;
  // Agosarat: de tant en tant dobla també amb 3 o 6 (mai amb figures, 1, 2 o 7).
  if ((visible === 3 || visible === 6) && p.edgeChance > 0) return rng() < p.edgeChance;
  return false;
}

export function decideBotSplit(ctx: StrategyContext, profile: BotProfile, rng: DecisionRng = botRng): boolean {
  if (!ctx.canSplit || ctx.hand.length !== 2) return false;
  const p = BOT_PROFILE_PARAMS[profile];
  if (ctx.chips < ctx.bet * p.splitChipsBetMultiple) return false;
  return rng() < p.splitChance;
}

export function decideBotMort(ctx: StrategyContext, profile: BotProfile): boolean {
  if (handScore(ctx) !== 7) return false;
  return ctx.chips < ctx.minBet * BOT_PROFILE_PARAMS[profile].mortChipsMinBets;
}
