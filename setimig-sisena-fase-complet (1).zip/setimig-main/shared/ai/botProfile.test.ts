import assert from "node:assert/strict";
import { afterEach, describe, it } from "node:test";
import type { Card } from "../../src/gameTypes.ts";
import { scoreCards } from "../scoring.ts";
import type { BotDifficulty } from "./botDifficulty.ts";
import {
  BOT_PROFILES,
  MAX_HIT_SCORE,
  MIN_STAND_SCORE,
  botProfileFor,
  botRng,
  decideBotDouble,
  decideBotHitOrStand,
  decideBotMort,
  decideBotSplit,
  seededRng,
  setBotRngForTests,
  type BotProfile,
} from "./botProfile.ts";
import type { StrategyContext } from "./strategy.ts";
import { randomBotPaceMs } from "../../server/bots.ts";

function card(value: number, suit: Card["suit"] = "hearts"): Card {
  return { suit, value, points: value >= 10 ? 0.5 : value };
}

function deck(): Card[] {
  const out: Card[] = [];
  for (const suit of ["hearts", "clubs", "swords", "coins"] as Card["suit"][]) {
    for (const v of [1, 2, 3, 4, 5, 6, 7, 10, 11, 12]) out.push(card(v, suit));
  }
  return out;
}

function ctx(hand: Card[], over: Partial<StrategyContext> = {}): StrategyContext {
  return {
    seen: [...hand],
    hand,
    minBet: 100,
    chips: 5000,
    bet: 100,
    rivalVisibleMax: 5,
    bankerTargetScores: [],
    isBanker: false,
    mortOffered: false,
    canDouble: false,
    canSplit: false,
    blindPair: false,
    ...over,
  };
}

function shuffle(cards: Card[], rng: () => number): Card[] {
  const a = [...cards];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

/** Juga moltes mans amb una baralla barrejada amb llavor i retorna el total mitjà en plantar-se. */
function simulate(profile: BotProfile, difficulty: BotDifficulty, hands: number, seed: number) {
  const rng = seededRng(seed);
  let standSum = 0;
  let stands = 0;
  let busts = 0;
  for (let h = 0; h < hands; h++) {
    const shoe = shuffle(deck(), rng);
    const hand: Card[] = [shoe.pop()!];
    for (;;) {
      const score = scoreCards(hand.map((c) => ({ card: c })));
      if (score > 7.5) {
        busts++;
        break;
      }
      if (decideBotHitOrStand(ctx([...hand]), difficulty, profile, rng) === "stand") {
        standSum += score;
        stands++;
        break;
      }
      hand.push(shoe.pop()!);
    }
  }
  return { meanStand: standSum / stands, bustRate: busts / hands };
}

afterEach(() => setBotRngForTests(null));

describe("perfils de bot", () => {
  it("assigna el perfil de manera determinista pel nom i en fa servir els tres", () => {
    const names = ["Laia", "Pau", "Núria", "Oriol", "Marta", "Jordi", "Clara", "Arnau", "Quim", "Roser", "Biel", "Martí", "Aina", "Pol", "Gemma"];
    const seen = new Set<BotProfile>();
    for (const n of names) {
      assert.equal(botProfileFor(n), botProfileFor(n));
      assert.equal(botProfileFor(n), botProfileFor(` ${n.toUpperCase()} `));
      seen.add(botProfileFor(n));
    }
    assert.deepEqual([...seen].sort(), [...BOT_PROFILES].sort());
  });

  for (const difficulty of ["easy", "normal", "hard"] as BotDifficulty[]) {
    it(`prudent es planta abans que agosarat de mitjana (${difficulty}, 4000 mans amb llavor)`, () => {
      const prudent = simulate("prudent", difficulty, 4000, 101);
      const normal = simulate("normal", difficulty, 4000, 101);
      const bold = simulate("agosarat", difficulty, 4000, 101);
      assert.ok(prudent.meanStand < bold.meanStand - 0.1, `prudent ${prudent.meanStand} vs agosarat ${bold.meanStand}`);
      assert.ok(prudent.meanStand <= normal.meanStand + 0.02, `prudent ${prudent.meanStand} vs normal ${normal.meanStand}`);
      assert.ok(normal.meanStand <= bold.meanStand + 0.02, `normal ${normal.meanStand} vs agosarat ${bold.meanStand}`);
      assert.ok(prudent.bustRate < bold.bustRate, `bust prudent ${prudent.bustRate} vs agosarat ${bold.bustRate}`);
    });
  }

  it("la mateixa llavor dona les mateixes decisions", () => {
    assert.deepEqual(simulate("normal", "easy", 300, 7), simulate("normal", "easy", 300, 7));
  });

  it("límits: mai es planta per sota de 4 ni demana amb 7 o 7½ (tots els perfils, dificultats i RNG)", () => {
    const rng = seededRng(9);
    const singles = [1, 2, 3, 4, 5, 6, 7, 10];
    const hands: Card[][] = [];
    for (const a of singles) {
      hands.push([card(a)]);
      for (const b of singles) hands.push([card(a), card(b, "clubs")]);
    }
    for (const profile of BOT_PROFILES) {
      for (const difficulty of ["easy", "normal", "hard"] as BotDifficulty[]) {
        for (const isBanker of [false, true]) {
          for (const hand of hands) {
            const score = scoreCards(hand.map((c) => ({ card: c })));
            if (score > 7.5) continue;
            for (const rival of [0, 4, 5.5, 7, 7.5]) {
              for (let k = 0; k < 6; k++) {
                const a = decideBotHitOrStand(
                  ctx(hand, { rivalVisibleMax: rival, isBanker, bankerTargetScores: isBanker ? [rival || 5.5] : [] }),
                  difficulty,
                  profile,
                  rng
                );
                if (score < MIN_STAND_SCORE) assert.equal(a, "hit", `${profile}/${difficulty} es planta amb ${score}`);
                if (score >= MAX_HIT_SCORE) assert.equal(a, "stand", `${profile}/${difficulty} demana amb ${score}`);
              }
            }
          }
        }
      }
    }
  });

  it("parella cega: sempre es planta", () => {
    for (const profile of BOT_PROFILES) {
      assert.equal(decideBotHitOrStand(ctx([card(2)], { blindPair: true }), "easy", profile, () => 0), "stand");
    }
  });

  it("doblar: respecta canDouble i les fitxes; agosarat dobla més sovint que prudent", () => {
    for (const profile of BOT_PROFILES) {
      assert.equal(decideBotDouble(ctx([card(4)], { canDouble: false }), profile, () => 0), false);
      assert.equal(decideBotDouble(ctx([card(4)], { canDouble: true, chips: 50 }), profile, () => 0), false);
      for (const v of [1, 2, 7, 10]) assert.equal(decideBotDouble(ctx([card(v)], { canDouble: true }), profile, () => 0), false);
    }
    const count = (profile: BotProfile) => {
      const rng = seededRng(3);
      let n = 0;
      for (let i = 0; i < 2000; i++) {
        for (const v of [3, 4, 5, 6]) if (decideBotDouble(ctx([card(v)], { canDouble: true }), profile, rng)) n++;
      }
      return n;
    };
    assert.ok(count("prudent") < count("normal"));
    assert.ok(count("normal") < count("agosarat"));
  });

  it("no dobla amb més d'una carta, encara que canDouble sigui cert", () => {
    const splitHand = [card(10), card(4)];
    assert.equal(decideBotDouble(ctx(splitHand, { canDouble: true }), "normal", () => 0), false);
    assert.equal(decideBotDouble(ctx(splitHand, { canDouble: false }), "normal", () => 0), false);
    assert.equal(decideBotDouble(ctx([card(10), card(10)], { canDouble: true }), "agosarat", () => 0), false);
    assert.equal(
      decideBotDouble(ctx([card(4), card(1), card(1)], { canDouble: true }), "normal", () => 0),
      false,
    );
    assert.equal(decideBotDouble(ctx([card(4)], { canDouble: true }), "normal", () => 0), true);
  });

  it("separar i mort varien pel perfil", () => {
    for (const profile of BOT_PROFILES) {
      assert.equal(decideBotSplit(ctx([card(5), card(5)], { canSplit: false }), profile, () => 0), false);
      assert.equal(decideBotSplit(ctx([card(5), card(5)], { canSplit: true, chips: 50 }), profile, () => 0), false);
      assert.equal(decideBotMort(ctx([card(6)]), profile), false);
    }
    assert.equal(decideBotSplit(ctx([card(5), card(5)], { canSplit: true }), "prudent", () => 0.8), false);
    assert.equal(decideBotSplit(ctx([card(5), card(5)], { canSplit: true }), "agosarat", () => 0.8), true);
    const seven = ctx([card(7)], { chips: 2000, minBet: 100 });
    assert.equal(decideBotMort(seven, "prudent"), true);
    assert.equal(decideBotMort(seven, "normal"), false);
    assert.equal(decideBotMort(ctx([card(7)], { chips: 1000, minBet: 100 }), "normal"), true);
    assert.equal(decideBotMort(ctx([card(7)], { chips: 1000, minBet: 100 }), "agosarat"), false);
  });
});

describe("ritme dels bots", () => {
  it("la pausa entre accions sempre és 1,2–1,5 s fora del mode de tests ràpids", () => {
    const prev = process.env.SETIMIG_TEST_FAST;
    delete process.env.SETIMIG_TEST_FAST;
    try {
      assert.equal(randomBotPaceMs(() => 0), 1200);
      assert.equal(randomBotPaceMs(() => 0.999_999_9), 1500);
      assert.equal(randomBotPaceMs(() => 1), 1500);
      const rng = seededRng(5);
      const seen = new Set<number>();
      for (let i = 0; i < 5000; i++) {
        const ms = randomBotPaceMs(rng);
        assert.ok(ms >= 1200 && ms <= 1500, `pausa fora de rang: ${ms}`);
        seen.add(Math.floor(ms / 100));
      }
      assert.ok(seen.size >= 3, "la pausa ha de variar dins del rang");
      setBotRngForTests(() => 0.5);
      assert.equal(botRng(), 0.5);
      assert.equal(randomBotPaceMs(), 1350);
    } finally {
      if (prev === undefined) delete process.env.SETIMIG_TEST_FAST;
      else process.env.SETIMIG_TEST_FAST = prev;
    }
  });
});
