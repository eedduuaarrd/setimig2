import { describe, it } from "node:test";
import { strict as assert } from "node:assert";
import { botBetWithMemory } from "./botBet.ts";
const basic = {minBet:100,chips:10000,maxBet:10000,lastBetAmount:200};
describe("fourth phase bot bet and bankroll",()=>{
 it("different strategies produce stable bet sizes",()=>{
  assert.equal(botBetWithMemory({...basic,profile:"prudent"}),100);
  assert.equal(botBetWithMemory({...basic,profile:"normal"}),200);
  assert.equal(botBetWithMemory({...basic,profile:"agosarat"}),200);
 });
 it("previous stake informs bold bot within strict limits",()=>{
  assert.equal(botBetWithMemory({...basic,lastBetAmount:1000,profile:"agosarat"}),300);
 });
 it("never bets beyond coverage or chips",()=>{
  for (const profile of ["prudent","normal","agosarat"] as const) {
   const amount=botBetWithMemory({...basic, chips:150, maxBet:120,profile});
   assert.ok(amount>=100 && amount<=120);
   assert.equal(botBetWithMemory({...basic, chips:60,profile}),0);
  }
 });
});
