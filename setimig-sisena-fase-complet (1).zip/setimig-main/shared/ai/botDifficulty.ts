export type BotDifficulty = "easy" | "normal" | "hard";

export const BOT_DIFFICULTIES: BotDifficulty[] = ["easy", "normal", "hard"];

export const DEFAULT_BOT_DIFFICULTY: BotDifficulty = "normal";

export function isBotDifficulty(value: string): value is BotDifficulty {
  return value === "easy" || value === "normal" || value === "hard";
}
