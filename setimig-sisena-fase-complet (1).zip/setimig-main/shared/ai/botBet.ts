import type { BotProfile } from "./botProfile.ts";
/** Deterministic risk-aware bot stakes. Previous bet provides bounded memory across hands.
 * This uses only the bot's own chips/bet history, never private opponent cards. */
export function botBetWithMemory(input: {
  minBet: number; chips: number; maxBet: number; lastBetAmount?: number | null; profile: BotProfile;
}): number {
  const { minBet, chips, maxBet, profile } = input;
  const cap = Math.min(Math.max(0, chips), Math.max(0, maxBet));
  if (!Number.isFinite(cap) || minBet <= 0 || cap < minBet) return 0;
  const ownHistory = Number.isFinite(input.lastBetAmount) ? (input.lastBetAmount ?? minBet) : minBet;
  const prior = Math.max(minBet, Math.min(ownHistory, minBet * 4));
  const desired = profile === "prudent" ? minBet
    : profile === "agosarat" ? Math.max(minBet * 2, Math.min(minBet * 3, prior))
    : Math.min(minBet * 2, Math.max(minBet, prior));
  const bankrollLimit = profile === "agosarat" ? chips * 0.35 : profile === "normal" ? chips * 0.25 : chips * 0.15;
  const step = Math.max(1, minBet);
  const maxSafe = Math.min(cap, Math.max(minBet, Math.floor(bankrollLimit / step) * step));
  return Math.min(maxSafe, Math.max(minBet, Math.floor(desired / step) * step));
}
