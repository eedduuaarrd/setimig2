import type { StrategyContext } from "./strategy.ts";
import {
  decideHitOrStand as decideHitOrStandBaseline,
  expectedScoreAfterHit,
  probBustOneDraw,
  remainingFromSeen,
} from "./strategy.ts";
import { scoreCards } from "../scoring.ts";
import type { BotDifficulty } from "./botDifficulty.ts";

const BUST = 7.5;

export type DecisionRng = () => number;

function decideHitStandHard(ctx: StrategyContext): "hit" | "stand" {
  const hist = remainingFromSeen(ctx.seen);
  const score = scoreCards(ctx.hand.map((c) => ({ card: c })));
  if (score >= BUST || ctx.blindPair) return "stand";

  const target = ctx.isBanker
    ? ctx.bankerTargetScores.length
      ? Math.max(...ctx.bankerTargetScores)
      : 5.5
    : Math.max(ctx.rivalVisibleMax, 5);

  const pBust = probBustOneDraw(score, hist);
  const expAfterHit = expectedScoreAfterHit(score, hist);

  if (!ctx.isBanker && score >= 6.5 && score <= BUST && score >= target) {
    return "stand";
  }
  if (!ctx.isBanker && score >= 7 && score <= BUST) {
    return "stand";
  }

  if (score > target && score <= BUST) {
    if (pBust < 0.1 && expAfterHit > score + 0.3) return "hit";
    return "stand";
  }

  if (score < target) {
    if (pBust <= 0.28) return "hit";
    if (pBust <= 0.42 && expAfterHit >= target - 0.1) return "hit";
    return pBust > 0.45 ? "stand" : "hit";
  }

  if (pBust > 0.4) return "stand";
  if (expAfterHit > score + 0.2 && pBust < 0.38) return "hit";
  return "stand";
}

function decideHitStandEasy(ctx: StrategyContext, rng: DecisionRng): "hit" | "stand" {
  const score = scoreCards(ctx.hand.map((c) => ({ card: c })));
  if (score >= BUST || ctx.blindPair) return "stand";

  let action = decideHitOrStandBaseline(ctx);

  if (score <= 4 && rng() < 0.22) action = "stand";
  if (score >= 6 && score < 7.5 && rng() < 0.32) action = "hit";
  if (rng() < 0.26) action = action === "hit" ? "stand" : "hit";

  return action;
}

export function decideHitOrStandEasy(ctx: StrategyContext, rng: DecisionRng = Math.random): "hit" | "stand" {
  return decideHitStandEasy(ctx, rng);
}

export function decideHitOrStandNormal(ctx: StrategyContext): "hit" | "stand" {
  const base = decideHitOrStandBaseline(ctx);
  if (ctx.isBanker || ctx.blindPair) return base;
  const score = scoreCards(ctx.hand.map((c) => ({ card: c })));
  if (score >= BUST) return "stand";
  const noise =
    (ctx.hand.reduce((s, c) => s + c.value * 17, ctx.seen.length * 13) + Math.round(ctx.rivalVisibleMax * 31)) %
    100;
  if (score >= 5.5 && score < 7.5 && noise < 10) {
    return base === "hit" ? "stand" : "hit";
  }
  return base;
}

export function decideHitOrStandHard(ctx: StrategyContext): "hit" | "stand" {
  return decideHitStandHard(ctx);
}

export function decideHitOrStandByDifficulty(
  ctx: StrategyContext,
  difficulty: BotDifficulty,
  rng: DecisionRng = Math.random
): "hit" | "stand" {
  switch (difficulty) {
    case "easy":
      return decideHitOrStandEasy(ctx, rng);
    case "hard":
      return decideHitOrStandHard(ctx);
    default:
      return decideHitOrStandNormal(ctx);
  }
}
