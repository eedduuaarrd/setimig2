export const DEFAULT_RISING_BLINDS_HANDS_PER_LEVEL = 3;
export const MIN_RISING_BLINDS_HANDS_PER_LEVEL = 1;
export const MAX_RISING_BLINDS_HANDS_PER_LEVEL = 20;

export type RisingBlindsOptions = {
  enabled: boolean;
  handsPerLevel: number;
};

export type RisingBlindsState = {
  levelIndex: number;
  handsAtLevel: number;
  /** Nivells d'aposta mínima (generats a partir del perfil de taula). */
  levels: number[];
};

export type RisingBlindsView = {
  enabled: boolean;
  levelIndex: number;
  handsAtLevel: number;
  handsPerLevel: number;
  currentMinBet: number;
  nextMinBet: number | null;
  handsUntilNextLevel: number;
};

function clampInt(n: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, Math.floor(n)));
}

/** Genera la taula de nivells entre minBet i maxBet de la taula. */
export function buildRisingBlindLevels(minBet: number, maxBet: number): number[] {
  const levels: number[] = [];
  let cur = Math.max(1, Math.floor(minBet));
  const cap = Math.max(cur, Math.floor(maxBet));
  while (cur <= cap && levels.length < 24) {
    levels.push(cur);
    if (cur >= cap) break;
    const step = Math.max(1, Math.floor(cur * 0.5));
    const next = cur + step;
    cur = next > cap ? cap : next;
    if (levels.length > 0 && levels[levels.length - 1] === cur) break;
  }
  if (levels.length === 0) levels.push(Math.max(1, minBet));
  return levels;
}

export function normalizeRisingBlindsOptions(raw: unknown): RisingBlindsOptions | null {
  if (raw === undefined || raw === null) {
    return { enabled: false, handsPerLevel: DEFAULT_RISING_BLINDS_HANDS_PER_LEVEL };
  }
  if (typeof raw !== "object" || Array.isArray(raw)) return null;
  const input = raw as Record<string, unknown>;
  let enabled = false;
  if (input.enabled !== undefined) {
    if (typeof input.enabled !== "boolean") return null;
    enabled = input.enabled;
  }
  let handsPerLevel = DEFAULT_RISING_BLINDS_HANDS_PER_LEVEL;
  if (input.handsPerLevel !== undefined) {
    const n = Number(input.handsPerLevel);
    if (!Number.isFinite(n)) return null;
    handsPerLevel = clampInt(n, MIN_RISING_BLINDS_HANDS_PER_LEVEL, MAX_RISING_BLINDS_HANDS_PER_LEVEL);
  }
  return { enabled, handsPerLevel };
}

export function initialRisingBlindsState(levels: number[]): RisingBlindsState {
  const safe = levels.length > 0 ? levels : [100];
  return { levelIndex: 0, handsAtLevel: 0, levels: [...safe] };
}

export function currentRisingBlindMinBet(state: RisingBlindsState): number {
  const idx = clampInt(state.levelIndex, 0, state.levels.length - 1);
  return state.levels[idx] ?? state.levels[0] ?? 100;
}

export function nextRisingBlindMinBet(state: RisingBlindsState): number | null {
  const nextIdx = state.levelIndex + 1;
  if (nextIdx >= state.levels.length) return null;
  return state.levels[nextIdx] ?? null;
}

export type AdvanceRisingBlindsResult = {
  state: RisingBlindsState;
  minBet: number;
  advancedLevel: boolean;
};

/** Cridat després de cada mà quan les cegues pujants estan actives. */
export function advanceRisingBlindsAfterHand(
  state: RisingBlindsState,
  options: RisingBlindsOptions
): AdvanceRisingBlindsResult {
  if (!options.enabled) {
    return { state, minBet: currentRisingBlindMinBet(state), advancedLevel: false };
  }
  let { levelIndex, handsAtLevel, levels } = state;
  handsAtLevel += 1;
  let advancedLevel = false;
  if (handsAtLevel >= options.handsPerLevel && levelIndex < levels.length - 1) {
    levelIndex += 1;
    handsAtLevel = 0;
    advancedLevel = true;
  }
  const next: RisingBlindsState = { levelIndex, handsAtLevel, levels };
  return { state: next, minBet: currentRisingBlindMinBet(next), advancedLevel };
}

export function risingBlindsToView(
  state: RisingBlindsState | undefined,
  options: RisingBlindsOptions | undefined,
  fallbackMinBet: number
): RisingBlindsView | null {
  if (!options?.enabled || !state) return null;
  const currentMinBet = currentRisingBlindMinBet(state);
  const nextMin = nextRisingBlindMinBet(state);
  const handsUntilNextLevel =
    nextMin == null ? 0 : Math.max(0, options.handsPerLevel - state.handsAtLevel);
  return {
    enabled: true,
    levelIndex: state.levelIndex,
    handsAtLevel: state.handsAtLevel,
    handsPerLevel: options.handsPerLevel,
    currentMinBet,
    nextMinBet: nextMin,
    handsUntilNextLevel,
  };
}

export function applyRisingBlindsToRoomMinBet(
  minBet: number,
  maxBet: number,
  options: RisingBlindsOptions
): { minBet: number; state: RisingBlindsState } {
  const levels = buildRisingBlindLevels(minBet, maxBet);
  const state = initialRisingBlindsState(levels);
  const effectiveMin = options.enabled ? currentRisingBlindMinBet(state) : minBet;
  return { minBet: effectiveMin, state };
}
