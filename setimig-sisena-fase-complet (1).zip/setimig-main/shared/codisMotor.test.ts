/**
 * Codis del motor: cada entrada de `lastRound.highlights[]` i `lastRound.results[]` porta
 * `code` + `params` (només dades) i el text català antic com a reserva (docs/codis-motor.md).
 */
import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { emptyRoomBase, settleGame, type GameHost, type HandSlot, type Player, type Room } from "./gameEngine.ts";
import { createSingleSpanishDeck } from "./spanishDeck.ts";
import { parseGameMessage } from "./gameMessages.ts";
import {
  HIGHLIGHT_CODES,
  RESULT_CODES,
  highlightFallbackText,
  resultFallbackDetail,
  type HighlightMessage,
  type ResultMessage,
} from "./messageCodes.ts";
import type { Card } from "../src/gameTypes.ts";

const deck = createSingleSpanishDeck();
const SUITS: Card["suit"][] = ["hearts", "clubs", "spades", "diamonds"].filter((s) =>
  deck.some((d) => d.suit === s)
) as Card["suit"][];
function card(value: number, suitIdx = 0): Card {
  const suits = [...new Set(deck.map((d) => d.suit))];
  const c = deck.find((d) => d.value === value && d.suit === suits[suitIdx % suits.length]);
  assert.ok(c, `carta ${value}`);
  return { ...c };
}
const VALUES = [...new Set(deck.map((d) => d.value))];
void SUITS;

let slotSeq = 0;
function slot(cards: Card[], bet: number, status: HandSlot["status"], extra: Partial<HandSlot> = {}): HandSlot {
  slotSeq += 1;
  return {
    id: `s-${slotSeq}`,
    cards: cards.map((c, i) => ({ id: `c${slotSeq}-${i}`, card: c, faceUp: true })),
    bet,
    doubled: false,
    canDouble: false,
    mort: false,
    blindPair: false,
    blindUntilBankEnd: false,
    mortOffered: false,
    status,
    ...extra,
  };
}

function seat(id: string, name: string, extra: Partial<Player> = {}): Player {
  return {
    id,
    playerId: `pid-${id}`,
    seatToken: `tok-${id}`,
    name,
    chips: 1000,
    bet: 0,
    isBanker: false,
    status: "stood",
    handSlots: [],
    activeSlotIndex: 0,
    lastRoyal7Payout: 0,
    royal7AsBankerStreak: 0,
    ...extra,
  };
}

const host: GameHost = {
  emitRoomUpdate() {},
  schedule: () => 0 as unknown as ReturnType<typeof setTimeout>,
  clearTimeout() {},
};

function roomWith(banker: Player, players: Player[], jackpot = 0): Room {
  const room = emptyRoomBase("codis", "Codis", 100, jackpot);
  room.players = [banker, ...players];
  room.pot = players.reduce((s, p) => s + p.handSlots.reduce((a, sl) => a + sl.bet, 0), 0);
  room.jackpot = jackpot;
  room.phase = "banker";
  room.roundStartChips = new Map(room.players.map((p) => [p.playerId, p.chips + (p.isBanker ? 0 : p.handSlots.reduce((a, sl) => a + sl.bet, 0))]));
  room.roundStartJackpot = jackpot;
  return room;
}

/** Paràmetres = dades: números, booleans, null, o el nom / id de seient d'un jugador de la taula. */
function assertDataOnly(value: unknown, allowedStrings: Set<string>, where: string) {
  if (value === null || typeof value === "number" || typeof value === "boolean") return;
  if (typeof value === "string") {
    assert.ok(allowedStrings.has(value), `${where}: «${value}» no és un nom ni un id`);
    return;
  }
  if (Array.isArray(value)) {
    value.forEach((v, i) => assertDataOnly(v, allowedStrings, `${where}[${i}]`));
    return;
  }
  if (typeof value === "object") {
    const o = value as Record<string, unknown>;
    if ("code" in o && "params" in o) {
      assert.ok(HIGHLIGHT_CODES.includes(o.code as never), `${where}: codi niat ${String(o.code)}`);
      assertDataOnly(o.params, allowedStrings, `${where}.params`);
      return;
    }
    for (const [k, v] of Object.entries(o)) assertDataOnly(v, allowedStrings, `${where}.${k}`);
    return;
  }
  assert.fail(`${where}: tipus no permès ${typeof value}`);
}

const CATALAN_WORDS = /Passat|Mort|Banca|banca|Empat|natural|Sense canvi|CF|guanya|perd/;

/** JSON dels valors (sense els noms de codi niats, que són identificadors). */
const valuesJson = (v: unknown) => JSON.stringify(v, (k, x) => (k === "code" ? undefined : x));

function assertRoomEntries(room: Room) {
  const lr = room.lastRound;
  assert.ok(lr, "hi ha lastRound");
  // `special` (normes de la casa) és un identificador estable, no text: «mort» | «threeSwap».
  const allowed = new Set([...room.players.flatMap((p) => [p.name, p.id]), "mort", "threeSwap"]);
  for (const h of lr!.highlights) {
    assert.ok(h.code && HIGHLIGHT_CODES.includes(h.code), `highlight amb codi: ${JSON.stringify(h)}`);
    assert.ok(h.params, "highlight amb params");
    assert.equal(typeof h.text, "string");
    assert.doesNotMatch(h.text, /\bCF\b/, `el text de reserva no porta unitat: ${h.text}`);
    assert.equal(h.text, highlightFallbackText({ code: h.code, params: h.params } as HighlightMessage));
    assert.equal(h.name, h.params!.player);
    assertDataOnly(h.params, allowed, `highlight ${h.code}`);
    assert.doesNotMatch(valuesJson(h.params), CATALAN_WORDS);
    const parsed = parseGameMessage(h.text);
    assert.equal(parsed?.code, `engine.result.${h.code}`, `el text de reserva «${h.text}» es reconeix`);
    if ("amount" in h.params!) assert.equal(parsed?.params?.amount, (h.params as { amount: number }).amount);
  }
  for (const r of lr!.results ?? []) {
    assert.ok(r.code && RESULT_CODES.includes(r.code), `result amb codi: ${JSON.stringify(r)}`);
    assert.ok(r.params, "result amb params");
    assert.equal(typeof r.detail, "string");
    assert.doesNotMatch(r.detail, /\bCF\b/, `el detail no porta unitat: ${r.detail}`);
    assert.equal(r.detail, resultFallbackDetail({ code: r.code, params: r.params } as ResultMessage));
    assert.equal(r.params!.player, r.name);
    assert.equal(r.params!.chipDelta, r.chipDelta);
    assertDataOnly(r.params, allowed, `result ${r.code}`);
    assert.doesNotMatch(valuesJson(r.params), CATALAN_WORDS);
    if (r.code === "hands") {
      const own = lr!.highlights.filter((h) => h.name === r.name).map((h) => h.text).join(" · ");
      assert.equal(r.detail, own, "detail = highlights del jugador units amb « · »");
    }
  }
  // La liquidació única porta les mateixes línies.
  assert.deepEqual(room.lastSettlement?.highlights, lr!.highlights);
  assert.deepEqual(room.lastSettlement?.results, lr!.results);
}

const base = { player: "Anna", seatId: "s1", hand: 0, score: 8 };

describe("codis del motor · text de reserva sense unitat", () => {
  const cases: [HighlightMessage, string][] = [
    [{ code: "bust", params: base }, "Passat"],
    [{ code: "mortLoses", params: { ...base, score: 5 } }, "Mort — perd l'aposta"],
    [{ code: "bankWins", params: { ...base, score: 5, bankScore: 6 } }, "Banca guanya"],
    [{ code: "tieSevenHalfBank", params: { ...base, score: 7.5, bankScore: 7.5 } }, "Empat a 7½ — banca"],
    [{ code: "tieBank", params: { ...base, score: 6, bankScore: 6 } }, "Empat — banca"],
    [{ code: "win", params: { ...base, score: 7, amount: 200, bankScore: 6 } }, "+200"],
    [{ code: "winBankBust", params: { ...base, score: 5, amount: 300, bankScore: 9 } }, "+300 (banca passada)"],
    [
      { code: "naturalWin", params: { ...base, score: 7.5, amount: 12500, jackpot: 12200, bankBusted: false } },
      "7 i Mig natural — +12500",
    ],
    [
      {
        code: "specialWin",
        params: { ...base, score: 6, special: "threeSwap", amount: 300, jackpot: 0, bankScore: 5, bankBusted: false, multiplier: 2 },
      },
      "3 canviat ×2 — +300",
    ],
  ];
  for (const [msg, text] of cases) {
    it(`${msg.code} → «${text}»`, () => assert.equal(highlightFallbackText(msg), text));
  }
  it("tots els codis de highlight tenen cas", () => {
    assert.deepEqual(new Set(cases.map(([m]) => m.code)), new Set(HIGHLIGHT_CODES));
  });
  it("resultats: bank, noChange i hands", () => {
    assert.equal(resultFallbackDetail({ code: "bank", params: { player: "B", seatId: "b", chipDelta: 5, score: 6 } }), "Banca");
    assert.equal(resultFallbackDetail({ code: "noChange", params: { player: "A", seatId: "a", chipDelta: 0 } }), "Sense canvi");
    assert.equal(
      resultFallbackDetail({
        code: "hands",
        params: {
          player: "Anna",
          seatId: "s1",
          chipDelta: 0,
          hands: [
            { code: "bust", params: base },
            { code: "win", params: { ...base, hand: 1, score: 7, amount: 200, bankScore: 6 } },
          ],
        },
      }),
      "Passat · +200"
    );
  });
});

describe("codis del motor · liquidació real", () => {
  it("cada codi surt amb code, params i text, i el text és l'antic", () => {
    // Banca amb 6: Anna passada, Pere 7 (guanya), Rosa 6 (empat), Joan 5 (perd), Mia natural, Mort perdut, split Biel.
    const banker = seat("b", "Quim", { isBot: true, isBanker: true, chips: 5000, handSlots: [slot([card(6)], 0, "stood")] });
    const anna = seat("a", "Anna", { handSlots: [slot([card(6), card(5, 1)], 100, "busted")] });
    const pere = seat("p", "Pere", { handSlots: [slot([card(7)], 100, "stood")] });
    const rosa = seat("r", "Rosa", { handSlots: [slot([card(6, 1)], 100, "stood")] });
    const joan = seat("j", "Joan", { handSlots: [slot([card(5, 2)], 100, "stood")] });
    const mia = seat("m", "Mia", { handSlots: [slot([card(7, 1), card(VALUES.find((v) => v >= 10)!)], 100, "stood")] });
    const mort = seat("t", "Toni", { handSlots: [slot([card(3), card(2)], 100, "stood", { mort: true })] });
    const biel = seat("x", "Biel", {
      handSlots: [slot([card(4), card(4, 1), card(1)], 100, "busted"), slot([card(4, 2), card(3, 1)], 100, "stood")],
    });
    const room = roomWith(banker, [anna, pere, rosa, joan, mia, mort, biel], 1000);
    settleGame(host, room);
    assertRoomEntries(room);
    const byName = (n: string) => room.lastRound!.highlights.filter((h) => h.name === n).map((h) => h.code);
    assert.deepEqual(byName("Anna"), ["bust"]);
    assert.deepEqual(byName("Pere"), ["win"]);
    assert.deepEqual(byName("Rosa"), ["tieBank"]);
    assert.deepEqual(byName("Joan"), ["bankWins"]);
    assert.deepEqual(byName("Mia"), ["naturalWin"]);
    assert.deepEqual(byName("Toni"), ["mortLoses"]);
    assert.deepEqual(byName("Biel"), ["bust", "win"]);
    const bielHands = room.lastRound!.highlights.filter((h) => h.name === "Biel").map((h) => h.params!.hand);
    assert.deepEqual(bielHands, [0, 1]);
    const pereH = room.lastRound!.highlights.find((h) => h.name === "Pere")!;
    assert.deepEqual(pereH.params, { player: "Pere", seatId: "p", hand: 0, score: 7, amount: 100, bankScore: 6 });
    assert.equal(pereH.text, "+100");
    const results = room.lastRound!.results!;
    assert.equal(results.find((r) => r.name === "Quim")?.code, "bank");
    assert.match(results.find((r) => r.name === "Biel")?.detail ?? "", /^Passat · \+\d+$/);
  });

  it("banca passada i banca amb 7½: winBankBust, naturalWin (bankBusted) i tieSevenHalfBank", () => {
    const b1 = seat("b", "Quim", { isBanker: true, chips: 5000, handSlots: [slot([card(6), card(5, 1)], 0, "busted")] });
    const p1 = seat("p", "Pere", { handSlots: [slot([card(5)], 100, "stood")] });
    const m1 = seat("m", "Mia", { handSlots: [slot([card(7, 1), card(VALUES.find((v) => v >= 10)!)], 100, "stood")] });
    const r1 = roomWith(b1, [p1, m1]);
    settleGame(host, r1);
    assertRoomEntries(r1);
    assert.deepEqual(r1.lastRound!.highlights.map((h) => h.code), ["winBankBust", "naturalWin"]);
    assert.equal(r1.lastRound!.highlights[0]!.text, "+100 (banca passada)");
    assert.equal((r1.lastRound!.highlights[1]!.params as { bankBusted: boolean }).bankBusted, true);

    const face = VALUES.find((v) => v >= 10)!;
    const b2 = seat("b", "Quim", { isBanker: true, chips: 5000, handSlots: [slot([card(7), card(face, 1)], 0, "stood")] });
    const p2 = seat("p", "Pere", { handSlots: [slot([card(7, 2), card(face, 2)], 100, "stood")] });
    const r2 = roomWith(b2, [p2]);
    settleGame(host, r2);
    assertRoomEntries(r2);
    assert.deepEqual(r2.lastRound!.highlights.map((h) => [h.code, h.text]), [["tieSevenHalfBank", "Empat a 7½ — banca"]]);
  });

  it("partides simulades: tota entrada porta code/params/text i els paràmetres no porten català", () => {
    let seed = 20261027;
    const rnd = () => {
      seed = (seed * 1103515245 + 12345) % 2 ** 31;
      return seed / 2 ** 31;
    };
    const pick = <T,>(a: T[]) => a[Math.floor(rnd() * a.length)]!;
    const names = ["Anna", "Pere", "Rosa", "Joan", "Núria", "Bot Valent"];
    const seen = new Set<string>();
    for (let g = 0; g < 400; g++) {
      const bankCards = Array.from({ length: 1 + Math.floor(rnd() * 3) }, (_, i) => card(pick(VALUES), i));
      const bankScoreBusted = rnd() < 0.25;
      const banker = seat("b", "Quim", {
        isBanker: true,
        isBot: rnd() < 0.5,
        chips: 20000,
        handSlots: [slot(bankCards, 0, bankScoreBusted ? "busted" : "stood")],
      });
      const n = 1 + Math.floor(rnd() * 4);
      const players: Player[] = [];
      for (let i = 0; i < n; i++) {
        const slots: HandSlot[] = [];
        const nSlots = rnd() < 0.2 ? 2 : 1;
        for (let k = 0; k < nSlots; k++) {
          const cards = Array.from({ length: 1 + Math.floor(rnd() * 3) }, (_, j) => card(pick(VALUES), j + k));
          const r = rnd();
          const extra: Partial<HandSlot> =
            r < 0.08 && cards.length === 2 ? { mort: true } : r < 0.14 ? { blindPair: true } : {};
          const busted = rnd() < 0.2;
          slots.push(slot(cards, rnd() < 0.1 ? 0 : 100 * (1 + Math.floor(rnd() * 3)), busted ? "busted" : "stood", extra));
        }
        players.push(seat(`s${i}`, names[i]!, { chips: 2000, handSlots: slots }));
      }
      const room = roomWith(banker, players, rnd() < 0.3 ? 5000 : 0);
      settleGame(host, room);
      assertRoomEntries(room);
      for (const h of room.lastRound!.highlights) seen.add(h.code!);
      for (const r of room.lastRound!.results ?? []) seen.add(`result:${r.code}`);
    }
    for (const c of HIGHLIGHT_CODES) assert.ok(seen.has(c), `la simulació cobreix ${c}`);
    assert.ok(seen.has("result:bank") && seen.has("result:hands"), "la simulació cobreix bank i hands");
  });
});
