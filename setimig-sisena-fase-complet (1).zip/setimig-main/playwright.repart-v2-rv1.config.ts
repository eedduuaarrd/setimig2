import { defineConfig, devices } from "@playwright/test";
import { catalanStorageState } from "./e2e/catalanLocale";
import { e2eServerEnv } from "./e2e/helpers/e2eServerEnv";

const port = Number(process.env.SETIMIG_E2E_PORT ?? process.env.PORT ?? 3177);
const appUrl = process.env.APP_URL ?? `http://127.0.0.1:${port}`;

/** Repart v2 · RV1 (repart-v2.md §8): carta de 2 cares i flip 3D monòton. Només mesures, sense captures. */
export default defineConfig({
  testDir: "./e2e",
  testMatch: "repart-v2-rv1.spec.ts",
  timeout: 150_000,
  retries: 0,
  use: {
    ...devices["iPhone 12"],
    browserName: "chromium",
    baseURL: appUrl,
    locale: "ca-ES",
    storageState: catalanStorageState(),
    colorScheme: "dark",
  },
  globalTeardown: "./e2e/helpers/e2eGlobalTeardown.ts",
  webServer: {
    command: `npm run build && cross-env NODE_ENV=production PORT=${port} APP_URL=${appUrl} PLAYER_TOKEN_SECRET=playwright-e2e-test-secret npm run start`,
    env: e2eServerEnv(),
    url: appUrl,
    reuseExistingServer: false,
    timeout: 120_000,
  },
});
