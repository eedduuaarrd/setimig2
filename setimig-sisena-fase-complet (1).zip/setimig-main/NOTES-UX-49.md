# Setimig UX V19 — motion aplicat als patrons dels repositoris

Aquesta iteració incorpora patrons concrets de Motion (ja present al projecte) i els principis útils observats als repositoris de jocs de cartes: moviments curts, feedback discret, jerarquia clara i respecte pel moviment reduït. No s'afegeixen dependències ni es canvia la lògica del joc.

## Canvis
- La cronologia anima l'entrada i sortida de les accions i utilitza `layout` perquè la llista es reorganitzi amb suavitat quan arriba una acció nova.
- El moviment és curt i discret; es desactiva quan el sistema demana moviment reduït.
- Les files del resum de liquidació entren de manera escalonada molt subtil, sense retardar la interacció ni modificar els resultats.
- Es reutilitza la dependència `motion/react` existent. No s'afegeix la biblioteca 3D `react-ttrpg-cards`, ja que necessita Three.js/WebGL i podria ser excessiva per a cartes espanyoles i una taula mòbil. Les animacions actuals de cartes ja es gestionen amb Motion.
- Es conserva el sistema actual de so i vibració, amb preferències pròpies de Setimig; no s'introdueix una segona capa d'àudio ni es dupliquen efectes.

## Inspiració dels repositoris
- Motion: animacions declaratives, layout i `useReducedMotion`.
- Steellgold/blackjack: animacions de repartiment, disseny adaptable i feedback d'accions com a referència de producte, no com a codi importat.
- playpip/pip-web: experiència calmada, jerarquia clara i separació entre lògica i presentació.
- react-ttrpg-cards: patrons de repartiment/so/accessibilitat, adaptats sense adoptar-ne el motor 3D.
- Playwright: recomanat per validar torns, liquidació i mides mòbils després d'instal·lar dependències.

## Validació
- No s'han afegit paquets.
- Cal executar `npm ci`, `npm run check` i `npm test` en un entorn amb dependències instal·lades i fer una prova manual de partida abans del desplegament.
