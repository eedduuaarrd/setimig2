import { defineConfig, devices } from "@playwright/test";
import { catalanStorageState } from "./e2e/catalanLocale";
import { e2eServerEnv } from "./e2e/helpers/e2eServerEnv";

const port = 3177;
const baseURL = `http://127.0.0.1:${port}`;

export default defineConfig({
  testDir: "./e2e",
  testMatch: "pas15-smoke.spec.ts",
  timeout: 120_000,
  retries: 0,
  projects: [{ name: "chromium", use: { ...devices["Pixel 5"], browserName: "chromium" } }],
  use: {
    locale: "ca-ES",
    storageState: catalanStorageState(),
    baseURL,
    viewport: { width: 390, height: 844 },
  },
  globalTeardown: "./e2e/helpers/e2eGlobalTeardown.ts",
  webServer: {
    command: `cross-env NODE_ENV=production PORT=${port} APP_URL=${baseURL} tsx server.ts`,
    env: e2eServerEnv(),
    url: `${baseURL}/api/health`,
    reuseExistingServer: false,
    timeout: 120_000,
  },
});
