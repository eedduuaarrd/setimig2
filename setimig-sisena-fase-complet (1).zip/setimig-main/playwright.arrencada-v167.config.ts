import { defineConfig } from "@playwright/test";
import { e2eServerEnv } from "./e2e/helpers/e2eServerEnv";

const port = Number(process.env.SETIMIG_E2E_PORT ?? 3304);
/** v167 · arrencada. Cal `npm run build` abans; el webServer engega el build de producció a SETIMIG_E2E_PORT. */
export default defineConfig({
  testDir: "./e2e",
  testMatch: ["arrencada-v167.spec.ts", "intro-primer.spec.ts", "login-marca.spec.ts"],
  timeout: 120_000,
  retries: 0,
  workers: 1,
  use: { browserName: "chromium", baseURL: `http://127.0.0.1:${port}`, viewport: { width: 390, height: 844 }, locale: "en-US", colorScheme: "dark" },
  globalTeardown: "./e2e/helpers/e2eGlobalTeardown.ts",
  webServer: {
    command: `cross-env NODE_ENV=production SETIMIG_HOST=127.0.0.1 PORT=${port} APP_URL=http://127.0.0.1:${port} tsx server.ts`,
    env: e2eServerEnv(),
    url: `http://127.0.0.1:${port}/`,
    reuseExistingServer: false,
    timeout: 60_000,
  },
});
